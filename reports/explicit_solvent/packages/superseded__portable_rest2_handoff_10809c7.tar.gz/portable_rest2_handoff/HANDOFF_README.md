# Portable explicit-solvent REST2 — handoff package

Everything needed to install and mechanically validate the pipeline on a machine that has never
seen the source repository. Verify the checksums first:

```bash
sha256sum -c SHA256SUMS
```

## Install

```bash
conda env create -f environment.yml         # creates: escort-ais-explicit
conda activate escort-ais-explicit
python -m pip install ./escort_ais-0.1.0-py3-none-any.whl --no-deps
```

`--no-deps` is deliberate: OpenMM, OpenFF, AmberTools and RDKit come from conda, and letting pip
resolve them produces a different and usually broken stack. `environment.yml` therefore lists every
runtime dependency. An editable install is not required and the source checkout is never needed.

## Validate on the target machine — REQUIRED

**Nothing in this package has been validated on your machine.** It was built and mechanically
verified on the source machine only. Run this before trusting anything:

```bash
escort-explicit validate-env --platform CPU
escort-explicit validate-env --platform CUDA --device 0     # if you will use a GPU
escort-explicit validate-system --system cyclo_rgdfv --experiment rgd_rest2_10rung
cd "$(mktemp -d)"
escort-explicit smoke --system small_macrocycle_smoke --out-root ./portable-test-runs --platform CPU
```

The smoke must print `status: completed` with at least two exchange rounds and exit `0`. It takes
about a minute on CPU. `validate-env` fails if `sqm` (AmberTools) is not on PATH — without it
AM1-BCC charges are silently unobtainable.

## Run

```bash
escort-explicit prepare --system cyclo_rgdfv --experiment rgd_rest2_10rung \
  --out-root ./runs --platform CUDA --device 0
escort-explicit rest2 --bundle ./runs/<TIMESTAMP>__cyclo_rgdfv__bundle__<HASH> \
  --out-root ./runs --platform CUDA --device 0
```

The shipped manifests are inside the wheel, so `--system cyclo_rgdfv` works with no paths. The
copies here are for reading and for editing into your own variants.

## What the shipped manifests claim

| file | status |
|---|---|
| `cyclo_rgdfv.yaml` | the exact zwitterion, canonical hash `59d4422635f7…`, formal charge 0, Sage 2.2 / AM1-BCC, **dodecahedron** box (the geometry the ladder pilots ran in) |
| `rgd_rest2_10rung.yaml` | `ladder_status: pilot_supported` — system-specific pilot evidence for RGD **only**; not convergence, not production readiness |
| `macrocycle_pilot_8rung.yaml` | `ladder_status: unvalidated` — a template for running your own pair-resolved acceptance pilot |
| `smoke.yaml` | `ladder_status: unvalidated` — picoseconds; proves execution, nothing scientific |

## Limits

* The smoke proves installability and mechanical execution. It does not validate a ladder.
* A new macrocycle needs its own pair-resolved acceptance pilot before any production ladder.
* Restart safety, the 2 fs / 4 fs hydrogen-mass-repartitioning equivalence, and convergence are
  **not** established. Do not start long production on the strength of this package.
