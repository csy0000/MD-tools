#!/usr/bin/env python3
"""Evaluate importance-sampling weights from AIS work values.

Reads ``ais_work.csv`` from one or more AIS output directories, computes
normalised IS weights, ESS, and the Jarzynski free-energy estimate, and
writes:

    ais_weights.npy               — raw log IS weights  (log w_i = -W_i)
    ais_weights_normalized.npy    — normalised weights  (sum to 1)
    ais_weight_summary.json       — ESS, mean work, Jarzynski ΔF, etc.

Usage
-----
    python -m escort_ais.experiments.prep.step11_evaluate_openmm_ais_weights --ais-dir <AIS_OUTPUT_DIR>
    python -m escort_ais.experiments.prep.step11_evaluate_openmm_ais_weights --ais-dir dir1 dir2 ...
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp


def load_work_reduced(csv_path: Path) -> np.ndarray:
    """Load successful work values from ais_work.csv."""
    import csv
    works: list[float] = []
    with csv_path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            if row.get("success", "True").lower() in {"true", "1", "yes"}:
                try:
                    w = float(row["work_reduced"])
                    if not (w != w):   # filter NaN
                        works.append(w)
                except (KeyError, ValueError):
                    pass
    return np.array(works, dtype=float)


def evaluate_weights(ais_dir: Path, overwrite: bool = False) -> dict:
    """Evaluate IS weights for a single AIS output directory."""
    csv_path = ais_dir / "ais_work.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"No ais_work.csv found in {ais_dir}")

    works = load_work_reduced(csv_path)
    n = len(works)
    if n == 0:
        raise ValueError(f"No successful samples found in {csv_path}")

    # Log IS weights: log w_i = -W_i (unnormalised)
    log_weights = -works

    # Normalised weights
    lse = logsumexp(log_weights)
    log_weights_norm = log_weights - lse
    weights_norm = np.exp(log_weights_norm)

    # ESS
    ess = float(np.exp(2 * lse - logsumexp(2 * log_weights)))
    ess_normalized = ess / n

    # Jarzynski ΔF (reduced units)
    jarzynski_df = float(-logsumexp(-works) + np.log(n))

    # Additional statistics
    summary = {
        "n_samples": n,
        "work_reduced_mean": float(np.mean(works)),
        "work_reduced_std": float(np.std(works)),
        "work_reduced_min": float(np.min(works)),
        "work_reduced_max": float(np.max(works)),
        "work_reduced_median": float(np.median(works)),
        "log_weight_max": float(np.max(log_weights)),
        "log_weight_min": float(np.min(log_weights)),
        "ess": ess,
        "ess_normalized": ess_normalized,
        "jarzynski_delta_f_reduced": jarzynski_df,
        "weight_max": float(np.max(weights_norm)),
        "weight_sum": float(np.sum(weights_norm)),
    }

    # Write outputs
    weights_path = ais_dir / "ais_weights.npy"
    weights_norm_path = ais_dir / "ais_weights_normalized.npy"
    summary_path = ais_dir / "ais_weight_summary.json"

    for path in [weights_path, weights_norm_path, summary_path]:
        if path.exists() and not overwrite:
            raise FileExistsError(
                f"{path} already exists. Pass --overwrite to replace."
            )

    np.save(weights_path, log_weights)
    np.save(weights_norm_path, weights_norm)
    summary_path.write_text(json.dumps(summary, indent=2))

    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate AIS importance-sampling weights.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--ais-dir", required=True, nargs="+", type=Path,
        help="One or more AIS output directories containing ais_work.csv.",
    )
    parser.add_argument(
        "--overwrite", action="store_true",
        help="Overwrite existing weight files.",
    )
    args = parser.parse_args()

    for ais_dir in args.ais_dir:
        print(f"\n=== {ais_dir} ===")
        try:
            summary = evaluate_weights(ais_dir, overwrite=args.overwrite)
            print(f"  n_samples           : {summary['n_samples']}")
            print(f"  work_reduced mean   : {summary['work_reduced_mean']:.4f} ± {summary['work_reduced_std']:.4f}")
            print(f"  ESS                 : {summary['ess']:.1f} / {summary['n_samples']} "
                  f"({100 * summary['ess_normalized']:.1f}%)")
            print(f"  Jarzynski ΔF        : {summary['jarzynski_delta_f_reduced']:.4f} (reduced)")
        except (FileNotFoundError, ValueError, FileExistsError) as exc:
            print(f"  ERROR: {exc}")


if __name__ == "__main__":
    main()
