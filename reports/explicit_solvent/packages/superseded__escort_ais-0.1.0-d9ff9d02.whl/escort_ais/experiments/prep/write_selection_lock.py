"""Freeze the cutoff-selection protocol BEFORE any reference error is looked at (brief rule 12).

Rule 12 is the one rule in this campaign that cannot be repaired after the fact. Every threshold
below is either quoted from Section 9.4 of the brief or read off the data that already exists on
disk; none is tuned, and none may be revised once a reference comparison has been made. A threshold
chosen after seeing which value would have produced the "right" ALA answer is not a threshold, it
is a fit -- and the resulting cutoff carries no evidence at all about a system whose answer is not
already known, which is the entire point of the exercise.

Two boundaries, deliberately distinct (Section 9.5):

* ``source_burn_cutoff`` -- the earliest hot block judged usable as an AIS source.
* ``production_start``   -- the first UNTOUCHED block after the confirmation streak. Every record
  used to select or confirm the cutoff is quarantined regardless of which side of the cutoff it
  falls on, so the production estimate cannot inherit the adaptivity of the selection.

The gap between them is not a claim that the intervening trajectory was physically unequilibrated.

WHAT THIS FILE DOES NOT DO. It does not run the scan, and it does not look at any reference. It
records the rules and the immutable inputs, hashes them, and stops. The scan reads this file.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path

from escort_ais.common.paths import project_root

ROOT = project_root()

#: Section 9.4, verbatim. The kT tolerances are all the same 0.20 kT screen value; they are listed
#: separately rather than as one constant because they gate different quantities and a later
#: campaign may justify moving one without the others.
SSG_V1_CRITERIA = {
    "1_estimator_precision": {
        "statistic": "grouped-bootstrap half-width of every reported basin free-energy difference",
        "threshold_kT": 0.20, "direction": "at most",
        "grouping": "hot block first, then AIS seed/start configuration"},
    "2_temporal_agreement": {
        "statistic": "pairwise slab gap in free-energy difference",
        "threshold": "max(0.20 kT, 2 * pooled_standard_error)", "direction": "at most"},
    "3_no_material_residual_drift": {
        "statistic": "blockwise time-slope CI and fitted end-to-end drift across the suffix",
        "requires": ["slope CI includes zero", "end-to-end drift below 0.20 kT"],
        "method": "robust regression or block bootstrap; record estimate AND interval"},
    "4_block_influence": {
        "leave_one_block_out_range_kT": 0.20,
        "max_single_block_weight_share": 0.25,
        "scope": "in any required basin"},
    "5_importance_support": {
        "overall_forward_ess_min": 100, "per_required_basin_ess_min": 50,
        "on_failure": "return AIS_WEIGHT_COLLAPSE or REGION_UNSAMPLED",
        "note": "do NOT loosen after looking at the reference"},
    "6_landing_distribution_stability": {
        "test": "bootstrap-calibrated MMD or the repository's validated weighted-Wasserstein test",
        "level": 0.05,
        "null_calibration": "within-suffix block resampling",
        "note": "distance predeclared here, never chosen against the answer"},
    "7_replicate_consistency": {
        "statistic": "independent AIS seed sets at MATCHED shot counts",
        "threshold": "max(0.20 kT, 2 * pooled_standard_error)"},
}

ELIGIBILITY = {
    "min_diagnostic_blocks_in_candidate": 6,
    "n_slabs": 3, "min_blocks_per_slab": 2,
    "all_required_basins_have_support": True,
    "candidate_uses_blocks": "c..t only; never future blocks",
    "selection": "earliest candidate c passing ALL criteria at a decision time",
    "persistence_decisions": 3,
    "persistence_tolerance_blocks": 1,
    "on_any_failure": "persistence streak resets",
    "on_exhaustion": "fail as HOT_NOT_CONVERGED or TRAJECTORY_EXHAUSTED; "
                     "do NOT wrap and do NOT default to the last available cutoff",
}

#: Section 8. REFERENCE_ORACLE_CUTOFF is computed only after every selection is locked and can
#: never be selected or promoted -- it exists to quantify how much hindsight would have bought.
POLICIES = {
    "LEGACY_ALL": "use every record, no cutoff (current behaviour)",
    "LEGACY_GATE_PURGE": "the existing gate's purge rule",
    "FIXED_CUTOFF_SWEEP": "every eligible non-overlapping block boundary; maps sensitivity, "
                          "NOT a deployable winner",
    "SSG_V1": "the Sequential Suffix Gate defined in Section 9",
    "REFERENCE_ORACLE_CUTOFF": "hindsight cutoff minimising reference error; DIAGNOSTIC ONLY, "
                               "overfitting evidence, never selectable or promotable",
}

ESTIMATORS = {
    "S_FULL": "stratified, all records",
    "S_SUFFIX": "stratified, records after the selected source cutoff",
    "U_SUFFIX": "unstratified, records after the cutoff; final validation uses only untouched "
                "held-out records",
}


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:16]


def system_block(campaign: Path, stage: str, slug: str, partition: Path) -> dict:
    blocks = json.loads((campaign / stage / "blocks.json").read_text())
    shots = campaign / stage / "ais_shots.parquet"
    spec = json.loads(partition.read_text())
    # Two partition schemas are in play and they are NOT interchangeable: nd_basin_tree writes
    # {"n_cv", "cells", "cut_cvs"} (the macrocycle path) while the 2-D alanine barrier_partition
    # writes {"basins", "cuts"}. Reading only "cells" silently recorded n_cells=None for alanine --
    # a lock that does not say how many cold cells it froze is not a lock.
    if "cells" in spec:
        n_cells, cut_cvs, schema = len(spec["cells"]), spec.get("cut_cvs"), "nd_basin_tree/cells"
    elif "basins" in spec:
        # barrier_partition names its cut coordinate in "dimension", as a CV NAME ("phi"/"psi"),
        # where nd_basin_tree uses integer indices. Recorded as given rather than mapped to an
        # index: the 2-D dipeptide CV order is a convention of a different module, and inventing an
        # index here would put a number in the lock that no file on disk actually asserts.
        n_cells, schema = len(spec["basins"]), "barrier_partition/basins"
        cut_cvs = sorted({c["dimension"] for c in spec.get("cuts", [])
                          if isinstance(c, dict) and "dimension" in c}) or None
    else:
        raise SystemExit(f"{partition}: unrecognised partition schema, keys={sorted(spec)}")
    return {
        "stage": stage,
        "hot_walker": blocks["walker"],
        "hot_walker_hash": blocks["walker_hash"],
        "n_frames": blocks["n_frames"],
        # Section 9.1: non-overlapping, contiguous, never wrapping.
        "block_definition": {
            "n_blocks": blocks["n_blocks"],
            "boundaries": blocks["blocks"],
            "contiguous_non_overlapping": True,
            "wraps": False,
            "frames_per_block": blocks["blocks"][0][1] - blocks["blocks"][0][0],
        },
        "diagnostic_ais": {
            "shots_per_block_per_seed_set": blocks["k_shots"],
            "n_seed_sets": blocks["n_seed_sets"],
            "matched_counts_across_blocks": True,
            "same_source_frames_across_policies": True,
            "shots_parquet": str(shots.relative_to(ROOT)),
            "shots_parquet_sha256_16": sha(shots),
            "record_role": "diagnostic -- quarantined from production under 9.4 regardless of "
                           "which side of the cutoff they fall on",
        },
        # Section 10: the cold partition is an INPUT, frozen here, never re-derived by the scan.
        "cold_cells": {
            "partition_file": str(partition.relative_to(ROOT)),
            "partition_sha256_16": sha(partition),
            "n_cells": n_cells,
            "cut_cvs": cut_cvs,
            "schema": schema,
            "immutable": True,
            "note": "cold cells are fixed thermodynamic output bins first and possible kinetic "
                    "states only after lag/stationarity/held-out CK validation (rule 16)",
        },
        "system_slug": slug,
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--campaign", type=Path,
                    default=ROOT / "campaigns/20260808T074306Z__forward-prep-burnin")
    ap.add_argument("--force", action="store_true",
                    help="overwrite an existing lock. Refused by default: a lock rewritten after "
                         "the scan has run is no longer a pre-registration.")
    a = ap.parse_args(argv)

    out = a.campaign / "selection_lock.json"
    if out.exists() and not a.force:
        raise SystemExit(f"{out} already exists. The lock is written ONCE, before any reference "
                         f"error is viewed; rewriting it silently would void rule 12. Pass "
                         f"--force only if no scan has consumed it yet.")

    lock = {
        "schema": "selection_lock/v1",
        "written_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "git_dirty": bool(subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()),
        "brief": "claude-instruction/20260807-36hr-burnin-test.md",
        "declaration": {
            "reference_consulted_before_locking": False,
            "rule_12": "Cutoffs and thresholds are frozen here, before any reference error is "
                       "viewed. Neither the REMD answer nor a historically good ALA/RGD result "
                       "entered any threshold below.",
            "thresholds_provenance": "quoted from Section 9.4 of the brief; none tuned on data",
        },
        "boundaries": {
            "source_burn_cutoff": "earliest hot block judged usable as an AIS source",
            "gate_decision_block": "block at which the confirmation streak completes",
            "production_start": "first UNTOUCHED hot block after the gate decision",
            "note": "production_start > source_burn_cutoff does NOT assert the intervening "
                    "trajectory was physically unequilibrated (Section 9.5)",
        },
        "ssg_v1_criteria": SSG_V1_CRITERIA,
        "eligibility": ELIGIBILITY,
        "policies": POLICIES,
        "estimator_matrix": ESTIMATORS,
        "stratification_eligibility": {
            "source_strata_chosen_from": "the frozen cold-cell partition ONLY -- never from the "
                                         "reference answer or from AIS outcomes",
            "requires": [
                "pi_H identified with adequate transition/occupancy support",
                "adequate conditional ESS for every source-to-landing contribution",
                "A_b[i,m] temporally stable within each source cell/state",
                "all thermodynamically material source cells represented",
                "S_FULL, S_SUFFIX and held-out U_SUFFIX agree within 0.20 kT or 2 pooled SE "
                "at matched effective cost",
                "leave-one-source-state-out and leave-one-hot-block-out pass the same "
                "support/influence standards as the unstratified estimator"],
            "never_repairs": ["missing cells", "biased configurations within a cell",
                              "hidden slow coordinates", "inaccurate pi_H", "weight collapse",
                              "execution-state leakage"],
            "reporting": "variance and GPU cost reported alongside bias/stability -- a valid but "
                         "much noisier estimator is not a free rescue",
        },
        "transition_model_caveats": {
            "transitions_counted_only_within": "genuinely chronological, continuous hot trajectory",
            "never_across": ["trajectory", "replica", "walker", "file segment",
                             "restart discontinuity", "wrapped index"],
            "replica_index_streams_are_not_physical_kinetics": True,
        },
        "systems": {},
    }

    lock["systems"]["alanine"] = system_block(
        a.campaign, "blocked_ais", "alanine_dipeptide",
        ROOT / "reports/alanine/conditional_bar/campaign_v8/basin_tree.json")
    lock["systems"]["cyclo_rgdfv"] = system_block(
        a.campaign, "blocked_ais_rgd", "cyclo_rgdfv",
        ROOT / "data/rgd/condbar_v3/partition.json")

    body = json.dumps(lock, indent=2, sort_keys=False)
    lock_hash = hashlib.sha256(body.encode()).hexdigest()[:16]
    out.write_text(body + "\n")
    (a.campaign / "selection_lock.sha256").write_text(lock_hash + "\n")

    print(f"wrote {out}")
    print(f"  lock sha256[:16] = {lock_hash}   (recorded in selection_lock.sha256)")
    for name, s in lock["systems"].items():
        cc = s["cold_cells"]
        print(f"  {name:<12} {s['block_definition']['n_blocks']} blocks x "
              f"{s['block_definition']['frames_per_block']} frames, "
              f"{s['diagnostic_ais']['shots_per_block_per_seed_set']} shots x "
              f"{s['diagnostic_ais']['n_seed_sets']} seed sets; "
              f"{cc['n_cells']} cold cells on CV{cc['cut_cvs']}")
    print("\nrule 12 satisfied: thresholds frozen before any reference error was viewed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
