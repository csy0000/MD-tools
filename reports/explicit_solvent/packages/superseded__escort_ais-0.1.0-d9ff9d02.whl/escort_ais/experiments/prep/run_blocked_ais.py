"""Fresh forward AIS from every chronological hot block -- the data the cutoff scan consumes.

Section 9.2 of the 36-hour brief. The saved hot walker is cut into contiguous, non-overlapping
chronological blocks and a MATCHED number of fresh AIS shots is launched from each. Comparing
blocks is what tests source-time nonstationarity; the Section 7 controls already established that
execution order and generation labels do not move the distribution, so a block-to-block difference
here is a property of the SOURCE, not of the harness.

Design rules this obeys, each of which is a way the experiment could otherwise be ruined:

* **Matched counts.** Every block gets the same number of shots from the same seed sets. Giving a
  late block more shots because its estimate looks better is how a cutoff scan becomes a fit.
* **Non-overlapping blocks, never wrapping.** Adjacent blocks share no frame, so a "difference
  between blocks" cannot be two views of the same configurations.
* **Two independent seed sets over the SAME frames.** This separates AIS stochastic scatter from
  source-time drift: the seed sets differ only in their random streams, so their disagreement is a
  floor below which no block-to-block claim is meaningful.
* **Append-only records.** Every shot carries its exact hot frame, block, seed and role. Nothing is
  deleted; the cutoff policies are masks over this one table (§2 rule 3), so all policies are
  compared on identical raw rows.

All rows are ``record_role=diagnostic``: they select the cutoff, so under §9.4 they are quarantined
from the production estimate no matter which side of the boundary they fall on.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np

from escort_ais.analysis.forward_prep_burnin import (ShotBatch, batch_rows, hot_blocks,
                                                     pick_frames, read_batch_works, run_batch,
                                                     write_seed_dir)
from escort_ais.common.paths import project_root

ROOT = project_root()
ALA_WALKER = ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"


def sha_head(p: Path, n: int = 1 << 20) -> str:
    with p.open("rb") as f:
        return hashlib.sha256(f.read(n)).hexdigest()[:16]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--campaign", type=Path, required=True)
    ap.add_argument("--walker", type=Path, default=ALA_WALKER)
    ap.add_argument("--system", default="alanine")
    ap.add_argument("--n-blocks", type=int, default=12)
    ap.add_argument("--k-shots", type=int, default=128, help="shots per block PER SEED SET")
    ap.add_argument("--n-seed-sets", type=int, default=2)
    ap.add_argument("--t-ais", type=int, default=500)
    ap.add_argument("--hz-n-observations", type=int, default=20)
    ap.add_argument("--s-min", type=float, default=0.7)
    ap.add_argument("--devices", default="0,1,2")
    ap.add_argument("--seed", type=int, default=20260808)
    ap.add_argument("--stage", default="blocked_ais")
    ap.add_argument("--cv-definition", default=None,
                    help="system slug whose DECLARED CVs the writer must use. MANDATORY for a "
                         "macrocycle: without it the writer falls back to mdtraj phi/psi, finds "
                         "none on a cyclic topology, and stores all-NaN CV columns.")
    ap.add_argument("--omega-exclude-npy", default=None,
                    help="bonds the REMD ladder leaves unscaled. MANDATORY for a macrocycle: "
                         "scaling the secondary-amide omegas gives a different ensemble.")
    ap.add_argument("--seed-config", default=None,
                    help="seed-dir config.json template carrying the system's prmtop paths")
    a = ap.parse_args(argv)

    import mdtraj as md
    import pandas as pd

    work = a.campaign / a.stage
    work.mkdir(parents=True, exist_ok=True)
    devices = [d.strip() for d in a.devices.split(",") if d.strip()]
    git = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    wh = sha_head(a.walker / "trajectory.dcd")

    with md.formats.DCDTrajectoryFile(str(a.walker / "trajectory.dcd")) as f:
        n_frames = len(f)
    blocks = hot_blocks(n_frames, a.n_blocks)
    print(f"[init] {a.system}: {n_frames} frames -> {a.n_blocks} non-overlapping blocks of "
          f"{blocks[0][1] - blocks[0][0]}; {a.k_shots} shots x {a.n_seed_sets} seed sets each "
          f"= {a.n_blocks * a.k_shots * a.n_seed_sets} shots", flush=True)

    # Frames are chosen ONCE per block and shared by both seed sets, so the seed sets differ only
    # in their random streams -- that is what makes their spread a pure AIS-noise floor.
    rng = np.random.default_rng(a.seed)
    frames_by_block = {b: pick_frames(lo, hi, a.k_shots, rng) for b, (lo, hi) in enumerate(blocks)}
    seed_dirs = {b: write_seed_dir(a.walker, fr, work / f"seeds_b{b:02d}",
                                   config_template=a.seed_config)
                 for b, fr in frames_by_block.items()}

    plan = []
    for s in range(a.n_seed_sets):
        for b in range(a.n_blocks):
            plan.append(ShotBatch(
                batch_id=f"b{b:02d}_s{s}", system=a.system, record_role="diagnostic",
                generation_label=f"seedset{s}", block_id=b,
                frame_indices=tuple(int(x) for x in frames_by_block[b]),
                ais_seed=a.seed + 1000 * s + 7 * b, exec_order_index=len(plan),
                device=devices[len(plan) % len(devices)]))

    rows, status, t_start = [], [], time.time()

    def one(batch: ShotBatch):
        out = work / batch.batch_id
        t0 = time.time()
        res = run_batch(batch, seed_dirs[batch.block_id], out, t_ais=a.t_ais,
                        n_obs=a.hz_n_observations, s_min=a.s_min,
                        cv_definition=a.cv_definition,
                        omega_exclude_npy=a.omega_exclude_npy)
        wall = round(time.time() - t0, 1)
        if res["returncode"] != 0:
            print(f"[FAIL] {batch.batch_id} rc={res['returncode']}\n{res['stderr_tail'][-600:]}",
                  flush=True)
            return batch, None, dict(batch_id=batch.batch_id, ok=False, wall_s=wall,
                                     returncode=res["returncode"])
        df = read_batch_works(out)
        print(f"[ok  ] {batch.batch_id} blk{batch.block_id:>2} GPU{batch.device} "
              f"{len(df)} shots  <W>={df['W_reduced'].mean():+.3f} kT  {wall:.0f}s", flush=True)
        return batch, df, dict(batch_id=batch.batch_id, ok=True, wall_s=wall, returncode=0)

    # one worker per GPU: the one-process-per-device rule, and no CUDA MPS
    with ThreadPoolExecutor(max_workers=len(devices)) as ex:
        for batch, df, st in ex.map(one, plan):
            status.append(st)
            if df is not None:
                rows += batch_rows(batch, df, git_commit=git, walker_hash=wh)

    if not rows:
        (work / "status.json").write_text(json.dumps(status, indent=2) + "\n")
        print("no batch produced records")
        return 1

    tab = pd.DataFrame(rows)
    tab.to_parquet(work / "ais_shots.parquet", index=False)
    (work / "blocks.json").write_text(json.dumps(dict(
        walker=str(a.walker), walker_hash=wh, n_frames=int(n_frames),
        n_blocks=a.n_blocks, k_shots=a.k_shots, n_seed_sets=a.n_seed_sets,
        blocks=[[int(lo), int(hi)] for lo, hi in blocks],
        frames_by_block={str(k): [int(x) for x in v] for k, v in frames_by_block.items()},
        git_commit=git, batches=status,
        wall_clock_s=round(time.time() - t_start, 1)), indent=2) + "\n")

    print(f"\n=== blockwise <W> (kT), {a.system} ===")
    piv = tab.pivot_table(index="block_id", columns="generation_label",
                          values="W_reduced", aggfunc="mean")
    print(piv.round(3).to_string())
    print(f"\nwrote {work}/ais_shots.parquet ({len(rows)} rows) in "
          f"{(time.time() - t_start)/60:.1f} min")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
