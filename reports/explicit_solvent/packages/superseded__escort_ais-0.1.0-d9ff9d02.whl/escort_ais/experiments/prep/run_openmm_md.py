#!/usr/bin/env python3
"""Run an OpenMM MD or REMD simulation from a build_topology output directory.

Examples
--------
# Single plain MD (implicit, 1 ns):
python -m escort_ais.experiments.prep.run_openmm_md \\
    --topology-dir data/topology/ff19sb_gbn2 \\
    --duration-ns 1.0

# Single scaled MD for AIS (REST2 s=0.1875, 10 ns):
python -m escort_ais.experiments.prep.run_openmm_md \\
    --topology-dir data/topology/ff19sb_gbn2 \\
    --duration-ns 10.0 \\
    --scale-factor 0.1875

# REST2 REMD (requires rest2/ladder.json from build-topology):
python -m escort_ais.experiments.prep.run_openmm_md \\
    --topology-dir data/topology/ff19sb_gbn2 \\
    --duration-ns 10.0 \\
    --remd \\
    --exchange-interval-ps 1.0

Platform note: CUDA context init fails on this machine.
Use --platform OpenCL or --platform CPU.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


from escort_ais.methods.md_run import (
    map_topology_solvent,
    run_remd,
    run_single_md,
    validate_ensemble_solvent,
)
from escort_ais.common.paths import ensure_dir


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run OpenMM MD or REMD from a build_topology output directory.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "--topology-dir", required=True, type=str,
        help="build_topology output directory (contains system.prmtop/inpcrd/config.json).",
    )
    parser.add_argument(
        "--duration-ns", required=True, type=float,
        help="Production simulation length in nanoseconds.",
    )
    parser.add_argument(
        "--temperature-k", type=float, default=300.0,
        help="Simulation temperature (K).",
    )
    parser.add_argument(
        "--ensemble", type=str, default=None,
        choices=["nvt", "npt"],
        help="Ensemble. Defaults to 'npt' for explicit, 'nvt' for implicit.",
    )
    parser.add_argument(
        "--scale-factor", type=float, default=1.0,
        help="REST2 scale factor applied to solute atoms (1.0 = physical).",
    )
    parser.add_argument(
        "--scaled-system-xml", type=str, default=None,
        help="Path to a pre-built System XML (from build_rest2_systems); "
             "overrides --scale-factor.",
    )
    parser.add_argument(
        "--remd", action="store_true",
        help="Run REST2 REMD; requires topology_dir/rest2/ladder.json.",
    )
    parser.add_argument(
        "--exchange-interval-ps", type=float, default=1.0,
        help="Replica exchange attempt interval (ps). Only for --remd.",
    )
    parser.add_argument(
        "--timestep-fs", type=float, default=2.0,
        help="MD timestep in femtoseconds.",
    )
    parser.add_argument(
        "--equilibration-nvt-ps", type=float, default=100.0,
        help="NVT equilibration length (ps).",
    )
    parser.add_argument(
        "--equilibration-npt-ps", type=float, default=100.0,
        help="NPT equilibration length (ps). Ignored for implicit solvent.",
    )
    parser.add_argument(
        "--minimize-steps", type=int, default=10_000,
        help="Maximum energy minimization steps.",
    )
    parser.add_argument(
        "--traj-interval-ps", type=float, default=10.0,
        help="Trajectory and state-log write interval (ps).",
    )
    parser.add_argument(
        "--checkpoint-interval-ps", type=float, default=100.0,
        help="Checkpoint write interval (ps).",
    )
    parser.add_argument(
        "--friction-per-ps", type=float, default=1.0,
        help="Langevin friction coefficient (ps⁻¹).",
    )
    parser.add_argument(
        "--pressure-bar", type=float, default=1.0,
        help="NPT pressure (bar).",
    )
    parser.add_argument(
        "--platform", type=str, default=None,
        help="OpenMM platform (CUDA, OpenCL, CPU). Auto-selected if not given.",
    )
    parser.add_argument(
        "--seed", type=int, default=42,
        help="Random seed for velocity initialization.",
    )
    parser.add_argument(
        "--output-dir", type=str, default=None,
        help="Output directory. Auto-derived from topology dir and parameters if not given.",
    )
    parser.add_argument(
        "--gb-radii", type=str, default="mbondi3",
        help="GB radii set applied via parmed changeRadii before createSystem. GBn2 implicit only. "
             "Default 'mbondi3' -- the reference Hamiltonian. Pass 'amber-builtin' for the legacy "
             "AmberPrmtopFile GB branch (differs by ~16 kJ/mol; only to reproduce pre-2026-07-31 runs).",
    )

    return parser.parse_args()


def _validate(args: argparse.Namespace) -> None:
    topology_dir = Path(args.topology_dir)
    if not (topology_dir / "config.json").exists():
        print(
            f"error: {topology_dir}/config.json not found. "
            "Provide a build_topology output directory.",
            file=sys.stderr,
        )
        sys.exit(1)

    import json as _json
    topo_cfg = _json.loads((topology_dir / "config.json").read_text(encoding="utf-8"))
    topology_solvent = topo_cfg.get("solvent", "")
    try:
        solvent = map_topology_solvent(topology_solvent)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)

    ensemble = args.ensemble or ("npt" if solvent == "explicit" else "nvt")
    try:
        validate_ensemble_solvent(ensemble, solvent)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)

    if args.remd and not (topology_dir / "rest2" / "ladder.json").exists():
        print(
            f"error: --remd requires topology_dir/rest2/ladder.json. "
            "Run build_rest2_systems(..., mode='remd') first.",
            file=sys.stderr,
        )
        sys.exit(1)

    if args.remd and args.scale_factor != 1.0:
        print(
            "warning: --scale-factor is ignored when --remd is set "
            "(each replica's scale is read from ladder.json).",
            file=sys.stderr,
        )
    if args.remd and args.scaled_system_xml is not None:
        print(
            "warning: --scaled-system-xml is ignored when --remd is set.",
            file=sys.stderr,
        )


def main() -> None:
    args = parse_args()
    _validate(args)

    topology_dir = Path(args.topology_dir)
    output_dir = Path(args.output_dir) if args.output_dir else None

    common_kwargs = dict(
        temperature_k=args.temperature_k,
        duration_ns=args.duration_ns,
        ensemble=args.ensemble,
        timestep_fs=args.timestep_fs,
        platform=args.platform,
        seed=args.seed,
        output_dir=output_dir,
        friction_per_ps=args.friction_per_ps,
        pressure_bar=args.pressure_bar,
        minimize_steps=args.minimize_steps,
        equilibration_nvt_ps=args.equilibration_nvt_ps,
        equilibration_npt_ps=args.equilibration_npt_ps,
        traj_interval_ps=args.traj_interval_ps,
        checkpoint_interval_ps=args.checkpoint_interval_ps,
    )

    if args.remd:
        summary = run_remd(
            topology_dir,
            exchange_interval_ps=args.exchange_interval_ps,
            **common_kwargs,
        )
    else:
        summary = run_single_md(
            topology_dir,
            scale_factor=args.scale_factor,
            scaled_system_xml=Path(args.scaled_system_xml) if args.scaled_system_xml else None,
            gb_radii=args.gb_radii,
            **common_kwargs,
        )

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
