"""Phase 1 of the forward-PREP burn-in campaign: the Section 7 forensic controls, on ALA.

Runs before any burn-in selector is trusted:

  Control A  fixed-start replay -- SAME hot configurations, two batches labelled "early" and "late".
             A generation label alone must not move the work distribution.
  Control B  chronological vs permuted execution -- same starts, same seed mapping, two submission
             orders. Order may change wall time, never physics.

ALA is the negative control: its hot walker equilibrates immediately (t0 = 0, g = 0.029 ns,
N_eff = 3396 measured 2026-08-07), so any drift these controls report is an implementation defect,
not the system.

All output is `record_role=diagnostic`, `accepted_for_production=false`. These shots exist to
falsify the harness and are excluded from every production estimator by construction.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path

import numpy as np

from escort_ais.analysis.forward_prep_burnin import (ShotBatch, batch_rows, hot_blocks,
                                                     order_invariance, pick_frames,
                                                     read_batch_works, run_batch, write_seed_dir)
from escort_ais.common.paths import project_root

ROOT = project_root()
ALA_WALKER = ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"


def sha_head(p: Path, n: int = 1 << 20) -> str:
    with p.open("rb") as f:
        return hashlib.sha256(f.read(n)).hexdigest()[:16]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--campaign", type=Path, required=True)
    ap.add_argument("--walker", type=Path, default=ALA_WALKER)
    ap.add_argument("--n-blocks", type=int, default=10)
    ap.add_argument("--k-shots", type=int, default=32, help="starts per batch")
    ap.add_argument("--t-ais", type=int, default=500, help="steps x 2 fs (500 = 1 ps)")
    ap.add_argument("--hz-n-observations", type=int, default=20)
    ap.add_argument("--s-min", type=float, default=0.7)
    ap.add_argument("--devices", default="0,1,2", help="nvidia-smi indices, one worker each")
    ap.add_argument("--seed", type=int, default=20260808)
    a = ap.parse_args(argv)

    import mdtraj as md
    import pandas as pd

    camp = a.campaign
    work = camp / "phase1_controls"
    work.mkdir(parents=True, exist_ok=True)
    devices = [d.strip() for d in a.devices.split(",") if d.strip()]
    git = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    wh = sha_head(a.walker / "trajectory.dcd")

    with md.formats.DCDTrajectoryFile(str(a.walker / "trajectory.dcd")) as f:
        n_frames = len(f)
    blocks = hot_blocks(n_frames, a.n_blocks)
    late_block = a.n_blocks - 1                    # the block believed stable (§7 Control A)
    lo, hi = blocks[late_block]
    rng = np.random.default_rng(a.seed)
    frames = pick_frames(lo, hi, a.k_shots, rng)
    print(f"[init] walker {a.walker.name}: {n_frames} frames -> {a.n_blocks} blocks of "
          f"{(hi - lo)} ; Control A uses block {late_block} [{lo},{hi})", flush=True)
    print(f"[init] {a.k_shots} fixed starts, frames {frames[:5].tolist()}...{frames[-3:].tolist()}",
          flush=True)

    seed_dir = write_seed_dir(a.walker, frames, work / "fixed_starts")

    # Control A: same starts, two generation LABELS, distinct velocity seeds mapped in advance.
    # Control B: same starts, the SAME two seeds, submitted in the opposite order.
    seed_map = {"early": a.seed + 11, "late": a.seed + 22}
    plan = [
        ShotBatch("A_early", "alanine", "diagnostic", "early", late_block, tuple(frames),
                  seed_map["early"], 0, devices[0 % len(devices)]),
        ShotBatch("A_late", "alanine", "diagnostic", "late", late_block, tuple(frames),
                  seed_map["late"], 1, devices[1 % len(devices)]),
        ShotBatch("B_perm_late", "alanine", "diagnostic", "late", late_block, tuple(frames),
                  seed_map["late"], 2, devices[2 % len(devices)]),
        ShotBatch("B_perm_early", "alanine", "diagnostic", "early", late_block, tuple(frames),
                  seed_map["early"], 3, devices[0 % len(devices)]),
    ]

    rows, status = [], []
    for b in plan:
        out = work / b.batch_id
        t0 = time.time()
        print(f"[run ] {b.batch_id}: seed {b.ais_seed}, label {b.generation_label!r}, "
              f"GPU {b.device}", flush=True)
        res = run_batch(b, seed_dir, out, t_ais=a.t_ais, n_obs=a.hz_n_observations, s_min=a.s_min)
        ok = res["returncode"] == 0
        status.append(dict(batch_id=b.batch_id, ok=ok, wall_s=round(time.time() - t0, 1),
                           **{k: res[k] for k in ("returncode", "command")}))
        if not ok:
            print(f"[FAIL] {b.batch_id} rc={res['returncode']}\n{res['stderr_tail']}", flush=True)
            continue
        df = read_batch_works(out)
        rows += batch_rows(b, df, git_commit=git, walker_hash=wh)
        print(f"[ok  ] {b.batch_id}: {len(df)} shots, <W> = {df['W_reduced'].mean():.3f} kT, "
              f"{time.time() - t0:.0f} s", flush=True)

    if not rows:
        (work / "status.json").write_text(json.dumps(status, indent=2) + "\n")
        print("no batch produced records -- see status.json")
        return 1

    tab = pd.DataFrame(rows)
    tab.to_parquet(work / "ais_shots.parquet", index=False)

    def sel(bid):
        return [r for r in rows if r["batch_id"] == bid]

    verdicts = {}
    if sel("A_early") and sel("A_late"):
        verdicts["control_A_fixed_start_replay"] = order_invariance(sel("A_early"), sel("A_late"))
    if sel("A_late") and sel("B_perm_late"):
        verdicts["control_B_execution_order"] = order_invariance(sel("A_late"), sel("B_perm_late"))

    out = dict(campaign=str(camp), git_commit=git, walker=str(a.walker), walker_hash=wh,
               n_frames=int(n_frames), n_blocks=a.n_blocks, block=[int(lo), int(hi)],
               k_shots=a.k_shots, t_ais=a.t_ais, seed_map=seed_map,
               batches=status, verdicts=verdicts)
    (work / "control_results.json").write_text(json.dumps(out, indent=2) + "\n")

    print("\n=== Section 7 controls ===")
    for name, v in verdicts.items():
        flag = "PASS" if v["consistent_at_95"] else "FAIL -- AIS_ORDER_STATE_LEAK"
        print(f"  {name}")
        print(f"    <W>  {v['mean_W_a']:+.3f} vs {v['mean_W_b']:+.3f} kT   "
              f"ESS {v['ess_a']:.1f} vs {v['ess_b']:.1f}")
        print(f"    dF   {v['dF_a']:+.3f} vs {v['dF_b']:+.3f}   diff {v['dF_diff']:+.4f} "
              f"CI95 [{v['dF_diff_ci95'][0]:+.4f}, {v['dF_diff_ci95'][1]:+.4f}]   {flag}")
    print(f"\nwrote {work}/ais_shots.parquet ({len(rows)} rows), control_results.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
