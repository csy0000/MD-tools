#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from escort_ais.systems.etkdg import ETKDGConfig, generate_conformers, save_etkdg_outputs
from escort_ais.common.paths import data_dir, ensure_dir


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate initial conformers for ACE-ALA-NME.")
    parser.add_argument("--n-conformers", type=int, default=2500)
    parser.add_argument("--seed", type=int, default=20260526)
    parser.add_argument("--max-mmff-iters", type=int, default=100)
    parser.add_argument("--mmff-steps", type=int, default=None, help="Alias for --max-mmff-iters")
    parser.add_argument(
        "--embedding-method",
        type=str,
        default="etkdg_v3",
        choices=["etkdg_v3", "kdg_random"],
    )
    parser.add_argument("--num-threads", type=int, default=0)
    parser.add_argument("--output-dir", type=str, default=None)
    return parser.parse_args(argv)


def resolve_output_dir(args: argparse.Namespace) -> Path:
    if args.output_dir:
        return Path(args.output_dir)

    if args.embedding_method == "etkdg_v3":
        return data_dir() / "etkdg"

    dirname = f"{args.embedding_method}_seed_{args.seed}_n{args.n_conformers}"
    return data_dir() / "conformers" / dirname


def main() -> None:
    args = parse_args()
    mmff_steps = args.mmff_steps if args.mmff_steps is not None else args.max_mmff_iters

    config = ETKDGConfig(
        n_conformers=args.n_conformers,
        seed=args.seed,
        max_mmff_iters=mmff_steps,
        embedding_method=args.embedding_method,
        num_threads=args.num_threads,
    )

    mol, metadata = generate_conformers(config)

    output_dir = ensure_dir(resolve_output_dir(args))
    paths = save_etkdg_outputs(mol, metadata, config, output_dir)

    summary = {
        "embedding_method": args.embedding_method,
        "n_generated": int(len(metadata)),
        "lowest_mmff_energy": float(metadata.sort_values("mmff_energy").iloc[0]["mmff_energy"]),
        "outputs": {k: str(v) for k, v in paths.items()},
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
