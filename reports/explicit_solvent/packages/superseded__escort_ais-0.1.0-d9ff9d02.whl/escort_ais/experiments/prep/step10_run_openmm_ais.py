#!/usr/bin/env python3
"""Run OpenMM Annealed Importance Sampling (scaled → unscaled ensemble).

The lambda schedule is discretised at one step per MD timestep:
    n_lambda_windows = int(switching_time_ps * 1000 / timestep_fs)

Usage — energy-scaling
-----------------------
python -m escort_ais.experiments.prep.step10_run_openmm_ais \\
  --solvent implicit \\
  --strategy energy-scaling \\
  --source-traj data/alanine_dipeptide/md/my_scaled_run/trajectory.dcd \\
  --source-prmtop data/topology/ff19sb_gbn2/system.prmtop \\
  --target-topology data/topology/ff19sb_gbn2_unscaled \\
  --output-dir data/alanine_dipeptide/openmm_ais/my_run/implicit/energy_interpolation/switch_1ps \\
  --switching-time-ps 1 \\
  --timestep-fs 2 \\
  --n-samples 1000

Usage — parameter-scaling
--------------------------
python -m escort_ais.experiments.prep.step10_run_openmm_ais \\
  --solvent implicit \\
  --strategy parameter-scaling \\
  --source-traj data/alanine_dipeptide/md/my_scaled_run/trajectory.dcd \\
  --source-prmtop data/topology/ff19sb_gbn2/system.prmtop \\
  --json-scaling data/topology/ff19sb_gbn2 \\
  --output-dir data/alanine_dipeptide/openmm_ais/my_run/implicit/rest2_scaling_interpolation/switch_1ps \\
  --switching-time-ps 1 \\
  --timestep-fs 2 \\
  --n-samples 1000
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Add repo root to path so escort_ais can be found when run from scripts/

from escort_ais.methods.openmm_ais import (
    OpenMMAISConfig,
    rest2_scaling_available,
    run_openmm_ais,
)
from escort_ais.systems.openmm_system import available_platform_names


def _parse_time_length_ps(value: str) -> float:
    text = value.strip().lower()
    if not text:
        raise argparse.ArgumentTypeError("Time length must not be empty.")

    multiplier = 1000.0
    number_text = text
    if text.endswith("ns"):
        number_text = text[:-2]
        multiplier = 1000.0
    elif text.endswith("ps"):
        number_text = text[:-2]
        multiplier = 1.0

    try:
        parsed = float(number_text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"Invalid time length '{value}'. Use values like 10ns or 10000ps."
        ) from exc

    if parsed <= 0:
        raise argparse.ArgumentTypeError("Time length must be positive.")
    return parsed * multiplier


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run OpenMM AIS (scaled → unscaled ensemble). "
            "n_lambda_windows = int(switching_time_ps * 1000 / timestep_fs)."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--solvent", required=True, choices=["implicit", "explicit"],
        help="Solvent model.",
    )
    parser.add_argument(
        "--strategy", required=True,
        choices=[
            "energy_interpolation", "rest2_scaling_interpolation",
            "energy-scaling", "parameter-scaling",
        ],
        help=(
            "'energy-scaling': U_λ=(1-λ)U_source+λU_target; propagates under U_source. "
            "'parameter-scaling': interpolates REST2 scale factor s(λ); N+1 systems built up-front."
        ),
    )
    # --- Source inputs ---
    parser.add_argument(
        "--source-traj", required=True, type=Path,
        help="DCD trajectory of the scaled (source) ensemble.",
    )
    parser.add_argument(
        "--source-prmtop", default=None, type=Path,
        help=(
            "Base (unscaled) prmtop for the source topology. "
            "Auto-resolved from --json-scaling or --target-topology dir "
            "(system_scale_<N>.prmtop) if not provided."
        ),
    )
    # --- Target / scaling inputs ---
    parser.add_argument(
        "--json-scaling", default=None, type=Path,
        help=(
            "Build-topology output directory containing config.json and rest2/ files. "
            "Provides scale_source and n_solute_atoms. Required for --strategy parameter-scaling; "
            "optional for energy-scaling (enables REST2-scaled propagation)."
        ),
    )
    parser.add_argument(
        "--target-topology", default=None, type=Path,
        help=(
            "Build-topology output directory containing system.prmtop for the physical "
            "(unscaled) target. Required for --strategy energy-scaling."
        ),
    )
    # --- Simulation parameters ---
    parser.add_argument(
        "--output-dir", required=True, type=Path,
        help="Output directory for AIS results.",
    )
    parser.add_argument(
        "--switching-time-ps", type=float, default=1.0,
        help="Total AIS switching time in picoseconds.",
    )
    parser.add_argument(
        "--timestep-fs", type=float, default=2.0,
        help=(
            "MD timestep in fs. Determines n_lambda_windows = "
            "int(switching_time_ps * 1000 / timestep_fs)."
        ),
    )
    parser.add_argument(
        "--temperature-k", type=float, default=300.0,
        help="Bath temperature in Kelvin.",
    )
    parser.add_argument(
        "--n-samples", type=int, default=1000,
        help="Number of independent AIS trajectories.",
    )
    parser.add_argument(
        "--seed", type=int, default=123,
        help="Random seed for initial frame sampling.",
    )
    parser.add_argument(
        "--platform", default=None,
        help="OpenMM platform (CUDA, OpenCL, CPU).  Auto-selected if not given.",
    )
    parser.add_argument(
        "--device-index", default=None,
        help="GPU device index (for CUDA/OpenCL multi-GPU nodes).",
    )
    parser.add_argument(
        "--friction-per-ps", type=float, default=1.0,
        help="Langevin friction coefficient in ps⁻¹.",
    )
    parser.add_argument(
        "--hot-time-length", type=_parse_time_length_ps, default=None,
        help=(
            "Restrict starting frames to the first part of the source trajectory. "
            "Accepts 10ns, 50ns, or 10000ps. Requires --traj-interval-ps."
        ),
    )
    parser.add_argument(
        "--traj-interval-ps", type=float, default=None,
        help=(
            "Trajectory frame write interval in ps (needed when --hot-time-length is set)."
        ),
    )
    parser.add_argument(
        "--debug", action="store_true",
        help="Debug mode: 5 samples, n_lambda_windows=5.",
    )
    parser.add_argument(
        "--overwrite", action="store_true",
        help="Allow replacing an existing output directory.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print resolved inputs/outputs and exit without running AIS.",
    )
    return parser.parse_args()


def _pick_platform(preferred: str | None) -> str:
    available = set(available_platform_names())
    if preferred:
        if preferred not in available:
            raise ValueError(
                f"Requested platform '{preferred}' not available. Available: {sorted(available)}"
            )
        return preferred
    for candidate in ["CUDA", "OpenCL", "CPU", "Reference"]:
        if candidate in available:
            return candidate
    raise RuntimeError("No OpenMM platform is available.")


def main() -> None:
    args = parse_args()

    output_dir = Path(args.output_dir)

    # Normalize user-facing aliases to canonical internal strategy names
    _STRATEGY_ALIASES = {
        "parameter-scaling": "rest2_scaling_interpolation",
        "energy-scaling": "energy_interpolation",
    }
    canonical_strategy = _STRATEGY_ALIASES.get(args.strategy, args.strategy)

    # --- Compute n_lambda_windows for display ---
    n_lambda_windows = (
        5 if args.debug
        else max(1, int(args.switching_time_ps * 1000 / args.timestep_fs))
    )

    if args.dry_run:
        print("=== DRY RUN ===")
        print(f"solvent            : {args.solvent}")
        print(f"strategy           : {canonical_strategy}")
        print(f"source_traj        : {Path(args.source_traj).resolve()}")
        print(f"source_prmtop      : {Path(args.source_prmtop).resolve() if args.source_prmtop else '(auto-resolved from topology dir)'}")
        print(f"json_scaling       : {Path(args.json_scaling).resolve() if args.json_scaling else '(none)'}")
        print(f"target_topology    : {Path(args.target_topology).resolve() if args.target_topology else '(none)'}")
        print(f"output_dir         : {output_dir.resolve()}")
        print(f"switching_time_ps  : {args.switching_time_ps}")
        print(f"timestep_fs        : {args.timestep_fs}")
        print(f"n_lambda_windows   : {n_lambda_windows}  (= T_ais/dt)")
        print(f"temperature_k      : {args.temperature_k}")
        print(f"n_samples          : {5 if args.debug else args.n_samples}{' (debug)' if args.debug else ''}")
        print(f"seed               : {args.seed}")
        print(f"friction_per_ps    : {args.friction_per_ps}")
        print(
            f"hot_time_length_ps : {args.hot_time_length:g}"
            if args.hot_time_length is not None else
            "hot_time_length_ps : full trajectory"
        )
        print(f"traj_interval_ps   : {args.traj_interval_ps if args.traj_interval_ps else '(not set)'}")
        print(f"debug              : {args.debug}")
        print(f"overwrite          : {args.overwrite}")
        return

    # --- Post-parse validation ---
    if args.source_prmtop is None and args.json_scaling is None and args.target_topology is None:
        print(
            "error: --source-prmtop is required when neither --json-scaling nor "
            "--target-topology is given (cannot auto-resolve prmtop).",
            file=sys.stderr,
        )
        sys.exit(2)

    if canonical_strategy == "energy_interpolation" and args.target_topology is None:
        print(
            "error: --target-topology is required for --strategy energy-scaling / "
            "energy_interpolation. Pass a build-topology output directory containing "
            "system.prmtop.",
            file=sys.stderr,
        )
        sys.exit(2)

    if canonical_strategy == "rest2_scaling_interpolation":
        if args.json_scaling is None:
            print(
                "error: --json-scaling is required for --strategy parameter-scaling / "
                "rest2_scaling_interpolation. Pass a build-topology output directory "
                "containing rest2/ files with a scale factor < 1.0.",
                file=sys.stderr,
            )
            sys.exit(2)
        if not rest2_scaling_available(Path(args.json_scaling)):
            print(
                f"error: --strategy parameter-scaling requires a REST2 scale factor < 1.0 "
                f"in {args.json_scaling}/rest2/. "
                "No such scale factor found — use --strategy energy-scaling instead.",
                file=sys.stderr,
            )
            sys.exit(2)

    if args.hot_time_length is not None and args.traj_interval_ps is None:
        print(
            "error: --hot-time-length requires --traj-interval-ps.",
            file=sys.stderr,
        )
        sys.exit(2)

    platform = _pick_platform(args.platform)

    config = OpenMMAISConfig(
        solvent=args.solvent,
        strategy=canonical_strategy,
        source_traj=args.source_traj,
        source_prmtop=args.source_prmtop,
        output_dir=output_dir,
        n_samples=args.n_samples,
        switching_time_ps=args.switching_time_ps,
        timestep_fs=args.timestep_fs,
        temperature_k=args.temperature_k,
        seed=args.seed,
        json_scaling=args.json_scaling,
        target_topology=args.target_topology,
        hot_time_length_ps=args.hot_time_length,
        traj_interval_ps=args.traj_interval_ps,
        platform=platform,
        device_index=args.device_index,
        friction_per_ps=args.friction_per_ps,
        overwrite=args.overwrite,
        debug=args.debug,
    )

    summary = run_openmm_ais(config)

    print("\n=== OpenMM AIS Run Complete ===")
    print(f"output_dir     : {output_dir}")
    print(f"n_lambda_windows: {n_lambda_windows}")
    print(f"n_success      : {summary['n_success']}")
    print(f"n_failed       : {summary['n_failed']}")
    if summary["work_reduced_mean"] is not None:
        print(f"work_reduced   : mean={summary['work_reduced_mean']:.4f}  "
              f"std={summary['work_reduced_std']:.4f}")
    if summary["ess"] is not None:
        print(f"ESS            : {summary['ess']:.1f} / {summary['n_success']} "
              f"({100 * summary['ess_normalized']:.1f}%)")
    if summary["jarzynski_delta_f_reduced"] is not None:
        print(f"Jarzynski ΔF   : {summary['jarzynski_delta_f_reduced']:.4f} (reduced units)")
    print(f"wall_time_s    : {summary['wall_time_s']:.1f}")


if __name__ == "__main__":
    main()
