#!/usr/bin/env python3
"""Build or reload cached Amber prmtop/inpcrd for a protein and/or ligand system.

Examples
--------
# ACE-ALA-NME with Sage ligand replaced by GAFF, explicit OPC + 0.15 M NaCl:
python -m escort_ais.experiments.prep.step00_build_topology \\
    --protein-sequence "ACE ALA NME" \\
    --forcefield ff19sb \\
    --solvent opc \\
    --output-dir data/topology/ala_opc

# Small molecule only (Sage + explicit OPC):
python -m escort_ais.experiments.prep.step00_build_topology \\
    --ligand-smiles "CCO" \\
    --forcefield sage \\
    --solvent opc \\
    --output-dir data/topology/ethanol_opc

# Protein + Sage ligand, implicit GBn2:
python -m escort_ais.experiments.prep.step00_build_topology \\
    --protein-pdb my_protein.pdb \\
    --ligand-sdf my_ligand.sdf \\
    --forcefield ff19sb+sage \\
    --solvent gbn2 \\
    --output-dir data/topology/complex_gbn2
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from escort_ais.common.paths import data_dir, ensure_dir
from escort_ais.systems.topology_prep import (
    DEFAULT_FORCEFIELD,
    DEFAULT_SOLVENT,
    VALID_FORCEFIELDS,
    VALID_SOLVENTS,
    build_topology,
    build_rest2_systems,
)
from escort_ais.systems.openmm_system import DEFAULT_SALT_CONCENTRATION_MOLAR


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build Amber prmtop/inpcrd for a protein and/or ligand system.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # -- Molecule sources --
    mol_group = parser.add_argument_group("molecule sources (at least one required)")
    mol_group.add_argument(
        "--protein-pdb", type=str, default=None,
        metavar="PATH",
        help="Protein PDB file (parameterised with ff19SB).",
    )
    mol_group.add_argument(
        "--protein-sequence", type=str, default=None,
        metavar="'RES1 RES2 ...'",
        help="Amber residue sequence string, e.g. 'ACE ALA NME'. "
             "tleap generates the 3-D structure.",
    )
    mol_group.add_argument(
        "--ligand-sdf", type=str, default=None,
        metavar="PATH",
        help="Ligand SDF file with 3-D coordinates.",
    )
    mol_group.add_argument(
        "--ligand-smiles", type=str, default=None,
        metavar="SMILES",
        help="Ligand SMILES string. A conformer is generated automatically.",
    )

    # -- Force field / solvent --
    parser.add_argument(
        "--forcefield", type=str, default=DEFAULT_FORCEFIELD,
        choices=sorted(VALID_FORCEFIELDS),
        help="Force-field combination.",
    )
    parser.add_argument(
        "--solvent", type=str, default=DEFAULT_SOLVENT,
        choices=sorted(VALID_SOLVENTS),
        help="'opc' = explicit OPC box + NaCl; 'gbn2' = implicit GBn2, no box.",
    )
    parser.add_argument(
        "--box-padding-angstrom", type=float, default=12.0,
        help="Solvent-box padding (Å). Ignored for --solvent gbn2.",
    )
    parser.add_argument(
        "--salt-concentration-molar", type=float,
        default=DEFAULT_SALT_CONCENTRATION_MOLAR,
        help="NaCl ionic strength (M). Ignored for --solvent gbn2.",
    )

    # -- Output --
    parser.add_argument(
        "--output-dir", type=str, default=None,
        help="Directory for Amber files and config.json. "
             "Defaults to data/topology/<forcefield>_<solvent>/.",
    )

    # -- REST2 --
    rest2_group = parser.add_argument_group("REST2 scaling (optional)")
    rest2_group.add_argument(
        "--rest2-mode", type=str, default="none",
        choices=["none", "single", "remd"],
        help="none = base topology only; single = one scaled system; "
             "remd = N-replica temperature ladder.",
    )
    rest2_group.add_argument(
        "--rest2-scale-factor", type=float, default=None,
        metavar="FLOAT",
        help="Raw REST2 scale factor for --rest2-mode single (0 < s <= 1).",
    )
    rest2_group.add_argument(
        "--n-replicas", type=int, default=None,
        metavar="N",
        help="Number of replicas (>= 2) for --rest2-mode remd.",
    )
    rest2_group.add_argument(
        "--base-temperature-k", type=float, default=300.0,
        help="Physical bath temperature (K) for REMD ladder.",
    )
    rest2_group.add_argument(
        "--effective-temperature-max-k", type=float, default=450.0,
        help="Effective temperature (K) of the hottest replica for REMD ladder.",
    )

    return parser.parse_args()


def _default_output_dir(args: argparse.Namespace) -> Path:
    label = f"{args.forcefield}_{args.solvent}"
    return data_dir() / "topology" / label


def _validate(args: argparse.Namespace) -> None:
    has_protein_input = args.protein_pdb is not None or args.protein_sequence is not None
    has_ligand_input = args.ligand_sdf is not None or args.ligand_smiles is not None

    if not has_protein_input and not has_ligand_input:
        print(
            "error: at least one of --protein-pdb, --protein-sequence, "
            "--ligand-sdf, or --ligand-smiles is required.",
            file=sys.stderr,
        )
        sys.exit(1)

    ff = args.forcefield.lower()
    if "ff19sb" not in ff and has_protein_input:
        print(
            f"warning: protein input provided but forcefield '{ff}' has no protein component; "
            "protein input will be ignored.",
            file=sys.stderr,
        )
    if "sage" not in ff and "gaff" not in ff and has_ligand_input:
        print(
            f"warning: ligand input provided but forcefield '{ff}' has no ligand component; "
            "ligand input will be ignored.",
            file=sys.stderr,
        )

    if args.solvent == "gbn2":
        if args.box_padding_angstrom != 12.0:
            print(
                "warning: --box-padding-angstrom has no effect with --solvent gbn2.",
                file=sys.stderr,
            )
        if abs(args.salt_concentration_molar - DEFAULT_SALT_CONCENTRATION_MOLAR) > 1e-9:
            print(
                "warning: --salt-concentration-molar has no effect with --solvent gbn2.",
                file=sys.stderr,
            )

    if args.rest2_mode == "single" and args.rest2_scale_factor is None:
        print(
            "error: --rest2-scale-factor is required when --rest2-mode single.",
            file=sys.stderr,
        )
        sys.exit(1)
    if args.rest2_mode == "remd" and args.n_replicas is None:
        print(
            "error: --n-replicas is required when --rest2-mode remd.",
            file=sys.stderr,
        )
        sys.exit(1)
    if args.rest2_mode == "remd" and args.n_replicas is not None and args.n_replicas < 2:
        print(
            f"error: --n-replicas must be >= 2, got {args.n_replicas}.",
            file=sys.stderr,
        )
        sys.exit(1)


def main() -> None:
    args = parse_args()
    _validate(args)

    output_dir = ensure_dir(
        Path(args.output_dir) if args.output_dir else _default_output_dir(args)
    )

    result = build_topology(
        output_dir=output_dir,
        protein_pdb=Path(args.protein_pdb) if args.protein_pdb else None,
        protein_sequence=args.protein_sequence.split() if args.protein_sequence else None,
        ligand_sdf=Path(args.ligand_sdf) if args.ligand_sdf else None,
        ligand_smiles=args.ligand_smiles,
        forcefield=args.forcefield,
        solvent=args.solvent,
        box_padding_angstrom=args.box_padding_angstrom,
        salt_concentration_molar=args.salt_concentration_molar,
    )

    summary = {
        "prmtop": str(result["prmtop"]),
        "inpcrd": str(result["inpcrd"]),
        "topology_pdb": str(result["topology_pdb"]),
        "config_json": str(result["config_json"]),
        "n_solute_atoms": result["n_solute_atoms"],
    }

    if args.rest2_mode != "none":
        rest2_result = build_rest2_systems(
            output_dir,
            mode=args.rest2_mode,
            scale_factor=args.rest2_scale_factor,
            n_replicas=args.n_replicas,
            base_temperature_k=args.base_temperature_k,
            effective_temperature_max_k=args.effective_temperature_max_k,
        )
        summary["rest2"] = {
            "mode": rest2_result["mode"],
            "system_xml_paths": [str(p) for p in rest2_result["system_xml_paths"]],
            "scale_factors": rest2_result["scale_factors"],
            "effective_temperatures_k": rest2_result["effective_temperatures_k"],
            "ladder_json": str(rest2_result["ladder_json"]) if rest2_result["ladder_json"] else None,
        }

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
