#!/usr/bin/env python3
"""demo_bais_tw10k_burn_toy.py — BAIS with a uniform walker length T_walker=10k and a hot burn-in of 20k.

Uses ONE per-generation length for hot AND cold (T_walker = 10,000 steps, so per generation the budget is
~(N_cold+1) T_walker), plus a single hot BURN-IN of 20,000 steps up front to discard the single-draw
initialization transient (the hot walker starts in one basin; a short run stays anchored there). Runs to a total
budget of 1.2M force-evaluations and records the running endpoint-BAR populations at every generation, so the
per-generation free energies can be compared with/without the burn-in.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_tw10k_burn_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import bais_protocol_run

ROOT = project_root()
OUT = ROOT / "results/toy"
ANALYTIC = np.array([0.25, 0.42, 0.33])          # [B, A1, A2]
B_TOTAL = 1_200_000
T_WALKER = 10_000
BURN = 20_000


def run(fast=False, nseed=4):
    seeds = list(range(2 if fast else nseed))
    B = 400_000 if fast else B_TOTAL
    # three reservoir treatments at T_walker=10k: all frames (no burn), all frames + burn-in, and LEQ-only.
    configs = {"all frames":  dict(burn=0),
               "burn=20k":    dict(burn=BURN),
               "LEQ-only":    dict(burn=0, leq_filter=True)}
    res = {}
    for label, cfg in configs.items():
        rows = []
        for s in seeds:
            r = bais_protocol_run(s, B, hot_steps=T_WALKER, cold_chunk=T_WALKER, pergen=True, n_fwd=100, **cfg)
            rows.append(r)
            print(f"  [{label:10}] seed {s}: n_gen={r['n_iter']:>3}  pi={np.round(r['pi'],3)}  "
                  f"pop-TV={r['pop_tv']:.3f}  ITS-err={r['its_relerr']:.3f}", file=sys.stderr)
        piB = np.array([r["pi"][0] for r in rows]); tv = np.array([r["pop_tv"] for r in rows])
        kept = [r["leq_kept"] for r in rows if r.get("leq_kept") is not None]
        res[label] = dict(rows=rows, median_piB=float(np.nanmedian(piB)), std_piB=float(np.nanstd(piB)),
                          median_tv=float(np.nanmedian(tv)),
                          median_its=float(np.nanmedian([r["its_relerr"] for r in rows])),
                          median_ngen=int(np.median([r["n_iter"] for r in rows])),
                          leq_kept_frac=float(np.median(kept)) if kept else None)
        keptxt = f", LEQ-kept={res[label]['leq_kept_frac']:.3f}" if res[label]["leq_kept_frac"] is not None else ""
        print(f"  => [{label}] median pi_B={res[label]['median_piB']:.3f} (std {res[label]['std_piB']:.3f}), "
              f"pop-TV={res[label]['median_tv']:.3f}, ITS-err={res[label]['median_its']:.3f}, "
              f"n_gen~{res[label]['median_ngen']}{keptxt}\n", file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "bais_tw10k_burn_toy.json").write_text(json.dumps(
        {"B_total": B, "T_walker": T_WALKER, "burn": BURN, "seeds": seeds, "analytic": ANALYTIC.tolist(),
         "summary": {k: {kk: vv for kk, vv in v.items() if kk != "rows"} for k, v in res.items()}}, indent=1))
    make_figure(res, seeds, B)
    return res


def make_figure(res, seeds, B):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 3, figsize=(17.5, 5.0))
    cols = plt.get_cmap("viridis")(np.linspace(0.15, 0.85, len(seeds)))

    def pergen(a, label, title):
        for r, c in zip(res[label]["rows"], cols):
            pg = np.array(r["pergen_pi"]); bg = np.array(r["pergen_budget"]) / 1e6
            if pg.size:
                a.plot(bg, pg[:, 0], "-o", color=c, ms=3, lw=1.1)
        a.axhline(0.25, ls="--", color="k", lw=1.2)
        a.set_xlabel("cumulative budget (M force-evals)"); a.set_ylabel("running $\\pi_B$")
        a.set_ylim(0, 0.6); a.set_title(title); a.grid(alpha=0.3)

    # (1) per-generation pi_B: LEQ-only vs all-frames (both no burn-in) -> does LEQ filtering change it?
    pergen(ax[0], "LEQ-only", "(1) LEQ-only reservoir: per-generation $\\pi_B$")
    pergen(ax[1], "all frames", "(2) all-frames reservoir (no burn): per-generation $\\pi_B$")

    # (3) final populations at 1.2M for all three treatments, vs analytic
    x = np.arange(3); order = ["all frames", "burn=20k", "LEQ-only"]; w = 0.26
    fills = ["#4c72b0", "#dd8452", "#55a868"]
    for i, lbl in enumerate(order):
        rows = res[lbl]["rows"]
        med = [np.nanmedian([r["pi"][b] for r in rows]) for b in range(3)]
        lo = [np.nanmin([r["pi"][b] for r in rows]) for b in range(3)]
        hi = [np.nanmax([r["pi"][b] for r in rows]) for b in range(3)]
        ax[2].bar(x + (i - 1) * w, med, w, yerr=[np.array(med) - lo, np.array(hi) - med], capsize=2.5,
                  color=fills[i], edgecolor="k", alpha=0.9,
                  label=f"{lbl} (TV={res[lbl]['median_tv']:.3f})")
    for b, an in enumerate(ANALYTIC):
        ax[2].plot([b - 0.45, b + 0.45], [an, an], "k--", lw=1.4)
    ax[2].set_xticks(x); ax[2].set_xticklabels(["B", "A1", "A2"]); ax[2].set_ylabel("population $\\pi$")
    ax[2].set_title("(3) final $\\pi$ at 1.2M (dashed = analytic)")
    ax[2].legend(fontsize=7.5); ax[2].grid(axis="y", alpha=0.3)

    fig.suptitle(f"BAIS, uniform $T_{{walker}}$=10k, total budget {B/1e6:.1f}M — reservoir treatments: all frames, "
                 f"+20k hot burn-in, and LEQ-only (reverse from residence segments $>$ 10\\,$t_2$; median of {len(seeds)} seeds).",
                 fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / "fig_bais_tw10k_burn_toy.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_tw10k_burn_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
