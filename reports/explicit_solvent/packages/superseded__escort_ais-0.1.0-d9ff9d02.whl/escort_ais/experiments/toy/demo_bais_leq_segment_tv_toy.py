#!/usr/bin/env python3
"""demo_bais_leq_segment_tv_toy.py — do LONGER residence segments sit closer to within-basin local equilibrium (LEQ)?

Evidence for the T_segment > 10 t2 LEQ rule. A residence SEGMENT is one uninterrupted visit of a cold walker to a
basin (from entry to escape). For each segment we measure how far its LOCAL configurational distribution is from the
basin's converged (equilibrium) local shape, by total-variation distance:

  * basin A (the merged {A1,A2} kinetic basin, internal slow mode t2 = t_A1<->A2): TV is on the A1/A2 sub-well split,
    p_seg(A1,A2) vs the equilibrium split. A short visit is trapped in ONE sub-well (TV ~ 0.44); only visits long
    compared with t2 sample both (TV -> 0). This is the case the LEQ rule is FOR.
  * basin B (a single well, no slow internal mode): TV is on the within-well theta histogram vs its equilibrium.
    Control: a single well relaxes fast, so even short visits have small TV -- no long-segment requirement.

Plotting T_segment vs TV (with the 10 t2 cutoff) shows the LEQ rule is well-founded: below 10 t2 the local shape is
biased (high TV), above it the shape is converged (low TV). This motivates the LEQ-only reconstruction experiment
(demo_bais_leq_only_toy.py).

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_leq_segment_tv_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.bais import estimate_msm_free_pi

ROOT = project_root()
OUT = ROOT / "results/toy"


def _segments(mask):
    """Yield (start, stop) index ranges of each maximal run of True in a boolean mask."""
    m = np.asarray(mask, bool); segs = []
    i = 0; n = len(m)
    while i < n:
        if m[i]:
            j = i
            while j < n and m[j]:
                j += 1
            segs.append((i, j)); i = j
        else:
            i += 1
    return segs


def _tv(p, q):
    p = np.asarray(p, float); q = np.asarray(q, float)
    return 0.5 * float(np.abs(p - q).sum())


def run(fast=False, seed=0):
    t = Toy1D(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"])
    kin = t.smoluchowski_kinetics(); t2_A = float(kin["t_A1A2"])              # A1<->A2 internal timescale
    n_walk = 8 if fast else 16                                                # pool many walkers -> dense segments
    steps = 800_000 if fast else 1_500_000
    thbins = np.linspace(-np.pi, np.pi, 41)

    # many long cold trajectories (each entering/leaving A) -> residence segments of all lengths (Kramers)
    x0 = np.full(n_walk, np.radians(ana["well_centers_deg"][1]))
    traj = wrap(t.langevin(x0, steps, 1.0, rng))                             # (steps, n_walk)
    dall = t.basin_of(traj, bnd).astype(int)                                 # 0=B, 1=A1, 2=A2

    # reference (equilibrium) local shapes from ALL pooled frames
    dflat = dall.ravel(); xflat = traj.ravel(); inA_flat = np.isin(dflat, [1, 2])
    ref_A_split = np.array([np.mean(dflat[inA_flat] == 1), np.mean(dflat[inA_flat] == 2)])
    ref_B_hist = np.histogram(xflat[dflat == 0], bins=thbins, density=True)[0]
    ref_B_hist = ref_B_hist / (ref_B_hist.sum() + 1e-12)

    rows = []                                                                 # (basin, T_segment, TV)
    for w in range(n_walk):
        d = dall[:, w]; xw = traj[:, w]
        for (i, j) in _segments(np.isin(d, [1, 2])):                         # basin A visits
            if j - i < 5:
                continue
            sub = d[i:j]
            p = np.array([np.mean(sub == 1), np.mean(sub == 2)])            # this visit's A1/A2 split
            rows.append(("A", j - i, _tv(p, ref_A_split)))
        for (i, j) in _segments(d == 0):                                     # basin B visits
            if j - i < 5:
                continue
            h = np.histogram(xw[i:j], bins=thbins, density=True)[0]; h = h / (h.sum() + 1e-12)
            rows.append(("B", j - i, _tv(h, ref_B_hist)))

    OUT.mkdir(parents=True, exist_ok=True)
    summ = _binned_summary(rows, t2_A)
    (OUT / "bais_leq_segment_tv_toy.json").write_text(json.dumps(
        {"seed": seed, "n_walk": n_walk, "steps": steps, "t2_A": t2_A, "ref_A_split": ref_A_split.tolist(),
         "n_segments_A": int(sum(r[0] == "A" for r in rows)), "n_segments_B": int(sum(r[0] == "B" for r in rows)),
         "binned": summ}, indent=1))
    for line in _report_lines(rows, t2_A):
        print(line, file=sys.stderr)
    make_figure(rows, t2_A, ref_A_split)
    return rows


def _count(dtrajs, nb, lag):
    C = np.zeros((nb, nb))
    for dt in dtrajs:
        dt = np.asarray(dt, int)
        if len(dt) > lag:
            np.add.at(C, (dt[:-lag], dt[lag:]), 1.0)
    return C


def _binned_summary(rows, t2_A):
    """Median TV for A-segments in log-length bins, and below/above the 10 t2 cutoff."""
    A = np.array([(T, tv) for (b, T, tv) in rows if b == "A"], float)
    if len(A) == 0:
        return {}
    cut = 10 * t2_A
    below = A[A[:, 0] < cut]; above = A[A[:, 0] >= cut]
    return {"cutoff_10t2": float(cut),
            "median_TV_below_cut": float(np.median(below[:, 1])) if len(below) else None,
            "median_TV_above_cut": float(np.median(above[:, 1])) if len(above) else None,
            "n_below": int(len(below)), "n_above": int(len(above))}


def _report_lines(rows, t2_A):
    A = np.array([(T, tv) for (b, T, tv) in rows if b == "A"], float)
    B = np.array([(T, tv) for (b, T, tv) in rows if b == "B"], float)
    out = [f"  basin A: {len(A)} segments, t2_A={t2_A:.0f}, 10*t2_A={10*t2_A:.0f}"]
    if len(A):
        cut = 10 * t2_A
        below = A[A[:, 0] < cut, 1]; above = A[A[:, 0] >= cut, 1]
        out.append(f"    A: median TV below 10t2 = {np.median(below):.3f} (n={len(below)}); "
                   f"above = {np.median(above):.3f} (n={len(above)})" if len(above) else
                   f"    A: median TV below 10t2 = {np.median(below):.3f} (n={len(below)}); NONE above 10t2")
    out.append(f"  basin B (single well, control): {len(B)} segments; median TV={np.median(B[:,1]):.3f}"
               if len(B) else "  basin B: no segments")
    return out


def make_figure(rows, t2_A, ref_A_split):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.stats import spearmanr
    A = np.array([(T, tv) for (b, T, tv) in rows if b == "A"], float)
    B = np.array([(T, tv) for (b, T, tv) in rows if b == "B"], float)
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))

    def _rho(D):                                          # Spearman rank correlation of T_seg vs TV
        if len(D) < 3:
            return float("nan")
        return float(spearmanr(D[:, 0], D[:, 1]).correlation)

    # (A) basin A: T_segment vs TV(A1/A2 split), with the 10 t2 LEQ cutoff + a binned-median trend
    ax[0].scatter(A[:, 0], A[:, 1], s=9, alpha=0.28, color="#3a8f3a", label="A residence segments")
    if len(A):
        edges = np.logspace(np.log10(max(A[:, 0].min(), 5)), np.log10(A[:, 0].max() + 1), 14)
        idx = np.digitize(A[:, 0], edges)
        bx, by = [], []
        for k in range(1, len(edges)):
            sel = idx == k
            if sel.sum() >= 4:
                bx.append(np.median(A[sel, 0])); by.append(np.median(A[sel, 1]))
        ax[0].plot(bx, by, "-o", color="#14521f", lw=2, ms=4, label="binned median")
    ax[0].axvline(10 * t2_A, ls="--", color="#b03030", lw=1.6, label=f"$10\\,t_2^A$ = {10*t2_A:.0f}")
    ax[0].axvline(t2_A, ls=":", color="0.5", lw=1.2, label=f"$t_2^A$ = {t2_A:.0f}")
    ax[0].set_xscale("log"); ax[0].set_xlabel("segment residence $T_{\\mathrm{seg}}^A$ (frames)")
    ax[0].set_ylabel("$TV^A$ ($A_1/A_2$ split to equilibrium)")
    ax[0].set_title("(A) basin $A$ (slow $A_1\\!\\leftrightarrow\\!A_2$): long visits $\\to$ LEQ")
    ax[0].text(0.03, 0.05, f"Spearman $\\rho={_rho(A):+.2f}$", transform=ax[0].transAxes, fontsize=10,
               fontweight="bold", va="bottom", ha="left")
    ax[0].legend(fontsize=8); ax[0].grid(alpha=0.3, which="both")

    # (B) basin B control: single well relaxes fast -> TV small even for short segments
    ax[1].scatter(B[:, 0], B[:, 1], s=9, alpha=0.28, color="#7a4fb0", label="B residence segments")
    ax[1].set_xscale("log"); ax[1].set_xlabel("segment residence $T_{\\mathrm{seg}}^B$ (frames)")
    ax[1].set_ylabel("$TV^B$ (within-well $\\theta$ hist to equilibrium)")
    ax[1].set_title("(B) basin $B$ (single well): fast intra-well relaxation (control)")
    ax[1].text(0.03, 0.05, f"Spearman $\\rho={_rho(B):+.2f}$", transform=ax[1].transAxes, fontsize=10,
               fontweight="bold", va="bottom", ha="left")
    ax[1].legend(fontsize=8); ax[1].grid(alpha=0.3, which="both")

    fig.suptitle("Correlation between segment residence $T_{\\mathrm{seg}}^m$ and within-basin TV$^m$: longer visits "
                 "are closer to local equilibrium (LEQ). Each point = one uninterrupted basin visit.",
                 fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(OUT / "fig_bais_leq_segment_tv_toy.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_leq_segment_tv_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
