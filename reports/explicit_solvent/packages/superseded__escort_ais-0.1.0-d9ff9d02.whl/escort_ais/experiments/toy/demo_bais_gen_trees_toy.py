#!/usr/bin/env python3
"""demo_bais_gen_trees_toy.py — the hierarchical KCC+TICA state tree computed at EACH BAIS generation.

One row per generation. Per generation the figure shows, and the row title reports the compute budget
(hot MD / AIS / cold MD force-evaluations):
  (col 1) KCC isolated basins on the cold density, coloured by final resolved state;
  (col 2) TICA t2(lag) inside each isolated basin against ½T_res (T_res = largest consecutive residence);
  (col 3) AFTER a basin splits, the histogram of the consecutive RESIDENCE times within each sub-basin
          (one continuous run that stays in sub-k), with the LEQ cutoff 2·t2_sub-k marked. Only segments
          longer than 2·t2_sub-k are locally equilibrated; reverse-AIS starts drawn from the shorter,
          non-equilibrated segments (shaded) are EXCLUDED so they do not bias the reverse work;
  (col 4) the resolved state tree (parent→child edges = population proportions; dashed sibling edges = ITS).

Residence is computed BEFORE the split at the KCC level (each isolated basin's walkers stay put, so their
runs are the full cold-MD segments, which feed TICA); the sub-basin residence histogram is computed AFTER
the split and gates which segments are LEQ-valid.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_gen_trees_toy [--fast]
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.kcc_split import level1_kcc, residence_segments
from escort_ais.experiments.toy.demo_bais_tica_tree_toy import COL, _lags, analyze, _leaf_name

ROOT = project_root()
OUT = ROOT / "results/toy"


def _feats1(angles):
    a = wrap(np.asarray(angles, float))
    return np.column_stack([np.cos(a), np.sin(a)])


def run(fast=False, gens=4, seed=1):
    t = Toy1D(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"])
    wells = np.radians(ana["well_centers_deg"])                      # [-120(B), 60(A1), 120(A2)]
    pops = np.array(ana["pops"])
    kin = t.smoluchowski_kinetics(); t_AB, t_A1A2 = float(kin["t_AB"]), float(kin["t_A1A2"])
    truepop = {"B": pops[0], "A1": pops[1], "A2": pops[2], "A": pops[1] + pops[2]}
    s_hot = t.s_hot

    n_hot, hot_steps = 12, 1000
    n_shot, m_ais = 50, 5
    n_per_well = 14 if fast else 20
    cold_chunk = 900                                                 # T_cold^m: cold-MD steps per walker per generation
    seeds0 = np.repeat(wells, n_per_well)                            # walkers per true well: B, A1, A2
    cold_pos = seeds0.copy()
    budget = dict(hot=0, ais=0, cold=0)
    hot = t.sample_boltzmann(s_hot, n_hot, rng)
    gen_rows = []

    for g in range(gens):
        hot = t.langevin(hot, hot_steps, s_hot, rng)[-1]; budget["hot"] += n_hot * hot_steps
        xh = hot[rng.integers(0, len(hot), n_shot)]
        land, lw = t.ais_switch(xh, s_hot, 1.0, m_steps=m_ais, freq=1, rng=rng); budget["ais"] += n_shot * m_ais
        cold = t.langevin(cold_pos, cold_chunk, 1.0, rng); cold_pos = wrap(cold[-1]); budget["cold"] += len(seeds0) * cold_chunk
        t.ais_switch(cold_pos, 1.0, s_hot, m_steps=m_ais, freq=1, rng=rng); budget["ais"] += n_shot * m_ais  # reverse

        # analyse THIS generation's fresh cold chunk: residence in an isolated basin = the chunk length T_cold^m
        wtraj = [wrap(cold[:, k]) for k in range(len(seeds0))]
        # a walker that made the rare A<->B crossing is really two residence segments; drop it so KCC sees clean
        # isolated basins (the crossing is anyway pruned by min_count, but this removes seed-to-seed noise)
        wtraj = [w for w in wtraj if not ((0 in (labs := set(t.basin_of(w, bnd).astype(int).tolist())))
                                          and ({1, 2} & labs))]
        wlens = [len(w) for w in wtraj]
        feats = np.vstack([_feats1(w) for w in wtraj]); pooled = np.concatenate(wtraj)
        lags = _lags(cold_chunk)
        kcc = level1_kcc(feats, wlens, lag=max(6, cold_chunk // 60), k=20, min_count=5, seed=seed)
        fc = kcc["frame_cluster"]
        basins = []
        for c in range(kcc["n_clusters"]):
            mask = fc == c
            if mask.sum() < 40:
                continue
            node = analyze(feats, wlens, mask, lags, seed)
            maj = np.bincount(t.basin_of(pooled[mask], bnd).astype(int), minlength=3).argmax()
            node["label"] = {0: "B", 1: "A", 2: "A"}[int(maj)]
            basins.append(node)
        basins.sort(key=lambda b: (b["label"] != "A", -b["n"]))
        gen_rows.append(dict(g=g, budget=dict(budget), basins=basins, pooled=pooled, wlens=wlens,
                             lags=list(lags), percold=int(cold_chunk * (g + 1))))
        print(f"  gen {g}: budget hot={budget['hot']} ais={budget['ais']} cold={budget['cold']} | "
              + " ".join(f"{b['label']}(Tres={b['Tres']},t2={b['dec']['t2']:.0f},split={b['dec']['split']})"
                         for b in basins), file=sys.stderr)

    OUT.mkdir(parents=True, exist_ok=True)
    make_figure(t, bnd, gen_rows, lags, t_AB, t_A1A2, truepop)
    return gen_rows


def make_figure(t, bnd, gen_rows, lags, t_AB, t_A1A2, truepop):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    G = len(gen_rows)
    bins = np.linspace(-180, 180, 73)
    fig, ax = plt.subplots(G, 4, figsize=(20.0, 3.7 * G), squeeze=False,
                           gridspec_kw=dict(width_ratios=[1.1, 1.0, 1.15, 1.3]))

    for i, r in enumerate(gen_rows):
        basins = r["basins"]; pooled = r["pooled"]; wlens = r["wlens"]; deg = np.degrees(pooled)
        lags = np.asarray(r["lags"], float)
        # leaf label per frame (for the density colours)
        leaf_of = np.array(["?"] * len(pooled), dtype=object)
        for b in basins:
            for nd in (b["children"] or [b]):
                leaf_of[nd["mask"]] = _leaf_name(t, nd, pooled, bnd)

        # (col 0) KCC density coloured by final state
        a0 = ax[i][0]
        for nm in ["A1", "A2", "B"]:
            m = leaf_of == nm
            if m.any():
                a0.hist(deg[m], bins=bins, color=COL[nm], alpha=0.8, label=nm)
        bud = r["budget"]
        a0.set_ylabel(f"gen {r['g']}\nhot {bud['hot']/1e3:.0f}k · AIS {bud['ais']} · cold {bud['cold']/1e3:.0f}k",
                      fontsize=8.5)
        a0.set_title("(1) KCC isolated basins → leaves", fontsize=8.5)
        a0.set_xlim(-180, 180); a0.set_xticks([]); a0.set_yticks([]); a0.legend(fontsize=6, loc="upper center")

        # (col 1) TICA t2(lag) per isolated basin with per-basin ½T_res
        a1 = ax[i][1]
        for b in basins:
            col = COL.get(b["label"], "0.4")
            y = np.array([np.nan if v is None else v for v in b["t2s"]], float)
            a1.plot(lags, y, "-o", ms=3.5, color=col,
                    label=f"{b['label']}: t2={b['dec']['t2']:.0f} ({'split' if b['dec']['split'] else 'LEQ'})")
            a1.axhline(0.5 * b["Tres"], ls="--", c=col, lw=1.0, alpha=0.6)
        a1.set_xscale("log"); a1.set_yscale("log"); a1.set_ylim(20, 6000)
        a1.set_title("(2) TICA t2(lag) vs ½T$_{res}$", fontsize=8.5)
        a1.set_xlabel("MSM lag"); a1.set_ylabel("t2"); a1.legend(fontsize=6, loc="lower right")

        # (col 2) sub-basin RESIDENCE-time histograms + 2·t2_sub-k LEQ cutoff
        a2 = ax[i][2]
        any_split = False
        for b in basins:
            for ch in (b["children"] or []):
                any_split = True
                nm = _leaf_name(t, ch, pooled, bnd)
                segs = residence_segments(ch["mask"], wlens)
                t2sub = max(float(ch["dec"]["t2"]) if np.isfinite(ch["dec"]["t2"]) else 0.0, float(lags[0]))
                cut = 2.0 * t2sub
                if segs.size:
                    a2.hist(segs, bins=np.linspace(0, max(segs.max(), cut * 1.5), 24),
                            color=COL[nm], alpha=0.7, label=f"{nm} (valid>{cut:.0f}: {100*(segs>cut).mean():.0f}%)")
                    a2.axvline(cut, color=COL[nm], ls="--", lw=1.3)
        if not any_split:
            a2.text(0.5, 0.5, "no split at this T$_{res}$\n(basins in LEQ)", ha="center", va="center",
                    transform=a2.transAxes, fontsize=9, color="0.4")
        a2.set_title("(3) sub-basin residence times → LEQ-valid reverse-AIS", fontsize=8.5)
        a2.set_xlabel("consecutive residence in sub-basin (frames)"); a2.set_yticks([])
        if any_split:
            a2.legend(fontsize=6, loc="upper right")

        # (col 3) the tree
        _draw_tree(ax[i][3], t, basins, pooled, bnd, t_AB, t_A1A2, truepop)

    fig.suptitle("BAIS state tree at each generation — KCC isolated basins, TICA ½T$_{res}$ split test, and the "
                 "sub-basin residence-time filter (only segments > 2·t2$_{sub}$ seed reverse AIS). "
                 "Row labels give the invested hot/AIS/cold force-evaluations.", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    fig.savefig(OUT / "fig_bais_gen_trees_toy.png", dpi=145, bbox_inches="tight"); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_gen_trees_toy.png'}", file=sys.stderr)


def _draw_tree(axt, t, basins, pooled, bnd, t_AB, t_A1A2, truepop):
    axt.axis("off"); axt.set_xlim(0, 1); axt.set_ylim(0, 1); axt.set_title("(4) resolved state tree", fontsize=8.5)

    def box(x, y, name, pop, r=900):
        axt.scatter([x], [y], s=r, color=COL.get(name, "0.6"), edgecolors="k", zorder=3)
        axt.text(x, y, name, ha="center", va="center", fontsize=9, fontweight="bold", color="w", zorder=4)
        axt.text(x, y - 0.075, f"π={pop:.2f}", ha="center", va="top", fontsize=7, zorder=4)

    def edge(x0, y0, x1, y1, prop):
        axt.plot([x0, x1], [y0, y1], "-", c="0.45", lw=1.4, zorder=1)
        axt.text((x0 + x1) / 2 + 0.02, (y0 + y1) / 2, f"{prop:.2f}", fontsize=7, color="0.3")

    def sib(x0, x1, y, tag, dy=0.08):
        axt.annotate("", xy=(x1, y), xytext=(x0, y), arrowprops=dict(arrowstyle="<->", ls="--", color="#b03030", lw=1.2))
        axt.text((x0 + x1) / 2, y + dy, tag, ha="center", va="bottom", fontsize=6.8, color="#b03030")

    box(0.5, 0.9, "root", 1.0)
    A = next((b for b in basins if b["label"] == "A"), None)
    B = next((b for b in basins if b["label"] == "B"), None)
    if A is not None:
        box(0.30, 0.56, "A", truepop["A"]); edge(0.5, 0.83, 0.30, 0.63, truepop["A"])
    if B is not None:
        box(0.74, 0.56, "B", truepop["B"]); edge(0.5, 0.83, 0.74, 0.63, truepop["B"])
    if A is not None and B is not None:
        sib(0.40, 0.64, 0.56, f"t$_{{AB}}$≈{t_AB:.0f} (ref)")
    if A is not None and A["children"]:
        box(0.16, 0.18, "A1", truepop["A1"]); box(0.44, 0.18, "A2", truepop["A2"])
        edge(0.30, 0.49, 0.16, 0.25, truepop["A1"] / truepop["A"]); edge(0.30, 0.49, 0.44, 0.25, truepop["A2"] / truepop["A"])
        sib(0.22, 0.38, 0.18, f"t2≈{A['dec']['t2']:.0f} (an. {t_A1A2:.0f})", dy=0.11)
    elif A is not None:
        axt.text(0.30, 0.40, "A in LEQ\n(no split)", ha="center", fontsize=7, color="0.4")


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
