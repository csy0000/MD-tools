#!/usr/bin/env python3
"""demo_baus_umbrella_restriction.py — how BAUS-10/50/100 restrict local structure with the flat-bottom bias.

The number of umbrellas is the AUTO-DETECTED state count K* from the AIS landings (GMM+BIC; see Figure 3): at
N_AIS = 10/50/100 the detector returns K* = 8/4/4 states. For each budget we place one flat-bottom umbrella at each
detected medoid and Langevin-sample under it. Each umbrella is UNBIASED inside its flat-bottom window [center ± hw]
and harmonically walled outside, so it restricts sampling to the local structure of that state:

    E_wall(θ) = ½ k · max(0, dev − hw)² ,   dev = arccos(cos(θ − center))   (0 inside the window, wall outside)

The overlaid restricted densities (one colour per state) show BAUS confining the ensemble to each state; more AIS
shots → fewer, cleaner states → wider, better-separated windows.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_baus_umbrella_restriction
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402
from escort_ais.methods.state_detect import detect_kstar, halfwidths, spring_constants  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])
BUDGETS = [10, 50, 100]
E_TARGET = 8.0                                   # kT of flat-bottom confinement at the nearest neighbour


def detect_medoids(angles, logw, seed=0):
    """(K*, sorted medoids rad) via the shared GMM+BIC detector on cold-weighted landings."""
    _, _, k_star, medoids = detect_kstar(angles, logw, seed=seed)
    return k_star, medoids


def main(seed=0, hot_steps=100_000, hot_walkers=10, us_n=1500, us_walkers=1, us_burn=600):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    grid = np.linspace(-np.pi, np.pi, 720); U = t.U_cold(grid); U -= U.min()

    # forward AIS landings (nested), generated identically to Figure 3 (same seed/pool) so K* is consistent
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, t.s_hot, rng)
    hot = wrap(hraw[(hot_steps // hot_walkers) // 20:].reshape(-1))
    xh = hot[rng.integers(0, len(hot), 1024)]                          # match demo_toy_ais_landing_sweep pool
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=10, freq=10, rng=rng)

    fig, axes = plt.subplots(1, len(BUDGETS), figsize=(5.4 * len(BUDGETS), 4.8), sharey=True)
    params = {}
    for ax, N in zip(axes, BUDGETS):
        w = np.exp(lwf[:N] - lwf[:N].max())
        Kstar, medoids = detect_medoids(land[:N], lwf[:N], seed=seed)
        hw = halfwidths(medoids)
        kspring = spring_constants(medoids, hw, e_target=E_TARGET)    # distance-calibrated flat-bottom stiffness
        assign = np.argmin(np.abs(wrap(land[:N][:, None] - medoids[None, :])), axis=1)   # landing → nearest state
        axU = ax.twinx()
        axU.plot(np.degrees(grid), U, color="0.55", lw=1.4, zorder=1)
        axU.set_ylim(0, 16); axU.set_yticks([])
        cols = plt.cm.tab10(np.linspace(0, 1, len(medoids)))
        basin_params = []
        for b, (c, mu, h) in enumerate(zip(cols, medoids, hw)):
            s = t.us_sample(mu, h, us_n, rng, k=float(kspring[b]), burn=us_burn, walkers=us_walkers)
            ax.hist(np.degrees(s), bins=np.linspace(-180, 180, 121), density=True, color=c, alpha=0.5, zorder=3)
            ax.axvspan(np.degrees(mu - h), np.degrees(mu + h), color=c, alpha=0.10, zorder=0)   # flat-bottom window
            ax.axvline(np.degrees(mu), color=c, lw=1.2, ls="--", zorder=4)
            basin_params.append(dict(center_deg=round(float(np.degrees(mu)), 1),
                                     hw_deg=round(float(np.degrees(h)), 1), k=round(float(kspring[b]), 1)))
        # actual AIS landings as a rug (count them!): tick per landing, coloured by state, sized by weight
        wn = w / w.max()
        ax.scatter(np.degrees(land[:N]), np.full(N, -0.0035), s=20 + 90 * wn, c=cols[assign],
                   marker="|", linewidths=1.3, zorder=6, clip_on=False)
        ax.set_title(f"BAUS-{N}  ({N} AIS landings → K*={Kstar} states)", fontsize=11)
        ax.set_xlabel("θ (deg)"); ax.set_xlim(-180, 180); ax.set_ylim(-0.007, 0.07)
        params[f"BAUS-{N}"] = dict(n_landings=int(N), K_star=int(Kstar), basins=basin_params)
    axes[0].set_ylabel("restricted density (per umbrella)")
    axes[0].annotate("│ = individual AIS landings (size ∝ weight)", (0.02, 0.02), xycoords="axes fraction",
                     fontsize=8, color="0.3")
    fig.suptitle("BAUS restricts local structure with a flat-bottom bias — #umbrellas = auto-detected K* from the "
                 "AIS landings\n"
                 r"$E_{\mathrm{wall}}(\theta)=\frac{1}{2} k\,\max(0,\ \mathrm{dev}-\mathrm{hw})^2$, "
                 r"$\mathrm{dev}=\arccos\cos(\theta-\mathrm{center})$; "
                 r"$k=2E_{\mathrm{target}}/(d_{\mathrm{near}}-\mathrm{hw})^2$ (dist-calibrated); "
                 r"grey = $U_{\mathrm{cold}}(\theta)$", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.9])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_baus_umbrella_restriction.png", dpi=190); plt.close(fig)
    (OUT / "baus_umbrella_params.json").write_text(json.dumps(dict(e_target=E_TARGET, budgets=params), indent=2))
    print(json.dumps(params, indent=2))
    print(f"  wrote {OUT / 'fig_baus_umbrella_restriction.png'}", file=sys.stderr)


if __name__ == "__main__":
    main()
