#!/usr/bin/env python3
"""demo_pcca_vs_tica_toy.py — kinetic sub-basin split by PCCA+ vs TICA, on the 1-D toy's major basin A.

The BAIS state-determination splits an isolated KCC basin into sub-basins along the TICA slow coordinate
(2-means on psi2). PCCA+ (Perron-cluster cluster analysis) is the classical alternative: build a fine
reversible MSM inside the basin and coarse-grain its metastable sets from the transfer-operator eigenvectors.
This compares the two on basin A (which should split into A1,A2):
  * do they agree on the A1|A2 assignment of each cold frame?
  * do they give the same sub-basin populations (vs the analytic conditional) and the same slow timescale t2?

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_pcca_vs_tica_toy [--fast]
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.kcc_split import (level1_kcc, cluster_its_curve, _split_location, _kmeans_labels,
                                          _cluster_count_matrix, residence_T)
from escort_ais.methods.four_state_msm import reversible_transition_matrix, implied_timescales

ROOT = project_root()
OUT = ROOT / "results/toy"
COL = {"A1": "#1f6f1f", "A2": "#8fce8f", "agree": "#3a8f3a", "disagree": "#c0392b"}


def _feats(traj):
    cols = [wrap(traj[:, k]) for k in range(traj.shape[1])]
    feats = np.vstack([np.column_stack([np.cos(c), np.sin(c)]) for c in cols])
    return feats, [len(c) for c in cols], np.concatenate(cols)


def _lags(T):
    base = max(8, T // 200)
    return [base * m for m in (1, 2, 4, 8, 16) if base * m < T // 4] or [max(4, T // 20), max(8, T // 8)]


def pcca_split(feats, mask, wlens, lag, n_micro=12, seed=0):
    """Fine reversible MSM inside `mask` -> PCCA+(2) metastable sets. Returns (per-in-mask-frame set label,
    t2 = slowest MSM implied timescale, n_micro_used)."""
    from deeptime.markov.msm import MarkovStateModel
    idx = np.where(mask)[0]
    nm = int(min(n_micro, max(2, len(idx) // 40)))
    micro_local = _kmeans_labels(feats[idx], nm, seed)
    micro_full = -np.ones(len(feats), int); micro_full[idx] = micro_local
    C = _cluster_count_matrix(micro_full, mask, wlens, int(lag), nm)
    if C.sum() < 5 * nm or (C.sum(1) == 0).any():
        return None, np.nan, nm
    T, _ = reversible_transition_matrix(C)
    try:
        pcca = MarkovStateModel(T).pcca(2)
        assign = np.asarray(pcca.assignments, int)
    except Exception:
        return None, np.nan, nm
    its = implied_timescales(T, int(lag))
    t2 = float(its[0]) if len(its) and np.isfinite(its[0]) else np.nan
    return assign[micro_local], t2, nm


def run(fast=False, seed=0):
    t = Toy1D(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    pops = np.array(ana["pops"])                                     # [B, A1, A2]
    kin = t.smoluchowski_kinetics(); t_A1A2 = float(kin["t_A1A2"])
    pi_A1c, pi_A2c = pops[1] / (pops[1] + pops[2]), pops[2] / (pops[1] + pops[2])   # analytic conditional in A

    # longer walkers so A1<->A2 is well sampled (better t2); alpha_split=10 still splits A. Drop A<->B crossers.
    T_walk = 2000 if fast else 3000
    n_per_well = 12 if fast else 16
    traj = t.langevin(np.repeat(wells, n_per_well), T_walk, 1.0, rng)
    cols = [wrap(traj[:, k]) for k in range(traj.shape[1])]
    cols = [c for c in cols if not ((0 in (labs := set(t.basin_of(c, bnd).astype(int).tolist()))) and ({1, 2} & labs))]
    feats = np.vstack([np.column_stack([np.cos(c), np.sin(c)]) for c in cols])
    wlens = [len(c) for c in cols]; pooled = np.concatenate(cols)
    lags = _lags(T_walk); lag = max(8, T_walk // 60)
    kcc = level1_kcc(feats, wlens, lag=max(8, T_walk // 200), k=20, min_count=5, seed=seed)
    # pick the major isolated basin A (spans A1,A2 = the largest that is not B)
    A = None; best = -1
    for c in range(kcc["n_clusters"]):
        m = kcc["frame_cluster"] == c
        b = np.bincount(t.basin_of(pooled[m], bnd).astype(int), minlength=3)
        if (b[1] + b[2]) > best and (b[1] + b[2]) > b[0]:
            best = b[1] + b[2]; A = m
    if A is None:
        print("  no A basin found", file=sys.stderr); return

    Tres = residence_T(A, wlens)
    # --- TICA split (2-means on psi2) ---
    t2s, t3s, proj = cluster_its_curve(feats, A, wlens, lags=lags, seed=seed)
    t2_tica = float([x for x in t2s if x][-1]) if any(x for x in t2s) else np.nan
    parts = _split_location(proj, A, seed=seed)
    idxA = np.where(A)[0]
    tica_lab = np.full(len(idxA), -1, int)
    if parts is not None:
        a_mask, b_mask = parts
        tica_lab[np.isin(idxA, np.where(a_mask)[0])] = 0
        tica_lab[np.isin(idxA, np.where(b_mask)[0])] = 1

    # --- PCCA+ split ---
    pcca_lab, t2_pcca, nmic = pcca_split(feats, A, wlens, lag, seed=seed)

    # align PCCA+ labels to TICA labels (by which set is the low-theta = A1) and compute agreement
    thA = pooled[idxA]
    def _order(lab):
        if lab is None:
            return None
        m0 = np.nanmean(np.degrees(thA[lab == 0])) if (lab == 0).any() else 0
        m1 = np.nanmean(np.degrees(thA[lab == 1])) if (lab == 1).any() else 0
        return lab if m0 <= m1 else 1 - lab      # label 0 = lower theta = A1
    tica_o = _order(tica_lab); pcca_o = _order(pcca_lab)
    agree = np.nan
    if tica_o is not None and pcca_o is not None:
        both = (tica_o >= 0)
        agree = float((tica_o[both] == pcca_o[both]).mean())

    def _pops(lab):
        if lab is None:
            return (np.nan, np.nan)
        n = (lab >= 0).sum()
        return ((lab == 0).sum() / n, (lab == 1).sum() / n) if n else (np.nan, np.nan)
    pop_tica, pop_pcca = _pops(tica_o), _pops(pcca_o)

    res = dict(seed=seed, T_res=int(Tres), n_micro_pcca=int(nmic), agreement=agree,
               t2_tica=round(t2_tica, 1), t2_pcca=round(t2_pcca, 1), t2_analytic=round(t_A1A2, 1),
               pop_tica=[round(x, 3) for x in pop_tica], pop_pcca=[round(x, 3) for x in pop_pcca],
               pop_analytic=[round(pi_A1c, 3), round(pi_A2c, 3)])
    print("  " + str(res), file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    make_figure(thA, tica_o, pcca_o, proj, idxA, agree, pop_tica, pop_pcca, (pi_A1c, pi_A2c),
                t2_tica, t2_pcca, t_A1A2, nmic)
    return res


def make_figure(thA, tica_o, pcca_o, proj, idxA, agree, pop_tica, pop_pcca, pop_an, t2_tica, t2_pcca, t2_an, nmic):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    deg = np.degrees(thA); bins = np.linspace(0, 180, 55)
    fig, ax = plt.subplots(2, 3, figsize=(16.5, 9.0))

    def _density(a, lab, title):
        if lab is None:
            a.text(0.5, 0.5, "no split", ha="center", transform=a.transAxes); a.set_title(title, fontsize=10); return
        for s, nm in [(0, "A1"), (1, "A2")]:
            m = lab == s
            if m.any():
                a.hist(deg[m], bins=bins, color=COL[nm], alpha=0.8, label=nm)
        a.set_title(title, fontsize=10); a.set_xlabel("θ (deg)"); a.set_yticks([]); a.legend(fontsize=8)

    _density(ax[0, 0], tica_o, "(A) TICA split (2-means on $\\psi_2$)")
    _density(ax[0, 1], pcca_o, f"(B) PCCA+ split ({nmic} microstates → 2 sets)")

    # (C) psi2 coloured by agree/disagree
    axc = ax[0, 2]
    if tica_o is not None and pcca_o is not None and proj is not None:
        p = np.asarray(proj)[idxA]; both = tica_o >= 0
        ag = both & (tica_o == pcca_o); dis = both & (tica_o != pcca_o)
        axc.hist(p[ag], bins=30, color=COL["agree"], alpha=0.8, label=f"agree ({100*agree:.0f}%)")
        if dis.any():
            axc.hist(p[dis], bins=30, color=COL["disagree"], alpha=0.8, label="disagree")
    axc.set_title("(C) $\\psi_2$: TICA/PCCA+ per-frame agreement", fontsize=10)
    axc.set_xlabel("TICA slow coord $\\psi_2$"); axc.set_yticks([]); axc.legend(fontsize=8)

    # (D) sub-basin populations
    axd = ax[1, 0]; x = np.arange(2)
    axd.bar(x - 0.25, pop_tica, 0.25, color="#2c6fbb", label="TICA")
    axd.bar(x + 0.00, pop_pcca, 0.25, color="#d08a2c", label="PCCA+")
    axd.bar(x + 0.25, pop_an, 0.25, color="0.6", label="analytic")
    axd.set_xticks(x); axd.set_xticklabels(["A1", "A2"]); axd.set_ylabel("conditional population in A")
    axd.set_title("(D) sub-basin populations", fontsize=10); axd.legend(fontsize=8)

    # (E) slow timescale t2
    axe = ax[1, 1]
    vals = [t2_tica, t2_pcca, t2_an]
    axe.bar([0, 1, 2], vals, color=["#2c6fbb", "#d08a2c", "0.6"])
    axe.set_xticks([0, 1, 2]); axe.set_xticklabels(["TICA-MSM", "PCCA+ MSM", "analytic"])
    axe.set_ylabel("$A_1\\leftrightarrow A_2$ timescale (frames)"); axe.set_title("(E) slow timescale $t_2$", fontsize=10)
    for i, v in enumerate(vals):
        if np.isfinite(v):
            axe.text(i, v, f"{v:.0f}", ha="center", va="bottom", fontsize=8)

    # (F) summary text
    axf = ax[1, 2]; axf.axis("off")
    lines = ["Comparison summary", "",
             f"per-frame agreement: {100*agree:.0f}%" if np.isfinite(agree) else "agreement: n/a",
             f"pop A1/A2  TICA:  {pop_tica[0]:.2f}/{pop_tica[1]:.2f}",
             f"           PCCA+: {pop_pcca[0]:.2f}/{pop_pcca[1]:.2f}",
             f"           anal.: {pop_an[0]:.2f}/{pop_an[1]:.2f}",
             f"t2  TICA {t2_tica:.0f} · PCCA+ {t2_pcca:.0f} · anal {t2_an:.0f}",
             "",
             "TICA: split along the slow TIC (geometry-",
             "  aware 1-D projection, then 2-means).",
             "PCCA+: coarse-grain the reversible MSM's",
             "  metastable sets from its eigenvectors.",
             "Both should recover the A1|A2 split; they",
             "agree closely on this toy."]
    axf.text(0.02, 0.98, "\n".join(lines), va="top", ha="left", fontsize=9, family="monospace")

    fig.suptitle("Kinetic sub-basin split of basin A: PCCA+ vs TICA on the 1-D toy", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(OUT / "fig_pcca_vs_tica_toy.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_pcca_vs_tica_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
