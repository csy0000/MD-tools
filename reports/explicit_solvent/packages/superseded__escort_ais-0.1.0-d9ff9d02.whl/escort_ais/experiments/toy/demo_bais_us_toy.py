#!/usr/bin/env python3
"""demo_bais_us_toy.py — validate the REMD-free bAIS+US thermodynamics tool on the 1D toy.

Reconstruct the full cold Boltzmann P(θ) WITHOUT REMD, from:
  * between-state populations from bAIS: forward (hot→cold) + reverse (cold→hot) AIS, combined per state with BAR
    (endpoint `solve_bar_with_infinite_works`, inf-padded forward + pool counts);
  * within-state shapes P(θ|state) from flat-bottom umbrella sampling (US) per state.

Run in the SAMPLABLE regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT) — the single system used throughout this PDF.
Failure→fix demonstrated:
  * plain COLD MD (Langevin) traps across the A↔B barrier → wrong P(θ) (the minor basin B under-weighted);
  * bAIS+US recovers the truth. FINE-state US (one window per sub-well) recovers P(θ) best; COARSE-state US (one
    window over the whole major basin A) is intermediate — better than plain cold MD but its within-A shape is less
    accurate. The gap widens as the internal barrier grows (coarse US eventually traps); here it is a modest 2.9 kT.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_us_toy
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.state_detect import spring_constants  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402

OUT = ROOT / "results/toy"
NB = 24                                                              # histogram bins for P(θ)
KAPPA = np.array([26.0, 26.0, 9.0])                                  # samplable regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)


def _hist(theta, bins=NB):
    h, e = np.histogram(theta, bins=bins, range=(-np.pi, np.pi), density=True)
    return 0.5 * (e[:-1] + e[1:]), h


def _tv(p, q, dx):
    return float(0.5 * np.sum(np.abs(p - q)) * dx)


def bais_between_state(t, xh, land, Wf, lb, wells_rad, hw_rad, rng, m_steps, freq, us_steps):
    """Per-state cold populations via forward+reverse BAR; also return each state's US within-state samples.

    Flat-bottom umbrella springs are distance-calibrated (``spring_constants``, e_target=8 kT) rather than a fixed
    stiff k, for consistency with Figures 3-5. Centers may be unsorted (e.g. the coarse case), so the sorted-order k
    array is scattered back to the caller's basin order to keep k aligned with each (center, half-width) pair.
    """
    nb = len(wells_rad); K = len(Wf)
    wells_rad = np.asarray(wells_rad, float); hw_rad = np.asarray(hw_rad, float)
    order = np.argsort(wells_rad)
    kspring = np.empty(nb)
    kspring[order] = spring_constants(wells_rad[order], hw_rad[order], e_target=8.0)
    print(f"  [bais_us] centers_deg={np.round(np.degrees(wells_rad),0)} kspring={np.round(kspring,2)}",
          file=sys.stderr)
    dF = np.zeros(nb); us_samples = []
    for b in range(nb):
        us = t.us_sample(wells_rad[b], hw_rad[b], us_steps, rng, k=float(kspring[b]), burn=1000, walkers=1)
        us_samples.append(us)
        _, lwr = t.ais_switch(us, 1.0, t.s_hot, m_steps, freq, rng)   # reverse cold→hot from US equilibrium
        Wr = -lwr
        Wfb = np.where(lb == b, Wf, np.inf)                          # forward works, inf if not landing in b
        dF[b], _ = solve_bar_with_infinite_works(Wfb, Wr, n_f_total=K, n_r_total=len(Wr))
    pi = np.exp(-(dF - dF.min())); pi /= pi.sum()
    return pi, us_samples


def run(seed=0, n_hot=6000, m_steps=60, freq=4, us_steps=4000):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations()
    bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    cg, p_true = _hist_grid(t)                                       # analytic P(θ) on the histogram grid
    dx = cg[1] - cg[0]

    # --- bAIS: hot ensemble + forward AIS ---
    xh = t.sample_boltzmann(t.s_hot, n_hot, rng)
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps, freq, rng); Wf = -lwf
    lb = t.basin_of(land, bnd)
    ess = float(np.exp(lwf).sum() ** 2 / np.exp(2 * lwf).sum())

    # --- FINE states (per sub-well): between-state BAR + US shape → reconstruct P(θ) ---
    hw_fine = np.full(nb, np.radians(30.0))
    pi_fine, us_fine = bais_between_state(t, xh, land, Wf, lb, wells, hw_fine, rng, m_steps, freq, us_steps)
    p_fine = _reconstruct(t, cg, pi_fine, us_fine)

    # --- COARSE states (major A merged): 2 states = A(center 90°, hw 60°) + B(minor well) ---
    a_wells = np.array([np.radians(90.0), wells[np.argmin(np.abs(np.degrees(wells) + 120))]])  # A, B
    a_hw = np.array([np.radians(60.0), np.radians(35.0)])
    # coarse landing labels: in-A window vs B
    in_A = np.abs(wrap(land - a_wells[0])) < a_hw[0]
    lb_c = np.where(in_A, 0, 1)
    pi_coarse, us_coarse = bais_between_state(t, xh, land, Wf, lb_c, a_wells, a_hw, rng, m_steps, freq, us_steps)
    p_coarse = _reconstruct(t, cg, pi_coarse, us_coarse)

    # --- baseline failure: plain COLD MD reservoir (traps) ---
    x0 = wrap(rng.uniform(-np.pi, np.pi, 400))
    cold = wrap(t.langevin(x0, us_steps, 1.0, rng)[-1])
    _, p_cold = _hist(cold)

    res = dict(
        seed=seed, ess_fwd=round(ess, 1), n_states_fine=nb,
        analytic_pops=[round(x, 3) for x in ana["pops"]],
        pi_fine=[round(x, 3) for x in pi_fine],
        pi_coarse=[round(x, 3) for x in pi_coarse],
        tv_ptheta=dict(cold_reservoir=round(_tv(p_cold, p_true, dx), 3),
                       bais_us_fine=round(_tv(p_fine, p_true, dx), 3),
                       bais_us_coarse=round(_tv(p_coarse, p_true, dx), 3)),
        pops_tv_fine=round(0.5 * float(np.abs(np.array(pi_fine) - ana["pops"]).sum()), 3))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "bais_us_toy.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
    make_figure(t, cg, p_true, p_cold, p_fine, p_coarse, ana, pi_fine, us_fine, res)
    return res


def _hist_grid(t, bins=NB):
    e = np.linspace(-np.pi, np.pi, bins + 1); cg = 0.5 * (e[:-1] + e[1:])
    p = t.p_eq(cg); p = p / (p.sum() * (cg[1] - cg[0]))
    return cg, p


def _reconstruct(t, cg, pi, us_samples):
    """P(θ) = Σ_state pi[state]·P(θ|state); P(θ|state) from the US samples of that state."""
    dx = cg[1] - cg[0]; p = np.zeros_like(cg)
    for w, us in zip(pi, us_samples):
        _, ph = _hist(us, bins=len(cg))
        p += w * ph
    return p / (p.sum() * dx)


def make_figure(t, cg, p_true, p_cold, p_fine, p_coarse, ana, pi_fine, us_fine, res):
    deg = np.degrees(cg)
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))
    # (A) reconstructed P(θ) vs analytic
    ax[0].plot(deg, p_true, "k-", lw=2.5, label="analytic (truth)")
    ax[0].plot(deg, p_fine, "-o", c="C0", ms=3, label=f"bAIS+US fine (TV {res['tv_ptheta']['bais_us_fine']})")
    ax[0].plot(deg, p_coarse, "-s", c="C1", ms=3, label=f"bAIS+US coarse (TV {res['tv_ptheta']['bais_us_coarse']})")
    ax[0].plot(deg, p_cold, "-^", c="0.5", ms=3, label=f"plain cold MD (TV {res['tv_ptheta']['cold_reservoir']})")
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("P(θ)")
    ax[0].set_title("reconstructed cold P(θ): bAIS+US fine best, coarse intermediate;\nplain cold MD fails (traps)",
                    fontsize=10); ax[0].legend(fontsize=8)
    # (B) state populations
    xb = np.arange(len(ana["pops"])); bw = 0.38
    ax[1].bar(xb - bw / 2, ana["pops"], bw, color="k", alpha=0.6, label="analytic")
    ax[1].bar(xb + bw / 2, pi_fine, bw, color="C0", label="bAIS (fwd+rev BAR)")
    ax[1].set_xticks(xb); ax[1].set_xticklabels([f"state {b}\n{ana['well_centers_deg'][b]:.0f}°"
                                                 for b in range(len(ana["pops"]))], fontsize=8)
    ax[1].set_ylabel("population"); ax[1].legend(fontsize=8)
    ax[1].set_title(f"between-state populations (pop TV {res['pops_tv_fine']}; fwd ESS {res['ess_fwd']:.0f})",
                    fontsize=10)
    # (C) within-state US shapes vs analytic conditional
    for b, us in enumerate(us_fine):
        c2, h2 = _hist(us, bins=NB)
        ax[2].plot(np.degrees(c2), h2, "-", color=plt.cm.tab10(b), lw=1.6, label=f"US state {b}")
    ax[2].plot(deg, p_true / p_true.max() * 0.02 + 0, ":", c="k", alpha=0.0)   # keep axis
    ax[2].set_xlabel("θ (deg)"); ax[2].set_ylabel("P(θ|state)")
    ax[2].set_title("flat-bottom US within-state shapes (fine)\neach sub-well equilibrates", fontsize=10)
    ax[2].legend(fontsize=8)
    fig.suptitle("bAIS+US on the 1D toy — REMD-free thermodynamics (between-state BAR + within-state US)",
                 fontsize=12)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_bais_us_toy.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_us_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
