#!/usr/bin/env python3
"""run_adaptive_baus_bata_toy.py — the 1-D toy engine for the adaptive BAUS/BAIS controller + a convergence run.

Provides ``ToyEngine`` (a thin ``Toy1D`` adapter implementing the ``adaptive.run_adaptive`` engine protocol) and a
CLI that runs the self-converging loop on both regimes and plots convergence vs total force-evaluations. The loop
streams the hot ensemble, fires AIS each round, auto-tunes the switch length by BAR overlap, and auto-seeds cold
walkers where BAUS/BAIS cannot resolve — stopping on internal self-consistency (no analytic reference used to drive
it; the analytic populations/kinetics are recorded only to *validate* convergence).

    conda activate escort-ais && python -m escort_ais.experiments.toy.run_adaptive_baus_bata_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402
from escort_ais.methods.baus import reconstruct_pmf  # noqa: E402
from escort_ais.methods.bais import estimate_bais  # noqa: E402
from escort_ais.common.budget import Budget  # noqa: E402
from escort_ais.workflows.adaptive import run_adaptive, AdaptiveConfig  # noqa: E402

OUT = ROOT / "results/toy"
REGIMES = {"S": np.array([26.0, 26.0, 9.0])}       # the single toy system (A↔B ~7.1 kT)
NG = 120


def _voronoi(theta, medoids):
    theta = np.atleast_1d(np.asarray(theta, float)); med = np.asarray(medoids, float)
    if med.size == 0:
        return np.zeros(theta.shape, int)
    return np.argmin(np.abs(wrap(theta[:, None] - med[None, :])), axis=1)


class ToyEngine:
    """Concrete 1-D-toy engine for adaptive.run_adaptive. Owns MD/AIS/estimator primitives + the force-eval budget."""

    def __init__(self, regime, n_shot=100, us_n=6000, us_walk=1, us_burn=600, ais_inner=6):
        self.t = Toy1D(kappa=REGIMES[regime])
        self.s_hot = self.t.s_hot
        self.n_shot = n_shot; self.us_n = us_n; self.us_walk = us_walk; self.us_burn = us_burn
        self.ais_inner = ais_inner
        self.budget = Budget()
        ana = self.t.populations()
        self.bnd_true = np.radians(ana["boundaries_deg"]); self.pt = np.array(ana["pops"]); self.nb_true = ana["n_basins"]
        self.its_true = float(self.t.smoluchowski_kinetics()["t_AB"])
        self.edges = np.linspace(-np.pi, np.pi, NG + 1); self.ctr = 0.5 * (self.edges[:-1] + self.edges[1:])
        self.dx = self.ctr[1] - self.ctr[0]

    # --- engine protocol ---
    def grid(self):
        return self.ctr, self.edges

    def hot_init(self, rng):
        return self.t.sample_boltzmann(self.s_hot, self.n_shot, rng)   # one hot walker per AIS shot

    def propagate_hot(self, x, n, rng):
        traj = self.t.langevin(x, n, self.s_hot, rng)
        self.budget.add("hot", Budget.langevin(len(x), n))
        return traj[-1]

    def forward_ais(self, x, m, rng):
        sched = np.linspace(np.sqrt(self.s_hot), 1.0, m + 1) ** 2      # √s-square spacing (m-adaptive), reversible at s_hot=0.01
        land, lw = self.t.ais_switch(x, self.s_hot, 1.0, m_steps=m, freq=self.ais_inner, rng=rng, schedule=sched)
        self.budget.add("fwd_ais", Budget.ais(len(x), m, self.ais_inner))
        return land, lw

    def umbrella(self, medoid, hw, k, rng):
        self.budget.add("umbrella", Budget.langevin(self.us_walk, self.us_n, self.us_burn))
        return self.t.us_sample(medoid, hw, self.us_n, rng, k=k, burn=self.us_burn, walkers=self.us_walk)

    def reverse_ais(self, starts, m, rng):
        sched = np.linspace(np.sqrt(self.s_hot), 1.0, m + 1) ** 2      # √s-square spacing (m-adaptive), reversible at s_hot=0.01
        _, lwr = self.t.ais_switch(starts, 1.0, self.s_hot, m_steps=m, freq=self.ais_inner, rng=rng, schedule=sched[::-1])
        self.budget.add("rev_ais", Budget.ais(len(starts), m, self.ais_inner))
        return lwr

    def basin_of(self, theta, medoids):
        return _voronoi(theta, medoids)

    def reconstruct(self, ctr, edges, Wf, land_basin, Wr, rev_basin, us_samples, nb, medoids, rng):
        return reconstruct_pmf(ctr, edges, Wf, land_basin, Wr, rev_basin, us_samples, nb, medoids, _voronoi, rng=rng)

    def cold_run(self, seed_angle, n, rng):
        self.budget.add("cold", Budget.langevin(1, n), sequential_len=n)
        return wrap(self.t.langevin(np.array([float(seed_angle)]), n, 1.0, rng)[:, 0])

    def cold_counts(self, cold_walkers, medoids, lag):
        nb = len(medoids); C = np.zeros((nb, nb))
        for w in cold_walkers:
            d = _voronoi(w, medoids)
            if len(d) > lag:
                np.add.at(C, (d[:-lag], d[lag:]), 1.0)
        return C

    def estimate_bais(self, C, pi, lag):
        return estimate_bais(C, pi, lag=lag)

    def reference_metrics(self, baus, bata, medoids, C):
        """Analytic validation only (NOT used to drive the loop): population/stationary TV to truth + ITS rel-err."""
        P = np.asarray(baus["P"], float)
        lab = self.t.basin_of(self.ctr, self.bnd_true).astype(int)
        pop = np.array([(P[lab == b] * self.dx).sum() for b in range(self.nb_true)])
        pop = pop / pop.sum() if pop.sum() > 0 else pop
        med_basin = self.t.basin_of(np.asarray(medoids), self.bnd_true).astype(int)
        pi_true = np.zeros(self.nb_true)
        for k, mb in enumerate(med_basin):
            pi_true[mb] += bata["pi"][k]
        pi_true = pi_true / pi_true.sum() if pi_true.sum() > 0 else pi_true
        its = bata.get("its", np.nan)
        return dict(pop_tv=float(0.5 * np.abs(pop - self.pt).sum()),
                    stat_tv=float(0.5 * np.abs(pi_true - self.pt).sum()),
                    its_relerr=(None if not np.isfinite(its) else float(abs(its - self.its_true) / self.its_true)))


def run_regime(regime, cfg, seed=0):
    engine = ToyEngine(regime, n_shot=cfg.n_shot)
    res = run_adaptive(engine, cfg, np.random.default_rng(seed))
    res["regime"] = regime
    est = [h for h in res["history"] if h["event"] == "estimate"]
    doubles = [h for h in res["history"] if h["event"] == "double_switch"]
    print(f"[{regime}] converged={res['converged']} at round {res['converged_round']} "
          f"budget={est[-1]['budget']:.2e} | final pop_tv={est[-1].get('pop_tv'):.3f} "
          f"stat_tv={est[-1].get('stat_tv'):.3f} K*={est[-1]['k_star']} n_cold={est[-1]['n_cold']} "
          f"switch-doublings={len(doubles)}", file=sys.stderr)
    return res


def make_figure(results):
    fig, ax = plt.subplots(len(results), 3, figsize=(15.5, 4.4 * len(results)), squeeze=False)
    names = {"S": "A↔B ~7.1 kT"}
    for i, res in enumerate(results):
        reg = res["regime"]; est = [h for h in res["history"] if h["event"] == "estimate"]
        bud = np.array([h["budget"] for h in est])
        cr = res["converged_round"]
        # (A) accuracy + self-consistency vs budget
        ax[i, 0].loglog(bud, [h.get("pop_tv", np.nan) for h in est], "-o", c="#2a7f2a", ms=4, label="BAUS pop-TV (vs analytic)")
        ax[i, 0].loglog(bud, [max(h.get("pi_tv", np.nan), 1e-4) for h in est], "-s", c="#888", ms=4,
                        label="self-consistency Δπ (stop signal)")
        ax[i, 0].axhline(0.02, c="0.6", ls=":", lw=1)
        ax[i, 0].set_ylabel("total-variation"); ax[i, 0].set_title(f"({'AB'[i]}1) accuracy & self-consistency — {names[reg]}", fontsize=9.5)
        ax[i, 0].legend(fontsize=8)
        # (B) overlap + switch length
        ax[i, 1].semilogx(bud, [h["min_overlap"] for h in est], "-o", c="#c0392b", ms=4, label="min BAR overlap")
        ax[i, 1].axhline(0.2, c="0.6", ls=":", lw=1, label="BOV_cut=0.2")
        axr = ax[i, 1].twinx()
        axr.semilogx(bud, [h["m_steps"] for h in est], "-^", c="#2c6fbb", ms=4, label="switch length m")
        axr.set_ylabel("switch length m", color="#2c6fbb")
        ax[i, 1].set_ylim(0, 1.02); ax[i, 1].set_ylabel("min BAR overlap", color="#c0392b")
        ax[i, 1].set_title(f"({'AB'[i]}2) overlap gate → switch doubling", fontsize=9.5); ax[i, 1].legend(fontsize=8, loc="lower right")
        # (C) states + cold walkers
        ax[i, 2].semilogx(bud, [h["k_star"] for h in est], "-o", c="#7a4fb0", ms=4, label="K* (detected states)")
        ax[i, 2].semilogx(bud, [h["n_cold"] for h in est], "-s", c="#e08000", ms=4, label="# cold walkers (seeded)")
        ax[i, 2].axhline(3, c="0.6", ls=":", lw=1, label="true #states")
        ax[i, 2].set_ylabel("count"); ax[i, 2].set_title(f"({'AB'[i]}3) auto state-detection & seeding", fontsize=9.5)
        ax[i, 2].legend(fontsize=8)
        for a in ax[i]:
            a.set_xlabel("total force-evaluations")
            if cr is not None and cr < len(est):
                a.axvline(est[cr]["budget"], c="green", ls="--", lw=1.2, alpha=0.7)
    fig.suptitle("Adaptive BAUS/BAIS — self-converging protocol on the 1-D toy "
                 "(stream hot+AIS · overlap-gated switch · auto-seed unresolved states; green dashed = converged)",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_adaptive_convergence.png", dpi=170); plt.close(fig)
    print(f"  wrote {OUT / 'fig_adaptive_convergence.png'}", file=sys.stderr)


def main(fast=False):
    # STRESSED start (short switch m0=3 + few shots n_shot=12) so the two feedback rules are actually
    # exercised: BAR overlap starts below the cut -> the switch-doubling gate fires, and the minor basin
    # B is missed at first (K*=2) -> auto-seeding grows it to K*=3. Converges 4/4 across seeds; seed 2 is
    # plotted as it visibly exercises both. (A well-fed start hides the gates — the earlier "flat" figure.)
    if fast:
        cfg = AdaptiveConfig(ais_freq=1000, n_shot=12, m0=3, cold_chunk=15000, min_cold=3500,
                             max_rounds=24, budget_cap=1.2e7, k_stable=2, lag=400, tol=0.05, pi_tol=0.015)
    else:
        cfg = AdaptiveConfig(ais_freq=1200, n_shot=12, m0=3, cold_chunk=20000, min_cold=4000,
                             max_rounds=40, budget_cap=1.5e7, k_stable=3, lag=500, tol=0.05, pi_tol=0.012)
    results = [run_regime(reg, cfg, seed=2) for reg in REGIMES]
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "adaptive_toy_run.json").write_text(json.dumps(
        dict(config=cfg.__dict__, results=[{k: v for k, v in r.items()} for r in results]), indent=2))
    make_figure(results)
    print("done", file=sys.stderr)


if __name__ == "__main__":
    main(fast="--fast" in sys.argv)
