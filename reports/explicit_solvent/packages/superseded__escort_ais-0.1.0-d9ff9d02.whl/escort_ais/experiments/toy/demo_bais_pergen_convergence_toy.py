#!/usr/bin/env python3
"""demo_bais_pergen_convergence_toy.py — PER-GENERATION convergence of fixed-π BAIS vs the walker baselines.

At every BAIS generation (a cumulative-budget "timestamp") we record the endpoint-BAR (fixed-π) populations and the
three restricted pairwise implied timescales A1-A2 / A1-B / A2-B, plus the cumulative barrier crossings. The
BAIS-free walker baselines (single, multi) are evaluated at the SAME budget timestamps via trajectory prefixes.
Curves are the median over seeds on a common log-budget grid.

Methods (rows of the figure): fixed-π BAIS, BAIS LEQ-only, multi-walker, single-walker, REST2-REMD. Columns:
per-basin populations, per-basin error, pairwise ITS, cumulative barrier crossings.

UNIFIED regimes (all κ-retune at fixed populations [0.25,0.42,0.33]; same s_hot=0.01 √s-square AIS ladder and √s-square
4-replica REMD reference [1.0,0.49,0.16,0.01]): the default BASE toy (samplable, A↔B≈7.1 kT crossable); with --mid3x,
the 3×-BARRIER κ-RETUNE toy (κ=[70,70,30] → A1↔A2≈8.8 kT crossable, A↔B≈21.4 kT frozen); with --hard, the 5×-BARRIER
κ-RETUNE toy (κ=[114,114,45] → A1↔A2≈14.5 kT and A↔B≈33 kT BOTH frozen, populations still PRESERVED — NOT a
potential-scaling collapse). Cold MD freezes progressively; only the annealing switch / exchange recover the populations.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_pergen_convergence_toy [--fast] [--hard|--mid3x]
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import (
    bais_protocol_run, LAG, PAIRS_IDX, _pair_its, _seg_crossings, HARD5X_KAPPA, MID3X_KAPPA, AIS_LADDER)

ROOT = project_root()
OUT = ROOT / "results/toy"
METHODS = ["fixed-π BAIS", "BAIS LEQ-only", "multi-walker", "single-walker", "REMD (s-ladder)"]
# UNIFIED REST2-REMD reference for EVERY regime: √s-square 4-replica ladder [1.0, 0.49, 0.16, 0.01] (cold s=1 FIRST;
# exchange every 100). Matches the √s-square AIS ladder's hot end (s_hot=0.01). Replaces the old base 5-linear and 5×
# 5-log ladders. Every regime is a κ-retune at fixed populations [0.25,0.42,0.33]: base (κ=None), 3× (κ=[70,70,30],
# A1↔A2≈8.8 kT crossable, A↔B≈21.4 kT frozen), 5× (κ=[114,114,45], A1↔A2≈14.5 kT and A↔B≈33 kT BOTH frozen).
REMD_S = tuple((np.linspace(np.sqrt(0.01), 1.0, 4) ** 2)[::-1])      # = [1.0, 0.49, 0.16, 0.01] (√s, 4 replicas)
BNAMES = ["B", "A1", "A2"]
BCOL = {"B": "#7a4fb0", "A1": "#1f6f1f", "A2": "#8fce8f"}
PCOL = ["#1f6f1f", "#b03030", "#7a4fb0"]                              # A1-A2, A1-B, A2-B


def _tv(pi, analytic):
    p = np.nan_to_num(np.asarray(pi, float), nan=0.0)
    return 0.5 * float(np.abs(p - np.asarray(analytic, float)).sum())


def _pair_cols(rows):
    """Transpose per-gen [gen][pair] -> [pair][gen]."""
    return [[row[k] for row in rows] for k in range(len(PAIRS_IDX))]


def _bais_record(stamps, pi_list, pergen_cross, pergen_pair_its, analytic):
    return dict(budget=stamps, pi=[list(p) for p in pi_list], tv=[_tv(p, analytic) for p in pi_list],
                pair_its=_pair_cols(pergen_pair_its), cross=_pair_cols(pergen_cross))


def walker_pergen(seed, budget, stamps, kind, u_scale=1.0, kappa=None):
    """Evaluate a BAIS-free walker baseline at the BAIS generation timestamps (trajectory prefixes):
    per-basin populations, pairwise ITS, and cumulative barrier crossings. `u_scale` selects the toy (1.0=base);
    `kappa` selects a κ-retune toy (e.g. [70,70,30] = 3× regime) and overrides u_scale when set."""
    t = Toy1D(u_scale=u_scale) if kappa is None else Toy1D(kappa=np.asarray(kappa, float))
    rng = np.random.default_rng(4000 + seed); ana = t.populations()
    bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    analytic = np.asarray(ana["pops"], float)
    if kind == "single":
        nwalk = 1
        frames = [t.basin_of(wrap(t.langevin(np.array([wells[1]]), budget, 1.0, rng)[:, 0]), bnd).astype(int)]
    else:                                                            # 3 walkers, budget/3 each, one per basin
        nwalk = 3; per = budget // 3
        xs = t.langevin(wells[:3].copy(), per, 1.0, rng)
        frames = [t.basin_of(wrap(xs[:, k]), bnd).astype(int) for k in range(3)]
    pi_all, pit, cross = [], [[], [], []], [[], [], []]
    for Bs in stamps:
        pref = int(Bs // nwalk)
        dtr = [d[:min(pref, len(d))] for d in frames]
        allf = np.concatenate(dtr) if dtr else np.zeros(0, int)
        pi = np.array([np.mean(allf == b) for b in range(3)]) if allf.size else np.full(3, np.nan)
        pi_all.append(pi.tolist())
        cc = np.zeros(3)
        for d in dtr:
            cc += _seg_crossings(d)
        for k, (a, b, _) in enumerate(PAIRS_IDX):
            Cp = np.zeros((2, 2))
            for d in dtr:
                s = d[(d == a) | (d == b)]
                if s.size > LAG:
                    s2 = (s == b).astype(int); np.add.at(Cp, (s2[:-LAG], s2[LAG:]), 1.0)
            pit[k].append(_pair_its(Cp, LAG)); cross[k].append(float(cc[k]))
    return dict(budget=list(map(int, stamps)), pi=pi_all, tv=[_tv(p, analytic) for p in pi_all],
                pair_its=[list(p) for p in pit], cross=[list(c) for c in cross])


def rest2_remd(seed, T_replica, s_list, exch=100, u_scale=1.0, kappa=None):
    """REST2 replica exchange: `len(s_list)` replicas at scales s (slot 0 = cold, s=1); Metropolis exchange of
    adjacent slots every `exch` steps. Returns the s=1-slot basin sequence (the cold-ensemble sample) and the
    exchange acceptance. Total force-evals = len(s_list)*T_replica. `u_scale` selects the toy (1.0=base);
    `kappa` selects a κ-retune toy (e.g. [70,70,30] = 3× regime) and overrides u_scale when set."""
    t = Toy1D(u_scale=u_scale) if kappa is None else Toy1D(kappa=np.asarray(kappa, float))
    rng = np.random.default_rng(7000 + seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    s = np.asarray(s_list, float); nrep = len(s)
    x = np.array([float(wells[k % len(wells)]) for k in range(nrep)])
    slot0 = []; nacc = natt = 0
    for w in range(int(T_replica // exch)):
        for k in range(nrep):
            seg = t.langevin(np.array([x[k]]), exch, s[k], rng)[:, 0]
            x[k] = float(wrap(np.array([seg[-1]]))[0])
            if k == 0:                                               # slot 0 carries s=1 (the cold ensemble)
                slot0.append(wrap(seg))
        for k in range(w % 2, nrep - 1, 2):                         # alternating adjacent-pair exchanges
            d = (s[k] - s[k + 1]) * (float(t.U_cold(np.array([x[k + 1]]))[0]) - float(t.U_cold(np.array([x[k]]))[0]))
            natt += 1
            if rng.random() < np.exp(-min(d, 700.0)):
                x[k], x[k + 1] = x[k + 1], x[k]; nacc += 1
    cold = np.concatenate(slot0) if slot0 else np.zeros(0)
    return t.basin_of(cold, bnd).astype(int), (nacc / max(natt, 1))


def remd_pergen(seed, budget, stamps, s_list, u_scale=1.0, kappa=None):
    """REST2-REMD evaluated at the same cumulative-budget timestamps as BAIS. Total investment = N_replica*T_replica,
    so at total budget B_s each replica has run B_s/N_replica steps and the s=1 slot has that many frames. Populations
    are the reference; the s=1-slot pairwise ITS/crossings are exchange-ACCELERATED (not the physical cold rate).
    `u_scale` selects the toy (1.0=base); `kappa` selects a κ-retune toy and overrides u_scale when set."""
    nrep = len(s_list)
    tref = Toy1D(u_scale=u_scale) if kappa is None else Toy1D(kappa=np.asarray(kappa, float))
    analytic = np.asarray(tref.populations()["pops"], float)
    d, _ = rest2_remd(seed, budget // nrep, s_list, u_scale=u_scale, kappa=kappa)  # s=1-slot basins to full budget
    pi_all, pit, cross = [], [[], [], []], [[], [], []]
    for Bs in stamps:
        dd = d[:min(int(Bs // nrep), len(d))]
        pi = np.array([np.mean(dd == b) for b in range(3)]) if dd.size else np.full(3, np.nan)
        pi_all.append(pi.tolist())
        cc = _seg_crossings(dd) if dd.size > 1 else np.zeros(3)
        for k, (a, b, _) in enumerate(PAIRS_IDX):
            Cp = np.zeros((2, 2)); s2 = dd[(dd == a) | (dd == b)]
            if s2.size > LAG:
                sr = (s2 == b).astype(int); np.add.at(Cp, (sr[:-LAG], sr[LAG:]), 1.0)
            pit[k].append(_pair_its(Cp, LAG)); cross[k].append(float(cc[k]))
    return dict(budget=list(map(int, stamps)), pi=pi_all, tv=[_tv(p, analytic) for p in pi_all],
                pair_its=[list(p) for p in pit], cross=[list(c) for c in cross])


def _interp(grid, xs, vals):
    xs = np.asarray(xs, float); vals = np.asarray(vals, float)
    m = np.isfinite(vals) & np.isfinite(xs)
    if m.sum() < 2:
        return np.full(len(grid), np.nan)
    xs, vals = xs[m], vals[m]; o = np.argsort(xs); xs, vals = xs[o], vals[o]
    out = np.interp(grid, xs, vals, left=np.nan, right=vals[-1])
    out[grid < xs[0]] = np.nan
    return out


def run(fast=False, nseed=3, n_fwd=100, hard=False, mid3x=False):
    budget = 400_000 if fast else 1_500_000
    seeds = list(range(2 if fast else nseed))
    # UNIFIED regime rule: κ-retune barrier height (populations PRESERVED [0.25,0.42,0.33]); every regime shares the
    # s_hot=0.01 √s-square AIS ladder AND the √s-square 4-replica REMD reference. base (κ=None), 3× (κ=[70,70,30]),
    # 5× (κ=[114,114,45]).
    kappa = HARD5X_KAPPA if hard else (MID3X_KAPPA if mid3x else None)
    u_scale    = 1.0
    ais_ladder = AIS_LADDER
    remd_s     = REMD_S
    tag        = "_hard" if hard else ("_mid3x" if mid3x else "")
    reg_lbl    = "5x-barrier κ-retune" if hard else ("3x-barrier κ-retune" if mid3x else "base")
    analytic = np.asarray((Toy1D(kappa=kappa) if kappa is not None else Toy1D()).populations()["pops"], float)
    data = {m: [] for m in METHODS}
    for s in seeds:
        rb = bais_protocol_run(s, budget, hot_steps=10000, cold_chunk=10000, n_fwd=n_fwd, pergen_full=True,
                               u_scale=u_scale, ais_ladder=ais_ladder, kappa=kappa)
        st, cr, pit = rb["pergen_budget"], rb["pergen_cross"], rb["pergen_pair_its"]
        data["fixed-π BAIS"].append(_bais_record(st, rb["pergen_pi"], cr, pit, analytic))
        rl = bais_protocol_run(s, budget, hot_steps=10000, cold_chunk=10000, n_fwd=n_fwd, pergen_full=True,
                               leq_filter=True, leq_cut=180, u_scale=u_scale, ais_ladder=ais_ladder, kappa=kappa)
        data["BAIS LEQ-only"].append(_bais_record(rl["pergen_budget"], rl["pergen_pi"],
                                                  rl["pergen_cross"], rl["pergen_pair_its"], analytic))
        data["multi-walker"].append(walker_pergen(s, budget, st, "multi", u_scale=u_scale, kappa=kappa))
        data["single-walker"].append(walker_pergen(s, budget, st, "single", u_scale=u_scale, kappa=kappa))
        data["REMD (s-ladder)"].append(remd_pergen(s, budget, st, remd_s, u_scale=u_scale, kappa=kappa))  # N_rep*T_rep
        print(f"  seed {s}: {len(st)} gens -> {st[-1] if st else 0:,} "
              f"({reg_lbl}, N_AIS={n_fwd}, {len(remd_s)} REMD)", file=sys.stderr)

    grid = np.geomspace(80_000, budget, 22)
    agg = {}
    for m, runs in data.items():
        tv = np.nanmedian([_interp(grid, r["budget"], r["tv"]) for r in runs], 0)
        pi_b = [np.nanmedian([_interp(grid, r["budget"], [row[b] for row in r["pi"]]) for r in runs], 0) for b in range(3)]
        err = [np.abs(pi_b[b] - analytic[b]) for b in range(3)]
        pit_k = [np.nanmedian([_interp(grid, r["budget"], r["pair_its"][k]) for r in runs], 0) for k in range(3)]
        cr_k = [np.nanmedian([_interp(grid, r["budget"], r["cross"][k]) for r in runs], 0) for k in range(3)]
        agg[m] = dict(tv=tv.tolist(), pi=[p.tolist() for p in pi_b], err=[e.tolist() for e in err],
                      pair_its=[p.tolist() for p in pit_k], cross=[c.tolist() for c in cr_k])
    kin = (Toy1D(kappa=kappa) if kappa is not None else Toy1D()).smoluchowski_kinetics()
    pair_true = [float(kin["t_A1A2"]), float(kin["t_AB"]), float(kin["t_AB"])]   # A1-A2, A1-B(≈AB), A2-B(≈AB)
    payload = dict(grid=grid.tolist(), agg=agg, methods=METHODS, pair_true=pair_true, n_fwd=n_fwd,
                   n_remd=len(remd_s), hard=hard, mid3x=mid3x, pair_names=[p[2] for p in PAIRS_IDX],
                   analytic=analytic.tolist(), budget=budget, seeds=seeds)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"bais_pergen_convergence{tag}_toy.json").write_text(json.dumps(payload, indent=1))
    if mid3x:
        subtitle = (f"3$\\times$-barrier $\\kappa$-retune toy (pops preserved [0.25,0.42,0.33]), fixed-$\\pi$ BAIS "
                    f"(N_AIS={n_fwd}/gen, all-frames and LEQ), walker baselines, and REST2-REMD ({len(remd_s)} replicas)")
    elif hard:
        subtitle = (f"5$\\times$-barrier $\\kappa$-retune toy (pops preserved [0.25,0.42,0.33]), fixed-$\\pi$ BAIS "
                    f"(N_AIS={n_fwd}/gen, all-frames and LEQ), walker baselines, and REST2-REMD ({len(remd_s)} replicas)")
    else:
        subtitle = (f"base toy, fixed-$\\pi$ BAIS (N_AIS={n_fwd}/gen, all-frames and LEQ), walker baselines, "
                    f"and REST2-REMD ({len(remd_s)} replicas)")
    make_figure(payload, methods=METHODS, fname=f"fig_bais_pergen_convergence_fixedpi{tag}_toy.png",
                subtitle=subtitle)
    return payload


def make_figure(P, methods=None, fname="fig_bais_pergen_convergence_toy.png", subtitle=""):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    grid = np.array(P["grid"]); names = P["pair_names"]; ptrue = P["pair_true"]; anal = np.array(P["analytic"])
    methods = methods if methods is not None else P["methods"]
    nrow = len(methods)
    # common population y-limit that fits every curve (incl. a single walker trapped at π≈1) and the analytic
    pmax = max([float(np.nanmax(P["agg"][m]["pi"])) for m in methods] + [float(np.nanmax(anal))])
    ymax_pop = max(0.56, 1.05 * pmax)
    fig, ax = plt.subplots(nrow, 4, figsize=(19.5, 2.5 * nrow), sharex=True, squeeze=False)
    L, R, Bm, Tm = 0.115, 0.995, 0.055, 0.915
    fig.subplots_adjust(left=L, right=R, bottom=Bm, top=Tm, wspace=0.34, hspace=0.30)
    for i, m in enumerate(methods):
        A = P["agg"][m]
        # (col 0) per-basin populations -> analytic
        a = ax[i, 0]
        for b, nm in enumerate(BNAMES):
            a.plot(grid, A["pi"][b], "-o", color=BCOL[nm], ms=3.5, label=f"$\\pi_{{{nm}}}$")
            a.axhline(anal[b], ls="--", color=BCOL[nm], lw=1.0, alpha=0.5)
        a.set_xscale("log"); a.set_ylim(0, ymax_pop); a.set_ylabel("population $\\pi_i$"); a.grid(alpha=0.3, which="both")
        # (col 1) per-basin error |pi_i - analytic|
        a = ax[i, 1]
        for b, nm in enumerate(BNAMES):
            a.plot(grid, np.maximum(A["err"][b], 1e-3), "-o", color=BCOL[nm], ms=3.5, label=nm)
        a.set_xscale("log"); a.set_yscale("log"); a.set_ylabel("$|\\pi_i-\\pi_i^{\\mathrm{true}}|$"); a.grid(alpha=0.3, which="both")
        # (col 2) pairwise ITS
        a = ax[i, 2]
        for k in range(3):
            a.plot(grid, A["pair_its"][k], "-o", color=PCOL[k], ms=3.5, label=names[k])
            a.axhline(ptrue[k], ls="--", color=PCOL[k], lw=1.0, alpha=0.55)
        a.set_xscale("log"); a.set_yscale("log"); a.set_ylim(2e2, 1e5); a.set_ylabel("pairwise ITS (frames)"); a.grid(alpha=0.3, which="both")
        # (col 3) cumulative barrier crossings
        a = ax[i, 3]
        for k in range(3):
            a.plot(grid, np.maximum(A["cross"][k], 0.5), "-o", color=PCOL[k], ms=3.5, label=names[k])
        a.set_xscale("log"); a.set_yscale("log"); a.set_ylabel("cumulative crossings"); a.grid(alpha=0.3, which="both")
        if i == 0:
            ax[0, 0].set_title("per-basin $\\pi_i\\to$ analytic (dashed)"); ax[0, 0].legend(fontsize=7, ncol=3, loc="upper right")
            ax[0, 1].set_title("per-basin error $|\\pi_i-\\pi_i^{\\mathrm{true}}|$"); ax[0, 1].legend(fontsize=7, ncol=3, loc="upper right")
            ax[0, 2].set_title("pairwise ITS (dashed = analytic)"); ax[0, 2].legend(fontsize=7, ncol=3, loc="lower right")
            ax[0, 3].set_title("cumulative barrier crossings"); ax[0, 3].legend(fontsize=7, ncol=3, loc="upper left")
        yc = Tm - (i + 0.5) * (Tm - Bm) / nrow                        # method label at the left edge (not clipped)
        fig.text(0.018, yc, m, rotation=90, va="center", ha="center", fontsize=11, fontweight="bold")
    for a in ax[-1, :]:
        a.set_xlabel("cumulative budget (per-generation timestamp)")
    fig.suptitle(f"Per-generation convergence (1-D toy) — {subtitle}; median over {len(P['seeds'])} seeds, "
                 "walkers at the same timestamps.\nColumns: per-basin populations · per-basin error · pairwise ITS · "
                 "cumulative barrier crossings.", fontsize=10.5)
    fig.savefig(OUT / fname, dpi=160); plt.close(fig)
    print(f"  wrote {OUT / fname}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv, hard="--hard" in sys.argv, mid3x="--mid3x" in sys.argv)
