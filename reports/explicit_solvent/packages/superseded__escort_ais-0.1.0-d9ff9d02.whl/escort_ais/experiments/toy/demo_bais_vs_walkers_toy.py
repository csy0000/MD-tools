#!/usr/bin/env python3
"""demo_bais_vs_walkers_toy.py — BAIS vs single-walker vs multi-walker on the 1D toy, matched budget.

Protocol, total budget B = 1,200,000 force-evaluations:
  * BAIS (no burn-in): the validated NEW protocol (see demo_bais_protocol_convergence_toy) — a SINGLE hot walker
    (3k steps/gen) + 100 forward AIS shots (5 steps) + ONE cold walker per occupied basin (3k steps each; seed
    empty basins, terminate the shorter-residence duplicate) + reverse AIS COUNT-MATCHED to the forward landings.
    Populations from endpoint-restricted BAR; kinetics from the fixed-pi reversible MSM on the cold reservoir.
  * single-walker: ONE cold trajectory of B steps, started in A1 / A2 / B (three variants).
  * multi-walker: 3 cold walkers of B/3 steps each, seeded one per basin.
Metrics: population TV to analytic; slow-ITS (A<->B) relative error. Median over seeds.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_vs_walkers_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.bais import basin_free_energies, estimate_bais, estimate_msm_free_pi
from escort_ais.methods.state_detect import detect_kstar
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import (
    bais_protocol_run, HARD5X_KAPPA, MID3X_KAPPA, AIS_LADDER)

ROOT = project_root()
OUT = ROOT / "results/toy"
B_TOTAL = 1_200_000
LAG = 500


def _tv(p, q):
    p = np.asarray(p, float); q = np.asarray(q, float)
    return 0.5 * float(np.abs(p / p.sum() - q / q.sum()).sum())


def count_matrix(dtrajs, nb, lag):
    C = np.zeros((nb, nb))
    for d in dtrajs:
        d = np.asarray(d, int)
        if len(d) > lag:
            np.add.at(C, (d[:-lag], d[lag:]), 1.0)
    return C


def _toy(u_scale=1.0, kappa=None):
    t = Toy1D(u_scale=u_scale) if kappa is None else Toy1D(kappa=np.asarray(kappa, float))
    ana = t.populations()
    bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    return t, ana, bnd, wells, int(ana["n_basins"]), np.array(ana["pops"]), float(t.smoluchowski_kinetics()["t_AB"])


def bais_run(seed, B, u_scale=1.0, ais_ladder=None, kappa=None):
    """Matched-budget BAIS run using the validated NEW protocol: a SINGLE hot walker; ONE cold walker per occupied
    basin (seed empty basins, terminate the shorter-residence duplicate); reverse AIS COUNT-MATCHED to the forward
    landings per basin. Delegates to the single shared implementation in demo_bais_protocol_convergence_toy, so
    this head-to-head uses exactly the protocol validated there (rather than a divergent copy). `u_scale`/`ais_ladder`
    select the 5x toy + log ladder; `kappa` selects a κ-retune toy (e.g. [70,70,30] = 3× regime)."""
    r = bais_protocol_run(seed, B, hot_steps=10000, cold_chunk=10000, u_scale=u_scale, ais_ladder=ais_ladder,
                          kappa=kappa)
    return dict(pop_tv=r["pop_tv"], its=r["its"], its_err=r["its_relerr"],
                n_cold=r["n_seeded"], budget=r["budget"], n_iter=r["n_iter"])


def single_run(seed, B, start_basin, u_scale=1.0, kappa=None):
    t, ana, bnd, wells, nb, pops, its_true = _toy(u_scale, kappa)
    x = wrap(t.langevin(np.array([wells[start_basin]]), B, 1.0, np.random.default_rng(seed))[:, 0])
    d = t.basin_of(x, bnd).astype(int)
    pi = np.array([np.mean(d == b) for b in range(nb)])
    its = estimate_msm_free_pi(count_matrix([d], nb, LAG), lag=LAG)["its"]
    return dict(pop_tv=_tv(pi, pops), its=its, its_err=_relerr(its, its_true), pi=pi.tolist())


def multi_run(seed, B, n=3, u_scale=1.0, kappa=None):
    t, ana, bnd, wells, nb, pops, its_true = _toy(u_scale, kappa)
    per = B // n
    x = t.langevin(wells[:n].copy(), per, 1.0, np.random.default_rng(seed))              # 3 walkers, B/3 each
    dtr = [t.basin_of(wrap(x[:, k]), bnd).astype(int) for k in range(n)]
    pi = np.array([np.mean([np.mean(d == b) for d in dtr]) for b in range(nb)])
    its = estimate_msm_free_pi(count_matrix(dtr, nb, LAG), lag=LAG)["its"]
    return dict(pop_tv=_tv(pi, pops), its=its, its_err=_relerr(its, its_true), pi=pi.tolist())


def _relerr(x, x0):
    return abs(x - x0) / x0 if (x is not None and np.isfinite(x)) else np.nan


def run(fast=False, nseed=4, hard=False, mid3x=False):
    B = 300_000 if fast else B_TOTAL
    seeds = list(range(2 if fast else nseed))
    # UNIFIED regime rule: barrier height via κ-retune (populations ALWAYS preserved [0.25,0.42,0.33]); every regime
    # uses the SAME s_hot=0.01 hot ensemble and √s-square AIS ladder. base (κ=None), 3× (κ=[70,70,30]), 5× (κ=[114,114,45]).
    kappa = HARD5X_KAPPA if hard else (MID3X_KAPPA if mid3x else None)
    u_scale = 1.0
    ais_ladder = AIS_LADDER
    tag = "_hard" if hard else ("_mid3x" if mid3x else "")
    # basin labels by centre: B(-120), A1(60), A2(120)
    _, ana, *_ = _toy(u_scale, kappa)
    ctr = np.array(ana["well_centers_deg"]); order = {int(np.argmin(ctr)): "B"}
    a = [i for i in range(3) if i != np.argmin(ctr)]
    order[a[0] if ctr[a[0]] < ctr[a[1]] else a[1]] = "A1"; order[a[1] if ctr[a[1]] > ctr[a[0]] else a[0]] = "A2"
    methods = {"BAIS": lambda s: bais_run(s, B, u_scale=u_scale, ais_ladder=ais_ladder, kappa=kappa),
               "single-A1": lambda s: single_run(s, B, [k for k, v in order.items() if v == "A1"][0], u_scale=u_scale, kappa=kappa),
               "single-A2": lambda s: single_run(s, B, [k for k, v in order.items() if v == "A2"][0], u_scale=u_scale, kappa=kappa),
               "single-B":  lambda s: single_run(s, B, [k for k, v in order.items() if v == "B"][0], u_scale=u_scale, kappa=kappa),
               "multi(3x)": lambda s: multi_run(s, B, u_scale=u_scale, kappa=kappa)}
    res = {m: [f(s) for s in seeds] for m, f in methods.items()}
    for m in methods:
        pt = [r["pop_tv"] for r in res[m]]; ie = [np.clip(r["its_err"], None, 2.0) for r in res[m]]
        extra = f" n_cold={res[m][0].get('n_cold')} iters={res[m][0].get('n_iter')}" if m == "BAIS" else ""
        print(f"  {m:10} pop-TV={np.median(pt):.3f}  ITS-err={np.nanmedian(ie):.3f}{extra}", file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"bais_vs_walkers{tag}_toy.json").write_text(
        json.dumps(dict(B=B, seeds=seeds, res=res, hard=hard, mid3x=mid3x), indent=1))
    make_figure(res, B, tag=tag, hard=hard, mid3x=mid3x)


def make_figure(res, B, tag="", hard=False, mid3x=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    methods = list(res)
    cols = {"BAIS": "#2a7f2a", "single-A1": "#9a6", "single-A2": "#6a9", "single-B": "#7a4fb0", "multi(3x)": "#b03030"}
    fig, ax = plt.subplots(1, 2, figsize=(12.5, 4.6))
    for a, key, ylab, clip in [(ax[0], "pop_tv", "population TV to analytic", None),
                               (ax[1], "its_err", "slow-ITS relative error", 2.0)]:
        med = [np.nanmedian([np.clip(r[key], None, clip) if clip else r[key] for r in res[m]]) for m in methods]
        lo = [np.nanmin([np.clip(r[key], None, clip) if clip else r[key] for r in res[m]]) for m in methods]
        hi = [np.nanmax([np.clip(r[key], None, clip) if clip else r[key] for r in res[m]]) for m in methods]
        x = np.arange(len(methods))
        a.bar(x, med, color=[cols[m] for m in methods], yerr=[np.array(med) - lo, np.array(hi) - med],
              capsize=3, alpha=0.9)
        a.set_xticks(x); a.set_xticklabels(methods, rotation=20, ha="right", fontsize=9)
        a.set_ylabel(ylab); a.grid(axis="y", alpha=0.3)
    ax[0].set_title("(1) free energy — basin populations")
    ax[1].set_title("(2) kinetics — A↔B slow timescale")
    # A↔B kinetics are frozen on both hardened toys (5×: 35 kT; 3× κ-retune: 21.4 kT): no direct cold crossings in
    # any feasible budget, so the A↔B slow-ITS is honestly unresolved for every direct-MD method (any finite bar is
    # the intra-A A1↔A2 mode, not A↔B). The 5× toy has zero finite ITS; the 3× toy resolves only A1↔A2, so we blank
    # panel 2 for both hardened regimes rather than plot a mislabelled bar.
    if mid3x or hard or all(not np.isfinite(r["its_err"]) for m in methods for r in res[m]):
        bar_kT = "$21.4\\,k_BT$" if mid3x else ("$33\\,k_BT$" if hard else "$7.1\\,k_BT$")
        for coll in list(ax[1].containers):
            coll.remove()
        ax[1].set_ylim(0, 1)
        ax[1].text(0.5, 0.5, f"$A\\!\\leftrightarrow\\!B$ unresolved for all methods\n(no cold crossings at {bar_kT})",
                   transform=ax[1].transAxes, ha="center", va="center", fontsize=11, color="#666")
    toy = ("3$\\times$ $\\kappa$-retune toy ($\\kappa{=}[70,70,30]$)" if mid3x else
           ("$5\\times$ $\\kappa$-retune toy ($\\kappa{=}[114,114,45]$)" if hard else "1-D toy"))
    switch = "10-rung $\\sqrt{s}$-AIS $s{=}0.01{\\to}1$"
    fig.suptitle(f"BAIS vs single-/multi-walker on the {toy} — matched budget $K={B:,}$ force-evals\n"
                 f"BAIS: 1 hot walker (10k) + one cold walker per occupied basin (10k) + {switch} + "
                 f"count-matched reverse. Bars = median; whiskers = min–max.", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.9])
    fig.savefig(OUT / f"fig_bais_vs_walkers{tag}_toy.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / ('fig_bais_vs_walkers' + tag + '_toy.png')}", file=sys.stderr)


if __name__ == "__main__":
    if "--figure-only" in sys.argv:
        d = json.load(open(OUT / "bais_vs_walkers_toy.json"))
        make_figure(d["res"], d["B"], hard=d.get("hard", False), mid3x=d.get("mid3x", False))
    else:
        run(fast="--fast" in sys.argv, hard="--hard" in sys.argv, mid3x="--mid3x" in sys.argv)
