#!/usr/bin/env python3
"""demo_mfep_convergence_toy.py — convergence of the MFEP (free-energy profile) between the 3 states, with vs
without bAIS, on the 1D toy.

In 1D the minimum-free-energy path through the states IS the free-energy profile F(θ) = U_cold(θ): the three
states are its minima, and the *barriers between them* are its maxima. The population study (demo_bais_convergence)
already covered the minima (state free energies); this adds the barriers — exactly where bAIS should help most,
since cold MD rarely visits a barrier top.

Run in the SAMPLABLE regime (A↔B lowered to ~7.1 kT, A1↔A2 ~2.9 kT — same as demo_kinetics_toy) so that the
"without bAIS" MFEP genuinely CONVERGES (cold MD does cross, slowly) and we can compare convergence RATES rather
than a flat failure. Compared:
  * WITHOUT bAIS — F(θ) = −kT ln P_cold(θ) from the accumulating cold MD (10 M, checkpointed every 0.5 M). Bins the
    cold trajectory never visits (barrier tops, the minor basin early on) are undefined → the profile is
    incomplete until enough rare crossings fill it in.
  * WITH bAIS+US — a connected flat-bottom umbrella-sampling STRING tiling θ (windows on the barriers too) gives the
    profile SHAPE including barrier tops; the between-state offsets (well depths) are anchored by per-basin endpoint
    BAR from only 0.1 M hot + forward/reverse AIS (N_NES ∈ {100, 1000, 5000}, 10 λ-windows × 10 MD steps each way).
    Independent of cold-MD length → converged from the first checkpoint.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_mfep_convergence_toy
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])                                   # samplable regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)


def cold_profile(theta, edges, kT):
    """F(θ) = −kT ln P from a histogram of cold samples; unvisited bins → NaN, then min → 0."""
    h, _ = np.histogram(theta, bins=edges)
    F = np.full(len(h), np.nan); m = h > 0
    F[m] = -kT * np.log(h[m] / h[m].sum())
    if m.any():
        F -= np.nanmin(F)
    return F, float(m.mean())


def us_string(t, centers, hw, us_n, rng, grid, edges, k=250.0, walkers=12, burn=600):
    """Reconstruct F(θ) SHAPE from a connected flat-bottom US string, chain-stitched in center order.

    Each box umbrella samples P_cold restricted to [center±hw] (flat-bottom = no bias inside), so −kT ln P recovers
    F(θ) up to a per-window constant; consecutive overlapping windows are aligned by the median offset."""
    NG = len(grid); F = np.full(NG, np.nan)
    for c in np.sort(centers):
        s = t.us_sample(c, hw, us_n, rng, k=k, burn=burn, walkers=walkers)
        h, _ = np.histogram(s, bins=edges)
        f = np.full(NG, np.nan); m = h > 0
        f[m] = -t.kT * np.log(h[m] / h[m].sum())
        f[np.abs(wrap(grid - c)) > hw * 1.02] = np.nan               # trust only the flat (in-box) region
        ov = (~np.isnan(f)) & (~np.isnan(F))
        o = float(np.median(F[ov] - f[ov])) if ov.sum() >= 2 else 0.0
        fc = f + o
        new = (~np.isnan(fc)) & np.isnan(F); F[new] = fc[new]
        F[ov] = 0.5 * (F[ov] + fc[ov])
    return F - np.nanmin(F)


def bais_offsets(t, hot, cold_th, cold_bas, bnd, nb, N, nes_win, nes_md, rng, n_rep=6):
    """Per-basin cold free energies (well depths, global-min 0) from forward/reverse AIS + endpoint BAR, averaged
    over n_rep AIS draws. pi_cold_b ∝ exp(−ΔF_b) (inf-padded BAR already folds in π_hot)."""
    depths = []
    for _ in range(n_rep):
        xh = hot[rng.integers(0, len(hot), N)]
        land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=nes_win, freq=nes_md, rng=rng)
        lb = t.basin_of(land, bnd).astype(int); Wf = -lwf; dF = np.zeros(nb); ok = True
        for b in range(nb):
            n_rev = int((lb == b).sum()); pool = cold_th[cold_bas == b]
            if n_rev == 0 or len(pool) == 0:
                ok = False; break
            starts = pool[rng.integers(0, len(pool), n_rev)]
            _, lwr = t.ais_switch(starts, 1.0, t.s_hot, m_steps=nes_win, freq=nes_md, rng=rng)
            dF[b], _ = solve_bar_with_infinite_works(np.where(lb == b, Wf, np.inf), -lwr,
                                                     n_f_total=len(Wf), n_r_total=n_rev)
        if ok:
            pi = np.exp(-(dF - dF.min())); pi /= pi.sum()
            d = -t.kT * np.log(pi); depths.append(d - d.min())
    return (np.mean(depths, 0), np.std(depths, 0)) if depths else (None, None)


def combine_mfep(F_shape, grid, bnd, nb, depths):
    """bAIS+US MFEP: US shape re-zeroed WITHIN each basin (well bottom → 0) + the BAR between-state depth."""
    F = np.full(len(grid), np.nan)
    bas = _basin_of(grid, bnd, nb)
    for b in range(nb):
        m = bas == b
        if m.any() and np.isfinite(F_shape[m]).any():
            F[m] = (F_shape[m] - np.nanmin(F_shape[m])) + depths[b]
    return F - np.nanmin(F)


def _basin_of(theta, bnd, nb):
    b = np.sort(bnd)
    return (np.searchsorted(b, wrap(theta), side="right") % b.size).astype(int)


def run(seed=0, cold_total=10_000_000, checkpoint=500_000, n_walkers=5, hot_steps=100_000, hot_walkers=10,
        ais_budgets=(100, 1000, 5000), nes_win=10, nes_md=10, ng=120, us_spacing_deg=10.0, us_hw_deg=12.0,
        us_n=3000):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    nb = ana["n_basins"]
    grid, edges = _grid(ng)
    F_true = t.U_cold(grid); F_true -= F_true.min()                  # analytic MFEP (ground truth)
    # --- transition barriers on the MFEP: A1↔A2 (max between wells 60/120) + the LOWER A↔B barrier (path uses it) ---
    _, maxs = t.extrema(); maxs = np.sort(maxs); mh = t.U_cold(maxs) - t.U_cold(grid).min()
    a12_deg = 90.0
    is_a12 = (np.degrees(maxs) > 60) & (np.degrees(maxs) < 120)
    a12_ang = float(maxs[is_a12][np.argmax(is_a12[is_a12])]) if is_a12.any() else np.radians(a12_deg)
    ab_cands = maxs[~is_a12]; ab_h = mh[~is_a12]
    ab_ang = float(ab_cands[np.argmin(ab_h)])                        # lower A↔B barrier (the one the MFEP crosses)
    barriers = {"A1_A2": a12_ang, "A_B": ab_ang}
    bidx = {k: int(np.argmin(np.abs(wrap(grid - a)))) for k, a in barriers.items()}
    barr_true = {k: round(float(F_true[i]), 2) for k, i in bidx.items()}
    # --- analytic between-state well depths (global-min 0) for the offset-accuracy metric ---
    depths_true = -t.kT * np.log(ana["pops"]); depths_true -= depths_true.min()

    # --- cold reservoir (10 M, walkers seeded across wells) ---
    per_w = cold_total // n_walkers
    cold = t.langevin(wells[np.arange(n_walkers) % nb], per_w, 1.0, rng)
    cold_th = [wrap(cold[:, k]) for k in range(n_walkers)]

    # --- bAIS+US (fixed; independent of cold length): US-string SHAPE + BAR between-state depths ---
    centers = np.radians(np.arange(-180.0 + us_spacing_deg / 2, 180.0, us_spacing_deg))
    F_shape = us_string(t, centers, np.radians(us_hw_deg), us_n, rng, grid, edges)
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, t.s_hot, rng)
    hot = wrap(hraw[max(1, (hot_steps // hot_walkers) // 20):].reshape(-1))
    cth_all = np.concatenate(cold_th); cbas_all = t.basin_of(cth_all, bnd).astype(int)
    F_bais, bais_rms, bais_extra = {}, {}, {}
    for N in ais_budgets:
        depths, _ = bais_offsets(t, hot, cth_all, cbas_all, bnd, nb, N, nes_win, nes_md, rng)
        Fb = combine_mfep(F_shape, grid, bnd, nb, depths)
        F_bais[N] = Fb
        bais_rms[N] = round(float(np.sqrt(np.nanmean((Fb - F_true) ** 2))), 3)
        bais_extra[N] = dict(
            barrier_err={k: round(float(Fb[i] - F_true[i]), 3) for k, i in bidx.items()},
            offset_rms=round(float(np.sqrt(np.mean((depths - depths_true) ** 2))), 3))

    # --- bAIS+US convergence: sweep the US sampling budget (fixed BAR offsets at N=1000) ---
    depths_ref, _ = bais_offsets(t, hot, cth_all, cbas_all, bnd, nb, 1000, nes_win, nes_md, rng)
    us_walkers, us_burn = 12, 600
    overhead = hot_steps + 2 * 1000 * nes_win * nes_md              # hot + fwd+rev AIS (N=1000, single draw)
    bais_curve = []
    for un in (10, 30, 100, 300, 1000, 3000):
        Fsh = us_string(t, centers, np.radians(us_hw_deg), un, rng, grid, edges, walkers=us_walkers, burn=us_burn)
        Fb = combine_mfep(Fsh, grid, bnd, nb, depths_ref)
        rms = float(np.sqrt(np.nanmean((Fb - F_true) ** 2)))
        budget = overhead + len(centers) * us_walkers * (us_burn + un)
        bais_curve.append(dict(budget=int(budget), us_n=int(un), rms=round(rms, 3)))

    # --- without bAIS: cold-MD MFEP per checkpoint (log-spaced, 10^2 → 10^7) ---
    checkpoints = sorted(set(np.geomspace(100, cold_total, 24).astype(int).tolist())
                         | {500_000, 2_000_000, cold_total})
    prof_at = {500_000, 2_000_000, cold_total}
    rows = []; cold_profiles = {}
    for T in checkpoints:
        cf = max(1, T // n_walkers)
        cth = np.concatenate([x[:cf] for x in cold_th])
        Fc, cov = cold_profile(cth, edges, t.kT)
        defined = ~np.isnan(Fc)
        rms = float(np.sqrt(np.nanmean((Fc[defined] - F_true[defined]) ** 2))) if defined.any() else np.nan
        berr = {k: (round(float(Fc[i] - F_true[i]), 3) if defined[i] else None) for k, i in bidx.items()}
        rows.append(dict(cold_steps=int(T), coverage=round(cov, 3), rms_defined=round(rms, 3), barrier_err=berr))
        if T in prof_at:
            cold_profiles[T] = Fc

    res = dict(seed=seed, regime="samplable (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)",
               transition_barriers_deg={k: round(float(np.degrees(a)), 1) for k, a in barriers.items()},
               transition_barriers_kT=barr_true, global_max_barrier_kT=round(float(F_true.max()), 2),
               hot_steps=hot_steps, nes=f"{nes_win}win x {nes_md}MD", ais_budgets=list(ais_budgets),
               bais_us_mfep_rms=bais_rms, bais_us_detail=bais_extra, bais_us_curve=bais_curve,
               cold_checkpoints=rows)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "mfep_convergence_toy.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({"transition_barriers_kT": barr_true, "global_max_barrier_kT": res["global_max_barrier_kT"],
                      "bais_us_mfep_rms": bais_rms, "bais_us_curve": bais_curve,
                      "cold_first": rows[0], "cold_final": rows[-1]}, indent=2))
    make_figure(grid, F_true, cold_profiles, F_bais, rows, ais_budgets, bais_rms, bais_extra,
                bais_curve, hot_steps, res)
    return res


def _grid(ng):
    edges = np.linspace(-np.pi, np.pi, ng + 1)
    return 0.5 * (edges[:-1] + edges[1:]), edges


def make_figure(grid, F_true, cold_profiles, F_bais, rows, ais_budgets, bais_rms, bais_extra,
                bais_curve, hot_steps, res):
    deg = np.degrees(grid)
    fig, ax = plt.subplots(1, 2, figsize=(15.5, 5.4))
    # (A) MFEP profiles
    ax[0].plot(deg, F_true, "k-", lw=2.5, label="analytic MFEP", zorder=5)
    greys = {k: g for k, g in zip(sorted(cold_profiles), ["0.75", "0.5", "0.3"])}
    for T, Fc in sorted(cold_profiles.items()):
        ax[0].plot(deg, Fc, "-", c=greys[T], lw=1.4, label=f"cold MD {T/1e6:.1f} M (no BAUS)")
    Nbest = ais_budgets[-1]
    ax[0].plot(deg, F_bais[Nbest], "-s", c="C2", ms=3, lw=1.4, label=f"BAUS, N_NES={Nbest}")
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("F(θ) (kT), min → 0"); ax[0].set_xlim(-180, 180)
    ax[0].set_title("MFEP profiles: cold MD leaves gaps at the barrier tops & the minor basin;\n"
                    "BAUS resolves the whole path from 0.1 M hot", fontsize=10)
    ax[0].legend(fontsize=7.5)
    # (B) convergence vs total simulation budget (log-log): cold MD AND bAIS+US both as curves
    cx = np.array([r["cold_steps"] for r in rows], float)
    ax[1].loglog(cx, [r["rms_defined"] for r in rows], "-o", c="k", lw=2, ms=4, label="cold MD (no BAUS)")
    bx = np.array([b["budget"] for b in bais_curve], float); brms = np.array([b["rms"] for b in bais_curve], float)
    ax[1].loglog(bx, brms, "-s", c="C2", lw=2, ms=6, label="BAUS (varying US budget)")
    for b in bais_curve:
        ax[1].annotate(f"US={b['us_n']}", (b["budget"], b["rms"]), fontsize=6, c="C2", ha="left", va="bottom")
    ax[1].set_xlim(10, 1e7); ax[1].set_xlabel("simulation budget (MD steps)")
    ax[1].set_ylabel("MFEP RMS error (kT)")
    axr = ax[1].twinx()
    axr.semilogx(cx, [r["coverage"] for r in rows], "-^", c="C0", alpha=0.5, ms=4, label="cold-MD θ coverage")
    axr.set_ylabel("cold-MD θ coverage (fraction)", color="C0"); axr.set_ylim(0, 1.02)
    axr.tick_params(axis="y", labelcolor="C0")
    ax[1].set_title("MFEP convergence vs budget: BAUS (green) resolves the FULL path (100% coverage) to "
                    "~0.3 kT;\ncold-MD RMS (over SAMPLED bins only) is lower but θ-coverage plateaus <1 — barrier "
                    "tops never resolved", fontsize=9.5)
    h1, l1 = ax[1].get_legend_handles_labels(); h2, l2 = axr.get_legend_handles_labels()
    ax[1].legend(h1 + h2, l1 + l2, fontsize=7.5, loc="lower left")
    fig.suptitle(f"MFEP (3-state free-energy profile) convergence — 1D toy, {res['regime']}; "
                 f"hot only {hot_steps/1e6:.1f} M, NES {res['nes']}", fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.94])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_mfep_convergence_toy.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_mfep_convergence_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
