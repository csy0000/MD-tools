#!/usr/bin/env python3
"""make_leq_toy_illustration.py — 4-well toy that illustrates the "sub-well residence <= T" selection rule.

A 1-D overdamped-Langevin model of ONE metastable basin with four SUB-WELLS. Three are mutually accessible
(crossable ~1 kT barriers = the real, connected basin) and the fourth is a kinetically ISOLATED TRAP (a
~4 kT barrier, tiny equilibrium weight) — the toy analogue of the cold-reservoir traps. Seeds are started
UNIFORMLY across the four wells (non-Boltzmann placement). Each seed either internally HOPS among the
connected wells (short longest sub-well residence R -> its time-average ~ the basin equilibrium) or sits
FROZEN in the trap (long R -> a spike the equilibrium barely has). Pooling the MIXING seeds (R <= T) recovers
equilibrium; pooling the FROZEN seeds (R > T) reproduces the trap/placement bias -> JS climbs.

Writes four figures to results/rgd/report/fig_leq_toy_*.png for docs/theory/leq_residence_rule.tex.

    conda activate escort-ais && python -m escort_ais.experiments.toy.make_leq_toy_illustration
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

OUT = Path(__file__).resolve().parents[2] / "results/rgd/report"
LN2 = float(np.log(2))

# --- model (kT = 1): equilibrium = 4-Gaussian mixture; well 3 is an isolated, low-weight trap -----------
MU = np.array([-1.6, 0.0, 1.6, 4.6])           # sub-well centers (well 3 = far, isolated trap)
SIG = 0.42                                      # sub-well width
W = np.array([0.44, 0.32, 0.22, 0.02])         # Boltzmann sub-well weights (trap weight tiny)
DT, TOTAL, GAMMA = 0.002, 6.0, 1.0             # Langevin step, total time per seed, friction
N_PER_WELL = 60                                 # seeds started at each well (uniform, non-Boltzmann placement)
T_STAR = 3.0                                    # residence threshold used for the "payoff" panel
T_LIST = np.array([1.0, 1.5, 2.0, 2.5, 3.0, 3.5])
BINS = np.linspace(-3.6, 6.2, 80)
CEN = 0.5 * (BINS[:-1] + BINS[1:])


def _g(x, m, s):
    return np.exp(-0.5 * ((x - m) / s) ** 2) / (s * np.sqrt(2 * np.pi))


def p_eq(x):
    return sum(w * _g(x, m, SIG) for w, m in zip(W, MU))


def U(x):
    return -np.log(p_eq(x))                     # potential of mean force (kT = 1)


def dU(x):
    return sum(w * _g(x, m, SIG) * (x - m) / SIG ** 2 for w, m in zip(W, MU)) / p_eq(x)


def js(p, q, e=1e-12):
    p = p + e; p = p / p.sum(); q = q + e; q = q / q.sum()
    m = 0.5 * (p + q)
    return float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))


def longest_residence(lab):
    best = cur = 1
    for i in range(1, len(lab)):
        cur = cur + 1 if lab[i] == lab[i - 1] else 1
        best = max(best, cur)
    return best * DT


def run():
    n = int(TOTAL / DT); c = np.sqrt(2 * DT / GAMMA); rng = np.random.default_rng(0)
    x0 = np.repeat(MU, N_PER_WELL).astype(float); N = len(x0)
    X = np.empty((N, n)); X[:, 0] = x0; x = x0.copy()
    for t in range(1, n):                       # vectorized over all seeds
        x = x - dU(x) * DT / GAMMA + c * rng.standard_normal(N); X[:, t] = x
    start = np.repeat(np.arange(4), N_PER_WELL)
    lab = np.argmin(np.abs(X[:, :, None] - MU[None, None, :]), axis=2)
    R = np.array([longest_residence(l) for l in lab])            # longest continuous sub-well residence
    REF = p_eq(CEN)                                             # equilibrium density on the pooling bins
    grid = np.linspace(-3.6, 6.2, 500); peq = p_eq(grid)

    def pool(mask):
        return np.histogram(X[mask].ravel(), BINS, density=True)[0] if mask.sum() else np.zeros_like(CEN)

    barr = [round(float(U((MU[i] + MU[i + 1]) / 2) - U(MU[i + 1])), 1) for i in range(3)]
    js_mix = [js(pool(R <= T), REF) for T in T_LIST]
    js_frz = [js(pool(R > T), REF) for T in T_LIST]
    print(f"[toy] barriers {barr} kT | trap seeds R>={R[start==3].min():.1f} | "
          f"JS keep-mix {js_mix} | keep-frozen {js_frz}")

    # ---------------------------------------------------------------- Fig 1: the model + the trap
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].plot(grid, U(grid), "k", lw=2)
    ax[0].set_ylim(U(grid).min() - 0.3, U(grid).min() + 6)
    ax[0].annotate("connected sub-wells\n(barriers ~1 $k_BT$: seeds hop)", (0.0, U(0.0) + 2.2),
                   ha="center", fontsize=8, color="C2")
    ax[0].annotate("isolated TRAP\n(~4 $k_BT$, tiny weight)", (4.6, U(4.6) + 0.5), ha="center",
                   fontsize=8, color="C3")
    ax[0].set_xlabel("sub-well coordinate  $x$"); ax[0].set_ylabel(r"$U(x)=-\ln P_{\rm eq}(x)$  [$k_BT$]")
    ax[0].set_title("(a) one basin: 3 connected sub-wells + 1 isolated trap")
    ax[1].plot(grid, peq, "C0", lw=2, label=r"$P_{\rm eq}(x)$")
    for m, w in zip(MU, W):
        ax[1].annotate(f"$w={w:.2f}$", (m, p_eq(m)), ha="center", va="bottom", fontsize=8)
    ax[1].set_xlabel("sub-well coordinate  $x$"); ax[1].set_ylabel(r"$P_{\rm eq}(x)$")
    ax[1].set_title("(b) equilibrium = Boltzmann mixture $\\sum_i w_i\\,g(x;\\mu_i,\\sigma)$"); ax[1].legend()
    fig.tight_layout(); fig.savefig(OUT / "fig_leq_toy_potential.png", dpi=140); plt.close(fig)

    # ---------------------------------------------------------------- Fig 2: mixing vs frozen seed
    i_mix = int(np.where(start < 3)[0][np.argmin(R[start < 3])])
    i_frz = int(np.where(start == 3)[0][np.argmax(R[start == 3])])
    tg = np.arange(n) * DT
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8), sharey=True)
    for a, i, name, col in [(ax[0], i_mix, "MIXING (connected wells)", "C2"),
                            (ax[1], i_frz, "FROZEN (trap)", "C3")]:
        a.plot(tg, X[i], lw=0.5, c=col)
        for m in MU:
            a.axhline(m, ls=":", c="0.8", lw=1)
        a.axhline(MU[3], ls="-", c="C3", lw=1, alpha=0.4)
        a.set_xlabel('time  $t$'); a.set_title(f"{name}:  longest residence $R={R[i]:.2f}$")
    ax[0].set_ylabel("sub-well coordinate  $x(t)$")
    fig.suptitle(r"A seed either HOPS among connected sub-wells (small $R$) or sits FROZEN in the trap "
                 r"(large $R\approx$ run length)", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.95]); fig.savefig(OUT / "fig_leq_toy_trajectories.png", dpi=140)
    plt.close(fig)

    # ---------------------------------------------------------------- Fig 3: residence dist + per-seed P_s
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].hist(R[start < 3], bins=np.linspace(0, 6, 31), color="C2", alpha=0.7, label="connected-well seeds")
    ax[0].hist(R[start == 3], bins=np.linspace(0, 6, 31), color="C3", alpha=0.7, label="trap seeds")
    ax[0].axvline(T_STAR, c="C1", lw=2, label=f"threshold $T={T_STAR:.0f}$")
    ax[0].set_xlabel("longest continuous sub-well residence  $R_s$")
    ax[0].set_ylabel("number of seeds"); ax[0].set_title("(a) $R_s$: mixing (small) vs frozen/trap (large)")
    ax[0].legend(fontsize=8)
    for i, name, cc in [(i_mix, r"a mixing seed: hops over connected wells", "C2"),
                        (i_frz, r"a frozen seed: stuck in the trap", "C3")]:
        ax[1].plot(CEN, pool(np.arange(N) == i), c=cc, lw=1.7, label=name)
    ax[1].plot(grid, peq, "C0", lw=2, ls="--", label=r"true $P_{\rm eq}$")
    ax[1].set_xlabel("$x$"); ax[1].set_ylabel("density")
    ax[1].set_title(r"(b) single-seed time-average $P_s(x)$ (one seed is noisy; the POOL converges)")
    ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(OUT / "fig_leq_toy_residence.png", dpi=140); plt.close(fig)

    # ---------------------------------------------------------------- Fig 4: the payoff
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].plot(grid, peq, "C0", lw=2.4, label=r"true $P_{\rm eq}$")
    ax[0].plot(CEN, pool(R <= T_STAR), "C2", lw=1.9, label=f"pool MIXING ($R\\leq{T_STAR:.0f}$), avg")
    ax[0].plot(CEN, pool(R > T_STAR), "C3", lw=1.9, ls="--", label=f"pool FROZEN ($R>{T_STAR:.0f}$), avg")
    ax[0].set_xlabel("$x$"); ax[0].set_ylabel("density")
    ax[0].set_title(f"(a) pooled distribution at $T={T_STAR:.0f}$"); ax[0].legend(fontsize=8)
    ax[1].plot(T_LIST, js_mix, "-o", c="C2", lw=2.2, label=r"keep MIXING ($R\leq T$)")
    ax[1].plot(T_LIST, js_frz, "--s", c="C3", lw=2.0, label="keep FROZEN ($R>T$)")
    ax[1].axhline(0.0, ls=":", c="green", lw=1, label="floor (LEQ)")
    ax[1].axhline(LN2, ls="--", c="k", lw=1, alpha=0.6, label=r"$\ln 2$ ceiling (disjoint)")
    ax[1].set_xlabel("residence threshold  $T$"); ax[1].set_ylabel(r"$\mathrm{JS}(P_{\rm pool},P_{\rm eq})$")
    ax[1].set_ylim(0, LN2 * 1.05); ax[1].set_title("(b) JS to equilibrium vs $T$"); ax[1].legend(fontsize=7.5)
    fig.tight_layout(); fig.savefig(OUT / "fig_leq_toy_payoff.png", dpi=140); plt.close(fig)
    print(f"wrote 4 figures to {OUT}/fig_leq_toy_*.png")


if __name__ == "__main__":
    run()
