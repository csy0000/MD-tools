#!/usr/bin/env python3
"""demo_toy_kstar_classification.py — how forward-AIS landings are classified into K* states (K*=2..5).

Four panels, one per candidate component count K in {2,3,4,5}: the (cold-reweighted) forward-AIS landings are
fit by a Gaussian mixture at that K and coloured by component assignment; the component means (medoids) are
marked, with the cold potential drawn for context. Each panel's title reports the GMM BIC; the BIC-optimal K
is the auto-detected K* (here K*=3, the true state count). This is the state-detection step that seeds BAIS.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_toy_kstar_classification
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np
from sklearn.mixture import GaussianMixture

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap

ROOT = project_root()
OUT = ROOT / "results/toy"
K_LIST = [2, 3, 4, 5]
# Unified hot ensemble + AIS ladder (mirrors demo_bais_protocol_convergence_toy.AIS_LADDER; defined locally to keep
# this driver self-contained). s_hot = AIS_LADDER[0] = 0.01, √s-square 0.01 → 1 (10 rungs, 9 annealing steps).
AIS_LADDER = np.linspace(np.sqrt(0.01), 1.0, 10) ** 2
S_HOT = float(AIS_LADDER[0])                                          # = 0.01 (unified hot ensemble; not t.s_hot)


def landings(seed=0, n_shot=100, hot_steps=100_000, hot_walkers=10):
    # n_shot=100 = the protocol's per-generation forward-AIS count (n_fwd, demo_bais_gen_bar_toy). At this
    # discovery-stage budget BIC robustly recovers the true K*=3 (checked over 12 seeds); the broad minor well B
    # (κ=9) only over-splits at much larger landing budgets — which the downstream kinetic merge collapses anyway.
    t = Toy1D(); rng = np.random.default_rng(seed); s = S_HOT
    hot = t.langevin(t.sample_boltzmann(s, hot_walkers, rng), hot_steps, s, rng)[-1]
    x0 = hot[rng.integers(0, len(hot), n_shot)]
    land, lw = t.ais_switch(x0, s, 1.0, m_steps=len(AIS_LADDER) - 1, freq=10, rng=rng, schedule=AIS_LADDER)
    return t, wrap(land), np.asarray(lw, float)


def run(seed=0):
    t, ang, lw = landings(seed)
    w = np.exp(lw - lw.max()); w /= w.sum()
    # resample by cold weight so the GMM sees the cold-target landing density
    rng = np.random.default_rng(seed + 1)
    idx = rng.choice(len(ang), size=len(ang), p=w)
    ang_c = ang[idx]
    X = np.column_stack([np.cos(ang_c), np.sin(ang_c)])
    ana = t.populations()
    make_figure(t, ana, ang_c, X, seed)


def make_figure(t, ana, ang_c, X, seed):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    grid = np.linspace(-np.pi, np.pi, 400)
    U = -np.log(np.clip(t.p_eq(grid), 1e-12, None))
    fig, axes = plt.subplots(2, 2, figsize=(14.5, 10.0))
    bics = {}
    for K in K_LIST:
        gm = GaussianMixture(K, covariance_type="full", random_state=seed, n_init=4, reg_covar=0.012).fit(X)
        bics[K] = gm.bic(X)
    kstar = min(bics, key=bics.get)
    cmap = plt.get_cmap("tab10")
    for ax, K in zip(axes.ravel(), K_LIST):
        gm = GaussianMixture(K, covariance_type="full", random_state=seed, n_init=4, reg_covar=0.012).fit(X)
        lab = gm.predict(X)
        med = np.sort(np.arctan2(gm.means_[:, 1], gm.means_[:, 0]))
        # order labels by medoid angle for stable colours
        order = np.argsort(np.arctan2(gm.means_[:, 1], gm.means_[:, 0]))
        remap = np.zeros(K, int); remap[order] = np.arange(K)
        lab = remap[lab]
        deg = np.degrees(wrap(ang_c))
        for c in range(K):
            m = lab == c
            ax.hist(deg[m], bins=np.linspace(-180, 180, 73), color=cmap(c), alpha=0.75,
                    label=f"comp {c+1}")
        axr = ax.twinx()
        axr.plot(np.degrees(grid), U - U.min(), "k-", lw=1.3, alpha=0.55)
        axr.set_ylabel("$U_{cold}$ (kT)", fontsize=8); axr.set_ylim(0, 16)
        for mdg in np.degrees(med):
            ax.axvline(mdg, color="k", ls="--", lw=1.0)
        star = " ★ K*=%d (BIC-optimal)" % kstar if K == kstar else ""
        ax.set_title(f"K={K}  (BIC={bics[K]:.0f}){star}", fontsize=10,
                     fontweight=("bold" if K == kstar else "normal"))
        ax.set_xlim(-180, 180); ax.set_xlabel("θ (deg)"); ax.set_yticks([])
        ax.legend(fontsize=7, loc="upper left", ncol=2)
    fig.suptitle("Classifying forward-AIS landings into K* states — GMM at K=2/3/4/5 over the (cos θ, sin θ) "
                 "embedding\n(dashed = component medoids; black curve = $U_{cold}$; BIC selects K*=3, the true count "
                 "A₁,A₂,B)", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_toy_kstar_classification.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_toy_kstar_classification.png'} (K*={kstar}, BIC={ {k: round(v) for k,v in bics.items()} })",
          file=sys.stderr)


if __name__ == "__main__":
    run()
