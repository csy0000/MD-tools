#!/usr/bin/env python3
"""demo_baus_bata_per_n_toy.py — the actual reconstructed BAUS-N and BAIS-N
OUTPUTS at N = 10/50/100, vs analytic.

Unlike the matched-budget comparison (which plots error *metrics* vs N), this
shows the estimator products themselves as the AIS budget grows:
  * BAUS-N: reconstructed cold P(θ) + 3-basin populations vs analytic.
  * BAIS-N: stationary distribution (≡ BAUS-N π) + slow ITS vs analytic.
Median over a few seeds. Illustrates how BAUS-10 under-resolves (K*=2, misses a
well) while BAUS-50/100 recover the three basins.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_baus_bata_per_n_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.toy1d import Toy1D, wrap                       # noqa: E402
from escort_ais.methods.baus import reconstruct_pmf                    # noqa: E402
from escort_ais.methods.bais import estimate_bais                      # noqa: E402
from escort_ais.methods.state_detect import detect_kstar, halfwidths, spring_constants  # noqa: E402
from escort_ais.experiments.toy.demo_baus_bata_vs_multiwalker import basin_pops, count_matrix, REGIMES     # noqa: E402

OUT = ROOT / "results/toy"
N_LIST = [10, 50, 100]
E_TARGET = 8.0


def reconstruct(kappa, N, seed, fast=False):
    """Run BAUS-N + BAIS-N once and return the raw reconstructed outputs."""
    t = Toy1D(kappa=kappa); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); bnd = np.radians(ana["boundaries_deg"])
    nb = ana["n_basins"]; pt = np.array(ana["pops"]); its_true = float(t.smoluchowski_kinetics()["t_AB"])
    NG = 120; edges = np.linspace(-np.pi, np.pi, NG + 1); ctr = 0.5 * (edges[:-1] + edges[1:]); dx = ctr[1] - ctr[0]
    # fixed-total budget policy (B=1e6): hot 0.1M + AIS 20N + US remainder/K* + rev AIS; BAIS cold = remainder
    total = 300_000 if fast else 1_000_000
    n_hot = 100_000; m_steps, freq = 10, 1; us_walk, us_burn = 1, 600; lag = 500
    remainder = total - n_hot - 20 * N

    hot = t.sample_boltzmann(t.s_hot, n_hot, rng); xh = hot[rng.integers(0, len(hot), N)]
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=m_steps, freq=freq, rng=rng); Wf = -lwf
    _, _, Kstar, medoids = detect_kstar(land, lwf, seed=seed)
    hw = halfwidths(medoids); kspring = spring_constants(medoids, hw, e_target=E_TARGET)
    bof = lambda th, med: np.argmin(np.abs(wrap(np.atleast_1d(th)[:, None] - np.asarray(med)[None, :])), axis=1)
    land_basin = bof(land, medoids)
    n_cold = Kstar                                             # K* cold walkers (one per detected state)
    us_steps = max(2000, remainder // Kstar); cold_len = max(lag + 10, remainder // n_cold)
    us_samples, Wr, rev_start = [], [], []
    for k in range(Kstar):
        us = t.us_sample(medoids[k], hw[k], us_steps, rng, k=float(kspring[k]), burn=us_burn, walkers=us_walk)
        us_samples.append(us); us_in = us[bof(us, medoids) == k]
        st = us_in[rng.integers(0, len(us_in), min(len(us_in), max(N, 50)))] if len(us_in) else us_in
        if len(st):
            _, lwr = t.ais_switch(st, 1.0, t.s_hot, m_steps=m_steps, freq=freq, rng=rng)
            Wr.append(-lwr); rev_start.append(np.full(len(lwr), k))
    Wr = np.concatenate(Wr); rev_start = np.concatenate(rev_start)

    baus = reconstruct_pmf(ctr, edges, Wf, land_basin, Wr, rev_start, us_samples, Kstar, medoids, bof, rng=rng)
    P = np.asarray(baus["P"], float); pi3 = basin_pops(P, ctr, dx, bnd, t); pi3 = pi3 / pi3.sum()
    cold = t.langevin(medoids, cold_len, 1.0, rng)             # K* cold walkers, one per detected medoid
    dtr = [t.basin_of(wrap(cold[:, k]), bnd).astype(int) for k in range(cold.shape[1])]
    C = count_matrix(dtr, nb, lag)
    bata = estimate_bais(C, pi3, lag=lag)
    its = float(bata["its"]) if (bata["its"] is not None and np.isfinite(bata["its"])) else np.nan
    stat = np.asarray(bata["pi"], float) if bata["pi"] is not None else np.full(nb, np.nan)
    T = np.asarray(bata["T"], float) if bata.get("T") is not None else np.full((nb, nb), np.nan)
    return dict(N=N, seed=int(seed), Kstar=int(Kstar), ctr=np.degrees(ctr).tolist(), P=(P / (P.sum() * dx)).tolist(),
                pops=pi3.tolist(), stat=stat.tolist(), its=its, T=T.tolist(),
                counts=C.tolist(), lag=int(lag),
                analytic_P=(t.p_eq(ctr) / (t.p_eq(ctr).sum() * dx)).tolist(),
                analytic_pops=pt.tolist(), its_true=its_true,
                basin_centers_deg=np.round(ana["well_centers_deg"], 0).tolist())


def main(fast=False, nseed=4):
    seeds = list(range(2 if fast else nseed))
    kappa = REGIMES["S"]                                        # samplable: A↔B crossable → finite cold ITS
    raw = []
    for N in N_LIST:
        for s in seeds:
            r = reconstruct(kappa, N, s, fast=fast); raw.append(r)
            print(f"BAUS/BAIS-{N} seed {s}: K*={r['Kstar']} pops={np.round(r['pops'],3)} "
                  f"ITS={r['its']:.0f} (true {r['its_true']:.0f})", file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "baus_bata_per_n_toy.json").write_text(json.dumps(dict(N_list=N_LIST, raw=raw), indent=1))
    make_figure(raw)


def _agg(raw, N):
    rr = [r for r in raw if r["N"] == N]
    return rr


def make_figure(raw):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # basin order for bars: sort by centre (B ≈ −120, A1 ≈ 60, A2 ≈ 120)
    centers = np.array(raw[0]["basin_centers_deg"], float)
    order = np.argsort(centers)
    names = []
    for c in centers[order]:
        names.append("B" if c < 0 else ("A1" if c < 90 else "A2"))
    ana_pops = np.array(raw[0]["analytic_pops"], float)[order]
    ana_its = raw[0]["its_true"]
    ctr = np.array(raw[0]["ctr"], float)
    ana_P = np.array(raw[0]["analytic_P"], float)

    lag_val = int(raw[0].get("lag", 500))
    fig, ax = plt.subplots(3, 3, figsize=(15, 12))
    for j, N in enumerate(N_LIST):
        rr = _agg(raw, N)
        Pmed = np.median([r["P"] for r in rr], axis=0)
        popmed = np.median([np.array(r["pops"])[order] for r in rr], axis=0)
        statmed = np.nanmedian([np.array(r["stat"])[order] for r in rr], axis=0)
        itsmed = np.nanmedian([r["its"] for r in rr])
        Kmed = int(np.median([r["Kstar"] for r in rr]))
        poptv = 0.5 * np.abs(popmed - ana_pops).sum()

        # --- Row 1: BAUS-N reconstructed cold P(θ) vs analytic, pops inset ---
        a = ax[0, j]
        a.fill_between(ctr, ana_P, color="0.8", label="analytic")
        a.plot(ctr, Pmed, color="#2a7f2a", lw=2, label=f"BAUS-{N}")
        a.set_title(f"BAUS-{N}: cold $P(θ)$  ($K^*$={Kmed}, pop TV={poptv:.3f})", fontsize=10)
        a.set_xlabel("θ (deg)"); a.set_xlim(-180, 180)
        if j == 0:
            a.set_ylabel("$P(θ)$"); a.legend(fontsize=8, loc="upper right")
        ins = a.inset_axes([0.04, 0.52, 0.32, 0.42])                   # populations inset in the (empty) upper-left
        x = np.arange(3)
        ins.bar(x - 0.2, ana_pops, 0.4, color="0.7", label="ana")
        ins.bar(x + 0.2, popmed, 0.4, color="#2a7f2a", label=f"B-{N}")
        ins.set_xticks(x); ins.set_xticklabels(names, fontsize=7); ins.tick_params(labelsize=6)
        ins.set_title("populations", fontsize=7)

        # --- Row 2: BAIS-N stationary (≡ BAUS π) bars + slow ITS ---
        a = ax[1, j]
        a.bar(x - 0.2, ana_pops, 0.4, color="0.7", label="analytic")
        a.bar(x + 0.2, statmed, 0.4, color="#2a7f2a", label=f"BAIS-{N}")
        a.set_xticks(x); a.set_xticklabels(names)
        a.set_ylim(0, max(ana_pops.max(), np.nanmax(statmed)) * 1.35)
        rel = abs(itsmed - ana_its) / ana_its if np.isfinite(itsmed) else np.nan
        a.set_title(f"BAIS-{N}: stationary + slow ITS\nITS={itsmed:.0f} vs analytic {ana_its:.0f} "
                    f"(rel.err {rel:.2f})", fontsize=10)
        if j == 0:
            a.set_ylabel("stationary prob."); a.legend(fontsize=8)

        # --- Row 3: BAIS-N reversible transition matrix T (lag τ), reordered to B/A1/A2 ---
        a = ax[2, j]
        Tmed = np.nanmedian([np.array(r["T"], float)[np.ix_(order, order)] for r in rr], axis=0)
        im = a.imshow(Tmed, cmap="viridis", vmin=0, vmax=1)
        for ii in range(3):
            for jj in range(3):
                v = Tmed[ii, jj]
                a.text(jj, ii, ("—" if not np.isfinite(v) else f"{v:.3f}"), ha="center", va="center",
                       color=("white" if (np.isfinite(v) and v < 0.6) else "black"), fontsize=9)
        a.set_xticks(range(3)); a.set_xticklabels(names); a.set_yticks(range(3)); a.set_yticklabels(names)
        a.set_title(f"BAIS-{N}: transition matrix $T_{{ij}}$ (lag $τ$={lag_val})", fontsize=10)
        a.set_xlabel("to state")
        if j == 0:
            a.set_ylabel("from state")

    fig.suptitle("Individual BAUS-$N$ and BAIS-$N$ reconstructions at $N$ = 10 / 50 / 100 — 1D toy\n"
                 "Row 1: BAUS-$N$ cold $P(θ)$ + populations (green) vs analytic (grey). Row 2: BAIS-$N$ stationary "
                 "distribution ($≡$ BAUS-$N$ π) + slow ITS. Row 3: BAIS-$N$ reversible cold transition matrix $T$. "
                 "Median over seeds.", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / "fig_baus_bata_per_n_toy.png", dpi=160); plt.close(fig)
    print(f"  wrote {OUT / 'fig_baus_bata_per_n_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    if "--figure-only" in sys.argv:
        make_figure(json.load(open(OUT / "baus_bata_per_n_toy.json"))["raw"])
    else:
        main(fast="--fast" in sys.argv)
