#!/usr/bin/env python3
"""demo_baus_bata_convergence_vs_time.py — CHECKPOINTED convergence vs total budget.

A single run per seed to the MAX budget (default 1e6), with the estimators evaluated at
20 growing sub-budgets (checkpoints). This is the right way to make a convergence curve:
one continuous run sampled at intermediate budgets — NOT 20 independent runs.

Budget policy (per checkpoint total X): fixed hot 1e5 + fwd AIS 10N, then the middle slot
(≈ X/K* per walker: US for BAUS, unbiased cold MD for BAIS/multi) grows with X, and N
reverse-AIS shots are re-fired from the samples-so-far to give the annealed π (shared by
BAUS and BAIS). BAIS and multi-walker read the kinetics from the SAME cold; the single
walker spends all of X on one cold trajectory (no hot).

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_baus_bata_convergence_vs_time [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.toy1d import Toy1D, wrap                                # noqa: E402
from escort_ais.methods.baus import reconstruct_pmf                            # noqa: E402
from escort_ais.methods.bais import estimate_bais, estimate_msm_free_pi        # noqa: E402
from escort_ais.methods.state_detect import detect_kstar, halfwidths, spring_constants  # noqa: E402
from escort_ais.experiments.toy.demo_baus_bata_vs_multiwalker import basin_pops, count_matrix, _tv, REGIMES  # noqa: E402

OUT = ROOT / "results/toy"
N_AIS = 50                      # fixed AIS-shot count; the budget is what is swept
E_TARGET = 8.0


def checkpointed_run(kappa, seed, total_max, n_ckpt, fast=False):
    """One run to total_max; return per-checkpoint (total, pop-TV, ITS-relerr) for the four methods."""
    t = Toy1D(kappa=kappa); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); bnd = np.radians(ana["boundaries_deg"])
    nb = ana["n_basins"]; pt = np.array(ana["pops"]); its_true = float(t.smoluchowski_kinetics()["t_AB"])
    NG = 120; edges = np.linspace(-np.pi, np.pi, NG + 1); ctr = 0.5 * (edges[:-1] + edges[1:]); dx = ctr[1] - ctr[0]
    n_hot = 100_000; m_steps, freq = 10, 1; lag = 500; N = N_AIS
    bof = lambda th, med: np.argmin(np.abs(wrap(np.atleast_1d(th)[:, None] - np.asarray(med)[None, :])), axis=1)

    # --- hot + forward AIS (once) → K*, medoids ---
    hot = t.sample_boltzmann(t.s_hot, n_hot, rng); xh = hot[rng.integers(0, len(hot), N)]
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=m_steps, freq=freq, rng=rng); Wf = -lwf
    _, _, Kstar, medoids = detect_kstar(land, lwf, seed=seed)
    hw = halfwidths(medoids); kspring = spring_constants(medoids, hw, e_target=E_TARGET)
    land_basin = bof(land, medoids)

    mid_max = total_max - n_hot - 20 * N                               # total middle budget (US or cold), all K* walkers
    per_walker = max(lag + 10, mid_max // Kstar)                       # steps per walker at the max

    # --- run the samplers ONCE to the max (full resolution), then slice at each checkpoint ---
    us_full = [t.us_sample(medoids[k], hw[k], per_walker, rng, k=float(kspring[k]), burn=600, walkers=1)
               for k in range(Kstar)]
    cold_full = t.langevin(medoids, per_walker, 1.0, rng)             # (per_walker, K*)
    sb = int(np.random.default_rng(seed + 555).integers(0, nb))
    single_full = wrap(t.langevin(np.array([wells[sb]]), total_max, 1.0, np.random.default_rng(seed + 999))[:, 0])

    def relerr(x):
        return abs(x - its_true) / its_true if (x is not None and np.isfinite(x)) else np.nan

    rows = []
    for i in range(1, n_ckpt + 1):
        frac = i / n_ckpt
        total_i = n_hot + 20 * N + frac * mid_max                     # total budget at this checkpoint
        us_i = [u[:max(2, int(frac * len(u)))] for u in us_full]
        cold_i = cold_full[:max(lag + 2, int(frac * cold_full.shape[0]))]

        # BAUS: reverse AIS (N shots) from the US-so-far → reconstruct → populations
        Wr, rev_start = [], []
        for k in range(Kstar):
            us_in = us_i[k][bof(us_i[k], medoids) == k]
            st = us_in[rng.integers(0, len(us_in), min(len(us_in), max(N, 50)))] if len(us_in) else us_in
            if len(st):
                _, lwr = t.ais_switch(st, 1.0, t.s_hot, m_steps=m_steps, freq=freq, rng=rng)
                Wr.append(-lwr); rev_start.append(np.full(len(lwr), k))
        if Wr:
            Wr = np.concatenate(Wr); rev_start = np.concatenate(rev_start)
            baus = reconstruct_pmf(ctr, edges, Wf, land_basin, Wr, rev_start, us_i, Kstar, medoids, bof, rng=rng)
            pi_baus = basin_pops(np.asarray(baus["P"], float), ctr, dx, bnd, t); pi_baus = pi_baus / pi_baus.sum()
        else:
            pi_baus = pt.copy()

        # BAIS / multi-walker: the SAME cold-so-far (fixed-π vs free-π)
        cold_dtr = [t.basin_of(wrap(cold_i[:, k]), bnd).astype(int) for k in range(cold_i.shape[1])]
        C = count_matrix(cold_dtr, nb, lag)
        bata = estimate_bais(C, pi_baus, lag=lag)
        pi_multi = np.array([np.mean([np.mean(d == b) for d in cold_dtr]) for b in range(nb)])
        pi_multi = pi_multi / pi_multi.sum()
        msm = estimate_msm_free_pi(C, lag=lag)

        # single walker: all of total_i on one cold trajectory (no hot)
        single_i = single_full[:max(lag + 2, int(total_i))]
        sd = t.basin_of(single_i, bnd).astype(int)
        pi_single = np.array([np.mean(sd == b) for b in range(nb)]); pi_single = pi_single / pi_single.sum()
        msm_s = estimate_msm_free_pi(count_matrix([sd], nb, lag), lag=lag)

        rows.append(dict(total=float(total_i), Kstar=int(Kstar),
                         pop=dict(baus=_tv(pi_baus, pt), multi=_tv(pi_multi, pt), single=_tv(pi_single, pt)),
                         its=dict(bata=relerr(bata["its"]), multi=relerr(msm["its"]), single=relerr(msm_s["its"]))))
    return rows


def run(fast=False, nseed=4):
    total_max = 300_000 if fast else 1_000_000
    n_ckpt = 10 if fast else 20
    seeds = list(range(2 if fast else nseed))
    runs = []
    for s in seeds:
        rows = checkpointed_run(REGIMES["S"], s, total_max, n_ckpt, fast=fast)
        runs.append(rows)
        print(f"[seed {s}] K*={rows[0]['Kstar']} | final popTV baus {rows[-1]['pop']['baus']:.3f} "
              f"multi {rows[-1]['pop']['multi']:.3f} | itsErr bata {rows[-1]['its']['bata']:.3f} "
              f"multi {rows[-1]['its']['multi']:.3f}", file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "baus_bata_convergence_vs_time.json").write_text(json.dumps(dict(n_ckpt=n_ckpt, runs=runs), indent=1))
    make_figure(runs, n_ckpt)


def _curve(runs, metric, sub, clip=None):
    """Median x (total) and y over seeds at each checkpoint index."""
    n = len(runs[0])
    xs = np.array([np.median([r[i]["total"] for r in runs]) for i in range(n)])
    ys = []
    for i in range(n):
        v = np.array([r[i][metric][sub] for r in runs], float)
        if clip is not None:
            v = np.clip(v, None, clip)
        ys.append(np.nanmedian(v))
    return xs, np.array(ys)


def make_figure(runs, n_ckpt):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    cols = {"baus": "#2a7f2a", "bata": "#2a7f2a", "multi": "#b03030", "single": "#7a4fb0"}
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))

    a = ax[0]
    for sub, lab in [("baus", "BAUS-N"), ("multi", "multi-walker"), ("single", "single-walker")]:
        x, y = _curve(runs, "pop", sub)
        a.plot(x, y, "-o", c=cols[sub], ms=4, label=lab, mfc=("none" if sub == "single" else cols[sub]))
    a.set_xscale("log"); a.set_yscale("log")
    a.set_xlabel("total budget $B$  (force-evaluations)"); a.set_ylabel("population TV to analytic")
    a.set_title("(1) free energy vs budget"); a.legend(fontsize=8); a.grid(alpha=0.3, which="both")

    a = ax[1]
    for sub, lab in [("bata", "BAIS-N"), ("multi", "multi-walker"), ("single", "single-walker")]:
        x, y = _curve(runs, "its", sub, clip=1.5)
        a.plot(x, y, "-o", c=cols[sub], ms=4, label=lab, mfc=("none" if sub == "single" else cols[sub]))
    a.set_xscale("log")
    a.set_xlabel("total budget $B$  (force-evaluations)"); a.set_ylabel("slow-ITS relative error"); a.set_ylim(0, 1.5)
    a.set_title("(2) kinetics vs budget"); a.legend(fontsize=8); a.grid(alpha=0.3)

    fig.suptitle(f"Checkpointed convergence vs total budget $B$ — one {'0.3M' if n_ckpt == 10 else '1M'} run per seed, "
                 f"evaluated at {n_ckpt} sub-budgets ($N$={N_AIS} AIS shots) — 1D toy\n"
                 "hot 0.1M + AIS 20$N$ + growing US/cold (≈$B/K^*$ per walker) + $N$ reverse-AIS; "
                 "BAIS/multi share the cold; single-walker spends all of $B$ on one trajectory.",
                 fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.88])
    fig.savefig(OUT / "fig_baus_bata_convergence_vs_time.png", dpi=170); plt.close(fig)
    print(f"  wrote {OUT / 'fig_baus_bata_convergence_vs_time.png'}", file=sys.stderr)


if __name__ == "__main__":
    if "--figure-only" in sys.argv:
        d = json.load(open(OUT / "baus_bata_convergence_vs_time.json"))
        make_figure(d["runs"], d["n_ckpt"])
    else:
        run(fast="--fast" in sys.argv)
