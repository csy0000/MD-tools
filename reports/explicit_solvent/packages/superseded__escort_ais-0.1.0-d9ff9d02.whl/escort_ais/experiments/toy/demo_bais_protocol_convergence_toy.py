#!/usr/bin/env python3
"""demo_bais_protocol_convergence_toy.py — does the NEW BAIS protocol converge to the analytic populations?

Validates the redesigned per-generation protocol (a SINGLE hot walker; ONE cold walker per occupied basin with
seed-empty / terminate-shorter-residence duplicate; forward 100x5 AIS; reverse COUNT-MATCHED to the forward
landings per basin) by running it to increasing total force-evaluation budgets and checking whether the
endpoint-BAR populations pi -> analytic [B,A1,A2]=[0.25,0.42,0.33]. The minor basin B is the stress test: because
count-matched reverse gives B only as many reverse shots as its sparse forward landings, B is the slowest to
converge -- this driver measures whether it converges at all (consistency) or plateaus below 0.25 (a bias).

`bais_protocol_run` is the single reusable implementation of the new protocol; demo_bais_vs_walkers_toy imports it
so the matched-budget comparison uses the SAME code that is validated here.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_protocol_convergence_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.state_detect import detect_kstar
from escort_ais.methods.bais import basin_free_energies, estimate_bais, reversible_mle, slow_timescale
from escort_ais.methods.kcc_split import leq_valid_mask, residence_T, decompose_reservoir
from escort_ais.methods.bais_basins import BasinManager
from escort_ais.experiments.toy.demo_bais_gen_bar_toy import _home_res


def _post_decompose_A(walkers, t, bnd, lag=300, seed=13):
    """POST-ANALYSIS on the run's OWN accumulated cold reservoir (no fresh sampling): resolve the A1/A2
    sub-basins WITHIN the LEQ-confident A basin and their free-energy difference from the MSM.

    Run-time BAR gives pi_A, pi_B (the slow, frozen A<->B split the reservoir cannot sample). This step reads
    A1<->A2 -- fast, so the single A walker equilibrates across it, and the accumulated reservoir carries the
    correct A1:A2 ratio -- off the cold MSM (`decompose_reservoir`), never BAR. Extracts contiguous A-residence
    segments (basin in {A1,A2}) from every walker's history as within-walker trajectories, then decomposes.
    Returns dict(n_c, a1_frac_within_A, dF_A1A2, t_a1a2, mfpt_a1a2) or None if too little A data.
    """
    featsA, wlensA, thA = [], [], []
    for w in walkers:
        if not w.get("acc"):
            continue
        th = np.concatenate(w["acc"]); inA = t.basin_of(th, bnd).astype(int) != 0
        i = 0
        while i < len(inA):
            if inA[i]:
                j = i
                while j < len(inA) and inA[j]:
                    j += 1
                if j - i >= 300:                       # a real A-residence segment (not a graze)
                    s = th[i:j]; featsA.append(np.column_stack([np.cos(s), np.sin(s)])); wlensA.append(j - i); thA.append(s)
                i = j
            else:
                i += 1
    if not wlensA or sum(wlensA) < 5000:
        return None
    feats = np.concatenate(featsA); th = np.concatenate(thA)
    r = decompose_reservoir(feats, wlensA, lag=lag, tica_lag=lag, n_tica=1, n_micro=40,
                            alpha_gap=10.0, n_floor=2, seed=seed)
    t2 = float(r["timescales"][0]) if r["timescales"] else float("nan")
    if r["n_c"] < 2:
        return dict(n_c=int(r["n_c"]), a1_frac_within_A=float("nan"), dF_A1A2=float("nan"), t_a1a2=t2, mfpt_a1a2=float("nan"))
    lab = r["labels"]
    cent = {b: np.degrees(np.arctan2(np.sin(th[lab == b]).mean(), np.cos(th[lab == b]).mean()))
            for b in set(lab.tolist())}
    a1 = min(cent, key=lambda k: abs(cent[k] - 60.0)); a2 = min(cent, key=lambda k: abs(cent[k] - 120.0))
    NA1 = int((lab == a1).sum()); NA2 = int((lab == a2).sum())
    return dict(n_c=int(r["n_c"]), a1_frac_within_A=float(NA1 / (NA1 + NA2)),
                dF_A1A2=float(-np.log(NA1 / NA2)) if NA2 else float("nan"), t_a1a2=t2,
                mfpt_a1a2=(float(r["mfpt"][a1][a2]) if r["mfpt"] is not None else float("nan")))


def _feat1d(ang):
    """1-D toy angle(s) (rad) -> (n, 2) cos/sin feature rows for the BasinManager / KCC."""
    ang = np.asarray(ang, float).ravel()
    return np.stack([np.cos(ang), np.sin(ang)], axis=1)

ROOT = project_root()
OUT = ROOT / "results/toy"
ANALYTIC = np.array([0.25, 0.42, 0.33])          # [B, A1, A2] analytic cold populations
LAG = 500
PAIRS_IDX = [(1, 2, "A1-A2"), (1, 0, "A1-B"), (2, 0, "A2-B")]     # basin idx 0=B, 1=A1, 2=A2


def _count_matrix(dtrajs, nb, lag):
    C = np.zeros((nb, nb))
    for d in dtrajs:
        d = np.asarray(d, int)
        if len(d) > lag:
            np.add.at(C, (d[:-lag], d[lag:]), 1.0)
    return C


def _seq_t2(dseq, lag, nb=3):
    """Slowest implied timescale t2 = -lag/ln(λ2) of ONE discrete-state sequence at `lag`: 3-state row-normalized
    transition matrix, λ2 = 2nd-largest (real) eigenvalue. Returns the fast-mixing floor `lag` if λ2 ∉ (0,1) or NaN."""
    C = _count_matrix([np.asarray(dseq, int)], nb, lag)
    rs = C.sum(1, keepdims=True)
    T = np.divide(C, rs, out=np.zeros_like(C), where=rs > 0)
    ev = np.sort(np.linalg.eigvals(T).real)[::-1]
    lam2 = ev[1] if ev.size > 1 else np.nan
    return float(-lag / np.log(lam2)) if (np.isfinite(lam2) and 0.0 < lam2 < 1.0) else float(lag)


def _seg_counts(bseq, lag):
    """Full 3x3 counts and the three restricted 2-state (A1-A2, A1-B, A2-B) counts of ONE cold segment."""
    bseq = np.asarray(bseq, int)
    Cfull = np.zeros((3, 3))
    if bseq.size > lag:
        np.add.at(Cfull, (bseq[:-lag], bseq[lag:]), 1.0)
    Cpairs = []
    for a, b, _ in PAIRS_IDX:
        s = bseq[(bseq == a) | (bseq == b)]; Cp = np.zeros((2, 2))
        if s.size > lag:
            s2 = (s == b).astype(int)
            np.add.at(Cp, (s2[:-lag], s2[lag:]), 1.0)
        Cpairs.append(Cp)
    return Cfull, Cpairs


def _seg_crossings(bseq):
    """Count basin-change events in one segment, per pair, in PAIRS_IDX order (A1-A2, A1-B, A2-B)."""
    d = np.asarray(bseq, int); out = np.zeros(3)
    key = {(1, 2): 0, (0, 1): 1, (0, 2): 2}                          # sorted(u,v) -> A1-A2, A1-B, A2-B
    for k in np.where(d[:-1] != d[1:])[0] if d.size > 1 else []:
        j = key.get(tuple(sorted((int(d[k]), int(d[k + 1])))))
        if j is not None:
            out[j] += 1
    return out


def _pair_its(Cp, lag):
    """Free-π reversible 2-state slow ITS from restricted pair counts. NaN if the pair is under-resolved: fewer
    than 4 committed cross-transitions (a near-reducible 2-state chain gives a blown-up/unstable timescale) or an
    ITS above 2e5 frames (>5x the slowest analytic; treated as unresolved rather than plotted as a spike)."""
    if Cp.sum() < 10 or np.any(Cp.sum(1) == 0) or (Cp[0, 1] + Cp[1, 0]) < 4:
        return np.nan
    T, _ = reversible_mle(Cp)
    v = slow_timescale(T, lag, C=Cp)
    v = float(v) if v is not None and np.isfinite(v) else np.nan
    return v if (np.isfinite(v) and v < 2e5) else np.nan


def _ess_frac(logw):
    """Effective sample size (Kish) from unnormalized log-weights: (Σw)^2/Σw^2 with w=exp(logw-max(logw))."""
    logw = np.asarray(logw, float)
    if logw.size == 0 or not np.isfinite(logw).any():
        return float("nan")
    w = np.exp(logw - np.nanmax(logw))
    denom = float(np.nansum(w ** 2))
    return float(np.nansum(w) ** 2 / denom) if denom > 0 else float("nan")


def bais_protocol_run(seed, B, *, hot_steps=3000, n_fwd=100, m_ais=5, cold_chunk=3000, n_detect=200,
                      merge_window=3, discover_every=5, burn=0, pergen=False, pergen_full=False, pergen_diag=False,
                      leq_filter=False, leq_cut=180, u_scale=1.0, ais_ladder=None, kappa=None,
                      post_decompose=False, hot_diag=False,
                      freeze_hot=False, freeze_nindep=300.0, freeze_min_pool=None, walker_trace=False):
    """The NEW BAIS protocol, run to total budget B. Returns populations (endpoint-BAR) + slow ITS (fixed-pi MSM).

    ONE hot walker; ONE cold walker per occupied basin (seed empty basins, terminate the shorter-residence
    duplicate); reverse AIS count-matched to the per-basin forward landings.

    burn : optional hot burn-in (steps discarded before productive sampling) to remove the single-draw
           initialization transient (the walker starts in one basin). Counts against the budget.
    u_scale : potential amplitude multiplier (default 1.0 = base toy). u_scale=5 scales the whole potential 5x
            (same STRUCTURE, 5x barriers), which sharpens the populations to [0.007,0.765,0.229]. The analytic
            reference is recomputed from the toy, so pop-TV / err_B are always scored against THIS toy's populations.
    ais_ladder : optional explicit array of AIS scale rungs (e.g. a LOG-spaced ladder 0.01→1.0); forward AIS
            anneals along it and reverse along its reverse. Sets the hot end (s_hot = ladder[0]) and the annealing
            step count (len-1) for budget accounting. None keeps the linear s_hot→1 ladder of m_ais steps.
    kappa : optional explicit von-Mises concentrations for a κ-RETUNE toy (sharper wells, higher barriers, SAME
            populations). When set, the toy is Toy1D(kappa=kappa) (u_scale is then ignored). e.g. [70,70,30] gives
            barriers A1↔A2≈8.8 kT, A↔B≈21.4 kT with populations preserved at [0.25,0.42,0.33] (the 3× regime).
    pergen : if True, also return the running endpoint-BAR pi after each generation ("pergen_pi") and the
             cumulative budget at each generation ("pergen_budget").
    pergen_full : if True (implies pergen), ALSO record per generation the fixed-pi full-MSM ITS
             ("pergen_fix_its"), the three restricted pairwise ITS A1-A2/A1-B/A2-B ("pergen_pair_its"), and the
             cumulative barrier crossings per pair ("pergen_cross").
    pergen_diag : if True (implies pergen), record — ONLY on generations where n_iter % 5 == 0 (to stay light) —
             a raw-diagnostics dict per such generation into "pergen_diag": this gen's forward reduced works Wf
             + landing basins lf, reverse works Wr + start basins rl, each surviving walker's THIS-gen cold θ
             segment (walker_theta) and home basin (walker_home), the AIS landing angles (land_theta), the
             running endpoint-BAR pi, and the per-shot forward/reverse ESS (ess_f, ess_r).
    hot_diag : if True (implies pergen; READ-ONLY, does not touch the RNG stream), record per recorded
             generation into "hot_diag" a LEQ-vs-accuracy diagnostic of the CUMULATIVE hot walker: cumulative
             length T_hot_cum, slowest implied timescale t2_hot (3-well count matrix, lag 50), LEQ margin/flag
             (α_LEQ=10), cumulative & this-gen TV of the hot walker to the analytic hot Boltzmann reference
             (tv_hot_cum / tv_hot_gen), and the running cold endpoint-BAR pi + its pop_tv to [0.25,0.42,0.33].
    """
    t = Toy1D(u_scale=u_scale) if kappa is None else Toy1D(kappa=np.asarray(kappa, float))
    rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    analytic = np.asarray(ana["pops"], float)                    # per-basin [B,A1,A2] reference for THIS toy
    ais_ladder = None if ais_ladder is None else np.asarray(ais_ladder, float)
    s_hot = float(ais_ladder[0]) if ais_ladder is not None else t.s_hot     # forward AIS starts at the hot rung
    m_eff = (len(ais_ladder) - 1) if ais_ladder is not None else m_ais       # annealing steps (budget accounting)
    its_true = float(t.smoluchowski_kinetics()["t_AB"])

    hot_pos = t.sample_boltzmann(s_hot, 1, rng)
    budget = 0
    if burn > 0:                                  # discard the initialization transient (one-basin start)
        hot_pos = wrap(t.langevin(hot_pos, burn, s_hot, rng)[-1]); budget += burn
    all_land, all_lw = [], []
    Wf_acc, lf_acc, Wr_acc, rl_acc = [], [], [], []
    walkers = []                                  # {pos, acc:[frames], basin(BasinManager id), home(geometric, figs)}
    mgr = BasinManager(lag=LAG, alpha_leq=10.0, alpha_split=2.0, w_min=0.02,
                       min_members=50, merge_radius=0.5, seed=seed)   # theory KCC + LEQ-gated sticky split
    cold_dtrajs = []                              # per-walker per-gen basin sequences (for the ITS count matrix)
    n_iter = 0; nseed_tot = 0; nkill_tot = 0; leq_kept = None
    next_wid = 0; wtrace = dict(births=[], merges=[])   # walker provenance: (wid, born_gen, home) + (killed, into, basin, gen)
    pergen = pergen or pergen_full or pergen_diag or hot_diag   # pergen_diag/pergen_full/hot_diag imply running-pi
    pergen_pi, pergen_budget = [], []
    pergen_diag_list = []
    hot_diag_list = []
    cum_hot_chunks = []                          # cumulative hot-walker angles (hot_diag only; READ-ONLY of hot_chunk)
    p_hot_analytic = None                        # 3-well fractions of a large deterministic hot Boltzmann reference
    if hot_diag:
        _hb = t.basin_of(t.sample_boltzmann(0.01, 200000, np.random.default_rng(12345)), bnd).astype(int)
        p_hot_analytic = np.bincount(_hb, minlength=3).astype(float); p_hot_analytic /= p_hot_analytic.sum()
    C_run = np.zeros((3, 3)); Cpair_run = [np.zeros((2, 2)) for _ in PAIRS_IDX]   # incremental cold counts
    cross_run = np.zeros(3)                                                        # cumulative crossings per pair
    pergen_fix_its, pergen_pair_its, pergen_cross = [], [], []
    # freeze_hot: stop hot MD once the CUMULATIVE hot ensemble has converged (self-contained: its well-distribution
    # stops moving AND it is LEQ-confident), then draw forward-AIS seeds iid from the frozen pool. The freed hot
    # budget is spent on more cold generations (the while-loop just runs longer). All state guarded behind freeze_hot.
    fz_chunks = []; fz_pool = None; fz_frozen = False; fz_gen = None
    fz_min_pool = int(freeze_min_pool) if freeze_min_pool is not None else max(4 * n_fwd, 2 * hot_steps)

    while budget < B:
        n_iter += 1
        # (1) hot MD + forward AIS
        if freeze_hot and fz_frozen:              # hot ensemble converged: no more hot MD, no hot budget; draw
            xh = fz_pool[rng.integers(0, fz_pool.size, n_fwd)]   # forward-AIS seeds iid from the FROZEN hot pool
        else:
            hot_chunk = t.langevin(hot_pos, hot_steps, s_hot, rng); hot_pos = wrap(hot_chunk[-1]); budget += hot_steps
            hc = wrap(hot_chunk[:, 0])
            if hot_diag:                          # accumulate the cumulative hot walker (READ-ONLY; no fresh randoms)
                cum_hot_chunks.append(hc)
            if freeze_hot:                        # accumulate + test convergence of the establishing hot pool
                fz_chunks.append(hc); pool = np.concatenate(fz_chunks)
                t2h = _seq_t2(t.basin_of(pool, bnd).astype(int), 50)   # slowest hot timescale (3-well, lag 50)
                n_indep = pool.size / max(t2h, 1.0)                    # independent hot samples so far
                if n_indep >= freeze_nindep and pool.size >= fz_min_pool:   # converged: enough iid hot samples
                    fz_frozen = True; fz_pool = pool; fz_gen = n_iter    # (MC error on the hot ensemble ~ 1/sqrt(N))
            xh = hc[rng.integers(0, hot_steps, n_fwd)]
        land, lwf = t.ais_switch(xh, s_hot, 1.0, m_steps=m_ais, freq=1, rng=rng, schedule=ais_ladder)
        budget += n_fwd * m_eff
        land = wrap(land); land_b = t.basin_of(land, bnd).astype(int)
        all_land.append(land); all_lw.append(np.asarray(lwf, float))
        Wf_acc.append(-np.asarray(lwf, float)); lf_acc.append(land_b)
        n_land = np.bincount(land_b, minlength=3)

        # (2) AIS graph (GMM on the weighted landings): nodes = medoids with cold-weight fraction W_c > W_min.
        #     SEED-IF-ABSENT (theory \S9): any AIS node with no resident walker gets a fresh walker at its
        #     top-weight landing; the cold-MD KCC then decides keep-vs-merge — a node that turns out kinetically
        #     connected to an existing basin becomes a duplicate and is removed by (3a); an isolated one stays.
        lp = np.concatenate(all_land); lwp = np.concatenate(all_lw)
        _, _, _kstar, medoids = detect_kstar(lp[-n_detect:], lwp[-n_detect:], seed=seed)
        medoids = wrap(np.asarray(medoids, float))
        if medoids.size:
            wl = np.exp(lwp - lwp.max())
            dl = np.abs(((lp[:, None] - medoids[None, :] + np.pi) % (2 * np.pi)) - np.pi)   # landing->medoid dist
            W_c = np.array([wl[dl.argmin(1) == k].sum() for k in range(len(medoids))]) / wl.sum()
            occ = set()                                          # AIS nodes with a resident walker (Voronoi)
            if walkers:
                wp = np.array([w["pos"] for w in walkers], float)
                dw = np.abs(((wp[:, None] - medoids[None, :] + np.pi) % (2 * np.pi)) - np.pi)
                occ = set(dw.argmin(1).tolist())
            for k in range(len(medoids)):
                if W_c[k] >= mgr.w_min and k not in occ:         # weighted AIS node, no resident walker -> seed
                    j = int(np.argmin(np.abs(((lp - medoids[k] + np.pi) % (2 * np.pi)) - np.pi)))
                    pos0 = float(lp[j])
                    hm = int(t.basin_of(np.array([pos0]), bnd)[0])
                    walkers.append({"pos": pos0, "acc": [], "basin": -1, "home": hm, "wid": next_wid})
                    wtrace["births"].append((next_wid, n_iter, hm)); next_wid += 1; nseed_tot += 1

        # (3) COLD MD (cold_chunk per walker, incl. this gen's new seeds); accumulate the geometric kinetics counts.
        if walkers:
            cpos = np.array([w["pos"] for w in walkers], float)
            cold = t.langevin(cpos, cold_chunk, 1.0, rng); budget += cold_chunk * len(walkers)
            for k, w in enumerate(walkers):
                fr = wrap(cold[:, k]); w["acc"].append(fr); w["pos"] = float(fr[-1])
                w["home"] = int(t.basin_of(np.array([w["pos"]]), bnd)[0])   # geometric well (for figures/reporting)
                bseq = t.basin_of(fr, bnd).astype(int)
                cold_dtrajs.append(bseq)                    # keep EVERY segment (incl. soon-terminated) for kinetics
                cf, cps = _seg_counts(bseq, LAG)            # accumulate full + pairwise counts incrementally
                C_run += cf; cross_run += _seg_crossings(bseq)
                for pk in range(len(Cpair_run)):
                    Cpair_run[pk] += cps[pk]

        # (4)+(5) DISCOVER (Level-1 KCC + LEQ-gated sticky split) and one-walker-per-basin BOOKKEEPING —
        #     THROTTLED to every `discover_every` generations. The per-gen `kcc_split` on the GROWING reservoir is
        #     the dominant cost; basins are sticky and the BAR/reverse (step 6+) use the GEOMETRIC labels, so
        #     re-sorting the walker set every gen is unnecessary. Between discoveries the walkers just extend and
        #     any new seed-if-absent walkers accrue; the walker set is re-sorted on the next discovery. Always run
        #     on the final generation so the reported reservoir is clean.
        wt = [np.concatenate(w["acc"]) for w in walkers if w["acc"]]
        pooled_r = np.concatenate(wt) if wt else np.zeros(0)
        if wt and ((n_iter % discover_every == 0) or budget >= B):
            mgr.discover(_feat1d(pooled_r), [len(tr) for tr in wt])
            nb = mgr.n_basins()
            for w in walkers:                               # (4) assign each walker to its committed basin
                if w["acc"] and nb:
                    lab = mgr.assign(_feat1d(w["acc"][-1]))
                    w["basin"] = int(np.bincount(lab[lab >= 0], minlength=nb).argmax()) if (lab >= 0).any() else -1
            pooled_lab = mgr.assign(_feat1d(pooled_r))

            def _res_in_basin(w):                           # longest consecutive residence of w in its own basin
                if not w["acc"]:
                    return 0
                lab = mgr.assign(_feat1d(np.concatenate(w["acc"])))
                return int(residence_T(lab == w.get("basin", -1), [len(a) for a in w["acc"]]))

            by_basin = {}                                   # (5a) one walker per basin: kill shorter-residence dup
            for w in walkers:
                by_basin.setdefault(w.get("basin", -1), []).append(w)
            kept = []
            for b, ws in by_basin.items():
                if b >= 0 and len(ws) > 1:
                    keep = max(ws, key=_res_in_basin); kept.append(keep); nkill_tot += len(ws) - 1
                    for w in ws:                            # provenance: duplicates retired INTO the kept walker
                        if w is not keep:
                            wtrace["merges"].append((w.get("wid"), keep.get("wid"), int(b), n_iter))
                else:
                    kept.extend(ws)
            walkers = kept
            covered = {w.get("basin", -1) for w in walkers}
            for b in range(nb):                             # (5b) restart an empty basin from a reservoir config in it
                if b not in covered:
                    inb = np.where(pooled_lab == b)[0]
                    if inb.size:
                        pos0 = float(pooled_r[inb[rng.integers(0, inb.size)]])
                        hm = int(t.basin_of(np.array([pos0]), bnd)[0])
                        walkers.append({"pos": pos0, "acc": [], "basin": b, "home": hm, "wid": next_wid})
                        wtrace["births"].append((next_wid, n_iter, hm)); next_wid += 1; nseed_tot += 1

        # (6) reverse AIS, count-matched to the forward landings (N_rev_b = N_fwd_b).
        #     Reservoir = each surviving walker's CONTINUOUS accumulated trajectory (wlens_w = per-walker lengths).
        walker_trajs = [np.concatenate(w["acc"]) for w in walkers if w["acc"]]
        pooled_all = np.concatenate(walker_trajs) if walker_trajs else np.zeros(0)
        pooled_all_b = t.basin_of(pooled_all, bnd).astype(int) if pooled_all.size else np.zeros(0, int)
        # LEQ filter (per SUB-BASIN m): a config may seed reverse AIS only if its continuous residence T_seg^m in
        # its own sub-basin m (geometric well: B, A1, A2) exceeds leq_cut = alpha*t2^m, where t2^m is the slowest
        # INTRA-sub-basin ITS (~18 for this toy, so leq_cut~180). Short (non-LEQ) segments -- transient passes that
        # have not internally equilibrated -- contribute ONLY to the transition-count matrix (cold_dtrajs, recorded
        # above), never to the reverse/local shape.
        leq_ok = None
        if leq_filter and pooled_all.size:
            wlens_w = [len(tr) for tr in walker_trajs]
            leq_ok = np.zeros(len(pooled_all), bool)
            for m in range(3):
                leq_ok |= leq_valid_mask(pooled_all_b == m, wlens_w, leq_cut)          # residence in sub-basin m > 10 t2^m
            leq_kept = float(leq_ok.mean())        # fraction of reservoir frames that pass the LEQ cut
        Wr_gen_list, rl_gen_list = [], []            # THIS gen's reverse works + start-basins (for pergen_diag)
        for b in range(3):
            if n_land[b] == 0 or pooled_all.size == 0:
                continue
            sel = pooled_all_b == b
            if leq_ok is not None:
                sel = sel & leq_ok
            cand = pooled_all[sel]
            if cand.size == 0:                        # all segments in b too short to be LEQ -> no reverse this gen
                continue
            starts = cand[rng.integers(0, len(cand), int(n_land[b]))]
            _, lwr = t.ais_switch(starts, 1.0, s_hot, m_steps=m_ais, freq=1, rng=rng,
                                  schedule=(ais_ladder[::-1] if ais_ladder is not None else None))
            budget += int(n_land[b]) * m_eff
            Wr_acc.append(-np.asarray(lwr, float)); rl_acc.append(np.full(int(n_land[b]), b, int))
            Wr_gen_list.append(-np.asarray(lwr, float)); rl_gen_list.append(np.full(int(n_land[b]), b, int))
        Wr_gen = np.concatenate(Wr_gen_list) if Wr_gen_list else np.zeros(0)
        rl_gen = np.concatenate(rl_gen_list) if rl_gen_list else np.zeros(0, int)

        if (pergen or pergen_full) and Wr_acc:    # running endpoint-BAR pi after this generation
            _Wf = np.concatenate(Wf_acc); _lf = np.concatenate(lf_acc)
            _Wr = np.concatenate(Wr_acc); _rl = np.concatenate(rl_acc)
            _fe = basin_free_energies(_Wf, _lf, _Wr, _rl, 3)
            _pi = np.nan_to_num(np.asarray(_fe["pi"], float), nan=0.0)      # unresolved (no reverse) basin -> 0
            _pi = _pi / _pi.sum() if _pi.sum() > 0 else _pi
            pergen_pi.append(_pi.tolist()); pergen_budget.append(int(budget))
            if hot_diag and cum_hot_chunks:       # LEQ / TV of the CUMULATIVE hot walker vs cold BAR accuracy
                cum_hot = np.concatenate(cum_hot_chunks)
                d_cum = t.basin_of(cum_hot, bnd).astype(int)
                T_hot_cum = int(cum_hot.size)
                t2_hot = _seq_t2(d_cum, 50)
                leq_margin = T_hot_cum / (10.0 * t2_hot) if t2_hot > 0 else float("inf")
                pe_cum = np.bincount(d_cum, minlength=3).astype(float); pe_cum /= pe_cum.sum()
                d_gen = t.basin_of(cum_hot_chunks[-1], bnd).astype(int)
                pe_gen = np.bincount(d_gen, minlength=3).astype(float); pe_gen /= pe_gen.sum()
                hot_diag_list.append(dict(
                    gen=int(n_iter), budget=int(budget),
                    T_hot_cum=T_hot_cum, t2_hot=float(t2_hot),
                    leq_margin=float(leq_margin), leq_hot=bool(leq_margin >= 1.0),
                    tv_hot_cum=0.5 * float(np.sum(np.abs(pe_cum - p_hot_analytic))),
                    tv_hot_gen=0.5 * float(np.sum(np.abs(pe_gen - p_hot_analytic))),
                    pi=_pi.tolist(), pop_tv=0.5 * float(np.nansum(np.abs(_pi - analytic)))))
            if pergen_full:
                _fi = estimate_bais(C_run, np.nan_to_num(_pi, nan=1e-6), lag=LAG)["its"] if np.isfinite(_pi).all() else np.nan
                pergen_fix_its.append(float(_fi) if _fi is not None and np.isfinite(_fi) else np.nan)
                pergen_pair_its.append([_pair_its(Cpair_run[pk], LAG) for pk in range(len(PAIRS_IDX))])
                pergen_cross.append(cross_run.tolist())
            if pergen_diag and (n_iter % 5 == 0):     # raw per-5th-gen diagnostics (trajectory + overlap + pi)
                Wf_gen = np.asarray(Wf_acc[-1], float)                          # this gen's forward reduced works
                pergen_diag_list.append(dict(
                    gen=int(n_iter), budget=int(budget),
                    Wf=Wf_gen.tolist(), lf=np.asarray(land_b, int).tolist(),
                    Wr=np.asarray(Wr_gen, float).tolist(), rl=np.asarray(rl_gen, int).tolist(),
                    walker_theta=[np.asarray(w["acc"][-1], float).tolist() for w in walkers if w["acc"]],
                    walker_home=[int(w["home"]) for w in walkers if w["acc"]],
                    land_theta=np.asarray(land, float).tolist(), pi=_pi.tolist(),
                    ess_f=_ess_frac(-Wf_gen), ess_r=_ess_frac(-Wr_gen)))

    # (7) endpoint-restricted BAR on the accumulated pools
    Wf = np.concatenate(Wf_acc); lf = np.concatenate(lf_acc)
    Wr = np.concatenate(Wr_acc) if Wr_acc else np.zeros(0); rl = np.concatenate(rl_acc) if rl_acc else np.zeros(0, int)
    fe = basin_free_energies(Wf, lf, Wr, rl, 3)
    pi = np.asarray(fe["pi"], float)
    # a basin with forward landings but no reverse (no cold reservoir -> below the W_min resolution floor, e.g.
    # the 0.7% B well in the 5x toy) is UNRESOLVED -> report 0 population (its mass is the honest resolution error).
    pi = np.nan_to_num(pi, nan=0.0)
    pi = pi / pi.sum() if pi.sum() > 0 else pi

    # (8) kinetics: fixed-pi reversible MSM on the cold reservoir (C accumulated incrementally = _count_matrix)
    C = C_run
    its = estimate_bais(C, np.clip(pi, 1e-9, None), lag=LAG)["its"] if pi.sum() > 0 else np.nan

    # (9) POST-ANALYSIS (optional): resolve A1/A2 within the LEQ-confident A basin + their MSM free energy
    #     from the run's OWN accumulated cold reservoir (BAR already gave pi_A, pi_B; the MSM splits A1/A2).
    post_decomp = _post_decompose_A(walkers, t, bnd, lag=LAG) if post_decompose else None

    tv = 0.5 * float(np.nansum(np.abs(pi - analytic)))
    return dict(pi=pi.tolist(), pop_tv=tv, err_B=float(pi[0] - analytic[0]), post_decomp=post_decomp,
                its=float(its) if its is not None and np.isfinite(its) else np.nan,
                its_relerr=float(abs(its - its_true) / its_true) if (its is not None and np.isfinite(its)) else np.nan,
                n_iter=n_iter, n_seeded=nseed_tot, n_killed=nkill_tot, budget=int(budget), its_true=its_true,
                pergen_pi=pergen_pi, pergen_budget=pergen_budget, leq_kept=leq_kept,
                pergen_fix_its=pergen_fix_its, pergen_pair_its=pergen_pair_its, pergen_cross=pergen_cross,
                pergen_diag=pergen_diag_list, hot_diag=hot_diag_list,
                hot_frozen=bool(fz_frozen), freeze_gen=(int(fz_gen) if fz_gen is not None else None),
                hot_pool_size=(int(fz_pool.size) if fz_pool is not None else None),
                walker_trace=wtrace)


def _uniform_tv(pi, analytic):
    """TV of a (possibly nan-padded) population vector to the analytic pi, treating a MISSING basin as 0 population.
    Uniform across methods so BAIS is not silently credited for an unfound minor basin (contrast the per-method
    nansum TV)."""
    p = np.nan_to_num(np.asarray(pi, float), nan=0.0)
    return 0.5 * float(np.sum(np.abs(p - np.asarray(analytic, float))))


MID3X_KAPPA = np.array([70.0, 70.0, 30.0])        # 3× κ-retune (sharper wells, SAME populations)
HARD5X_KAPPA = np.array([114.0, 114.0, 45.0])     # 5× κ-retune: A1↔A2≈14.5 kT (=5× base), A↔B frozen, SAME pops
# UNIFIED hot ensemble + AIS ladder for ALL regimes: s_hot=0.01, √s-square spacing 0.01→1.0 (10 rungs).
AIS_LADDER = np.linspace(np.sqrt(0.01), 1.0, 10) ** 2   # = [0.01,0.04,...,1.0]; s_hot = ladder[0] = 0.01


def run(fast=False, nseed=4, hard=False, mid3x=False):
    budgets = [80_000, 200_000, 500_000] if fast else [100_000, 300_000, 1_000_000, 3_000_000]
    seeds = list(range(2 if fast else nseed))
    # regime = barrier height via κ-retune (populations ALWAYS preserved [0.25,0.42,0.33]); every regime uses the
    # SAME s_hot=0.01 hot ensemble and √s AIS ladder. base (κ=None), 3× (κ=[70,70,30]), 5× (κ=[114,114,45]).
    kappa = HARD5X_KAPPA if hard else (MID3X_KAPPA if mid3x else None)
    u_scale = 1.0
    ais_ladder = AIS_LADDER
    tag = "_hard" if hard else ("_mid3x" if mid3x else "")
    analytic = np.asarray((Toy1D(kappa=kappa) if kappa is not None else Toy1D()).populations()["pops"], float)
    # single-/multi-walker baselines live in the vs_walkers driver; import lazily to avoid a circular import
    from escort_ais.experiments.toy.demo_bais_vs_walkers_toy import single_run, multi_run
    A1 = 1                                            # basin index of A1 (basin_of order [B, A1, A2])
    methods = {
        "BAIS (all frames)":  lambda s, B: bais_protocol_run(s, B, hot_steps=10000, cold_chunk=10000,
                                                             u_scale=u_scale, ais_ladder=ais_ladder, kappa=kappa),
        "BAIS (LEQ-only)":    lambda s, B: bais_protocol_run(s, B, hot_steps=10000, cold_chunk=10000,
                                                             leq_filter=True, leq_cut=180,
                                                             u_scale=u_scale, ais_ladder=ais_ladder, kappa=kappa),
        "multi-walker (3×)":  lambda s, B: multi_run(s, B, u_scale=u_scale, kappa=kappa),
        "single-walker (A1)": lambda s, B: single_run(s, B, A1, u_scale=u_scale, kappa=kappa),
    }
    res = {}
    for m, fn in methods.items():
        res[m] = {}
        for B in budgets:
            runs = [fn(s, B) for s in seeds]
            pis = np.array([np.nan_to_num(r["pi"], nan=0.0) for r in runs], float)     # (nseed, 3), missing -> 0
            tv = np.array([_uniform_tv(r["pi"], analytic) for r in runs])
            med_pi = np.nanmedian(pis, axis=0)
            res[m][B] = dict(pi=med_pi.tolist(), tv=float(np.nanmedian(tv)),
                             errB=float(abs(med_pi[0] - analytic[0])))
        row = "  ".join(f"{B//1000}k:TV={res[m][B]['tv']:.3f},πB={res[m][B]['pi'][0]:.3f}" for B in budgets)
        print(f"  {m:20s} {row}", file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"bais_protocol_convergence{tag}_toy.json").write_text(json.dumps(
        {"budgets": budgets, "seeds": seeds, "analytic": analytic.tolist(), "methods": list(methods), "hard": hard,
         "mid3x": mid3x, "res": {m: {str(B): res[m][B] for B in budgets} for m in methods}}, indent=1))
    make_figure(budgets, res, list(methods), analytic, tag=tag, hard=hard, mid3x=mid3x)
    return res


def make_figure(budgets, res, methods, analytic, tag="", hard=False, mid3x=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    B = np.array(budgets, float)
    PB, PA1, PA2 = "#7a4fb0", "#1f6f1f", "#8fce8f"
    nrow = len(methods)
    fig, ax = plt.subplots(nrow, 2, figsize=(12.5, 2.9 * nrow), sharex=True)

    # shared error y-range so the four method rows are directly comparable
    allerr = [max(res[m][b]["tv"], 1e-4) for m in methods for b in budgets] + \
             [max(res[m][b]["errB"], 1e-4) for m in methods for b in budgets]
    elo, ehi = 0.5 * min(allerr), 2.0 * max(allerr)
    pmax = max(max(res[m][b]["pi"]) for m in methods for b in budgets)     # incl. a walker trapped at π≈1
    ymax_pop = max(0.5, 1.05 * max(pmax, float(np.max(analytic))))

    for i, m in enumerate(methods):
        a0, a1 = ax[i, 0], ax[i, 1]
        for bi, (an, col, lab) in enumerate([(analytic[0], PB, "B"), (analytic[1], PA1, "A1"), (analytic[2], PA2, "A2")]):
            a0.plot(B, [res[m][b]["pi"][bi] for b in budgets], "-o", color=col, ms=5, label=lab)
            a0.axhline(an, ls="--", color=col, lw=1.0, alpha=0.5)
        a0.set_xscale("log"); a0.set_ylim(0, ymax_pop); a0.set_ylabel("population $\\pi$"); a0.grid(alpha=0.3)
        a0.text(-0.26, 0.5, m, transform=a0.transAxes, fontsize=12, fontweight="bold", rotation=90,
                va="center", ha="center")

        a1.plot(B, [max(res[m][b]["tv"], 1e-4) for b in budgets], "-o", color="#b03030", label="population TV")
        a1.plot(B, [max(res[m][b]["errB"], 1e-4) for b in budgets], "-s", color=PB, label="|$\\pi_B$ err|")
        a1.set_xscale("log"); a1.set_yscale("log"); a1.set_ylim(elo, ehi); a1.set_ylabel("error")
        a1.grid(alpha=0.3, which="both")
        if i == 0:
            a0.set_title("per-basin populations $\\to$ analytic (dashed)"); a0.legend(fontsize=8, ncol=3, loc="upper right")
            a1.set_title("convergence: TV and minor-basin error $\\downarrow$"); a1.legend(fontsize=8, loc="upper right")
    for a in ax[-1, :]:
        a.set_xlabel("total budget (force-evals)")

    toy = ("3$\\times$ $\\kappa$-retune toy ($\\pi{=}[0.25,0.42,0.33]$ preserved)" if mid3x else
           ("$5\\times$-barrier toy ($U\\to5U$, $\\pi_B{=}0.7\\%$)" if hard else "1-D toy"))
    fig.suptitle(f"Convergence vs total budget on the {toy}: BAIS (all-frames), BAIS (LEQ-only), multi-walker, and "
                 "single-walker.\nOne method per row; per-basin populations (left) and error (right), median over "
                 "seeds. A missing basin counts as $\\pi{=}0$ in the TV.", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / f"fig_bais_protocol_convergence{tag}_toy.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / ('fig_bais_protocol_convergence' + tag + '_toy.png')}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv, hard="--hard" in sys.argv, mid3x="--mid3x" in sys.argv)
