#!/usr/bin/env python3
"""demo_1x_ground_truth_toy.py — Fig 1 (ground truth) of the BASE (1x) bAIS toy report.

Writes results/toy/fig_ground_truth.png for the base toy Toy1D() (kappa=[26,26,9]):
  (A) cold potential U_cold(theta) with the three wells A1(60), A2(120), B(-120) and the barrier heights labelled
      (internal A1<->A2 ~= 2.9 kT; A<->B ~= 7.1 kT on the low path via A2, 13.6 kT on the high path via A1).
  (B) cold density P(theta) (the target) with the analytic populations [B 0.25, A1 0.42, A2 0.33] shaded per basin,
      plus the s=0.01 hot ensemble density (the nearly-uniform ensemble the forward AIS switch starts from — the
      production protocol anneals it back along the 10-rung sqrt(s)-square ladder s=0.01->1).

The hot overlay is the UNIFIED s=0.01 hot ensemble (shared with the 3x/5x companions), NOT the legacy s=0.2 one.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_1x_ground_truth_toy
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D

# Unified hot ensemble + AIS ladder (mirrors demo_bais_protocol_convergence_toy.AIS_LADDER; defined locally so this
# standalone driver is self-contained). s_hot = AIS_LADDER[0] = 0.01, sqrt(s)-square 0.01 -> 1.
AIS_LADDER = np.linspace(np.sqrt(0.01), 1.0, 10) ** 2
S_HOT = float(AIS_LADDER[0])                                          # = 0.01

OUT = project_root() / "results/toy"
BCOL = {"B": "#7a4fb0", "A1": "#1f6f1f", "A2": "#8fce8f"}
BNAMES = ["B", "A1", "A2"]                                            # basin_of index order


def run():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = Toy1D()                                                      # base toy: kappa=[26,26,9]
    ana = t.populations(); pops = ana["pops"]                        # [B, A1, A2] = [0.25, 0.42, 0.33]
    bnd = np.radians(ana["boundaries_deg"])
    wells = np.radians(ana["well_centers_deg"])                      # [B(-120), A1(60), A2(120)]
    mins, maxs = t.extrema(3600)

    th = np.linspace(-np.pi, np.pi, 1600); deg = np.degrees(th)
    dx = th[1] - th[0]
    U = t.U_cold(th); Umin = U.min(); U = U - Umin                   # potential, global min at 0
    p_cold = np.exp(-t.U_cold(th) / t.kT); p_cold /= p_cold.sum() * dx
    p_hot = np.exp(-S_HOT * t.U_cold(th) / t.kT); p_hot /= p_hot.sum() * dx   # s=0.01 hot density (nearly uniform)

    kin = t.smoluchowski_kinetics(); t_AB, t_A1A2 = float(kin["t_AB"]), float(kin["t_A1A2"])

    fig, ax = plt.subplots(1, 2, figsize=(15, 5.0))

    # ── (A) cold potential with wells + labelled barrier heights ─────────────────────────────────────
    ax[0].plot(deg, U, "k-", lw=2.2)
    well_col = "#1f6f1f"
    for nm, mu in (("B", -120.0), ("A1", 60.0), ("A2", 120.0)):      # well markers
        yv = float(t.U_cold(np.radians([mu]))[0] - Umin)
        ax[0].scatter([mu], [yv], s=110, color=well_col, zorder=5)
        ax[0].annotate(nm, (mu, yv), textcoords="offset points", xytext=(0, -20),
                       ha="center", color=well_col, fontweight="bold", fontsize=12)
    # barrier markers: label each maximum with its height above the global minimum + which pair it separates
    bar_labels = {}                                                  # nearest-deg -> "(pair) h kT"
    for mu, tag in ((90.6, "A1$\\leftrightarrow$A2"), (166.4, "A$\\leftrightarrow$B (low)"),
                    (-4.8, "A$\\leftrightarrow$B (high)")):
        bar_labels[round(mu)] = tag
    first_bar = True
    for mb in np.degrees(np.sort(maxs)):
        yv = float(t.U_cold(np.radians([mb]))[0] - Umin)
        ax[0].scatter([mb], [yv], s=90, marker="^", color="#b03030", zorder=5,
                      label="barriers" if first_bar else None)
        tag = bar_labels.get(round(mb), "")
        ax[0].annotate(f"{yv:.1f} kT\n{tag}", (mb, yv), textcoords="offset points", xytext=(0, 8),
                       ha="center", fontsize=8.5, color="#8a1a1a")
        first_bar = False
    ax[0].scatter([], [], s=110, color=well_col, label="wells")
    ax[0].set_xlim(-180, 180); ax[0].set_ylim(-1.0, 16.5)           # headroom so the tall-barrier label clears the title
    ax[0].set_xlabel("$\\theta$ (deg)"); ax[0].set_ylabel("$U_{\\mathrm{cold}}(\\theta)$ ($k_BT$)")
    ax[0].set_title("cold potential: internal $A_1\\!\\leftrightarrow\\!A_2\\approx2.9\\,k_BT$, "
                    "$A\\!\\leftrightarrow\\!B\\approx7.1\\,k_BT$ (low) / $13.6\\,k_BT$ (high)", fontsize=10)
    ax[0].legend(fontsize=9, loc="upper right"); ax[0].grid(alpha=0.3)

    # ── (B) cold density with shaded basins + populations, and the s=0.01 hot ensemble overlay ────────
    labc = t.basin_of(th, bnd).astype(int)
    for b, nm in enumerate(BNAMES):
        m = labc == b
        ax[1].fill_between(deg, 0, p_cold, where=m, color=BCOL[nm], alpha=0.5)
    ax[1].plot(deg, p_cold, "k-", lw=1.8, label="cold $P(\\theta)$ (target)")
    ax[1].plot(deg, p_hot, "-", color="#b03030", lw=2.0,
               label=f"hot ensemble ($s\\!=\\!{S_HOT:g}$): nearly uniform")
    # population labels above each well
    for nm, mu in (("B", -120.0), ("A1", 60.0), ("A2", 120.0)):
        b = BNAMES.index(nm); yv = float(np.interp(mu, deg, p_cold))
        ax[1].annotate(f"{nm}\n{pops[b]*100:.0f}%", (mu, yv), textcoords="offset points", xytext=(0, 6),
                       ha="center", color=BCOL[nm] if nm != "A2" else "#5a9a5a", fontweight="bold", fontsize=11)
    ax[1].set_xlim(-180, 180); ax[1].set_ylim(0, float(p_cold.max()) * 1.22)   # headroom for the population labels
    ax[1].set_xlabel("$\\theta$ (deg)")
    ax[1].set_ylabel("density"); ax[1].set_title("cold density $P(\\theta)$ with analytic populations "
                                                 "$[B,A_1,A_2]=[0.25,0.42,0.33]$", fontsize=10)
    ax[1].legend(fontsize=9, loc="upper left"); ax[1].grid(alpha=0.3)

    fig.suptitle("Base 1D toy ground truth — major basin $A=\\{A_1(60^\\circ),A_2(120^\\circ)\\}$ + minor $B(-120^\\circ)$; "
                 f"analytic, REMD-free (slow $t_{{AB}}/t_{{A_1A_2}}\\approx{t_AB/t_A1A2:.0f}$)", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_ground_truth.png", dpi=160); plt.close(fig)
    print(f"  wrote {OUT / 'fig_ground_truth.png'}  (pops [B,A1,A2]={np.round(pops,3).tolist()}, "
          f"t_AB={t_AB:.0f}, t_A1A2={t_A1A2:.0f}, s_hot={S_HOT:g})", file=sys.stderr)


if __name__ == "__main__":
    run()
