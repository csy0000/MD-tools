#!/usr/bin/env python3
"""demo_bais_msm_toy.py — validate the REMD-free bAIS+MSM tool (thermodynamics + kinetics) on the 1D toy.

Pipeline:
  * seed unrestrained cold MD from each state's medoid (well center), several walkers per state;
  * read the KINETIC structure directly from the cold trajectories' basin↔basin crossing counts: A1↔A2 crosses
    readily (fast-intra ~2.9 kT → merge into one basin A), A↔B crosses only rarely (~7.1 kT → B stays a separate,
    weakly-connected basin);
  * POPULATIONS: cold MD alone cannot equilibrate across the slow A↔B barrier, so raw cold-seed populations are a seeding
    artifact. bAIS fixes it — a HOT MSM (hot crosses every barrier) gives π_hot, forward+reverse AIS give per-basin
    BAR ΔF, and `tram_cold_populations` combines them into the correct cold populations;
  * KINETICS: the cold MD recovers the FAST A1↔A2 rate (direct MFPT); the SLOW A↔B rate is poorly sampled by cold
    MD — the hot MSM (crosses every barrier) resolves it (the "with-bAIS/hot" kinetics).

Run in the SAMPLABLE regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT) — the single system used throughout this PDF.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_msm_toy
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.state_detect import spring_constants  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402
from escort_ais.methods.tram_basin import hot_basin_msm, implied_timescales_basin, tram_cold_populations  # noqa: E402


OUT = ROOT / "results/toy"


def basin_crossings(basin_trajs, nb):
    """Pooled within-trajectory basin↔basin transition counts (lag 1), symmetrised off-diagonal."""
    C = np.zeros((nb, nb), int)
    for b in basin_trajs:
        np.add.at(C, (b[:-1], b[1:]), 1)
    return C


def mfpt_direct(basin_traj, src, dst):
    """Mean first-passage time (frames) src→dst (nan if never observed)."""
    fpts, clock = [], None
    for b in basin_traj:
        if b == src and clock is None:
            clock = 0
        elif clock is not None:
            clock += 1
            if b == dst:
                fpts.append(clock); clock = None
    return float(np.mean(fpts)) if fpts else float("nan")


KAPPA = np.array([26.0, 26.0, 9.0])                                  # samplable regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)


def run(seed=0, hot_steps=120000, cold_steps=30000, cold_walkers=4, ais_k=5000, m_steps=60, freq=4):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations()
    bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    a1, a2, B = 1, 2, 0                                               # basin indices: A1@60, A2@120, B@-120

    # --- HOT MSM (one long hot walker mixes all basins) → π_hot + hot timescales ---
    hot = wrap(t.langevin(np.array([0.0]), hot_steps, t.s_hot, rng)[:, 0])
    hb = t.basin_of(hot, bnd).astype(int)
    _, pi_hot, _ = hot_basin_msm(hb, nb, lag=20)
    its_hot = implied_timescales_basin(hb, nb, lags=[20]).ravel()     # hot basin timescales (frames)

    # --- BAR ΔF per basin (forward+reverse AIS; reverse from flat-bottom US equilibrium) → bAIS cold pops ---
    xh = t.sample_boltzmann(t.s_hot, ais_k, rng)
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps, freq, rng); Wf = -lwf; lb = t.basin_of(land, bnd)
    dF = np.zeros(nb)
    hw_us = np.full(nb, np.radians(30.0))                             # flat-bottom half-width per state
    order = np.argsort(wells)
    kspring = np.empty(nb)                                            # distance-calibrated springs (e_target=8 kT)
    kspring[order] = spring_constants(np.asarray(wells)[order], hw_us[order], e_target=8.0)
    print(f"  [bais_msm] centers_deg={np.round(np.degrees(wells),0)} kspring={np.round(kspring,2)}", file=sys.stderr)
    for b in range(nb):
        us = t.us_sample(wells[b], hw_us[b], 3000, rng, k=float(kspring[b]), burn=800, walkers=1)
        _, lwr = t.ais_switch(us, 1.0, t.s_hot, m_steps, freq, rng)
        dF[b], _ = solve_bar_with_infinite_works(np.where(lb == b, Wf, np.inf), -lwr,
                                                 n_f_total=len(Wf), n_r_total=us.size)
    _, pi_cold = tram_cold_populations(pi_hot, dF - dF[0])

    # --- COLD MD from medoid seeds (several walkers per state) ---
    cold_x, cold_b = [], []
    for b in range(nb):
        traj = t.langevin(np.full(cold_walkers, wells[b]), cold_steps, 1.0, rng)   # (steps, walkers)
        for wk in range(cold_walkers):
            x = wrap(traj[:, wk]); cold_x.append(x); cold_b.append(t.basin_of(x, bnd))
    pi_cold_raw = np.array([np.mean(np.concatenate(cold_b) == b) for b in range(nb)])
    Cx = basin_crossings(cold_b, nb)                                  # basin↔basin crossing counts (cold)
    off = Cx + Cx.T - np.diag(np.diag(Cx + Cx.T))
    ab = off[a1, B] + off[a2, B]
    merged = off[a1, a2] > 20 and ab < 0.15 * off[a1, a2]          # A1↔A2 many crossings, A↔B ≳10× rarer

    # --- kinetics: A1↔A2 MFPT direct (cold) vs the hot MSM A↔B (cold can't see it) ---
    long_cold = t.basin_of(wrap(t.langevin(np.full(1, wells[a1]), 200000, 1.0, rng)[:, 0]), bnd)
    mfpt_A1A2 = mfpt_direct(long_cold, a1, a2)

    _, maxs = t.extrema(); mh = t.U_cold(maxs) - t.U_cold(np.radians(ana["well_centers_deg"])).min()
    md = np.degrees(np.sort(maxs)); mv = mh[np.argsort(maxs)]
    ab_kT = round(float(mv[(md > 120) | (md < -120)].min()), 1)       # lower A↔B barrier
    a12_kT = round(float(mv[(md > 60) & (md < 120)][0]), 1)           # A1↔A2 internal barrier
    res = dict(
        seed=seed, n_basins=nb, regime="samplable", ab_barrier_kT=ab_kT, internal_barrier_kT=a12_kT,
        analytic_pops=[round(x, 3) for x in ana["pops"]],
        pi_cold_bais=[round(x, 3) for x in pi_cold],
        pi_cold_raw=[round(x, 3) for x in pi_cold_raw],
        pops_tv=dict(bais=round(0.5 * float(np.abs(pi_cold - ana["pops"]).sum()), 3),
                     raw_cold=round(0.5 * float(np.abs(pi_cold_raw - ana["pops"]).sum()), 3)),
        cold_crossings=dict(A1_A2=int(off[a1, a2]), A1_B=int(off[a1, B]), A2_B=int(off[a2, B])),
        merge_split=f"A1↔A2 merge (fast-intra); B weakly connected (A↔B ~{off[a1,a2]//max(ab,1)}× rarer)"
                    if merged else "check crossings",
        kinetics=dict(A1A2_mfpt_cold_frames=round(mfpt_A1A2, 0),
                      hot_msm_timescales_frames=[round(float(x), 1) for x in its_hot],
                      note=f"cold MD crosses A↔B only rarely (barrier {ab_kT} kT); the A↔B timescale is resolved "
                           "cleanly by the hot MSM → the with-bAIS/hot kinetics"))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "bais_msm_toy.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
    make_figure(t, ana, cold_x, cold_b, off, pi_cold, pi_cold_raw, res, a1, a2, B)
    return res


def make_figure(t, ana, cold_x, cold_b, off, pi_cold, pi_cold_raw, res, a1, a2, B):
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))
    cmap = {a1: "C0", a2: "C1", B: "C3"}
    # (A) cold trajectories in θ vs time — A1↔A2 hops but no A↔B crossing
    for x, b in zip(cold_x, cold_b):
        ax[0].plot(np.degrees(x[::40]), np.arange(len(x[::40])), ",", color=cmap[int(b[0])], alpha=0.5)
    for yb in ana["boundaries_deg"]:
        ax[0].axvline(yb, ls=":", c="0.6", lw=1)
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("cold-MD frame (×40)"); ax[0].set_xlim(-180, 180)
    ax[0].set_title(f"cold MD from medoid seeds (A1 blue, A2 orange, B red)\n"
                    f"crossings A1↔A2={res['cold_crossings']['A1_A2']}, "
                    f"A↔B={res['cold_crossings']['A1_B'] + res['cold_crossings']['A2_B']}", fontsize=9.5)
    # (B) populations: raw cold-seed vs bAIS vs analytic
    xb = np.arange(res["n_basins"]); bw = 0.27
    ax[1].bar(xb - bw, ana["pops"], bw, color="k", alpha=0.6, label="analytic")
    ax[1].bar(xb, pi_cold, bw, color="C0", label=f"bAIS (TV {res['pops_tv']['bais']})")
    ax[1].bar(xb + bw, pi_cold_raw, bw, color="0.5", label=f"raw cold-seed (TV {res['pops_tv']['raw_cold']})")
    ax[1].set_xticks(xb); ax[1].set_xticklabels([f"state {b}\n{ana['well_centers_deg'][b]:.0f}°"
                                                 for b in range(res["n_basins"])], fontsize=8)
    ax[1].set_ylabel("cold population"); ax[1].legend(fontsize=8)
    ax[1].set_title("populations: bAIS correct; raw cold-seed = seeding artifact\n(cold MD barely crosses A↔B)",
                    fontsize=9.5)
    # (C) basin↔basin cold crossing counts (merge/split) — A1↔A2 hot, A↔B zero
    im = ax[2].imshow(off, cmap="viridis")
    for i in range(off.shape[0]):
        for j in range(off.shape[1]):
            ax[2].text(j, i, int(off[i, j]), ha="center", va="center",
                       color="w" if off[i, j] < off.max() / 2 else "k", fontsize=11, fontweight="bold")
    lab = {a1: "A1", a2: "A2", B: "B"}
    ticks = [lab[i] for i in range(res["n_basins"])]
    ax[2].set_xticks(range(res["n_basins"])); ax[2].set_xticklabels(ticks)
    ax[2].set_yticks(range(res["n_basins"])); ax[2].set_yticklabels(ticks)
    fig.colorbar(im, ax=ax[2], fraction=0.046, pad=0.04, label="cold crossings")
    k = res["kinetics"]
    ax[2].set_title(f"cold basin↔basin crossings → {res['merge_split']}\n"
                    f"A1↔A2 MFPT(cold)={k['A1A2_mfpt_cold_frames']:.0f}; hot ts (A↔B, A1↔A2)="
                    f"{k['hot_msm_timescales_frames']}", fontsize=9)
    fig.suptitle("bAIS+MSM on the 1D toy — REMD-free thermodynamics + kinetics "
                 "(medoid-seeded MSM; merge/split; hot-MSM+BAR populations)", fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_bais_msm_toy.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_msm_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
