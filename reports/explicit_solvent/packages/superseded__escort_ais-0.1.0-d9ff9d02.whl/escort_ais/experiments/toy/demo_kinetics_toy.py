#!/usr/bin/env python3
"""demo_kinetics_toy.py — estimate implied timescales from DIRECT cold MD (no enhanced sampling) on the toy.

Uses the SAMPLABLE-barrier toy (A↔B lowered to ~7.1 kT, A1↔A2 ~2.9 kT) so both transitions are crossed enough
times within 5 M cold steps to build a cold MSM and read off the implied timescales — validated against the direct
mean-first-passage relaxation times measured from the same trajectories.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_kinetics_toy
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.msm_estimation import fit_reversible_msm  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402

OUT = ROOT / "results/toy"


def mfpt(traj, src, dst):
    fpts, clock = [], None
    for b in traj:
        if b == src and clock is None:
            clock = 0
        elif clock is not None:
            clock += 1
            if b == dst:
                fpts.append(clock); clock = None
    return (np.mean(fpts) if fpts else np.nan), len(fpts)


def relax_time(traj, s0, s1):
    """Two-state relaxation timescale 1/(k01+k10) from the two MFPTs (frames)."""
    m01, n01 = mfpt(traj, s0, s1); m10, n10 = mfpt(traj, s1, s0)
    if not np.isfinite(m01) or not np.isfinite(m10):
        return np.nan, min(n01, n10)
    return 1.0 / (1.0 / m01 + 1.0 / m10), min(n01, n10)


def core_fill(x, centers, hw):
    """Last-core label per frame (recrossing-free): assign to a core within hw of its center, else forward-fill
    the previous core. Barrier-top flicker no longer creates transitions. x, centers, hw in radians."""
    lab = np.full(len(x), -1)
    for i, c in enumerate(centers):
        lab[np.abs(wrap(x - c)) < hw] = i
    idx = np.where(lab >= 0, np.arange(len(x)), -1)
    np.maximum.accumulate(idx, out=idx)
    return np.where(idx >= 0, lab[np.clip(idx, 0, None)], -1)


def run(seed=0, walkers=20, steps=250000, nbin=36):
    t = Toy1D(kappa=np.array([26.0, 26.0, 9.0]))                     # samplable regime: A↔B ~7.1 kT, A1↔A2 ~2.9 kT
    rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    total = walkers * steps
    # --- 5M-frame cold MD: seed walkers spread across the wells, unrestrained ---
    x0 = wrap(np.concatenate([np.full(walkers // 3 + 1, w) for w in wells])[:walkers])
    traj = t.langevin(x0, steps, 1.0, rng)                           # (steps, walkers)
    dtrajs = [np.clip(np.digitize(wrap(traj[:, k]), np.linspace(-np.pi, np.pi, nbin + 1)) - 1, 0, nbin - 1)
              for k in range(walkers)]
    # --- direct relaxation timescales from CORE states (recrossing-free), same frame units as the MSM ---
    hw = np.radians(22.0)
    cores = [core_fill(wrap(traj[:, k]), wells, hw) for k in range(walkers)]   # 0=B,1=A1,2=A2 (last-core)
    lump = [np.where(c == 0, 0, np.where(c > 0, 1, -1)) for c in cores]        # 0=B, 1=A={A1,A2}
    ab = [relax_time(l, 1, 0) for l in lump]                         # A↔B
    a12 = [relax_time(c, 1, 2) for c in cores]                       # A1↔A2
    t_ab = np.nanmean([x[0] for x in ab]); n_ab = int(np.nansum([mfpt(l, 1, 0)[1] + mfpt(l, 0, 1)[1] for l in lump]))
    t_a12 = np.nanmean([x[0] for x in a12]); n_a12 = int(np.nansum([mfpt(c, 1, 2)[1] + mfpt(c, 2, 1)[1] for c in cores]))

    # --- MSM implied timescales vs lag ---
    lags = [50, 100, 200, 500, 1000, 2000, 4000]
    its = []
    for lag in lags:
        try:
            ts = np.sort(fit_reversible_msm(dtrajs, lag=lag).model.timescales())[::-1]
            its.append([float(ts[0]), float(ts[1])])
        except Exception:
            its.append([np.nan, np.nan])
    its = np.array(its)
    plateau = lags.index(500)                                        # a lag in the flat, resolved region for both

    res = dict(seed=seed, total_frames=total, nbin=nbin,
               ab_barrier_kT=7.1, internal_barrier_kT=2.9,
               n_crossings=dict(A_B=n_ab, A1_A2=n_a12),
               direct_relax_frames=dict(A_B=round(t_ab, 0), A1_A2=round(t_a12, 0)),
               msm_its_plateau_frames=[round(its[plateau, 0], 0), round(its[plateau, 1], 0)],
               msm_its_vs_direct=dict(A_B=f"{its[plateau,0]:.0f} vs {t_ab:.0f}",
                                      A1_A2=f"{its[plateau,1]:.0f} vs {t_a12:.0f}"),
               verdict=f"in {total/1e6:.0f}M cold steps: {n_ab} A↔B and {n_a12} A1↔A2 crossings → both implied "
                       f"timescales estimable without enhanced sampling")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "kinetics_toy.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
    make_figure(lags, its, t_ab, t_a12, res)
    return res


def make_figure(lags, its, t_ab, t_a12, res):
    fig, ax = plt.subplots(figsize=(8.5, 6.0))
    ax.plot(lags, its[:, 0], "-o", c="C0", label="MSM ITS #1 (A↔B)")
    ax.plot(lags, its[:, 1], "-s", c="C1", label="MSM ITS #2 (A1↔A2)")
    ax.axhline(t_ab, ls="--", c="C0", alpha=0.6, label=f"direct A↔B relax = {t_ab:.0f}")
    ax.axhline(t_a12, ls="--", c="C1", alpha=0.6, label=f"direct A1↔A2 relax = {t_a12:.0f}")
    ax.plot(lags, lags, ":", c="0.6", label="ITS = lag (resolution limit)")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("MSM lag (frames)"); ax.set_ylabel("implied timescale (frames)")
    ax.set_title(f"direct cold-MD implied timescales — samplable regime (A↔B {res['ab_barrier_kT']} kT)\n"
                 f"{res['total_frames']/1e6:.0f}M steps: {res['n_crossings']['A_B']} A↔B + "
                 f"{res['n_crossings']['A1_A2']} A1↔A2 crossings → ITS plateau matches direct relax "
                 f"(no enhanced sampling)", fontsize=10)
    ax.legend(fontsize=8, loc="best")
    panel_labels(fig); fig.tight_layout()
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_kinetics_toy.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_kinetics_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
