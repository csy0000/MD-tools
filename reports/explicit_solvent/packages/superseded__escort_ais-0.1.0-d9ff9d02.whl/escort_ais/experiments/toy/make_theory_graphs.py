#!/usr/bin/env python3
"""make_theory_graphs.py — star-graph illustrations of the two bAIS estimators' state connectivity.

Both graphs share the same HOT/COLD colour scheme and a left-to-right flow:
    HOT  --AIS (multi-step perturbation)-->  COLD  --one-step perturbation-->  { peripheral states }.

fig_theory_graph_us.png  (BAUS = bAIS+US, thermodynamic): the COLD ensemble node is a *transparent, dashed*
    intermediary — in BAUS we never sample its equilibrium directly; the AIS only bridges hot->cold, and each
    UMBRELLA restricts the cold ensemble to a small phase-space window per basin (one-step bias w_b). A pairwise
    hot<->basin BAR gives pi_b, then WHAM (with the F_b fixed) reconstructs the PMF.
fig_theory_graph_msm.png (bAIS+MSM, kinetic): the COLD ensemble node is *solid* — cold MD is sampled directly and
    resolved into Markov states joined by transition-count edges c_ij (the cold MSM). TRAM couples it with the hot
    equilibrium; counts come only from cold.

    conda activate escort-ais && python -m escort_ais.experiments.toy.make_theory_graphs
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
OUT = ROOT / "results/toy"
OUT.mkdir(parents=True, exist_ok=True)

HOT_FC = "#e39a8f"      # shared hot colour (both figures)
COLD_FC = "#8db9e2"     # shared cold colour (both figures)
US_FC = "#cfe0f2"       # umbrella = cold + bias
MK_FC = "#eef5fb"       # cold Markov microstate (sits on the solid cold node)


def _node(ax, xy, r, label, fc, sub=None, fs=12, alpha=1.0, ls="solid", ec="0.25", lw=1.7):
    ax.add_patch(Circle(xy, r, fc=fc, ec=ec, lw=lw, ls=ls, zorder=3, alpha=alpha))
    ax.text(xy[0], xy[1] + (0.10 if sub else 0), label, ha="center", va="center", fontsize=fs,
            fontweight="bold", zorder=5)
    if sub:
        ax.text(xy[0], xy[1] - 0.20, sub, ha="center", va="center", fontsize=7.6, zorder=5, color="0.3")


def _edge(ax, a, b, rad, color, lw, style="-", arrow="<->", z=2, alpha=1.0, sA=30, sB=30):
    ax.add_patch(FancyArrowPatch(a, b, connectionstyle=f"arc3,rad={rad}", arrowstyle=arrow,
                                 mutation_scale=15, lw=lw, color=color, ls=style, zorder=z,
                                 shrinkA=sA, shrinkB=sB, alpha=alpha))


def graph_us(ax):
    hot = (-4.3, 0.0); cold = (-1.2, 0.0)
    usp = [(2.6, 1.9), (3.5, 0.0), (2.6, -1.9)]; uslab = ["US$_{A_1}$", "US$_{A_2}$", "US$_{B}$"]
    # nodes
    _node(ax, hot, 0.72, "HOT", HOT_FC, sub="s=0.2, $f_0{\\equiv}0$", fs=13)
    _node(ax, cold, 1.05, "COLD", COLD_FC, sub="AIS target —\nnot eq.-sampled", fs=13, alpha=0.30, ls=(0, (5, 4)),
          ec="#2f6aa6", lw=2.2)
    for p, l in zip(usp, uslab):
        _node(ax, p, 0.5, l, US_FC, sub="cold + $w_b$")
    # hot <-> cold : AIS (multi-step), solid thick
    _edge(ax, hot, cold, 0.0, "#b0361f", 3.0, arrow="<->", sA=42, sB=62)
    ax.text(-2.75, 0.42, "AIS\n(multi-step)", color="#b0361f", fontsize=10, ha="center", fontweight="bold")
    ax.text(-2.75, -0.55, "$W_f\\;/\\;W_r$", color="#b0361f", fontsize=9, ha="center")
    # cold <-> US : one-step perturbation (restrict), dashed
    for p in usp:
        _edge(ax, cold, p, 0.0, "#2f6aa6", 1.8, style=(0, (4, 3)), arrow="<->", sA=62, sB=30)
    ax.text(1.15, 1.55, "one-step $\\pm U_{US}=\\pm w_b$", color="#2f6aa6", fontsize=9.5, rotation=27)
    ax.text(1.5, -1.15, "(restrict to basin)", color="#2f6aa6", fontsize=8.5, rotation=-27)
    # US <-> US overlap
    for i in range(3):
        _edge(ax, usp[i], usp[(i + 1) % 3], 0.24, "0.5", 1.4, arrow="<->", z=1, alpha=0.8)
    ax.text(4.35, 0.0, "US$\\leftrightarrow$US\none-step\n$\\Delta U{=}w_b{-}w_a$", color="0.4", fontsize=7.5,
            ha="left", va="center")
    # titles
    ax.text(0, 3.15, "BAUS  (bAIS+US)  —  thermodynamic estimator", ha="center", fontsize=14, fontweight="bold")
    ax.text(0, 2.72, "HOT —AIS (multi-step)→ COLD —one-step $w_b$→ umbrella windows;   "
            "pairwise hot↔basin BAR → $\\pi_b$, then WHAM (fixed $F_b$) → PMF", ha="center", fontsize=9.5, color="0.3")
    ax.text(0, -3.0, "each umbrella confines the large COLD phase space to a small window per basin (note the node "
            "sizes); the COLD equilibrium itself is never sampled in BAUS", ha="center", fontsize=9, color="0.4",
            style="italic")
    ax.set_xlim(-5.6, 6.2); ax.set_ylim(-3.4, 3.5); ax.set_aspect("equal"); ax.axis("off")


def graph_msm(ax):
    hot = (-4.1, 0.0)
    # solid COLD ensemble node = a rounded box that is directly sampled and resolved into Markov states
    box_xy, box_w, box_h = (1.35, 0.0), 5.0, 4.2
    ax.add_patch(FancyBboxPatch((box_xy[0] - box_w / 2, box_xy[1] - box_h / 2), box_w, box_h,
                                boxstyle="round,pad=0.15,rounding_size=0.5", fc=COLD_FC, ec="#2f6aa6", lw=2.2,
                                alpha=0.92, zorder=1))
    ax.text(box_xy[0], box_h / 2 - 0.32, "COLD ensemble  (directly sampled)", ha="center", fontsize=11,
            fontweight="bold", color="#173a5e", zorder=4)
    _node(ax, hot, 0.72, "HOT", HOT_FC, sub="equilibrium\n(no counts)", fs=13)
    # cold Markov states inside the box
    mk = [(-0.15, 1.05), (-0.15, -1.05), (2.85, 0.0)]; mklab = ["$A_1$", "$A_2$", "$B$"]
    for p, l in zip(mk, mklab):
        _node(ax, p, 0.52, l, MK_FC, sub="microstate", fs=13, ec="#2f6aa6", lw=1.8)
    # transition-count edges c_ij (width ~ counts)
    counts = {(0, 1): 972, (1, 2): 12, (0, 2): 0}
    clab = {(0, 1): "$c_{A_1A_2}{\\approx}972$", (1, 2): "$c_{A_2B}{\\approx}12$", (0, 2): "$c_{A_1B}{\\approx}0$"}
    for (i, j), ct in counts.items():
        lw = 1.0 + 3.4 * (ct / 715) ** 0.4
        col = "#1a7a34" if ct > 100 else ("#d9791f" if ct > 0 else "0.7")
        _edge(ax, mk[i], mk[j], 0.16, col, lw, arrow="<->", z=2, sA=30, sB=30)
        m = (0.5 * (mk[i][0] + mk[j][0]), 0.5 * (mk[i][1] + mk[j][1]))
        ax.text(m[0] + (0.5 if j == 2 else 0), m[1], clab[(i, j)], ha="center", fontsize=8.2, color=col, zorder=5,
                bbox=dict(boxstyle="round,pad=0.1", fc="white", ec="none", alpha=0.7))
    # hot <-> cold : BIDIRECTIONAL AIS (forward hot->cold + reverse cold->hot), two multi-step arrows
    cl = (box_xy[0] - box_w / 2, 0.0)
    # forward AIS hot->cold bulges DOWN (arc3 positive rad, rightward travel); reverse cold->hot bulges UP.
    _edge(ax, hot, cl, 0.34, "#b0361f", 2.6, arrow="-|>", sA=44, sB=8)      # forward AIS  hot -> cold (curves down)
    _edge(ax, cl, hot, 0.34, "#2f6aa6", 2.4, arrow="-|>", sA=8, sB=44)      # reverse AIS  cold -> hot (curves up)
    ax.text(-2.55, 1.15, "reverse AIS  $W_r$", color="#2f6aa6", fontsize=9.5, ha="center", fontweight="bold")
    ax.text(-2.55, -1.08, "forward AIS  $W_f$", color="#b0361f", fontsize=9.5, ha="center", fontweight="bold")
    ax.text(-2.55, -1.40, "+ last-step (step; LEQ)", color="#1a7a34", fontsize=7.5, ha="center")
    ax.text(-2.55, 0.03, "bidirectional AIS\n(multi-step); iterated\nwith the MSM (BAIS)", color="0.35",
            fontsize=8, ha="center")
    # inset: the last-step perturbation — BAUS smooth umbrella wall vs BAIS step function (basin indicator)
    iax = ax.inset_axes([0.60, 0.02, 0.38, 0.20])
    xx = np.linspace(-2, 2, 500); hw = 0.75
    iax.plot(xx, np.minimum(0.5 * 9 * np.maximum(0.0, np.abs(xx) - hw) ** 2, 6), color="#2f6aa6", lw=2.2,
             label="BAUS: umbrella $w_b$")
    iax.plot(xx, np.where(np.abs(xx) <= hw, 0.15, 6.0), color="#1a7a34", lw=2.2, label="BAIS: step ($\\infty$ out)")
    iax.axvspan(-hw, hw, color="0.9", zorder=0)
    iax.text(0, 0.7, "basin $\\mathcal{B}_b$", fontsize=6.5, ha="center", color="0.4")
    iax.set_ylim(-0.4, 7.6); iax.set_xticks([]); iax.set_yticks([])
    iax.set_title("last-step perturbation $U_{\\rm last}$", fontsize=8.5)
    iax.legend(fontsize=6.2, loc="upper center", handlelength=1.2, borderpad=0.3)
    # titles
    ax.text(0, 3.15, "BAIS  (bidirectional annealing + transition analysis)  —  kinetic estimator", ha="center",
            fontsize=13, fontweight="bold")
    ax.text(0, 2.72, "HOT (count-free anchor) $+$ directly-sampled COLD MSM $\\to$ TRAM solves "
            "$\\pi^{cold}$ AND reversible $p_{ij}$", ha="center", fontsize=9.5, color="0.3")
    ax.text(0, -3.0, "counts come ONLY from the (solid) cold ensemble ($R_i^{hot}{=}N_i^{hot}$); no biasing "
            "potential on the states — contrast BAUS", ha="center", fontsize=9, color="0.4", style="italic")
    ax.set_xlim(-5.4, 5.4); ax.set_ylim(-3.4, 3.5); ax.set_aspect("equal"); ax.axis("off")


def main():
    """Combined figure (both graphs stacked) plus the two single-panel figures used by the theory note:
    fig_theory_graph_msm.png (BAIS kinetic + the last-step-conditional inset) for the main text, and
    fig_theory_graph_us.png (BAUS thermodynamic) for the archived-BAUS section."""
    fig, axes = plt.subplots(2, 1, figsize=(13.0, 12.4))
    graph_us(axes[0])
    graph_msm(axes[1])
    fig.tight_layout()
    fig.savefig(OUT / "fig_theory_graphs.png", dpi=190); plt.close(fig)
    print(f"  wrote {OUT / 'fig_theory_graphs.png'}", file=sys.stderr)
    for name, draw in [("fig_theory_graph_us.png", graph_us), ("fig_theory_graph_msm.png", graph_msm)]:
        f, a = plt.subplots(figsize=(13.0, 6.3))
        draw(a)
        f.tight_layout()
        f.savefig(OUT / name, dpi=190); plt.close(f)
        print(f"  wrote {OUT / name}", file=sys.stderr)


if __name__ == "__main__":
    main()
