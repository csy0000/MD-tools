#!/usr/bin/env python3
"""demo_kcc_split_toy.py — validate the hierarchical KCC + TICA split on the 1D toy.

The split rule (kcc_split): level-1 KCC gives kinetically isolated clusters; each cluster is
split into sub-basins iff its internal slow timescale t2 (a) CONVERGES over a lag ladder AND
(b) t2 > 0.5*T, where T is the cold-walker length. This makes the number of resolved kinetic
states timescale-relative: sub-wells that are in local equilibrium (fast internal mixing,
t2 << T) stay merged.

Validation: SWEEP the cold-walker length T and show the resolved state count go 3 -> 2 -> 1 as
T grows, with the flips landing at T ~ 2*t2(A1<->A2) and T ~ 2*t2(A<->B) (analytic Smoluchowski
timescales). At short T even A1<->A2 looks metastable (3 states); at medium T A1<->A2 is in LEQ
so {A1,A2} merge to A (2 states: A, B); at long T even A<->B equilibrates (1 state).

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_kcc_split_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.toy1d import Toy1D, wrap                       # noqa: E402
from escort_ais.methods.kcc_split import kcc_split                     # noqa: E402

OUT = ROOT / "results/toy"
T_LIST = [600, 1000, 1500, 3000, 10000, 40000, 80000, 160000]
T_FAST = [800, 3000, 40000, 160000]


def _feats(traj):
    """(T, K) angle trajectory -> pooled walker-contiguous (K*T, 2) sin/cos features + wlens."""
    cols = [wrap(traj[:, k]) for k in range(traj.shape[1])]
    feats = np.vstack([np.column_stack([np.cos(c), np.sin(c)]) for c in cols])
    return feats, [len(c) for c in cols]


def _lags(T):
    """Geometric lag ladder ~T/200 .. T/12 for the ITS convergence test (all < T/4)."""
    base = max(10, T // 200)
    lags = [base * m for m in (1, 2, 4, 8, 16) if base * m < T // 4]
    return lags if len(lags) >= 2 else [max(5, T // 20), max(10, T // 8)]


def _reason(r):
    """Why a tested cluster did / did not split: split | leq-confident | undersampled-abstain.

    leq-confident = converged AND high LEQ-fraction  -> one LEQ-confident basin / one walker.
    undersampled  = ITS did not converge             -> too few transitions to resolve the slow mode
                                                        (a CONSERVATIVE no-split, not a physics claim).
    """
    if r["split"]:
        return "split"
    if r["converged"] and not r["slow_enough"]:
        return "leq-confident"
    return "undersampled-abstain"


def _kcc(t, feats, wlens, T, seed):
    lags = _lags(T)
    return kcc_split(feats, wlens, lag=max(10, T // 200), alpha_leq=10.0, alpha_split=2.0, k=20, lags=lags,
                     min_count=5, min_members=max(30, T // 50), max_depth=2, seed=seed)


def run_T(kappa, T, seed, n_per_well=6):
    """KCC+split at per-walker length T (multi-walker) AND a single-walker baseline at MATCHED
    total budget B = K*T. Returns both state counts, the per-cluster split reasons, and the trace."""
    t = Toy1D(kappa=kappa); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"])

    # --- multi-walker pool: n_per_well walkers seeded at each true well, each length T ---
    seeds0 = np.repeat(wells, n_per_well)
    n_walk = len(seeds0); B = n_walk * T
    feats, wlens = _feats(t.langevin(seeds0, T, 1.0, rng))
    res = _kcc(t, feats, wlens, T, seed)
    tested = [dict(t2=r["t2"], conv=r["converged"], slow=r["slow_enough"], split=r["split"],
                   reason=_reason(r), n=r["n"]) for r in res["trace"]]

    # --- single-walker baseline at the SAME total budget B (one long trajectory) ---
    sb = int(np.random.default_rng(seed + 555).integers(0, 3))
    sfeat, swlens = _feats(t.langevin(np.array([wells[sb]]), B, 1.0, np.random.default_rng(seed + 999)))
    sres = _kcc(t, sfeat, swlens, B, seed)

    return dict(T=int(T), B=int(B), n_walk=int(n_walk), seed=int(seed),
                n_states=int(res["n_states"]), n_states_single=int(sres["n_states"]),
                n_level1=int(res["level1"]["n_clusters"]), tested=tested)


def run(fast=False, nseed=4):
    kappa = Toy1D().kappa
    t = Toy1D(); ts = t.smoluchowski_timescales(ngrid=600, n=4, in_frames=True)
    t2_AB, t2_A1A2 = float(ts[0]), float(ts[1])
    Ts = T_FAST if fast else T_LIST
    seeds = list(range(2 if fast else nseed))
    from collections import Counter
    rows = []
    for T in Ts:
        for s in seeds:
            r = run_T(kappa, T, s)
            rows.append(r)
            rc = dict(Counter(x["reason"] for x in r["tested"]))
            print(f"T={T:>7} B={r['B']:>8}: seed{s} multi={r['n_states']} single={r['n_states_single']} "
                  f"| clusters {rc}", file=sys.stderr)
    OUT.mkdir(parents=True, exist_ok=True)
    payload = dict(Ts=Ts, rows=rows, t2_AB=t2_AB, t2_A1A2=t2_A1A2)
    (OUT / "kcc_split_toy.json").write_text(json.dumps(payload, indent=1))
    make_figure(payload)


def make_figure(payload):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = payload["rows"]; Ts = payload["Ts"]
    t2_AB, t2_A1A2 = payload["t2_AB"], payload["t2_A1A2"]
    flip_lo, flip_hi = 2 * t2_A1A2, 2 * t2_AB                   # predicted 3->2 and 2->1 flips
    n_walk = rows[0]["n_walk"]

    fig, ax = plt.subplots(1, 3, figsize=(18.5, 5))

    # (1) resolved kinetic states vs per-walker T (multi-walker) — validates the flip predictions
    a = ax[0]
    med = [np.median([r["n_states"] for r in rows if r["T"] == T]) for T in Ts]
    for r in rows:
        a.plot(r["T"], r["n_states"], "o", color="0.7", ms=4, zorder=1)
    a.plot(Ts, med, "-o", color="#2a7f2a", lw=2, ms=7, zorder=3, label="median resolved states")
    a.axvline(flip_lo, ls="--", color="#b03030", lw=1.5)
    a.axvline(flip_hi, ls="--", color="#3050b0", lw=1.5)
    a.text(flip_lo, 3.25, r"$T=2\,t_2(A_1\!\leftrightarrow\!A_2)$", color="#b03030", fontsize=8,
           rotation=90, va="top", ha="right")
    a.text(flip_hi, 3.25, r"$T=2\,t_2(A\!\leftrightarrow\!B)$", color="#3050b0", fontsize=8,
           rotation=90, va="top", ha="right")
    a.text(0.03, 0.90, r"$\{A_1,A_2,B\}$", transform=a.transAxes, fontsize=9, color="#555")
    a.text(0.40, 0.62, r"$\{A,B\}$", transform=a.transAxes, fontsize=9, color="#555")
    a.text(0.82, 0.30, r"$\{A\!\cup\!B\}$", transform=a.transAxes, fontsize=9, color="#555")
    a.set_xscale("log"); a.set_ylim(0.5, 3.6); a.set_yticks([1, 2, 3])
    a.set_xlabel("cold-walker length $T$ (frames)"); a.set_ylabel("resolved kinetic states")
    a.set_title("(1) states are timescale-relative: 3 → 2 → 1 as $T$ grows")
    a.legend(fontsize=8, loc="lower left"); a.grid(alpha=0.3, which="both")

    # (2) the split condition (b): tested internal t2 vs T, threshold line t2 = 0.5 T
    a = ax[1]
    for r in rows:
        for tt in r["tested"]:
            if tt["t2"] <= 0:
                continue
            col = "#2a7f2a" if tt["split"] else ("#c07020" if tt["conv"] else "#999")
            a.plot(r["T"], tt["t2"], "o", color=col, ms=5, alpha=0.8)
    xs = np.array(sorted(Ts), float)
    a.plot(xs, 0.5 * xs, "k--", lw=1.5, label=r"split threshold  $t_2 = 0.5\,T$")
    a.axhline(t2_A1A2, ls=":", color="#b03030", lw=1.2, label=r"$t_2(A_1\!\leftrightarrow\!A_2)$")
    a.axhline(t2_AB, ls=":", color="#3050b0", lw=1.2, label=r"$t_2(A\!\leftrightarrow\!B)$")
    a.set_xscale("log"); a.set_yscale("log")
    a.set_xlabel("cold-walker length $T$ (frames)"); a.set_ylabel("tested internal $t_2$ (frames)")
    a.set_title("(2) split iff converged AND above $t_2=0.5T$\n(green=split, orange=converged-but-fast, grey=not converged)")
    a.legend(fontsize=8, loc="upper left"); a.grid(alpha=0.3, which="both")

    # (3) matched-budget baseline: single-walker under-resolves the hierarchy
    a = ax[2]
    Bs = sorted({r["B"] for r in rows})
    med_m = [np.median([r["n_states"] for r in rows if r["B"] == B]) for B in Bs]
    med_s = [np.median([r["n_states_single"] for r in rows if r["B"] == B]) for B in Bs]
    for r in rows:
        a.plot(r["B"], r["n_states"], "o", color="#2a7f2a", ms=3, alpha=0.35, zorder=1)
        a.plot(r["B"], r["n_states_single"], "o", color="#7a4fb0", ms=3, alpha=0.35, zorder=1)
    a.plot(Bs, med_m, "-o", color="#2a7f2a", lw=2, ms=7, zorder=3, label=f"multi-walker ($K={n_walk}$)")
    a.plot(Bs, med_s, "-o", color="#7a4fb0", lw=2, ms=7, mfc="none", zorder=3, label="single-walker")
    a.set_xscale("log"); a.set_ylim(0.5, 3.6); a.set_yticks([1, 2, 3])
    a.set_xlabel("total budget $B = K\\,T$ (frames)"); a.set_ylabel("resolved kinetic states")
    a.set_title("(3) matched-budget baseline:\nsingle walker under-resolves the hierarchy (stalls at 1)")
    a.legend(fontsize=8, loc="upper right"); a.grid(alpha=0.3, which="both")

    fig.suptitle("Hierarchical KCC + TICA split on the 1D toy — level-1 KCC isolates clusters, then split iff "
                 "$t_2$ converged AND $t_2>0.5T$\n"
                 f"analytic $t_2(A_1\\!\\leftrightarrow\\!A_2)={t2_A1A2:.0f}$, "
                 f"$t_2(A\\!\\leftrightarrow\\!B)={t2_AB:.0f}$ frames; flips predicted at "
                 f"$T\\approx{flip_lo:.0f}$ and ${flip_hi:.0f}$.", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.9])
    fig.savefig(OUT / "fig_kcc_split_toy.png", dpi=170); plt.close(fig)
    print(f"  wrote {OUT / 'fig_kcc_split_toy.png'}", file=sys.stderr)


def _write_run_manifest(fast: bool) -> None:
    """Opt-in example of the run-manifest lifecycle (see docs/protocols/report_and_run_provenance.md)."""
    from escort_ais.common.paths import run_dir
    from escort_ais.common.run_manifest import RunManifest, config_hash, make_run_id, update_status, write_manifest

    cfg = {"fast": fast, "T_values": T_FAST if fast else T_LIST, "nseed": 2 if fast else 4}
    h = config_hash(cfg)
    rid = make_run_id("toy", "kcc_split", h)
    d = run_dir(rid)
    m = RunManifest.new(run_id=rid, system="toy", method="kcc_split", config_hash=h,
                        command="python -m escort_ais.experiments.toy.demo_kcc_split_toy"
                                + (" --fast" if fast else ""),
                        seeds=list(range(2 if fast else 4)), backend="numpy+numba", retention="exploratory")
    write_manifest(d, m)                                  # status: planned
    update_status(d, "running")
    run(fast=fast)
    update_status(d, "completed",
                  output_paths=[str((OUT / "fig_kcc_split_toy.png")), str((OUT / "kcc_split_toy.json"))])
    print(f"  wrote run manifest {d / 'manifest.json'}", file=sys.stderr)


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="Validate the hierarchical KCC + TICA split on the 1D toy.")
    ap.add_argument("--fast", action="store_true", help="fast smoke sweep (4 T-values, 2 seeds)")
    ap.add_argument("--figure-only", action="store_true", help="re-render the figure from the saved JSON")
    ap.add_argument("--manifest", action="store_true",
                    help="also write a run-manifest under <data_root>/runs/ (example provenance integration)")
    args = ap.parse_args()

    if args.figure_only:
        make_figure(json.load(open(OUT / "kcc_split_toy.json")))
    elif args.manifest:
        _write_run_manifest(fast=args.fast)
    else:
        run(fast=args.fast)
