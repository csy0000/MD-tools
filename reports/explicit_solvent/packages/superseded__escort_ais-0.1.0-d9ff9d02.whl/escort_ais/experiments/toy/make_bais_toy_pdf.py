#!/usr/bin/env python3
"""make_bais_toy_pdf.py — assemble bAIS_toy_validation.pdf from the 1D-toy ground truth + the two demos.

  Fig 1 — ground truth: cold potential U(θ), equilibrium p_eq(θ), wells/barriers, analytic populations & timescales.
  Fig 2 — BAUS demo (embedded fig_bais_us_toy.png).
  Fig 3 — BAIS demo (embedded fig_bais_msm_toy.png).
  Fig 4 — text summary: validation numbers + verdict (from the two demo JSONs).

Run the two demos first (they write the PNG/JSON): demo_bais_us_toy.py, demo_bais_msm_toy.py.

    conda activate escort-ais && python -m escort_ais.experiments.toy.make_bais_toy_pdf
"""
from __future__ import annotations

import json
import sys
import textwrap
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.systems.toy1d import Toy1D  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])                                  # samplable regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)


def ground_truth_figure(t):
    ana = t.populations()
    mins, maxs = t.extrema()
    ts = t.smoluchowski_timescales(ngrid=360, n=3)
    th = np.linspace(-np.pi, np.pi, 720); deg = np.degrees(th)
    fig, ax = plt.subplots(1, 2, figsize=(13, 5.2))
    # label wells A1/A2/B by angle (A1@60, A2@120, B@−120)
    def _well_label(cdeg):
        return {60: "A1", 120: "A2", -120: "B"}.get(int(round(cdeg)), "")
    # (A) potential
    ax[0].plot(deg, t.U_cold(th), "k-", lw=2)
    ax[0].plot(np.degrees(mins), t.U_cold(mins), "o", c="C2", ms=9, label="wells")
    ax[0].plot(np.degrees(maxs), t.U_cold(maxs), "^", c="C3", ms=9, label="barriers")
    Umin = float(t.U_cold(mins).min())
    for m in maxs:
        um = float(t.U_cold(np.array([m]))[0])
        ax[0].annotate(f"{um - Umin:.1f} kT", (np.degrees(m), um), fontsize=8, ha="center", va="bottom")
    for mn in mins:                                                  # A1/A2/B labels at each well bottom
        cdeg = float(np.degrees(mn)); lab = _well_label(cdeg)
        if lab:
            ax[0].annotate(lab, (cdeg, float(t.U_cold(np.array([mn]))[0]) - Umin), fontsize=13, ha="center",
                           va="top", fontweight="bold", color="C2", xytext=(0, -4), textcoords="offset points")
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("U_cold(θ) (kT)"); ax[0].set_xlim(-180, 180)
    ax[0].set_title("cold potential: A1↔A2 internal ~2.9 kT, A↔B ~7.1 kT (samplable regime)", fontsize=10)
    ax[0].legend(fontsize=8)
    # (B) equilibrium density with populations + the s=0.2 hot ensemble overlaid
    p_cold = t.p_eq(th); p_cold = p_cold / (p_cold.sum() * (th[1] - th[0]))
    p_hot = np.exp(-t.U(th, t.s_hot) / t.kT); p_hot = p_hot / (p_hot.sum() * (th[1] - th[0]))
    ax[1].plot(deg, p_cold, "k-", lw=2, label="cold P(θ) (target)")
    ax[1].plot(deg, p_hot, "-", c="C3", lw=2, label=f"hot ensemble (s={t.s_hot})")
    for c, p in zip(ana["well_centers_deg"], ana["pops"]):
        yy = float(p_cold[np.argmin(np.abs(deg - c))])
        ax[1].annotate(f"{_well_label(c)}\n{p:.2f}", (c, yy), fontsize=9.5, ha="center", va="bottom",
                       fontweight="bold", color="C0")
    ax[1].set_xlabel("θ (deg)"); ax[1].set_ylabel("density"); ax[1].set_xlim(-180, 180)
    ax[1].legend(fontsize=8)
    ax[1].set_title(f"cold populations + hot ensemble (s={t.s_hot}); slow-timescale ratio "
                    f"{ts[0] / ts[1]:.0f}:{ts[1] / ts[2]:.0f}:1", fontsize=10)
    fig.suptitle("1D toy ground truth — major basin A={A1(60°), A2(120°)} + minor B(−120°); analytic, REMD-free",
                 fontsize=12)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    return fig


def methods_figure():
    """A text page: one paragraph explaining how each method/estimator is actually computed."""
    fig = plt.figure(figsize=(8.3, 10.4)); fig.clf()
    P = [
        ("Methods — how each estimate is computed", None),
        ("The system & AIS work",
         "One periodic coordinate θ with cold potential U_cold(θ) = −kT ln p_eq(θ) (a von-Mises mixture: sub-wells "
         "A1@60°, A2@120°, minor B@−120°). The REST2-like HOT ensemble scales the whole potential, U(θ;s)=s·U_cold "
         "with s=0.2, so its barriers are 0.2× the cold ones and it mixes freely. All dynamics are overdamped "
         "Langevin. An "
         "AIS/NES switch drives s along a linear schedule s_from→s_to; at each step it adds the work ΔW=(Δs)·U_cold(θ) "
         "at fixed θ and then propagates a few MD steps, accumulating logw=Σ−βΔW. Forward = hot→cold, reverse = "
         "cold→hot. Endpoint BAR on the forward/reverse reduced works W=−logw gives a per-state free energy ΔF."),
        ("BAUS  (thermodynamics → cold P(θ))",
         "Between-state populations come from bAIS: a hot ensemble is switched forward to cold; each landing is "
         "labelled by state, and per state b the forward works (∞ if it did not land in b) are combined by endpoint "
         "BAR with reverse works from that state → ΔF_b, and π_b ∝ exp(−ΔF_b). Within-state shapes P(θ|state) come "
         "from a flat-bottom umbrella per state (zero force inside the well, soft wall outside). The cold profile is "
         "P(θ)=Σ_b π_b · P(θ|b). Cross-checked against plain cold MD (which traps) and coarse vs fine state "
         "definitions."),
        ("BAIS  (thermodynamics + kinetics)",
         "Unrestrained cold MD is seeded from each state's medoid (well centre), several walkers each. The KINETIC "
         "structure is read straight from the cold basin↔basin crossing counts: A1↔A2 crosses readily (fast-intra → "
         "merge into one basin A), A↔B crosses only rarely (slow → keep B separate). POPULATIONS: cold MD alone "
         "cannot equilibrate across the slow A↔B barrier, so a HOT basin-MSM gives the (well-mixed) π_hot and "
         "forward/reverse AIS give per-basin BAR ΔF; π_cold ∝ exp(−ΔF). KINETICS: cold MD gives the fast A1↔A2 rate "
         "directly; the slow A↔B timescale is read from the hot MSM."),
        ("Population convergence  (BAR-MSM, with vs without bAIS)",
         "10 M steps of cold MD (5 walkers seeded across the wells), checkpointed every 0.5 M. WITHOUT bAIS: the "
         "cold populations are just the running basin fractions. WITH bAIS: only 0.1 M HOT MD (also seeded across "
         "basins so π_hot is unbiased) plus forward/reverse AIS at N_NES∈{100,1000,5000} (10 λ-windows × 10 MD steps "
         "each way, reverse count = forward landings per basin from the cold reservoir); per-basin endpoint BAR → "
         "π_cold ∝ exp(−ΔF_b). Error = population total-variation vs analytic, averaged over 6 AIS draws."),
        ("MFEP between states  (BAUS string)",
         "The minimum-free-energy path in 1D is the profile F(θ). Its SHAPE (incl. the barrier tops) comes from a "
         "connected string of flat-bottom umbrellas tiling θ: each box samples P_cold restricted to its window, "
         "−kT ln P recovers F up to a constant, and consecutive overlapping windows are aligned by their median "
         "offset. The between-state well depths are anchored by the same per-basin BAR (0.1 M hot + AIS). WITHOUT "
         "bAIS the profile is −kT ln P_cold(θ) from the cold histogram, which is undefined wherever cold MD never "
         "goes (barrier tops, the minor basin early on)."),
    ]
    y = 0.975
    for i, (head, body) in enumerate(P):
        if body is None:
            fig.text(0.06, y, head, fontsize=13, fontweight="bold", va="top"); y -= 0.045
            continue
        fig.text(0.06, y, head, fontsize=10.2, fontweight="bold", va="top", color="0.1"); y -= 0.028
        for ln in textwrap.wrap(body, 95):
            fig.text(0.07, y, ln, fontsize=8.4, va="top", family="monospace"); y -= 0.0208
        y -= 0.016
    return fig


def _render_text_page(title, blocks, figsize=(8.3, 10.4)):
    """A text page: bold title, then blocks of {head, body, eqs} (eqs = centered mathtext equations)."""
    fig = plt.figure(figsize=figsize); fig.clf()
    fig.text(0.055, 0.975, title, fontsize=11.0, fontweight="bold", va="top")
    y = 0.930
    for blk in blocks:
        if blk.get("head"):
            fig.text(0.06, y, blk["head"], fontsize=10.2, fontweight="bold", va="top", color="0.1"); y -= 0.027
        for ln in textwrap.wrap(blk.get("body", ""), 96):
            fig.text(0.07, y, ln, fontsize=8.4, va="top", family="monospace"); y -= 0.0206
        for eq in blk.get("eqs", []):
            y -= 0.006
            fig.text(0.5, y, eq, fontsize=11.5, va="top", ha="center"); y -= 0.040
        y -= 0.016
    return fig


def bar_combination_figure():
    """Item 6 (updated) — BAUS as a multistate MSK/MBAR estimator. Full derivation in the LaTeX report."""
    return _render_text_page(
        "BAUS — multistate MSK/MBAR estimator (thermodynamics)    [full derivation: LaTeX report]",
        [
            {"head": "States", "body":
             "M+1 thermodynamic states: the HOT ensemble (index 0, u_0 = s·U_cold) and one biased UMBRELLA per basin "
             "(index b, u_b = U_cold + w_b, w_b = flat-bottom wall). Reduced free energies f_k = −ln Z_k, gauge "
             "f_0 ≡ 0. (Star graph: hot = centre supernode; umbrellas = peripheral, partially overlapping nodes.)"},
            {"head": "1. hot↔US spokes — corrected forward/backward work", "body":
             "AIS switches hot→cold (work W_f); a ONE-STEP bias-on maps cold→US_b (cost U_US = w_b(x)). So the "
             "hot→US and US→hot reduced works are (the ±U_US perturbation is what an earlier draft omitted):",
             "eqs": [r"$W^{0\to b}=W_f+U_{US},\qquad W^{b\to 0}=-U_{US}+W_r$"]},
            {"head": "2. US↔US edges — one-step overlap", "body":
             "All umbrellas share U_cold, so a US_a sample re-evaluated in US_b costs ΔU = w_b−w_a (U_cold cancels); "
             "overlapping umbrellas give M² one-step, well-overlapped pairs → M hot↔US spokes + M² US↔US pairs."},
            {"head": "3. Multistate solve (MSK; MBAR in the one-step limit)", "body":
             "The optimal combination of all forward/reverse work is the Maragakis–Spichty–Karplus multistate "
             "estimator; with N_k samples per state it satisfies the self-consistent MBAR equations (f_0 ≡ 0):",
             "eqs": [r"$f_k=-\ln\sum_{l,n}\frac{e^{-u_k(x_{l,n})}}{\sum_m N_m\,e^{\,f_m-u_m(x_{l,n})}}$"]},
            {"head": "4. PMF: WHAM (fixed f) or MBAR", "body":
             "With {f_k} FIXED from MSK (no free-energy iteration), one WHAM pass gives the grid-level F_cold(ξ) "
             "[b_0=(s−1)U_cold, b_b=w_b]; or MBAR weights each configuration μ(x)=[Σ_m N_m e^{f_m−u_m(x)}]^{−1}:",
             "eqs": [r"$F_{\mathrm{cold}}(\xi)=-\ln\frac{\sum_k n_k(\xi)}{\sum_k N_k\,e^{\,f_k-b_k(\xi)}}$"]},
            {"body":
             "BAUS applies a biasing potential to EACH BASIN → it is the THERMODYNAMIC estimator (populations + "
             "PMF, no kinetics). Contrast BAIS (next), which puts no bias on the states and returns kinetics."},
        ])


def tram_estimator_figure():
    """Item 10 (corrected) — BAIS as a restricted TRAM. Full derivation in the LaTeX report §6."""
    return _render_text_page(
        "BAIS — restricted TRAM (kinetics)    [Wu et al. PNAS 2016, eqs 15–19; full derivation: LaTeX report]",
        [
            {"head": "States & data (counts ONLY from cold)", "body":
             "Two ensembles k∈{hot,cold}: cold is the reference (b^cold=0), hot bias b^hot(x)=(s−1)·U_cold(x). "
             "Markov states i=1..m. COLD gives transition counts c_ij (lag τ) + N_i^cold samples; HOT gives "
             "N_i^hot samples ONLY — no counts. This single restriction distinguishes us from full TRAM. "
             "(Star graph: hot = count-free centre; cold Markov states = periphery joined by c_ij edges.)"},
            {"head": "Likelihood (Eq. 9) — kinetic product over COLD only", "body":
             "μ(x)=unbiased density; f_i^(k)=reduced free energy of state i in ensemble k:",
             "eqs": [r"$L=\left[\prod_{ij}p_{ij}^{\,c_{ij}}\right]\prod_{k}\prod_i\prod_{x\in X_i^k}"
                     r"\mu(x)\,e^{\,f_i^{(k)}-b^{(k)}(x)}$"]},
            {"head": "Reversible cold transition matrix (Eq. 16) + multipliers (Eq. 18)", "body":
             "Maximise s.t. row-stochastic + detailed balance e^{−f_i}p_ij = e^{−f_j}p_ji (multipliers v_i):",
             "eqs": [r"$p_{ij}=\frac{c_{ij}+c_{ji}}{v_i+v_j\,e^{\,f_j^{c}-f_i^{c}}},\quad "
                     r"v_i\leftarrow c_{ii}+\sum_{j\neq i}(c_{ij}{+}c_{ji})"
                     r"\frac{v_i}{v_i+v_j e^{\,f_j^{c}-f_i^{c}}}$"]},
            {"body": "(v_i = λ_i e^{−f_i} with f^cold FIXED ⇒ the earlier 'fixed-π' reversible MLE — the special "
             "case where f^cold is supplied externally instead of solved. That is what we corrected.)"},
            {"head": "Thermodynamic coupling (Eqs. 15, 17, 19)", "body":
             "Effective counts R_i^k join kinetics+equilibrium; HOT has no counts ⇒ R_i^hot=N_i^hot (the "
             "restriction). μ (Eq. 17) and the free energies (Eq. 19) close the loop:",
             "eqs": [r"$R_i^{hot}=N_i^{hot},\qquad "
                     r"f_i^{(k)}=-\ln\!\!\sum_{x\in X_i}\frac{e^{-b^{(k)}(x)}}"
                     r"{\sum_l R_i^{(l)}e^{\,f_i^{(l)}-b^{(l)}(x)}}$"]},
            {"head": "Conditional BAR — the parallel with BAUS (last-step perturbation)", "body":
             "The thermodynamic half is the same annealed bridge as BAUS, differing only in the LAST-STEP "
             "perturbation mapping cold→state b: BAUS uses a smooth umbrella U_last=w_b(x) (active confinement); "
             "BAIS uses a STEP function U_last(x)=0 if x∈basin b else +∞ (basin indicator), assuming LEQ within b. "
             "So W^{0→b}=W_f+U_last is W_f for landings in b and +∞ otherwise → the ∞-padded conditional BAR:",
             "eqs": [r"$\sum_{i:\,\mathrm{land}\in b} f(W_f^{i}-\Delta F_b+M)"
                     r"=\sum_{j\in b} f(\Delta F_b-W_r^{b,j}+M)$"]},
            {"body":
             "These per-basin ΔF_b iterate with the reversible MSM. Iterating jointly returns π_i^cold AND the "
             "reversible p_ij (t=−τ/ln|Λ|). The hot equilibrium pins the A↔B populations the sparse cold crossings "
             "(c_AB≈17) can't; the AIS ladder supplies the hot→cold overlap. BAIS = the KINETIC estimator (no bias "
             "on states; contrast BAUS). Implemented via deeptime's C++ TRAM: src/escort_ais/bata.py "
             "(fixed-π special case: fixed_pi_msm.py)."},
        ])


def make_pdf():
    us = json.load(open(OUT / "bais_us_toy.json"))
    msm = json.load(open(OUT / "bais_msm_toy.json"))
    conv_path = OUT / "bais_convergence_toy.json"
    conv = json.load(open(conv_path)) if conv_path.exists() else None
    mfep_path = OUT / "mfep_convergence_toy.json"
    mfep = json.load(open(mfep_path)) if mfep_path.exists() else None
    its_path = OUT / "toy_seeding_its.json"
    its = json.load(open(its_path)) if its_path.exists() else None
    out = OUT / "bAIS_toy_validation.pdf"
    with PdfPages(out) as pdf:
        fign = [0]

        def _save(f, number=True):
            if number:
                fign[0] += 1
                f.text(0.012, 0.994, f"Figure {fign[0]}", fontsize=12, fontweight="bold", va="top", color="0.15")
            pdf.savefig(f, dpi=200); plt.close(f)

        def _png(png):
            p = OUT / png
            if p.exists():
                im = plt.imread(str(p)); h, w = im.shape[:2]
                figj, axj = plt.subplots(figsize=(11, max(3.0, 11 * h / w)))
                axj.imshow(im); axj.axis("off"); figj.tight_layout(pad=0.2); _save(figj)

        # ── logical flow: ground truth → methods → building blocks → the two thermo tools →
        #    sampling protocols → kinetics (TRAM math + ITS) → convergence studies → verdict ──
        _save(ground_truth_figure(Toy1D(kappa=KAPPA)))                # 1  (A1/A2/B + s=0.2 ensemble)
        _save(methods_figure(), number=False)
        _png("fig_toy_hot_ais.png")                                  # hot ensemble & AIS reweighting (items 2-4)
        _png("fig_toy_ais_landing_sweep.png")                       # landing profiles vs N_AIS=2^n
        _png("fig_toy_gmm_us.png")                                   # GMM split + per-basin US (item 5)
        _save(bar_combination_figure(), number=False)               # BAUS multistate MSK/MBAR math (item 6)
        _png("fig_theory_graph_us.png")                             # BAUS star graph
        _png("fig_bais_us_toy.png")                                  # BAUS
        _png("fig_bais_msm_toy.png")                                 # BAIS
        _png("fig_toy_trajectories.png")                            # sampling protocols (item 7)
        _png("fig_toy_rmse.png")                                     # RMSE convergence (item 8)
        _save(tram_estimator_figure(), number=False)                # restricted-TRAM math (item 10)
        _png("fig_theory_graph_msm.png")                            # BAIS star graph
        _png("fig_toy_its.png")                                      # ITS: plain vs fixed-π (items 9, 11)
        _png("fig_bais_convergence_toy.png")                        # population convergence
        _png("fig_mfep_convergence_toy.png")                        # MFEP convergence

        # summary text
        fig = plt.figure(figsize=(8.3, 9.5)); fig.clf()
        lines = [
            "bAIS toy validation — two REMD-free estimators on a 1D toy with analytic ground truth", "=" * 84, "",
            "TOY (mirrors rgd): major basin A = two sub-wells A1(60°), A2(120°) split by a ~2.9 kT internal",
            "  barrier; minor basin B(−120°) behind a ~7.1 kT barrier. Analytic populations A1/A2/B ="
            f" {us['analytic_pops']}. Samplable regime: cold MD crosses A↔B only slowly; hot (s=0.2) mixes freely.",
            "", "  (One single system is used throughout this PDF; see the Methods page for how each estimate is "
            "computed.)", "",
            "TOOL 1 — BAUS (thermodynamics): forward+reverse AIS give between-state populations (per-basin BAR);",
            "  flat-bottom US gives within-state P(θ|state); combine → cold P(θ).",
            f"    between-state populations: bAIS {us['pi_fine']}  vs analytic {us['analytic_pops']}"
            f"  (pop TV {us['pops_tv_fine']})",
            f"    reconstructed P(θ) total-variation to analytic:  BAUS fine = {us['tv_ptheta']['bais_us_fine']}"
            f"   |  coarse-state US = {us['tv_ptheta']['bais_us_coarse']}"
            f"   |  plain cold MD = {us['tv_ptheta']['cold_reservoir']}",
            "    → BAUS fine-state recovers the truth; coarse-state is intermediate (within-A shape less exact); "
            "plain cold MD fails (traps at A↔B). The fine-vs-coarse gap widens as the internal barrier grows.", "",
            "TOOL 2 — BAIS (thermodynamics + kinetics): medoid-seeded cold MD → MSM; hot MSM + BAR → populations.",
            f"    cold populations: bAIS {msm['pi_cold_bais']} (TV {msm['pops_tv']['bais']})  vs"
            f"  raw cold-seed {msm['pi_cold_raw']} (TV {msm['pops_tv']['raw_cold']})  vs analytic"
            f" {msm['analytic_pops']}",
            f"    merge/split (cold basin↔basin crossings): A1↔A2 = {msm['cold_crossings']['A1_A2']},"
            f"  A↔B = {msm['cold_crossings']['A1_B'] + msm['cold_crossings']['A2_B']}"
            f"  → {msm['merge_split']}",
            f"    kinetics: A1↔A2 MFPT(cold) = {msm['kinetics']['A1A2_mfpt_cold_frames']:.0f} frames;"
            f"  A↔B resolved cleanly by the hot MSM (ts {msm['kinetics']['hot_msm_timescales_frames']}).", "",
            "CONVERGENCE — does bAIS (BAR-MSM) beat plain cold MSM? (samplable regime, hot only 0.1M, NES 10x10):"]
        if conv is not None:
            c0, cf = conv["checkpoints"][0], conv["checkpoints"][-1]
            lines += [
                f"    plain cold MSM population TV: {c0['tv_plain']} (0.5M) → {cf['tv_plain']} (10M) — a slow ramp "
                "as A↔B crossings accumulate (seeding-biased at short cold length).",
                f"    bAIS TV (mean±sd over 6 AIS draws), FLAT across cold length (uses only 0.1M hot): "
                f"N=100 {cf['tv_bais_100']}±{cf['tvsd_bais_100']}  |  N=1000 {cf['tv_bais_1000']}±"
                f"{cf['tvsd_bais_1000']}  |  N=5000 {cf['tv_bais_5000']}±{cf['tvsd_bais_5000']}.",
                f"    → bAIS reaches its floor from 0.1M hot, while plain cold MSM only ramps down to {cf['tv_plain']} "
                "over ~10M steps → bAIS converges faster (the rate advantage; larger still in the harder-barrier "
                "regime where plain MSM barely crosses). More N_NES → tighter.", ""]
        lines += ["MFEP (3-state free-energy profile incl. BARRIERS) convergence — samplable regime (A↔B lowered to "
                  "~7.1 kT):"]
        if mfep is not None:
            c0, cf = mfep["cold_checkpoints"][0], mfep["cold_checkpoints"][-1]
            rms = mfep["bais_us_mfep_rms"]
            lines += [
                "    the MFEP minima are the state free energies (above); the MFEP MAXIMA are the barriers between "
                "states — the new part, where cold MD struggles (rarely visits a barrier top).",
                "    WITHOUT bAIS (cold MD): full-profile RMS "
                f"{c0['rms_defined']} (0.5M) → {cf['rms_defined']} (10M); θ-coverage {c0['coverage']} → "
                f"{cf['coverage']} (plateaus <1 — barrier tops/minor basin never fully filled).",
                "    WITH BAUS (connected US string + BAR offsets, 0.1M hot): full-profile RMS "
                f"{rms['100']}/{rms['1000']}/{rms['5000']} kT at N_NES=100/1000/5000, FLAT across cold length; "
                "resolves both transition barriers to <0.3 kT.",
                "    → BAUS reconstructs the WHOLE path (wells + barriers) from 0.1M hot; cold MD needs ~5–6M "
                "steps to match the RMS and never fully covers the barrier tops. MFEP shape is US-set → only weakly "
                "N_NES-dependent (N_NES matters more for populations, above).", ""]
        if its is not None:
            il = its["its_at_lag500"]; tf = its["tv_final"]
            lines += ["KINETICS — implied timescales & the BAIS (restricted-TRAM) estimator (samplable regime):",
                      f"    sampling protocols (population TV): (b) multi-medoid raw {tf['b_multimedoid']}, "
                      f"(c) medoid+US→BAUS {tf['c_baus']} → BAUS is low & flat (single-medoid dropped).",
                      f"    slow A↔B implied timescale @lag500 (ref {its['ref_slow_its_plateau_frames']:.0f}): plain "
                      f"MSM {il['plain']:.0f}  vs  BAIS {il['bata']:.0f} — both match the reference once A↔B is sampled.",
                      "    → BAIS (deeptime C++ TRAM) jointly solves the cold π AND the reversible p_ij; it additionally "
                      "returns the correct populations (which plain MSM does not), and cannot invent kinetics the cold "
                      "counts lack.", ""]
        lines += ["VERDICT:"]
        verdict = ("Both REMD-free tools recover the analytic ground truth on a single 1D system (samplable regime, "
                   "A↔B ~7.1 kT). BAUS reconstructs the cold P(θ) and populations from AIS (between-state) + "
                   "flat-bottom US (within-state); here fine and coarse states both work (the fine-state requirement "
                   "bites only at higher internal barriers). BAIS recovers the cold populations that raw "
                   "cold-seed MD gets wrong (the slow A↔B barrier is barely crossed), merges the fast-intra A1↔A2 "
                   "pair, keeps B as a separate weakly-connected basin, gives the fast A1↔A2 rate directly, and reads "
                   "the slow A↔B rate from the hot MSM. The two convergence studies then show bAIS reaching its "
                   "population floor and the full MFEP (wells + barriers) from only 0.1 M hot, while plain cold MD "
                   "needs many more steps and never fully covers the barrier tops. This validates the estimator "
                   "machinery before the macrocycle application.")
        for wln in textwrap.wrap(verdict, 92):
            lines.append("    " + wln)
        fig.text(0.05, 0.97, "\n".join(lines), va="top", ha="left", family="monospace", fontsize=8.0)
        _save(fig, number=False)
    print(f"wrote {out}")


if __name__ == "__main__":
    make_pdf()
