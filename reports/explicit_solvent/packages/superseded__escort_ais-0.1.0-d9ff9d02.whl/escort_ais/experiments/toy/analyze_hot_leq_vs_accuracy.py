#!/usr/bin/env python3
"""analyze_hot_leq_vs_accuracy.py — is the cold BAR-π error driven by an out-of-equilibrium HOT ensemble?

Reanalysis (CPU, deterministic replay — NO fresh sims) of the unified-ladder BAIS protocol on the 1×/3×/5×
barrier toys. For each regime × seed we replay `bais_protocol_run(..., hot_diag=True)`, which instruments the
SINGLE hot walker with the project's LEQ condition (α_LEQ=10: T_hot_cum ≥ 10·t2_hot) plus its TV to the analytic
hot Boltzmann reference, alongside the running cold endpoint-BAR π accuracy (pop_tv to [0.25,0.42,0.33]).

Hypothesis under test: the cold-π error comes from an early out-of-equilibrium hot ensemble. If instead the hot
walker is already LEQ-confident AND low-TV by the first recorded generation while cold pop_tv is still large,
the error is cold-sampling-limited, not hot-driven.

    conda activate escort-ais && python -m escort_ais.experiments.toy.analyze_hot_leq_vs_accuracy
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np
from scipy.stats import spearmanr

from escort_ais.common.paths import project_root
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import (
    bais_protocol_run, AIS_LADDER, MID3X_KAPPA, HARD5X_KAPPA)

ROOT = project_root()
OUT = ROOT / "results/toy"
ANALYTIC = [0.25, 0.42, 0.33]
REGIMES = [("1x", None), ("3x", MID3X_KAPPA), ("5x", HARD5X_KAPPA)]
SEEDS = [0, 1, 2, 3]
FIELDS = ["budget", "t2_hot", "leq_margin", "tv_hot_cum", "tv_hot_gen", "pop_tv"]


def _spearman(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    m = np.isfinite(x) & np.isfinite(y)
    if m.sum() < 3 or np.unique(x[m]).size < 2 or np.unique(y[m]).size < 2:
        return float("nan")
    return float(spearmanr(x[m], y[m]).correlation)


def _aggregate(recs_by_seed):
    """recs_by_seed: list (over seeds) of hot_diag record-lists. Align by `gen`, median + IQR per field per gen."""
    gens = sorted({r["gen"] for recs in recs_by_seed for r in recs})
    agg = {"gen": gens}
    for f in FIELDS:
        med, q25, q75 = [], [], []
        for g in gens:
            vals = [r[f] for recs in recs_by_seed for r in recs if r["gen"] == g]
            vals = np.asarray(vals, float)
            med.append(float(np.nanmedian(vals)))
            q25.append(float(np.nanpercentile(vals, 25)))
            q75.append(float(np.nanpercentile(vals, 75)))
        agg[f] = med; agg[f + "_q25"] = q25; agg[f + "_q75"] = q75
    # median per-basin pi per gen (component-wise)
    pi_med = []
    for g in gens:
        pis = np.array([r["pi"] for recs in recs_by_seed for r in recs if r["gen"] == g], float)
        pi_med.append(np.nanmedian(pis, axis=0).tolist())
    agg["pi"] = pi_med
    return agg


def _first_where(gens, arr, pred):
    for g, v in zip(gens, arr):
        if np.isfinite(v) and pred(v):
            return int(g)
    return None


def run():
    raw = {}                                    # regime -> list over seeds of hot_diag record-lists
    for name, kappa in REGIMES:
        raw[name] = []
        for s in SEEDS:
            r = bais_protocol_run(s, 1_000_000, hot_steps=10000, cold_chunk=10000,
                                  ais_ladder=AIS_LADDER, kappa=kappa, pergen=True, hot_diag=True)
            raw[name].append(r["hot_diag"])
            print(f"  {name} seed{s}: {len(r['hot_diag'])} gens, final pop_tv="
                  f"{r['hot_diag'][-1]['pop_tv']:.3f}, tv_hot_cum(gen0)={r['hot_diag'][0]['tv_hot_cum']:.3f}",
                  file=sys.stderr)

    # pooled scatter data (all regimes/seeds/gens) + per-regime pooled points
    glob_poptv, glob_tvhot = [], []
    out = {"regimes": [n for n, _ in REGIMES], "seeds": SEEDS, "analytic": ANALYTIC,
           "alpha_leq": 10.0, "budget": 1_000_000, "per_regime": {}}

    for name, _ in REGIMES:
        agg = _aggregate(raw[name])
        gens = agg["gen"]
        # pooled per-seed/per-gen points for this regime
        p_poptv = [r["pop_tv"] for recs in raw[name] for r in recs]
        p_tvhot = [r["tv_hot_cum"] for recs in raw[name] for r in recs]
        p_leq = [r["leq_margin"] for recs in raw[name] for r in recs]
        glob_poptv += p_poptv; glob_tvhot += p_tvhot

        g_leq = _first_where(gens, agg["leq_margin"], lambda v: v >= 1.0)
        g_cold = _first_where(gens, agg["pop_tv"], lambda v: v <= 0.05)
        b_at = lambda g: (float(agg["budget"][gens.index(g)]) if g is not None else None)
        tvhot_at = lambda g: (float(agg["tv_hot_cum"][gens.index(g)]) if g is not None else None)
        all_leq_true = all(r["leq_hot"] for recs in raw[name] for r in recs)

        out["per_regime"][name] = {
            "agg": agg,
            "summary": {
                "gen_hot_leq_onset": g_leq, "budget_hot_leq_onset": b_at(g_leq),
                "tv_hot_at_onset": tvhot_at(g_leq),
                "tv_hot_cum_gen0": float(agg["tv_hot_cum"][0]), "tv_hot_cum_final": float(agg["tv_hot_cum"][-1]),
                "leq_margin_gen0": float(agg["leq_margin"][0]),
                "hot_leq_confident_from_gen0": bool(all_leq_true),
                "gen_coldpi_below_0.05": g_cold, "budget_coldpi_below_0.05": b_at(g_cold),
                "pop_tv_gen0": float(agg["pop_tv"][0]), "pop_tv_final": float(agg["pop_tv"][-1]),
                "spearman_poptv_vs_tvhot": _spearman(p_tvhot, p_poptv),
                "spearman_poptv_vs_leqmargin": _spearman(p_leq, p_poptv)}}

    out["spearman_poptv_vs_tvhot"] = _spearman(glob_tvhot, glob_poptv)

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "hot_leq_vs_accuracy.json").write_text(json.dumps(out, indent=1))
    print(f"  wrote {OUT / 'hot_leq_vs_accuracy.json'}", file=sys.stderr)
    make_figure(raw, out)
    return out


def make_figure(raw, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    BLUE, RED, GREEN = "#1f6fb0", "#b03030", "#1f8f3f"
    REG_COL = {"1x": "#4c72b0", "3x": "#dd8452", "5x": "#55a868"}
    fig = plt.figure(figsize=(12.5, 15))
    gs = fig.add_gridspec(4, 2, height_ratios=[1, 1, 1, 1.05], hspace=0.42, wspace=0.26)

    for i, (name, _) in enumerate(REGIMES):
        ax = fig.add_subplot(gs[i, :]); axr = ax.twinx()
        s = out["per_regime"][name]; agg = s["agg"]; summ = s["summary"]
        x = np.array(agg["budget"], float)
        flo = lambda a: np.clip(np.array(a, float), 1e-3, None)

        ax.plot(x, flo(agg["tv_hot_cum"]), "-o", color=BLUE, ms=4, label="hot TV (cum) to analytic hot")
        ax.fill_between(x, flo(agg["tv_hot_cum_q25"]), flo(agg["tv_hot_cum_q75"]), color=BLUE, alpha=0.18)
        ax.plot(x, flo(agg["pop_tv"]), "-s", color=RED, ms=4, label="cold BAR pop_tv to analytic cold")
        ax.fill_between(x, flo(agg["pop_tv_q25"]), flo(agg["pop_tv_q75"]), color=RED, alpha=0.18)
        ax.axhline(0.05, ls=":", color=RED, lw=1.0, alpha=0.7)
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_ylabel("TV (log)")
        ax.grid(alpha=0.3, which="both")

        axr.plot(x, flo(agg["leq_margin"]), "-^", color=GREEN, ms=4, label="hot LEQ margin (α=10)")
        axr.fill_between(x, flo(agg["leq_margin_q25"]), flo(agg["leq_margin_q75"]), color=GREEN, alpha=0.15)
        axr.axhline(1.0, ls="--", color=GREEN, lw=1.2)
        axr.set_yscale("log"); axr.set_ylabel("LEQ margin (log)", color=GREEN)
        axr.tick_params(axis="y", colors=GREEN)

        bk = summ["budget_hot_leq_onset"]; bc = summ["budget_coldpi_below_0.05"]
        if bk is not None:
            ax.axvline(bk, color=GREEN, lw=1.4, alpha=0.8)
        if bc is not None:
            ax.axvline(bc, color=RED, lw=1.4, alpha=0.8)
        bks = f"{bk/1000:.0f}k" if bk is not None else "never"
        bcs = f"{bc/1000:.0f}k" if bc is not None else "never (pop_tv>0.05 to end)"
        ax.set_title(f"{name} regime: hot LEQ-confident at B={bks}; cold pop_tv<0.05 at B={bcs}  "
                     f"(tv_hot gen0={summ['tv_hot_cum_gen0']:.3f}→final={summ['tv_hot_cum_final']:.3f}, "
                     f"cold pop_tv gen0={summ['pop_tv_gen0']:.3f}→final={summ['pop_tv_final']:.3f})",
                     fontsize=9.5)
        if i == 0:
            l1, la1 = ax.get_legend_handles_labels(); l2, la2 = axr.get_legend_handles_labels()
            ax.legend(l1 + l2, la1 + la2, fontsize=8, loc="upper right", ncol=1)
        ax.set_xlabel("total budget (force-evals)")

    # row 4: pooled scatters over ALL regimes/seeds/gens
    ax1 = fig.add_subplot(gs[3, 0]); ax2 = fig.add_subplot(gs[3, 1])
    all_leq_true = True
    for name, _ in REGIMES:
        recs = [r for seed_recs in raw[name] for r in seed_recs]
        pv = np.array([r["pop_tv"] for r in recs]); th = np.array([r["tv_hot_cum"] for r in recs])
        lm = np.array([r["leq_margin"] for r in recs])
        all_leq_true &= all(r["leq_hot"] for r in recs)
        ax1.scatter(np.clip(th, 1e-3, None), np.clip(pv, 1e-3, None), s=16, alpha=0.6,
                    color=REG_COL[name], label=name)
        ax2.scatter(np.clip(lm, 1e-3, None), np.clip(pv, 1e-3, None), s=16, alpha=0.6,
                    color=REG_COL[name], label=name)

    rho_th = out["spearman_poptv_vs_tvhot"]
    poolp = [r["pop_tv"] for name, _ in REGIMES for sr in raw[name] for r in sr]
    poollm = [r["leq_margin"] for name, _ in REGIMES for sr in raw[name] for r in sr]
    rho_lm = _spearman(poollm, poolp)

    ax1.set_xscale("log"); ax1.set_yscale("log"); ax1.grid(alpha=0.3, which="both")
    ax1.set_xlabel("hot TV (cumulative) to analytic hot"); ax1.set_ylabel("cold BAR pop_tv")
    ax1.set_title(f"cold pop_tv vs hot TV (all regimes/seeds/gens)\nSpearman ρ={rho_th:.2f}", fontsize=9.5)
    ax1.legend(fontsize=8)
    ax2.set_xscale("log"); ax2.set_yscale("log"); ax2.grid(alpha=0.3, which="both")
    ax2.set_xlabel("hot LEQ margin (α=10)"); ax2.set_ylabel("cold BAR pop_tv")
    ax2.axvline(1.0, ls="--", color=GREEN, lw=1.2)
    ax2.set_title(f"cold pop_tv vs hot LEQ margin\nSpearman ρ={rho_lm:.2f}", fontsize=9.5)
    ax2.legend(fontsize=8)
    if all_leq_true:
        for a in (ax1, ax2):
            a.text(0.03, 0.05, "hot ensemble LEQ-confident from gen 0\n(no LEQ-False generations)",
                   transform=a.transAxes, fontsize=8, color=GREEN, va="bottom",
                   bbox=dict(boxstyle="round", fc="white", ec=GREEN, alpha=0.85))

    fig.suptitle("Is the cold BAR-π error driven by an out-of-equilibrium hot ensemble? "
                 "Hot LEQ + hot-TV vs cold pop_tv, unified s_hot=0.01 ladder, 1×/3×/5× toys.",
                 fontsize=11)
    fig.savefig(OUT / "fig_hot_leq_vs_accuracy.png", dpi=170, bbox_inches="tight")
    plt.close(fig)
    print(f"  wrote {OUT / 'fig_hot_leq_vs_accuracy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
