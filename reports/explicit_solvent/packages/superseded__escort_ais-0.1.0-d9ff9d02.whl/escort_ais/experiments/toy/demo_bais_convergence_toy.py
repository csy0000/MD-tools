#!/usr/bin/env python3
"""demo_bais_convergence_toy.py — does bAIS (BAR-MSM) converge faster than plain cold MSM? (1D toy)

Run in the SAMPLABLE regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT) — the single system used throughout this PDF.
Estimates the 3-state cold populations/free energies vs cold-MD length, comparing:
  * WITHOUT bAIS — raw cold populations from the accumulating cold MD (checkpointed every 0.5 M up to 10 M). These
    are seeding-biased at short cold length and converge only as enough rare A↔B crossings accumulate → slow ramp.
  * WITH bAIS — only 0.1 M HOT MD (seeded across basins so the hot ensemble is unbiased) + forward+reverse AIS
    (nonequilibrium switching, 10 λ-windows × 10 MD steps each way; N_fwd = [100, 1000, 5000], N_rev = the forward
    landing count per basin, reverse started from the cold reservoir). Per-basin endpoint BAR gives ΔF_b and the
    cold populations are pi_cold_b ∝ exp(−ΔF_b) (the correct combination — ΔF_b = F_cold_b − F_hot_full, so no
    extra pi_hot factor; that is what `tram_cold_populations` would double-count).

Bias notes learned building this: the hot walkers MUST be seeded across basins (else burn-in under-samples the
minor and biases the forward AIS); and `pi_cold ∝ exp(−ΔF_inf)` — NOT `tram_cold_populations(pi_hot, ΔF_inf)`.
Pure numpy — no OpenMM/GPU.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_convergence_toy
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])                                  # samplable regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)


def free_err(pi, pi_true, ref):
    """RMS free-energy error (kT) over states, relative to the reference well."""
    f = -np.log(np.clip(pi, 1e-8, None)); ft = -np.log(np.clip(pi_true, 1e-8, None))
    f -= f[ref]; ft -= ft[ref]
    return float(np.sqrt(np.mean((f - ft) ** 2)))


def run(seed=0, cold_total=10_000_000, checkpoint=500_000, n_walkers=5, hot_steps=100_000,
        hot_walkers=10, ais_budgets=(100, 1000, 5000), nes_win=10, nes_md=10):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)        # samplable regime: A↔B ~7.1 kT
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    nb = ana["n_basins"]; ref = int(np.argmax(ana["pops"])); pt = ana["pops"]

    # --- cold MD reservoir (10 M total, walkers seeded across all wells) ---
    per_w = cold_total // n_walkers
    cold = t.langevin(wells[np.arange(n_walkers) % nb], per_w, 1.0, rng)
    cold_th = [wrap(cold[:, k]) for k in range(n_walkers)]
    cold_bas = [t.basin_of(x, bnd).astype(int) for x in cold_th]

    # --- hot ensemble (0.1 M total, seeded ACROSS basins + burn → unbiased forward-AIS starts) ---
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, t.s_hot, rng)
    burn = max(1, (hot_steps // hot_walkers) // 20)
    hot = wrap(hraw[burn:].reshape(-1))

    # --- forward AIS per budget, n_rep independent draws (FIXED across checkpoints; for error bars) ---
    n_rep = 6
    fwd = {N: [] for N in ais_budgets}
    for N in ais_budgets:
        for _ in range(n_rep):
            xh = hot[rng.integers(0, len(hot), N)]
            land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=nes_win, freq=nes_md, rng=rng)
            fwd[N].append((t.basin_of(land, bnd).astype(int), -lwf))

    checkpoints = list(range(checkpoint, cold_total + 1, checkpoint))
    rows = []
    for T in checkpoints:
        cf = T // n_walkers
        cb = np.concatenate([b[:cf] for b in cold_bas]); cth = np.concatenate([x[:cf] for x in cold_th])
        pi_plain = np.array([np.mean(cb == b) for b in range(nb)])   # WITHOUT bAIS: raw cold populations
        row = dict(cold_steps=T, tv_plain=round(0.5 * float(np.abs(pi_plain - pt).sum()), 3),
                   ferr_plain=round(free_err(pi_plain, pt, ref), 3))
        for N in ais_budgets:                                        # WITH bAIS: per-basin BAR, reverse from cold@T
            tvs, ferrs = [], []
            for lb, Wf in fwd[N]:                                    # average over the n_rep independent AIS draws
                dF = np.zeros(nb); ok = True
                for b in range(nb):
                    n_rev = int((lb == b).sum()); pool = cth[cb == b]
                    if n_rev == 0 or len(pool) == 0:
                        ok = False; break
                    starts = pool[rng.integers(0, len(pool), n_rev)]
                    _, lwr = t.ais_switch(starts, 1.0, t.s_hot, m_steps=nes_win, freq=nes_md, rng=rng)
                    dF[b], _ = solve_bar_with_infinite_works(np.where(lb == b, Wf, np.inf), -lwr,
                                                             n_f_total=len(Wf), n_r_total=n_rev)
                if ok:
                    pi_b = np.exp(-(dF - dF.min())); pi_b /= pi_b.sum()   # pi_cold ∝ exp(−ΔF) (correct combination)
                    tvs.append(0.5 * float(np.abs(pi_b - pt).sum())); ferrs.append(free_err(pi_b, pt, ref))
            row[f"tv_bais_{N}"] = round(float(np.mean(tvs)), 3) if tvs else None
            row[f"tvsd_bais_{N}"] = round(float(np.std(tvs)), 3) if tvs else None
            row[f"ferr_bais_{N}"] = round(float(np.mean(ferrs)), 3) if ferrs else None
            row[f"ferrsd_bais_{N}"] = round(float(np.std(ferrs)), 3) if ferrs else None
        rows.append(row)

    res = dict(seed=seed, regime="samplable (A↔B ~7.1 kT — plain cold MD crosses slowly)",
               analytic_pops=[round(x, 3) for x in pt], hot_steps=hot_steps, nes=f"{nes_win}win x {nes_md}MD",
               ais_budgets=list(ais_budgets), checkpoints=rows)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "bais_convergence_toy.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({"analytic": res["analytic_pops"], "first": rows[0], "final": rows[-1]}, indent=2))
    make_figure(checkpoints, rows, ais_budgets, hot_steps, res)
    return res


def make_figure(checkpoints, rows, ais_budgets, hot_steps, res):
    cs = np.array(checkpoints) / 1e6
    fig, ax = plt.subplots(1, 2, figsize=(15, 5.2))
    for axi, key, ylab in [(ax[0], "tv", "population total-variation error"),
                           (ax[1], "ferr", "free-energy RMS error (kT)")]:
        axi.plot(cs, [r[f"{key}_plain"] for r in rows], "-o", c="k", lw=2, label="plain MSM (no bAIS)")
        for i, N in enumerate(ais_budgets):
            col = plt.cm.viridis(0.12 + 0.72 * i / max(len(ais_budgets) - 1, 1))
            y = np.array([r.get(f"{key}_bais_{N}") for r in rows], float)
            sd = np.array([r.get(f"{key}sd_bais_{N}", 0.0) for r in rows], float)
            axi.plot(cs, y, "-s", c=col, label=f"bAIS (BAR), N_NES={N}")
            axi.fill_between(cs, np.clip(y - sd, 1e-4, None), y + sd, color=col, alpha=0.18)
        axi.axvline(hot_steps / 1e6, ls=":", c="C3", alpha=0.7)
        axi.set_xlabel("cold-MD length (M steps)"); axi.set_ylabel(ylab); axi.set_yscale("log")
        axi.legend(fontsize=8)
    ax[0].set_title("population convergence: bAIS reaches its floor at 0.1M hot;\nplain MSM needs many M cold steps",
                    fontsize=10)
    ax[1].set_title("free-energy convergence", fontsize=10)
    fig.suptitle(f"bAIS (BAR-MSM) vs plain cold MSM — 1D toy, {res['regime']}; hot only {hot_steps/1e6:.1f}M, "
                 f"NES {res['nes']}", fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.94])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_bais_convergence_toy.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_convergence_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
