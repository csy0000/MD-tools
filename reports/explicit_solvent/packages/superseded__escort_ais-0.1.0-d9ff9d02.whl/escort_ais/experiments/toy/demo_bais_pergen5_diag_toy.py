#!/usr/bin/env python3
"""demo_bais_pergen5_diag_toy.py — raw per-5th-generation BAIS diagnostics on the 3x kappa-retune toy.

Runs ONE representative seed of the 3x toy (Toy1D(kappa=[70,70,30])) through the generational BAIS protocol with
`pergen_diag=True`, then draws — one ROW per recorded 5th generation (gens 5,10,15,20,25,...) and 3 COLUMNS — the
raw diagnostics that underlie the aggregate per-generation convergence figure:

  (col 1) TRAJECTORY  — each surviving cold walker's THIS-generation cold theta segment (deg, y in -180..180) vs
          step index, coloured by its home basin (B/A1/A2), with the 3 analytic basin bands lightly shaded. As
          generations accumulate the cold walkers fill each basin's sub-well and stay resident.
  (col 2) WORK OVERLAP — overlaid histograms of this generation's forward reduced works W_f (hot->cold) and reverse
          works W_r (cold->hot); the BAR/Crooks overlap panel. Healthy overlap => endpoint-BAR well-conditioned each
          generation. ESS_f/K and ESS_r/K annotated.
  (col 3) RUNNING POPULATIONS — running endpoint-BAR pi (bars B/A1/A2) vs the analytic [0.25,0.42,0.33] (dashed);
          pop-TV annotated. Converges to [0.25,0.42,0.33].

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_pergen5_diag_toy
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import bais_protocol_run, MID3X_KAPPA, AIS_LADDER

ROOT = project_root()
OUT = ROOT / "results/toy"
KAPPA = list(MID3X_KAPPA)                               # 3x kappa-retune [70,70,30]
ANALYTIC = np.array([0.25, 0.42, 0.33])                # [B, A1, A2]
# basin colours, matching the other 3x toy figures (0=B, 1=A1, 2=A2)
BCOL = ["#7a4fb0", "#1f6f1f", "#8fce8f"]
BLAB = ["B", "A1", "A2"]


def _basin_bands(ax):
    """Lightly shade the 3 analytic basin bands (deg) as horizontal spans on a theta(deg) axis."""
    t = Toy1D(kappa=np.asarray(KAPPA, float))
    bnd = np.radians(t.populations()["boundaries_deg"])
    ys = np.linspace(-180.0, 180.0, 1441)
    lab = t.basin_of(np.radians(ys), bnd).astype(int)
    # contiguous runs of the same basin label -> one axhspan each (handles the circular wrap cleanly)
    edges = np.where(np.diff(lab) != 0)[0]
    starts = np.concatenate(([0], edges + 1)); stops = np.concatenate((edges, [len(ys) - 1]))
    for s0, s1 in zip(starts, stops):
        b = int(lab[s0])
        ax.axhspan(ys[s0], ys[s1], color=BCOL[b], alpha=0.08, lw=0)


def _run(seed=4, B=1_500_000):
    """Run the 3x toy with pergen_diag; escalate B until at least 6 fifth-generations are recorded."""
    for Btry in (B, 2_000_000, 3_000_000, 4_500_000):
        r = bais_protocol_run(seed=seed, B=Btry, hot_steps=10000, cold_chunk=10000, n_fwd=100, m_ais=5,
                              kappa=KAPPA, ais_ladder=AIS_LADDER, pergen_diag=True)
        diag = r["pergen_diag"]
        print(f"  B={Btry//1000}k -> n_iter={r['n_iter']}, {len(diag)} fifth-gens "
              f"{[g['gen'] for g in diag]}", file=sys.stderr)
        if len(diag) >= 6:
            return r, Btry
    return r, Btry                                     # fall through with whatever we have


def make_figure(diag, seed=4):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    rows = diag[:7]                                     # up to 7 rows: gens 5,10,...,35
    n = len(rows)
    fig, ax = plt.subplots(n, 3, figsize=(13.5, 2.55 * n), squeeze=False)

    for i, g in enumerate(rows):
        a_tr, a_ov, a_pi = ax[i, 0], ax[i, 1], ax[i, 2]

        # ── col 1: this-gen cold-walker trajectories (deg) coloured by home basin ─────────────────
        try:
            _basin_bands(a_tr)
            homes = g.get("walker_home", [])
            for wtheta, home in zip(g.get("walker_theta", []), homes):
                y = np.degrees(np.asarray(wtheta, float))
                a_tr.plot(np.arange(y.size), y, lw=0.7, color=BCOL[int(home)],
                          label=f"walker@{BLAB[int(home)]}")
            a_tr.set_ylim(-180, 180); a_tr.set_yticks([-180, -90, 0, 90, 180])
            a_tr.set_ylabel(r"$\theta$ (deg)"); a_tr.grid(alpha=0.25)
            a_tr.set_title(f"gen {g['gen']} — budget {g['budget']/1e6:.2f} M   (cold walkers)",
                           fontsize=9, loc="left")
            if homes:
                a_tr.legend(fontsize=6.5, loc="upper right", ncol=max(1, len(homes)))
        except Exception as e:                          # keep the row alive if a panel is empty
            a_tr.text(0.5, 0.5, f"traj n/a\n{e}", transform=a_tr.transAxes, ha="center", va="center", fontsize=7)

        # ── col 2: forward/reverse AIS work overlap (BAR/Crooks conditioning) ─────────────────────
        try:
            Wf = np.asarray(g.get("Wf", []), float); Wr = np.asarray(g.get("Wr", []), float)
            both = np.concatenate([Wf, Wr]) if (Wf.size + Wr.size) else np.zeros(1)
            bins = np.linspace(np.nanmin(both), np.nanmax(both), 26)
            if Wf.size:
                a_ov.hist(Wf, bins=bins, color="#b03030", alpha=0.55, label=r"$W_f$ (hot$\to$cold)")
            if Wr.size:
                a_ov.hist(Wr, bins=bins, color="#3060b0", alpha=0.55, label=r"$W_r$ (cold$\to$hot)")
            a_ov.axvline(0.0, color="k", lw=0.7, ls=":")
            a_ov.set_ylabel("count"); a_ov.grid(alpha=0.25)
            ef = g.get("ess_f", np.nan); er = g.get("ess_r", np.nan)
            Kf = max(Wf.size, 1); Kr = max(Wr.size, 1)
            a_ov.set_title(f"work overlap  (ESS$_f$/K={ef/Kf:.2f}, ESS$_r$/K={er/Kr:.2f})",
                           fontsize=9, loc="left")
            a_ov.legend(fontsize=7, loc="upper right")
        except Exception as e:
            a_ov.text(0.5, 0.5, f"overlap n/a\n{e}", transform=a_ov.transAxes, ha="center", va="center", fontsize=7)

        # ── col 3: running endpoint-BAR pi vs analytic ───────────────────────────────────────────
        try:
            pi = np.asarray(g.get("pi", [np.nan] * 3), float)
            x = np.arange(3)
            a_pi.bar(x, pi, color=BCOL, alpha=0.85, width=0.62)
            for k in range(3):
                a_pi.hlines(ANALYTIC[k], x[k] - 0.36, x[k] + 0.36, color="k", ls="--", lw=1.1)
            a_pi.set_xticks(x); a_pi.set_xticklabels(BLAB)
            a_pi.set_ylim(0, max(0.55, np.nanmax(pi) * 1.15 if np.isfinite(pi).any() else 0.55))
            a_pi.set_ylabel(r"running $\pi$"); a_pi.grid(alpha=0.25, axis="y")
            tv = 0.5 * float(np.nansum(np.abs(pi - ANALYTIC)))
            a_pi.set_title(f"running populations  (pop-TV={tv:.3f})", fontsize=9, loc="left")
        except Exception as e:
            a_pi.text(0.5, 0.5, f"pi n/a\n{e}", transform=a_pi.transAxes, ha="center", va="center", fontsize=7)

    for a in ax[-1, :]:
        a.set_xlabel("")
    ax[-1, 0].set_xlabel("cold step index"); ax[-1, 1].set_xlabel(r"reduced work $W$ ($k_BT$)")
    ax[-1, 2].set_xlabel("basin")

    fig.suptitle(r"3$\times$ $\kappa$-retune toy — per-5th-generation BAIS diagnostics (seed 4)", fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    OUT.mkdir(parents=True, exist_ok=True)
    out = OUT / "fig_bais_pergen5_diag_mid3x_toy.png"
    fig.savefig(out, dpi=150); plt.close(fig)
    print(f"  wrote {out}", file=sys.stderr)
    return out


if __name__ == "__main__":
    r, B = _run(seed=4, B=1_500_000)
    diag = r["pergen_diag"]
    gens = [g["gen"] for g in diag[:7]]
    print(f"  final budget used = {B/1e6:.2f} M; rendering gens {gens}; "
          f"final pi={[round(x,3) for x in r['pi']]} pop-TV={r['pop_tv']:.3f}", file=sys.stderr)
    make_figure(diag, seed=4)
