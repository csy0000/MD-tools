#!/usr/bin/env python3
"""demo_bais_tica_tree_toy.py — hierarchical KCC + TICA state determination and the resulting state tree.

At a fixed cold-walker length T, on the 1-D toy:
  1. KCC (level-1) coarse-grains the pooled cold reservoir into kinetically ISOLATED basins.
  2. Inside each isolated basin, TICA builds the slow coordinate psi2 and its implied timescale t2(lag).
     The basin is SPLIT into two sub-basins iff t2 converges AND t2 > 1/2 T (the local-equilibrium / LEQ test).
  3. The split recurses: each leaf is TICA-tested again (a single well has no slow mode, so it stops).
The output is a STATE TREE: parent->child edges carry the population proportions; sibling (dashed) edges carry
the inter-state implied timescale (the parent's TICA t2 = the timescale that splits its children; the top A<->B
edge uses the analytic Smoluchowski reference since the short walkers do not cross that barrier).

Colours are consistent across the KCC-basin panel, the TICA psi2 panels, and the tree.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_tica_tree_toy [--fast]
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.kcc_split import (level1_kcc, cluster_its_curve, fit_cluster_tica, decide_split,
                                          _split_location, residence_T, residence_segments, leq_valid_mask)

ROOT = project_root()
OUT = ROOT / "results/toy"

# colour families: basin A = greens (leaves A1 dark, A2 light), basin B = purple
COL = {"A": "#3a8f3a", "A1": "#1f6f1f", "A2": "#8fce8f", "B": "#7a4fb0"}


def _feats(traj):
    cols = [wrap(traj[:, k]) for k in range(traj.shape[1])]
    feats = np.vstack([np.column_stack([np.cos(c), np.sin(c)]) for c in cols])
    return feats, [len(c) for c in cols], np.concatenate(cols)


def _lags(T):
    base = max(8, T // 200)
    lags = [base * m for m in (1, 2, 4, 8, 16) if base * m < T // 4]
    return lags if len(lags) >= 2 else [max(4, T // 20), max(8, T // 8)]


def _name(theta_deg):
    d = float(np.degrees(theta_deg)) if abs(theta_deg) < 7 else float(theta_deg)
    if -170 < d < -70:
        return "B"
    if 20 < d < 90:
        return "A1"
    if 90 <= d < 170:
        return "A2"
    return "?"


def analyze(feats, wlens, mask, lags, seed, depth=0, max_depth=2):
    """Recursive TICA/LEQ analysis of a masked cluster.

    A state is split iff its internal t2 converges AND its LEQ-equilibrated residence fraction is below
    1/alpha_split (alpha_split=2): i.e. at least half the time spent in the state is in visits too short
    (< alpha_leq * t2, alpha_leq=10) to internally equilibrate. Short (non-LEQ) residence segments are excluded
    from the LEQ statistics (`leq_valid_mask`), keeping only frames in visits longer than alpha_leq * t2."""
    t2s, _t3s, proj = cluster_its_curve(feats, mask, wlens, lags=lags, seed=seed)
    segs = residence_segments(mask, wlens)
    dec = decide_split(t2s, lags, segs)             # LEQ-confidence gate: split iff t2 converged AND LEQ-frac < 1/alpha_split
    t2 = max(dec["t2"], 1.0)
    valid = leq_valid_mask(mask, wlens, dec["leq_cut"])             # frames in LEQ segments (residence > alpha_leq*t2)
    Tres = int(segs.max()) if segs.size else 0
    node = dict(mask=mask, valid=valid, n=int(mask.sum()), n_valid=int(valid.sum()),
                t2s=t2s, proj=proj, dec=dec, Tres=int(Tres), segs=segs, children=[])
    if dec["split"] and depth < max_depth:
        parts = _split_location(proj, mask, seed=seed)
        if parts is not None:
            for sub in parts:
                node["children"].append(analyze(feats, wlens, sub, lags, seed, depth + 1, max_depth))
    return node


def run(fast=False, seed=0):
    t = Toy1D(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"])
    wells = np.radians(ana["well_centers_deg"])                       # [-120(B), 60(A1), 120(A2)]
    pops = np.array(ana["pops"])                                      # [B, A1, A2] = [.25,.42,.33]
    kin = t.smoluchowski_kinetics(); t_AB, t_A1A2 = float(kin["t_AB"]), float(kin["t_A1A2"])
    truepop = {"B": pops[0], "A1": pops[1], "A2": pops[2], "A": pops[1] + pops[2]}

    T = 700 if fast else 900                                          # short walker so 1/2 T < t_A1A2(=571) -> A splits
    n_per_well = 12 if fast else 18
    seeds0 = np.repeat(wells, n_per_well)                             # n_per_well walkers seeded at each true well
    traj = t.langevin(seeds0, T, 1.0, rng)                           # (T, 3*n_per_well)
    feats, wlens, pooled = _feats(traj)
    lags = _lags(T)
    lag = max(8, T // 200)

    kcc = level1_kcc(feats, wlens, lag=lag, k=20, min_count=5, seed=seed)
    fc = kcc["frame_cluster"]; n_iso = kcc["n_clusters"]

    # analyse each isolated basin; label by majority true basin
    basins = []
    for c in range(n_iso):
        mask = fc == c
        if mask.sum() < 40:
            continue
        node = analyze(feats, wlens, mask, lags, seed)
        maj = np.bincount(t.basin_of(pooled[mask], bnd).astype(int), minlength=3).argmax()
        node["label"] = {0: "B", 1: "A", 2: "A"}[int(maj)]           # coarse A/B for the isolated basin
        basins.append(node)
    # order: A first then B for a stable layout
    basins.sort(key=lambda b: (b["label"] != "A", -b["n"]))

    print(f"  walker_len={T} n_walkers={traj.shape[1]} KCC_iso={n_iso} lags={lags}", file=sys.stderr)
    for b in basins:
        print(f"    basin {b['label']}: n={b['n']} T_res={b['Tres']} t2={b['dec']['t2']:.0f} "
              f"(½T_res={b['Tres']/2:.0f}) split={b['dec']['split']} children={len(b['children'])}", file=sys.stderr)

    OUT.mkdir(parents=True, exist_ok=True)
    make_figure(t, ana, basins, pooled, bnd, T, lags, t_AB, t_A1A2, truepop)
    return basins


def _leaf_name(t, node, pooled, bnd):
    maj = np.bincount(t.basin_of(pooled[node["mask"]], bnd).astype(int), minlength=3).argmax()
    return {0: "B", 1: "A1", 2: "A2"}[int(maj)]


def make_figure(t, ana, basins, pooled, bnd, T, lags, t_AB, t_A1A2, truepop):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.gridspec import GridSpec
    deg = np.degrees(pooled)
    bins = np.linspace(-180, 180, 73)

    # assign a final-leaf label + colour to every pooled frame (for the density panel)
    leaf_of = np.array(["?"] * len(pooled), dtype=object)
    for b in basins:
        if b["children"]:
            for ch in b["children"]:
                leaf_of[ch["mask"]] = _leaf_name(t, ch, pooled, bnd)
        else:
            leaf_of[b["mask"]] = _leaf_name(t, b, pooled, bnd)

    fig = plt.figure(figsize=(19.5, 10.5))
    gs = GridSpec(3, 4, figure=fig, width_ratios=[1.15, 1.0, 1.0, 1.35], hspace=0.42, wspace=0.30)

    # (A) density coloured by final leaf state (consistent colours)
    axd = fig.add_subplot(gs[0, 0])
    for name in ["A1", "A2", "B"]:
        m = leaf_of == name
        if m.any():
            axd.hist(deg[m], bins=bins, color=COL[name], alpha=0.8, label=name)
    axd.set_title(f"(A) cold reservoir → {len(basins)} KCC isolated basins → leaves\n(colours = final states)",
                  fontsize=9)
    axd.set_xlim(-180, 180); axd.set_xlabel("θ (deg)"); axd.set_yticks([]); axd.legend(fontsize=7)

    # per-basin TICA panels; the LEQ threshold is 1/2 of the state's largest RESIDENCE time T_res (not the budget)
    def _t2_panel(ax, node, title, colour):
        half_n = 0.5 * node["Tres"]
        y = np.array([np.nan if v is None else v for v in node["t2s"]], float)
        ax.plot(lags, y, "-o", color=colour, ms=4)
        ax.axhline(half_n, ls="--", c="k", lw=1.1, label=f"½T$_{{res}}$={half_n:.0f}")
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_ylim(20, 5000)
        verdict = "SPLIT (t2>½T$_{res}$)" if node["dec"]["split"] else (
            "LEQ (t2<½T$_{res}$)" if node["dec"]["converged"] else "undersampled")
        ax.set_title(f"{title}: t2={node['dec']['t2']:.0f}, T$_{{res}}$={node['Tres']} → {verdict}", fontsize=8.3)
        ax.set_xlabel("MSM lag"); ax.set_ylabel("t2 (frames)"); ax.legend(fontsize=7, loc="lower right")

    def _psi_panel(ax, node, title, leaf_colours):
        idx = np.where(node["mask"])[0]
        proj = node["proj"]
        if proj is None or len(idx) < 10:
            ax.text(0.5, 0.5, "no TICA coord", ha="center", va="center", transform=ax.transAxes)
            ax.set_title(title, fontsize=8.5); return
        p = np.asarray(proj)[idx]
        if node["children"]:
            for ch, col in zip(node["children"], leaf_colours):
                ci = np.where(ch["mask"])[0]
                # position of child frames within this basin's proj
                pin = np.asarray(proj)[ci]
                ax.hist(pin, bins=30, color=col, alpha=0.8)
        else:
            ax.hist(p, bins=30, color=leaf_colours[0], alpha=0.8)
        ax.set_title(title, fontsize=8.5); ax.set_xlabel("TICA slow coord $\\psi_2$"); ax.set_yticks([])

    basinA = next((b for b in basins if b["label"] == "A"), None)
    basinB = next((b for b in basins if b["label"] == "B"), None)

    if basinA is not None:
        _t2_panel(fig.add_subplot(gs[0, 1]), basinA, "(B) TICA of isolated basin A", COL["A"])
        _psi_panel(fig.add_subplot(gs[0, 2]), basinA, "(C) $\\psi_2$ of A → split A1|A2", [COL["A1"], COL["A2"]])
    if basinB is not None:
        _t2_panel(fig.add_subplot(gs[1, 1]), basinB, "(D) TICA of isolated basin B", COL["B"])
        _psi_panel(fig.add_subplot(gs[1, 2]), basinB, "(E) $\\psi_2$ of B (single well)", [COL["B"]])

    # leaves of A: their own TICA (single wells -> no further split)
    axLt = fig.add_subplot(gs[2, 1]); axLp = fig.add_subplot(gs[2, 2])
    if basinA is not None and basinA["children"]:
        for ch in basinA["children"]:
            nm = _leaf_name(t, ch, pooled, bnd)
            y = np.array([np.nan if v is None else v for v in ch["t2s"]], float)
            axLt.plot(lags, y, "-o", color=COL[nm], ms=4, label=f"{nm} (T$_{{res}}$={ch['Tres']})")
            ci = np.where(ch["mask"])[0]
            if ch["proj"] is not None:
                axLp.hist(np.asarray(ch["proj"])[ci], bins=24, color=COL[nm], alpha=0.75, label=nm)
    axLt.set_xscale("log"); axLt.set_yscale("log"); axLt.set_ylim(20, 5000)
    axLt.set_title("(F) TICA of leaves A1, A2 (single wells → no split)", fontsize=8.5)
    axLt.set_xlabel("MSM lag"); axLt.set_ylabel("t2 (frames)"); axLt.legend(fontsize=7, loc="lower right")
    axLp.set_title("(G) $\\psi_2$ within each leaf (unimodal)", fontsize=8.5)
    axLp.set_xlabel("TICA slow coord $\\psi_2$"); axLp.set_yticks([]); axLp.legend(fontsize=7)

    # (H) the STATE TREE
    axt = fig.add_subplot(gs[:, 3]); axt.axis("off")
    axt.set_xlim(0, 1); axt.set_ylim(0, 1); axt.set_title("(H) resolved state tree", fontsize=10)

    def node_box(x, y, name, pop):
        axt.scatter([x], [y], s=1500, color=COL.get(name, "0.5"), edgecolors="k", zorder=3)
        axt.text(x, y, name, ha="center", va="center", fontsize=11, fontweight="bold", color="w", zorder=4)
        axt.text(x, y - 0.045, f"π={pop:.2f}", ha="center", va="top", fontsize=8, zorder=4)

    def tree_edge(x0, y0, x1, y1, prop):
        axt.plot([x0, x1], [y0, y1], "-", c="0.4", lw=1.6, zorder=1)
        axt.text((x0 + x1) / 2 + 0.02, (y0 + y1) / 2, f"{prop:.2f}", fontsize=8, color="0.25", zorder=2)

    def sib_edge(x0, x1, y, tag, dy=0.045):
        axt.annotate("", xy=(x1, y), xytext=(x0, y),
                     arrowprops=dict(arrowstyle="<->", ls="--", color="#b03030", lw=1.4))
        axt.text((x0 + x1) / 2, y + dy, tag, ha="center", va="bottom", fontsize=7.5, color="#b03030")

    # layout: root (0.5,0.90); A (0.30,0.58) B (0.74,0.58); A1 (0.16,0.18) A2 (0.44,0.18)
    node_box(0.5, 0.90, "root", 1.0)
    node_box(0.30, 0.58, "A", truepop["A"]); node_box(0.74, 0.58, "B", truepop["B"])
    tree_edge(0.5, 0.85, 0.30, 0.63, truepop["A"]); tree_edge(0.5, 0.85, 0.74, 0.63, truepop["B"])
    sib_edge(0.375, 0.665, 0.58, f"t$_{{AB}}$≈{t_AB:.0f} (analytic ref)")
    if basinA is not None and basinA["children"]:
        node_box(0.16, 0.18, "A1", truepop["A1"]); node_box(0.44, 0.18, "A2", truepop["A2"])
        tree_edge(0.30, 0.53, 0.16, 0.23, truepop["A1"] / truepop["A"])
        tree_edge(0.30, 0.53, 0.44, 0.23, truepop["A2"] / truepop["A"])
        sib_edge(0.215, 0.385, 0.18, f"t2≈{basinA['dec']['t2']:.0f} (meas; analytic {t_A1A2:.0f})", dy=0.10)
    axt.text(0.5, 0.04, "tree edges: population proportions · dashed sibling edges: implied timescale (frames)",
             ha="center", fontsize=7.5, color="0.35")

    fig.suptitle("Hierarchical KCC + TICA state determination on the 1-D toy — "
                 "LEQ window T$_{res}$ = each state's largest consecutive residence time (not the budget); "
                 "split iff t2 converges and t2 > ½T$_{res}$ (only residence segments > 2·t2 count as equilibrated)",
                 fontsize=10.5)
    fig.savefig(OUT / "fig_bais_tica_tree_toy.png", dpi=155, bbox_inches="tight"); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_tica_tree_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
