#!/usr/bin/env python3
"""demo_toy_pipeline_diagnostics.py — pipeline diagnostics for the bAIS toy (items 2-5 of the expanded report).

Two figures, both in the samplable regime (A↔B ~7.1 kT), UNIFIED hot ensemble s=0.01 + √s-square AIS ladder:
  fig_toy_hot_ais.png:
    (A) analytic cold P(θ), analytic hot density (s=0.01, nearly uniform), and a HOT-MD histogram.
    (B) hot-MD convergence: TV(hot histogram so far, analytic hot density) vs number of hot frames → the hot
        ensemble equilibrates quickly (its barriers are 0.01× the cold ones).
    (C) forward-AIS landing histogram UNWEIGHTED vs WEIGHTED by w=exp(logw) vs analytic cold P(θ): the raw landings
        are hot-biased; the 10-rung √s-square AIS weights reweight them onto the cold target (fwd ESS reported).
  fig_toy_gmm_us.png:
    (A) a 3-component Gaussian-mixture fit to the cold-AIS landings → basin split (medoids + responsibility
        boundaries).
    (B) the cold potential U_cold(θ) with the flat-bottom umbrella wall drawn for each basin (the US restraint used
        per state in bAIS+US).

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_toy_pipeline_diagnostics
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402
from escort_ais.methods.state_detect import detect_kstar, halfwidths, spring_constants  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])                                  # samplable regime (A↔B ~7.1 kT)
# Unified hot ensemble + AIS ladder (mirrors demo_bais_protocol_convergence_toy.AIS_LADDER; defined locally to keep
# this driver self-contained). s_hot = AIS_LADDER[0] = 0.01, √s-square 0.01 → 1 (10 rungs, 9 annealing steps).
AIS_LADDER = np.linspace(np.sqrt(0.01), 1.0, 10) ** 2
S_HOT = float(AIS_LADDER[0])                                          # = 0.01 (unified hot ensemble; not t.s_hot)
NB = 60                                                              # histogram bins
GMM_BUDGETS = [10, 50, 100]                                          # per-budget GMM-split panels (BAUS-N)
E_TARGET = 8.0                                                       # kT of confinement at the nearest neighbour


def aligned_landings(t, seed=0, hot_steps=100_000, hot_walkers=1):
    """Forward-AIS landings generated IDENTICALLY to demo_toy_ais_landing_sweep (same seed/pool) → consistent K*."""
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    rng = np.random.default_rng(seed)
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, S_HOT, rng)
    hot = wrap(hraw[(hot_steps // hot_walkers) // 20:].reshape(-1))
    xh = hot[rng.integers(0, len(hot), 1024)]
    return t.ais_switch(xh, S_HOT, 1.0, m_steps=len(AIS_LADDER) - 1, freq=1, rng=rng, schedule=AIS_LADDER)


def _hist(theta, bins=NB):
    h, e = np.histogram(theta, bins=bins, range=(-np.pi, np.pi), density=True)
    return 0.5 * (e[:-1] + e[1:]), h


def _tv(p, q, dx):
    return float(0.5 * np.sum(np.abs(p - q)) * dx)


def run(seed=0, hot_steps=100_000, hot_walkers=1, n_ais=4000, m_steps=5, freq=1):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    bnd = np.radians(ana["boundaries_deg"])
    grid = np.linspace(-np.pi, np.pi, 720); deg = np.degrees(grid)
    dx_g = grid[1] - grid[0]
    p_cold = t.p_eq(grid); p_cold /= p_cold.sum() * dx_g
    p_hot = np.exp(-t.U(grid, S_HOT) / t.kT); p_hot /= p_hot.sum() * dx_g   # analytic hot density (s=0.01)
    cg, _ = _hist(np.zeros(2)); dxh = cg[1] - cg[0]
    pc_hist = t.p_eq(cg); pc_hist /= pc_hist.sum() * dxh
    ph_hist = np.exp(-t.U(cg, S_HOT) / t.kT); ph_hist /= ph_hist.sum() * dxh

    # --- HOT ensemble (s=0.01, nearly uniform), seeded across basins + burn ---
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, S_HOT, rng)
    burn = (hot_steps // hot_walkers) // 20
    hot = wrap(hraw[burn:].reshape(-1))

    # --- item 3: hot-MD convergence to the analytic hot density ---
    ns = np.unique(np.geomspace(200, len(hot), 25).astype(int))
    conv = []
    for n in ns:
        _, hh = _hist(hot[:n]); conv.append(_tv(hh, ph_hist, dxh))

    # --- item 4: forward AIS hot→cold along the unified 10-rung √s-square ladder, landings + weights ---
    n_rungs = len(AIS_LADDER) - 1                                    # 9 annealing steps (freq=1 MD step each)
    xh = hot[rng.integers(0, len(hot), n_ais)]
    land, lwf = t.ais_switch(xh, S_HOT, 1.0, m_steps=n_rungs, freq=1, rng=rng, schedule=AIS_LADDER)
    w = np.exp(lwf - lwf.max()); w /= w.sum()
    ess = float(np.exp(lwf).sum() ** 2 / np.exp(2 * lwf).sum())
    _, h_unw = _hist(land)
    h_w, e = np.histogram(land, bins=NB, range=(-np.pi, np.pi), weights=w, density=True)
    tv_unw = _tv(h_unw, pc_hist, dxh); tv_w = _tv(h_w, pc_hist, dxh)

    res = dict(seed=seed, s_hot=S_HOT, regime="samplable (A↔B ~7.1 kT)", ess_fwd=round(ess, 1), n_ais=n_ais,
               hot_steps=int(hot_steps), hot_frames=int(len(hot)), ais_steps=int(n_rungs),
               ais_m_steps=int(n_rungs), ais_freq=1, ais_ladder="√s-square, 10 rungs 0.01→1",
               tv_landings=dict(unweighted=round(tv_unw, 3), weighted=round(tv_w, 3)),
               hot_conv_tv_final=round(conv[-1], 3))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "toy_pipeline_diagnostics.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))

    _fig_hot_ais(deg, p_cold, p_hot, cg, hot, ns, conv, land, w, h_unw, h_w, pc_hist, res, t)
    _fig_gmm_us(t, grid, deg, seed=seed)                              # per-budget GMM split + biased potential
    return res


def _fig_hot_ais(deg, p_cold, p_hot, cg, hot, ns, conv, land, w, h_unw, h_w, pc_hist, res, t):
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))
    # (A) ensembles
    ax[0].plot(deg, p_cold, "k-", lw=2.2, label="analytic cold P(θ)")
    ax[0].plot(deg, p_hot, "-", c="C3", lw=2.2, label=f"analytic hot density (s={S_HOT:g})")
    cgh, hh_hot = _hist(hot)                                          # per-radian density (matches the curves)
    ax[0].bar(np.degrees(cgh), hh_hot, width=360 / NB, color="C3", alpha=0.28, label="hot MD histogram")
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("density"); ax[0].set_xlim(-180, 180)
    ax[0].set_title(f"cold vs hot (s={S_HOT:g}) ensembles — hot MD: {res['hot_steps']//1000}k steps "
                    f"({res['hot_frames']//1000}k after burn)\n(hot barriers are {S_HOT:g}× cold → hot nearly uniform)",
                    fontsize=9.5); ax[0].legend(fontsize=8)
    # (B) hot convergence
    ax[1].loglog(ns, conv, "-o", c="C3")
    ax[1].set_xlabel("hot-MD frames used"); ax[1].set_ylabel("TV(hot MD, analytic hot density)")
    ax[1].set_title(f"hot-MD convergence to the analytic hot density\n(final TV {res['hot_conv_tv_final']} at "
                    f"{len(hot)//1000}k frames)", fontsize=10)
    # (C) AIS landings weighted vs unweighted
    ax[2].plot(deg, pc_hist_grid(t, deg), "k-", lw=2.2, label="analytic cold P(θ)")
    ax[2].bar(np.degrees(cg), h_unw, width=360 / NB, color="0.6", alpha=0.5,
              label=f"landings, UNWEIGHTED (TV {res['tv_landings']['unweighted']})")
    ax[2].bar(np.degrees(cg), h_w, width=360 / NB, color="C0", alpha=0.5,
              label=f"landings, WEIGHTED by e^logw (TV {res['tv_landings']['weighted']})")
    ax[2].set_xlabel("θ (deg)"); ax[2].set_ylabel("P(θ)"); ax[2].set_xlim(-180, 180)
    ax[2].set_title(f"forward-AIS landings → cold target ({res['ais_steps']}-rung √s-square ladder, "
                    f"s={S_HOT:g}→1)\n(reweighting fixes the hot bias; fwd ESS "
                    f"{res['ess_fwd']:.0f}/{res['n_ais']})", fontsize=9.5); ax[2].legend(fontsize=8)
    fig.suptitle("bAIS pipeline diagnostics — hot ensemble & AIS reweighting (1D toy, samplable regime)",
                 fontsize=12)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / "fig_toy_hot_ais.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_toy_hot_ais.png'}", file=sys.stderr)


def pc_hist_grid(t, deg):
    g = np.radians(deg); p = t.p_eq(g); return p / (p.sum() * (g[1] - g[0]))


def _fig_gmm_us(t, grid, deg, seed=0):
    """Per-budget building blocks: for N_AIS = 10/50/100, the weighted AIS landings + GMM split (top row) and the
    per-well flat-bottom biased potential (bottom row). The landing count is stated in each title and drawn as a rug."""
    land, lwf = aligned_landings(t, seed=seed)
    U = t.U_cold(grid); U -= U.min()
    fig, axes = plt.subplots(2, len(GMM_BUDGETS), figsize=(5.3 * len(GMM_BUDGETS), 8.0), sharex=True)
    per_budget = {}
    for j, N in enumerate(GMM_BUDGETS):
        w = np.exp(lwf[:N] - lwf[:N].max()); wn = w / w.sum()
        _, _, Kstar, medoids = detect_kstar(land[:N], lwf[:N], seed=seed)
        hw = halfwidths(medoids)
        kspring = spring_constants(medoids, hw, e_target=E_TARGET)    # distance-calibrated flat-bottom stiffness
        assign = np.argmin(np.abs(wrap(land[:N][:, None] - medoids[None, :])), axis=1)
        cols = plt.cm.tab10(np.linspace(0, 1, Kstar))
        axA, axB = axes[0, j], axes[1, j]
        # --- top: weighted landings histogram + rug + per-well Gaussian component ---
        hh, ee = np.histogram(land[:N], bins=np.linspace(-np.pi, np.pi, 48), weights=wn, density=True)
        axA.bar(np.degrees(0.5 * (ee[:-1] + ee[1:])), hh, width=360 / 48, color="0.8", alpha=0.7,
                label="weighted landings")
        params = []
        for k in range(Kstar):
            m = assign == k; wk = w[m]
            if wk.sum() <= 0:
                continue
            dev = wrap(land[:N][m] - medoids[k])
            sd = max(np.sqrt(np.sum(wk * dev ** 2) / wk.sum()), np.radians(3.0))   # weighted angular std
            comp = (wk.sum() / w.sum()) * np.exp(-0.5 * ((grid - medoids[k]) / sd) ** 2) / (sd * np.sqrt(2 * np.pi))
            axA.plot(deg, comp, lw=1.8, c=cols[k])
            axA.axvline(np.degrees(medoids[k]), ls="--", c=cols[k], alpha=0.7)
            params.append(dict(center_deg=round(float(np.degrees(medoids[k])), 1),
                               hw_deg=round(float(np.degrees(hw[k])), 1), k=round(float(kspring[k]), 1)))
        axA.scatter(np.degrees(land[:N]), np.full(N, -0.15 * hh.max() - 1e-3), s=18 + 80 * (w / w.max()),
                    c=cols[assign], marker="|", linewidths=1.2, clip_on=False, zorder=6)
        axA.set_title(f"N_AIS={N} landings → K*={Kstar} GMM components", fontsize=10)
        axA.set_xlim(-180, 180); axA.set_ylabel("weighted density" if j == 0 else "")
        # --- bottom: U_cold + flat-bottom biased potential per detected well ---
        axB.plot(deg, U, "k-", lw=2.0, label=r"$U_{\mathrm{cold}}$")
        for k in range(Kstar):
            wall = 0.5 * kspring[k] * np.maximum(0.0, np.abs(wrap(grid - medoids[k])) - hw[k]) ** 2
            axB.plot(deg, U + wall, lw=1.5, c=cols[k], alpha=0.9)
            axB.axvspan(np.degrees(medoids[k] - hw[k]), np.degrees(medoids[k] + hw[k]), color=cols[k], alpha=0.10)
        axB.set_ylim(-0.5, U.max() + 3); axB.set_xlim(-180, 180)
        axB.set_xlabel("θ (deg)"); axB.set_ylabel("energy (kT)" if j == 0 else "")
        axB.set_title(f"biased potential per well (k∝1/dist², {np.array2string(np.round(kspring,0), separator=',')}; "
                      f"hw≈{np.degrees(hw).mean():.0f}°)", fontsize=9)
        per_budget[f"N_AIS={N}"] = dict(n_landings=N, K_star=int(Kstar), wells=params)
    axes[0, 0].annotate("│ = AIS landings (size ∝ weight)", (0.03, 0.9), xycoords="axes fraction", fontsize=8,
                        color="0.3")
    fig.suptitle("bAIS+US building blocks — GMM basin split & per-well flat-bottom bias for "
                 "N_AIS = 10/50/100 (1D toy)", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(OUT / "fig_toy_gmm_us.png", dpi=180); plt.close(fig)
    (OUT / "toy_gmm_us_perbudget.json").write_text(json.dumps(per_budget, indent=2))
    print(f"  wrote {OUT / 'fig_toy_gmm_us.png'}", file=sys.stderr)
    print(json.dumps(per_budget, indent=2))


if __name__ == "__main__":
    run()
