#!/usr/bin/env python3
"""demo_bais_generations_toy.py — per-generation BAIS state-determination diagnostic on the 1-D toy.

Runs the BAIS protocol (no burn-in) generation by generation and, for EACH generation, records how the
metastable states are determined and whether within-basin local equilibrium (LEQ) holds:

  (A) AIS + GMM     : the accumulated forward-AIS landings and the GMM/BIC state detector's medoids (K*);
                      a landing far from every current medoid triggers a NEW cold walker.
  (B) cold MD       : the cold reservoir, ONE COLOUR PER WALKER (a walker seeded this generation is tagged NEW).
  (C) KCC           : level-1 kinetic connectivity — KMeans microstates -> lag-tau counts -> connected
                      components = kinetically ISOLATED basins (rate-blind; separates A from B).
  (D) TICA + LEQ    : inside each KCC basin, the TICA slow-coordinate implied timescale t2(lag). The basin is
                      split into sub-basins iff t2 CONVERGES and t2 > T_res/10, where T_res is the state's LARGEST
                      consecutive RESIDENCE time (longest uninterrupted visit), NOT the total budget: a slow
                      internal barrier => NOT LEQ. Converged with t2 < T_res/10 => LEQ (merge). Not converged =>
                      undersampled (conservative no-split). (Short residence segments <= 2 t2 do not equilibrate.)

This is the mechanism figure behind the matched-budget BAIS result: it shows the states being built and the
LEQ test being applied at every iteration.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_generations_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.state_detect import detect_kstar
from escort_ais.methods.kcc_split import level1_kcc, cluster_its_curve, decide_split, residence_segments

ROOT = project_root()
OUT = ROOT / "results/toy"

BASIN_NAME = {0: "B", 1: "A1", 2: "A2"}      # toy basin_of order: 0=B(-120 deg), 1=A1(60), 2=A2(120)
NEW_MEDOID_DEG = 25.0                         # a landing/medoid > this from every walker medoid => new state


def _feats(angles):
    """1-D angle array -> (N,2) (cos,sin) features."""
    a = wrap(np.asarray(angles, float))
    return np.column_stack([np.cos(a), np.sin(a)])


def _lags(T):
    base = max(10, T // 200)
    lags = [base * m for m in (1, 2, 4, 8, 16) if base * m < T // 4]
    return lags if len(lags) >= 2 else [max(5, T // 20), max(10, T // 8)]


def _leq_verdict(dec):
    """decide_split dict -> (label, human) LEQ-confidence verdict for a KCC basin (walker gate)."""
    if dec["split"]:
        return "split", "SPLIT (t2 converged, LEQ-fraction < 1/alpha_split -> not yet confident as one basin)"
    if dec["converged"] and not dec["slow_enough"]:
        return "leq", "LEQ-confident (fast internal mixing, high LEQ-fraction -> one walker)"
    return "under", "undersampled (t2 not converged -> abstain)"


def run(fast=False, gens=5, seed=1):
    t = Toy1D(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); nb = int(ana["n_basins"])
    s_hot = t.s_hot
    hot_steps = 10000                        # a SINGLE hot walker, streamed; T_hot = T_cold = 10k
    n_shot = 30 if fast else 50
    cold_chunk = 6000 if fast else 10000     # T_cold = T_hot = 10k (equal walker length)
    n_detect = 200 if fast else 300          # bounded landing window for GMM/BIC (stable K*, no over-split)
    analysis_win = 14000 if fast else 24000  # fixed cold-frame tail window for KCC/TICA (stable 1/2 T LEQ test)

    hot_pos = t.sample_boltzmann(s_hot, 1, rng)                      # one hot walker, no burn-in
    all_land, all_lw = [], []
    walker_med = []                                                  # per-walker seed medoid (rad)
    walker_frames = []                                               # per-walker list of cold-sample chunks
    cold_pos = np.zeros(0)
    records = []

    for g in range(gens):
        hot_chunk = t.langevin(hot_pos, hot_steps, s_hot, rng); hot_pos = wrap(hot_chunk[-1])
        hot_frames = wrap(hot_chunk[:, 0])                          # hot production (1-walker trajectory)
        xh = hot_frames[rng.integers(0, len(hot_frames), n_shot)]
        land, lw = t.ais_switch(xh, s_hot, 1.0, m_steps=5, freq=1, rng=rng)     # forward AIS
        all_land.append(wrap(land)); all_lw.append(lw)
        land_pool = np.concatenate(all_land); lw_pool = np.concatenate(all_lw)

        # --- (A) GMM/BIC state detection on a BOUNDED recent landing window (stable K*, no over-split) ---
        det_land, det_lw = land_pool[-n_detect:], lw_pool[-n_detect:]
        _, _, kstar, medoids = detect_kstar(det_land, det_lw, seed=seed)
        medoids = np.asarray(medoids, float)
        new_this_gen = []
        for m in medoids:                                           # seed a walker for any uncovered medoid
            if not walker_med or np.min(np.abs(wrap(m - np.array(walker_med)))) > np.radians(NEW_MEDOID_DEG):
                walker_med.append(float(m)); walker_frames.append([]); new_this_gen.append(len(walker_med) - 1)
        n_cold = len(walker_med)
        if new_this_gen:                                            # APPEND new walkers; keep existing positions
            cold_pos = np.concatenate([cold_pos, np.array([walker_med[k] for k in new_this_gen], float)])

        # --- cold MD, one walker per detected state ---
        cold = t.langevin(cold_pos, cold_chunk, 1.0, rng)
        cold_pos = wrap(cold[-1])
        for k in range(n_cold):
            walker_frames[k].append(wrap(cold[:, k]))
        _, _ = t.ais_switch(land_pool[rng.integers(0, len(land_pool), n_shot)], 1.0, s_hot,
                            m_steps=5, freq=1, rng=rng)             # reverse AIS (protocol completeness)

        # --- (C) KCC isolated basins on a FIXED-length tail window of the cold reservoir ---
        # (fixed window => fixed LEQ threshold 1/2 T across generations, so verdicts stabilise once
        #  the states are discovered, instead of drifting to global equilibration as MD accumulates.)
        wtraj = [np.concatenate(f)[-analysis_win:] for f in walker_frames]
        wlens = [len(w) for w in wtraj]
        feats = np.vstack([_feats(w) for w in wtraj])
        T_rep = int(analysis_win)                                   # fixed cold-walker length for the LEQ test
        lag = max(10, T_rep // 200)
        kcc = level1_kcc(feats, wlens, lag=lag, k=20, min_count=5, seed=seed)
        frame_cluster = kcc["frame_cluster"]; n_iso = kcc["n_clusters"]

        # --- (D) TICA within each isolated basin: t2 ladder + split/LEQ verdict ---
        lags = _lags(T_rep)
        pooled = np.concatenate(wtraj)
        coarse = {0: "B", 1: "A", 2: "A"}                           # A1,A2 both belong to the major A basin
        clusters = []
        for c in range(n_iso):
            mask = frame_cluster == c
            if mask.sum() < 40:
                continue
            t2s, _t3s, _ = cluster_its_curve(feats, mask, wlens, lags=lags, seed=seed)
            segs = residence_segments(mask, wlens)                   # residence-segment lengths in the basin
            Tres = int(segs.max()) if segs.size else 0               # largest consecutive residence (for the figure)
            dec = decide_split(t2s, lags, segs)   # LEQ-confidence gate: split iff t2 converged AND LEQ-frac < 1/alpha_split
            label, human = _leq_verdict(dec)
            tb = t.basin_of(pooled[mask], bnd).astype(int)
            names = sorted({coarse[int(b)] for b in np.unique(tb)})  # coarse basins the cluster spans
            spans_A12 = {1, 2}.issubset(set(np.unique(tb)))
            blabel = "+".join(names) + (" (A1,A2)" if spans_A12 else "")
            clusters.append(dict(c=int(c), n=int(mask.sum()), t2s=t2s, t2=dec["t2"], Tres=int(Tres),
                                 split=dec["split"], leq=label, human=human, basin=blabel))
        n_states = sum(2 if cl["split"] else 1 for cl in clusters)  # resolved kinetic states after split
        records.append(dict(gen=g, kstar=int(kstar), medoids_deg=list(np.round(np.degrees(medoids), 1)),
                            new_walkers=new_this_gen,
                            new_medoid_deg=[float(np.degrees(walker_med[k])) for k in new_this_gen],
                            n_cold=n_cold, wlens=wlens,
                            n_iso=int(n_iso), n_states=int(n_states), lags=lags, T_rep=T_rep,
                            land_pool_deg=np.degrees(land_pool),
                            walker_theta=[np.degrees(w) for w in wtraj],
                            frame_cluster=frame_cluster, pooled_deg=np.degrees(pooled),
                            clusters=clusters))
        print(f"  gen {g}: K*={kstar} n_cold={n_cold} new={new_this_gen} "
              f"KCC_iso={n_iso} resolved_states={n_states} "
              f"LEQ={[cl['leq'] for cl in clusters]}", file=sys.stderr)

    OUT.mkdir(parents=True, exist_ok=True)
    _save_json(records, seed)
    make_figure(records, ana)
    return records


def _save_json(records, seed):
    slim = [dict(gen=r["gen"], kstar=r["kstar"], medoids_deg=r["medoids_deg"], new_walkers=r["new_walkers"],
                 n_cold=r["n_cold"], n_iso=r["n_iso"], n_states=r["n_states"], T_rep=r["T_rep"],
                 clusters=[dict(basin=c["basin"], n=c["n"], t2=round(c["t2"], 1), split=c["split"],
                                leq=c["leq"], Tres=c.get("Tres")) for c in r["clusters"]]) for r in records]
    (OUT / "bais_generations_toy.json").write_text(json.dumps(dict(seed=seed, generations=slim), indent=1))


def make_figure(records, ana):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    G = len(records)
    wells = np.array(ana["well_centers_deg"]); bnd_deg = np.array(ana["boundaries_deg"])
    wcol = plt.get_cmap("tab10")
    kcol = plt.get_cmap("Set2")
    fig, ax = plt.subplots(G, 4, figsize=(19.5, 3.5 * G), squeeze=False)
    bins = np.linspace(-180, 180, 73)

    for i, r in enumerate(records):
        # (A) AIS landings (GMM input) + detected medoids (GMM output); new medoid highlighted
        a = ax[i][0]
        a.hist(r["land_pool_deg"], bins=bins, color="#f0c0b0", density=True, label="AIS landings (pool)")
        for m in r["medoids_deg"]:
            is_new = any(abs(m - nm) < 1.0 for nm in r["new_medoid_deg"])
            a.axvline(m, color=("#1f6f1f" if is_new else "#c0392b"),
                      lw=(2.4 if is_new else 1.6), ls=("-" if is_new else "-"))
            if is_new:
                a.plot([m], [a.get_ylim()[1] * 0.9], marker="*", ms=13, color="#1f6f1f")
        a.set_title(f"gen {r['gen']} — (A) AIS+GMM: K*={r['kstar']}"
                    + (f", +{len(r['new_walkers'])} new seed" if r["new_walkers"] else ""), fontsize=9)
        a.set_xlim(-180, 180); a.set_yticks([]); a.set_xlabel("θ (deg)")
        a.legend(fontsize=6, loc="upper center")

        # (B) cold MD, one colour per walker
        b = ax[i][1]
        for k, th in enumerate(r["walker_theta"]):
            tag = " NEW" if k in r["new_walkers"] else ""
            b.hist(th, bins=bins, histtype="stepfilled", alpha=0.45, color=wcol(k % 10),
                   density=True, label=f"walker {k}{tag}")
            if k in r["new_walkers"]:
                b.hist(th, bins=bins, histtype="step", lw=2.0, color=wcol(k % 10), density=True)
        b.set_title(f"(B) cold MD per walker (n_cold={r['n_cold']})", fontsize=9)
        b.set_xlim(-180, 180); b.set_yticks([]); b.set_xlabel("θ (deg)"); b.legend(fontsize=6, loc="upper center")

        # (C) KCC isolated basins
        c = ax[i][2]
        fc = r["frame_cluster"]; pooled = r["pooled_deg"]
        for cl in range(r["n_iso"]):
            m = fc == cl
            if m.sum() < 40:
                continue
            c.hist(pooled[m], bins=bins, histtype="stepfilled", alpha=0.6, color=kcol(cl % 8),
                   density=True, label=f"KCC basin {cl}")
        c.set_title(f"(C) KCC isolated basins: {r['n_iso']}", fontsize=9)
        c.set_xlim(-180, 180); c.set_yticks([]); c.set_xlabel("θ (deg)"); c.legend(fontsize=6, loc="upper center")

        # (D) TICA ITS ladder + LEQ verdict per KCC basin (LEQ threshold = T_res/10, per basin)
        d = ax[i][3]
        lags = np.array(r["lags"], float)
        for cl in r["clusters"]:
            y = np.array([np.nan if v is None else v for v in cl["t2s"]], float)
            col = {"split": "#b03030", "leq": "#2a7f2a", "under": "#888888"}[cl["leq"]]
            d.plot(lags, y, "-o", ms=4, color=col,
                   label=f"{cl['basin']}: {cl['leq']} (t2={cl['t2']:.0f})")
            d.axhline(cl.get("Tres", 0) / 10.0, ls="--", c=col, lw=1.0, alpha=0.6)
        d.set_xscale("log"); d.set_yscale("log"); d.set_ylim(30, 40000)     # common scale across rows
        d.set_title(f"(D) TICA t2(lag) + T$_{{res}}$/10 LEQ → {r['n_states']} state(s)", fontsize=9)
        d.set_xlabel("MSM lag (frames)"); d.set_ylabel("t2 (frames)"); d.legend(fontsize=6, loc="lower right")

    fig.suptitle("BAIS state determination per generation on the 1-D toy — "
                 "(A) AIS+GMM detect states/seeds · (B) cold MD per walker · (C) KCC isolated basins · "
                 "(D) TICA slow-timescale LEQ test (split iff t2 converged and t2 > T$_{res}$/10)", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.985])
    fig.savefig(OUT / "fig_bais_generations_toy.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_bais_generations_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
