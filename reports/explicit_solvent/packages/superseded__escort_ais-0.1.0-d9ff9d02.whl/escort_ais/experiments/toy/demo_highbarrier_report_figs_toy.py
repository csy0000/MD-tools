#!/usr/bin/env python3
"""demo_highbarrier_report_figs_toy.py — figures for the detailed 5x-BARRIER kappa-RETUNE toy report.

Generates the section figures for reports/toy/bAIS_toy_5x.pdf that are NOT the per-generation convergence
(that one is produced by demo_bais_pergen_convergence_toy --hard), the matched-budget head-to-head
(demo_bais_vs_walkers_toy --hard) or the protocol-convergence sweep (demo_bais_protocol_convergence_toy --hard):

  fig_hb_ground_truth.png   §1  the kappa-retuned potential (base [26,26,9] thin vs 5x [114,114,45] bold), cold
                                density with basins shaded + populations PRESERVED [0.25,0.42,0.33], ground-truth table
  fig_hb_hot_ais.png        §2  hot ensemble at s=0.01 + √s-square 10-rung AIS reweighting back to the cold density
  fig_hb_ais_overlap.png    §3  per-rung AIS work, forward/reverse work overlap, and ESS vs (√s) ladder length
  fig_hb_kstar.png          §4  GMM/K* state determination from the AIS landings (all three basins full weight)
  fig_hb_remd_ladder.png    §7  REMD ladder-size sweep (TV / acceptance vs N) + 4-replica per-pair acceptance

The 5x toy is Toy1D(kappa=[114,114,45]) (a von-Mises CONCENTRATION retune, NOT a potential scaling): barriers rise to
A1<->A2 ~ 14.5 kT and A<->B ~ 33 kT — BOTH frozen for cold MD — while the populations are PRESERVED at
[0.25,0.42,0.33]. It uses the UNIFIED s_hot=0.01 √s-square AIS ladder (10 rungs 0.01→1) and the √s-square 4-replica
REMD reference [1.0,0.49,0.16,0.01] (matching demo_bais_pergen_convergence_toy --hard).

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_highbarrier_report_figs_toy
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.state_detect import detect_kstar
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import HARD5X_KAPPA, AIS_LADDER
from escort_ais.experiments.toy.demo_bais_pergen_convergence_toy import REMD_S

OUT = project_root() / "results/toy"
KAPPA = np.asarray(HARD5X_KAPPA, float)                 # 5x kappa-retune [114,114,45] (BOTH barriers frozen, pops preserved)
# UNIFIED ladders: √s-square AIS ladder (10 rungs, s_hot=0.01 → 1) and √s-square 4-replica REMD [1.0,0.49,0.16,0.01].
REMD_LADDER = np.asarray(REMD_S, float)                 # 4 √s replicas, cold (s=1) first
N_REMD = len(REMD_LADDER)
BCOL = {"B": "#7a4fb0", "A1": "#1f6f1f", "A2": "#8fce8f"}
BNAMES = ["B", "A1", "A2"]


def _sqrt_ladder(n):
    """√s-square ladder with n rungs from s_hot=0.01 to cold=1 (matches the unified AIS ladder for n=10)."""
    return np.linspace(np.sqrt(0.01), 1.0, n) ** 2


def _toy():
    return Toy1D(kappa=KAPPA)


def _forward_ais(t, x0, ladder, rng, freq=1):
    """Forward AIS hot->cold along `ladder`, recording per-rung reduced-work increments.
    Returns (landing (K,), logw (K,), rung_work (n_rung, K)) with logw = sum rung_work, rung_work_j = -(Δs)U_cold/kT."""
    theta = wrap(np.array(x0, float)); K = theta.size
    n = len(ladder) - 1
    rw = np.zeros((n, K)); logw = np.zeros(K)
    for j in range(n):
        s_old, s_new = ladder[j], ladder[j + 1]
        dW = (s_new - s_old) * t.U_cold(theta)          # reduced work increment at fixed θ
        rw[j] = -dW / t.kT
        logw += rw[j]
        theta = t.langevin(theta, freq, s_new, rng)[-1] if freq > 0 else theta
    return wrap(theta), logw, rw


def _reverse_ais(t, x0, ladder, rng, freq=1):
    """Reverse AIS cold->hot along `ladder` reversed; returns logw (K,)."""
    theta = wrap(np.array(x0, float)); K = theta.size
    lad = ladder[::-1]; logw = np.zeros(K)
    for j in range(len(lad) - 1):
        s_old, s_new = lad[j], lad[j + 1]
        logw += -((s_new - s_old) * t.U_cold(theta)) / t.kT
        theta = t.langevin(theta, freq, s_new, rng)[-1] if freq > 0 else theta
    return logw


def _ess_frac(logw):
    w = np.exp(logw - logw.max()); s = w.sum()
    return float(s * s / np.sum(w * w) / len(w)) if s > 0 else 0.0


# ─────────────────────────────────────────────────────────────────────────────
def fig_ground_truth():
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    tb, t5 = Toy1D(), _toy()                              # base [26,26,9] vs 5x-retune [114,114,45]
    th = np.linspace(-np.pi, np.pi, 1200)
    Ub, U5 = tb.U_cold(th), t5.U_cold(th)
    p5 = np.exp(-U5 / t5.kT); p5 /= (p5).sum() * (th[1] - th[0])
    ana = t5.populations(); pops = ana["pops"]; bnd = np.radians(ana["boundaries_deg"])
    fig, ax = plt.subplots(1, 3, figsize=(15, 3.6))
    # (A) potential: same wells + weights, much sharper (kappa-retuned) -> 5x higher barriers
    ax[0].plot(np.degrees(th), Ub, color="#999", lw=1.3, label="base $\\kappa=[26,26,9]$")
    ax[0].plot(np.degrees(th), U5, color="#b03030", lw=2.2, label="5$\\times$ $\\kappa=[114,114,45]$")
    ax[0].set_title("$\\kappa$-retune: sharper wells, $5\\times$ barriers"); ax[0].set_xlabel("$\\theta$ (deg)")
    ax[0].set_ylabel("$U_{\\mathrm{cold}}$ ($k_BT$)"); ax[0].legend(fontsize=9); ax[0].grid(alpha=0.3)
    # (B) cold density with basins shaded — populations PRESERVED
    labc = t5.basin_of(th, bnd).astype(int)
    for b, nm in enumerate(BNAMES):
        m = labc == b
        ax[1].fill_between(np.degrees(th), 0, p5, where=m, color=BCOL[nm], alpha=0.5, label=f"${nm}$: {pops[b]*100:.1f}%")
    ax[1].plot(np.degrees(th), p5, color="k", lw=1.2)
    ax[1].set_title("cold density $\\propto e^{-U}$ (pops preserved)"); ax[1].set_xlabel("$\\theta$ (deg)")
    ax[1].set_ylabel("density"); ax[1].legend(fontsize=9, loc="upper right"); ax[1].grid(alpha=0.3)
    # (C) barriers + timescales table
    kin5 = t5.smoluchowski_kinetics(); kinb = tb.smoluchowski_kinetics()
    ax[2].axis("off")
    rows = [("", "base", "5$\\times$ $\\kappa$-retune"),
            ("$\\pi=[B,A_1,A_2]$", "[0.25,0.42,0.33]", f"[{pops[0]:.2f},{pops[1]:.2f},{pops[2]:.2f}]"),
            ("$A_1\\!\\leftrightarrow\\!A_2$ barrier", "$2.9\\,k_BT$", "$14.5\\,k_BT$"),
            ("$A\\!\\leftrightarrow\\!B$ barrier", "$7.1\\,k_BT$", "$33\\,k_BT$"),
            ("$t_{A_1A_2}$ (frames)", f"{kinb['t_A1A2']:.2e}", f"{kin5['t_A1A2']:.2e} (frozen)"),
            ("$t_{AB}$ (frames)", f"{kinb['t_AB']:.2e}", "unresolved ($\\gg\\!10^{14}$)")]
    tab = ax[2].table(cellText=[[a, b, c] for a, b, c in rows], cellLoc="center", loc="center")
    tab.auto_set_font_size(False); tab.set_fontsize(9); tab.scale(1, 1.5)
    ax[2].set_title("analytic ground truth")
    fig.suptitle("5$\\times$-barrier $\\kappa$-retune 1D toy: sharper von-Mises wells ($\\kappa\\!=\\![114,114,45]$) raise "
                 "BOTH barriers $\\sim\\!5\\times$ (both frozen) while PRESERVING the populations $[0.25,0.42,0.33]$", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.94]); fig.savefig(OUT / "fig_hb_ground_truth.png", dpi=160); plt.close(fig)
    print("  wrote fig_hb_ground_truth.png", file=sys.stderr)


def fig_hot_ais(seed=0):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    t = _toy(); rng = np.random.default_rng(seed)
    th = np.linspace(-np.pi, np.pi, 800)
    # hot ensemble at s=0.01 (nearly uniform), cold analytic density
    hot = t.sample_boltzmann(AIS_LADDER[0], 20000, rng)
    p_cold = np.exp(-t.U_cold(th) / t.kT); p_cold /= (p_cold).sum() * (th[1] - th[0])
    p_hot = np.exp(-AIS_LADDER[0] * t.U_cold(th) / t.kT); p_hot /= (p_hot).sum() * (th[1] - th[0])
    # forward AIS from hot starts -> cold, with weights
    x0 = t.sample_boltzmann(AIS_LADDER[0], 8000, rng)
    land, logw, _ = _forward_ais(t, x0, AIS_LADDER, rng)
    w = np.exp(logw - logw.max()); w /= w.sum()
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].hist(hot, bins=60, range=(-np.pi, np.pi), density=True, color="#b03030", alpha=0.5, label="hot MD ($s\\!=\\!0.01$)")
    ax[0].plot(th, p_hot, color="#b03030", lw=1.5); ax[0].plot(th, p_cold, color="k", lw=1.2, ls="--", label="cold target")
    ax[0].set_title("hot ensemble ($s\\!=\\!0.01$): nearly uniform"); ax[0].set_xlabel("$\\theta$ (rad)")
    ax[0].set_ylabel("density"); ax[0].legend(fontsize=8); ax[0].grid(alpha=0.3)
    ax[1].hist(land, bins=60, range=(-np.pi, np.pi), weights=w, density=True, color="#1f6f1f", alpha=0.5,
               label="AIS-reweighted landings")
    ax[1].plot(th, p_cold, color="k", lw=1.4, ls="--", label="analytic cold")
    ax[1].set_title("10-rung $\\sqrt{s}$-square AIS reweight $\\to$ cold"); ax[1].set_xlabel("$\\theta$ (rad)")
    ax[1].set_ylabel("density"); ax[1].legend(fontsize=8); ax[1].grid(alpha=0.3)
    fig.suptitle("Hot ensemble and AIS reweighting on the $5\\times$ $\\kappa$-retune toy: the 10-rung $\\sqrt{s}$-square "
                 "ladder $s=0.01\\to1$ carries the nearly-uniform hot ensemble back to the sharp cold density", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.93]); fig.savefig(OUT / "fig_hb_hot_ais.png", dpi=160); plt.close(fig)
    print("  wrote fig_hb_hot_ais.png", file=sys.stderr)


def fig_ais_overlap(seed=1):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    t = _toy(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    # forward: hot starts -> cold (per-rung work); reverse: cold starts (equilibrated per basin) -> hot
    xh = t.sample_boltzmann(AIS_LADDER[0], 4000, rng)
    land, logwf, rw = _forward_ais(t, xh, AIS_LADDER, rng)
    Wf = -logwf                                                     # reduced forward work
    xc = np.concatenate([t.langevin(np.full(1400, wells[b]), 1, 1.0, rng)[-1] for b in range(3)])
    logwr = _reverse_ais(t, xc, AIS_LADDER, rng); Wr = -logwr
    fig, ax = plt.subplots(1, 3, figsize=(15, 3.7))
    # (A) forward/reverse work overlap (BAR needs overlap of Wf and -Wr)
    lo = min(Wf.min(), (-Wr).min()); hi = max(Wf.max(), (-Wr).max())
    bins = np.linspace(lo, hi, 60)
    ax[0].hist(Wf, bins=bins, density=True, color="#1f6f1f", alpha=0.5, label="forward $W_f$ (hot$\\to$cold)")
    ax[0].hist(-Wr, bins=bins, density=True, color="#b03030", alpha=0.5, label="reverse $-W_r$ (cold$\\to$hot)")
    ax[0].set_title(f"work overlap  (ESS$_f$={_ess_frac(logwf):.2f}, ESS$_r$={_ess_frac(logwr):.2f})")
    ax[0].set_xlabel("reduced work ($k_BT$)"); ax[0].set_ylabel("density"); ax[0].legend(fontsize=8); ax[0].grid(alpha=0.3)
    # (B) per-rung |work| increment (the cold rungs carry the most work)
    ax[1].bar(range(1, len(AIS_LADDER)), np.mean(np.abs(rw), axis=1), color="#7a4fb0", alpha=0.8)
    ax[1].set_xticks(range(1, len(AIS_LADDER)))
    ax[1].set_xticklabels([f"{a:.2f}$\\to${b:.2f}" for a, b in zip(AIS_LADDER[:-1], AIS_LADDER[1:])],
                          rotation=60, fontsize=6.5)
    ax[1].set_title("mean $|$work$|$ per rung"); ax[1].set_ylabel("$\\langle|\\Delta W|\\rangle$ ($k_BT$)"); ax[1].grid(alpha=0.3, axis="y")
    # (C) forward ESS fraction vs number of √s rungs (why 10 rungs, not fewer)
    ess_by_n = []
    ns = [2, 3, 4, 5, 6, 8, 10, 14, 20]
    for n in ns:
        lad = _sqrt_ladder(n)
        _, lw2, _ = _forward_ais(t, t.sample_boltzmann(AIS_LADDER[0], 2000, rng), lad, rng)
        ess_by_n.append(_ess_frac(lw2))
    ax[2].plot(ns, ess_by_n, "-o", color="#1f6f1f")
    ax[2].axvline(10, ls="--", color="#999", lw=1); ax[2].set_title("forward ESS fraction vs number of rungs")
    ax[2].set_xlabel("number of $\\sqrt{s}$ rungs"); ax[2].set_ylabel("ESS / shot"); ax[2].grid(alpha=0.3)
    fig.suptitle("AIS work-overlap and ESS on the $5\\times$ $\\kappa$-retune toy: the coldest rungs carry the largest "
                 "work; a $\\sim\\!10$-rung $\\sqrt{s}$-square ladder keeps forward/reverse overlap usable", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.93]); fig.savefig(OUT / "fig_hb_ais_overlap.png", dpi=160); plt.close(fig)
    print("  wrote fig_hb_ais_overlap.png", file=sys.stderr)


def fig_kstar(seed=2):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    t = _toy(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); pops = ana["pops"]
    xh = t.sample_boltzmann(AIS_LADDER[0], 4000, rng)
    land, logw, _ = _forward_ais(t, xh, AIS_LADDER, rng)
    land = wrap(land); w = np.exp(logw - logw.max()); w /= w.sum()
    _, _, kstar, medoids = detect_kstar(land, logw, seed=seed)
    medoids = wrap(np.asarray(medoids, float)); med_b = t.basin_of(medoids, bnd).astype(int)
    landb = t.basin_of(land, bnd).astype(int)
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    for b, nm in enumerate(BNAMES):
        m = landb == b
        ax[0].scatter(np.degrees(land[m]), np.log(w[m] + 1e-12), s=6, color=BCOL[nm], alpha=0.5,
                      label=f"land in ${nm}$ ($n={int(m.sum())}$)")
    for md in np.degrees(medoids):
        ax[0].axvline(md, ls="--", color="k", lw=1, alpha=0.6)
    ax[0].set_title(f"AIS landings, $K^*={kstar}$ medoids (dashed)"); ax[0].set_xlabel("$\\theta$ (deg)")
    ax[0].set_ylabel("$\\log$ weight"); ax[0].legend(fontsize=7, loc="lower center"); ax[0].grid(alpha=0.3)
    # detected populations from weighted landings vs analytic
    det = np.array([w[landb == b].sum() for b in range(3)])
    x = np.arange(3); ax[1].bar(x - 0.18, det, 0.36, color="#1f6f1f", alpha=0.7, label="AIS-weighted landings")
    ax[1].bar(x + 0.18, pops, 0.36, color="#7a4fb0", alpha=0.7, label="analytic")
    ax[1].set_xticks(x); ax[1].set_xticklabels(BNAMES)
    ax[1].set_title("weighted-landing populations vs analytic"); ax[1].set_ylabel("population")
    ax[1].legend(fontsize=8); ax[1].grid(alpha=0.3, axis="y")
    fig.suptitle(f"State determination from AIS landings ($5\\times$ $\\kappa$-retune toy): all three full-weight "
                 f"basins detected ($K^*={kstar}$) and correctly weighted", fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.93]); fig.savefig(OUT / "fig_hb_kstar.png", dpi=160); plt.close(fig)
    print("  wrote fig_hb_kstar.png", file=sys.stderr)


def _remd_sweep(seed, T_replica, s, exch=100):
    t = _toy(); rng = np.random.default_rng(7000 + seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    s = np.asarray(s, float); nrep = len(s); x = np.array([float(wells[k % 3]) for k in range(nrep)])
    natt = np.zeros(nrep - 1); nacc = np.zeros(nrep - 1); slot0 = []
    for wct in range(int(T_replica // exch)):
        for k in range(nrep):
            seg = t.langevin(np.array([x[k]]), exch, s[k], rng)[:, 0]; x[k] = float(wrap(np.array([seg[-1]]))[0])
            if k == 0:
                slot0.append(wrap(seg))
        for k in range(wct % 2, nrep - 1, 2):
            d = (s[k] - s[k + 1]) * (float(t.U_cold(np.array([x[k + 1]]))[0]) - float(t.U_cold(np.array([x[k]]))[0]))
            natt[k] += 1
            if rng.random() < np.exp(-min(d, 700.0)):
                x[k], x[k + 1] = x[k + 1], x[k]; nacc[k] += 1
    cold = np.concatenate(slot0) if slot0 else np.zeros(0)
    bseq = t.basin_of(cold, bnd).astype(int)
    pi = np.array([np.mean(bseq == b) for b in range(3)]) if bseq.size else np.full(3, np.nan)
    return nacc / np.maximum(natt, 1), pi


def fig_remd_ladder(nseed=3, budget=1_500_000):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    analytic = _toy().populations()["pops"]
    Ns = [4, 5, 6, 8, 10]; minacc = []; tvs = []
    print("  REMD ladder sweep (5x kappa-retune, √s-square ladders 0.01->1):", file=sys.stderr)
    for N in Ns:
        s = _sqrt_ladder(N)[::-1]; accs = []; tv = []
        for sd in range(nseed):
            a, pi = _remd_sweep(sd, budget // N, s)
            accs.append(a); tv.append(0.5 * np.abs(pi - analytic).sum())
        ma = float(np.median(accs, axis=0).min()); mean_a = float(np.median(accs, axis=0).mean())
        mtv = float(np.median(tv))
        minacc.append(ma); tvs.append(mtv)
        print(f"    N={N:2d}  cold_frames={budget//N:>8d}  min_acc={ma:.3f}  mean_acc={mean_a:.3f}  pop_TV={mtv:.3f}",
              file=sys.stderr)
    # per-pair for the chosen N_REMD-replica √s ladder
    sC = REMD_LADDER; npair = len(sC) - 1
    accC = np.median([_remd_sweep(sd, budget // N_REMD, sC)[0] for sd in range(nseed)], axis=0)
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax0 = ax[0]; ax0b = ax0.twinx()
    l1, = ax0.plot(Ns, tvs, "-o", color="#b03030", label="pop-TV ($s\\!=\\!1$)")
    l2, = ax0b.plot(Ns, minacc, "-s", color="#1f6f1f", label="min pair acceptance")
    ax0.axvline(N_REMD, ls="--", color="#999", lw=1); ax0b.axhline(0.2, ls=":", color="#999", lw=1)
    ax0.set_xlabel("number of REMD replicas"); ax0.set_ylabel("pop-TV", color="#b03030")
    ax0b.set_ylabel("min pair acceptance", color="#1f6f1f")
    ax0.set_title("ladder-size sweep (fixed total budget)"); ax0.legend(handles=[l1, l2], fontsize=8, loc="upper center")
    ax0.grid(alpha=0.3)
    ax[1].bar(range(npair), accC, color="#7a4fb0", alpha=0.8)
    ax[1].set_xticks(range(npair)); ax[1].set_xticklabels([f"{sC[k]:.2f}$\\to${sC[k+1]:.2f}" for k in range(npair)], rotation=30, fontsize=7)
    ax[1].axhline(0.2, ls=":", color="#999", lw=1); ax[1].set_ylim(0, 1)
    ax[1].set_title(f"{N_REMD}-replica per-pair acceptance"); ax[1].set_ylabel("acceptance"); ax[1].grid(alpha=0.3, axis="y")
    fig.suptitle("REMD on the $5\\times$ $\\kappa$-retune toy ($\\sqrt{s}$-square 4 replicas): fewer replicas give a "
                 "tighter $s\\!=\\!1$ reference, exchange stays usable", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.93]); fig.savefig(OUT / "fig_hb_remd_ladder.png", dpi=160); plt.close(fig)
    print("  wrote fig_hb_remd_ladder.png", file=sys.stderr)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    fig_ground_truth()
    fig_hot_ais()
    fig_ais_overlap()
    fig_kstar()
    fig_remd_ladder()
    print("all 5x-barrier report figures written", file=sys.stderr)
