#!/usr/bin/env python3
"""demo_baus_bata_vs_multiwalker.py — BAUS-N / BAIS-N vs multi-walker-N at matched budget (auto-detected K* states).

For N_AIS ∈ {10,50,100} (BAUS-N / BAIS-N), and a multi-walker cold-MD baseline (multi-walker-N) spending the SAME
total force-evaluation budget:

  * state identification is AUTOMATIC: GMM+BIC (cos/sin, K=1..10) on the AIS landings → K* medoids → one flat-bottom
    umbrella per detected state (as in Fig. 3-5).
  * BAUS-N: bidirectional annealing + conditional BAR over the K* states → cold P(θ); populations reported over the
    three TRUE basins (integrating the reconstruction) so every method is compared on the same footing.
  * BAIS-N: the BAUS populations feed a fixed-π reversible MSM on the cold trajectories → stationary dist + slow ITS.
  * multi-walker-N: cold MD only (matched total budget), seeded across wells → histogram populations + free-π MSM.

Metrics vs N (median + per-seed over NSEED seeds): population TV to analytic, stationary TV, slow-ITS relative error.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_baus_bata_vs_multiwalker [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402
from escort_ais.methods.baus import reconstruct_pmf  # noqa: E402
from escort_ais.methods.bais import estimate_bais, estimate_msm_free_pi  # noqa: E402
from escort_ais.common.budget import Budget  # noqa: E402
from escort_ais.methods.state_detect import detect_kstar, halfwidths, spring_constants  # noqa: E402

OUT = ROOT / "results/toy"
REGIMES = {"S": np.array([26.0, 26.0, 9.0])}       # the toy system: A↔B ~7.1 kT (cold MD CAN cross)
N_LIST = [10, 50, 100]
E_TARGET = 8.0                                    # kT of flat-bottom confinement at the nearest neighbour


def _tv(p, q):
    if p is None or q is None:                                       # degenerate MSM (e.g. disconnected counts) → NaN
        return float("nan")
    return 0.5 * float(np.abs(np.asarray(p, float) - np.asarray(q, float)).sum())


def basin_pops(P, ctr, dx, bnd, t):
    """Integrate a grid density P(θ) over the three TRUE basins → populations."""
    lab = t.basin_of(ctr, bnd).astype(int)
    return np.array([(P[lab == b] * dx).sum() for b in range(len(bnd))])


def count_matrix(dtrajs, nb, lag):
    C = np.zeros((nb, nb))
    for d in dtrajs:
        if len(d) > lag:
            np.add.at(C, (d[:-lag], d[lag:]), 1.0)
    return C


def replicate(kappa, regime, N, seed, fast=False, *, total=None, n_hot=100_000, m_steps=10, freq=1,
              us_burn=600, n_cold=3, lag=500):
    """One replicate under the FIXED-TOTAL budget policy (default B=1e6):
        hot 0.1M (fixed) + fwd AIS 10N + [ US per K* umbrella (BAUS) | unbiased cold MD (BAIS) ] = remainder
        + rev AIS 10N  =  B.
    The multi-walker baseline also pays the 0.1M hot (same seeding source as BAIS); the single walker starts from
    ONE random well (no hot) and spends all of B on one cold trajectory. BAIS and the multi-walker SHARE one cold
    ensemble — fixed-π (annealed) vs free-π on identical data — isolating what the annealed π buys."""
    t = Toy1D(kappa=kappa); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); bnd = np.radians(ana["boundaries_deg"])
    nb = ana["n_basins"]; pt = np.array(ana["pops"]); kin = t.smoluchowski_kinetics()
    its_true = float(kin["t_AB"])                                       # slowest 3-state process (A↔B)
    NG = 120; edges = np.linspace(-np.pi, np.pi, NG + 1); ctr = 0.5 * (edges[:-1] + edges[1:]); dx = ctr[1] - ctr[0]

    if total is None:
        total = 1_000_000 if not fast else 300_000
    us_walk = 1
    remainder = total - n_hot - 20 * N                                 # BAUS US / BAIS cold middle slot

    # --- hot (fixed 0.1M) + forward AIS (N shots × 10 steps) ---
    hot = t.sample_boltzmann(t.s_hot, n_hot, rng)
    xh = hot[rng.integers(0, len(hot), N)]
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=m_steps, freq=freq, rng=rng); Wf = -lwf

    # --- K* states + per-umbrella US sampling (remainder / K*) + reverse AIS ---
    _, _, Kstar, medoids = detect_kstar(land, lwf, seed=seed)
    hw = halfwidths(medoids); kspring = spring_constants(medoids, hw, e_target=E_TARGET)
    bof = lambda th, med: np.argmin(np.abs(wrap(np.atleast_1d(th)[:, None] - np.asarray(med)[None, :])), axis=1)
    land_basin = bof(land, medoids)
    us_steps = max(2000, remainder // Kstar)                           # BAUS US budget: remainder / K*
    us_samples, Wr, rev_start = [], [], []
    for k in range(Kstar):
        us = t.us_sample(medoids[k], hw[k], us_steps, rng, k=float(kspring[k]), burn=us_burn, walkers=us_walk)
        us_samples.append(us)
        us_in = us[bof(us, medoids) == k]
        st = us_in[rng.integers(0, len(us_in), min(len(us_in), max(N, 50)))] if len(us_in) else us_in
        if len(st):
            _, lwr = t.ais_switch(st, 1.0, t.s_hot, m_steps=m_steps, freq=freq, rng=rng)
            Wr.append(-lwr); rev_start.append(np.full(len(lwr), k))
    Wr = np.concatenate(Wr); rev_start = np.concatenate(rev_start)

    # --- BAUS-N reconstruction (K* states) → populations over the 3 true basins ---
    baus = reconstruct_pmf(ctr, edges, Wf, land_basin, Wr, rev_start, us_samples, Kstar, medoids, bof, rng=rng)
    pi_baus3 = basin_pops(baus["P"], ctr, dx, bnd, t); pi_baus3 = pi_baus3 / pi_baus3.sum()

    # --- ONE unbiased cold ensemble: K* walkers (one per DETECTED medoid, not a fixed 3), (B−0.1M)/K* steps
    #     each, SHARED by BAIS (fixed-π) and multi-walker (free-π) — the SAME trajectories, differing only in
    #     the π treatment. Both pay the 0.1M hot. ---
    n_cold = Kstar
    cold_len = max(lag + 10, (total - n_hot) // n_cold)
    cold = t.langevin(medoids, cold_len, 1.0, rng)                     # one cold walker per detected state (K*)
    cold_dtrajs = [t.basin_of(wrap(cold[:, k]), bnd).astype(int) for k in range(cold.shape[1])]
    C_cold = count_matrix(cold_dtrajs, nb, lag)
    bata = estimate_bais(C_cold, pi_baus3, lag=lag)                    # BAIS-N: fixed-π (annealed)
    pi_multi3 = np.array([np.mean([np.mean(d == b) for d in cold_dtrajs]) for b in range(nb)])
    pi_multi3 = pi_multi3 / pi_multi3.sum()
    msm = estimate_msm_free_pi(C_cold, lag=lag)                        # multi-walker-N: free-π on the SAME cold

    # --- single walker from a RANDOM well, all of B on one cold trajectory (no hot) ---
    start_basin = int(np.random.default_rng(seed + 555).integers(0, nb))
    single = wrap(t.langevin(np.array([wells[start_basin]]), total, 1.0, np.random.default_rng(seed + 999))[:, 0])
    sd = t.basin_of(single, bnd).astype(int)
    pi_single3 = np.array([np.mean(sd == b) for b in range(nb)]); pi_single3 = pi_single3 / pi_single3.sum()
    msm_s = estimate_msm_free_pi(count_matrix([sd], nb, lag), lag=lag)

    def relerr(x):
        return abs(x - its_true) / its_true if (x is not None and np.isfinite(x)) else np.nan

    budget = dict(hot=int(n_hot), fwd_ais=10 * N, us=int(Kstar * us_steps), rev_ais=10 * N,
                  cold=int(n_cold * cold_len), n_cold=int(n_cold), total=int(total),
                  us_steps=int(us_steps), cold_len=int(cold_len))
    T = bata.get("T"); T = (np.asarray(T, float).tolist() if T is not None else None)
    return dict(regime=regime, N=N, seed=seed, K_star=int(Kstar), total_budget=int(total), start_basin=start_basin,
                budget=budget, bata_T=T, msm_T=(np.asarray(msm.get("T"), float).tolist() if msm.get("T") is not None else None),
                pop_tv=dict(baus=_tv(pi_baus3, pt), multi=_tv(pi_multi3, pt), single=_tv(pi_single3, pt)),
                stat_tv=dict(bata=_tv(bata["pi"], pt), multi=_tv(msm["pi"], pt), single=_tv(msm_s["pi"], pt)),
                its_relerr=dict(bata=relerr(bata["its"]), multi=relerr(msm["its"]), single=relerr(msm_s["its"])),
                its_true=float(its_true))


def main(fast=False, nseed=8):
    seeds = list(range(2 if fast else nseed))
    raw = []
    for regime, kappa in REGIMES.items():
        for N in N_LIST:
            for s in seeds:
                raw.append(replicate(kappa, regime, N, s, fast=fast))
                r = raw[-1]
                print(f"[{regime}] N={N:3d} seed={s} K*={r['K_star']} | popTV baus {r['pop_tv']['baus']:.3f} "
                      f"multi {r['pop_tv']['multi']:.3f} single {r['pop_tv']['single']:.3f} | "
                      f"statTV bata {r['stat_tv']['bata']:.3f} multi {r['stat_tv']['multi']:.3f} "
                      f"single {r['stat_tv']['single']:.3f}", file=sys.stderr)

    def agg(regime, key, sub):
        return {N: np.array([r[key][sub] for r in raw if r["N"] == N and r["regime"] == regime], float)
                for N in N_LIST}

    OUT.mkdir(parents=True, exist_ok=True)
    summary = {reg: {N: dict(K_star=int(np.median([r["K_star"] for r in raw if r["N"] == N and r["regime"] == reg])),
                             pop_tv_baus=float(np.nanmedian(agg(reg, "pop_tv", "baus")[N])),
                             pop_tv_multi=float(np.nanmedian(agg(reg, "pop_tv", "multi")[N])),
                             pop_tv_single=float(np.nanmedian(agg(reg, "pop_tv", "single")[N])),
                             stat_tv_bata=float(np.nanmedian(agg(reg, "stat_tv", "bata")[N])),
                             stat_tv_multi=float(np.nanmedian(agg(reg, "stat_tv", "multi")[N])),
                             stat_tv_single=float(np.nanmedian(agg(reg, "stat_tv", "single")[N])),
                             its_relerr_bata=float(np.nanmedian(agg(reg, "its_relerr", "bata")[N])),
                             its_relerr_multi=float(np.nanmedian(agg(reg, "its_relerr", "multi")[N])))
                     for N in N_LIST} for reg in REGIMES}
    (OUT / "baus_bata_vs_multiwalker.json").write_text(json.dumps(
        dict(n_seeds=len(seeds), N_list=N_LIST, summary=summary, raw=raw), indent=2))
    make_figure(agg)
    print("done", file=sys.stderr)


def _panel(ax, agg, regime, key, subs_labels, title, ylabel, ymax=None):
    cols = {"baus": "#2a7f2a", "bata": "#2a7f2a", "multi": "#b03030", "single": "#7a4fb0"}
    for si, (sub, lab) in enumerate(subs_labels):
        med = [np.nanmedian(agg(regime, key, sub)[N]) for N in N_LIST]
        off = 1 + 0.06 * (si - (len(subs_labels) - 1) / 2)             # index-based jitter so all series are visible
        for N in N_LIST:
            pts = agg(regime, key, sub)[N]
            if ymax is not None:
                pts = np.clip(pts, None, ymax)
            ax.scatter([N * off] * len(pts), pts, s=14, c=cols[sub], alpha=0.35)
        ax.plot(N_LIST, med, "-o", c=cols[sub], ms=6, label=lab)
    ax.set_xscale("log"); ax.set_xticks(N_LIST); ax.set_xticklabels(N_LIST)
    ax.set_xlabel("N  (AIS shots for BAUS/BAIS; matched budget for multi-walker)", fontsize=8)
    ax.set_ylabel(ylabel); ax.set_title(title, fontsize=10); ax.legend(fontsize=8)
    if ymax is not None:
        ax.set_ylim(0, ymax * 1.05)


def make_figure(agg):
    rows = list(REGIMES)
    fig, ax = plt.subplots(len(rows), 3, figsize=(16, 4.5 * len(rows)), squeeze=False)
    for i, reg in enumerate(rows):
        _panel(ax[i, 0], agg, reg, "pop_tv",
               [("baus", "BAUS-N"), ("multi", "multi-walker-N"), ("single", "single-walker-N (1 basin)")],
               "(1) BAUS-N — populations (thermodynamics)", "population TV")
        _panel(ax[i, 1], agg, reg, "stat_tv",
               [("bata", "BAIS-N (π ≡ BAUS-N)"), ("multi", "multi-walker-N"), ("single", "single-walker-N")],
               "(2) BAIS-N — stationary vs free-π MSM", "stationary TV")
        _panel(ax[i, 2], agg, reg, "its_relerr",
               [("bata", "BAIS-N"), ("multi", "multi-walker-N"), ("single", "single-walker-N")],
               "(3) BAIS-N — kinetics (slow ITS); BAUS-N: none", "slow-ITS rel. error", ymax=1.5)
    fig.suptitle("BAUS-N (thermodynamics) and BAIS-N (kinetics) vs multi/single-walker-N at matched budget — 1D toy\n"
                 "BAIS-N reuses the BAUS-N annealed π (panels 1≡2 green); its distinct result is the kinetics (panel 3)."
                 "  8 seeds; dots per-seed, ITS clipped at 1.5", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / "fig_baus_bata_vs_multiwalker.png", dpi=170); plt.close(fig)
    print(f"  wrote {OUT / 'fig_baus_bata_vs_multiwalker.png'}", file=sys.stderr)


def figure_only():
    """Remake the comparison figure from the saved raw metrics (no MD re-run)."""
    raw = json.load(open(OUT / "baus_bata_vs_multiwalker.json"))["raw"]

    def agg(regime, key, sub):
        return {N: np.array([r[key][sub] for r in raw if r["N"] == N and r["regime"] == regime], float)
                for N in N_LIST}
    make_figure(agg)


if __name__ == "__main__":
    if "--figure-only" in sys.argv:
        figure_only()
    else:
        main(fast="--fast" in sys.argv)
