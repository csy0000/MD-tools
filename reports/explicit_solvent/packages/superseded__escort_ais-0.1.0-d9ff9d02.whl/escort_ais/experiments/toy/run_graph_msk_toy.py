"""run_graph_msk_toy.py — Phase-1 validation of the graph-based BAUS-MSK method
on the 1D toy (design: claude-instruction/20260112_BAISUS_workflow_gpt56.md).

The advantage it demonstrates (honestly)
-----------------------------------------
The A-basin is split into two sub-wells A1/A2 by an internal barrier. Two routes
to the A1↔A2 relative free energy Δf(A1,A2):

  * STAR ("current BAUS"): one soft umbrella per kinetic basin, each tied to the
    hot state by its own finite-time AIS edge. Δf(A1,A2) is the DIFFERENCE of two
    independent hot→window AIS-BAR estimates. Each is informed only by the AIS
    shots that LAND in that tight sub-well, so the difference is noisy when AIS is
    sparse.

  * GRAPH MSK: tile the A-basin with overlapping soft windows (A1, mid, A2) and
    add INSTANTANEOUS window↔window edges (A1↔mid↔A2). These are computed from the
    equilibrium umbrella samples we ALREADY generate (they seed the reverse AIS
    legs), need only spatial OVERLAP — not a barrier crossing or an AIS landing —
    and telescope to Δf(A1,A2) along the tiling. One global GLS solve then pins the
    split at low variance, essentially independent of the AIS budget.

So we SWEEP the AIS budget N_shot. At generous budget both routes agree (bAIS is
well-conditioned here — that is the whole point of BAUS). As N_shot falls, the
STAR error climbs (few shots reach each sub-well) while the GRAPH error stays
flat: the graph decouples the internal-split accuracy from AIS quality, at
near-zero extra cost. Across the big A↔B barrier there is NO overlapping-window
path, so B stays connected only by its AIS edge — the two edge types are
complementary, not competing.

Outputs: results/toy/graph_msk_toy.json, results/toy/fig_graph_msk_toy.png,
results/toy/graph_msk_toy_results.md
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

from escort_ais.methods import graph_msk as gm            # noqa: E402
from escort_ais.systems.toy1d import Toy1D, REGIMES       # noqa: E402

OUT = Path(__file__).resolve().parents[2] / "results" / "toy"
OUT.mkdir(parents=True, exist_ok=True)

HW = np.radians(26.0)     # flat-bottom half-width for the isolated basin B
KH = 25.0                 # harmonic spring for the A1→A2 string (kT/rad²; std≈11.5°)
KW = 60.0
# A1→A2 tiled by a 15°-spaced harmonic string that steps ACROSS the internal
# barrier at 90°; B is an isolated flat-bottom basin (no overlap path to A).
STRING = ["A1", "s75", "mid", "s105", "A2"]               # centers 60..120
STRING_DEG = dict(A1=60.0, s75=75.0, mid=90.0, s105=105.0, A2=120.0)
ORDER = STRING + ["B"]                                    # node 0 reserved for H


def make_windows():
    wins = {}
    for i, name in enumerate(STRING):
        wins[name] = gm.Window(np.radians(STRING_DEG[name]), 0.0, KH,
                               node_id=i + 1, label=name, harmonic=True)
    wins["B"] = gm.Window(np.radians(-120.0), HW, KW, node_id=len(STRING) + 1, label="B")
    return wins


def us_pool(toy, win, n_steps, rng, walkers=16, burn=1000):
    """Equilibrium umbrella samples for either window kind."""
    if not win.harmonic:
        return toy.us_sample(win.center, win.halfwidth, n_steps, rng, k=win.k,
                             walkers=walkers, burn=burn)
    c = win.center
    x = gm._wrap(c + rng.normal(0.0, 1.0 / np.sqrt(win.k), walkers))
    D = toy.kT / toy.gamma; noise = np.sqrt(2 * D * toy.dt)
    out = []
    for t in range(burn + n_steps):
        force = toy.dU(x, 1.0) + win.k * gm._wrap(x - c)
        x = gm._wrap(x - force / toy.gamma * toy.dt + noise * rng.standard_normal(walkers))
        if t >= burn:
            out.append(x.copy())
    return gm._wrap(np.array(out).reshape(-1))


def analytic_window_f(toy, win, ngrid=8000):
    c, _, h = toy._grid(ngrid)
    u = toy.U_cold(c) + gm.flatbottom_bias(c, win)
    return -np.log(np.sum(np.exp(-u)) * h)


def hot_edge(toy, win, x_hot_all, x_win_pool, m_steps, freq, n_shot, rng):
    """Hot↔window AIS BAR edge at AIS budget n_shot (forward + reverse shots).
    Reverse legs start from the fixed equilibrium umbrella pool x_win_pool."""
    x_hot = x_hot_all[:n_shot]
    land, logw_f = toy.ais_switch(x_hot, toy.s_hot, 1.0, m_steps, freq, rng)
    Wf = -logw_f + gm.bias(land, win)                              # W_{H→C}+w(x_end)
    x0 = rng.choice(x_win_pool, size=min(n_shot, x_win_pool.size), replace=False)
    _, logw_r = toy.ais_switch(x0, 1.0, toy.s_hot, m_steps, freq, rng)
    Wr = -gm.bias(x0, win) + (-logw_r)                             # −w(x_start)+W_{C→H}
    df, var = gm.bar_bootstrap(Wf, Wr, n_boot=30, seed=int(win.center * 1e4) % 9999)
    return df, var, gm.work_overlap(Wf, Wr)


def inst_edge(toy, wa, wb, sa, sb, seed):
    wf, wr = gm.instantaneous_works(sa, sb, wa, wb)
    df, var = gm.bar_bootstrap(wf, wr, n_boot=30, seed=seed)
    return df, var, gm.work_overlap(wf, wr)


def run_seed(regime, seed, m_steps, freq, budgets, us_n):
    """One seed: fixed umbrella pools + a large hot pool, then evaluate STAR and
    GRAPH Δf(A1,A2) at each AIS budget (nested, so the pools are shared)."""
    toy = Toy1D(kappa=np.asarray(REGIMES[regime]["kappa"], float))
    rng = np.random.default_rng(seed)
    wins = make_windows()
    n_nodes = len(ORDER) + 1

    f_hot = -np.log(toy.partition_function(toy.s_hot))
    f_true = {n: analytic_window_f(toy, wins[n]) - f_hot for n in ORDER}
    d_true = f_true["A2"] - f_true["A1"]

    # fixed equilibrium umbrella pools (persistent walkers we run anyway)
    pool = {n: us_pool(toy, wins[n], us_n, rng) for n in ORDER}
    # instantaneous string edges A1→s75→mid→s105→A2 (AIS-independent, from pools)
    inst_edges = []
    for a, b in zip(STRING[:-1], STRING[1:]):
        df, var, ovl = inst_edge(toy, wins[a], wins[b], pool[a], pool[b], seed + hash((a, b)) % 997)
        inst_edges.append(gm.Edge(wins[a].node_id, wins[b].node_id, df, var, "inst", ovl))
    df_dir, _, ovl_direct = inst_edge(toy, wins["A1"], wins["A2"], pool["A1"], pool["A2"], seed + 7)
    ovl_inst = float(np.mean([e.ovl for e in inst_edges]))

    hot_nodes = ["A1", "A2", "B"]                            # "kinetic basins" get hot edges
    x_hot_all = toy.sample_boltzmann(toy.s_hot, max(budgets), rng)
    rows = []
    for nb in budgets:
        ais_edges, ovl_ais, nland = [], {}, {}
        for n in hot_nodes:
            df, var, ovl = hot_edge(toy, wins[n], x_hot_all, pool[n], m_steps, freq, nb, rng)
            ais_edges.append(gm.Edge(0, wins[n].node_id, df, var, "ais", ovl))
            ovl_ais[n] = ovl
        land, _ = toy.ais_switch(x_hot_all[:nb], toy.s_hot, 1.0, m_steps, freq,
                                 np.random.default_rng(seed + 1))
        dev = np.abs(gm._wrap(land - wins["A2"].center))
        nland["A2"] = int(np.sum(dev <= np.radians(15.0)))
        # STAR: hot→basin edges only. GRAPH: + instantaneous A1→A2 string.
        f_star = gm.graph_gls_solve(n_nodes, ais_edges, ref=0)
        f_graph = gm.graph_gls_solve(n_nodes, ais_edges + inst_edges, ref=0)
        j1, j2 = wins["A1"].node_id, wins["A2"].node_id
        rows.append(dict(
            n_shot=nb,
            dA1A2_star=float(f_star[j2] - f_star[j1]),
            dA1A2_graph=float(f_graph[j2] - f_graph[j1]),
            ovl_ais_A2=float(ovl_ais["A2"]), n_land_A2=nland["A2"],
        ))
    return dict(regime=regime, seed=seed, d_true=float(d_true), f_true=f_true,
                ovl_inst=ovl_inst, ovl_direct=float(ovl_direct), rows=rows)


def main(fast=False):
    seeds = [0, 1, 2] if fast else list(range(8))
    budgets = [40, 120, 400] if fast else [30, 60, 120, 250, 600]
    m_steps = 120 if fast else 250
    us_n = 6000 if fast else 12000
    freq = 2
    raw = []
    for regime in ("S",):
        for seed in seeds:
            r = run_seed(regime, seed, m_steps, freq, budgets, us_n)
            raw.append(r)
            lo = r["rows"][0]
            print(f"[{regime} s{seed}] N={lo['n_shot']}: star Δ={lo['dA1A2_star']:+.2f} "
                  f"graph Δ={lo['dA1A2_graph']:+.2f} (true {r['d_true']:+.2f}); "
                  f"A2 landings={lo['n_land_A2']}, ovl_inst={r['ovl_inst']:.2f}")
    (OUT / "graph_msk_toy.json").write_text(json.dumps(dict(budgets=budgets, raw=raw), indent=1))
    make_figure(raw, budgets)
    write_results_md(raw, budgets)


# ── figure + text ────────────────────────────────────────────────────────────
def _rmse(raw, regime, nb, key):
    d_true = next(r["d_true"] for r in raw if r["regime"] == regime)
    vals = np.array([row[key] for r in raw if r["regime"] == regime
                     for row in r["rows"] if row["n_shot"] == nb])
    return float(np.sqrt(np.mean((vals - d_true) ** 2)))


def make_figure(raw, budgets):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    toys = {"S": Toy1D(kappa=np.asarray(REGIMES["S"]["kappa"], float))}
    wins = make_windows()
    fig, ax = plt.subplots(1, 3, figsize=(17, 4.7), squeeze=False)
    th = np.linspace(-np.pi, np.pi, 800)

    for row, reg, tag in [(0, "S", "A1↔A2 ~2.9 kT")]:
        toy = toys[reg]
        # col0: potential + harmonic string tiling A1→A2 + isolated basin B
        a = ax[row, 0]
        a.plot(np.degrees(th), toy.U_cold(th), "k-", lw=2, label="cold $U(θ)$")
        for name in STRING:
            w = wins[name]; cd = np.degrees(w.center)
            std = np.degrees(1.0 / np.sqrt(w.k))
            a.axvspan(cd - std, cd + std, color="tab:purple", alpha=0.13)
            a.axvline(cd, color="tab:purple", ls=":", lw=1)
        a.axvspan(np.degrees(wins["B"].center - wins["B"].halfwidth),
                  np.degrees(wins["B"].center + wins["B"].halfwidth), color="tab:red", alpha=0.15)
        for name, lab in [("A1", "A1"), ("A2", "A2"), ("B", "B")]:
            w = wins[name]
            a.text(np.degrees(w.center), float(toy.U_cold(np.array([w.center]))[0]) - 0.7, lab,
                   ha="center", fontweight="bold", fontsize=11,
                   color="tab:red" if name == "B" else "tab:purple")
        a.annotate("", xy=(120, 4.7), xytext=(60, 4.7),
                   arrowprops=dict(arrowstyle="<->", color="purple", lw=2))
        a.text(90, 4.85, "harmonic string (instantaneous edges)", color="purple", ha="center", fontsize=8)
        a.text(-120, 4.85, "AIS only\n(no overlap path)", color="tab:red", ha="center", fontsize=8)
        a.set_title(f"({'AB'[row]}1) window tiling — {tag}")
        a.set_xlabel("θ (deg)"); a.set_ylabel("U / kT"); a.set_xlim(-180, 180)
        if row == 0:
            a.legend(loc="upper left", fontsize=8)

        # col1: Δf(A1,A2) RMSE vs AIS budget — the money plot
        a = ax[row, 1]
        rs = np.array([_rmse(raw, reg, nb, "dA1A2_star") for nb in budgets])
        rg = np.array([_rmse(raw, reg, nb, "dA1A2_graph") for nb in budgets])
        a.plot(budgets, rs, "o-", color="tab:orange", lw=2, label="STAR (current BAUS)")
        a.plot(budgets, rg, "s-", color="tab:purple", lw=2, label="GRAPH MSK (instantaneous edges)")
        a.set_xscale("log"); a.set_xlabel("AIS budget  $N_\\mathrm{shot}$ per window")
        a.set_ylabel("Δf(A1,A2) RMSE / kT"); a.set_ylim(bottom=0)
        a.set_title(f"({'AB'[row]}2) internal-split error vs AIS budget")
        if row == 0:
            a.legend(fontsize=8)

        # col2: per-seed scatter at the LOWEST budget
        a = ax[row, 2]
        d_true = next(r["d_true"] for r in raw if r["regime"] == reg)
        nb = budgets[0]
        star = np.array([row_["dA1A2_star"] for r in raw if r["regime"] == reg
                         for row_ in r["rows"] if row_["n_shot"] == nb])
        graph = np.array([row_["dA1A2_graph"] for r in raw if r["regime"] == reg
                          for row_ in r["rows"] if row_["n_shot"] == nb])
        jit = np.random.default_rng(0).normal(0, 0.04, star.size)
        a.axhline(d_true, color="k", lw=2, label="analytic")
        a.scatter(jit, star, color="tab:orange", alpha=0.7, label="STAR")
        a.scatter(1 + jit, graph, color="tab:purple", alpha=0.7, label="GRAPH")
        a.plot([-.3, .3], [np.median(star)] * 2, color="tab:orange", lw=3)
        a.plot([.7, 1.3], [np.median(graph)] * 2, color="tab:purple", lw=3)
        a.set_xticks([0, 1]); a.set_xticklabels([f"STAR\nN={nb}", f"GRAPH\nN={nb}"])
        a.set_ylabel("Δf(A1,A2) / kT")
        a.set_title(f"({'AB'[row]}3) per-seed spread at N={nb}")
        if row == 0:
            a.legend(fontsize=8, loc="best")

    fig.suptitle(
        "Graph-based BAUS-MSK vs current star BAUS on the 1D toy — recovering the A1↔A2 internal split\n"
        "Instantaneous window↔window edges get the split from cheap equilibrium umbrella samples, so the graph "
        "solve stays accurate as the AIS budget falls, where the star (AIS-difference) degrades.",
        fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / "fig_graph_msk_toy.png", dpi=130)
    print("wrote", OUT / "fig_graph_msk_toy.png")


def write_results_md(raw, budgets):
    lines = ["# Graph-based BAUS-MSK on the 1D toy — Phase-1 result", "",
             "Δf(A1,A2) RMSE (kT) vs AIS budget, median over 8 seeds.", ""]
    for reg, tag in [("S", "toy")]:
        d_true = next(r["d_true"] for r in raw if r["regime"] == reg)
        ovl_inst = float(np.median([r["ovl_inst"] for r in raw if r["regime"] == reg]))
        ovl_dir = float(np.median([r["ovl_direct"] for r in raw if r["regime"] == reg]))
        lines += [f"## {tag} regime (analytic Δf(A1,A2) = {d_true:+.3f} kT)",
                  "| N_shot | STAR RMSE | GRAPH RMSE | STAR/GRAPH |",
                  "|---|---|---|---|"]
        for nb in budgets:
            rs = _rmse(raw, reg, nb, "dA1A2_star"); rg = _rmse(raw, reg, nb, "dA1A2_graph")
            lines.append(f"| {nb} | {rs:.3f} | {rg:.3f} | ×{rs/max(rg,1e-6):.1f} |")
        lines += [f"- instantaneous-edge OVL (mid↔A2 etc.) ≈ {ovl_inst:.2f} (AIS-independent, cheap); "
                  f"direct A1↔A2 (60° apart, no overlap) OVL ≈ {ovl_dir:.2f} — why tiling via `mid` is required.",
                  ""]
    (OUT / "graph_msk_toy_results.md").write_text("\n".join(lines))
    print("wrote", OUT / "graph_msk_toy_results.md")


if __name__ == "__main__":
    if "--figure-only" in sys.argv:
        d = json.load(open(OUT / "graph_msk_toy.json"))
        make_figure(d["raw"], d["budgets"]); write_results_md(d["raw"], d["budgets"])
    else:
        main(fast="--fast" in sys.argv)
