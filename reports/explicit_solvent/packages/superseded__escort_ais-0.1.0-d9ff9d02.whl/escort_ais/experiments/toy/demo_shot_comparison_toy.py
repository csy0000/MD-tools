#!/usr/bin/env python3
"""demo_shot_comparison_toy.py — s_hot = 0.1 hot-ensemble comparison for the three BAIS 1-D toy regimes.

For each of the three barrier regimes, this driver produces ONE figure comparing the analysis with the hot
ensemble at s_hot = 0.1 against the regime's CURRENT hot rung, with everything else (barriers, populations,
budget, ladder TYPE and rung count) held fixed — only the hot end of the AIS ladder moves to s = 0.1:

  regime  toy                       current s_hot   ladder (current -> s=0.1)
  base    Toy1D(u_scale=1)          0.2             linspace(0.2,1,6)  ->  linspace(0.1,1,6)
  mid3x   Toy1D(kappa=[70,70,30])   0.2             linspace(0.2,1,6)  ->  linspace(0.1,1,6)
  hard    Toy1D(u_scale=5)          0.01            logspace(-2,0,10)  ->  logspace(-1,0,10)

Each figure (results/toy/fig_shot_compare_<regime>_toy.png) has three panels:
  (1) Hot-ensemble density: θ-histograms of t.sample_boltzmann(s,20000) at the current s_hot AND s=0.1, over the
      analytic cold density, with the three analytic basin bands shaded — does the hotter s=0.1 ensemble cover the
      minor basin B better or worse?
  (2) AIS work overlap: forward W_f (hot->cold) and reverse -W_r (cold->hot) reduced-work histograms for BOTH s_hot
      values (Kish ESS/K annotated) — the longer/shorter AIS switch changes the forward/reverse overlap.
  (3) Convergence: population-TV vs total budget (median over 3 seeds) at s=0.1 vs the current s_hot, from
      bais_protocol_run(..., pergen=True) — does the hotter ensemble still converge to the analytic reference?

s_hot is controlled ENTIRELY through the AIS ladder handed to bais_protocol_run (its core logic is untouched):
bais_protocol_run derives s_hot = ais_ladder[0]. Pure NumPy/matplotlib (Agg). numpy 2.x safe (no np.trapz).

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_shot_comparison_toy [--regime base|mid3x|hard]
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.experiments.toy.demo_bais_protocol_convergence_toy import bais_protocol_run

OUT = project_root() / "results/toy"

# regime configuration: current hot rung + the matching s=0.1 ladder (same TYPE and rung count, only the hot end moves)
REGIMES = {
    "base":  dict(u_scale=1.0, kappa=None,
                  cur=np.linspace(0.2, 1.0, 6),  new=np.linspace(0.1, 1.0, 6),
                  cur_s=0.2, label="1$\\times$ base toy", ladder_kind="linear"),
    "mid3x": dict(u_scale=1.0, kappa=[70.0, 70.0, 30.0],
                  cur=np.linspace(0.2, 1.0, 6),  new=np.linspace(0.1, 1.0, 6),
                  cur_s=0.2, label="3$\\times$ $\\kappa$-retune toy", ladder_kind="linear"),
    "hard":  dict(u_scale=5.0, kappa=None,
                  cur=np.logspace(-2.0, 0.0, 10), new=np.logspace(-1.0, 0.0, 10),
                  cur_s=0.01, label="5$\\times$ high-barrier toy", ladder_kind="log"),
}

C_CUR = "#2c6fbb"     # current s_hot (blue)
C_NEW = "#e08214"     # s = 0.1 (orange)
BCOL = ["#7a4fb0", "#1f6f1f", "#8fce8f"]   # basin bands B, A1, A2
BNAMES = ["B", "A1", "A2"]

B_CONV = 800_000      # per-seed total budget for the convergence panel
CONV_SEEDS = (0, 1, 2)


def _toy(cfg):
    return Toy1D(u_scale=cfg["u_scale"]) if cfg["kappa"] is None else Toy1D(kappa=np.asarray(cfg["kappa"], float))


def _cold_density_deg(t, thd):
    """Analytic cold density on a DEGREE grid (normalised so ∫ dθ_deg = 1, no np.trapz)."""
    p = np.exp(-t.U_cold(np.radians(thd)) / t.kT)
    return p / (p.sum() * (thd[1] - thd[0]))


def _shade_basins(ax, t, alpha=0.13):
    """Shade the three analytic basin bands (B, A1, A2) as light vertical bands, in degrees."""
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"])
    thd = np.linspace(-180.0, 180.0, 1441)
    lab = t.basin_of(np.radians(thd), bnd).astype(int)
    ymax = ax.get_ylim()[1]
    for b in range(3):
        ax.fill_between(thd, 0, ymax, where=(lab == b), color=BCOL[b], alpha=alpha, lw=0, step="mid")


def _forward_ais(t, x0, ladder, rng, freq=1):
    """Forward AIS hot->cold along `ladder`; returns (landing, logw). logw = Σ −(Δs)U_cold/kT (mirrors ais_switch)."""
    theta = wrap(np.array(x0, float)); logw = np.zeros(theta.size)
    for j in range(len(ladder) - 1):
        s_old, s_new = ladder[j], ladder[j + 1]
        logw += -((s_new - s_old) * t.U_cold(theta)) / t.kT
        theta = t.langevin(theta, freq, s_new, rng)[-1] if freq > 0 else theta
    return wrap(theta), logw


def _reverse_ais(t, x0, ladder, rng, freq=1):
    """Reverse AIS cold->hot along `ladder` reversed; returns logw."""
    theta = wrap(np.array(x0, float)); lad = ladder[::-1]; logw = np.zeros(theta.size)
    for j in range(len(lad) - 1):
        s_old, s_new = lad[j], lad[j + 1]
        logw += -((s_new - s_old) * t.U_cold(theta)) / t.kT
        theta = t.langevin(theta, freq, s_new, rng)[-1] if freq > 0 else theta
    return logw


def _ess_over_k(logw):
    """Kish effective sample size fraction ESS/K from unnormalised log-weights."""
    logw = np.asarray(logw, float)
    if logw.size == 0 or not np.isfinite(logw).any():
        return float("nan")
    w = np.exp(logw - np.nanmax(logw)); s = float(np.nansum(w))
    denom = float(np.nansum(w * w))
    return float(s * s / denom / logw.size) if denom > 0 else float("nan")


def _tv(pi, analytic):
    p = np.nan_to_num(np.asarray(pi, float), nan=0.0)
    return 0.5 * float(np.sum(np.abs(p - np.asarray(analytic, float))))


def _interp(grid, xs, vals):
    """Interpolate one seed's TV(budget) onto the common grid; NaN below its first recorded budget."""
    xs = np.asarray(xs, float); vals = np.asarray(vals, float)
    m = np.isfinite(vals) & np.isfinite(xs)
    if m.sum() < 2:
        return np.full(len(grid), np.nan)
    xs, vals = xs[m], vals[m]; o = np.argsort(xs); xs, vals = xs[o], vals[o]
    out = np.interp(grid, xs, vals, left=np.nan, right=vals[-1])
    out[grid < xs[0]] = np.nan
    return out


# ── the three panels ─────────────────────────────────────────────────────────
def _panel_density(ax, t, cfg, seed=0):
    rng = np.random.default_rng(seed)
    thd = np.linspace(-180.0, 180.0, 800)
    hot_cur = np.degrees(t.sample_boltzmann(cfg["cur_s"], 20000, rng))
    hot_new = np.degrees(t.sample_boltzmann(0.1, 20000, rng))
    p_cold = _cold_density_deg(t, thd)
    ax.hist(hot_cur, bins=70, range=(-180, 180), density=True, color=C_CUR, alpha=0.45,
            label=f"hot MD ($s\\!=\\!{cfg['cur_s']:g}$)")
    ax.hist(hot_new, bins=70, range=(-180, 180), density=True, histtype="step", color=C_NEW, lw=1.8,
            label="hot MD ($s\\!=\\!0.1$)")
    ax.plot(thd, p_cold, color="k", lw=1.3, ls="--", label="analytic cold")
    ax.set_xlim(-180, 180); ax.set_ylim(bottom=0)
    _shade_basins(ax, t)
    ax.set_title("(1) hot-ensemble density: $s\\!=\\!0.1$ vs current $s_{\\mathrm{hot}}$")
    ax.set_xlabel("$\\theta$ (deg)"); ax.set_ylabel("density"); ax.legend(fontsize=7.5, loc="upper left")
    ax.grid(alpha=0.3)
    # annotate minor-basin B coverage (fraction of hot samples in the B band)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"])
    fB_cur = float(np.mean(t.basin_of(np.radians(hot_cur), bnd) == 0))
    fB_new = float(np.mean(t.basin_of(np.radians(hot_new), bnd) == 0))
    ax.text(0.98, 0.02, f"$B$ coverage: {fB_cur:.2f} ($s\\!=\\!{cfg['cur_s']:g}$) $\\to$ {fB_new:.2f} ($s\\!=\\!0.1$)",
            transform=ax.transAxes, fontsize=7.5, ha="right", va="bottom",
            bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.85))


def _panel_overlap(ax, t, cfg, seed=1, n_shot=4000):
    rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"])
    out = {}
    for tag, lad, col in (("cur", cfg["cur"], C_CUR), ("new", cfg["new"], C_NEW)):
        xh = t.sample_boltzmann(lad[0], n_shot, rng)
        _, logwf = _forward_ais(t, xh, lad, rng); Wf = -logwf
        xc = np.concatenate([t.langevin(np.full(n_shot // 3, wells[b]), 1, 1.0, rng)[-1] for b in range(3)])
        logwr = _reverse_ais(t, xc, lad, rng); Wr = -logwr
        out[tag] = dict(Wf=Wf, Wr=Wr, essf=_ess_over_k(logwf), essr=_ess_over_k(logwr))
    allv = np.concatenate([out["cur"]["Wf"], -out["cur"]["Wr"], out["new"]["Wf"], -out["new"]["Wr"]])
    lo, hi = np.percentile(allv, 0.5), np.percentile(allv, 99.5)
    bins = np.linspace(lo, hi, 70)
    s_cur = cfg["cur_s"]
    ax.hist(out["cur"]["Wf"], bins=bins, density=True, color=C_CUR, alpha=0.40,
            label=f"$W_f$ $s\\!=\\!{s_cur:g}$ (ESS/K={out['cur']['essf']:.2f})")
    ax.hist(-out["cur"]["Wr"], bins=bins, density=True, histtype="step", color=C_CUR, lw=1.6, ls="--",
            label=f"$-W_r$ $s\\!=\\!{s_cur:g}$ (ESS/K={out['cur']['essr']:.2f})")
    ax.hist(out["new"]["Wf"], bins=bins, density=True, color=C_NEW, alpha=0.40,
            label=f"$W_f$ $s\\!=\\!0.1$ (ESS/K={out['new']['essf']:.2f})")
    ax.hist(-out["new"]["Wr"], bins=bins, density=True, histtype="step", color=C_NEW, lw=1.6, ls="--",
            label=f"$-W_r$ $s\\!=\\!0.1$ (ESS/K={out['new']['essr']:.2f})")
    ax.set_title("(2) AIS work overlap: $W_f$ (hot$\\to$cold) & $-W_r$ (cold$\\to$hot)")
    ax.set_xlabel("reduced work ($k_BT$)"); ax.set_ylabel("density")
    ax.legend(fontsize=7, loc="upper right"); ax.grid(alpha=0.3)


def _panel_convergence(ax, t, cfg, budget=B_CONV, seeds=CONV_SEEDS):
    analytic = np.asarray(t.populations()["pops"], float)
    grid = np.geomspace(80_000, budget, 30)
    curves = {}
    for tag, lad, col in (("cur", cfg["cur"], C_CUR), ("new", cfg["new"], C_NEW)):
        tvs = []
        for s in seeds:
            r = bais_protocol_run(s, budget, hot_steps=10000, cold_chunk=10000, n_fwd=100, pergen=True,
                                  u_scale=cfg["u_scale"], kappa=cfg["kappa"], ais_ladder=lad)
            bud = r["pergen_budget"]; pis = r["pergen_pi"]
            tv_seed = [_tv(p, analytic) for p in pis]
            tvs.append(_interp(grid, bud, tv_seed))
        curves[tag] = np.nanmedian(np.asarray(tvs), axis=0)
    ax.plot(grid, curves["cur"], "-o", color=C_CUR, ms=3.5, label=f"$s_{{\\mathrm{{hot}}}}\\!=\\!{cfg['cur_s']:g}$ (current)")
    ax.plot(grid, curves["new"], "-s", color=C_NEW, ms=3.5, label="$s_{\\mathrm{hot}}\\!=\\!0.1$")
    ax.axhline(0.0, ls="--", color="0.5", lw=1.0)
    ax.set_xscale("log"); ax.set_ylim(bottom=0)
    ax.set_title(f"(3) population-TV vs budget (median of {len(seeds)} seeds)")
    ax.set_xlabel("total budget (force-evals)"); ax.set_ylabel("population TV to analytic $\\pi$")
    ax.legend(fontsize=8, loc="upper right"); ax.grid(alpha=0.3, which="both")
    return curves


def run(regime):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    if regime not in REGIMES:
        raise ValueError(f"unknown regime {regime!r}; choose from {list(REGIMES)}")
    cfg = REGIMES[regime]
    t = _toy(cfg)
    OUT.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 3, figsize=(17.5, 4.4))

    for panel_fn, a in ((_panel_density, ax[0]), (_panel_overlap, ax[1]), (_panel_convergence, ax[2])):
        try:
            panel_fn(a, t, cfg)
        except Exception as e:                                          # one failed panel must not kill the figure
            a.text(0.5, 0.5, f"panel failed:\n{type(e).__name__}: {e}", transform=a.transAxes,
                   ha="center", va="center", fontsize=8, color="#b03030", wrap=True)
            print(f"  [{regime}] panel {panel_fn.__name__} FAILED: {type(e).__name__}: {e}", file=sys.stderr)

    lad_kind = cfg["ladder_kind"]
    fig.suptitle(f"Hot-ensemble temperature comparison on the {cfg['label']}: $s_{{\\mathrm{{hot}}}}\\!=\\!0.1$ vs the "
                 f"current $s_{{\\mathrm{{hot}}}}\\!=\\!{cfg['cur_s']:g}$ ({lad_kind} ladder, {len(cfg['cur'])} rungs, "
                 "identical barriers/populations/budget).", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    out = OUT / f"fig_shot_compare_{regime}_toy.png"
    fig.savefig(out, dpi=150); plt.close(fig)
    print(f"  wrote {out}", file=sys.stderr)
    return out


if __name__ == "__main__":
    if "--regime" in sys.argv:
        run(sys.argv[sys.argv.index("--regime") + 1])
    else:
        for reg in ("base", "mid3x", "hard"):
            run(reg)
        print("all three s_hot=0.1 comparison figures written", file=sys.stderr)
