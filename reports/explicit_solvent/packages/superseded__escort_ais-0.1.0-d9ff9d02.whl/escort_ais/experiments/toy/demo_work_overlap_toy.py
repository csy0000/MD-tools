#!/usr/bin/env python
"""demo_work_overlap_toy.py — forward/reverse AIS work-distribution overlap shared by BAUS and BAIS.

BAUS and BAIS are built on the SAME bidirectional annealing: a forward AIS leg (hot s=0.2 → cold s=1) and a reverse
leg (cold → hot), whose work distributions are combined by an ∞-padded conditional BAR to give the per-basin free
energies ΔF_b and populations π_b. BAUS turns those π_b into the cold PMF; BAIS feeds the identical π_b to the
reversible cold MSM. So the forward/reverse work overlap is a single diagnostic common to both — it sets how
well-conditioned the annealing (hence π_b) is, independent of any cold kinetics.

Convention (endpoint_bar): W_f = −lnw_f (hot→cold), W_r = −lnw_r (cold→hot). Under the Crooks pairing W_f and −W_r
share an axis and cross at ΔG_b; the histogram overlap OVL∈[0,1] (higher = better) and the forward/reverse ESS
quantify conditioning.

Run:  python -m escort_ais.experiments.toy.demo_work_overlap_toy
Out:  results/toy/fig_work_overlap_toy.png, results/toy/work_overlap_toy.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.endpoint_bar import _overlap_score, solve_bar_with_infinite_works
from escort_ais.methods.bais import basin_free_energies
from escort_ais.methods.baus import _ess

OUT = Path("results/toy")
KAPPA = np.array([26.0, 26.0, 9.0])          # samplable regime (A↔B ~7.1 kT, A1↔A2 ~2.9 kT) — matches the report


def anneal_works(seed=0, n_shots=4000, nes_win=12, nes_md=12, hot_steps=100_000, hot_walkers=10):
    t = Toy1D(kappa=KAPPA)
    rng = np.random.default_rng(seed)
    ana = t.populations()
    bnd = np.radians(ana["boundaries_deg"]); wells = ana["well_centers_deg"]; nb = ana["n_basins"]

    # forward leg: draw hot (s=0.2) Boltzmann starts, anneal hot→cold, record landing basin
    hot0 = t.sample_boltzmann(t.s_hot, n_shots, rng)
    land, lwf = t.ais_switch(hot0, t.s_hot, 1.0, m_steps=nes_win, freq=nes_md, rng=rng)
    Wf = -lwf
    land_basin = t.basin_of(land, bnd).astype(int)

    # reverse leg: draw cold (s=1) Boltzmann starts (LEQ within each basin), anneal cold→hot, record START basin
    cold0 = t.sample_boltzmann(1.0, n_shots, rng)
    start_basin = t.basin_of(cold0, bnd).astype(int)
    _, lwr = t.ais_switch(cold0, 1.0, t.s_hot, m_steps=nes_win, freq=nes_md, rng=rng)
    Wr = -lwr

    res = basin_free_energies(Wf, land_basin, Wr, start_basin, nb, ref_basin=0)
    return t, ana, nb, wells, Wf, land_basin, Wr, start_basin, res


def _panel(ax, wf, wr, title, dF=None):
    """Crooks overlap panel: forward hit works W_f (filled) vs negated reverse works −W_r (step)."""
    wf = np.asarray(wf, float); wf = wf[np.isfinite(wf)]
    wr = np.asarray(wr, float); wr = wr[np.isfinite(wr)]
    if wf.size < 2 or wr.size < 2:
        ax.text(0.5, 0.5, "too few\nsamples", ha="center", va="center", transform=ax.transAxes); ax.set_title(title)
        return
    a, b = wf, -wr
    both = np.concatenate([a, b])
    lo, hi = np.percentile(both, 0.5), np.percentile(both, 99.5)
    pad = 0.08 * (hi - lo + 1e-9); bins = np.linspace(lo - pad, hi + pad, 45)
    ax.hist(a, bins=bins, density=True, color="#c0392b", alpha=0.55, label=r"forward $W_f$ (hot$\to$cold)")
    ax.hist(b, bins=bins, density=True, histtype="step", color="#2c6fbb", lw=2, label=r"reverse $-W_r$ (cold$\to$hot)")
    ovl = _overlap_score(wf, wr)
    if dF is not None and np.isfinite(dF):
        ax.axvline(dF, color="k", ls="--", lw=1.2)
        ax.annotate(r"$\Delta F$", (dF, ax.get_ylim()[1] * 0.92), fontsize=8, ha="left")
    ax.set_title(f"{title}\nOVL={ovl:.2f}, ESS$_f$={_ess(-wf):.0f}, ESS$_r$={_ess(-wr):.0f}", fontsize=9)
    ax.set_xlabel("work (kT)"); ax.set_yticks([])


def main():
    t, ana, nb, wells, Wf, land_basin, Wr, start_basin, res = anneal_works()
    dF = np.asarray(res["dF"], float)                                   # per-basin ΔF_b = F_cold(b) − F_hot (ref-shifted)
    pi = np.asarray(res["pi"], float)
    def _name(deg):                                                    # well_centers are sorted by angle, not label
        if abs(deg - 60) < 30:
            return f"A1 ({deg:+.0f}°)"
        if abs(deg - 120) < 30:
            return f"A2 ({deg:+.0f}°)"
        return f"B ({deg:+.0f}°)"
    names = [_name(w) for w in wells][:nb]

    fig, axes = plt.subplots(1, nb + 1, figsize=(4.0 * (nb + 1), 4.1))
    # (A) global overlap — all forward hits vs all reverse
    dG_global, ok = solve_bar_with_infinite_works(Wf, Wr, n_f_total=len(Wf), n_r_total=len(Wr))
    _panel(axes[0], Wf, Wr, "GLOBAL (all shots)", dF=dG_global if ok else None)
    axes[0].legend(fontsize=7.5, loc="upper right")
    # (B..) per-basin CONDITIONAL overlap — the ∞-padded BAR that yields π_b (shared by BAUS & BAIS). The Crooks
    # crossing is the ABSOLUTE per-basin ΔG_b = F_cold(b) − F_hot (∞-padded: forward non-landings carry W=+inf).
    for b in range(nb):
        wfb = Wf[land_basin == b]                                       # forward works landing in basin b
        wrb = Wr[start_basin == b]                                      # reverse works starting in basin b
        dGb, okb = solve_bar_with_infinite_works(wfb, wrb, n_f_total=len(Wf), n_r_total=len(wrb))
        tag = f"basin {names[b]}\n$\\pi_b$={pi[b]:.2f}, $\\Delta G_b$={dGb:.2f} kT" if okb else f"basin {names[b]}"
        _panel(axes[b + 1], wfb, wrb, tag, dF=None)                     # ∞-padded ΔG_b ≠ visual density crossing

    fig.suptitle("Forward/backward AIS work-distribution overlap — shared by BAUS and BAIS\n"
                 "(same bidirectional annealing → per-basin BAR → $\\pi_b$; BAUS builds the PMF, BAIS feeds the MSM)",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.9])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_work_overlap_toy.png", dpi=190); plt.close(fig)
    print(f"  wrote {OUT / 'fig_work_overlap_toy.png'}", file=sys.stderr)

    out = dict(regime="samplable (A↔B ~7.1 kT, A1↔A2 ~2.9 kT)", n_shots=int(len(Wf)),
               global_dG=round(float(dG_global), 3), global_overlap=round(float(_overlap_score(Wf, Wr)), 3),
               per_basin=[dict(name=names[b], pi=round(float(pi[b]), 3), dF=round(float(dF[b]), 3),
                               overlap=round(float(_overlap_score(Wf[land_basin == b], Wr[start_basin == b])), 3),
                               ess_fwd=round(float(_ess(-Wf[land_basin == b])), 1),
                               ess_rev=round(float(_ess(-Wr[start_basin == b])), 1),
                               n_fwd=int((land_basin == b).sum()), n_rev=int((start_basin == b).sum()))
                          for b in range(nb)])
    (OUT / "work_overlap_toy.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
