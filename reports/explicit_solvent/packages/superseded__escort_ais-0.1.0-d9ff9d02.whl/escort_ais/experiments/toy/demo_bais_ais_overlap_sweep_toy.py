#!/usr/bin/env python3
"""demo_bais_ais_overlap_sweep_toy.py — AIS switch-length sweep: overlap/ESS vs annealing length on the 1D toy.

The precision of the endpoint-restricted BAR is set by the forward<->reverse work overlap. A short (dissipative)
AIS switch gives poor overlap and a low effective sample size (ESS); a longer switch (more lambda-increments)
anneals more reversibly, raising overlap/ESS and shrinking the population error --- but costs more force-evaluations
per shot. This driver quantifies that trade-off and finds the switch length that minimises the population error
*at a fixed total force-evaluation budget* (the efficient frontier).

To isolate the SWITCH quality from cold-MD sampling artefacts, both endpoints are drawn from the EXACT Boltzmann
distribution (`Toy1D.sample_boltzmann`): forward shots start hot (s=0.2), reverse shots start cold (s=1) in each
basin, count-matched to the forward landings (the production rule). Metrics per switch length L:
  * per-shot forward/reverse ESS fraction and Crooks work overlap (OVL);
  * mean total dissipation <W_f>+<W_r> (the forward/reverse work gap; ->0 as L->inf);
  * endpoint-BAR population TV to the analytic pi, both at fixed shot count and at fixed force-eval budget.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_ais_overlap_sweep_toy [--fast]
"""
from __future__ import annotations

import json
import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.bais import basin_free_energies
from escort_ais.methods.endpoint_bar import _overlap_score

ROOT = project_root()
OUT = ROOT / "results/toy"
LS = [5, 10, 20, 40, 80, 160]                        # AIS switch lengths (lambda-increments, freq=1 -> MD steps/shot)
BUDGET_FWD = 60_000                                  # forward force-evals per direction (fixed across L)
N_SEED = 8
COLF, COLR = "#2c6fbb", "#b03030"


def _ess_frac(logw):
    lw = np.asarray(logw, float)
    if lw.size == 0:
        return np.nan
    m = lw.max(); w = np.exp(lw - m)
    return float(w.sum() ** 2 / np.sum(w ** 2) / lw.size)


def one_run(t, bnd, pops, L, n_shots, seed):
    """One forward+reverse AIS batch at switch length L; return overlap/ESS/dissipation/TV metrics + raw works."""
    rng = np.random.default_rng(seed)
    s_hot = t.s_hot
    # forward hot->cold from exact hot Boltzmann
    xh = t.sample_boltzmann(s_hot, n_shots, rng)
    land, lwf = t.ais_switch(xh, s_hot, 1.0, m_steps=L, freq=1, rng=rng)
    Wf = -np.asarray(lwf, float); land_b = t.basin_of(wrap(land), bnd).astype(int)
    n_land = np.bincount(land_b, minlength=3)
    # reverse cold->hot from exact cold Boltzmann, count-matched per basin to the forward landings
    pool = t.sample_boltzmann(1.0, max(6 * n_shots, 6000), rng); pool_b = t.basin_of(pool, bnd).astype(int)
    Wr_list, rb_list = [], []
    for b in range(3):
        need = int(n_land[b]); cand = pool[pool_b == b]
        if need == 0 or cand.size == 0:
            continue
        starts = cand[rng.integers(0, cand.size, need)]
        _, lwr = t.ais_switch(starts, 1.0, s_hot, m_steps=L, freq=1, rng=rng)
        Wr_list.append(-np.asarray(lwr, float)); rb_list.append(np.full(need, b, int))
    Wr = np.concatenate(Wr_list) if Wr_list else np.zeros(0)
    rev_b = np.concatenate(rb_list) if rb_list else np.zeros(0, int)

    fe = basin_free_energies(Wf, land_b, Wr, rev_b, 3)
    pi = np.nan_to_num(np.asarray(fe["pi"], float), nan=0.0)           # missing basin -> 0 population (counts in TV)
    tv = 0.5 * float(np.sum(np.abs(pi - pops)))
    ovl = float(_overlap_score(Wf, Wr)) if Wf.size and Wr.size else np.nan
    return dict(L=L, n_shots=int(n_shots), tv=tv, pi=pi.tolist(),
                ess_f=_ess_frac(-Wf), ess_r=_ess_frac(-Wr), ovl=ovl,
                dissip=float(np.mean(Wf) + np.mean(Wr)) if Wf.size and Wr.size else np.nan,
                Wf=Wf, Wr=Wr)


def run(fast=False):
    t = Toy1D(kappa=np.array([26.0, 26.0, 9.0]))                      # samplable regime (A<->B ~7.1 kT), s_hot=0.2
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); pops = np.array(ana["pops"])   # [B, A1, A2]
    seeds = range(3 if fast else N_SEED)
    budget = BUDGET_FWD // 4 if fast else BUDGET_FWD

    # fixed-budget sweep: n_shots(L) = budget / L, so total force-evals ~= 2*budget is CONSTANT across L
    rows, hists = {}, {}
    for L in LS:
        n_shots = max(budget // L, 30)
        runs = [one_run(t, bnd, pops, L, n_shots, 1000 + 7 * s) for s in seeds]
        rows[L] = dict(
            n_shots=n_shots,
            tv=[r["tv"] for r in runs], ess_f=[r["ess_f"] for r in runs], ess_r=[r["ess_r"] for r in runs],
            ovl=[r["ovl"] for r in runs], dissip=[r["dissip"] for r in runs],
            pi=np.median(np.array([r["pi"] for r in runs]), axis=0).tolist(),
        )
        hists[L] = (runs[0]["Wf"], runs[0]["Wr"])                     # one seed's works for the overlap panel
        med = lambda k: float(np.nanmedian(rows[L][k]))               # noqa: E731
        print(f"  L={L:3d}  n_shots={n_shots:5d}  OVL={med('ovl'):.2f}  ESS_f={med('ess_f'):.2f}  "
              f"ESS_r={med('ess_r'):.2f}  <diss>={med('dissip'):.2f}kT  TV={med('tv'):.3f}", file=sys.stderr)

    # a fixed-SHOTS reference sweep (same n_shots for every L) -> shows raw per-shot quality unconfounded by budget
    n_fixed = 1500 if not fast else 400
    fixed = {}
    for L in LS:
        runs = [one_run(t, bnd, pops, L, n_fixed, 5000 + 7 * s) for s in seeds]
        fixed[L] = dict(tv=[r["tv"] for r in runs], ess_f=[r["ess_f"] for r in runs])

    payload = dict(regime="samplable (A<->B ~7.1 kT)", s_hot=float(t.s_hot), Ls=LS,
                   budget_fwd=budget, n_seeds=len(list(seeds)), analytic_pops=pops.tolist(),
                   fixed_budget={str(L): {k: rows[L][k] for k in ("n_shots", "tv", "ess_f", "ess_r", "ovl", "dissip", "pi")}
                                 for L in LS},
                   fixed_shots={"n_shots": n_fixed, **{str(L): fixed[L] for L in LS}})
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "bais_ais_overlap_sweep_toy.json").write_text(json.dumps(payload, indent=2, default=float))
    make_figure(rows, hists, fixed, n_fixed, pops)
    return payload


def _band(ax, xs, series, color, label, marker="o"):
    """median line + IQR band across seeds for a per-L metric dict {L: [values over seeds]}."""
    med = np.array([np.nanmedian(series[L]) for L in xs], float)
    lo = np.array([np.nanpercentile(series[L], 25) for L in xs], float)
    hi = np.array([np.nanpercentile(series[L], 75) for L in xs], float)
    ax.plot(xs, med, marker + "-", color=color, lw=2, ms=6, label=label)
    ax.fill_between(xs, lo, hi, color=color, alpha=0.18, lw=0)
    return med


def make_figure(rows, hists, fixed, n_fixed, pops):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 12, "axes.titlesize": 12.5, "axes.labelsize": 12, "legend.fontsize": 9.5})
    Ls = np.array(LS, float)
    Lbig = LS[-2]                                                      # a long switch for the overlap comparison
    fig, ax = plt.subplots(2, 2, figsize=(14, 10.5))

    # (A) per-shot quality: OVL + forward/reverse ESS fraction rise with L; dissipation (twin axis) falls ∝1/L
    a = ax[0, 0]
    _band(a, LS, {L: rows[L]["ess_f"] for L in LS}, COLF, "forward ESS fraction", "o")
    _band(a, LS, {L: rows[L]["ess_r"] for L in LS}, COLR, "reverse ESS fraction", "s")
    _band(a, LS, {L: rows[L]["ovl"] for L in LS}, "#2f8f2f", "Crooks overlap OVL", "^")
    a.set_xscale("log"); a.set_xlabel("AIS switch length $L$ (λ-increments)"); a.set_ylabel("per-shot quality")
    a.set_ylim(0, 1.02); a.set_xticks(LS); a.set_xticklabels(LS); a.grid(alpha=0.3, which="both")
    a.legend(loc="center left")
    at = a.twinx()
    medd = np.array([np.nanmedian(rows[L]["dissip"]) for L in LS], float)
    at.plot(LS, medd, "d--", color="#8a1a1a", lw=1.5, ms=5, label="dissipation")
    at.plot(Ls, medd[0] * Ls[0] / Ls, ":", color="0.6", lw=1.2)
    at.set_yscale("log"); at.set_ylabel(r"$\langle W_f\rangle+\langle W_r\rangle$ (kT), $\propto 1/L$ guide",
                                        color="#8a1a1a")
    at.tick_params(axis="y", colors="#8a1a1a")
    a.set_title("(A) per-shot overlap/ESS rise, dissipation falls with $L$")

    # (B) forward vs reverse work histograms: a short (L=5) vs long (Lbig) switch — the overlap improves per shot
    b = ax[0, 1]
    for L, is5 in ((5, True), (int(Lbig), False)):
        Wf, Wr = hists[L]
        both = np.concatenate([Wf, -Wr]); lo, hi = np.percentile(both, [0.5, 99.5]); binsw = np.linspace(lo, hi, 46)
        b.hist(Wf, binsw, density=True, histtype="stepfilled", color=COLF, alpha=0.5 if is5 else 0.22,
               label=f"fwd $W_f$, L={L}")
        b.hist(-Wr, binsw, density=True, histtype="step", color=COLR, lw=2.0 if is5 else 1.4,
               ls="-" if is5 else "--", label=f"rev $-W_r$, L={L}")
    b.set_xlabel("reduced work (kT)"); b.set_yticks([]); b.grid(alpha=0.3)
    b.set_title(f"(B) forward/reverse work overlap: L=5 vs L={int(Lbig)} (per shot)"); b.legend(loc="upper right")

    # (C) THE reframe: at FIXED force-eval budget the TOTAL effective samples ESS_frac·N_shots FALL with L —
    #     lengthening the switch buys per-shot quality but loses more shots (N_shots ∝ 1/L). More cheap shots win.
    c = ax[1, 0]
    esf = {L: [e * rows[L]["n_shots"] for e in rows[L]["ess_f"]] for L in LS}
    esr = {L: [e * rows[L]["n_shots"] for e in rows[L]["ess_r"]] for L in LS}
    _band(c, LS, esf, COLF, "forward $\\mathrm{ESS}_{\\mathrm{tot}}$", "o")
    _band(c, LS, esr, COLR, "reverse $\\mathrm{ESS}_{\\mathrm{tot}}$", "s")
    c.set_xscale("log"); c.set_yscale("log"); c.set_xlabel("AIS switch length $L$ (λ-increments)")
    c.set_ylabel("total effective samples at fixed budget"); c.set_xticks(LS); c.set_xticklabels(LS)
    c.grid(alpha=0.3, which="both"); c.legend(loc="upper right")
    c.set_title("(C) fixed budget: total effective samples FALL with $L$")

    # (D) consequence for the estimate: population TV vs L — fixed shots (quality wins) vs fixed budget (shots win)
    d = ax[1, 1]
    _band(d, LS, {L: fixed[L]["tv"] for L in LS}, "#2f8f2f", f"fixed shots ({n_fixed}/dir; cost ∝ L)", "s")
    medtv = _band(d, LS, {L: rows[L]["tv"] for L in LS}, "#7a4fb0", "fixed budget (const force-evals)", "o")
    d.axvline(5, ls="--", color="0.4", lw=1.2)
    d.text(5, d.get_ylim()[0], " production L=5", fontsize=9, va="bottom", color="0.35")
    d.set_xscale("log"); d.set_xlabel("AIS switch length $L$ (λ-increments)")
    d.set_ylabel("population TV to analytic $\\pi$"); d.set_xticks(LS); d.set_xticklabels(LS)
    d.grid(alpha=0.3, which="both"); d.legend(loc="upper left")
    d.set_title("(D) population error: fixed shots ↓ but fixed budget ↑ with $L$")

    fig.suptitle("AIS switch-length sweep (1D toy): a longer switch helps overlap/ESS PER SHOT, "
                 "but at FIXED BUDGET more cheap shots win", fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.965])
    fig.savefig(OUT / "fig_bais_ais_overlap_sweep_toy.png", dpi=200); plt.close(fig)
    plt.rcParams.update(plt.rcParamsDefault)
    print(f"  wrote {OUT / 'fig_bais_ais_overlap_sweep_toy.png'}", file=sys.stderr)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
