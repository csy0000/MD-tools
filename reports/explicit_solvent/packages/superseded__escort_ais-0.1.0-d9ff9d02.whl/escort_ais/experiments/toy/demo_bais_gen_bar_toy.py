#!/usr/bin/env python3
"""demo_bais_gen_bar_toy.py — one INDEPENDENT figure at every `show_every`-th BAIS generation (default: 0, 5, 10,
15, 20): walker trajectories + endpoint-BAR per leaf, tracking convergence across generations.

Walker protocol (per generation, uniform T_walker = 10k so T_hot = T_cold):
  * ONE hot walker (10k steps at s=0.01), streamed; 100 forward AIS shots (√s-square ladder 0.01→1) are fired from random
    frames of THIS generation's hot trajectory -> landings, forward works.
  * the cold reservoir keeps exactly ONE cold walker per KINETIC basin (the committed KCC+LEQ set of production
    BAIS, via BasinManager): a walker is seeded into any GMM-detected geometric well not already covered by a
    resident walker's committed basin, and if two walkers end up in the same kinetic (KCC) basin the
    shorter-residence one is terminated. Each cold walker runs 10k steps (= the hot walker's).
  * the reverse AIS is COUNT-MATCHED to the forward landings, basin by basin, and is fired from THIS generation's
    cold frames: if the forward shots land B/A1/A2 as 20/20/60, the 100 reverse shots are fired 20/20/60 from those
    basins' cold frames (total reverse = total forward). Forward AND reverse per basin therefore have equal counts.

Note: A1<->A2 is a fast barrier, so the two A sub-wells behave as ONE kinetic basin — the termination rule merges
their walkers, and n_cold settles at 2 ({A, B}, the kinetic-state count) even though GMM's geometric K*=3. The
endpoint-BAR still resolves all three geometric populations (A1, A2, B) from the two walkers' reservoirs.

For each generation the figure shows (suptitle gives invested hot / cold / AIS force-evals):
  * top (spanning) — the walker trajectories this generation: the hot walker (RED) and each cold walker (its basin
    colour), with markers where forward AIS (from the hot walker) and reverse AIS (from the cold walkers) were
    initiated;
  * middle — the hot->leaf work overlap for each geometric leaf (A1, A2, B): forward hot->cold W_f of shots LANDING
    in the leaf vs reverse cold->hot −W_r of the count-matched shots STARTED in it (equal counts per basin);
  * bottom — the endpoint-BAR ΔΔF (BAIS vs analytic), the TICA t2/LEQ split test (split iff the LEQ-equilibrated
    residence fraction < 1/α_split), and the resolved state tree with the endpoint-BAR π.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_bais_gen_bar_toy [--fast]
"""
from __future__ import annotations

import sys
import warnings

warnings.filterwarnings("ignore")
import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.systems.toy1d import Toy1D, wrap
from escort_ais.methods.bais import basin_free_energies
from escort_ais.methods.endpoint_bar import _overlap_score, solve_bar_with_infinite_works
from escort_ais.methods.state_detect import detect_kstar
from escort_ais.experiments.toy.demo_bais_tica_tree_toy import COL, _lags, analyze, _leaf_name

# Unified hot ensemble + AIS ladder (mirrors demo_bais_protocol_convergence_toy.AIS_LADDER; defined locally to avoid
# a circular import, since that module imports _home_res from here). s_hot = AIS_LADDER[0] = 0.01, √s-square 0.01→1.
AIS_LADDER = np.linspace(np.sqrt(0.01), 1.0, 10) ** 2

ROOT = project_root()
OUT = ROOT / "results/toy"
NAME2IDX = {"B": 0, "A1": 1, "A2": 2}                                # basin_of order
IDX2NAME = {0: "B", 1: "A1", 2: "A2"}
PAIRS = [("A1", "A2"), ("A1", "B"), ("A2", "B")]


def _feats1(angles):
    a = wrap(np.asarray(angles, float))
    return np.column_stack([np.cos(a), np.sin(a)])


def _break_wrap(theta_deg):
    """Return a copy with NaN at ±180° wrap points, so a periodic θ trace does not draw vertical connectors."""
    th = np.asarray(theta_deg, float).copy()
    if th.size > 1:
        jump = np.abs(np.diff(th)) > 180.0
        th[1:][jump] = np.nan
    return th


def _home_res(basin_seq):
    """Home basin (most-visited) and its LARGEST CONSECUTIVE residence (frames) for one cold segment."""
    basin_seq = np.asarray(basin_seq, int)
    if basin_seq.size == 0:
        return 0, 0
    home = int(np.bincount(basin_seq, minlength=3).argmax())
    isin = (basin_seq == home).astype(int)
    best = cur = 0
    for v in isin:                                    # longest run of consecutive frames in the home basin
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return home, int(best)


def _ess(logw):
    lw = np.asarray(logw, float)
    if lw.size == 0:
        return 0.0
    m = lw.max(); w = np.exp(lw - m)
    return float(w.sum() ** 2 / np.sum(w ** 2))


def run(fast=False, gens=21, seed=1, show_every=5):
    t = Toy1D(); rng = np.random.default_rng(seed)
    ana = t.populations(); bnd = np.radians(ana["boundaries_deg"]); wells = np.radians(ana["well_centers_deg"])
    pops = np.array(ana["pops"])                                     # [B, A1, A2]
    kin = t.smoluchowski_kinetics(); t_AB, t_A1A2 = float(kin["t_AB"]), float(kin["t_A1A2"])
    truepop = {"B": pops[0], "A1": pops[1], "A2": pops[2], "A": pops[1] + pops[2]}
    pi_an = {"B": pops[0], "A1": pops[1], "A2": pops[2]}
    s_hot = float(AIS_LADDER[0]); m_eff = len(AIS_LADDER) - 1   # unified hot ensemble s=0.01 + √s-square ladder (0.01→1)

    T_walker = 10000                    # uniform per-generation length: ONE hot walker AND each cold walker run this
    n_fwd, m_ais = 100, 5               # 100 forward AIS shots/gen along the √s ladder (m_eff rungs); reverse count-matched
    analysis_win, n_detect = 6000, 200  # KCC/TICA tail window; GMM landing window

    hot_pos = t.sample_boltzmann(s_hot, 1, rng)                       # one hot walker
    all_land, all_lw = [], []
    Wf_acc, lf_acc = [], []             # accumulated forward works + landing basin (for BAR)
    Wr_acc, rl_acc = [], []             # accumulated reverse works + start basin (for BAR)
    walkers = []                        # ONE cold walker per KINETIC basin: {pos, acc:[frames], home, res, basin, this_gen}
    budget = dict(hot=0, ais=0, cold=0)

    for g in range(gens):
        # (1) hot MD (1 walker, T_walker) + forward AIS (100 x 5) fired from THIS gen's hot trajectory
        hot_chunk = t.langevin(hot_pos, T_walker, s_hot, rng); hot_pos = wrap(hot_chunk[-1])
        hot_frames = wrap(hot_chunk[:, 0]); budget["hot"] += T_walker
        fwd_idx = rng.integers(0, len(hot_frames), n_fwd)            # which hot frames seed the forward shots
        xh = hot_frames[fwd_idx]
        land, lwf = t.ais_switch(xh, s_hot, 1.0, m_steps=m_ais, freq=1, rng=rng, schedule=AIS_LADDER); budget["ais"] += n_fwd * m_eff
        land = wrap(land); land_b = t.basin_of(land, bnd).astype(int)
        all_land.append(land); all_lw.append(np.asarray(lwf, float))
        Wf_acc.append(-np.asarray(lwf, float)); lf_acc.append(land_b)
        n_land = np.bincount(land_b, minlength=3)                     # [B, A1, A2] forward landings THIS gen

        # (2) GMM/BIC K* on the bounded landing window -> detected basins (the states)
        lp = np.concatenate(all_land); lwp = np.concatenate(all_lw)
        _, _, kstar, medoids = detect_kstar(lp[-n_detect:], lwp[-n_detect:], seed=seed)
        medoids = wrap(np.asarray(medoids, float)); med_b = t.basin_of(medoids, bnd).astype(int)
        det_basins = sorted(set(med_b.tolist()))                      # basins a GMM medoid falls in

        # (3) seed one walker per KINETIC basin not yet covered: B (geometric well 0) and the A-side (wells 1,2,
        #     one KCC cluster since A1<->A2 interconvert fast). A detected A sub-well is NOT re-seeded when an
        #     A-walker already holds the A cluster, so the reservoir carries exactly the {A,B} walker set.
        has_A = any(w["home"] in (1, 2) for w in walkers)
        has_B = any(w["home"] == 0 for w in walkers); n_seeded = 0
        for b in det_basins:
            if (has_B if b == 0 else has_A):                         # this kinetic basin already has a resident
                continue
            mb = medoids[med_b == b]
            pos0 = float(mb[0]) if mb.size else float(wells[b])
            walkers.append({"pos": pos0, "acc": [], "home": b, "res": 0, "basin": -1, "this_gen": np.zeros(0)})
            if b == 0:
                has_B = True
            else:
                has_A = True
            n_seeded += 1

        # (4) cold MD: propagate every walker T_walker steps (each cold walker matches the hot walker's length)
        if walkers:
            cpos = np.array([w["pos"] for w in walkers], float)
            cold = t.langevin(cpos, T_walker, 1.0, rng); budget["cold"] += T_walker * len(walkers)
            for k, w in enumerate(walkers):
                fr = wrap(cold[:, k]); w["acc"].append(fr); w["pos"] = float(fr[-1]); w["this_gen"] = fr
                w["home"], w["res"] = _home_res(t.basin_of(fr, bnd).astype(int))

        # (5) LEQ-GATE walker bookkeeping (the same gate production BAIS runs, decide_split via analyze): B is its
        #     own kinetic basin; the A-side wells {1,2} are ONE basin whose two walkers collapse to a single
        #     A-walker WHEN the LEQ gate finds the A reservoir locally equilibrated as one basin (A1<->A2 fast).
        #     If the gate instead says A is NOT yet LEQ-confident it keeps one walker per occupied A sub-well.
        #     So the figure's walker count is driven by the LEQ gate, and settles at n_cold=2 {A,B}.
        a_walkers = [w for w in walkers if w["home"] in (1, 2)]     # A-side (wells 1,2) vs B-side (well 0), by this
        b_walkers = [w for w in walkers if w["home"] == 0]          # generation's residence (self-corrects on drift)
        kept = [max(b_walkers, key=lambda w: w["res"])] if b_walkers else []
        if a_walkers:
            a_res = [np.concatenate(w["acc"])[-analysis_win:] for w in a_walkers if w["acc"]]
            a_split = False
            if a_res:
                af = np.vstack([_feats1(r) for r in a_res]); awl = [len(r) for r in a_res]
                a_split = bool(analyze(af, awl, np.ones(len(af), bool), _lags(analysis_win), seed)["dec"]["split"])
            if a_split and len(a_walkers) > 1:                        # gate: A NOT LEQ-confident -> keep A1,A2 walkers
                by_home = {}
                for w in a_walkers:
                    by_home.setdefault(w["home"], []).append(w)
                kept += [max(ws, key=lambda w: w["res"]) for ws in by_home.values()]
            else:                                                    # gate: A LEQ-confident -> single A-walker
                kept.append(max(a_walkers, key=lambda w: w["res"]))
        walkers = kept
        n_cold = len(walkers)

        # (6) diagnostic on the pooled walker tails. States are geometric basins (one walker each), so build the
        #     A (basins 1,2) and B (basin 0) nodes DIRECTLY: the A node's TICA t2 is the A1<->A2 timescale (LEQ
        #     test). Expose A1/A2/B as geometric leaves for the BAR panels.
        show = (g % show_every == 0)                                # render only every show_every-th generation
        basins, leaves, pooled, wlens, lags = [], [], np.zeros(0), [], _lags(analysis_win)
        wtraj = [np.concatenate(w["acc"])[-analysis_win:] for w in walkers] if show else []
        if wtraj:
            wlens = [len(w) for w in wtraj]; feats = np.vstack([_feats1(w) for w in wtraj]); pooled = np.concatenate(wtraj)
            pb = t.basin_of(pooled, bnd).astype(int)
            for label, sel in (("A", np.isin(pb, [1, 2])), ("B", pb == 0)):
                if sel.sum() < 40:
                    continue
                nd = analyze(feats, wlens, sel, lags, seed); nd["label"] = label
                for ch in (nd["children"] or []):
                    ch["name"] = _leaf_name(t, ch, pooled, bnd)
                basins.append(nd)
            basins.sort(key=lambda b: (b["label"] != "A", -b["n"]))
            for bi, nm in ((0, "B"), (1, "A1"), (2, "A2")):         # geometric leaves for the per-basin BAR panels
                m = pb == bi
                if m.sum() >= 40:                                    # ignore boundary leakage from a neighbouring walker
                    leaves.append({"mask": m, "name": nm})

        # (7) reverse AIS: count-matched to the forward landings, fired from THIS gen's cold frames per basin;
        #     record which cold frames seed each reverse shot (for the trajectory markers).
        colds = []                                                   # per surviving walker: trajectory + reverse marks
        for w in walkers:
            th = w["this_gen"]
            colds.append(dict(theta=th, basin=t.basin_of(th, bnd).astype(int) if th.size else np.zeros(0, int),
                              name=IDX2NAME[w["home"]], color=COL[IDX2NAME[w["home"]]], rev_idx=[]))
        for b in range(3):
            need = int(n_land[b])
            if need == 0:
                continue
            per_w = [(k, np.where(cw["basin"] == b)[0]) for k, cw in enumerate(colds)]
            per_w = [(k, idx) for k, idx in per_w if idx.size]
            if not per_w:
                continue
            allk = np.concatenate([np.full(idx.size, k) for k, idx in per_w])
            alli = np.concatenate([idx for _, idx in per_w])
            pick = rng.integers(0, alli.size, need)
            selk, seli = allk[pick], alli[pick]
            starts = np.array([colds[k]["theta"][i] for k, i in zip(selk, seli)])
            _, lwr = t.ais_switch(starts, 1.0, s_hot, m_steps=m_ais, freq=1, rng=rng, schedule=AIS_LADDER[::-1]); budget["ais"] += need * m_eff
            Wr_acc.append(-np.asarray(lwr, float)); rl_acc.append(np.full(need, b, int))
            for k, i in zip(selk, seli):
                colds[k]["rev_idx"].append(int(i))

        # (8) endpoint-restricted BAR on the accumulated pools
        Wf = np.concatenate(Wf_acc); land_leaf = np.concatenate(lf_acc)
        Wr = np.concatenate(Wr_acc) if Wr_acc else np.zeros(0); rev_leaf = np.concatenate(rl_acc) if rl_acc else np.zeros(0, int)
        fe = basin_free_energies(Wf, land_leaf, Wr, rev_leaf, 3)   # ref = most-landed basin (auto)
        dF = np.asarray(fe["dF"], float); pi = np.asarray(fe["pi"], float)

        if show:
            traj = dict(hot=hot_frames, fwd_idx=np.asarray(fwd_idx, int),
                        colds=[dict(theta=c["theta"], color=c["color"], name=c["name"],
                                    rev_idx=np.asarray(c["rev_idx"], int)) for c in colds])
            make_figure(t, g, budget, basins, leaves, pooled, bnd, Wf, land_leaf, Wr, rev_leaf, dF, pi,
                        t_AB, t_A1A2, truepop, pi_an, kstar, n_cold, bool(n_seeded), lags, wlens, seed, T_walker, traj,
                        n_fwd, m_ais)
        print(f"  gen {g}{' [shown]' if show else ''}: K*={kstar} n_cold={n_cold} seeded={n_seeded} "
              f"homes={sorted(w['home'] for w in walkers)} n_land(B,A1,A2)={n_land.tolist()} "
              f"hot={budget['hot']} cold={budget['cold']} pi={np.round(pi,2)}", file=sys.stderr)


def _ddf_calc(dF, i, j):                                             # dF indexed [B,A1,A2]; ddF_ij = F_i - F_j
    return float(dF[NAME2IDX[i]] - dF[NAME2IDX[j]])


def make_figure(t, g, budget, basins, leaves, pooled, bnd, Wf, land_leaf, Wr, rev_leaf, dF, pi,
                t_AB, t_A1A2, truepop, pi_an, kstar, n_cold, seeded_new, lags, wlens, seed, T_walker, traj,
                n_fwd, m_ais):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.gridspec import GridSpec
    # ~2x larger fonts than the previous revision (titles/labels/legends/ticks all bumped)
    plt.rcParams.update({"font.size": 15, "axes.titlesize": 18, "axes.labelsize": 17,
                         "legend.fontsize": 13, "xtick.labelsize": 14, "ytick.labelsize": 14})
    lags = np.asarray(lags, float)
    rev_leaf = np.asarray(rev_leaf, int)
    present = [nm for nm in ["A1", "A2", "B"]                          # a panel per basin with accumulated BAR data
               if (land_leaf == NAME2IDX[nm]).sum() >= 2 and (rev_leaf == NAME2IDX[nm]).sum() >= 2]
    fig = plt.figure(figsize=(22.0, 18.0))
    gs = GridSpec(3, 3, figure=fig, hspace=0.42, wspace=0.24, height_ratios=[1.05, 1.0, 1.0])

    # ── row 0 (spanning): walker trajectories this generation + AIS-initiation markers ───────────────
    axtr = fig.add_subplot(gs[0, :])
    hot = np.degrees(traj["hot"]); xh = np.arange(len(hot))
    axtr.plot(xh, _break_wrap(hot), color="#d62728", lw=0.5, alpha=0.55, zorder=2, label="hot walker (s=0.01)")
    fi = traj["fwd_idx"]
    axtr.scatter(fi, hot[fi], s=42, marker="v", color="#d62728", edgecolors="k", lw=0.5, zorder=5,
                 label=f"forward AIS init ({fi.size})")
    n_rev_total = 0
    for c in traj["colds"]:
        th = np.degrees(c["theta"]); xc = np.arange(len(th))
        axtr.plot(xc, _break_wrap(th), color=c["color"], lw=0.9, alpha=0.9, zorder=3, label=f"cold walker {c['name']}")
        ri = c["rev_idx"]; n_rev_total += ri.size
        if ri.size:
            axtr.scatter(ri, th[ri], s=46, marker="o", facecolors="none", edgecolors=c["color"], lw=1.4, zorder=6)
    # one proxy legend entry for the reverse markers (colour varies per walker)
    axtr.scatter([], [], s=46, marker="o", facecolors="none", edgecolors="0.25", lw=1.4,
                 label=f"reverse AIS init ({n_rev_total})")
    axtr.set_xlim(0, T_walker); axtr.set_ylim(-185, 185); axtr.set_yticks([-120, 60, 120])
    for yb in (-180, 0, 180):
        axtr.axhline(yb, color="0.85", lw=0.6, zorder=1)
    axtr.set_xlabel("MD step this generation"); axtr.set_ylabel("θ (deg)")
    axtr.set_title(f"walker trajectories this generation — hot (red, T={T_walker//1000}k) + "
                   f"{len([c for c in traj['colds']])} cold walker(s) (T={T_walker//1000}k each); "
                   "markers = AIS-shot initiation points")
    axtr.legend(ncol=3, loc="upper right", framealpha=0.9)

    # ── row 1: hot→leaf work overlap per geometric leaf (forward vs count-matched reverse) ──────────
    for k, nm in enumerate(["A1", "A2", "B"]):
        ax = fig.add_subplot(gs[1, k])
        if nm not in present:
            ax.axis("off"); ax.set_title(f"{nm}: not resolved this gen"); continue
        li = NAME2IDX[nm]
        wf = Wf[(land_leaf == li) & np.isfinite(Wf)]; wr = Wr[(rev_leaf == li) & np.isfinite(Wr)]
        if wf.size >= 2 and wr.size >= 2:
            both = np.concatenate([wf, -wr]); lo, hi = np.percentile(both, [1, 99]); pad = 0.1 * (hi - lo + 1e-9)
            binsw = np.linspace(lo - pad, hi + pad, 40)
            ax.hist(wf, binsw, density=True, color=COL[nm], alpha=0.6, label=r"fwd $W_f$ (hot$\to$cold)")
            ax.hist(-wr, binsw, density=True, histtype="step", color="k", lw=1.8, label=r"rev $-W_r$ (count-matched)")
            ovl = _overlap_score(wf, wr)
            dG, ok = solve_bar_with_infinite_works(wf, wr, n_f_total=len(Wf), n_r_total=len(wr))
            gtxt = f"{dG:+.2f}" if ok else "n/a"
            if ok:
                ax.axvline(dG, ls="--", c="0.3", lw=1.4)
            ax.set_title(f"{nm}: OVL={ovl:.2f}, $\\Delta G_{{|hot}}$={gtxt} kT, π={pi[li]:.2f}\n"
                         f"$N_{{fwd\\to {nm}}}$={wf.size} (ESS {_ess(-wf):.0f}) = "
                         f"$N_{{rev}}$={wr.size} (ESS {_ess(-wr):.0f})")
        ax.set_xlabel("work (kT)"); ax.set_yticks([]); ax.legend(loc="upper right")

    # ── row 2: ΔΔF (BAIS vs analytic) | TICA t2/LEQ split test | resolved state tree ────────────────
    axb = fig.add_subplot(gs[2, 0])
    labels, calc, anal = [], [], []
    for i, j in PAIRS:
        if i in present and j in present:
            labels.append(f"{i}–{j}")
            calc.append(_ddf_calc(dF, i, j))
            anal.append(float(-np.log(pi_an[i] / pi_an[j])))
    x = np.arange(len(labels))
    if labels:
        axb.bar(x - 0.2, calc, 0.4, color="#2c6fbb", label="BAIS (endpoint-BAR)")
        axb.bar(x + 0.2, anal, 0.4, color="0.6", label="analytic")
        lo = min(0, min(calc + anal)); hi = max(0, max(calc + anal)); pad = 0.12 * (hi - lo + 1e-6)
        for xi, (c, a) in enumerate(zip(calc, anal)):
            axb.text(xi, lo - 0.5 * pad, f"Δ={c-a:+.2f}", ha="center", va="top", fontsize=12, color="#8a1a1a")
        axb.set_ylim(lo - 1.6 * pad, hi + pad)
        axb.set_xticks(x); axb.set_xticklabels(labels); axb.axhline(0, c="0.7", lw=0.8)
        axb.legend(loc="upper left")
    axb.set_ylabel(r"$\Delta\Delta F$ (kT)")
    axb.set_title(r"$\Delta\Delta F=\Delta G_i-\Delta G_j$: BAIS vs analytic")

    axt2 = fig.add_subplot(gs[2, 1])
    for b in basins:
        col = COL.get(b["label"], "0.4")
        y = np.array([np.nan if v is None else v for v in b["t2s"]], float)
        frac = b["dec"].get("leq_frac", float("nan"))
        verdict = "split" if b["dec"]["split"] else ("LEQ" if b["dec"]["converged"] else "under")
        axt2.plot(lags, y, "-o", ms=5, color=col, label=f"{b['label']}: {verdict} (LEQ frac {frac:.2f})")
    axt2.set_xscale("log"); axt2.set_yscale("log"); axt2.set_ylim(20, 6000)
    axt2.set_title(r"TICA $t_2$(lag); split iff LEQ-frac $<1/\alpha_{split}$ (=0.5)")
    axt2.set_xlabel("MSM lag"); axt2.set_ylabel("$t_2$"); axt2.legend(loc="lower right")

    tree_pop = {}
    for nm, li in NAME2IDX.items():
        tree_pop[nm] = float(pi[li]) if np.isfinite(pi[li]) else truepop[nm]
    tree_pop["A"] = tree_pop["A1"] + tree_pop["A2"]
    _draw_tree(fig.add_subplot(gs[2, 2]), basins, t_AB, t_A1A2, tree_pop, "BAIS $\\pi$")

    b = budget; Tk = T_walker // 1000
    seedtxt = " (+new walker seeded)" if seeded_new else ""
    fig.suptitle(
        f"BAIS generation {g}: GMM $K^*$={kstar}, {n_cold} cold walkers (one per occupied basin){seedtxt}\n"
        f"per generation: $T_{{hot}}=T_{{cold}}=T_{{walker}}={Tk}$k · "
        f"$N^{{AIS}}_{{fwd}}=N^{{AIS}}_{{rev}}={n_fwd}$ shots ($\\sqrt{{s}}$ ladder, {len(AIS_LADDER)} rungs $0.01\\!\\to\\!1$), count-matched per basin\n"
        f"cumulative to gen {g}: hot {b['hot']/1e3:.0f}k (1 walker $\\times$ {Tk}k/gen) · "
        f"cold {b['cold']/1e3:.0f}k (each cold walker adds {Tk}k/gen) · AIS {b['ais']} force-evals",
        fontsize=15)
    fig.tight_layout(rect=[0, 0, 1, 0.945])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_bais_gen_bar_g{g}.png", dpi=200); plt.close(fig)
    plt.rcParams.update(plt.rcParamsDefault)
    print(f"  wrote {OUT / f'fig_bais_gen_bar_g{g}.png'}", file=sys.stderr)


def _draw_tree(axt, basins, t_AB, t_A1A2, pop, pop_label="π"):
    axt.axis("off"); axt.set_xlim(0, 1); axt.set_ylim(0, 1); axt.set_title(f"resolved state tree ({pop_label})")

    def box(x, y, name, pop):
        axt.scatter([x], [y], s=1500, color=COL.get(name, "0.6"), edgecolors="k", zorder=3)
        axt.text(x, y, name, ha="center", va="center", fontsize=14, fontweight="bold", color="w", zorder=4)
        axt.text(x, y - 0.085, f"π={pop:.2f}", ha="center", va="top", fontsize=12)

    def edge(x0, y0, x1, y1, p):
        axt.plot([x0, x1], [y0, y1], "-", c="0.45", lw=1.4)
        axt.text((x0 + x1) / 2 + 0.02, (y0 + y1) / 2, f"{p:.2f}", fontsize=11, color="0.3")

    def sib(x0, x1, y, tag, dy=0.09):
        axt.annotate("", xy=(x1, y), xytext=(x0, y), arrowprops=dict(arrowstyle="<->", ls="--", color="#b03030", lw=1.2))
        axt.text((x0 + x1) / 2, y + dy, tag, ha="center", va="bottom", fontsize=11, color="#b03030")

    box(0.5, 0.9, "root", 1.0)
    A = next((b for b in basins if b["label"] == "A"), None); B = next((b for b in basins if b["label"] == "B"), None)
    if A is not None:
        box(0.30, 0.56, "A", pop["A"]); edge(0.5, 0.83, 0.30, 0.63, pop["A"])
    if B is not None:
        box(0.74, 0.56, "B", pop["B"]); edge(0.5, 0.83, 0.74, 0.63, pop["B"])
    if A is not None and B is not None:
        sib(0.40, 0.64, 0.56, f"t$_{{AB}}$≈{t_AB:.0f}")
    if A is not None and A["children"]:
        box(0.16, 0.18, "A1", pop["A1"]); box(0.44, 0.18, "A2", pop["A2"])
        edge(0.30, 0.49, 0.16, 0.25, pop["A1"] / pop["A"]); edge(0.30, 0.49, 0.44, 0.25, pop["A2"] / pop["A"])
        sib(0.22, 0.38, 0.18, f"t2≈{A['dec']['t2']:.0f}", dy=0.12)


if __name__ == "__main__":
    run(fast="--fast" in sys.argv)
