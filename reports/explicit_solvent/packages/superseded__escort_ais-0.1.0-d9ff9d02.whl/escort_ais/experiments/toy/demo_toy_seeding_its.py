#!/usr/bin/env python3
"""demo_toy_seeding_its.py — seeding strategies, RMSE convergence, and implied-timescale analysis (items 7-11).

Cold-MD sampling protocols on the 1D toy (samplable regime, A↔B ~7.1 kT). Per the naming convention, single-medoid
results are NOT shown; we compare the MULTI-medoid protocol (b, unrestrained) and the medoid+UMBRELLA protocol (c):

Figures:
  fig_toy_trajectories.png  (item 7): θ(t) for (b) multi-medoid and (c) medoid+US.
  fig_toy_rmse.png          (item 8): population-TV error vs simulation time — (b) raw multi-medoid vs (c) BAUS.
  fig_toy_its.png           (items 9 & 11): slow implied timescale vs MSM lag and vs simulation time, for the
      multi-medoid protocol, WITHOUT annealing (free-π reversible MSM MLE) vs WITH BAIS (restricted TRAM via
      deeptime's C++ solver; cold counts + hot equilibrium anchor, iterated).

Naming: AUS/ATA = forward-only annealing; BAUS/BAIS = bidirectional (reverse AIS also performed) — used here.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_toy_seeding_its
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.bais import estimate_bais_tram_control as estimate_bais  # noqa: E402  (v1 compat)
from escort_ais.methods.fixed_pi_msm import fixed_pi_reversible_mle, implied_timescales, reversible_mle  # noqa: E402
from escort_ais.methods.state_detect import spring_constants  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])                                  # samplable regime (A↔B ~7.1 kT)


def count_matrix(dtrajs, n, lag):
    C = np.zeros((n, n))
    for d in dtrajs:
        if len(d) > lag:
            np.add.at(C, (d[:-lag], d[lag:]), 1)
    return C


TS_MAX = 2e5                                                        # above this the slow timescale is unresolved (→ nan)


def _resolved(ts):
    return ts if (np.isfinite(ts) and ts < TS_MAX) else np.nan       # nan-out unresolved (near-disconnected) MSMs


def slow_ts(C, lag, pi=None):
    """Slowest implied timescale from C via free-π (pi=None) or fixed-π reversible MLE."""
    if C.sum() < 10 or np.any(C.sum(1) == 0):
        return np.nan
    try:
        T = reversible_mle(C)[0] if pi is None else fixed_pi_reversible_mle(C, pi)
        return _resolved(float(np.sort(implied_timescales(T, lag))[::-1][0]))
    except Exception:
        return np.nan


def bais_basin_pi(t, hot, us_by_basin, bnd, nb, n_f, m_steps, freq, rng):
    """bAIS/BAR per-basin cold populations: forward AIS hot→cold + reverse AIS cold→hot from US-equilibrated
    per-basin samples; endpoint BAR → ΔF_b; π_b ∝ exp(−ΔF_b)."""
    xh = hot[rng.integers(0, len(hot), n_f)]
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=m_steps, freq=freq, rng=rng)
    lb = t.basin_of(land, bnd).astype(int); Wf = -lwf; dF = np.zeros(nb)
    for b in range(nb):
        us = us_by_basin[b]
        _, lwr = t.ais_switch(us[rng.integers(0, len(us), min(len(us), n_f))], 1.0, t.s_hot,
                              m_steps=m_steps, freq=freq, rng=rng)
        dF[b], _ = solve_bar_with_infinite_works(np.where(lb == b, Wf, np.inf), -lwr,
                                                 n_f_total=len(Wf), n_r_total=len(lwr))
    pi = np.exp(-(dF - dF.min())); pi /= pi.sum()
    return pi


def run(seed=0, steps_a=400_000, walkers_b=4, steps_b=150_000, us_steps=40_000, hot_steps=100_000, hot_walkers=10,
        n_f=2000, m_steps=10, freq=10):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    bnd = np.radians(ana["boundaries_deg"]); a1 = int(np.argmin(np.abs(ana["well_centers_deg"] - 60)))
    pt = ana["pops"]

    # --- flat-bottom US springs: distance-calibrated (spring_constants, e_target=8 kT) for consistency w/ Figs 3-5 ---
    hw_us = np.full(nb, np.radians(30.0))
    order = np.argsort(wells)
    kspring = np.empty(nb)
    kspring[order] = spring_constants(np.asarray(wells)[order], hw_us[order], e_target=8.0)
    print(f"  [toy_its] centers_deg={np.round(np.degrees(wells),0)} kspring={np.round(kspring,2)}", file=sys.stderr)

    # --- hot ensemble + US per basin → bAIS/BAR π (used by method c and the fixed-π MSM) ---
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, t.s_hot, rng)
    hot = wrap(hraw[(hot_steps // hot_walkers) // 20:].reshape(-1))
    us_by_basin = [t.us_sample(wells[b], hw_us[b], us_steps, rng, k=float(kspring[b]), burn=800, walkers=1)
                   for b in range(nb)]
    pi_bais = bais_basin_pi(t, hot, us_by_basin, bnd, nb, n_f, m_steps, freq, rng)

    # --- (b) multiple walkers from each medoid (unrestrained) — single-medoid protocol dropped per convention ---
    x0b = np.repeat(wells, walkers_b)
    trajs_b_raw = t.langevin(x0b, steps_b, 1.0, rng)
    trajs_b = [wrap(trajs_b_raw[:, k]) for k in range(x0b.size)]
    seed_basin_b = np.repeat(np.arange(nb), walkers_b)
    bb = [t.basin_of(x, bnd).astype(int) for x in trajs_b]
    # --- (c) same as (b) but US-restrained (already sampled as us_by_basin; traj view for the figure) ---
    trajs_c = [t.us_sample(wells[b], hw_us[b], steps_b // 4, rng, k=float(kspring[b]), burn=400, walkers=1)
               for b in range(nb)]

    # --- item 8: population-TV RMSE vs time ---
    times = np.unique(np.geomspace(2000, steps_b, 22).astype(int))
    tv_b, tv_c = [], []
    for T in times:
        cb = np.concatenate([d[:T] for d in bb])
        pb = np.array([np.mean(cb == b) for b in range(nb)])
        tv_b.append(0.5 * np.abs(pb - pt).sum())
        us_t = [u[:max(1, int(len(u) * T / steps_b))] for u in us_by_basin]
        pc = bais_basin_pi(t, hot, us_t, bnd, nb, n_f, m_steps, freq, rng)
        tv_c.append(0.5 * np.abs(pc - pt).sum())

    # --- reference slow ITS from a long well-sampled trajectory (basin MSM plateau) ---
    ref_raw = t.langevin(np.repeat(wells, 6), 400_000, 1.0, rng)
    ref_d = [t.basin_of(wrap(ref_raw[:, k]), bnd).astype(int) for k in range(ref_raw.shape[1])]
    lags = [50, 100, 200, 500, 1000, 2000, 4000]
    ref_its = [slow_ts(count_matrix(ref_d, nb, L), L) for L in lags]
    ref_plateau = float(np.nanmedian([ref_its[i] for i, L in enumerate(lags) if L >= 500]))

    # --- BAIS inputs: cold basin trajectories (multi-medoid) + per-frame hot bias; hot equilibrium anchor ---
    sh1 = t.s_hot - 1.0                                              # b^hot(x) = (s−1)·U_cold(x)
    cold_bhot = [sh1 * t.U_cold(x) for x in trajs_b]
    hot_bas = t.basin_of(hot, bnd).astype(int); hot_bhot = sh1 * t.U_cold(hot)

    def bata_ts(dtrajs, bhots, lag):
        try:
            out = estimate_bais(dtrajs, bhots, hot_bas, hot_bhot, nb, lagtime=lag, seed=seed)
            Tm = out["T"]                                             # estimate_bais_* returns dict(pi,T,its)
            if Tm is None:
                return np.nan
            return _resolved(float(np.sort(implied_timescales(np.asarray(Tm, float), lag))[::-1][0]))
        except Exception:
            return np.nan

    # --- items 9 & 11: slow ITS vs lag — multi-medoid, plain MSM (no annealing) vs BAIS (restricted TRAM) ---
    its = {"plain": [], "bata": []}
    for L in lags:
        its["plain"].append(slow_ts(count_matrix(bb, nb, L), L))
        its["bata"].append(bata_ts(bb, cold_bhot, L))

    # --- ITS vs SIMULATION TIME at a fixed lag ---
    fix_lag = 500
    tb_b = np.unique(np.geomspace(fix_lag * 4, steps_b, 14).astype(int))
    itt = {"plain": [], "bata": [], "frames": []}
    for tbb in tb_b:
        itt["plain"].append(slow_ts(count_matrix([d[:tbb] for d in bb], nb, fix_lag), fix_lag))
        itt["bata"].append(bata_ts([d[:tbb] for d in bb], [c[:tbb] for c in cold_bhot], fix_lag))
        itt["frames"].append(int(tbb * len(bb)))

    res = dict(seed=seed, s_hot=t.s_hot, regime="samplable (A↔B ~7.1 kT)",
               analytic_pops=[round(x, 3) for x in pt], pi_bais=[round(x, 3) for x in pi_bais],
               tv_final=dict(b_multimedoid=round(tv_b[-1], 3), c_baus=round(tv_c[-1], 3)),
               ref_slow_its_plateau_frames=round(ref_plateau, 0),
               its_at_lag500=dict(plain=_r(its["plain"][lags.index(500)]), bata=_r(its["bata"][lags.index(500)])))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "toy_seeding_its.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))

    _fig_traj(trajs_b, seed_basin_b, trajs_c, ana, res)
    _fig_rmse(times, tv_b, tv_c, res)
    _fig_its(lags, its, itt, fix_lag, ref_plateau, res)
    return res


def _r(x):
    return None if (x is None or not np.isfinite(x)) else round(float(x), 0)


def _traj_line(ax, theta, color, stride, lw=0.6, alpha=0.85):
    """Plot θ(deg) vs frame as a LINE, inserting NaN at ±180° wraps so no spurious horizontal jumps are drawn."""
    th = np.degrees(theta[::stride]); fr = (np.arange(len(th)) * stride).astype(float)
    brk = np.where(np.abs(np.diff(th)) > 180)[0] + 1                  # wrap / barrier-crossing jumps
    th = np.insert(th, brk, np.nan); fr = np.insert(fr, brk, np.nan)
    ax.plot(th, fr, "-", color=color, lw=lw, alpha=alpha)


def _fig_traj(trajs_b, seed_basin_b, trajs_c, ana, res):
    fig, ax = plt.subplots(1, 2, figsize=(12.5, 5.0))
    cmap = {0: "C3", 1: "C0", 2: "C1"}
    for x, sb in zip(trajs_b, seed_basin_b):
        _traj_line(ax[0], x, cmap[int(sb)], max(1, len(x) // 3000), lw=0.5, alpha=0.7)
    ax[0].set_title("(b) walkers from each medoid (unrestrained)\ncover all basins; slow to equilibrate", fontsize=10)
    for b, x in enumerate(trajs_c):
        _traj_line(ax[1], x, cmap[b], max(1, len(x) // 3000), lw=0.6, alpha=0.8)
    ax[1].set_title("(c) medoid walkers + flat-bottom US\nconfined to each basin (within-state P(θ|state))",
                    fontsize=10)
    for yb in ana["boundaries_deg"]:
        for a in ax:
            a.axvline(yb, ls=":", c="0.6", lw=1)
    for a in ax:
        a.set_xlabel("θ (deg)"); a.set_xlim(-180, 180)
    ax[0].set_ylabel("MD frame")
    fig.suptitle("cold-MD sampling protocols on the 1D toy (A1@60°, A2@120°, B@−120°)", fontsize=12)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / "fig_toy_trajectories.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_toy_trajectories.png'}", file=sys.stderr)


def _fig_rmse(times, tv_b, tv_c, res):
    fig, ax = plt.subplots(figsize=(8.5, 6.0))
    ax.loglog(times, tv_b, "-s", c="C2", label=f"(b) multi-medoid raw pops (final {res['tv_final']['b_multimedoid']})")
    ax.loglog(times, tv_c, "-^", c="C3", label=f"(c) medoid+US → BAUS pops (final {res['tv_final']['c_baus']})")
    ax.set_xlabel("simulation time per walker (MD steps)"); ax.set_ylabel("population total-variation error")
    ax.set_title("population RMSE convergence by sampling protocol\n(b) multi-medoid raw = slow ramp; "
                 "(c) BAUS = low & flat", fontsize=10)
    ax.legend(fontsize=9)
    panel_labels(fig); fig.tight_layout()
    fig.savefig(OUT / "fig_toy_rmse.png", dpi=200); plt.close(fig)
    print(f"  wrote {OUT / 'fig_toy_rmse.png'}", file=sys.stderr)


def _fig_its(lags, its, itt, fix_lag, ref, res):
    fig, ax = plt.subplots(1, 2, figsize=(15.0, 6.0))
    style = dict(plain=("C2", "-s", "multi-medoid, plain MSM (no annealing)"),
                 bata=("C0", "-o", "multi-medoid, BAIS (restricted TRAM, deeptime C++)"))
    # (A) ITS vs lag
    for key, (c, ls, lab) in style.items():
        ax[0].plot(lags, np.array(its[key], float), ls, c=c, label=lab)
    ax[0].axhline(ref, ls="-", c="k", lw=2, alpha=0.7, label=f"reference slow ITS = {ref:.0f}")
    ax[0].plot(lags, lags, ":", c="0.6", label="ITS = lag (resolution limit)")
    ax[0].set_xscale("log"); ax[0].set_yscale("log")
    ax[0].set_xlabel("MSM lag (frames)"); ax[0].set_ylabel("slowest implied timescale (frames)")
    ax[0].set_title("slow (A↔B) implied timescale vs MSM lag\nBAIS (joint π & p_ij) and plain MSM both match the "
                    "reference once A↔B is sampled", fontsize=10)
    ax[0].legend(fontsize=8, loc="best")
    # (B) ITS vs simulation time (fixed lag)
    for key, (c, ls, lab) in style.items():
        ax[1].plot(itt["frames"], np.array(itt[key], float), ls, c=c, ms=5, label=lab)
    ax[1].axhline(ref, ls="-", c="k", lw=2, alpha=0.7, label=f"reference slow ITS = {ref:.0f}")
    ax[1].set_xscale("log"); ax[1].set_yscale("log")
    ax[1].set_xlabel("simulation time (total cold-MD frames)")
    ax[1].set_ylabel("slowest implied timescale (frames)")
    ax[1].set_title(f"slow implied timescale vs simulation TIME (lag {fix_lag})\nunresolved until the cold MD "
                    "crosses A↔B; then both converge to the reference", fontsize=10)
    ax[1].legend(fontsize=8, loc="lower right")
    fig.suptitle("implied-timescale analysis — plain reversible MSM vs BAIS (restricted TRAM); BAIS additionally "
                 "returns the correct π", fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(OUT / "fig_toy_its.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / 'fig_toy_its.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
