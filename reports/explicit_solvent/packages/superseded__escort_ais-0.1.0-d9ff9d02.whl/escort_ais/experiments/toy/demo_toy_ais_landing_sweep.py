#!/usr/bin/env python3
"""demo_toy_ais_landing_sweep.py — AIS-landing reconstruction + automatic state-count detection (Figure 3).

(A) weighted-landing reconstructed cold P(θ) for the three method budgets N_AIS = 10/50/100 (bold), over the faint
    2^n sweep, converging to the analytic target.
(B) TV error and forward ESS fraction vs N_AIS.
(C) automatic GMM model selection: BIC over candidate cluster counts K = 2^n (n=1..10) at the largest budget; the
    minimum picks K*.
(D) detected K* vs AIS budget — how the auto-detected number of states settles toward the true 3; the K* at
    10/50/100 is what BAUS-N and BAIS-N use as their number of states/seeds.

GMM is fit on the circular embedding θ→(cosθ,sinθ) so the ±180° wrap is handled.

    conda activate escort-ais && python -m escort_ais.experiments.toy.demo_toy_ais_landing_sweep
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np
from sklearn.mixture import GaussianMixture

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, wrap  # noqa: E402

OUT = ROOT / "results/toy"
KAPPA = np.array([26.0, 26.0, 9.0])
NBIN = 40
BUDGETS_HI = [10, 50, 100]                       # the three method budgets (BAUS-N / BAIS-N)
K_CANDIDATES = list(range(1, 11))                # candidate #clusters K = 1..10 (so 3 is actually testable)
BUDGETS_GMM = [2 ** n for n in range(1, 11)]     # K*-vs-budget sweep at N = 2^n (2,4,...,1024)
NSEED = 8                                        # independent seeds for the K*-robustness sweep (panel D)
BIC_BUDGET = 100                                 # budget at which the BIC(K) model-selection curve is shown


def gen_landings(t, seed, hot_steps=100_000, hot_walkers=10):
    """Forward-AIS landings (nested, Nmax=1024) for one seed — the generation reused everywhere for consistency."""
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    rng = np.random.default_rng(seed)
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, t.s_hot, rng)
    hot = wrap(hraw[(hot_steps // hot_walkers) // 20:].reshape(-1))
    xh = hot[rng.integers(0, len(hot), 1024)]
    return t.ais_switch(xh, t.s_hot, 1.0, m_steps=10, freq=10, rng=rng)


REG_COVAR = 0.012                                # ~6° covariance floor on the unit circle (don't over-resolve wells)


def _embed(ang):
    """Map angles → the (cosθ, sinθ) unit-circle embedding (handles the ±180° wrap natively — standard for angles)."""
    return np.column_stack([np.cos(ang), np.sin(ang)])


def detect_kstar(angles, weights=None, seed=0):
    """Automatic GMM state count on the COLD-representative landings in (cos,sin) space: BIC over K = 2^n.

    The landings are importance-weighted (hot-generated), so we resample by weight to M=N points (keeping the honest
    BIC sample size, not inflating it) to recover the cold density, then fit GMMs on the (cosθ,sinθ) embedding. BIC
    selects K*. Returns (Ks, bics, k_star). BIC still slightly OVER-splits the von-Mises wells at high budget
    (K* > true #wells), which is exactly what the downstream kinetic merge (state_merge / kinetic tree) collapses.
    """
    ang = np.asarray(angles, float)
    rng = np.random.default_rng(seed)
    if weights is not None:
        w = np.asarray(weights, float); w = w / w.sum()
        ang = ang[rng.choice(len(ang), size=len(ang), p=w)]           # weighted resample to M=N (honest BIC penalty)
    X = _embed(ang)
    Ks, bics = [], []
    for K in K_CANDIDATES:
        if K >= len(np.unique(ang)):
            break
        gm = GaussianMixture(K, covariance_type="full", random_state=seed, n_init=3, reg_covar=REG_COVAR).fit(X)
        Ks.append(K); bics.append(float(gm.bic(X)))
    if not Ks:
        return [], [], 1
    return Ks, bics, int(Ks[int(np.argmin(bics))])


def run(seed=0, n_max=10, hot_steps=100_000, hot_walkers=10, m_steps=10, freq=10):
    t = Toy1D(kappa=KAPPA); rng = np.random.default_rng(seed)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); nb = ana["n_basins"]
    edges = np.linspace(-np.pi, np.pi, NBIN + 1); cg = 0.5 * (edges[:-1] + edges[1:]); dx = cg[1] - cg[0]
    p_cold = t.p_eq(cg); p_cold /= p_cold.sum() * dx
    grid = np.linspace(-np.pi, np.pi, 720)
    p_cold_fine = t.p_eq(grid); p_cold_fine /= p_cold_fine.sum() * (grid[1] - grid[0])

    # --- one large hot pool; nested forward-AIS shots so every budget uses the first-N of the same draw ---
    hraw = t.langevin(wells[np.arange(hot_walkers) % nb], hot_steps // hot_walkers, t.s_hot, rng)
    hot = wrap(hraw[(hot_steps // hot_walkers) // 20:].reshape(-1))
    Nmax = 2 ** n_max
    xh = hot[rng.integers(0, len(hot), Nmax)]
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=m_steps, freq=freq, rng=rng)

    def profile(N):
        lw = lwf[:N]; w = np.exp(lw - lw.max()); w /= w.sum()
        h, _ = np.histogram(land[:N], bins=edges, weights=w, density=True)
        ess = float(np.exp(lw).sum() ** 2 / np.exp(2 * lw).sum())
        tv = 0.5 * float(np.abs(h - p_cold).sum()) * dx
        return h, ess, tv

    Ns_pow = [2 ** n for n in range(1, n_max + 1)]
    profiles_pow = {N: profile(N)[0] for N in Ns_pow}
    profiles_hi = {N: profile(N)[0] for N in BUDGETS_HI}
    rows = []
    for N in sorted(set(Ns_pow) | set(BUDGETS_HI)):
        _, ess, tv = profile(N)
        rows.append(dict(N_ais=N, tv=round(tv, 3), ess=round(ess, 1), ess_frac=round(ess / N, 3)))

    # --- automatic state count K* vs AIS budget: robustness over NSEED independent seeds, N = 2^n ---
    def wts(N):
        lw = lwf[:N]; w = np.exp(lw - lw.max()); return w
    kstar_ms = {N: [] for N in BUDGETS_GMM}
    for s in range(NSEED):
        land_s, lwf_s = gen_landings(t, s)
        for N in BUDGETS_GMM:
            w_s = np.exp(lwf_s[:N] - lwf_s[:N].max())
            kstar_ms[N].append(detect_kstar(land_s[:N], w_s, seed=s)[2])
    kstar_curve = [dict(N_ais=N, k_stars=kstar_ms[N], k_star_median=float(np.median(kstar_ms[N])))
                   for N in BUDGETS_GMM]
    Ks_big, bics_big, kstar_big = detect_kstar(land[:BIC_BUDGET], wts(BIC_BUDGET), seed=seed)  # BIC(K) at N=100
    kstar_hi = {N: detect_kstar(land[:N], wts(N), seed=seed)[2] for N in BUDGETS_HI}

    res = dict(seed=seed, s_hot=t.s_hot, regime="samplable (A↔B ~7.1 kT)", n_bins=NBIN, n_basins_true=nb,
               sweep=rows, kstar_vs_budget=kstar_curve, kstar_at_budget=kstar_hi,
               bic_curve=dict(K=Ks_big, bic=[round(b, 1) for b in bics_big], k_star=kstar_big))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "ais_landing_sweep.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({"kstar_at_10_50_100": kstar_hi, "kstar_big": kstar_big,
                      "first": rows[0], "last": rows[-1]}, indent=2))
    make_figure(cg, p_cold_fine, grid, Ns_pow, profiles_pow, profiles_hi, rows,
                Ks_big, bics_big, kstar_big, kstar_curve, res)
    return res


def make_figure(cg, p_cold_fine, grid, Ns_pow, profiles_pow, profiles_hi, rows,
                Ks_big, bics_big, kstar_big, kstar_curve, res):
    deg = np.degrees(cg)
    fig, ax = plt.subplots(2, 2, figsize=(14.5, 9.2))
    # (A) weighted-landing profiles: faint 2^n sweep + BOLD 10/50/100
    ax[0, 0].plot(np.degrees(grid), p_cold_fine, "k-", lw=2.6, label="analytic cold P(θ)", zorder=10)
    for N in Ns_pow:
        ax[0, 0].plot(deg, profiles_pow[N], "-", c="0.8", lw=0.9, alpha=0.7, zorder=1)
    hicol = {10: "#1f77b4", 50: "#ff7f0e", 100: "#2ca02c"}
    for N in BUDGETS_HI:
        ax[0, 0].plot(deg, profiles_hi[N], "-", c=hicol[N], lw=2.2, label=f"weighted landings, N_AIS={N}", zorder=6)
    ax[0, 0].set_xlabel("θ (deg)"); ax[0, 0].set_ylabel("reconstructed P(θ) (weighted landings)")
    ax[0, 0].set_xlim(-180, 180)
    ax[0, 0].set_title("(A) weighted-AIS-landing profiles — bold: the three method budgets 10/50/100\n"
                       "(faint grey: full 2ⁿ sweep; all converge to the analytic target)", fontsize=9.5)
    ax[0, 0].legend(fontsize=8, loc="upper left")
    # (B) TV and ESS-fraction vs N_AIS
    N = [r["N_ais"] for r in rows]
    ax[0, 1].loglog(N, [r["tv"] for r in rows], "-o", c="C0", ms=4, label="TV to analytic cold")
    for Nh in BUDGETS_HI:
        ax[0, 1].axvline(Nh, c="0.6", ls=":", lw=1)
    ax[0, 1].set_xlabel("N_AIS (forward shots)"); ax[0, 1].set_ylabel("total-variation error", color="C0")
    ax[0, 1].tick_params(axis="y", labelcolor="C0")
    axr = ax[0, 1].twinx()
    axr.semilogx(N, [r["ess_frac"] for r in rows], "-s", c="C1", ms=4, label="ESS / N_AIS")
    axr.set_ylabel("forward ESS fraction", color="C1"); axr.set_ylim(0, 1.02)
    axr.tick_params(axis="y", labelcolor="C1")
    ax[0, 1].set_title("(B) reconstruction convergence (TV ↓ ~1/√N; dotted = 10/50/100)", fontsize=9.5)
    h1, l1 = ax[0, 1].get_legend_handles_labels(); h2, l2 = axr.get_legend_handles_labels()
    ax[0, 1].legend(h1 + h2, l1 + l2, fontsize=8, loc="center right")
    # (C) BIC(K) model selection at a method budget — candidate K = 1..10 (3 is testable)
    ax[1, 0].plot(Ks_big, bics_big, "-o", c="C3", ms=5)
    ax[1, 0].axvline(kstar_big, c="k", ls="--", lw=1.4)
    ax[1, 0].annotate(f"K*={kstar_big}", (kstar_big, min(bics_big)), fontsize=10,
                      xytext=(6, 8), textcoords="offset points")
    if 3 in Ks_big:                                                    # explicitly mark the true-count BIC
        b3 = bics_big[Ks_big.index(3)]
        ax[1, 0].scatter([3], [b3], s=90, facecolors="none", edgecolors="k", lw=1.6, zorder=5)
        ax[1, 0].annotate(f"K=3: {b3:.0f}", (3, b3), fontsize=9, xytext=(6, -14), textcoords="offset points")
    ax[1, 0].set_xticks(range(1, 11)); ax[1, 0].set_xlabel("candidate #clusters K")
    ax[1, 0].set_ylabel("GMM BIC (lower = better)")
    ax[1, 0].set_title(f"(C) automatic model selection at N_AIS={BIC_BUDGET}\nBIC over K∈{{1,…,10}} picks K*",
                       fontsize=9.5)
    # (D) detected K* vs AIS budget — robustness over NSEED seeds, N = 2^n
    allk = []
    for r in kstar_curve:
        N = r["N_ais"]; ks = r["k_stars"]; allk += ks
        xs = [N * (1 + 0.05 * (i - (len(ks) - 1) / 2) / max(len(ks), 1)) for i in range(len(ks))]  # deterministic jitter
        ax[1, 1].scatter(xs, ks, s=16, c="C4", alpha=0.4, zorder=2)
    ax[1, 1].plot([r["N_ais"] for r in kstar_curve], [r["k_star_median"] for r in kstar_curve], "-o", c="C4", ms=5,
                  zorder=3, label=f"median K* ({NSEED} seeds)")
    ax[1, 1].axhline(res["n_basins_true"], c="k", ls=":", lw=1.4, label=f"true #states = {res['n_basins_true']}")
    for Nh in BUDGETS_HI:
        ax[1, 1].axvline(Nh, c="0.75", ls=":", lw=1)
    ax[1, 1].set_xscale("log"); ax[1, 1].set_xlabel("N_AIS = 2ⁿ (forward shots)")
    ax[1, 1].set_ylabel("auto-detected #states K*"); ax[1, 1].set_ylim(0, max(allk) + 1.3)
    ax[1, 1].set_title(f"(D) robustness of K* over {NSEED} seeds (N=2ⁿ)\ndots = per-seed K*; dotted vlines = 10/50/100",
                       fontsize=9.5)
    ax[1, 1].legend(fontsize=8, loc="upper left")
    fig.suptitle(f"AIS landings → automatic state-count detection — 1D toy, {res['regime']}, s_hot={res['s_hot']}",
                 fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(OUT / "fig_toy_ais_landing_sweep.png", dpi=190); plt.close(fig)
    print(f"  wrote {OUT / 'fig_toy_ais_landing_sweep.png'}", file=sys.stderr)


if __name__ == "__main__":
    run()
