#!/usr/bin/env python
"""Per-microstate MATCHED reverse AIS + 24-state endpoint BAR for cyclo-RGDfV.

Unlike the 2-state (major/minor) reverse allocation, here the reverse leg is allocated PER MICROSTATE to
match the forward-landing count of that microstate: microstate S with n_fwd(S) forward landings gets
n_fwd(S) reverse trajectories, drawn from the cold-reservoir frames that fall in S. Never-landed microstates
(n_fwd=0) get zero reverse -> no reverse-only/undefined states. Then endpoint BAR gives a dF per microstate
(reference = the microstate with the most forward landings). Forward-landing-limited microstates stay noisy;
this just removes the reverse-only ambiguity and tightens the well-sampled states.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.run_rgd_permicrostate_reverse_bar \
        --device 0 --out-dir data/rgd/diagnostics/bar_permicro
"""
from __future__ import annotations
import argparse, glob, json, shutil, sys
from pathlib import Path
import numpy as np, pandas as pd, mdtraj as md
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.endpoint_bar import endpoint_restricted_bar
from escort_ais.methods.run_macrocycle_seedsource_swap import run_leg

RES = "data/rgd/2026-06-29-reservoir-sw-s0p25"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out-dir", default="data/rgd/diagnostics/bar_permicro")
    ap.add_argument("--device", default="0")
    ap.add_argument("--n-microstates", type=int, default=24)
    ap.add_argument("--switch-ps", type=float, default=20.0)   # match the 20 ps forward
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    cfg = load_cfg("rgd"); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    fz = BasinModel.load("data/rgd/basins_tica/basin_model_backbone.pkl")
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    K = args.n_microstates

    # ---- 24-microstate model on the cold reservoir (identical build to the diagnostics) ----
    seeds = sorted(glob.glob(f"{RES}/cold_md_10ns/seed_*/trajectory.dcd"))
    xyz, mic_res, X_list = [], [], []
    for s in seeds:
        t = md.load_dcd(s, top=top)[50:]
        X_list.append(featurize(t, q)); xyz.append(t.xyz)
    Xall = np.concatenate(X_list)
    pca = PCA(8, random_state=0).fit(Xall); sc = StandardScaler().fit(pca.transform(Xall))
    km = KMeans(K, n_init=10, random_state=0).fit(sc.transform(pca.transform(Xall)))
    res_micro = km.predict(sc.transform(pca.transform(Xall)))
    xyz = np.concatenate(xyz); top0 = md.load_dcd(seeds[0], top=top).topology

    # ---- forward AIS: works + landing microstate + per-microstate counts ----
    fdf = pd.read_csv(f"{RES}/step_forward_ais/ais_trajectory_summary.csv")
    W_f = -fdf["final_logw"].to_numpy()
    micro_f = km.predict(sc.transform(pca.transform(
        featurize(md.load_dcd(f"{RES}/step_forward_ais/ais_final_coordinates.dcd", top=top), q))))
    nf = np.bincount(micro_f, minlength=K)
    ref = int(np.argmax(nf))
    print(f"reference microstate = {ref} ({nf[ref]} landings)", flush=True)

    # ---- reverse allocation PER MICROSTATE == forward landing count ----
    rp, mr0 = [], []
    for S in range(K):
        avail = np.where(res_micro == S)[0]
        if nf[S] > 0 and avail.size > 0:
            sel = rng.choice(avail, int(nf[S]), replace=True)     # match forward count
            rp.append(xyz[sel]); mr0 += [S] * int(nf[S])
        elif nf[S] > 0:
            print(f"  microstate {S}: {nf[S]} landings but 0 reservoir frames -> cannot draw reverse", flush=True)
    mr0 = np.asarray(mr0)
    print(f"reverse total {len(mr0)} trajectories across {len(set(mr0.tolist()))} microstates "
          f"(matched to forward)", flush=True)

    rs = out / "seed_cold"; rs.mkdir(parents=True, exist_ok=True)
    md.Trajectory(np.concatenate(rp), top0).save_dcd(str(rs / "trajectory.dcd"))
    shutil.copy2(cfg.top_pdb, rs / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(cfg.prmtop), inpcrd_path=str(cfg.inpcrd), gb_model="GBn2",
                   gb_radii="mbondi3", n_solute_atoms=cfg.n_solute_atoms, timestep_fs=2.0,
                   friction_per_ps=1.0, temperature_k=300.0, solvent="implicit"),
              open(rs / "config.json", "w"), indent=2)

    # ---- run reverse AIS (cold -> hot) at the matched switch ----
    print(f"running per-microstate reverse AIS ({len(mr0)} traj, {args.switch_ps} ps) on device {args.device} ...",
          flush=True)
    logw, sel = run_leg(rs, out / "rev", len(mr0), 1.0, 0.25, args.switch_ps, 4, 10, "OpenCL",
                        args.seed, cfg, devices=args.device)
    W_r = -logw; micro_r = mr0[sel]

    # ---- 24-state endpoint BAR ----
    r = endpoint_restricted_bar(W_f, micro_f, W_r, micro_r, list(range(K)), reference_basin=ref,
                                bootstrap=True, n_bootstrap=1000, rng=rng)
    dd = r["ddF"]; nr = np.bincount(micro_r, minlength=K); npop = np.bincount(res_micro, minlength=K)
    rows = []
    print(f"\n{'state':>5} {'n_fwd':>6} {'n_rev':>6} {'res%':>6} {'dF(BAR)':>9}", flush=True)
    for k in np.argsort(-npop):
        val = dd.get(k, np.nan)
        rows.append(dict(state=int(k), n_fwd=int(nf[k]), n_rev=int(nr[k]),
                         res_pct=float(100 * npop[k] / npop.sum()),
                         dF=(float(val) if np.isfinite(val) else None)))
        print(f"{k:5d} {nf[k]:6d} {nr[k]:6d} {100*npop[k]/npop.sum():6.1f} "
              f"{val:9.2f}" if np.isfinite(val) else f"{k:5d} {nf[k]:6d} {nr[k]:6d} "
              f"{100*npop[k]/npop.sum():6.1f}      ----", flush=True)
    json.dump(dict(reference=ref, switch_ps=args.switch_ps, per_microstate=rows,
                   n_defined=int(sum(1 for x in rows if x["dF"] is not None))),
              open(out / "result.json", "w"), indent=2)
    print(f"\nsaved {out/'result.json'}  ({sum(1 for x in rows if x['dF'] is not None)}/{K} defined)", flush=True)


if __name__ == "__main__":
    main()
