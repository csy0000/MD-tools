#!/usr/bin/env python3
"""analyze_rgd_kinetic_leaves_projection.py — where do the KINETIC split states land in PCA / dihedral space?

Reconstructs the T=100 ns hierarchical (psi2 timescale-gated) leaves — the states the cold-MD *kinetics* produced
— maps every REMD frame to its leaf (via the KMeans microstate), and projects, coloured by leaf, onto:
  PC1-PC2, PC1-PC3, (dih#14, dih#2), (dih#2, dih#4).
Shows whether the kinetic split resolved only the BETWEEN-state axis (PC1 ~ dih#14) or also the WITHIN-S0
sub-states (dih#2/#4).

    conda activate escort-ais && python -m escort_ais.experiments.rgd.analyze_rgd_kinetic_leaves_projection
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
from sklearn.decomposition import PCA

from escort_ais.common.paths import project_root
ROOT = project_root()
from sklearn.cluster import KMeans  # noqa: E402
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets  # noqa: E402
from escort_ais.methods.hierarchical_basins import recursive_split  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_fps10_hierarchical_leq import (load_system, kcc_core, its_lags,  # noqa: E402
                                            KMICRO, FPN, LAG_SPLIT, DEAD_FRAC, RESID_MULT)

REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
OUT = ROOT / "results/rgd/report"
T = 100


def process(name="rgd"):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone")
    data = load_system(name)
    feats, dfull, p_land, remd_feats = data["feats"], data["dfull"], data["p_land"], data["remd_feats"]
    km = KMeans(KMICRO, n_init=4, random_state=0).fit(np.concatenate([f[:5 * FPN] for f in feats]))  # same as load

    # --- reconstruct the T=100 kinetic (hierarchical) leaves over the KMeans microstates ---
    d = [dd[:T * FPN] for dd in dfull]
    core, iso, traps = kcc_core(d, p_land)
    leaves, dead, _ = recursive_split(core, d, p_land, KMICRO, float(T), fpn=FPN, lag_split=LAG_SPLIT,
                                      conv_lags=its_lags(T), dead_frac=DEAD_FRAC, resid_mult=RESID_MULT)
    leaves = list(leaves) + ([iso] if (len(iso) and p_land[iso].sum() > DEAD_FRAC) else [])
    leaves = sorted(leaves, key=lambda L: -p_land[np.asarray(L)].sum())
    m2leaf = np.full(KMICRO, -1, int)
    for lid, L in enumerate(leaves):
        m2leaf[np.asarray(L)] = lid
    visits = np.bincount(np.concatenate(d), minlength=KMICRO).astype(float)      # cold visits per microstate
    labels = [f"leaf{lid} (fwd {p_land[np.asarray(L)].sum():.2f})" for lid, L in enumerate(leaves)]
    cold14 = np.degrees(np.arctan2(np.concatenate([f[:, 14] for f in feats]),
                                   np.concatenate([f[:, 15 + 14] for f in feats])))
    cold_minor = float(((cold14 > -15) & (cold14 < 180)).mean())                 # cold coverage of the minor

    # --- microstate CENTROIDS (clean, no frame-assignment noise): project on PCA + recover dihedrals ---
    pca = PCA(4, random_state=0).fit(remd_feats)
    Yc = pca.transform(km.cluster_centers_)                                       # (100, 4)
    C = km.cluster_centers_                                                        # [sin(0..14), cos(0..14)]
    Dc = np.degrees(np.arctan2(C[:, :15], C[:, 15:]))                              # centroid dihedral (100,15)
    Yr = pca.transform(remd_feats)                                                # REMD background
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    Dr = np.degrees(md.compute_dihedrals(remd, np.asarray(q)))                     # REMD dihedrals background
    print(f"T={T}: {len(leaves)} live leaves; centroids per leaf "
          + ", ".join(f"{lid}:{int((m2leaf == lid).sum())}" for lid in range(len(leaves)))
          + f", trap/dead:{int((m2leaf == -1).sum())}; cold minor coverage={cold_minor:.3f} (REMD minor=0.25)",
          file=sys.stderr)
    make_figure(name, Yc, Dc, visits, m2leaf, len(leaves), labels, Yr, Dr, cold_minor)


def make_figure(name, Yc, Dc, visits, m2leaf, nleaf, labels, Yr, Dr, cold_minor):
    from escort_ais.common.figutil import panel_labels
    cols = plt.cm.tab10(np.linspace(0, 1, max(nleaf, 3)))
    sz = 30 + 400 * np.sqrt(visits / visits.max())               # centroid size ~ cold population
    panels = [("PC1", "PC2", Yc[:, 0], Yc[:, 1], Yr[:, 0], Yr[:, 1]),
              ("PC1", "PC3", Yc[:, 0], Yc[:, 2], Yr[:, 0], Yr[:, 2]),
              ("dih #14", "dih #2", Dc[:, 14], Dc[:, 2], Dr[:, 14], Dr[:, 2]),
              ("dih #2", "dih #4", Dc[:, 2], Dc[:, 4], Dr[:, 2], Dr[:, 4])]
    fig, ax = plt.subplots(1, 4, figsize=(19, 4.6))
    for axi, (xl, yl, Xc, Yv, Xr, Yrv) in zip(ax, panels):
        axi.scatter(Xr[::40], Yrv[::40], s=3, c="0.85", alpha=0.5, zorder=1)       # REMD background
        for lid in range(-1, nleaf):
            mm = m2leaf == lid
            if not mm.any():
                continue
            c = "0.5" if lid == -1 else cols[lid]
            lab = "trap/dead micro" if lid == -1 else labels[lid]
            axi.scatter(Xc[mm], Yv[mm], s=sz[mm], color=c, edgecolor="k", lw=0.4, alpha=0.85, zorder=3, label=lab)
        axi.set_xlabel(xl); axi.set_ylabel(yl)
        if "dih" in xl:
            axi.set_xlim(-180, 180); axi.set_ylim(-180, 180)
    ax[0].legend(fontsize=7, markerscale=1, loc="best")
    fig.suptitle(f"{name}: KINETIC (T=100) leaves — microstate centroids (size~cold pop) over REMD (grey).  "
                 f"ALL live leaves sit in the MAJOR (dih14<-15); cold covers the minor only {cold_minor*100:.0f}% "
                 f"(REMD 25%) -> minor is trap/dead + mis-assigned, NOT a real 'minor leaf'", fontsize=10)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_kinetic_leaves_projection.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_kinetic_leaves_projection.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
