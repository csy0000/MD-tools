import warnings; warnings.filterwarnings('ignore'); import json, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
d=json.load(open('data/rgd/diagnostics/bar_permicro/bar_vs_remd.json'))
xb=np.array([r['ddF_bar'] for r in d]); xr=np.array([r['ddF_remd'] for r in d])
bas=[r['basin'] for r in d]; st=[r['state'] for r in d]
col=['#CC3311' if b=='min' else '#4477AA' for b in bas]
mae=np.mean(np.abs(xb-xr)); rmse=np.sqrt(np.mean((xb-xr)**2)); r=np.corrcoef(xb,xr)[0,1]
fig,ax=plt.subplots(figsize=(6.2,6))
lim=[-0.6,3.0]; ax.plot(lim,lim,'k--',lw=.9,label='y = x')
ax.scatter(xr,xb,c=col,s=90,edgecolor='k',lw=.6,zorder=3)
for r_ in d: ax.annotate(str(r_['state']),(r_['ddF_remd'],r_['ddF_bar']),fontsize=8,
                         xytext=(4,4),textcoords='offset points')
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([],[],ls='--',c='k',label='y = x'),
                   Line2D([],[],marker='o',ls='',mfc='#4477AA',mec='k',label='major'),
                   Line2D([],[],marker='o',ls='',mfc='#CC3311',mec='k',label='minor')],fontsize=9)
ax.set(xlabel=r'$\Delta F$ from REMD populations ($k_BT$)',ylabel=r'$\Delta F$ from AIS+BAR ($k_BT$)',
       xlim=lim,ylim=lim,title=f'Per-microstate $\\Delta F$: AIS+BAR vs REMD (9 well-sampled states)\n'
       f'MAE={mae:.2f}, RMSE={rmse:.2f} $k_BT$, r={r:.3f}  (ref = state 16)')
ax.set_aspect('equal'); fig.tight_layout()
p='results/rgd/report/fig_bar_vs_remd_parity.png'; fig.savefig(p,dpi=150); print('saved',p,f'MAE {mae:.2f} RMSE {rmse:.2f} r {r:.3f}')
