#!/usr/bin/env python3
"""pick_rgd_hot_start_confs.py — pick random major/minor starting conformations from the hot
(s=0.25) ensemble for seeded single-walker replicas.

Assigns TICA basins to a hot trajectory, then draws N random distinct frames from each basin and
writes them as PDBs (in prmtop atom order, so run_cyclosporin_reference_md.py --start-pdb can load
them directly). A manifest records which source frame each PDB came from.

Usage:
  python -m escort_ais.experiments.rgd.pick_rgd_hot_start_confs
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import mdtraj as md
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.cyclosporin_torsion_basins import TICABasinModel  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source-dcd",
                    default="data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns/replica_05/trajectory.dcd",
                    help="hot (s=0.25) trajectory to draw start conformations from")
    ap.add_argument("--top", default="data/rgd/topology/topology.pdb")
    ap.add_argument("--basin-model", default="data/rgd/basins_tica/basin_model_backbone.pkl")
    ap.add_argument("--out-dir", default="data/rgd/hot_start_confs")
    ap.add_argument("--n-per-basin", type=int, default=2)
    ap.add_argument("--seed", type=int, default=20260702, help="RNG seed for the random frame choice")
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    traj = md.load_dcd(args.source_dcd, top=args.top)
    model = TICABasinModel.load(args.basin_model)
    basins = model.assign(traj)
    rng = np.random.default_rng(args.seed)

    manifest = []
    for basin_id, name in [(0, "major"), (1, "minor")]:
        idx = np.where(basins == basin_id)[0]
        if len(idx) < args.n_per_basin:
            raise RuntimeError(f"basin {name} has only {len(idx)} frames; need {args.n_per_basin}")
        chosen = rng.choice(idx, size=args.n_per_basin, replace=False)
        for j, frame in enumerate(chosen):
            pdb = out / f"{name}_{j}.pdb"
            traj[int(frame)].save_pdb(str(pdb))
            manifest.append(dict(state=name, index=j, source_frame=int(frame), pdb=str(pdb)))
            print(f"  {name}_{j}: source frame {int(frame):6d}  -> {pdb}")

    (out / "start_confs_manifest.json").write_text(json.dumps(dict(
        source_dcd=args.source_dcd, basin_model=args.basin_model, seed=args.seed,
        n_frames_source=int(traj.n_frames),
        minor_frac_source=float((basins == 1).mean()), picks=manifest,
    ), indent=2))
    print(f"  wrote {len(manifest)} start conformations + manifest to {out}")


if __name__ == "__main__":
    main()
