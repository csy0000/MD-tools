#!/usr/bin/env python
"""Convergence of the major/minor free-energy split ddF = -ln(p_minor/p_major) for four estimators:

  REMD (10 ns discard)  physical rung-0 population counting (reference)
  AIS-1ns               forward-only Jarzynski reweight of the hot ensemble (sum e^{logw} per basin)
  BAR-1ns / BAR-5ns     endpoint-restricted bidirectional BAR, 1 ns vs 5 ns reverse reservoir

The forward AIS data is shared by AIS/BAR-1ns/BAR-5ns; only the reverse reservoir length differs between
BAR-1ns and BAR-5ns (coldlen_retest). Shows that both BAR variants converge to the REMD reference while the
forward-only AIS estimate does not -- and that reservoir length is not the sensitive variable.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.make_rgd_ais_bar_convergence
"""
from __future__ import annotations
import sys, warnings, glob
from pathlib import Path

import numpy as np
import pandas as pd
import mdtraj as md
from scipy.special import logsumexp

warnings.filterwarnings("ignore")
from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel
from escort_ais.methods.endpoint_bar import endpoint_restricted_bar

FWD = ROOT / "data/rgd/diagnostics/forward_5ps"   # forward AIS at 5 ps (MATCHES the 5 ps reverse)
RET = ROOT / "data/rgd/diagnostics/coldlen_retest"
REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns/replica_00"
OUT = ROOT / "results/rgd/report"
MINOR, MAJOR = 1, 0
NS_PER_FRAME = 0.01  # REMD: 10 ps/frame


def ddF_pop(counts):
    p = counts.astype(float); p = p / p.sum()
    return float(-np.log(p[MINOR] / p[MAJOR]))


def load_reverse(ns_dir, top, model):
    rev = pd.read_csv(ns_dir / "rev/ais_trajectory_summary.csv")
    W_r = -rev["final_logw"].to_numpy()
    sc = md.load_dcd(str(ns_dir / "seed_cold/trajectory.dcd"), top=top)
    b_start = model.assign(sc)
    b_r = b_start[rev["initial_frame_index"].to_numpy()]
    return W_r, b_r


def main():
    cfg = load_cfg("rgd"); top = str(cfg.top_pdb)
    model = BasinModel.load(str(ROOT / "data/rgd/basins_tica/basin_model_backbone.pkl"))

    # ---- shared forward AIS ----
    fdf = pd.read_csv(FWD / "ais_trajectory_summary.csv")
    logw_f = fdf["final_logw"].to_numpy(); W_f = -logw_f
    b_f = model.assign(md.load_dcd(str(FWD / "ais_final_coordinates.dcd"), top=top))
    nF = len(W_f)
    W_r1, b_r1 = load_reverse(RET / "ns1", top, model)
    W_r5, b_r5 = load_reverse(RET / "ns5", top, model)

    # ---- REMD reference: cumulative ddF after a 10 ns discard, on two time axes ----
    disc = int(round(10.0 / NS_PER_FRAME))                            # 1000 frames = 10 ns
    parts = [str(REMD / "trajectory.dcd")] + [str(p) for p in sorted(REMD.glob("trajectory_ext*.dcd"))]
    b_remd = model.assign(md.load(parts, top=top))[disc:]            # rung-0 basins after discard
    N_REP = 6
    ks = np.linspace(200, len(b_remd), 40, dtype=int)
    remd_ddF = np.array([ddF_pop(np.bincount(b_remd[:k], minlength=2)) for k in ks])
    remd_t_perrep = (disc + ks) * NS_PER_FRAME                        # invested wall time of ONE replica (incl discard)
    remd_t_total = remd_t_perrep * N_REP                             # total compute across all replicas
    remd_final = ddF_pop(np.bincount(b_remd, minlength=2))

    # ---- AIS / BAR convergence vs CUMULATIVE simulation time ----
    # per-trajectory switch cost: forward 20 ps, reverse 5 ps; cold reservoir = 20 seeds x cold-ns.
    FWD_SW, REV_SW = 0.005, 0.005                                     # ns per AIS trajectory (both 5 ps, matched)
    RES1, RES5 = 20 * 1.0, 20 * 5.0                                   # cold-reservoir ns (1 ns / 5 ns protocol)
    Ns = np.linspace(50, nF, 25, dtype=int)
    ais, bar1, bar5, t_ais, t_bar1, t_bar5 = ([] for _ in range(6))
    for Nf in Ns:
        lw = logw_f[:Nf]; bb = b_f[:Nf]
        lz_min = logsumexp(lw[bb == MINOR]) if (bb == MINOR).any() else -np.inf
        lz_maj = logsumexp(lw[bb == MAJOR]) if (bb == MAJOR).any() else -np.inf
        ais.append(lz_maj - lz_min)
        t_ais.append(Nf * FWD_SW)                                     # forward switches only (no reverse/reservoir)
        for Wr, br, out, tout, res in [(W_r1, b_r1, bar1, t_bar1, RES1), (W_r5, b_r5, bar5, t_bar5, RES5)]:
            Nr = max(int(round(Nf * len(Wr) / nF)), 4)
            r = endpoint_restricted_bar(W_f[:Nf], b_f[:Nf], Wr[:Nr], br[:Nr],
                                        list(range(2)), reference_basin=MAJOR)
            out.append(float(r["ddF"][MINOR]))
            tout.append(Nf * FWD_SW + res + Nr * REV_SW)              # fwd switches + reservoir + rev switches
    ais, bar1, bar5, t_ais, t_bar1, t_bar5 = map(np.array, (ais, bar1, bar5, t_ais, t_bar1, t_bar5))

    print(f"REMD (10 ns discard) final ddF = {remd_final:.3f}  "
          f"[per-replica {remd_t_perrep[-1]:.0f} ns, total {remd_t_total[-1]:.0f} ns]")
    print(f"AIS  (fwd only) final ddF = {ais[-1]:.3f}  [added {t_ais[-1]:.1f} ns]")
    print(f"BAR-1ns final ddF = {bar1[-1]:.3f}  [added {t_bar1[-1]:.1f} ns]")
    print(f"BAR-5ns final ddF = {bar5[-1]:.3f}  [added {t_bar5[-1]:.1f} ns]")

    # ---- figure: same AIS/BAR in both panels; REMD counted per-replica (left) vs total x6 (right) ----
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    def draw_aisbar(a):
        a.plot(t_ais, ais, "^-", color="C2", ms=4, label=f"AIS (fwd only) → {ais[-1]:.2f}")
        a.plot(t_bar1, bar1, "o-", color="C0", ms=4, label=f"BAR-1ns → {bar1[-1]:.2f}")
        a.plot(t_bar5, bar5, "s-", color="C3", ms=4, label=f"BAR-5ns → {bar5[-1]:.2f}")
        a.axhline(remd_final, ls=":", c="gray", lw=1)

    fig, ax = plt.subplots(1, 2, figsize=(11, 4.0), sharey=True)
    draw_aisbar(ax[0])
    ax[0].plot(remd_t_perrep, remd_ddF, "-", color="k", lw=1.8, label=f"REMD / replica → {remd_final:.2f}")
    ax[0].set(title="REMD counted per-replica (500 ns)")
    draw_aisbar(ax[1])
    ax[1].plot(remd_t_total, remd_ddF, "-", color="k", lw=1.8,
               label=f"REMD total ($\\times${N_REP} = 3000 ns) → {remd_final:.2f}")
    ax[1].set(title=f"REMD counted as total replica-time ($\\times${N_REP})")
    for a in ax:
        a.set_xlabel("cumulative simulation time (ns)")
        a.axhline(0, c="lightgray", lw=.5)
        a.legend(fontsize=8, loc="upper right")
    ax[0].set_ylabel(r"$\Delta\Delta F$ (minor$-$major, $k_BT$)")
    fig.suptitle("Major/minor $\\Delta\\Delta F$ convergence vs cumulative simulation time", y=1.02)
    fig.tight_layout()
    OUT.mkdir(parents=True, exist_ok=True)
    p = OUT / "fig_rgd_ais_bar_convergence.png"
    fig.savefig(p, dpi=140, bbox_inches="tight")
    print(f"saved {p}")


if __name__ == "__main__":
    main()
