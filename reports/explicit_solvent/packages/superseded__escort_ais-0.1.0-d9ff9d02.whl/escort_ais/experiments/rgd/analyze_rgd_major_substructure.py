#!/usr/bin/env python3
"""analyze_rgd_major_substructure.py — can the rgd major state (S0) be defined by ONE dihedral?

S0 is the dih#14-major (theta14 in [-180,-15], REMD 0.746). If one dihedral sufficed, every OTHER backbone
dihedral would be unimodal within S0. This script quantifies the internal structure of S0:
  * per dihedral: within-S0 modality (REMD) and the between-restrained-seed 'trapping spread' (circular std of the
    8 frozen restrained seeds' means) -> which coordinate the 300K-restrained seeds get stuck along;
  * REMD within-S0 2D density on the top-2 trapping coordinates, overlaid with the 8 restrained-seed frozen means
    and the cold reservoir -> shows S0's internal sub-structure and that it is NOT a single-dihedral state.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.analyze_rgd_major_substructure
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
from scipy.ndimage import gaussian_filter1d

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
RESTR = ROOT / "data/rgd/diagnostics/within_basin_restrained/rgd/major"
COLD = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment/rgd/cold_md"
OUT = ROOT / "results/rgd/report"
SEP = 14                                                  # the dih#14 major/minor separator


def cmean(deg):
    r = np.radians(deg)
    return np.degrees(np.arctan2(np.sin(r).mean(), np.cos(r).mean()))


def cstd(deg):
    r = np.radians(deg)
    R = np.hypot(np.sin(r).mean(), np.cos(r).mean())
    return float(np.degrees(np.sqrt(-2 * np.log(max(R, 1e-9)))))


def n_modes(ang, nb=36, thr=0.12):
    h, _ = np.histogram(ang, bins=nb, range=(-180, 180))
    hs = gaussian_filter1d(h / max(h.sum(), 1), 1.2, mode="wrap")
    return sum(hs[i] >= hs[(i - 1) % nb] and hs[i] >= hs[(i + 1) % nb] and hs[i] > thr * hs.max()
              for i in range(nb))


def dih_of(traj, Q):
    return np.degrees(md.compute_dihedrals(traj, Q))


def in_major(D):
    return (D[:, SEP] >= -180) & (D[:, SEP] <= -15)


def process(name="rgd"):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone"); Q = np.asarray(q)
    top = str(cfg.top_pdb)
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    Dr = dih_of(remd, Q); mr = in_major(Dr); Rmaj = Dr[mr]
    seeds = []
    for d in sorted(glob.glob(str(RESTR / "seed_*"))):
        t = md.load_dcd(str(Path(d) / "trajectory.dcd"), top=top)[1000:]
        Ds = dih_of(t, Q); m = in_major(Ds)
        if m.sum() > 100:
            seeds.append(Ds[m])
    cold = []
    for d in sorted(glob.glob(str(COLD / "seed_*"))):
        pdb = Path(d) / "final_structure.pdb"
        if pdb.exists():
            Dc = dih_of(md.load_dcd(str(Path(d) / "trajectory.dcd"), top=str(pdb)), Q)
            m = in_major(Dc)
            if m.any():
                cold.append(Dc[m])
    Cmaj = np.concatenate(cold)

    # per-dihedral: within-S0 REMD modality + trapping spread of the restrained seeds
    seed_means = np.array([[cmean(s[:, i]) for i in range(15)] for s in seeds])   # (nseed, 15)
    rank = []
    for i in range(15):
        if i == SEP:
            continue
        rank.append(dict(dih=i, remd_modes=int(n_modes(Rmaj[:, i])),
                         trap_spread=round(cstd(seed_means[:, i]), 1)))
    rank.sort(key=lambda r: -r["trap_spread"])
    top2 = [rank[0]["dih"], rank[1]["dih"]]
    verdict = ("S0 is NOT definable by one dihedral" if rank[0]["trap_spread"] > 25
               else "one dihedral may suffice")
    res = dict(name=name, separator_dih=SEP, remd_major_frac=round(float(mr.mean()), 3),
               n_restrained_seeds=len(seeds), top_substructure_dihedrals=top2, verdict=verdict,
               per_dihedral=rank)
    (RESTR.parent / "major_substructure.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({k: res[k] for k in ("top_substructure_dihedrals", "verdict")}, indent=2), file=sys.stderr)
    for r in rank[:5]:
        print(f"  dih#{r['dih']:2d}: trap_spread={r['trap_spread']:5.1f} deg  remd_modes={r['remd_modes']}",
              file=sys.stderr)
    make_figure(name, Rmaj, Cmaj, seeds, seed_means, rank, top2)
    return res


def make_figure(name, Rmaj, Cmaj, seeds, seed_means, rank, top2):
    # Colour convention (consistent across the bAIS report figures):
    #   REMD (equilibrium reference) = GREY;  cold reservoir (FPS 300 K MD, the tested ensemble) = ORANGE;
    #   restrained seeds = BLUE.  Do not colour REMD and cold the same.
    from escort_ais.common.figutil import panel_labels
    a, b = top2
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.6))
    # (0) trapping spread per dihedral
    idx = [r["dih"] for r in rank]; sp = [r["trap_spread"] for r in rank]
    ax[0].bar(range(len(idx)), sp, color=["C3" if d in top2 else "0.6" for d in idx])
    ax[0].set_xticks(range(len(idx))); ax[0].set_xticklabels([f"#{d}" for d in idx], fontsize=7)
    ax[0].axhline(25, ls=":", c="0.4"); ax[0].set_ylabel("between-seed trapping spread (deg)")
    ax[0].set_xlabel("backbone dihedral (excl. #14 separator)")
    ax[0].set_title("which coordinate do frozen seeds separate along?")
    # (1) REMD as GREY DENSITY CONTOURS (drawn on top, so never hidden) over the cold reservoir (ORANGE points)
    # + restrained seeds (BLUE). Earlier the cold scatter was painted over the REMD scatter and buried it; contours
    # keep the compact REMD region always visible AND leave the cold points readable where they spill BEYOND REMD
    # (the dih#4~0 trap sub-wells REMD leaves empty). REMD-R0 is unimodal, so its contours are one tight island.
    from matplotlib.lines import Line2D
    from scipy.ndimage import gaussian_filter
    Hr, xe, ye = np.histogram2d(Rmaj[:, a], Rmaj[:, b], bins=40, range=[[-180, 180], [-180, 180]])
    Hs = gaussian_filter(Hr.T, 1.0)                                     # smooth; threshold above the noise floor
    xc = 0.5 * (xe[:-1] + xe[1:]); yc = 0.5 * (ye[:-1] + ye[1:])
    ax[1].scatter(Cmaj[::50, a], Cmaj[::50, b], s=5, c="C1", alpha=0.4, zorder=1,
                  label="cold reservoir (FPS 300 K MD)")
    ax[1].contour(xc, yc, Hs, levels=np.linspace(0.06, 0.9, 6) * Hs.max(), colors="0.15", linewidths=1.1, zorder=3)
    ax[1].scatter(seed_means[:, a], seed_means[:, b], s=90, c="C0", edgecolor="k", zorder=5,
                  label="restrained seeds (frozen)")
    ax[1].set_xlim(-180, 180); ax[1].set_ylim(-180, 180)
    ax[1].set_xlabel(f"dih #{a} (deg)"); ax[1].set_ylabel(f"dih #{b} (deg)")
    ax[1].set_title(f"{name} S0: grey contours = REMD (compact, one basin), orange = cold reservoir spillover")
    handles, _ = ax[1].get_legend_handles_labels()
    handles = [Line2D([0], [0], color="0.15", lw=1.5, label="REMD (equilibrium) density")] + handles
    ax[1].legend(handles=handles, fontsize=7, loc="lower left")
    # (2) 1D marginal on the top coordinate: REMD vs cold reservoir vs restrained-pooled
    Smaj = np.concatenate(seeds)
    for X, c, lab, lw in [(Rmaj[:, a], "0.35", "REMD (equilibrium)", 2.6), (Cmaj[:, a], "C1", "cold reservoir", 2.0),
                          (Smaj[:, a], "C0", "restrained", 2.0)]:
        h, e = np.histogram(X, bins=48, range=(-180, 180), density=True)
        ax[2].plot(0.5 * (e[:-1] + e[1:]), gaussian_filter1d(h, 1.0), c=c, lw=lw, label=lab)
    ax[2].set_xlabel(f"dih #{a} (deg)"); ax[2].set_ylabel("within-S0 density")
    ax[2].set_title(f"S0 marginal on dih #{a}"); ax[2].legend(fontsize=8)
    fig.suptitle(f"{name}: is the major state S0 definable by one dihedral (#14)?  "
                 f"NO — sub-structure along dih #{a}/#{b}", fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.96]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_major_substructure.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_major_substructure.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
