import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob, json, sys
import mdtraj as md
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
RES='data/rgd/2026-06-29-reservoir-sw-s0p25'
# rebuild identical 24-state kmeans
seeds=sorted(glob.glob(f'{RES}/cold_md_10ns/seed_*/trajectory.dcd'))
Xall=np.concatenate([featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds])
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(24,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
# REMD populations per microstate
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
rmic=km.predict(sc.transform(pca.transform(featurize(remd,q))))
p=np.bincount(rmic,minlength=24).astype(float); p/=p.sum()
ref=16
with np.errstate(divide='ignore'): ddF_remd={k:-np.log(p[k]/p[ref]) for k in range(24)}
# BAR results
bar=json.load(open('data/rgd/diagnostics/bar_permicro/result.json'))
byk={r['state']:r for r in bar['per_microstate']}
# the 9 well-sampled states (n_fwd>=20)
nine=[k for k in range(24) if byk[k]['n_fwd']>=20]
mf=lambda k: 'min' if fz.assign(remd[rmic==k][:1] if (rmic==k).any() else remd[:1])[0]==1 else 'maj'
minorf={k: fz.assign(remd[rmic==k]).mean() if (rmic==k).any() else np.nan for k in range(24)}
print(f"reference = state {ref}; ddF = -ln(p_state/p_ref) in kT",flush=True)
print(f"\n{'state':>5} {'basin':>5} {'n_fwd':>5} {'REMD_pop%':>9} {'ddF_BAR':>8} {'ddF_REMD':>9} {'diff':>6}",flush=True)
rows=[]
for k in sorted(nine,key=lambda k:(minorf[k]>.5,-p[k])):
    b='min' if minorf[k]>.5 else 'maj'
    dB=byk[k]['dF']; dR=ddF_remd[k]
    diff=(dB-dR) if (dB is not None and np.isfinite(dR)) else np.nan
    rows.append((k,b,byk[k]['n_fwd'],100*p[k],dB,dR,diff))
    print(f"{k:5d} {b:>5} {byk[k]['n_fwd']:5d} {100*p[k]:9.2f} "
          f"{dB:8.2f} {dR:9.2f} {diff:6.2f}",flush=True)
d=np.array([r[6] for r in rows]); print(f"\nMAE(BAR-REMD) over 9 states: {np.nanmean(np.abs(d)):.2f} kT; "
      f"RMSE {np.sqrt(np.nanmean(d**2)):.2f} kT",flush=True)
# also aggregate 2-state check
maj=[k for k in nine if minorf[k]<.5]; mino=[k for k in nine if minorf[k]>.5]
print(f"\naggregate: major states {maj} ddF~0 ; minor states {mino}",flush=True)
json.dump([dict(state=r[0],basin=r[1],n_fwd=r[2],remd_pop=r[3],ddF_bar=r[4],ddF_remd=r[5],diff=r[6]) for r in rows],
          open('data/rgd/diagnostics/bar_permicro/bar_vs_remd.json','w'),indent=2)
