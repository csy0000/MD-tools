#!/usr/bin/env python
"""Re-run the RGD forward AIS at 5 ps (to MATCH the 5 ps reverse) from the same hot seeds.

The reservoir-sw forward was generated at 20 ps (script default); combining it with a 5 ps reverse breaks
the BAR/Crooks pairing (reverse must be the time-reverse of the forward -> same switch schedule). This
reuses the identical seed_hot frames and only changes switch_ps 20 -> 5.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.run_rgd_forward_5ps
"""
import sys
from pathlib import Path

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.methods.run_macrocycle_seedsource_swap import run_leg

cfg = load_cfg("rgd")
seed_dir = ROOT / "data/rgd/2026-06-29-reservoir-sw-s0p25/seed_hot"
out = ROOT / "data/rgd/diagnostics/forward_5ps"
logw, sel = run_leg(seed_dir, out, 1000, 0.25, 1.0, 5.0, 4, 10, "OpenCL", 7, cfg, devices="0")
print(f"forward 5 ps done: {len(logw)} trajectories -> {out}")
