#!/usr/bin/env python3
"""analyze_rgd_state_pca_separation.py — can the metastable states S0/S1/S2 be separated by 2-3 PC axes?

PCA on the REMD backbone-torsion features (sin/cos of all 15 dihedrals); label frames by REMD's own density
metastable states (S0/S1/S2). Reports how much variance PC1-3 hold and how accurately a linear classifier
separates the 3 states from just PC1-2 and PC1-3, and plots the PC1-2 / PC1-3 projections coloured by state.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.analyze_rgd_state_pca_separation
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import cross_val_score

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_fps10_leq_convergence import density_basins  # noqa: E402

REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
OUT = ROOT / "results/rgd/report"


def process(name="rgd"):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone")
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    X = featurize(remd, q)                                             # sin/cos of 15 backbone dihedrals (30-D)
    rng = np.random.default_rng(0)
    lab, _knn, NB, _noise = density_basins(X, rng)                     # REMD's own metastable states S0/S1/...
    pca = PCA(8, random_state=0).fit(X); Y = pca.transform(X)
    ev = pca.explained_variance_ratio_
    mask = lab >= 0
    pops = {int(b): round(float((lab == b).mean()), 3) for b in range(NB)}
    accs = {}
    for npc in (2, 3, 5):
        accs[npc] = round(float(cross_val_score(LDA(), Y[mask, :npc], lab[mask], cv=3).mean()), 3)
    res = dict(name=name, n_states=int(NB), state_pops=pops,
               explained_var=[round(float(v), 3) for v in ev],
               cum_var={n: round(float(ev[:n].sum()), 3) for n in (2, 3, 5)},
               lda_3state_accuracy=accs)
    (OUT / f"{name}_state_pca_separation.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2), file=sys.stderr)
    make_figure(name, Y, lab, NB, ev, accs)
    return res


def make_figure(name, Y, lab, NB, ev, accs):
    from escort_ais.common.figutil import panel_labels
    cols = plt.cm.tab10(np.linspace(0, 1, max(NB, 3)))
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.6))
    for pair, axi in ((( 0, 1), ax[0]), ((0, 2), ax[1])):
        i, j = pair
        for b in range(NB):
            m = lab == b
            axi.scatter(Y[m, i][::20], Y[m, j][::20], s=4, color=cols[b], alpha=0.4, label=f"S{b}")
        axi.set_xlabel(f"PC{i+1} ({ev[i]*100:.0f}%)"); axi.set_ylabel(f"PC{j+1} ({ev[j]*100:.0f}%)")
        axi.set_title(f"{name}: states in PC{i+1}-PC{j+1}"); axi.legend(fontsize=8, markerscale=2)
    ax[2].bar([f"PC1-{n}" for n in accs], list(accs.values()), color="C0")
    for n, v in accs.items():
        ax[2].text(list(accs).index(n), v, f"{v}", ha="center", va="bottom", fontsize=9)
    ax[2].axhline(1.0, ls=":", c="0.4"); ax[2].set_ylim(0, 1.05)
    ax[2].set_ylabel("3-state LDA accuracy (3-fold CV)")
    ax[2].set_title("can 2/3/5 PCs separate S0/S1/S2?")
    fig.suptitle(f"{name}: are metastable states S0/S1/S2 low-dimensional in PCA?", fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.96]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_state_pca_separation.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_state_pca_separation.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
