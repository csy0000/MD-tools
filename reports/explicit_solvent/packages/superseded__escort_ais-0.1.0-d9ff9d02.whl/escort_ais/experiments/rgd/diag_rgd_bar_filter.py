import warnings; warnings.filterwarnings('ignore'); import argparse,sys,glob,json,shutil
import numpy as np, pandas as pd, mdtraj as md
from pathlib import Path
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.endpoint_bar import endpoint_restricted_bar
from escort_ais.methods.run_macrocycle_seedsource_swap import run_leg, largest_remainder
ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['filtered','unfiltered'],required=True)
ap.add_argument('--out-dir',required=True); ap.add_argument('--device',default='0'); ap.add_argument('--k',type=int,default=800)
a=ap.parse_args(); rng=np.random.default_rng(7)
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl'); nb=2
RES='data/rgd/2026-06-29-reservoir-sw-s0p25'
fdf=pd.read_csv(f'{RES}/step_forward_ais/ais_trajectory_summary.csv'); W_f=-fdf['final_logw'].to_numpy()
land=md.load_dcd(f'{RES}/step_forward_ais/ais_final_coordinates.dcd',top=top)
b_f=fz.assign(land); landX=featurize(land,q)
# 24-state kmeans on cold reservoir
seeds=sorted(glob.glob(f'{RES}/cold_md_10ns/seed_*/trajectory.dcd'))
Xs=[featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds]; Xall=np.concatenate(Xs)
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(24,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
land_micro=km.predict(sc.transform(pca.transform(landX)))
landed=set(np.unique(land_micro).tolist())              # states that received >=1 forward landing
print(f"[{a.mode}] landed states {sorted(landed)} ; removed {sorted(set(range(24))-landed)}",flush=True)
# pool reservoir xyz+basin+micro
xyz=[]; bas=[]; mic=[]
for s in seeds:
    t=md.load_dcd(s,top=top)[50:]; xyz.append(t.xyz); bas.append(fz.assign(t))
    mic.append(km.predict(sc.transform(pca.transform(featurize(t,q)))))
xyz=np.concatenate(xyz); bas=np.concatenate(bas); mic=np.concatenate(mic)
top0=md.load_dcd(seeds[0],top=top).topology
if a.mode=='filtered':
    keep=np.isin(mic,list(landed)); xyz=xyz[keep]; bas=bas[keep]
    print(f"  kept {keep.sum()}/{len(keep)} frames; minor frac {bas.mean():.3f}",flush=True)
# reverse allocation == forward landing ratio (major/minor)
lc=np.bincount(b_f,minlength=nb)
usable=np.array([B for B in range(nb) if lc[B]>0 and (bas==B).sum()>0])
alloc=largest_remainder(lc[usable],a.k); rp=[]; b_r0=[]
for B,n in zip(usable,alloc):
    idx=rng.choice(np.where(bas==B)[0],int(n),replace=True); rp.append(xyz[idx]); b_r0+=[int(B)]*int(n)
b_r0=np.asarray(b_r0)
out=Path(a.out_dir); rs=out/'seed_cold'; rs.mkdir(parents=True,exist_ok=True)
md.Trajectory(np.concatenate(rp),top0).save_dcd(str(rs/'trajectory.dcd')); shutil.copy2(cfg.top_pdb,rs/'start_structure.pdb')
json.dump(dict(prmtop_path=str(cfg.prmtop),inpcrd_path=str(cfg.inpcrd),gb_model='GBn2',gb_radii='mbondi3',
              n_solute_atoms=cfg.n_solute_atoms,timestep_fs=2.0,friction_per_ps=1.0,temperature_k=300.0,solvent='implicit'),open(rs/'config.json','w'),indent=2)
print(f"[{a.mode}] reverse alloc major/minor {alloc.tolist()}; running reverse AIS 20ps...",flush=True)
logw,sel=run_leg(rs,out/'rev',len(b_r0),1.0,0.25,20.0,4,10,'OpenCL',7,cfg,devices=a.device)
W_r=-logw; b_r=b_r0[sel]
r=endpoint_restricted_bar(W_f,b_f,W_r,b_r,list(range(nb)),reference_basin=0,bootstrap=True,n_bootstrap=1000,rng=rng)
res=dict(mode=a.mode,ddF_minor=float(r['ddF'][1]),W_r_std=float(W_r.std()),W_r_std_minor=float(W_r[b_r==1].std()),
         n_removed=len(set(range(24))-landed))
json.dump(res,open(out/'result.json','w'),indent=2)
print(f"[{a.mode}] BAR ddF_minor = {r['ddF'][1]:.2f}  (REMD ref 1.11)  W_r std {W_r.std():.0f}",flush=True)
