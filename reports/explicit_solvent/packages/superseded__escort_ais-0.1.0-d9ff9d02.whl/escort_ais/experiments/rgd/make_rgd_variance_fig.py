#!/usr/bin/env python3
"""make_rgd_variance_fig.py — variance-lever comparison figure for the AIS/BAR CI.

Two levers on the T=100 ns hot ensemble at equal ~2x cost: (A) double the switching samples
(k=1000->2000, 5 ps) vs (B) double the switching time (5->10 ps, k=1000), against a k=1000/5 ps
baseline. Reads the three cells' validation_summary.json and plots (a) ddF +/- 95% CI and
(b) the CI half-width per lever.

Usage:  python -m escort_ais.experiments.rgd.make_rgd_variance_fig
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
REPORT = ROOT / "results/rgd/report"
REF = 1.11
DIAG = ROOT / "data/rgd/diagnostics"

CELLS = [  # (dir, short label, wall-min)
    ("var_k1000_sw5_hot100",  "baseline\n$k{=}1000$, 5 ps", 14.5),
    ("var_k2000_sw5_hot100",  "(A) 2$\\times$ samples\n$k{=}2000$, 5 ps", 28.6),
    ("var_k1000_sw10_hot100", "(B) 2$\\times$ switch\n$k{=}1000$, 10 ps", 28.6),
]


def main():
    dd, lo, hi, half, nrmin, labels = [], [], [], [], [], []
    for d, lab, _ in CELLS:
        c = json.load(open(DIAG / d / "validation_summary.json"))
        m = c["ddF_bar"][1]; ci = c["ddF_bar_ci"][1]
        dd.append(m); lo.append(m - ci[0]); hi.append(ci[1] - m)
        half.append((ci[1] - ci[0]) / 2); nrmin.append(c["n_r"][1]); labels.append(lab)
    x = np.arange(len(CELLS))

    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))

    # (a) ddF +/- 95% CI
    ax[0].errorbar(x, dd, yerr=[lo, hi], fmt="o", color="C0", capsize=5, ms=8, lw=1.8)
    ax[0].axhline(REF, ls=":", color="gray", label=f"REMD reference ({REF})")
    for xi, m, nm in zip(x, dd, nrmin):
        ax[0].annotate(f"{m:.2f}\n($n_{{r,\\min}}{{=}}{nm}$)", (xi, m), textcoords="offset points",
                       xytext=(12, 0), va="center", fontsize=8)
    ax[0].set_xticks(x); ax[0].set_xticklabels(labels, fontsize=8)
    ax[0].set_ylabel(r"$\Delta\Delta F$ minor (kT)")
    ax[0].set_title(r"(a) $\Delta\Delta F \pm$ 95% CI (all consistent with reference)")
    ax[0].legend(fontsize=8); ax[0].set_xlim(-0.5, len(CELLS) - 0.3)

    # (b) CI half-width bars
    bars = ax[1].bar(x, half, color=["#7f7f7f", "C0", "C1"], width=0.6)
    sqrt2 = half[0] / np.sqrt(2)
    ax[1].axhline(sqrt2, ls="--", color="C0",
                  label=fr"baseline$/\sqrt{{2}}$ = {sqrt2:.2f} (2$\times$-sample expectation)")
    for b, h in zip(bars, half):
        ax[1].annotate(f"$\\pm${h:.2f}", (b.get_x() + b.get_width() / 2, h),
                       textcoords="offset points", xytext=(0, 3), ha="center", fontsize=9)
    ax[1].set_xticks(x); ax[1].set_xticklabels(labels, fontsize=8)
    ax[1].set_ylabel("95% CI half-width (kT)")
    ax[1].set_title(r"(b) CI half-width --- (A) and (B) cost the same $\sim$2$\times$")
    ax[1].legend(fontsize=8); ax[1].set_ylim(0, max(half) * 1.25)

    fig.suptitle("AIS/BAR variance levers on the 100 ns hot ensemble: more samples $>$ longer switch",
                 y=1.02)
    fig.tight_layout()
    out = REPORT / "fig_rgd_variance_levers.png"
    fig.savefig(out, dpi=130, bbox_inches="tight")
    print(f"wrote {out}")
    for (d, lab, w), h, nm in zip(CELLS, half, nrmin):
        print(f"  {d}: half=+/-{h:.2f}  n_r_min={nm}  wall={w}min")


if __name__ == "__main__":
    main()
