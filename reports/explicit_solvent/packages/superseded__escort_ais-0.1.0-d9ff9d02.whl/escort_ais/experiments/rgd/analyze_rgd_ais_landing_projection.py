#!/usr/bin/env python3
"""analyze_rgd_ais_landing_projection.py — did the forward-AIS landings sample every basin?

The cold reservoir under-samples the minor (6.5% vs REMD 25%). The forward-AIS landings, drawn from the HOT
ensemble, should cover all basins — and they drive the between-state populations. This projects the 1000 gen0
forward-AIS landings onto the REMD PCA / dihedral-pair axes, coloured by REMD density basin (S0/S1/S2), sized by
AIS weight exp(final_logw), over a REMD background, and reports per-basin RAW landing count and AIS-WEIGHTED
population vs REMD.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.analyze_rgd_ais_landing_projection
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.decomposition import PCA

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_fps10_leq_convergence import density_basins  # noqa: E402

REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
FWD = ROOT / "data/rgd/diagnostics/bais_eval/rgd/gen0/fwd"
OUT = ROOT / "results/rgd/report"


def process(name="rgd"):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone"); Q = np.asarray(q)
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    Xr = featurize(remd, q); Dr = np.degrees(md.compute_dihedrals(remd, Q))
    rng = np.random.default_rng(0)
    rlab, knn, NB, _noise = density_basins(Xr, rng)                              # REMD states + a knn classifier
    remd_pop = {int(b): round(float((rlab == b).mean()), 3) for b in range(NB)}
    pca = PCA(4, random_state=0).fit(Xr); Yr = pca.transform(Xr)

    land = md.load_dcd(str(FWD / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    Xl = featurize(land, q); Dl = np.degrees(md.compute_dihedrals(land, Q)); Yl = pca.transform(Xl)
    logw = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    lab = knn.predict(Xl)                                                        # basin of each landing
    w = np.exp(logw - logw.max())                                               # AIS weight (unnormalised)

    tot = logsumexp(logw)
    raw = {int(b): round(float((lab == b).mean()), 3) for b in range(NB)}
    wpop = {int(b): (round(float(np.exp(logsumexp(logw[lab == b]) - tot)), 3) if (lab == b).any() else 0.0)
            for b in range(NB)}
    ess_all = float((w.sum() ** 2) / np.sum(w ** 2))
    ess = {int(b): (round(float((w[lab == b].sum() ** 2) / np.sum(w[lab == b] ** 2)), 1) if (lab == b).any()
                    else 0.0) for b in range(NB)}
    res = dict(name=name, n_landings=int(len(Xl)), n_states=int(NB), remd_pop=remd_pop,
               landing_raw_frac=raw, landing_weighted_pop=wpop,
               ess_all=round(ess_all, 1), ess_per_basin=ess, top1_weight_frac=round(float(w.max() / w.sum()), 3))
    (OUT / f"{name}_ais_landing_coverage.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2), file=sys.stderr)
    make_figure(name, Yr, Dr, Yl, Dl, lab, w, NB, raw, wpop, remd_pop, ess, ess_all)


def make_figure(name, Yr, Dr, Yl, Dl, lab, w, NB, raw, wpop, remd_pop, ess, ess_all):
    from escort_ais.common.figutil import panel_labels
    cols = plt.cm.tab10(np.linspace(0, 1, max(NB, 3)))
    sz = 8 + 220 * np.sqrt(w / w.max())
    panels = [("PC1", "PC2", Yl[:, 0], Yl[:, 1], Yr[:, 0], Yr[:, 1]),
              ("PC1", "PC3", Yl[:, 0], Yl[:, 2], Yr[:, 0], Yr[:, 2]),
              ("dih #14", "dih #2", Dl[:, 14], Dl[:, 2], Dr[:, 14], Dr[:, 2]),
              ("dih #2", "dih #4", Dl[:, 2], Dl[:, 4], Dr[:, 2], Dr[:, 4])]
    fig, ax = plt.subplots(1, 4, figsize=(19, 4.6))
    for axi, (xl, yl, Xc, Yv, Xr, Yrv) in zip(ax, panels):
        axi.scatter(Xr[::40], Yrv[::40], s=3, c="0.85", alpha=0.5, zorder=1)
        for b in range(NB):
            m = lab == b
            axi.scatter(Xc[m], Yv[m], s=sz[m], color=cols[b], edgecolor="k", lw=0.2, alpha=0.7, zorder=3,
                        label=f"S{b}: n{int(m.sum())} wpop{wpop[b]:.2f} ESS{ess[b]:.0f} (REMD {remd_pop[b]:.2f})")
        axi.set_xlabel(xl); axi.set_ylabel(yl)
        if "dih" in xl:
            axi.set_xlim(-180, 180); axi.set_ylim(-180, 180)
    ax[0].legend(fontsize=7, markerscale=1, loc="best")
    fig.suptitle(f"{name}: forward-AIS landings (size~AIS weight) over REMD (grey) by basin.  AIS SAMPLES every "
                 f"basin, but weights are DEGENERATE: overall ESS={ess_all:.0f}/1000; the minor's wpop rests on "
                 f"~{ess[1]:.0f} effective landings -> AIS-weighted minor pop unreliable", fontsize=10)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_ais_landing_projection.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_ais_landing_projection.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
