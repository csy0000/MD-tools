#!/usr/bin/env python3
"""run_rgd_baus_bata_coldtime.py — BAUS-N/BAIS-N on cyclo-RGDfV: ddF RMSE vs cold-MD time.

From a 60 ns hot (REST2 s=0.25) ensemble, run forward AIS at a 5 ps switch for N∈{500,1000}, seed ONE cold-MD walker
per basin (major/minor), run cold MD to 100 ns, and record the ddF RMSE vs the REMD reference every 10 ns of cold time.

The ddF is the STANDING-RULE population estimate (per-cluster reweight → weighted single-torsion histogram vs REMD;
NEVER 2-basin BAR): microstates = PCA(8)→KMeans(24) on the cold reservoir, p_land(S)=softmax of forward-AIS
`final_logw` within S, cold frames weighted W=p_land(S)/n_cold(S), p_minor = weighted fraction of the dih14 minor
window, ddF = −ln(p_minor/(1−p_minor)). For this 2-state population BAUS-N and BAIS-N COINCIDE (BAIS adds the cold
major↔minor MSM rate, which one-walker-per-basin cold MD cannot resolve → reported separately, NaN if uncrossed).

Phases (run in one process): prep 60 ns hot seed → forward AIS (both N, GPU-pinned) → cold MD (2 basins, parallel) →
analyze (reweight ddF per 10 ns cold prefix) → figure + JSON.

    conda activate escort-ais && python -m escort_ais.experiments.rgd.run_rgd_baus_bata_coldtime [--smoke]
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import write_seed_dir, run_leg, load_sw_hot, load_remd_ensemble  # noqa: E402

HOT_TRAJ = ROOT / "data/rgd/2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701/trajectory.dcd"
REMD_DIR = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
START_PDB = {0: ROOT / "data/rgd/hot_start_confs/major_0.pdb", 1: ROOT / "data/rgd/hot_start_confs/minor_0.pdb"}
OUT = ROOT / "data/rgd/diagnostics/baus_bata_coldtime"


def in_window(deg, lo, hi):
    return (deg >= lo) & (deg <= hi) if lo <= hi else (deg >= lo) | (deg <= hi)


def _ddF(p_minor):
    p = min(max(float(p_minor), 1e-9), 1 - 1e-9)
    return -float(np.log(p / (1 - p)))


def reference_ddF(model, top, burn_frames):
    """REMD reference ddF = population −ln(p_minor/p_major) on replica_00 (the standing rule)."""
    remd = load_remd_ensemble(REMD_DIR, "replica_00", top, burn_frames)
    b = model.assign(remd); p = np.bincount(b, minlength=model.n_basins).astype(float); p /= p.sum()
    return _ddF(p[1])


def reweight_ddF(fwdX, fwdW, coldX, coldTor, lo, hi, K=24, seed=0):
    """Per-cluster reweight → weighted single-torsion (dih14) population ddF. Returns (ddF_torsion, ddF_micro)."""
    K = int(min(K, max(2, len(coldX) // 20)))
    pca = PCA(min(8, coldX.shape[1]), random_state=seed).fit(coldX)
    scal = StandardScaler().fit(pca.transform(coldX))
    km = KMeans(K, n_init=10, random_state=seed).fit(scal.transform(pca.transform(coldX)))
    micro = lambda X: km.predict(scal.transform(pca.transform(X)))
    mc = micro(coldX); ncold = np.bincount(mc, minlength=K)
    is_minor = in_window(coldTor, lo, hi)
    micro_is_minor = np.array([(is_minor[mc == S].mean() > 0.5) if (mc == S).any() else False for S in range(K)])
    # p_land(S) from forward landings
    mf = micro(fwdX); lp = np.full(K, -np.inf)
    for S in range(K):
        m = mf == S
        if m.any():
            lp[S] = logsumexp(fwdW[m])
    lp -= logsumexp(lp); p_land = np.exp(lp)
    # single-torsion reweight
    Wcold = np.array([p_land[S] / ncold[S] if ncold[S] > 0 else 0.0 for S in mc])
    tot = Wcold.sum()
    p_tor = float(Wcold[in_window(coldTor, lo, hi)].sum() / tot) if tot > 0 else np.nan
    p_mic = float(p_land[micro_is_minor].sum())
    return _ddF(p_tor), _ddF(p_mic)


def run(smoke=False):
    cfg = load_cfg("rgd")
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.basin_model_path); qi, lo, hi = model.rules[0]; qi = int(qi)

    ns_list = [10, 20] if smoke else [500, 1000]
    switch_ps = 5.0
    hot_frames = 200 if smoke else 6000          # 60 ns at 10 ps/frame (2 ns for smoke)
    cold_ns = 0.2 if smoke else 100.0
    checkpoints = [round(cold_ns, 3)] if smoke else list(np.arange(10, 101, 10))
    n_shards = 2 if smoke else 4
    burn_frames_remd = 500 if smoke else 5000    # REMD 50 ns burn (10 ps/frame)
    cold_burn_ps = 200.0                          # cold-MD burn before the reservoir is used
    OUT.mkdir(parents=True, exist_ok=True)

    ref = reference_ddF(model, top, burn_frames_remd)
    print(f"REMD reference ddF (replica_00) = {ref:.3f} kT", file=sys.stderr)

    # 1. 60 ns hot forward-AIS seed dir
    seed_dir = OUT / "hot_seed"
    hot = load_sw_hot(HOT_TRAJ, cfg.top_pdb)[:hot_frames]
    write_seed_dir(seed_dir, hot, cfg, timestep_fs=2.0)
    print(f"hot seed: {hot.n_frames} frames ({hot.n_frames*0.01:.0f} ns)", file=sys.stderr)

    # 2. forward AIS for each N (device-pinned; run sequentially, each shards internally)
    fwd = {}
    for i, N in enumerate(ns_list):
        outd = OUT / f"fwd_N{N}"
        dev = "0" if smoke else ["0", "2"][i % 2]
        print(f"forward AIS N={N} switch={switch_ps}ps on GPU {dev} ...", file=sys.stderr)
        logw, sel = run_leg(seed_dir, outd, N, 0.25, 1.0, switch_ps, n_shards, 10,
                            "CUDA", 20260712 + i, cfg, devices=dev)
        land = md.load_dcd(str(outd / "ais_final_coordinates.dcd"), top=top)
        n = min(len(logw), land.n_frames)
        fwd[N] = dict(X=featurize(land[:n], q), W=np.asarray(logw)[:n])
        print(f"  N={N}: {n} landings, minor-frac {model.assign(land[:n]).mean():.3f}", file=sys.stderr)

    # 3. cold MD, one walker per basin (parallel across GPUs)
    cold_dir = OUT / "cold_md"
    procs = []
    for sid, (basin, pdb) in enumerate([(0, START_PDB[0]), (1, START_PDB[1])]):
        dev = "0" if smoke else ["1", "2"][sid]
        cmd = ["python", "src/escort_ais/experiments/macrocycle/run_macrocycle_cold_md_seed.py", "--name", "rgd",
               "--seed-pdb", str(pdb), "--out-dir", str(cold_dir), "--sid", str(sid),
               "--prod-ps", str(int(cold_ns * 1000)), "--save-ps", "1.0",
               "--platform", "CUDA", "--device", dev]
        print("cold MD:", " ".join(cmd), file=sys.stderr)
        procs.append(subprocess.Popen(cmd, cwd=str(ROOT)))
    for p in procs:
        p.wait()

    # 4. analyze: reweight ddF per cold-time prefix
    seed_dcds = sorted(cold_dir.glob("seed_*/trajectory.dcd"))
    cold_all = [md.load_dcd(str(d), top=top) for d in seed_dcds]
    burn = int(round(cold_burn_ps / 1.0))
    results = {N: [] for N in ns_list}
    for t in checkpoints:
        stop = int(round(t * 1000))                                    # cold MD is 1 ps/frame
        pooled = [tr[burn:stop] for tr in cold_all if tr.n_frames > burn]
        if not pooled:
            continue
        cX = np.concatenate([featurize(tr, q) for tr in pooled])
        cTor = np.concatenate([np.degrees(md.compute_dihedrals(tr, q))[:, qi] for tr in pooled])
        for N in ns_list:
            ddf_tor, ddf_mic = reweight_ddF(fwd[N]["X"], fwd[N]["W"], cX, cTor, lo, hi)
            results[N].append(dict(cold_ns=float(t), n_cold_frames=int(len(cTor)),
                                   ddF=ddf_tor, ddF_micro=ddf_mic,
                                   rmse=abs(ddf_tor - ref), rmse_micro=abs(ddf_mic - ref)))
            print(f"  N={N} cold={t:.0f}ns ddF={ddf_tor:.3f} (rmse {abs(ddf_tor-ref):.3f})", file=sys.stderr)

    out = dict(name="rgd", reference_ddF=ref, switch_ps=switch_ps, hot_ns=hot.n_frames * 0.01,
               cold_ns=cold_ns, ns_list=ns_list, note="BAUS-N=BAIS-N for the 2-state population ddF; "
               "BAIS major<->minor kinetics unresolved with one walker/basin (no crossing).",
               results={str(N): results[N] for N in ns_list})
    (OUT / "coldtime_rmse.json").write_text(json.dumps(out, indent=2))
    make_figure(out)
    print("done", file=sys.stderr)


def make_figure(out):
    ref = out["reference_ddF"]
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    cols = {500: "#2c6fbb", 1000: "#b0361f", 10: "#2c6fbb", 20: "#b0361f"}
    for N in out["ns_list"]:
        r = out["results"][str(N)]
        if not r:
            continue
        t = [x["cold_ns"] for x in r]
        ax[0].plot(t, [x["ddF"] for x in r], "-o", c=cols.get(N, "k"), label=f"BAUS/BAIS-{N}")
        ax[1].plot(t, [x["rmse"] for x in r], "-o", c=cols.get(N, "k"), label=f"BAUS/BAIS-{N}")
    ax[0].axhline(ref, c="k", ls="--", lw=1.2, label=f"REMD ref {ref:.2f} kT")
    ax[0].set_xlabel("cold-MD time (ns)"); ax[0].set_ylabel("ΔΔF (kT)"); ax[0].set_title("ddF vs cold time")
    ax[0].legend(fontsize=8)
    ax[1].set_xlabel("cold-MD time (ns)"); ax[1].set_ylabel("RMSE to REMD (kT)")
    ax[1].set_title("ddF RMSE vs cold time (5 ps AIS, 60 ns hot)"); ax[1].legend(fontsize=8)
    fig.suptitle("cyclo-RGDfV — BAUS-N/BAIS-N ddF convergence vs cold-MD time (one walker per basin)", fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    (ROOT / "results/rgd").mkdir(parents=True, exist_ok=True)
    fig.savefig(ROOT / "results/rgd/fig_rgd_baus_bata_coldtime.png", dpi=170); plt.close(fig)
    print(f"  wrote results/rgd/fig_rgd_baus_bata_coldtime.png", file=sys.stderr)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    run(smoke=ap.parse_args().smoke)
