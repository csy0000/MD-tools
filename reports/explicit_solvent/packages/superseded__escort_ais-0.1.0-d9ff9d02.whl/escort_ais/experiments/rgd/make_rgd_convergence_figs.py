#!/usr/bin/env python3
"""make_rgd_convergence_figs.py — regenerate the RGD ddF-convergence report figure (Fig. 12).

Two panels, both with discrete error bars (no fill_between band):
  (a) REMD-FREE incremental AIS+BAR ddF vs accumulated hot-ensemble length (from the incremental
      driver's convergence.json; 95% BAR CI shown as error bars).
  (b) REMD cold-reference ddF vs cumulative REMD length [30, T] ns (from replica_00; 10-block SEM).

Usage:
  python -m escort_ais.experiments.rgd.make_rgd_convergence_figs
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.cyclosporin_torsion_basins import TICABasinModel  # noqa: E402

REPORT = ROOT / "results/rgd/report"
REF = 1.11


def _ddF(p):
    p = np.clip(p, 1e-3, 1 - 1e-3)
    return np.log((1 - p) / p)               # F_minor - F_major (minor higher F), in kT


def remd_ddF_convergence(burn_ns=30, step_ns=50, nblocks=10):
    top = str(ROOT / "data/rgd/topology/topology.pdb")
    tr = md.load_dcd(str(ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns/replica_00/trajectory.dcd"),
                     top=top)
    m = TICABasinModel.load(str(ROOT / "data/rgd/basins_tica/basin_model_backbone.pkl"))
    minor = (m.assign(tr) == 1).astype(float)
    fpn = len(minor) / 500.0                 # frames per ns
    total_ns = int(len(minor) / fpn)
    Ts, dd, err = [], [], []
    for T in range(step_ns, total_ns + 1, step_ns):
        if T <= burn_ns:
            continue
        w = minor[int(burn_ns * fpn):int(T * fpn)]
        Ts.append(T)
        dd.append(_ddF(w.mean()))
        L = len(w) // nblocks
        blk = np.array([_ddF(w[i * L:(i + 1) * L].mean()) for i in range(nblocks)])
        err.append(blk.std(ddof=1) / np.sqrt(nblocks))
    return np.array(Ts), np.array(dd), np.array(err)


def main():
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))

    # --- (a) REMD-free incremental AIS+BAR, error bars from the BAR 95% CI ---
    h = json.load(open(ROOT / "data/rgd/diagnostics/incremental/convergence.json"))["history"]
    x = np.array([e["hot_ns"] for e in h], float)
    y = np.array([e["ddF_bar"] for e in h], float)
    yerr = np.array([[e["ddF_bar"] - e["ci"][0] for e in h],
                     [e["ci"][1] - e["ddF_bar"] for e in h]])           # asymmetric 95% CI
    ax[0].errorbar(x, y, yerr=yerr, fmt="o-", color="C0", capsize=3, lw=1.6,
                   label=r"BAR $\Delta\Delta F$ (accumulated) $\pm$95% CI")
    ax[0].axhline(REF, ls=":", color="gray", label=f"REMD 500 ns reference ({REF})")
    ax[0].set_xlabel("hot-ensemble length (ns)  [+1 fwd & +1 rev AIS per ns]")
    ax[0].set_ylabel(r"$\Delta\Delta F$ minor (kT)")
    ax[0].set_title(r"(a) REMD-free incremental AIS+BAR $\Delta\Delta F$")
    ax[0].legend(fontsize=8)
    axk = ax[0].twiny(); axk.set_xlim(ax[0].get_xlim())
    ticks = np.arange(100, 501, 100)
    axk.set_xticks(ticks); axk.set_xticklabels([f"k={1000 + (t - 100)}" for t in ticks], fontsize=8)

    # --- (b) REMD cold reference, error bars = 10-block SEM ---
    Ts, dd, err = remd_ddF_convergence()
    ax[1].errorbar(Ts, dd, yerr=err, fmt="s-", color="k", capsize=3, lw=1.6,
                   label=r"REMD cold $s{=}1.0$ (cumulative 30$\to$T)")
    ax[1].axhline(REF, ls=":", color="gray", label=f"latest = {dd[-1]:.2f} kT")
    ax[1].set_xlabel("REMD length T (ns)")
    ax[1].set_ylabel(r"$\Delta\Delta F$ minor (kT)")
    ax[1].set_title(r"(b) REMD cold-reference $\Delta\Delta F$ convergence")
    ax[1].legend(fontsize=8)

    # --- shared x/y range on both panels for direct comparison ---
    xmin = min(x.min(), Ts.min()); xmax = max(x.max(), Ts.max())
    xpad = 0.03 * (xmax - xmin)
    XLIM = (xmin - xpad, xmax + xpad)
    ylo = min((y - yerr[0]).min(), (dd - err).min())
    yhi = max((y + yerr[1]).max(), (dd + err).max())
    ypad = 0.06 * (yhi - ylo)
    YLIM = (ylo - ypad, yhi + ypad)
    for a in ax:
        a.set_xlim(*XLIM); a.set_ylim(*YLIM)
    axk.set_xlim(*XLIM)                          # keep the k top-axis synced to the shared x-range

    fig.suptitle(r"$\Delta\Delta F$ convergence with error bars: REMD-free AIS+BAR (accumulated) vs REMD reference",
                 y=1.02)
    fig.tight_layout()
    out = REPORT / "fig_rgd_incremental.png"
    fig.savefig(out, dpi=130, bbox_inches="tight")
    print(f"wrote {out}")
    print(f"  (a) incremental final: ddF={y[-1]:.2f} (CI {h[-1]['ci'][0]:.2f},{h[-1]['ci'][1]:.2f})")
    print(f"  (b) REMD final: ddF={dd[-1]:.3f} +/- {err[-1]:.3f} at T={Ts[-1]} ns")


if __name__ == "__main__":
    main()
