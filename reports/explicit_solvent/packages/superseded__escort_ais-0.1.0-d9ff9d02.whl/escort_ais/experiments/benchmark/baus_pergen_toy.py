"""baus_pergen_toy.py — numeric per-generation coverage-BAUS on the 1-D toy (1x/3x/5x κ-retune), vs baselines.

Builds one `schema.result` per regime by running N_G coverage generations on `systems.toy1d.Toy1D` and, each
generation, recording the four benchmark panels:
  1. vM umbrella design (μ=x0, κ=k) from `coverage_windows.build_windows`/`update_windows`;
  2. per-generation confined sampling density (vM-restrained Langevin walkers, segmented by generation);
  3. H–m BAR overlap + edge information (`endpoint_bar._overlap_score`, `baus_estimator` edge info);
  4. reweighted C0(θ) from BOTH `bar_only_free_energies` and `solve_joint` + `reconstruct_weights`.
Baselines (single-walker, multi-walker, REMD s-ladder) and the analytic + long-cold-MD references are computed
for the convergence overlay. No OpenMM — pure numba/numpy, seconds per regime.
"""
from __future__ import annotations

import argparse

import numpy as np

from escort_ais.experiments.benchmark import schema
from escort_ais.methods import baus_estimator as be
from escort_ais.methods import coverage_windows as cw
from escort_ais.methods.endpoint_bar import _overlap_score
from escort_ais.systems.toy1d import Toy1D, wrap

# Canonical κ-retune regimes + AIS ladder (mirrors experiments/toy/demo_bais_protocol_convergence_toy.py:457-460;
# inlined to avoid that demo's heavy legacy import chain). 3x/5x sharpen the wells (higher barriers) while the
# analytic populations stay ~[0.25,0.42,0.33].
MID3X_KAPPA = np.array([70.0, 70.0, 30.0])
HARD5X_KAPPA = np.array([114.0, 114.0, 45.0])
AIS_LADDER = np.linspace(np.sqrt(0.01), 1.0, 10) ** 2                 # [0.01, ..., 1.0]; s_hot = ladder[0] = 0.01

REGIMES = {"1x": None, "3x": MID3X_KAPPA, "5x": HARD5X_KAPPA}
REMD_S = tuple((np.linspace(np.sqrt(0.01), 1.0, 4) ** 2)[::-1])       # [1.0, 0.49, 0.16, 0.01]
THETA_BINS = 72                                                       # C0(θ) / density histogram resolution


def _toy(regime):
    return Toy1D() if REGIMES[regime] is None else Toy1D(kappa=np.asarray(REGIMES[regime], float))


# ── confined vM-restrained walkers (persistent; per-generation frame segmentation) ────────────────
class ToyUmbrellaWalkers:
    """One vM-restrained Langevin walker-set per umbrella on U_cold+U_m; frames accumulate and are tagged by gen."""

    def __init__(self, toy, walkers=8, seed=0):
        self.toy = toy; self.W = int(walkers)
        self.noise = float(np.sqrt(2.0 * (toy.kT / toy.gamma) * toy.dt))
        self.rng = np.random.default_rng(seed)
        self.win = []                                                # list of dict(mu, kappa, theta(W,), frames)

    def add(self, window, seed_theta):
        th = wrap(np.full(self.W, float(seed_theta)) + self.rng.uniform(-0.1, 0.1, self.W))
        self.win.append(dict(mu=float(np.asarray(window["mu"]).ravel()[0]),
                             kappa=float(np.asarray(window["kappa"]).ravel()[0]),
                             theta=th, frames=[]))

    def advance(self, gen, steps, save_stride=5):
        for w in self.win:
            th, mu, kp = w["theta"], w["mu"], w["kappa"]
            saved = []
            for t in range(int(steps)):
                f = self.toy.dU(th, 1.0) + kp * np.sin(wrap(th - mu))     # dU_cold + dU_m (vM restraint)
                th = wrap(th - (f / self.toy.gamma) * self.toy.dt + self.noise * self.rng.standard_normal(self.W))
                if (t + 1) % save_stride == 0:
                    saved.append(th.copy())
            w["theta"] = th
            w["frames"].append((int(gen), wrap(np.concatenate(saved)) if saved else np.zeros(0)))

    def samples(self, m):
        fr = [a for _, a in self.win[m]["frames"] if len(a)]
        return np.concatenate(fr) if fr else np.zeros(0)

    def gen_samples(self, m, gen):
        for g, a in self.win[m]["frames"]:
            if g == gen:
                return a
        return np.zeros(0)


# ── baseline samplers (cumulative populations per generation) ─────────────────────────────────────
def _basin_pops(toy, boundaries, theta):
    lab = toy.basin_of(theta, boundaries)
    nb = max(len(boundaries), 1)
    p = np.array([float(np.sum(lab == k)) for k in range(nb)])
    return p / p.sum() if p.sum() > 0 else p


def _cold_md(toy, n_walkers, steps_per_gen, n_gen, rng, save_stride=10):
    """K cold Langevin walkers started in the major well A1; return cumulative frames after each gen."""
    x = wrap(np.full(int(n_walkers), toy.mu[0]))                      # start in A1 (μ[0]=60°): trapped baseline
    per_gen_frames, pool = [], []
    for _ in range(int(n_gen)):
        traj = toy.langevin(x, int(steps_per_gen), s=1.0, rng=rng, save_stride=save_stride)
        x = traj[-1] if len(traj) else x
        if len(traj):
            pool.append(wrap(traj.reshape(-1)))
        per_gen_frames.append(np.concatenate(pool) if pool else np.zeros(0))
    return per_gen_frames


def _remd(toy, s_ladder, steps_per_gen, n_gen, rng, exch_freq=50, save_stride=10):
    """REST2 replica-exchange on the s-ladder; return cumulative s=1-replica frames after each gen."""
    s = np.asarray(s_ladder, float); R = len(s)
    x = wrap(np.full(R, toy.mu[0]))
    noise = float(np.sqrt(2.0 * (toy.kT / toy.gamma) * toy.dt))
    per_gen, cold_pool = [], []
    for _ in range(int(n_gen)):
        cold = []
        for t in range(int(steps_per_gen)):
            f = np.array([toy.dU(x[i:i + 1], s[i])[0] for i in range(R)])
            x = wrap(x - (f / toy.gamma) * toy.dt + noise * rng.standard_normal(R))
            if (t + 1) % exch_freq == 0:
                for i in range(R - 1):
                    dE = (s[i] - s[i + 1]) * (toy.U_cold(x[i + 1:i + 2])[0] - toy.U_cold(x[i:i + 1])[0])
                    if rng.random() < np.exp(min(0.0, -dE)):
                        x[i], x[i + 1] = x[i + 1], x[i]
            if (t + 1) % save_stride == 0:
                cold.append(x[0])                                    # s_ladder[0] = 1.0 → cold replica
        if cold:
            cold_pool.append(np.array(cold))
        per_gen.append(np.concatenate(cold_pool) if cold_pool else np.zeros(0))
    return per_gen


# ── the toy coverage-BAUS run ─────────────────────────────────────────────────────────────────────
def run_toy_benchmark(regime, *, n_gen=10, n_ais=100, n_rev=100, walker_steps=1500, walkers=8,
                      ais_freq=8, seed=0, long_cold_frac=4, rcap=0.45, merge_ov=0.15):
    """Run N_G coverage generations on the toy `regime`; return a validated `schema.result` dict."""
    toy = _toy(regime)
    rng = np.random.default_rng(seed)
    pop = toy.populations()
    boundaries = np.radians(pop["boundaries_deg"])
    labels = [f"basin{k}" for k in range(pop["n_basins"])]
    theta_grid = np.linspace(-np.pi, np.pi, THETA_BINS, endpoint=False) + np.pi / THETA_BINS
    theta_edges = np.linspace(-np.pi, np.pi, THETA_BINS + 1)
    c0_analytic = np.exp(-toy.U_cold(theta_grid) / toy.kT); c0_analytic /= c0_analytic.sum()

    # ── baselines + long cold MD reference (cumulative per gen; matched ~budget) ──
    steps_pg = walker_steps * max(walkers, 1)                         # ~confined-walker dynamics budget / gen
    single = _cold_md(toy, 1, steps_pg, n_gen, np.random.default_rng(seed + 11))
    multi = _cold_md(toy, walkers, steps_pg, n_gen, np.random.default_rng(seed + 12))
    remd = _remd(toy, REMD_S, steps_pg // max(len(REMD_S), 1), n_gen, np.random.default_rng(seed + 13))
    long_cold = _cold_md(toy, walkers, steps_pg * long_cold_frac, 1, np.random.default_rng(seed + 14))[0]
    long_cold_pops = _basin_pops(toy, boundaries, long_cold)
    remd_final_pops = _basin_pops(toy, boundaries, remd[-1])

    reference = dict(labels=labels, analytic_pops=pop["pops"].tolist(),
                     basin_centers_deg=pop["well_centers_deg"].tolist(),
                     boundaries_deg=pop["boundaries_deg"].tolist(),
                     long_cold_md_pops=long_cold_pops.tolist(), remd_pops=remd_final_pops.tolist(),
                     c0=dict(theta_deg=np.degrees(theta_grid).tolist(), P=c0_analytic.tolist()))

    # ── coverage generations ──
    walkers_obj = ToyUmbrellaWalkers(toy, walkers=walkers, seed=seed + 1)
    wins = []
    land_all, Wf_all = [], []
    per_gen = []
    for g in range(1, n_gen + 1):
        # 1. hot forward AIS: equilibrium hot starts → anneal s_hot→1
        x_hot = toy.sample_boltzmann(toy.s_hot, n_ais, rng)
        land, logw = toy.ais_switch(x_hot, toy.s_hot, 1.0, len(AIS_LADDER) - 1, ais_freq, rng, schedule=AIS_LADDER)
        land_all.append(wrap(land)); Wf_all.append(-logw)
        land_cat = np.concatenate(land_all)[:, None]                 # (N,1) rad
        Wf = np.concatenate(Wf_all)
        fje_w = np.exp(-(Wf - Wf.max()))

        # 2. vM umbrella design (build once, then grow). Tighter rcap ⇒ one umbrella per sub-well (A1,A2 separate),
        #    so each confined walker equilibrates a single well and MBAR+hot edges recombine them (avoids a broad
        #    window straddling the A1↔A2 internal barrier).
        if not wins:
            wins, _ = cw.build_windows(land_cat, fje_w, rcap=rcap, merge_ov=merge_ov)
        else:
            wins, _added, _un = cw.update_windows(wins, land_cat, fje_w, rcap=rcap)
        while len(walkers_obj.win) < len(wins):                      # spin up walkers for new windows
            nw = wins[len(walkers_obj.win)]
            walkers_obj.add(nw, float(np.asarray(nw["mu"]).ravel()[0]))
        nb = len(wins)

        # 3. advance confined walkers this generation
        walkers_obj.advance(g, walker_steps)

        # 4. reverse AIS per window from equilibrium umbrella draws + matched hot-edge works
        edges, pooled, sample_window, Ncounts = [], [], [], []
        Um_land = [cw.bias_u(land_cat, wins[m]) for m in range(nb)]
        for m in range(nb):
            conf = walkers_obj.samples(m)
            Ncounts.append(len(conf))
            if len(conf):
                pooled.append(conf[:, None]); sample_window.append(np.full(len(conf), m))
            if len(conf) < 2:
                continue
            x0 = conf[rng.integers(0, len(conf), min(n_rev, len(conf)))]
            _, logw_r = toy.ais_switch(x0, 1.0, toy.s_hot, len(AIS_LADDER) - 1, ais_freq, rng,
                                       schedule=AIS_LADDER[::-1])
            Wfwd, Wrev = be.hot_edge_works(Wf, Um_land[m], -logw_r, cw.bias_u(x0[:, None], wins[m]))
            edges.append(be.HotEdge(window=m, Wfwd=Wfwd, Wrev=Wrev, n_fwd=len(Wf), n_rev=len(x0)))
        pooled = np.vstack(pooled) if pooled else np.zeros((0, 1))
        sample_window = np.concatenate(sample_window) if len(sample_window) else np.zeros(0, int)
        Ncounts = np.array(Ncounts, int)
        U = be.bias_matrix(pooled, wins) if len(pooled) else np.zeros((nb, 0))

        # 5. estimators: BAR-only + joint MSK → f → reconstruct C0(θ)
        bar = be.bar_only_free_energies(edges, n_windows=nb)
        joint = be.solve_joint(edges, U, sample_window, Ncounts, n_windows=nb)
        c0, pops = {}, {}
        for name, res in (("bar", bar), ("joint", joint)):
            if len(pooled):
                a = be.reconstruct_weights(U, res.f, Ncounts)
                P, _ = np.histogram(pooled[:, 0], bins=theta_edges, weights=a)
                s = P.sum(); P = (P / s) if s > 0 else P
                lab = toy.basin_of(pooled[:, 0], boundaries)
                pk = np.array([float(a[lab == k].sum()) for k in range(pop["n_basins"])])
                pk = pk / pk.sum() if pk.sum() > 0 else pk
            else:
                P = np.zeros(THETA_BINS); pk = np.full(pop["n_basins"], np.nan)
            c0[name] = P.tolist(); pops[name] = pk.tolist()

        # panels 1–3 payloads
        windows_rec = [dict(mu_deg=np.degrees(np.asarray(w["mu"]).ravel()).tolist(),
                            kappa=np.asarray(w["kappa"]).ravel().tolist()) for w in wins]
        per_win_hist = []
        for m in range(nb):
            gf = walkers_obj.gen_samples(m, g)
            h, _ = np.histogram(gf, bins=theta_edges) if len(gf) else (np.zeros(THETA_BINS), None)
            per_win_hist.append(h.tolist())
        edge_win = {e.window: e for e in edges}
        bar_ovl = [(_overlap_score(np.asarray(edge_win[m].Wfwd)[np.isfinite(edge_win[m].Wfwd)], edge_win[m].Wrev)
                    if m in edge_win else np.nan) for m in range(nb)]

        per_gen.append(schema.pergen_record(
            gen=g, n_land=int(len(Wf)), n_win=nb, windows=windows_rec,
            density=dict(theta_edges_deg=np.degrees(theta_edges).tolist(), per_window_hist=per_win_hist),
            overlap=dict(bar_overlap=[None if not np.isfinite(x) else float(x) for x in bar_ovl],
                         I_bar=bar.edge_information.tolist(), I_joint=joint.edge_information.tolist()),
            c0=dict(theta_deg=np.degrees(theta_grid).tolist(), bar=c0["bar"], joint=c0["joint"]),
            populations=dict(bar=pops["bar"], joint=pops["joint"], baselines=dict(
                single=_basin_pops(toy, boundaries, single[g - 1]).tolist(),
                multi=_basin_pops(toy, boundaries, multi[g - 1]).tolist(),
                remd=_basin_pops(toy, boundaries, remd[g - 1]).tolist()))))

    return schema.result(system=f"toy_{regime}", dim=1, regime=regime, reference=reference, per_gen=per_gen)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--regime", choices=list(REGIMES), default="1x")
    ap.add_argument("--n-gen", type=int, default=10)
    ap.add_argument("--n-ais", type=int, default=100)
    ap.add_argument("--n-rev", type=int, default=100)
    ap.add_argument("--walker-steps", type=int, default=1500)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--out", default=None)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    kw = dict(n_gen=args.n_gen, n_ais=args.n_ais, n_rev=args.n_rev, walker_steps=args.walker_steps, seed=args.seed)
    if args.smoke:
        kw.update(n_gen=2, n_ais=40, n_rev=40, walker_steps=400, walkers=6)
    res = run_toy_benchmark(args.regime, **kw)
    from escort_ais.common.paths import project_root
    out = args.out or project_root() / "reports" / "comparisons" / "baus_benchmark" / res["system"] / "pergen.json"
    schema.save(res, out)
    fin = res["per_gen"][-1]
    print(f"[{res['system']}] gens={len(res['per_gen'])} windows={fin['n_win']} "
          f"pops(bar)={np.round(fin['populations']['bar'],3).tolist()} "
          f"pops(joint)={np.round(fin['populations']['joint'],3).tolist()} "
          f"analytic={np.round(res['reference']['analytic_pops'],3).tolist()}")
    print(f"wrote {out}")
    return res


if __name__ == "__main__":
    main()
