"""Per-generation BAUS benchmark (3 toy regimes + alanine) vs baseline samplers.

Modules:
  schema            — the common per-generation JSON schema (save/load + validation).
  baus_pergen_toy   — numeric (numba Langevin) toy coverage-BAUS harness for the 1x/3x/5x κ-retune regimes.
  baus_pergen_alanine — alanine OpenMM coverage path (reuses the cached hot ensemble + committed references).
  plot_baus_pergen  — shared 4-panel plotter → one PDF per system.
  run_all           — orchestration (3 toys + alanine → pergen.json → PDFs).

Both producers report a common per-gen schema (dim=1 toy θ, dim=2 alanine φ,ψ) and estimate the cold C0 with
BOTH the hot-edge-only BAR (`baus_estimator.bar_only_free_energies`) and the joint MSK⊕MBAR
(`baus_estimator.solve_joint`).
"""
