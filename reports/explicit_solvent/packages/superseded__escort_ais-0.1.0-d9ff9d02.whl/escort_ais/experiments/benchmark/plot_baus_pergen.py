"""plot_baus_pergen.py — shared 4-panel plotter for the BAUS benchmark → one PDF per system.

Reads a `schema` result JSON (toy dim=1 or alanine dim=2) and renders the four per-generation panels:
  A  vM fitting + umbrella design (centres x0=μ, widths k=κ) and their per-generation growth;
  B  local (confined) sampling density per generation;
  C  H–m BAR overlap per generation (+ BAR vs joint edge information);
  D  reweighted C0 per generation (BAR + joint), overlaid with REMD + long cold MD (+ analytic) references,
     with a convergence inset (population error vs generation for BAUS-BAR/joint and the baseline samplers).
"""
from __future__ import annotations

import argparse

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from escort_ais.experiments.benchmark import schema

GEN_CMAP = "viridis"


def _tv(p, q):
    p = np.asarray(p, float); q = np.asarray(q, float)
    if p.shape != q.shape or not np.isfinite(p).all() or not np.isfinite(q).all():
        return np.nan
    return 0.5 * float(np.abs(p - q).sum())


def _gen_colors(n):
    return plt.get_cmap(GEN_CMAP)(np.linspace(0.15, 0.9, n))


# ── dim=1 (toy θ) ─────────────────────────────────────────────────────────────────────────────────
def _plot_toy(res, fig):
    pg = res["per_gen"]; ng = len(pg); ref = res["reference"]
    cols = _gen_colors(ng)
    th = np.array(pg[-1]["c0"]["theta_deg"])
    gs = GridSpec(4, 1, figure=fig, hspace=0.55)

    # A: final-gen vM umbrella designs (e^{-U_m}) + centres, and κ / n_win growth
    axA = fig.add_subplot(gs[0]); axk = axA.twinx()
    tt = np.radians(th)
    for w in pg[-1]["windows"]:
        mu = np.radians(w["mu_deg"][0]); k = w["kappa"][0]
        axA.plot(th, np.exp(-k * (1 - np.cos(tt - mu))), lw=1.6)
        axA.axvline(np.degrees(mu), color="gray", ls=":", lw=0.6)
        axA.annotate(f"$x_0$={w['mu_deg'][0]:.0f}°\n$k$={k:.0f}", (np.degrees(mu), 1.02),
                     fontsize=6.5, ha="center", va="bottom")
    axk.plot(range(1, ng + 1), [p["n_win"] for p in pg], "s-", color="crimson", ms=3, label="$n_{win}$")
    axk.set_ylabel("$n_{win}$", color="crimson", fontsize=8); axk.tick_params(labelsize=7, colors="crimson")
    axk.set_xlabel("")
    axA.set_title("A  vM umbrella design (final gen): $e^{-U_m}$, centre $x_0$, width $k$; "
                  "$n_{win}$ vs gen", fontsize=9, loc="left")
    axA.set_xlabel("θ (deg)", fontsize=8); axA.set_ylabel("$e^{-U_m}$", fontsize=8)
    axA.set_xlim(-180, 180); axA.tick_params(labelsize=7)

    # B: per-generation confined density (summed over windows), gen-coloured
    axB = fig.add_subplot(gs[1])
    for gi, p in enumerate(pg):
        edges = np.array(p["density"]["theta_edges_deg"]); ctr = 0.5 * (edges[:-1] + edges[1:])
        tot = np.sum(np.array(p["density"]["per_window_hist"]), axis=0).astype(float)
        if tot.sum() > 0:
            tot = tot / tot.sum()
        axB.plot(ctr, tot, color=cols[gi], lw=1.1)
    axB.set_title("B  confined sampling density per generation (gen-coloured, dark→light)", fontsize=9, loc="left")
    axB.set_xlabel("θ (deg)", fontsize=8); axB.set_ylabel("density", fontsize=8)
    axB.set_xlim(-180, 180); axB.tick_params(labelsize=7)

    # C: H–m BAR overlap heatmap (gen × window)
    axC = fig.add_subplot(gs[2])
    nwin = max(p["n_win"] for p in pg)
    ov = np.full((ng, nwin), np.nan)
    for gi, p in enumerate(pg):
        for m, v in enumerate(p["overlap"]["bar_overlap"]):
            ov[gi, m] = np.nan if v is None else v
    im = axC.imshow(ov, aspect="auto", origin="lower", cmap="magma", vmin=0, vmax=np.nanmax(ov) if np.isfinite(ov).any() else 1,
                    extent=[-0.5, nwin - 0.5, 0.5, ng + 0.5])
    fig.colorbar(im, ax=axC, fraction=0.03, pad=0.02).set_label("H–m BAR overlap", fontsize=7)
    axC.set_title("C  H–m BAR overlap per generation (window × gen)", fontsize=9, loc="left")
    axC.set_xlabel("window m", fontsize=8); axC.set_ylabel("generation", fontsize=8); axC.tick_params(labelsize=7)

    # D: reweighted C0(θ) per gen (joint solid, bar dashed) + references + convergence inset
    axD = fig.add_subplot(gs[3])
    for gi, p in enumerate(pg):
        axD.plot(th, p["c0"]["joint"], color=cols[gi], lw=1.0)
    axD.plot(th, pg[-1]["c0"]["bar"], color="tab:red", lw=1.2, ls="--", label="BAUS-BAR (final)")
    axD.plot(ref["c0"]["theta_deg"], ref["c0"]["P"], color="k", lw=2.0, label="analytic C0")
    axD.set_title("D  reweighted $C_0(θ)$ per gen (joint, gen-coloured; BAR dashed) vs analytic", fontsize=9, loc="left")
    axD.set_xlabel("θ (deg)", fontsize=8); axD.set_ylabel("$C_0(θ)$", fontsize=8)
    axD.set_xlim(-180, 180); axD.tick_params(labelsize=7); axD.legend(fontsize=6, loc="upper left")

    # convergence inset: TV(pops, analytic) vs gen for all methods
    ins = axD.inset_axes([0.62, 0.45, 0.36, 0.5])
    ana = ref["analytic_pops"]; x = range(1, ng + 1)
    series = {"BAUS-BAR": ("bar", "tab:red"), "BAUS-joint": ("joint", "tab:blue")}
    for lab, (key, c) in series.items():
        ins.plot(x, [_tv(p["populations"][key], ana) for p in pg], "o-", color=c, ms=2.5, lw=1, label=lab)
    for lab, c in (("single", "tab:green"), ("multi", "tab:orange"), ("remd", "tab:purple")):
        ins.plot(x, [_tv(p["populations"]["baselines"][lab], ana) for p in pg], "^-", color=c, ms=2, lw=0.8, label=lab)
    ins.set_title("TV to analytic vs gen", fontsize=6.5); ins.tick_params(labelsize=6)
    ins.set_xlabel("gen", fontsize=6); ins.legend(fontsize=5, ncol=1, loc="upper right")


# ── dim=2 (alanine φ,ψ) ─────────────────────────────────────────────────────────────────────────
def _scatter_c0(ax, c0, title):
    phi = np.array(c0.get("phi_deg", [])); psi = np.array(c0.get("psi_deg", [])); pop = np.array(c0.get("population", []))
    if len(phi):
        sc = ax.scatter(phi, psi, s=8 + 400 * pop / (pop.max() + 1e-12), c=pop, cmap="viridis",
                        edgecolor="k", linewidth=0.2)
    ax.axvline(0, ls=":", color="gray", lw=0.6)
    ax.set_xlim(-180, 180); ax.set_ylim(-180, 180); ax.set_title(title, fontsize=7)
    ax.set_xlabel("φ", fontsize=7); ax.set_ylabel("ψ", fontsize=7); ax.tick_params(labelsize=6)


def _plot_alanine(res, fig):
    pg = res["per_gen"]; ng = len(pg); ref = res["reference"]
    gs = GridSpec(4, 1, figure=fig, hspace=0.5)

    # A: final-gen umbrella centres (φ,ψ) sized by κ, LABELLED by index; φ>0 (αL) highlighted
    axA = fig.add_subplot(gs[0])
    for m, w in enumerate(pg[-1]["windows"]):
        phi, psi = w["mu_deg"][0], w["mu_deg"][1]
        aL = phi > 0.0
        axA.scatter(phi, psi, s=40 + 3 * np.mean(w["kappa"]), marker="*",
                    color=("tab:red" if aL else "tab:blue"), edgecolor="k", linewidth=0.4, zorder=3)
        axA.annotate(f"{m}", (phi, psi), xytext=(6, 6), textcoords="offset points",
                     fontsize=9, fontweight="bold", color=("tab:red" if aL else "black"), zorder=4)
    axA.axvline(0, ls=":", color="gray", lw=0.6); axA.set_xlim(-180, 180); axA.set_ylim(-180, 180)
    axA.set_title(f"A  vM umbrella centres, labelled by index m (★ size ∝ κ; red = φ>0 αL); "
                  f"n_win {pg[0]['n_win']}→{pg[-1]['n_win']}", fontsize=9, loc="left")
    axA.set_xlabel("φ", fontsize=8); axA.set_ylabel("ψ", fontsize=8); axA.tick_params(labelsize=7)

    # B: BAR overlap heatmap (reuse the toy logic)
    axB = fig.add_subplot(gs[1])
    nwin = max(p["n_win"] for p in pg); ov = np.full((ng, nwin), np.nan)
    for gi, p in enumerate(pg):
        for m, v in enumerate(p["overlap"]["bar_overlap"]):
            ov[gi, m] = np.nan if v is None else v
    im = axB.imshow(ov, aspect="auto", origin="lower", cmap="magma", extent=[-0.5, nwin - 0.5, 0.5, ng + 0.5])
    fig.colorbar(im, ax=axB, fraction=0.03, pad=0.02).set_label("H–m BAR overlap", fontsize=7)
    axB.set_title("B  H–m BAR overlap per generation", fontsize=9, loc="left")
    axB.set_xlabel("window m", fontsize=8); axB.set_ylabel("generation", fontsize=8); axB.tick_params(labelsize=7)

    # C: C0 map small-multiples across a few generations (joint)
    axC = fig.add_subplot(gs[2]); axC.axis("off")
    axC.set_title("C  reweighted $C_0$ (φ,ψ) — early / mid / final generation (joint)", fontsize=9, loc="left")
    picks = sorted(set([0, ng // 2, ng - 1]))
    for j, gi in enumerate(picks):
        sub = axC.inset_axes([j / len(picks), 0.0, 0.9 / len(picks), 0.9])
        _scatter_c0(sub, pg[gi]["c0"]["joint"], f"gen {pg[gi]['gen']}")

    # D: αL population vs gen for BAUS(bar/joint) + REMD + cold-MD reference lines
    axD = fig.add_subplot(gs[3])
    al = ref.get("alpha_L_index", 0)
    x = range(1, ng + 1)
    axD.plot(x, [p["populations"]["bar"][al] for p in pg], "o-", color="tab:red", label="BAUS-BAR αL")
    axD.plot(x, [p["populations"]["joint"][al] for p in pg], "s-", color="tab:blue", label="BAUS-joint αL")
    if ref["remd_pops"]:
        axD.axhline(ref["remd_pops"][al], color="tab:purple", ls="--", lw=1.2, label="REMD αL")
    if ref["long_cold_md_pops"]:
        axD.axhline(ref["long_cold_md_pops"][al], color="k", ls="-", lw=1.5, label="1µs cold-MD αL")
    axD.set_title("D  αL population vs generation (BAUS-BAR/joint) vs REMD + long cold MD", fontsize=9, loc="left")
    axD.set_xlabel("generation", fontsize=8); axD.set_ylabel("αL population", fontsize=8)
    axD.tick_params(labelsize=7); axD.legend(fontsize=6)


def render(res, out_pdf):
    fig = plt.figure(figsize=(9.0, 12.5))
    (_plot_toy if res["dim"] == 1 else _plot_alanine)(res, fig)
    fig.suptitle(f"BAUS per-generation benchmark — {res['system']}  (regime {res['regime']}, "
                 f"N_G={len(res['per_gen'])})", fontsize=11, y=0.995)
    from pathlib import Path
    Path(out_pdf).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_pdf, bbox_inches="tight")
    plt.close(fig)
    return out_pdf


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--pergen", required=True, help="path to a schema pergen.json")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    res = schema.load(args.pergen)
    from pathlib import Path
    out = args.out or str(Path(args.pergen).parent / f"{res['system']}.pdf")
    render(res, out)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
