"""baus_pergen_alanine.py — post-process a finished alanine coverage-BAUS run into the benchmark schema (dim=2).

Reuses the SAME cached hot ensemble the coverage driver already consumed (nothing re-run here) and the committed
references — the 1 µs cold-MD `reference.json` and the s=1 REMD replica — with NO fresh baseline runs. Reconstructs
the reweighted C0 (φ,ψ) per main generation with BOTH the hot-edge-only BAR (`bar_only_free_energies`) and the
joint MSK⊕MBAR (`solve_joint`), from the per-generation artifacts already on disk (windows are grown-not-rebuilt,
so `land_ang[:n_land_g]` + `reverse/umb_XX/seed_g{≤gcur}` give the through-gen state; final κ is stable).

αL is the region φ>0 (the isolated node); populations are reported as [bulk(φ<0), αL(φ>0)].
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.experiments.benchmark import schema
from escort_ais.methods import baus_estimator as be
from escort_ais.methods.coverage_windows import bias_u

REF_JSON = "results/alanine_dipeptide/reference_cold_1us_mbondi3/reference.json"
REMD_DIR = "data/alanine_dipeptide/md/ff19sb_gbn2_mbondi3_6rep_300K_remd_100ns"
LABELS = ["bulk(phi<0)", "alphaL(phi>0)"]
MAP_BINS = 48


def _phipsi(dcd, top, quart):
    import mdtraj as md
    return md.compute_dihedrals(md.load_dcd(dcd, top=top), quart)    # (F, 2) rad


def _quartets(top_pdb):
    import mdtraj as md
    t = md.load(top_pdb)
    return np.array([md.compute_phi(t)[0][0], md.compute_psi(t)[0][0]], int)


def _region_pops(phi_rad):
    """[bulk, αL] populations from a φ array (fraction with φ>0)."""
    al = float(np.mean(np.asarray(phi_rad) > 0.0)) if len(phi_rad) else np.nan
    return [1.0 - al, al]


def _binned_map(phi_deg, psi_deg, weights, bins=MAP_BINS):
    edges = np.linspace(-180.0, 180.0, bins + 1)
    mass, pe, se = np.histogram2d(phi_deg, psi_deg, bins=(edges, edges), weights=weights)
    ctr_p, ctr_s = 0.5 * (pe[:-1] + pe[1:]), 0.5 * (se[:-1] + se[1:])
    P, S = np.meshgrid(ctr_p, ctr_s, indexing="ij")
    keep = mass > 0
    return dict(phi_deg=P[keep].tolist(), psi_deg=S[keep].tolist(), population=mass[keep].tolist())


# ── references (reused; nothing re-run) ───────────────────────────────────────────────────────────
def load_references(top_pdb, remd_dir=None):
    root = project_root()
    ref = json.load(open(root / REF_JSON))
    # cold-MD αL: macrostate populations_pi = [bulk, αL]
    macro = ref.get("macrostates", {}).get("populations_pi")
    cold = [float(macro[0]), float(macro[1])] if macro and len(macro) == 2 else \
        _region_pops(np.radians(np.array(ref["basin_centers_phi_psi_deg"])[:, 0]))   # fallback
    # reference C0 nodes = cold basin centres weighted by populations
    cen = np.array(ref["basin_centers_phi_psi_deg"], float)
    pops = np.array(ref["basin_populations_pi"], float)
    c0_ref = dict(phi_deg=cen[:, 0].tolist(), psi_deg=cen[:, 1].tolist(), population=pops.tolist())
    # REMD αL from the s=1 replica (replica_00)
    remd = [np.nan, np.nan]
    rdir = Path(remd_dir or (root / REMD_DIR))
    dcd = rdir / "replica_00" / "trajectory.dcd"
    if dcd.exists():
        try:
            phi = _phipsi(str(dcd), str(top_pdb), _quartets(str(top_pdb)))[:, 0]
            remd = _region_pops(phi)
        except Exception as e:                                        # pragma: no cover
            print(f"[ala-bench] REMD αL skipped ({type(e).__name__}: {e})")
    return dict(labels=LABELS, analytic_pops=None, long_cold_md_pops=cold, remd_pops=remd,
                alpha_L_index=1, c0=c0_ref)


# ── per-generation reconstruction from on-disk artifacts ─────────────────────────────────────────
def _load_through_gen(D, mu, kappa, n_win_g, land_g, Wf_g, max_gcur, quart, top_by_umb):
    """Confined samples + reverse (Wann,start) for windows [0,n_win_g) using reverse seeds with gcur ≤ max_gcur."""
    import pandas as pd
    conf, Wann, start = [], [], []
    for m in range(n_win_g):
        cm, wa, sa = [], [], []
        for sdir in sorted(glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*")):
            gcur = int(os.path.basename(sdir).replace("seed_g", ""))
            if gcur > max_gcur:
                continue
            top = top_by_umb[m]
            cm.append(_phipsi(f"{sdir}/trajectory.dcd", top, quart))
            summ = f"{D}/reverse/umb_{m:02d}/g{gcur:04d}/ais_trajectory_summary.csv"
            if os.path.exists(summ):
                s = pd.read_csv(summ)
                sang = _phipsi(f"{sdir}/trajectory.dcd", top, quart)
                for j, fi in zip(-s["final_logw"].to_numpy(), s["initial_frame_index"].to_numpy().astype(int)):
                    wa.append(j); sa.append(sang[min(max(int(fi), 0), len(sang) - 1)])
        conf.append(np.concatenate(cm) if cm else np.zeros((0, 2)))
        Wann.append(np.asarray(wa)); start.append(np.asarray(sa) if sa else np.zeros((0, 2)))
    return conf, Wann, start


def build_from_run(run_dir=None):
    """Assemble a schema.result (dim=2) from a finished alanine coverage run directory."""
    root = project_root()
    D = Path(run_dir or (root / "data/alanine_dipeptide/bais_standalone/coverage"))
    z = np.load(D / "coverage_windows.npz")
    mu, kappa, Wf, land_ang = z["mu"], z["kappa"], z["Wf"], z["land_ang"]
    pergen_meta = json.load(open(D / "cov_gen_pergen.json"))["per_gen"]
    mains = [p for p in pergen_meta if p.get("phase") == "main"]
    top_pdb = glob.glob(str(D / "reverse/umb_00/seed_g*/start_structure.pdb"))[0]
    quart = _quartets(top_pdb)
    top_by_umb = {m: glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*/start_structure.pdb")[0]
                  for m in range(len(mu)) if glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*/start_structure.pdb")}
    reference = load_references(top_pdb)

    per_gen = []
    for p in mains:
        gcur = int(p["gen"]); gi = int(p.get("gi", len(per_gen) + 1))
        n_win_g = int(p["n_win"]); n_land_g = int(p["n_land"])
        wins = [{"mu": np.asarray(mu[m], float), "kappa": np.asarray(kappa[m], float)} for m in range(n_win_g)]
        land_g = land_ang[:n_land_g]; Wf_g = Wf[:n_land_g]; Nf = len(Wf_g)
        conf, Wann, start = _load_through_gen(D, mu, kappa, n_win_g, land_g, Wf_g, gcur, quart, top_by_umb)

        pooled, sw, edges = [], [], []
        for m in range(n_win_g):
            if len(conf[m]):
                pooled.append(conf[m]); sw.append(np.full(len(conf[m]), m))
            if len(Wann[m]) == 0 or len(start[m]) == 0:
                continue
            Um_land = bias_u(land_g, wins[m]); Um_start = bias_u(start[m], wins[m])
            Wfwd, Wrev = be.hot_edge_works(Wf_g, Um_land, Wann[m], Um_start)
            edges.append(be.HotEdge(window=m, Wfwd=Wfwd, Wrev=Wrev, n_fwd=Nf, n_rev=len(Wann[m])))
        pooled = np.vstack(pooled) if pooled else np.zeros((0, 2))
        sw = np.concatenate(sw) if len(sw) else np.zeros(0, int)
        N = np.array([len(c) for c in conf], int)
        U = be.bias_matrix(pooled, wins) if len(pooled) else np.zeros((n_win_g, 0))

        bar = be.bar_only_free_energies(edges, n_windows=n_win_g)
        joint = be.solve_joint(edges, U if len(pooled) else None, sw if len(pooled) else None,
                               N if len(pooled) else None, n_windows=n_win_g)
        c0, pops = {}, {}
        for name, res in (("bar", bar), ("joint", joint)):
            if len(pooled):
                a = be.reconstruct_weights(U, res.f, N)
                c0[name] = _binned_map(np.degrees(pooled[:, 0]), np.degrees(pooled[:, 1]), a)
                al = float(a[pooled[:, 0] > 0.0].sum())              # αL = reweighted mass with φ>0
                pops[name] = [1.0 - al, al]
            else:
                c0[name] = dict(phi_deg=[], psi_deg=[], population=[]); pops[name] = [np.nan, np.nan]

        # panel-2 density: this-gen confined seed frames per window (seed_g{gcur})
        per_win_hist = []
        for m in range(n_win_g):
            dcds = glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g{gcur:04d}/trajectory.dcd")
            if dcds:
                ang = _phipsi(dcds[0], top_by_umb.get(m, top_pdb), quart)
                per_win_hist.append(dict(phi_deg=np.degrees(ang[:, 0]).tolist(),
                                         psi_deg=np.degrees(ang[:, 1]).tolist()))
            else:
                per_win_hist.append(dict(phi_deg=[], psi_deg=[]))

        edge_win = {e.window: e for e in edges}
        from escort_ais.methods.endpoint_bar import _overlap_score
        bar_ovl = [(_overlap_score(np.asarray(edge_win[m].Wfwd)[np.isfinite(edge_win[m].Wfwd)], edge_win[m].Wrev)
                    if m in edge_win else np.nan) for m in range(n_win_g)]

        per_gen.append(schema.pergen_record(
            gen=gi, n_land=n_land_g, n_win=n_win_g,
            windows=[dict(mu_deg=np.degrees(np.asarray(w["mu"])).tolist(),
                          kappa=np.asarray(w["kappa"]).tolist()) for w in wins],
            density=dict(per_window=per_win_hist),
            overlap=dict(bar_overlap=[None if not np.isfinite(x) else float(x) for x in bar_ovl],
                         I_bar=bar.edge_information.tolist(), I_joint=joint.edge_information.tolist()),
            c0=dict(bar=c0["bar"], joint=c0["joint"]),
            populations=dict(bar=pops["bar"], joint=pops["joint"],
                             baselines=dict(single=[np.nan, np.nan], multi=[np.nan, np.nan],
                                            remd=reference["remd_pops"]))))
    return schema.result(system="alanine", dim=2, regime="-", reference=reference, per_gen=per_gen)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    res = build_from_run(args.run_dir)
    out = args.out or project_root() / "reports" / "comparisons" / "baus_benchmark" / "alanine" / "pergen.json"
    schema.save(res, out)
    fin = res["per_gen"][-1]["populations"] if res["per_gen"] else {}
    print(f"[alanine] gens={len(res['per_gen'])} αL(bar)={fin.get('bar',[None,None])[1]} "
          f"αL(joint)={fin.get('joint',[None,None])[1]} cold-ref={res['reference']['long_cold_md_pops'][1]:.4f} "
          f"REMD={res['reference']['remd_pops'][1]}")
    print(f"wrote {out}")
    return res


if __name__ == "__main__":
    main()
