"""correlation_tica.py — correlation-time + TICA-timescale analysis of the hot ensemble and each BAUS umbrella.

For the reused hot MD ensemble and for every coverage umbrella's confined-walker time series, computes:
  * the integrated autocorrelation time τ_int of the slowest collective coordinate (TICA-1 projection) — how many
    frames (and ps) between statistically independent samples (the equilibrium-MBAR N_m should count decorrelated
    configs); and
  * the slowest TICA relaxation timescale t2 (the leading finite implied timescale from time-lagged features).

Hot ensemble: the cached REST2 hot trajectory (fast, flat → short τ/t2). Each window: the contiguous confined
walker torsion series dumped by run_bais_standalone (`window_walker_angles.npz`, one frame / save_ps).

Run:  python -m escort_ais.experiments.benchmark.correlation_tica \
          --run-dir data/alanine_dipeptide/bais_standalone/coverage
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root

HOT_DCD = "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns/trajectory.dcd"
HOT_PDB = "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns/start_structure.pdb"
HOT_PS_PER_FRAME = 2.0


def _feats(angles_rad):
    """(T, d) torsions → (T, 2d) (cos, sin) features (the smooth periodic TICA basis)."""
    a = np.atleast_2d(np.asarray(angles_rad, float))
    return np.column_stack([np.cos(a), np.sin(a)])


def tica(X, lag):
    """Return (implied_timescales_in_lags, first_eigenvector). Solves C(τ)v = λ C(0)v on mean-removed features."""
    from scipy.linalg import eigh
    X = np.asarray(X, float)
    X = X - X.mean(0)
    n = len(X)
    if n <= lag + 2:
        return np.array([np.nan]), None
    C0 = (X.T @ X) / n
    C0 += 1e-8 * np.eye(C0.shape[0])                               # regularize (constant/degenerate features)
    Xt, Xl = X[:-lag], X[lag:]
    Ct = (Xt.T @ Xl) / len(Xt)
    Ct = 0.5 * (Ct + Ct.T)                                         # symmetrize (reversible estimate)
    lam, vec = eigh(Ct, C0)
    order = np.argsort(np.abs(lam))[::-1]
    lam = np.clip(np.abs(lam[order]), 1e-9, 1 - 1e-9)
    ts = -lag / np.log(lam)                                        # implied timescales in units of lag frames
    return ts, vec[:, order[0]]


def integrated_autocorr_time(a):
    """τ_int (frames) of a 1-D series via pymbar statistical inefficiency g = 1 + 2τ_int."""
    a = np.asarray(a, float)
    if len(a) < 8 or np.allclose(a, a[0]):
        return np.nan
    try:
        from pymbar import timeseries
        g = getattr(timeseries, "statistical_inefficiency", getattr(timeseries, "statisticalInefficiency"))(a)
        return max(0.0, (float(g) - 1.0) / 2.0)
    except Exception:                                             # simple normalized-ACF fallback
        x = a - a.mean(); v = np.dot(x, x)
        if v == 0:
            return np.nan
        tau = 0.0
        for k in range(1, min(len(a) // 2, 2000)):
            c = np.dot(x[:-k], x[k:]) / v
            if c <= 0:
                break
            tau += c
        return tau


def _analyze_series(angles_rad, dt_ps, lag_frames):
    """τ_int (frames, ps) of the TICA-1 projection + slowest TICA relaxation timescale t2 (frames, ps)."""
    a = np.atleast_2d(np.asarray(angles_rad, float))
    if a.shape[0] < lag_frames + 4:
        return dict(n_frames=int(a.shape[0]), tau_int_frames=np.nan, tau_int_ps=np.nan,
                    tica_t2_frames=np.nan, tica_t2_ps=np.nan)
    X = _feats(a)
    ts, v1 = tica(X, lag_frames)
    proj = (X - X.mean(0)) @ v1 if v1 is not None else a[:, 0]     # slowest collective coordinate
    tau = integrated_autocorr_time(proj)
    t2 = float(ts[0]) if np.isfinite(ts[0]) else np.nan            # slowest finite TICA relaxation
    return dict(n_frames=int(a.shape[0]),
                tau_int_frames=float(tau) if np.isfinite(tau) else np.nan,
                tau_int_ps=float(tau * dt_ps) if np.isfinite(tau) else np.nan,
                tica_t2_frames=t2, tica_t2_ps=float(t2 * dt_ps) if np.isfinite(t2) else np.nan)


def analyze(run_dir, hot_dcd=None, hot_pdb=None, hot_lag=10, win_lag=3, hot_stride=5):
    import mdtraj as md
    root = project_root()
    hot_dcd = str(hot_dcd or root / HOT_DCD); hot_pdb = str(hot_pdb or root / HOT_PDB)
    # hot ensemble
    ht = md.load_dcd(hot_dcd, top=hot_pdb)[::hot_stride]
    quart = np.array([md.compute_phi(md.load(hot_pdb))[0][0], md.compute_psi(md.load(hot_pdb))[0][0]], int)
    hot_ang = md.compute_dihedrals(ht, quart)
    hot = _analyze_series(hot_ang, HOT_PS_PER_FRAME * hot_stride, hot_lag)
    hot["label"] = "hot(s=0.25)"

    # per-window confined walkers
    z = np.load(Path(run_dir) / "window_walker_angles.npz")
    dt_win = float(z["save_ps"]); cen = z["centres_deg"] if "centres_deg" in z else None
    wins = []
    for k in sorted(n for n in z.files if n.startswith("umb_")):
        r = _analyze_series(z[k], dt_win, win_lag)
        m = int(k.split("_")[1])
        r["label"] = f"{k} ({cen[m,0]:+.0f},{cen[m,1]:+.0f})" if cen is not None and m < len(cen) else k
        wins.append(r)
    return dict(hot=hot, windows=wins, hot_ps_per_frame=HOT_PS_PER_FRAME * hot_stride, win_ps_per_frame=dt_win)


def _plot(res, out_pdf):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    wins = res["windows"]; labels = [w["label"] for w in wins]
    tau = [w["tau_int_ps"] for w in wins]; t2 = [w["tica_t2_ps"] for w in wins]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5))
    x = np.arange(len(wins))
    a1.bar(x, tau, color="tab:blue"); a1.axhline(res["hot"]["tau_int_ps"], color="k", ls="--", label="hot")
    a1.set_title("Integrated autocorrelation time τ_int (ps)"); a1.set_ylabel("ps")
    a2.bar(x, t2, color="tab:green"); a2.axhline(res["hot"]["tica_t2_ps"], color="k", ls="--", label="hot")
    a2.set_title("Slowest TICA relaxation timescale t2 (ps)"); a2.set_ylabel("ps")
    for ax in (a1, a2):
        ax.set_xticks(x); ax.set_xticklabels(labels, rotation=60, ha="right", fontsize=7); ax.legend(fontsize=8)
    fig.suptitle("BAUS correlation-time + TICA-t2: hot ensemble (dashed) vs each umbrella", fontsize=12)
    fig.tight_layout(); Path(out_pdf).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_pdf, bbox_inches="tight"); plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--hot-lag", type=int, default=10)
    ap.add_argument("--win-lag", type=int, default=3)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    res = analyze(args.run_dir, hot_lag=args.hot_lag, win_lag=args.win_lag)
    out = Path(args.out or (project_root() / "reports/comparisons/baus_benchmark/alanine/correlation_tica"))
    json.dump(res, open(str(out) + ".json", "w"), indent=1)
    _plot(res, str(out) + ".pdf")
    h = res["hot"]
    print(f"HOT {h['label']:16} n={h['n_frames']:6d}  τ_int={h['tau_int_ps']:7.1f} ps  "
          f"TICA t2={h['tica_t2_ps']:7.1f} ps")
    for w in res["windows"]:
        print(f"    {w['label']:20} n={w['n_frames']:5d}  τ_int={w['tau_int_ps']:7.1f} ps  "
              f"TICA t2={w['tica_t2_ps']:7.1f} ps")
    print(f"\nwrote {out}.json / {out}.pdf")
    return res


if __name__ == "__main__":
    main()
