"""Common per-generation schema for the BAUS benchmark, shared by the toy and alanine producers + the plotter.

A benchmark result is one JSON per system:

    {
      "system": "toy_3x" | "alanine",
      "dim": 1 | 2,                      # 1 = toy angle θ; 2 = alanine (φ,ψ)
      "regime": "1x" | "3x" | "5x" | "-",
      "estimators": ["bar", "joint"],
      "reference": {                     # ground-truth / reference C0 + populations (static overlays)
         "labels": [...],                # basin/region labels the populations index
         "analytic_pops": [...] | null,  # toy analytic ground truth (null for alanine)
         "long_cold_md_pops": [...],     # long single-walker cold MD populations
         "remd_pops": [...],             # REMD (s=1 replica) populations
         "c0": {...}                     # dim-specific reference C0 (grid P(θ) for toy; binned map for alanine)
      },
      "per_gen": [ <PerGen>, ... ]       # length N_G
    }

Each <PerGen> (see `pergen_record`):

    {
      "gen": g,                          # 1-based main-generation index
      "n_land": int, "n_win": int,
      "windows": [{"mu_deg": [...], "kappa": [...]}, ...],          # panel 1: vM design (x0=μ, k=κ)
      "density": {...},                  # panel 2: this-gen confined sampling density (per window)
      "overlap": {"bar_overlap": [...], "I_bar": [...], "I_joint": [...]},   # panel 3: H–m BAR overlap + edge info
      "c0": {"bar": {...}, "joint": {...}},                        # panel 4: reweighted C0 (dim-specific)
      "populations": {                   # region populations per estimator + baselines (convergence inset)
         "bar": [...], "joint": [...],
         "baselines": {"single": [...], "multi": [...], "remd": [...]}
      }
    }

Populations are indexed by `reference["labels"]`. dim-1 C0 payload = {"theta_deg": grid, "P": density};
dim-2 C0 payload = {"phi_deg": [...], "psi_deg": [...], "population": [...]} (binned nodes, as written by
`analysis.coverage_c0_mbar._write_reconstruction_tables`).
"""
from __future__ import annotations

import json
from pathlib import Path


def pergen_record(gen, windows, density, overlap, c0, populations, n_land, n_win):
    """Assemble one per-generation record (all fields JSON-serializable)."""
    return {
        "gen": int(gen), "n_land": int(n_land), "n_win": int(n_win),
        "windows": windows, "density": density, "overlap": overlap, "c0": c0,
        "populations": populations,
    }


def result(system, dim, regime, reference, per_gen, estimators=("bar", "joint")):
    return {"system": system, "dim": int(dim), "regime": regime,
            "estimators": list(estimators), "reference": reference, "per_gen": per_gen}


REQUIRED_TOP = {"system", "dim", "regime", "estimators", "reference", "per_gen"}
REQUIRED_GEN = {"gen", "n_land", "n_win", "windows", "density", "overlap", "c0", "populations"}


def validate(res):
    """Cheap structural check; raises AssertionError on a malformed result. Returns the result."""
    assert REQUIRED_TOP <= set(res), f"missing top-level keys: {REQUIRED_TOP - set(res)}"
    assert res["dim"] in (1, 2)
    ref = res["reference"]
    assert "labels" in ref and "remd_pops" in ref and "long_cold_md_pops" in ref and "c0" in ref
    assert isinstance(res["per_gen"], list) and res["per_gen"], "per_gen must be a non-empty list"
    for pg in res["per_gen"]:
        assert REQUIRED_GEN <= set(pg), f"gen {pg.get('gen')} missing {REQUIRED_GEN - set(pg)}"
        assert set(pg["overlap"]) >= {"bar_overlap", "I_bar", "I_joint"}
        assert set(pg["c0"]) >= {"bar", "joint"}
        assert set(pg["populations"]) >= {"bar", "joint", "baselines"}
    return res


def save(res, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    json.dump(validate(res), open(path, "w"), indent=1)
    return path


def load(path):
    return validate(json.load(open(path)))
