"""run_all.py — orchestrate the full BAUS per-generation benchmark: 3 toy regimes + alanine → pergen.json → PDFs.

Toys run in-process (numeric, seconds each). Alanine reuses an existing/finished coverage run (the OpenMM GPU
coverage run is launched separately — see baus_pergen_alanine); this orchestrator post-processes it and reuses the
committed cold-MD + REMD references. Writes one PDF per system under reports/comparisons/baus_benchmark/<system>/.
"""
from __future__ import annotations

import argparse

from escort_ais.common.paths import project_root
from escort_ais.experiments.benchmark import plot_baus_pergen, schema
from escort_ais.experiments.benchmark.baus_pergen_toy import REGIMES, run_toy_benchmark


def _out_dir(system):
    return project_root() / "reports" / "comparisons" / "baus_benchmark" / system


def run_toys(smoke=False, seed=0):
    kw = dict(n_gen=2, n_ais=40, n_rev=40, walker_steps=400, walkers=6) if smoke else {}
    out_pdfs = []
    for regime in REGIMES:
        res = run_toy_benchmark(regime, seed=seed, **kw)
        d = _out_dir(res["system"])
        schema.save(res, d / "pergen.json")
        out_pdfs.append(plot_baus_pergen.render(res, str(d / f"{res['system']}.pdf")))
        fin = res["per_gen"][-1]["populations"]
        print(f"[{res['system']}] pops(joint)={[round(x,3) for x in fin['joint']]} "
              f"analytic={[round(x,3) for x in res['reference']['analytic_pops']]}")
    return out_pdfs


def run_alanine(run_dir=None):
    """Post-process a finished alanine coverage run into a pergen.json + PDF (references reused, no re-run)."""
    from escort_ais.experiments.benchmark import baus_pergen_alanine
    res = baus_pergen_alanine.build_from_run(run_dir)
    d = _out_dir(res["system"])
    schema.save(res, d / "pergen.json")
    return plot_baus_pergen.render(res, str(d / f"{res['system']}.pdf"))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--toys-only", action="store_true")
    ap.add_argument("--alanine-only", action="store_true")
    ap.add_argument("--ala-run-dir", default=None, help="finished coverage run dir (default: data/.../coverage)")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    pdfs = []
    if not args.alanine_only:
        pdfs += run_toys(smoke=args.smoke, seed=args.seed)
    if not args.toys_only:
        try:
            pdfs.append(run_alanine(args.ala_run_dir))
        except Exception as e:
            print(f"[alanine] skipped/failed: {type(e).__name__}: {e}")
    print("\nPDFs:")
    for p in pdfs:
        print(f"  {p}")


if __name__ == "__main__":
    main()
