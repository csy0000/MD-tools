"""assemble_cluster_grid.py — 3x4 grid of the rendered top-4 centroid panels (per method).

Reads the per-medoid PNGs (results/cyclosporin/cluster250/img/) and hbonds.json, and labels each
panel with the cluster population, the cluster-AVERAGE number of intramolecular H-bonds, and the
medoid's H-bond count. Usage: python -m escort_ais.experiments.misc.assemble_cluster_grid
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.image as mpimg
import matplotlib.pyplot as plt

import os
_T = os.environ.get("CSA_TORSION", "backbone")
OUT = (Path("results/cyclosporin/cluster250") if _T == "backbone"
       else Path("results/cyclosporin") / _T / "cluster250")
IMG = OUT / "img"
hb = json.load(open(OUT / "hbonds.json"))
methods = [("DBSCAN", "DBSCAN"), ("HDBSCAN", "HDBSCAN"), ("DBSCAN++", "DBSCANpp")]

fig, axes = plt.subplots(3, 4, figsize=(15, 12))
for r, (label, fstem) in enumerate(methods):
    for c in range(4):
        ax = axes[r][c]
        ax.imshow(mpimg.imread(IMG / f"{fstem}_c{c}.png")); ax.set_xticks([]); ax.set_yticks([])
        info = hb[f"medoids/{fstem}_c{c}.pdb"]
        ax.set_title(f"cluster {c}: {info['pop_pct']}%   $\\langle$H-bonds$\\rangle$={info['avg_hb']:.1f}"
                     f"  (medoid {info['medoid_hb']})", fontsize=9.5)
        if c == 0:
            ax.set_ylabel(label, fontsize=13, fontweight="bold")
fig.suptitle("Top-4 cluster medoids (250 ns cold REMD) — aligned, element-coloured "
             "(C grey / N blue / O red), backbone amide N-H$\\cdots$O=C H-bonds dashed; "
             r"$\langle$H-bonds$\rangle$ = cluster-average backbone H-bonds per frame", fontsize=12)
fig.tight_layout(rect=(0, 0, 1, 0.97))
fig.savefig(OUT / "fig_centroids_grid.png", dpi=130)
print("saved fig_centroids_grid.png with cluster-average H-bond counts")
