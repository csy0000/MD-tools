#!/usr/bin/env python
"""bAIS Task 1: can the method find the CORRECT clusters as a function of hot-MD length?

For each hot checkpoint T in [60, 800] ns, fit hot-TICA on the hot window [burn, T] (the bAIS state-discovery
route), assign the REMD cold reference with that model, and score against the REMD-reference partition
(built from the REMD cold rung = ground truth). Metrics per T: population of the discovered minor state,
per-frame agreement with the REMD-reference labels on REMD data, and the population error. Cheap (CPU) —
no AIS. Writes results/rgd/report/bais_task1_clustering_<name>.json.

    conda activate escort-ais && python -m escort_ais.experiments.misc.evaluate_bais_clustering \
        --name rgd --hot-ref <800ns hot trajectory.dcd> --remd-dir <REMD dir>
"""
from __future__ import annotations
import argparse, glob, json, sys, warnings
from pathlib import Path
import numpy as np, mdtraj as md
warnings.filterwarnings("ignore")

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model_from_traj, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_sw_hot, load_remd_ensemble

NS_PER_FRAME = 0.01   # hot MD 10 ps/frame


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True)
    ap.add_argument("--hot-ref", required=True, help="existing hot trajectory.dcd (>=800 ns)")
    ap.add_argument("--remd-dir", required=True)
    ap.add_argument("--burn-ns", type=float, default=10.0)
    ap.add_argument("--tica-lag", type=int, default=50)
    ap.add_argument("--checkpoints", default="60:800:20", help="start:stop:step ns")
    ap.add_argument("--remd-burn-ns", type=float, default=30.0)
    args = ap.parse_args()
    cfg = load_cfg(args.name)

    ref_model = BasinModel.load(cfg.basin_model_path)                      # REMD-reference partition (truth)
    nb = ref_model.n_basins
    hot = load_sw_hot(Path(args.hot_ref), cfg.top_pdb)
    remd = load_remd_ensemble(Path(args.remd_dir), "replica_00", cfg.top_pdb,
                              int(round(args.remd_burn_ns / NS_PER_FRAME)))
    ref_lab = ref_model.assign(remd)
    ref_pop = np.bincount(ref_lab, minlength=nb).astype(float); ref_pop /= ref_pop.sum()
    lo = int(round(args.burn_ns / NS_PER_FRAME))
    a, b, st = (float(x) for x in args.checkpoints.split(":"))
    checks = np.arange(a, b + 1e-6, st)
    print(f"[{args.name}] REMD-ref partition {nb} states, pop {np.round(ref_pop,3).tolist()}; "
          f"{len(checks)} checkpoints", flush=True)

    rows = []
    for T in checks:
        hi = int(round(T / NS_PER_FRAME))
        win = hot[lo:hi]
        try:
            m = build_tica_basin_model_from_traj([win], cfg.topo, n_basins=nb, lag=args.tica_lag, seed=0)
            lab = m.assign(remd)
            pop = np.bincount(lab, minlength=nb).astype(float); pop /= pop.sum()
            # best-permutation agreement with the reference labels (2-state: identity or flip)
            from itertools import permutations
            acc = max(np.mean(np.array([p[x] for x in lab]) == ref_lab) for p in permutations(range(nb)))
            # align discovered pop to reference by that best perm for a fair population-error
            best = max(permutations(range(nb)),
                       key=lambda p: np.mean(np.array([p[x] for x in lab]) == ref_lab))
            pop_aligned = np.array([pop[list(best).index(i)] for i in range(nb)])
            pop_err = float(np.abs(pop_aligned - ref_pop).max())
            rows.append(dict(hot_ns=float(T), minor_pop=float(sorted(pop)[0]), agreement=float(acc),
                             pop_err=pop_err))
            print(f"  T={T:5.0f} ns: minor_pop {sorted(pop)[0]:.3f} (ref {sorted(ref_pop)[0]:.3f}) "
                  f"agreement {acc:.3f} pop_err {pop_err:.3f}", flush=True)
        except Exception as e:
            rows.append(dict(hot_ns=float(T), error=str(e)))
            print(f"  T={T:5.0f} ns: ERROR {e}", flush=True)

    out = ROOT / "results/rgd/report"; out.mkdir(parents=True, exist_ok=True)
    Path(out / f"bais_task1_clustering_{args.name}.json").write_text(json.dumps(
        dict(name=args.name, ref_pop=ref_pop.tolist(), n_states=nb, checkpoints=rows), indent=2))
    print(f"[{args.name}] Task-1 clustering -> {out}/bais_task1_clustering_{args.name}.json", flush=True)


if __name__ == "__main__":
    main()
