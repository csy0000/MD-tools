#!/usr/bin/env python
"""bAIS Task 2 summary: ddF vs hot-MD length and RMSE vs REMD, for all 3 systems.

Reads each system's data/rgd/diagnostics/bais_eval/<name>/generations.json (ddF_bar + reference per
checkpoint) and results/rgd/report/bais_task1_clustering_<name>.json (Task 1), and writes a combined
figure + summary JSON. RMSE at checkpoint T = |ddF_bar(T) - reference|  (2-state). Run whenever ready;
partial (incremental) ledgers are handled.

    conda activate escort-ais && python -m escort_ais.experiments.misc.evaluate_bais_ddf
"""
from __future__ import annotations
import json, sys
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

from escort_ais.common.paths import project_root
ROOT = project_root()
BASE = ROOT / "data/rgd/diagnostics/bais_eval"
OUT = ROOT / "results/rgd/report"
SYS = ["rgd", "cilengitide", "rgd_redPheVal"]
COL = {"rgd": "C0", "cilengitide": "C1", "rgd_redPheVal": "C3"}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(13, 5))
    summary = {}
    for name in SYS:
        gj = BASE / name / "generations.json"
        if not gj.exists():
            print(f"{name}: no generations.json yet (Task 2 not finished)"); continue
        d = json.loads(gj.read_text()); ref = d.get("reference_ddF")
        gens = d["generations"]
        T = np.array([g["hot_ns"] for g in gens], float)
        ddf = np.array([g["ddF_bar"] if g["ddF_bar"] is not None else np.nan for g in gens], float)
        rf = np.array([g.get("reference", ref) for g in gens], float)
        rmse = np.abs(ddf - rf)
        ok = np.isfinite(rmse)
        summary[name] = dict(reference_ddF=float(rf[-1]) if len(rf) else None,
                             final_ddF=float(ddf[ok][-1]) if ok.any() else None,
                             final_rmse=float(rmse[ok][-1]) if ok.any() else None,
                             mean_rmse_last5=float(np.nanmean(rmse[ok][-5:])) if ok.any() else None,
                             n_checkpoints=int(ok.sum()))
        ax[0].plot(T[ok], ddf[ok], "o-", color=COL[name], ms=3, label=f"{name} (ref {rf[-1]:.2f})")
        ax[0].axhline(rf[-1], ls=":", color=COL[name], alpha=.5)
        ax[1].plot(T[ok], rmse[ok], "o-", color=COL[name], ms=3, label=name)
        print(f"{name}: {ok.sum()} ckpts; final ddF {summary[name]['final_ddF']}, "
              f"ref {summary[name]['reference_ddF']}, final RMSE {summary[name]['final_rmse']}")
    ax[0].set(xlabel="hot MD length (ns)", ylabel=r"$\Delta\Delta F$ ($k_BT$)",
              title="Task 2: bAIS ddF vs hot-MD length (dotted = REMD ref)")
    ax[1].set(xlabel="hot MD length (ns)", ylabel=r"RMSE vs REMD ($k_BT$)",
              title="Task 2: |ddF_bAIS - ddF_REMD|"); ax[1].axhline(0, color="gray", lw=.5)
    for a in ax: a.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(OUT / "fig_bais_task2_rmse.png", dpi=140)
    Path(OUT / "bais_task2_summary.json").write_text(json.dumps(summary, indent=2))
    print(f"\nsaved {OUT}/fig_bais_task2_rmse.png + bais_task2_summary.json")


if __name__ == "__main__":
    main()
