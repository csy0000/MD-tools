#!/usr/bin/env python3
"""analyze_long_md_feasibility.py — is a FEW-LONG-MD reservoir feasible? (read-only, no new MD)

The 86-short-seed reservoir traps in disjoint sub-wells (fails intra-basin local equilibrium, LEQ; not
reconcilable by reweighting). This sizes the alternative — a few long cold-MD trajectories per basin — from
data already on disk:

  PART A (direct evidence): the existing 1000 ns cyclosporin COLD s=1 single-walker MD, vs cyclosporin REMD.
    - basin ESCAPES + MFPT (four_state_msm) -> is an inter-basin MSM viable at s=1, or rare-event-limited?
    - LEQ: JS(cold(.|B), REMD(.|B)) per basin vs a REMD-self floor -> does one long cold MD reach the REMD
      conditional? quarter-by-quarter (250 ns) convergence -> is it still improving at 1000 ns?
    - intra-basin slowest implied timescale (ITS) -> relaxation time = how long to reach LEQ.
  PART B (context): the macrocycle 800 ns HOT s=0.25 MD -> inter-basin flip rate + intra-basin ITS at s=0.25
    (transition-rich sanity; cold s=1 is exponentially slower).

    conda activate escort-ais && python -m escort_ais.experiments.misc.analyze_long_md_feasibility
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.four_state_msm import (count_matrix, reversible_transition_matrix,  # noqa: E402
                                       implied_timescales, mfpt_matrix)
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

CYC = ROOT / "data/cyclosporin"
COLD = CYC / "2026-06-19-ref-singlewalker-cold-s1p0-1000ns/trajectory.dcd"
HOTC = CYC / "2026-06-19-ref-singlewalker-hot-s0p4-1000ns/trajectory.dcd"
CYC_REMD = CYC / "2026-06-18-rest2-remd-8rep-s0p4-250ns"
HOTM = {"rgd": ROOT / "data/rgd/2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701/trajectory.dcd",
        "cilengitide": ROOT / "data/cilengitide/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd"}
NSTATE, KSUB, MINN, DT_COLD, DT_HOT = 4, 12, 300, 0.010, 0.010   # ns/frame (10 ps)


def _js(a, b, eps=1e-12):
    a = np.asarray(a, float) + eps; a /= a.sum(); b = np.asarray(b, float) + eps; b /= b.sum()
    m = 0.5 * (a + b)
    return float(0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m)))


def mdwell(d, D=5):
    """min-dwell flicker filter: suppress basin visits shorter than D frames (hold previous label)."""
    d = d.copy()
    i = 0
    while i < len(d):
        j = i
        while j < len(d) and d[j] == d[i]:
            j += 1
        if j - i < D and i > 0:
            d[i:j] = d[i - 1]
        i = j
    return d


def slowest_intrabasin_its(feats, dtraj, B, dt, k=8, lag=50):
    """slowest implied timescale within basin B, from contiguous within-B segments (ns)."""
    inB = dtraj == B
    if inB.sum() < MINN:
        return np.nan
    # contiguous runs of B
    idx = np.where(inB)[0]
    breaks = np.where(np.diff(idx) > 1)[0] + 1
    runs = np.split(idx, breaks)
    km = KMeans(k, n_init=4, random_state=0).fit(feats[idx])
    segs = [km.predict(feats[r]) for r in runs if len(r) > lag]
    if not segs:
        return np.nan
    C = count_matrix(segs, lag, k, pseudocount=1e-6)
    T, _ = reversible_transition_matrix(C)
    its = implied_timescales(T, lag, dt)
    return float(np.max(its)) if len(its) else np.nan


def leq_js(featC, featR, rng):
    """JS(cold(.|B) , REMD(.|B)) and REMD-self floor over a shared sub-clustering (size-controlled)."""
    if len(featC) < MINN or len(featR) < MINN:
        return np.nan, np.nan
    km = KMeans(min(KSUB, len(featR) // 25 + 2), n_init=6, random_state=0).fit(np.concatenate([featR, featC]))
    K = km.n_clusters
    n = min(len(featC), len(featR))
    ic = rng.permutation(len(featC))[:n]; ir = rng.permutation(len(featR))[:n]
    js = _js(np.bincount(km.predict(featC[ic]), minlength=K), np.bincount(km.predict(featR[ir]), minlength=K))
    h = n // 2
    floor = _js(np.bincount(km.predict(featR[ir[:h]]), minlength=K),
                np.bincount(km.predict(featR[ir[h:2 * h]]), minlength=K))
    return js, floor


def part_a():
    rng = np.random.default_rng(0)
    cfg = load_cfg("cyclosporin"); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = build_tica_basin_model(HOTC, cfg.top_pdb, cfg.topo, n_basins=NSTATE, lag=20, n_tic=4,
                                   burn_frames=1000, stride=2, seed=0)
    cold = md.load_dcd(str(COLD), top=top); coldX = featurize(cold, q); cd = model.assign(cold)
    remd = load_remd_ensemble(CYC_REMD, "replica_00", cfg.top_pdb, 0); remdX = featurize(remd, q)
    rd = model.assign(remd)
    p_remd = np.bincount(rd, minlength=NSTATE).astype(float); p_remd /= p_remd.sum()
    p_cold = np.bincount(cd, minlength=NSTATE).astype(float); p_cold /= p_cold.sum()
    order = np.argsort(-p_remd)

    # escapes / MFPT over the continuous cold trajectory (flicker-filtered)
    cdf = mdwell(cd, D=5)
    n_escape = int((np.diff(cdf) != 0).sum())
    C = count_matrix([cdf], lag=50, n_states=NSTATE, pseudocount=1e-6)
    T, pi = reversible_transition_matrix(C)
    M = mfpt_matrix(T, lag=50, dt=DT_COLD)                       # ns
    a, b = order[0], order[1]                                    # two most REMD-populated basins

    print("\n===== PART A: cyclosporin 1000 ns COLD s=1 MD vs REMD (direct) =====", file=sys.stderr)
    print(f"  basin populations  REMD={np.round(p_remd,3).tolist()}  cold-MD={np.round(p_cold,3).tolist()}",
          file=sys.stderr)
    print(f"  basin escapes over 1000 ns (flicker-filtered): {n_escape}   "
          f"MFPT S{a}<->S{b}: {M[a,b]:.0f} / {M[b,a]:.0f} ns", file=sys.stderr)
    print(f"  state | REMD | LEQ JS(cold|B vs REMD|B) [floor] | quarters(250ns each) | intra-basin slowest ITS",
          file=sys.stderr)
    q_bounds = np.linspace(0, len(cold), 5).astype(int)
    for B in order:
        if p_remd[B] < 0.02:
            continue
        js, floor = leq_js(coldX[cd == B], remdX[rd == B], rng)
        qj = []
        for qi in range(4):
            sl = slice(q_bounds[qi], q_bounds[qi + 1])
            cB = coldX[sl][cd[sl] == B]
            qj.append(round(leq_js(cB, remdX[rd == B], rng)[0], 2) if len(cB) >= MINN else np.nan)
        its = slowest_intrabasin_its(coldX, cd, B, DT_COLD)
        print(f"   S{B}   | {p_remd[B]:.2f} | {js:.3f} [{floor:.3f}] | {qj} | "
              f"{its:.0f} ns" if not np.isnan(its) else f"   S{B}   | {p_remd[B]:.2f} | {js:.3f} [{floor:.3f}] "
              f"| {qj} | n/a", file=sys.stderr)


def part_b():
    print("\n===== PART B: macrocycle 800 ns HOT s=0.25 MD (context; cold s=1 is exp. slower) =====",
          file=sys.stderr)
    for name in ["rgd", "cilengitide", "rgd_redPheVal"]:
        cfg = load_cfg(name); top = str(cfg.top_pdb); q, _, _ = load_quartets(cfg.topo, "backbone")
        model = build_tica_basin_model(HOTM[name], cfg.top_pdb, cfg.topo, n_basins=5, lag=20, n_tic=4,
                                       burn_frames=1000, stride=2, seed=0)
        hot = md.load_dcd(str(HOTM[name]), top=top); hd = model.assign(hot)
        hdf = mdwell(hd, D=5); n_flip = int((np.diff(hdf) != 0).sum())
        p = np.bincount(hd, minlength=5).astype(float); p /= p.sum(); order = np.argsort(-p)
        C = count_matrix([hdf], lag=50, n_states=5, pseudocount=1e-6)
        T, _ = reversible_transition_matrix(C)
        M = mfpt_matrix(T, lag=50, dt=DT_HOT); a, b = order[0], order[1]
        featX = featurize(hot, q)
        its = slowest_intrabasin_its(featX, hd, order[0], DT_HOT)
        print(f"  {name:14s}: {n_flip} inter-basin flips/800ns hot; MFPT S{a}<->S{b} "
              f"{M[a,b]:.0f}/{M[b,a]:.0f} ns; major-basin intra ITS {its:.0f} ns (all at s=0.25)",
              file=sys.stderr)


def main():
    part_a()
    part_b()


if __name__ == "__main__":
    main()
