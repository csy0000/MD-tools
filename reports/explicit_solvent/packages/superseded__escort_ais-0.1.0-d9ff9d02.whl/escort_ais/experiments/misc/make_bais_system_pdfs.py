#!/usr/bin/env python3
"""make_bais_system_pdfs.py — one convergence PDF per system for the bAIS evaluation.

Scores bAIS by the POPULATION over isolated metastable states (TICA-on-hot), NOT the single-torsion
major/minor ddF (whose boundary is ill-defined for the derivatives). For each system writes
    results/rgd/report/bais_convergence_<name>.pdf
with:
  page 1 — (a) bAIS state free energies vs hot-MD length converging to the REMD reference;
           (b) state populations REMD vs bAIS vs raw cold reservoir (artifact suppression);
           (c) Task 1 clustering agreement / minor-population error.
  page 2 — text summary: per-state populations + dG, total-variation distance to REMD, budget, verdict.

Reads state_population_convergence.json (compute_state_population_convergence.py). Partial-safe.

    conda activate escort-ais && python -m escort_ais.experiments.misc.make_bais_system_pdfs
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import pandas as pd
import mdtraj as md

KT_KJ = 0.0083144621 * 300.0        # kJ/mol per kT at 300 K

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_sw_hot, load_remd_ensemble  # noqa: E402

BASE = ROOT / "data/rgd/diagnostics/bais_eval"
OUT = ROOT / "results/rgd/report"

HOT = {
    "rgd": "data/rgd/2026-06-29-ref-singlewalker-hot-s0p25-300ns/trajectory.dcd",
    "cilengitide": "data/cilengitide/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
    "rgd_redPheVal": "data/rgd_redPheVal/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
}
REMD = {
    "rgd": "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
    "cilengitide": "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
    "rgd_redPheVal": "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns",
}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide (N-Me)",
        "rgd_redPheVal": "RGD reduced-PheVal amide"}


def _ddF(p):
    p = np.clip(p, 1e-4, 1 - 1e-4)
    return float(np.log((1 - p) / p))


def remd_ddF_convergence(name, burn_ns=50, step_ns=50, nblocks=10, total_ns=500.0):
    """REMD cold-rung (replica_00) ddF vs cumulative REMD length [burn, T], with 10-block SEM."""
    cfg = load_cfg(name)
    m = BasinModel.load(cfg.basin_model_path)
    tr = load_remd_ensemble(Path(ROOT / REMD[name]), "replica_00", cfg.top_pdb, 0)
    minor = (m.assign(tr) == 1).astype(float)
    fpn = len(minor) / total_ns
    Ts, dd, err = [], [], []
    for T in range(step_ns, int(total_ns) + 1, step_ns):
        if T <= burn_ns:
            continue
        w = minor[int(burn_ns * fpn):int(T * fpn)]
        Ts.append(T)
        dd.append(_ddF(w.mean()))
        L = len(w) // nblocks
        blk = np.array([_ddF(w[i * L:(i + 1) * L].mean()) for i in range(nblocks)])
        err.append(blk.std(ddof=1) / np.sqrt(nblocks))
    return np.array(Ts), np.array(dd), np.array(err)


def populations(name):
    """Minor populations on the REMD-reference basins: SW-hot, REMD hot rung, REMD cold (=reference)."""
    cfg = load_cfg(name)
    ref = BasinModel.load(cfg.basin_model_path)
    top = cfg.top_pdb
    sw = load_sw_hot(Path(ROOT / HOT[name]), top)
    cold = load_remd_ensemble(Path(ROOT / REMD[name]), "replica_00", top, 0)
    hotr = load_remd_ensemble(Path(ROOT / REMD[name]), "replica_05", top, 0)
    return {
        "sw_hot": float((ref.assign(sw) == 1).mean()),
        "remd_hot": float((ref.assign(hotr) == 1).mean()),
        "remd_cold": float((ref.assign(cold) == 1).mean()),
    }


def state_definition(name):
    """Human-readable 2-state definition from the GeometricBasinModel (split torsion + modes + pop)."""
    cfg = load_cfg(name)
    m = BasinModel.load(cfg.basin_model_path)
    idx, a, b = m.rules[0]
    quartet = list(np.asarray(m.quartets[idx]))
    major, minor = m.basin_pop
    return {
        "dih_index": int(idx), "atoms": quartet, "modes": (float(a), float(b)),
        "pop": (float(major), float(minor)), "torsion": getattr(m, "torsion", "backbone"),
        "text": (f"2 states split on {m.torsion} dihedral #{idx} (atoms {quartet}): "
                 f"basin modes at {a:.0f}deg / {b:.0f}deg; model populations "
                 f"{major:.3f} major / {minor:.3f} minor."),
    }


def pool_works(name):
    """Pool AIS reduced works (kT) across all generations, tagged by COLD-side basin.

    Forward: work of each hot->cold switch, tagged by its cold LANDING basin
             (assign ais_final_coordinates.dcd, row-aligned to the summary CSV).
    Reverse: work of each cold->hot switch, tagged by its cold START basin
             (assign rev/seed_cold, indexed by the summary's initial_frame_index).
    Returns {'fwd':{b:arr}, 'rev':{b:arr}, 'n_fwd':N, 'n_rev':N}.
    """
    cfg = load_cfg(name)
    model = BasinModel.load(cfg.basin_model_path)
    top = str(cfg.top_pdb)
    sysdir = BASE / name
    fwd = {0: [], 1: []}
    rev = {0: [], 1: []}

    for csv in sorted(sysdir.glob("gen*/fwd/ais_trajectory_summary.csv")):
        df = pd.read_csv(csv)
        dcd = csv.parent / "ais_final_coordinates.dcd"
        if not dcd.exists():
            continue
        lab = model.assign(md.load_dcd(str(dcd), top=top))
        n = min(len(df), len(lab))
        w = df["final_W"].values[:n] / KT_KJ
        for b in (0, 1):
            fwd[b].extend(w[lab[:n] == b].tolist())

    for csv in sorted(sysdir.glob("gen*/rev/step/ais_trajectory_summary.csv")):
        df = pd.read_csv(csv)
        seed = csv.parent.parent / "seed_cold/trajectory.dcd"
        if not seed.exists():
            continue
        slab = model.assign(md.load_dcd(str(seed), top=top))
        ifi = df["initial_frame_index"].values
        ok = ifi < len(slab)
        w = df["final_W"].values[ok] / KT_KJ
        b_start = slab[ifi[ok]]
        for b in (0, 1):
            rev[b].extend(w[b_start == b].tolist())

    fwd = {b: np.array(v) for b, v in fwd.items()}
    rev = {b: np.array(v) for b, v in rev.items()}
    return {"fwd": fwd, "rev": rev,
            "n_fwd": sum(len(v) for v in fwd.values()),
            "n_rev": sum(len(v) for v in rev.values())}


def make_pdf(name):
    # bAIS is scored by the POPULATION over isolated metastable states (TICA-on-hot; boundaries in kinetic
    # barriers), NOT the single-torsion major/minor ddF -- that boundary sits in a populated region for the
    # derivatives, so its ddF is threshold-arbitrary by ~1-2 kT (see analyze_threshold_sensitivity.py and
    # reports/rgd/cold_artifact_identification.md, 2026-07-08 revised conclusion). bAIS pop = forward-AIS Jarzynski
    # sum e^{logw} per state; compared to REMD by total-variation distance.
    sp = json.load(open(BASE / name / "state_population_convergence.json"))
    ck = sp["checkpoints"]
    x = np.array([c["hot_ns"] for c in ck], float)
    p_remd = np.array(sp["p_remd"], float)
    dG_remd = np.array(sp["dG_remd"], float)
    p_cold = np.array(sp["p_cold_raw"], float)
    p_bais = np.array(ck[-1]["p_bais"], float)
    dG_bais = np.array([c["dG_bais"] for c in ck], float)      # (ncheck, nstate)
    tv = np.array([c["tv"] for c in ck], float)
    ref, sil, ns = sp["ref_state"], sp["silhouette"], len(p_remd)
    order = list(np.argsort(-p_remd))
    tracked = [s for s in order if p_remd[s] >= 0.01 and s != ref]      # populated non-reference states
    trap_cold = float(p_cold[[s for s in range(ns) if p_remd[s] < 0.005]].sum())

    t1 = json.load(open(OUT / f"bais_task1_clustering_{name}.json"))
    c1 = t1.get("checkpoints", [])
    tx = np.array([c["hot_ns"] for c in c1], float)
    agree = np.array([c["agreement"] for c in c1], float)
    poperr = np.array([c["pop_err"] for c in c1], float)

    g = json.load(open(BASE / name / "generations.json"))["generations"]
    gl = g[-1]; sw_ps = gl.get("switch_ps", 5.0)
    kf, kr, ncold = gl.get("k_fwd"), gl.get("k_rev"), gl.get("n_cold_seeds")
    cold_each = gl.get("reverse_diag", {}).get("cold_ns_generated", 0.0)
    cum_ns = gl.get("cumulative_ns")
    running = "  [RUN IN PROGRESS]" if x[-1] < 799 and name != "rgd" else "  [complete]"
    colors = ["C1", "C2", "C4", "C5", "C6"]

    rc = sp.get("remd_convergence", [])
    rT = np.array([r["T"] for r in rc], float)
    rdG = np.array([r["dG"] for r in rc], float) if rc else np.zeros((0, ns))
    rsem = np.array([r["sem"] for r in rc], float) if rc else np.zeros((0, ns))

    out = OUT / f"bais_convergence_{name}.pdf"
    with PdfPages(out) as pdf:
        # Every figure page is stamped "Figure N" (top-left) so panels are citable as e.g. "Figure 3B"
        # (page number + the A/B/C… panel letter drawn inside each figure). The text-summary page is not
        # a figure and is saved with number=False.
        _fig = {"n": 0}

        def _save(f, number=True):
            if number:
                _fig["n"] += 1
                f.text(0.012, 0.994, f"Figure {_fig['n']}", fontsize=12, fontweight="bold",
                       va="top", ha="left", color="0.15")
            pdf.savefig(f, dpi=300); plt.close(f)

        # ---- page 1 ----
        fig, ax = plt.subplots(4, 1, figsize=(8.3, 15.5), gridspec_kw={"height_ratios": [3, 2.4, 2, 2]})

        # (a) bAIS state free energies converging to REMD (dashed) vs hot length
        for i, s in enumerate(tracked):
            c = colors[i % len(colors)]
            ax[0].plot(x, dG_bais[:, s], "o-", color=c, lw=1.6, ms=4,
                       label=f"bAIS $\\Delta G$(S{s}) = {dG_bais[-1, s]:+.2f} kT   (REMD {dG_remd[s]:+.2f})")
            ax[0].axhline(dG_remd[s], ls="--", color=c, lw=1.4, alpha=0.85)
        ax[0].set_xlabel("hot-ensemble length (ns)")
        ax[0].set_ylabel("$\\Delta G$ vs most-populated state (kT)")
        ax[0].set_title(f"{NICE.get(name, name)} — bAIS state free energies vs REMD{running}\n"
                        f"isolated metastable states (TICA-on-hot, silhouette {sil:+.2f}); "
                        f"final population TV to REMD = {tv[-1]:.3f}", fontsize=11)
        ax[0].legend(fontsize=8, loc="best"); ax[0].grid(alpha=0.3)

        # (b) REMD reference convergence vs cumulative REMD length (10-block SEM)
        for i, s in enumerate(tracked):
            c = colors[i % len(colors)]
            if len(rT):
                ax[1].errorbar(rT, rdG[:, s], yerr=rsem[:, s], fmt="s-", color=c, lw=1.6, ms=4, capsize=2,
                               label=f"REMD $\\Delta G$(S{s}) = {rdG[-1, s]:+.2f} kT")
                ax[1].axhline(dG_remd[s], ls="--", color=c, lw=1.1, alpha=0.6)
        ax[1].set_xlabel("REMD length T (ns)")
        ax[1].set_ylabel("$\\Delta G$ vs most-populated state (kT)")
        # drift of the POPULATED states only (empty states' dG blows up and is not meaningful)
        drift = max((rdG[:, s].max() - rdG[:, s].min()) for s in tracked) if (len(rT) and tracked) else 0.0
        ax[1].set_title(f"REMD reference convergence vs cumulative REMD length "
                        f"(10-block SEM; max drift {drift:.2f} kT over 50$\\to$500 ns)", fontsize=10)
        ax[1].legend(fontsize=8, loc="best"); ax[1].grid(alpha=0.3)

        # (c) state populations: REMD vs bAIS vs raw cold reservoir
        show = [s for s in order if (p_remd[s] >= 0.005 or p_cold[s] >= 0.02)][:6]
        xb = np.arange(len(show)); w = 0.27
        ax[2].bar(xb - w, p_remd[show], w, color="crimson", label="REMD (reference)")
        ax[2].bar(xb, p_bais[show], w, color="C0", label="bAIS (forward-AIS reweighted)")
        ax[2].bar(xb + w, p_cold[show], w, color="0.6", label="raw cold reservoir (unweighted)")
        ax[2].set_xticks(xb); ax[2].set_xticklabels([f"S{s}" for s in show])
        ax[2].set_ylabel("population")
        ax[2].set_title(f"state populations: bAIS matches REMD (TV {tv[-1]:.3f}); raw cold puts "
                        f"{trap_cold:.0%} in REMD-empty trap states", fontsize=10)
        ax[2].legend(fontsize=8); ax[2].grid(alpha=0.3, axis="y")

        # (d) Task 1
        ax[3].plot(tx, agree, "s-", color="C2", label="clustering agreement vs REMD partition")
        ax[3].plot(tx, poperr, "^-", color="C3", label="minor-population error")
        ax[3].axhline(1.0, ls=":", color="C2", alpha=0.5)
        ax[3].set_xlabel("hot-ensemble length (ns)"); ax[3].set_ylabel("Task 1 score")
        ax[3].set_ylim(-0.02, 1.02)
        ax[3].set_title("Task 1 — can hot-TICA recover the REMD basin partition?", fontsize=10)
        ax[3].legend(fontsize=8, loc="center right"); ax[3].grid(alpha=0.3)
        panel_labels(fig); fig.tight_layout(); _save(fig)

        # ---- page 2: cold-MD quality — JS to REMD(.|B) vs continuous sub-well residence ----
        jr_path = BASE / name / "js_vs_residence.json"
        if jr_path.exists():
            jr = json.load(open(jr_path))
            R = np.array([p["residence_ns"] for p in jr["points"]], float)
            J = np.array([p["js"] for p in jr["points"]], float)
            figr, axr = plt.subplots(figsize=(8.3, 6.0))
            axr.scatter(R, J, s=34, c="C0", alpha=0.6, edgecolor="k", lw=0.3)
            axr.axhline(0.05, ls=":", c="green", lw=1.3, label="near-equilibrium (JS < 0.05)")
            axr.axhline(0.693, ls=":", c="gray", lw=1.3, label="ln2 ceiling (fully disjoint)")
            axr.set_xlabel("longest continuous sub-well residence (ns, of 5 ns run)")
            axr.set_ylabel("per-cold-MD JS to REMD(.|B)")
            axr.set_title(f"{NICE.get(name, name)} — cold-MD quality: JS to REMD vs continuous residence\n"
                          f"Spearman = {jr['spearman_residence_js']:+.2f}  (n={jr['n_cold_md']}, median "
                          f"{jr['median_residence_ns']:.2f} ns) — frozen = disjoint, mixing = near-REMD",
                          fontsize=10)
            axr.legend(fontsize=9); axr.grid(alpha=0.3)
            figr.tight_layout(); _save(figr)

        # ---- page: LEQ convergence — cumulative + blocked JS(t) vs REMD (density basins + KCC) ----
        # Does LONGER (100 ns) cold MD reach intra-basin local equilibrium? See analyze_fps10_leq_convergence.py
        # and reports/rgd/cold_artifact_identification.md (2026-07-09). Embedded from the generated wide PNG.
        def _embed(png, width=8.0):
            if png.exists():
                im = plt.imread(str(png)); h, w = im.shape[:2]
                figj, axj = plt.subplots(figsize=(width, max(1.6, width * h / w)))
                axj.imshow(im, interpolation="none"); axj.axis("off")
                figj.tight_layout(pad=0.2); _save(figj)
        # LEQ convergence, then the adaptive hierarchical timescale-gated LEQ pages (overview, per-leaf
        # implied-timescale convergence, within-leaf sub-basin distributions) — see
        # src/escort_ais/analysis/analyze_fps10_hierarchical_leq.py and .docs/records/artifacts/2026-07-09-hierarchical-*.
        for png in (OUT / f"fig_{name}_leq_convergence.png", OUT / f"fig_{name}_residence_vs_leq.png",
                    OUT / f"fig_{name}_hierarchical_leq.png", OUT / f"fig_{name}_hierarchical_leq_its.png",
                    OUT / f"fig_{name}_hierarchical_leq_dists.png",
                    OUT / f"fig_{name}_hierarchical_backend_compare.png",
                    OUT / f"fig_{name}_within_basin_restrained.png",
                    OUT / f"fig_{name}_major_substructure.png",
                    OUT / f"fig_{name}_r0_dih14_dih4_hist.png",
                    OUT / f"fig_{name}_r0_dih0_dih6_2dhist.png",
                    OUT / f"fig_{name}_state_pca_separation.png",
                    OUT / f"fig_{name}_kinetic_leaves_projection.png",
                    OUT / f"fig_{name}_ais_landing_projection.png"):
            _embed(png)

        # ---- page 3: 2D torsion contour map of the metastable states ----
        c2d = OUT / f"fig_{name}_state_torsion_2d.png"
        if c2d.exists():
            figc, axc = plt.subplots(figsize=(8.3, 7.4))
            axc.imshow(plt.imread(str(c2d))); axc.axis("off")
            figc.tight_layout(pad=0.2); _save(figc)

        # ---- page 4: text summary ----
        fig = plt.figure(figsize=(8.3, 9.5)); fig.clf()
        lines = [
            f"bAIS state-population summary — {NICE.get(name, name)}  ({name})",
            "=" * 78, "",
            f"STATE DEFINITION: {ns} isolated metastable states from TICA on the hot ensemble",
            f"    (n_tic=4, lag 20). REMD-frame silhouette = {sil:+.2f} (>0.25 = well separated).",
            "    Threshold-free: replaces the single-torsion major/minor split, whose boundary",
            "    sits in a populated region for the derivatives (ddF arbitrary by ~1-2 kT).", "",
            "POPULATION per state (sorted by REMD population):",
            "    state |  REMD    bAIS   raw-cold | dG_REMD  dG_bAIS  (kT vs most-pop)",
        ]
        for s in order:
            if p_remd[s] < 0.005 and p_cold[s] < 0.02:
                continue
            lines.append(f"     S{s}   | {p_remd[s]:6.3f} {p_bais[s]:6.3f} {p_cold[s]:8.3f}  | "
                         f"{dG_remd[s]:+7.2f} {dG_bais[-1, s]:+7.2f}")
        lines += [
            "",
            f"AGREEMENT (total-variation distance to REMD, 0 = perfect):",
            f"    bAIS (forward-AIS reweighted) : {tv[-1]:.3f}",
            f"    raw cold reservoir            : {0.5*np.abs(p_cold - p_remd).sum():.3f}   "
            f"({trap_cold:.0%} of cold frames sit in REMD-empty trap states -> reweighting zeroes them)",
            "",
            "SIMULATION BUDGET (final checkpoint):",
            f"    forward AIS : k_fwd = {kf} x {sw_ps:.0f} ps        cold MD : {ncold} seeds x {cold_each:.0f} ns",
            f"    hot ensemble: {x[-1]:.0f} ns single walker (s=0.25)   total : {cum_ns:.0f} ns",
            "",
            "VERDICT:",
        ]
        verdict = (f"bAIS reproduces the REMD state populations to TV {tv[-1]:.3f}; the populated-state free "
                   f"energies match REMD within a few tenths of a kT. The forward-AIS reweighting correctly "
                   f"suppresses the {trap_cold:.0%} of cold-reservoir frames trapped in REMD-empty states. "
                   f"The earlier single-torsion ddF discrepancy was an artifact of an ill-defined state "
                   f"boundary, not a bAIS failure (reports/rgd/cold_artifact_identification.md).")
        import textwrap
        for wln in textwrap.wrap(verdict, 74):
            lines.append("    " + wln)
        fig.text(0.06, 0.97, "\n".join(lines), va="top", ha="left", family="monospace", fontsize=9.2)
        _save(fig, number=False)

    print(f"wrote {out}  ({len(ck)} checkpoints, final TV {tv[-1]:.3f}, silhouette {sil:+.2f})")


def main():
    for name in ["rgd", "cilengitide", "rgd_redPheVal"]:
        make_pdf(name)


if __name__ == "__main__":
    main()
