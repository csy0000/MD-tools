#!/usr/bin/env python3
"""run_ais_leg.py — run ONE AIS leg (or one shard of a leg) as a standalone process.

A thin CLI around escort_ais.methods.ais_linear.run_linear_scaling_ais so that independent AIS trajectories
can be fanned out across processes (each its own CUDA context) and merged afterwards. A shard draws a
DISJOINT stride of the seed pool: --frame-offset i --frame-stride N --k k/N -> frames i, i+N, i+2N, …
Distinct --seed per shard decorrelates the stochastic dynamics. Output dir gets the usual AIS files
(ais_trajectory_summary.csv, selected_initial_frames.csv, ais_final_coordinates.dcd, …), and because
selected_initial_frames are in the SEED-DIR coordinate, shard outputs concatenate trivially.

Usage (one shard):  python -m escort_ais.experiments.misc.run_ais_leg \
    --seed-dir <dir> --out-dir <dir> --k 250 --s-hot 0.4 --s-cold 1.0 --switch-ps 10 \
    --frame-offset 0 --frame-stride 4 --omega-exclude <path.npy> --seed 1 --platform CUDA
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seed-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--k", type=int, required=True)
    ap.add_argument("--s-hot", type=float, required=True)
    ap.add_argument("--s-cold", type=float, required=True)
    ap.add_argument("--switch-ps", type=float, required=True)
    ap.add_argument("--frame-offset", type=int, default=0)
    ap.add_argument("--frame-stride", type=int, default=1)
    ap.add_argument("--freq-ais", type=int, default=10)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--omega-exclude", default=None, help="path to omega_exclude_bonds.npy (optional)")
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device", default=None, help="GPU device index (CUDA DeviceIndex / OpenCL OpenCLDeviceIndex)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-gpu-switching", dest="gpu_switching", action="store_false",
                    help="use the per-window updateParametersInContext reload path (default: GPU-side globals)")
    args = ap.parse_args()

    excl = np.load(args.omega_exclude) if args.omega_exclude else None
    t_ais = max(1, int(round(args.switch_ps * 1000.0 / args.timestep_fs)))
    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=args.k, t_ais=t_ais, freq_ais=args.freq_ais,
        s_hot=args.s_hot, s_cold=args.s_cold, omega_exclude_bonds=excl,
        start_frame_offset=args.frame_offset, start_frame_stride=args.frame_stride,
        input_scaled_dir=Path(args.seed_dir), output_dir=Path(args.out_dir), platform=args.platform,
        device_index=args.device, seed=args.seed, overwrite=True, save_traj_every_switch=False,
        gpu_switching=args.gpu_switching))


if __name__ == "__main__":
    main()
