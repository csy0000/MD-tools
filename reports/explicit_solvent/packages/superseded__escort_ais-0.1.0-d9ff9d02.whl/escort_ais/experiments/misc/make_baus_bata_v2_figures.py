#!/usr/bin/env python3
"""make_baus_bata_v2_figures.py — figures for the v2 BAUS/BAIS validation (reads baus_bata_v2_summary.json + raw).

Produces: problem definition (both regimes), population convergence vs total budget (median+IQR), PMF reconstruction
+ coverage, kinetic convergence (stationary TV + ITS relative error) vs budget, and a phase diagram.
    conda activate escort-ais && python -m escort_ais.experiments.misc.make_baus_bata_v2_figures
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.systems.toy1d import Toy1D, REGIMES  # noqa: E402

OUT = ROOT / "results/toy"
CLR = dict(single="C0", multi="C1", aus="C4", baus="C2", msm="C1", bata="C2", tram="C5")
LAB = dict(single="single-walker cold", multi="multi-seed cold", aus="AUS (fwd-only)", baus="BAUS",
           msm="free-π MSM", bata="BAIS", tram="restricted-TRAM control")


def _band(ax, x, agg, key, marker):
    med = np.array([a[key]["median"] if a[key]["median"] is not None else np.nan for a in agg], float)
    q25 = np.array([a[key]["q25"] if a[key]["q25"] is not None else np.nan for a in agg], float)
    q75 = np.array([a[key]["q75"] if a[key]["q75"] is not None else np.nan for a in agg], float)
    ax.plot(x, med, marker, c=CLR[key], label=LAB[key], lw=2, ms=5)
    ax.fill_between(x, q25, q75, color=CLR[key], alpha=0.18)


def fig_problem():
    fig, ax = plt.subplots(1, 2, figsize=(13, 5.0))
    th = np.linspace(-np.pi, np.pi, 720); deg = np.degrees(th)
    for reg, c in (("S", "C2"),):
        t = Toy1D(kappa=REGIMES[reg]["kappa"]); U = t.U_cold(th); U -= U.min()
        kin = t.smoluchowski_kinetics()
        ax[0].plot(deg, U, "-", c=c, lw=2, label=f"Regime {reg} (A↔B {REGIMES[reg]['barriers_kT']['A_B']} kT, "
                   f"t$_{{AB}}$={kin['t_AB']/1e3:.0f}k fr)")
    ana = Toy1D(kappa=REGIMES["S"]["kappa"]).populations()
    for cdeg, p, lab in zip(ana["well_centers_deg"], ana["pops"], ["B", "A1", "A2"]):
        ax[0].annotate(f"{lab}\n{p:.2f}", (cdeg, 0.2), ha="center", fontsize=9, fontweight="bold", color="0.2")
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("U_cold(θ) (kT), min→0"); ax[0].set_xlim(-180, 180)
    ax[0].set_title("cold potential — two regimes, SAME populations (0.42/0.33/0.25)", fontsize=10)
    ax[0].legend(fontsize=8)
    t = Toy1D(kappa=REGIMES["S"]["kappa"]); pc = t.p_eq(th); pc /= pc.sum() * (th[1] - th[0])
    ph = np.exp(-t.U(th, t.s_hot)); ph /= ph.sum() * (th[1] - th[0])
    ax[1].plot(deg, pc, "k-", lw=2, label="cold P(θ) (target)")
    ax[1].plot(deg, ph, "-", c="C3", lw=2, label=f"hot ensemble (s={t.s_hot})")
    ax[1].set_xlabel("θ (deg)"); ax[1].set_ylabel("density"); ax[1].set_xlim(-180, 180)
    ax[1].set_title("cold vs hot densities (hot covers all basins)", fontsize=10); ax[1].legend(fontsize=8)
    fig.suptitle("Problem definition — slow cold A↔B equilibration; hot gives coverage; annealing gives normalization",
                 fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / "fig_v2_problem.png", dpi=200); plt.close(fig)


def fig_convergence(summ):
    fig, ax = plt.subplots(1, 2, figsize=(14, 5.2), sharey=True)
    for k, reg in enumerate(["S"]):
        sc = sorted(summ[reg], key=float)
        x = [summ[reg][s]["total_budget"] for s in sc]
        agg = [summ[reg][s]["pop_tv"] for s in sc]
        for m in ("single", "multi", "aus", "baus"):
            _band(ax[k], x, agg, m, "-o" if m == "baus" else "-s")
        ax[k].set_xscale("log"); ax[k].set_yscale("log")
        ax[k].set_xlabel("total force-evaluation budget"); ax[k].set_title(f"Regime {reg}", fontsize=10)
        ax[k].legend(fontsize=8, loc="lower left")
    ax[0].set_ylabel("basin-population total-variation error")
    fig.suptitle("Population convergence vs matched budget (median, 25–75% band; 20 seeds) — BAUS removes multi-seed "
                 "bias; bidirectional beats forward-only AUS", fontsize=10.5)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / "fig_v2_pop_convergence.png", dpi=200); plt.close(fig)


def fig_kinetics(summ):
    fig, ax = plt.subplots(1, 2, figsize=(14, 5.2))
    for k, reg in enumerate(["S"]):
        sc = sorted(summ[reg], key=float)
        xtr = [summ[reg][s]["ab_transitions"]["median"] for s in sc]
        for m in ("msm", "bata"):
            agg = [summ[reg][s]["stat_tv"] for s in sc]
            med = [a[m]["median"] for a in agg]
            ax[0].plot(xtr, med, "-o" if m == "bata" else "-s", c=CLR[m],
                       label=f"{LAB[m]} ({reg})", alpha=0.5 + 0.5 * (reg == "H"))
        for m in ("msm", "bata", "tram"):
            agg = [summ[reg][s]["its_relerr"] for s in sc]
            med = [a[m]["median"] if a[m]["median"] is not None else np.nan for a in agg]
            ax[1].plot(xtr, med, "-o" if m == "bata" else ("-s" if m == "msm" else "-^"), c=CLR[m],
                       label=f"{LAB[m]} ({reg})", alpha=0.5 + 0.5 * (reg == "H"))
    ax[0].set_xscale("log"); ax[0].set_yscale("log")
    ax[0].set_xlabel("# committed A↔B cold transitions"); ax[0].set_ylabel("stationary-distribution TV error")
    ax[0].set_title("stationary populations: BAIS (fixed BAUS π) removes the\nmulti-seed bias that free-π MSM carries",
                    fontsize=9.5); ax[0].legend(fontsize=7.5)
    ax[1].set_xscale("log"); ax[1].set_yscale("log")
    ax[1].set_xlabel("# committed A↔B cold transitions"); ax[1].set_ylabel("slow ITS relative error (vs FP truth)")
    ax[1].set_title("kinetics (ITS): BAIS helps when transitions are sparse;\nfree-π MSM is as good when counts are "
                    "rich (unresolved→NaN)", fontsize=9.5); ax[1].legend(fontsize=7.5)
    fig.suptitle("Kinetic results — BAIS vs free-π MSM on the SAME cold trajectories (median, 20 seeds)", fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / "fig_v2_kinetics.png", dpi=200); plt.close(fig)


def fig_pmf():
    """One representative BAUS reconstruction (Regime S) with the analytic PMF, cold baselines, and coverage mask."""
    from escort_ais.methods.baus import reconstruct_pmf
    from escort_ais.systems.toy1d import wrap
    t = Toy1D(kappa=REGIMES["S"]["kappa"]); rng = np.random.default_rng(7)
    ana = t.populations(); wells = np.radians(ana["well_centers_deg"]); bnd = np.radians(ana["boundaries_deg"]); nb = 3
    NG = 90; edges = np.linspace(-np.pi, np.pi, NG + 1); ctr = 0.5 * (edges[:-1] + edges[1:]); deg = np.degrees(ctr)
    F_true = t.U_cold(ctr); F_true -= F_true.min()
    hot = t.sample_boltzmann(t.s_hot, 60000, rng); xh = hot[rng.integers(0, len(hot), 3000)]
    land, lwf = t.ais_switch(xh, t.s_hot, 1.0, m_steps=10, freq=6, rng=rng)
    lb = t.basin_of(land, bnd).astype(int); us_s, Wr, rs = [], [], []
    for b in range(nb):
        us = t.us_sample(wells[b], np.radians(45.0), 6000, rng, k=250, burn=600, walkers=10); us_s.append(us)
        ui = us[t.basin_of(us, bnd).astype(int) == b]
        _, lwr = t.ais_switch(ui[rng.integers(0, len(ui), 3000)], 1.0, t.s_hot, m_steps=10, freq=6, rng=rng)
        Wr.append(-lwr); rs.append(np.full(len(lwr), b))
    out = reconstruct_pmf(ctr, edges, -lwf, lb, np.concatenate(Wr), np.concatenate(rs), us_s, nb, bnd, t.basin_of)
    single = wrap(t.langevin(np.array([wells[1]]), 120000, 1.0, rng)[:, 0])
    h, _ = np.histogram(single, bins=edges, density=True); Fs = np.full(NG, np.nan); m = h > 0
    Fs[m] = -np.log(h[m]); Fs -= np.nanmin(Fs)
    fig, ax = plt.subplots(1, 2, figsize=(14, 5.0))
    ax[0].plot(deg, F_true, "k-", lw=2.5, label="analytic PMF")
    ax[0].plot(deg, out["F"], "-o", c="C2", ms=3, label=f"BAUS (coverage {out['coverage']:.2f})")
    ax[0].plot(deg, Fs, "-", c="C0", lw=1.3, label="single-walker cold (traps in A)")
    ax[0].set_xlabel("θ (deg)"); ax[0].set_ylabel("F(θ) (kT), min→0"); ax[0].set_xlim(-180, 180)
    ax[0].set_ylim(-0.5, 12); ax[0].legend(fontsize=8)
    ax[0].set_title("PMF reconstruction — BAUS resolves wells+approaches;\nbasin umbrellas under-cover the barrier "
                    "tops (honest gap)", fontsize=9.5)
    ax[1].bar(deg, np.isfinite(out["F"]).astype(float), width=360 / NG, color="C2", alpha=0.5, label="BAUS covered")
    ax[1].bar(deg, -np.isfinite(Fs).astype(float), width=360 / NG, color="C0", alpha=0.5, label="single covered")
    ax[1].set_xlabel("θ (deg)"); ax[1].set_ylabel("covered (up=BAUS, down=single)"); ax[1].set_xlim(-180, 180)
    ax[1].set_title("angular coverage mask (single-walker misses B entirely)", fontsize=9.5); ax[1].legend(fontsize=8)
    fig.suptitle("PMF reconstruction and coverage (Regime S, one seed)", fontsize=11)
    panel_labels(fig); fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / "fig_v2_pmf.png", dpi=200); plt.close(fig)


def fig_phase(raw):
    fig, ax = plt.subplots(figsize=(8.5, 6.2))
    for r in raw:
        n_ab = max(r["ab_transitions"], 0.5)
        ess = np.nanmean([e for e in r["ess_fwd"] if e is not None]) if any(e is not None for e in r["ess_fwd"]) else 1
        resolved = r["resolved"]
        c = "C2" if resolved else "C3"
        ax.scatter(n_ab, ess, s=18, c=c, alpha=0.5, marker=("o" if r["regime"] == "S" else "s"))
    ax.axvline(30, ls="--", c="0.5"); ax.text(35, ax.get_ylim()[1] * 0.5 if False else 1e3,
                                              "few A↔B transitions →\nkinetics unresolved (NaN)", fontsize=8, color="C3")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("# committed cold A↔B transitions"); ax.set_ylabel("forward-AIS ESS (BAUS/BAIS population signal)")
    ax.set_title("Phase diagram — green: BAIS ITS resolved; red: unresolved (reported NaN, never a hot rate).\n"
                 "○ Regime S, □ Regime H. BAUS/BAIS fix populations across the whole plane; kinetics need cold "
                 "transitions.", fontsize=9.5)
    from matplotlib.lines import Line2D
    ax.legend(handles=[Line2D([], [], marker="o", ls="", c="C2", label="ITS resolved"),
                       Line2D([], [], marker="o", ls="", c="C3", label="ITS unresolved (NaN)")], fontsize=8)
    panel_labels(fig); fig.tight_layout()
    fig.savefig(OUT / "fig_v2_phase.png", dpi=200); plt.close(fig)


def main():
    d = json.load(open(OUT / "baus_bata_v2_summary.json")); summ = d["summary"]
    raw = json.load(open(OUT / "baus_bata_v2_raw.json"))
    fig_problem(); fig_convergence(summ); fig_kinetics(summ); fig_pmf(); fig_phase(raw)
    for f in ("problem", "pop_convergence", "kinetics", "pmf", "phase"):
        print(f"  wrote {OUT / ('fig_v2_' + f + '.png')}", file=sys.stderr)


if __name__ == "__main__":
    main()
