#!/usr/bin/env python
"""demo_kinetic_tree.py — recursive-split kinetic tree (BAIS hierarchical state definition) on the 1-D toy.

Illustrates that the metastability tree built by recursive spectral bisection of the cold MSM (kinetic_tree.py) is
*thermodynamically complete* (every leaf carries a BAUS population) but *kinetically partial*: a branch gets a
resolved rate only if the cold run actually crossed it, otherwise the branch is present structurally with an
`unresolved (NaN)` rate — kinetics are never manufactured for an unobserved transition.

Two cold observation windows on Regime S (A1↔A2 fast, A↔B slow):
  * SHORT — samples A1↔A2 many times but never crosses A↔B → the A↔B branch is a disconnected/structural cut (NaN).
  * LONG  — crosses A↔B too → the A↔B branch carries a resolved timescale.

Leaf populations are the analytic (BAUS-target) populations, distributed within each basin by the equilibrium
density; in the full pipeline these π come from BAUS/BAR, not from the cold histogram.

Run:  python -m escort_ais.experiments.misc.demo_kinetic_tree
Out:  results/toy/fig_v2_kinetic_tree.png, results/toy/kinetic_tree_demo.json
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from escort_ais.systems.toy1d import Toy1D, REGIME_S
from escort_ais.methods.kinetic_tree import recursive_split_tree, leaves, flatten_branches

OUT = Path("results/toy")
NBIN = 30                                         # microstates: uniform θ grid
LAG = 200                                         # count lag (frames)


def cold_counts(toy, n_steps, seeds_per_basin, rng, boundaries):
    """Run cold Langevin walkers seeded in every basin; return (C, dtraj_edges). C = lag-LAG microstate counts."""
    _, mins = toy.basins()
    x0 = np.repeat(mins, seeds_per_basin)                         # seed every basin so all are populated
    traj = toy.langevin(x0, n_steps, s=1.0, rng=rng, save_stride=1)   # (n_steps, K)
    edges = np.linspace(-np.pi, np.pi, NBIN + 1)
    C = np.zeros((NBIN, NBIN))
    d = np.clip(np.digitize(traj, edges) - 1, 0, NBIN - 1)        # (n_steps, K) microstate per walker per frame
    for k in range(d.shape[1]):                                   # count within each walker only (no cross-walker)
        a = d[:-LAG, k]; b = d[LAG:, k]
        np.add.at(C, (a, b), 1.0)
    return C, edges


def microstate_pi(toy, edges):
    """Analytic (BAUS-target) populations per microstate: equilibrium mass in each θ bin."""
    centers = 0.5 * (edges[:-1] + edges[1:])
    w = edges[1] - edges[0]
    p = toy.p_eq(centers) * w
    return p / p.sum()


def basin_label(members, edges, boundaries, toy):
    """Majority basin name (A1/A2/B) for a set of microstates, by their θ centers."""
    centers = 0.5 * (edges[:-1] + edges[1:])[members]
    b = toy.basin_of(centers, boundaries)
    names = np.array(["A1", "A2", "B"])                          # basins sorted by angle: A1(-120?),... use order
    # basins() returns mins sorted by angle; map basin index → name by well center sign
    _, mins = toy.basins()
    order = np.argsort(np.degrees(mins))
    deg = np.degrees(mins)
    # name by physical location: B near ±180/-120, A1/A2 near 60/120 etc. Use provided order A1<A2<B by populations.
    lab = np.bincount(b, minlength=len(mins)).argmax()
    return f"S{lab}", np.degrees(np.mean(centers))


# ---- tree layout (simple dendrogram) -------------------------------------------------
def _layout(node, x0, x1, depth, centers, pos):
    """Assign each node a horizontal span [x0,x1] and vertical level = depth; leaves get a center x."""
    node["_x0"], node["_x1"], node["_depth"] = x0, x1, depth
    node["_xc"] = 0.5 * (x0 + x1)
    if not node["children"]:
        node["_deg"] = float(np.degrees(np.mean(centers[node["members"]])))
        pos.append(node)
        return
    tot = sum(c["members"].size for c in node["children"])
    x = x0
    for c in node["children"]:
        frac = c["members"].size / tot
        _layout(c, x, x + frac * (x1 - x0), depth + 1, centers, pos)
        x += frac * (x1 - x0)


def draw_tree(ax, node, centers, title):
    pos = []
    _layout(node, 0.0, 1.0, 0, centers, pos)
    maxd = max(n["_depth"] for n in _all(node))

    def y(depth):
        return maxd - depth

    for nd in _all(node):
        if nd["children"]:
            for c in nd["children"]:
                col = "#2a7f2a" if c.get("_from_resolved", True) else "#b03030"
                # branch resolved flag lives on the PARENT split; color the edge by parent's resolved
                col = "#2a7f2a" if nd["resolved"] else "#b03030"
                ls = "-" if nd["resolved"] else "--"
                ax.plot([nd["_xc"], c["_xc"]], [y(nd["_depth"]), y(c["_depth"])], color=col, ls=ls, lw=2, zorder=1)
    for nd in _all(node):
        if nd["children"]:
            lab = "unresolved\n(NaN)" if not nd["resolved"] else f"$t$≈{nd['split_its']:.0f} fr"
            col = "#2a7f2a" if nd["resolved"] else "#b03030"
            ax.scatter([nd["_xc"]], [y(nd["_depth"])], s=90, c="white", edgecolors=col, zorder=3, linewidths=2)
            ax.annotate(lab, (nd["_xc"], y(nd["_depth"])), textcoords="offset points", xytext=(8, 6),
                        fontsize=8, color=col, ha="left")
        else:
            ax.scatter([nd["_xc"]], [y(nd["_depth"])], s=240, c="#3b6fb0", edgecolors="k", zorder=3)
            ax.annotate(f"θ≈{nd['_deg']:+.0f}°\nπ={nd['pop']:.2f}", (nd["_xc"], y(nd["_depth"])),
                        textcoords="offset points", xytext=(0, -12), ha="center", va="top",
                        fontsize=8.5, color="#1a1a1a", zorder=4)
    ax.set_title(title, fontsize=10)
    ax.set_xlim(-0.08, 1.08); ax.set_ylim(-1.05, maxd + 0.8)
    ax.set_ylabel("kinetic depth\n(slowest at top)", fontsize=8)
    ax.set_xticks([]); ax.set_yticks(range(maxd + 1)); ax.set_yticklabels([f"{maxd-i}" for i in range(maxd + 1)], fontsize=7)


def _all(node):
    out = [node]
    for c in node["children"]:
        out.extend(_all(c))
    return out


def summarize(node):
    return dict(n_leaves=len(leaves(node)),
                leaf_pops=[round(float(l["pop"]), 3) for l in leaves(node)],
                branches=[dict(depth=b["depth"],
                               its=(None if np.isnan(b["split_its"]) else round(float(b["split_its"]), 1)),
                               resolved=bool(b["resolved"]), sizes=[int(s) for s in b["sizes"]])
                          for b in flatten_branches(node)])


def main():
    toy = Toy1D(kappa=REGIME_S["kappa"])
    boundaries, _ = toy.basins()
    rng = np.random.default_rng(20260711)

    C_short, edges = cold_counts(toy, n_steps=25_000, seeds_per_basin=24, rng=rng, boundaries=boundaries)
    C_long, _ = cold_counts(toy, n_steps=400_000, seeds_per_basin=24, rng=rng, boundaries=boundaries)
    pi_full = microstate_pi(toy, edges)
    centers_full = 0.5 * (edges[:-1] + edges[1:])

    def build(C, tcold):
        """Restrict to VISITED microstates (unvisited barrier-top bins are not kinetically placeable), then split."""
        keep = np.nonzero((C + C.T).sum(1) > 0)[0]
        Ck = C[np.ix_(keep, keep)]
        pik = pi_full[keep]; pik = pik / pik.sum()
        return recursive_split_tree(Ck, lag=LAG, tcold=tcold, pi=pik, gap_floor_its=2 * LAG), centers_full[keep]

    # tcold ≈ trajectory length (frames) sets the resolution window; gap_floor separates real metastable gaps
    tree_short, cen_short = build(C_short, tcold=25_000)
    tree_long, cen_long = build(C_long, tcold=400_000)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))
    draw_tree(axes[0], tree_short, cen_short,
              "SHORT cold (25k fr): A↔B never crossed\n→ structural branch, rate unresolved (NaN)")
    draw_tree(axes[1], tree_long, cen_long,
              "LONG cold (400k fr): A↔B crossed\n→ branch carries a resolved timescale")
    from matplotlib.lines import Line2D
    fig.legend(handles=[Line2D([0], [0], color="#2a7f2a", lw=2, label="resolved transition (cold observed it)"),
                        Line2D([0], [0], color="#b03030", lw=2, ls="--", label="unresolved / structural (NaN rate)"),
                        Line2D([0], [0], marker="o", color="w", markerfacecolor="#3b6fb0", markersize=11,
                               label="metastable leaf (BAUS population π)")],
               loc="lower center", ncol=3, fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("BAIS hierarchical states: recursive spectral bisection of the cold MSM\n"
                 "populations complete at every leaf; kinetics only where the cold run sampled the transition",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0.06, 1, 0.94])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_v2_kinetic_tree.png", dpi=150)
    print("  wrote", OUT / "fig_v2_kinetic_tree.png")

    (OUT / "kinetic_tree_demo.json").write_text(json.dumps(
        dict(lag=LAG, nbin=NBIN, short=summarize(tree_short), long=summarize(tree_long)), indent=2))
    print("  short:", summarize(tree_short))
    print("  long :", summarize(tree_long))


if __name__ == "__main__":
    main()
