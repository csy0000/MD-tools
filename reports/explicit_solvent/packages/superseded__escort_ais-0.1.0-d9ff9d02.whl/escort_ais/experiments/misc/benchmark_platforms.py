#!/usr/bin/env python
"""CUDA vs OpenCL smoke benchmark for the RGD implicit-solvent systems: cold MD, hot MD, REMD.

Builds the same GBn2/mbondi3 REST2-scaled systems the production runs use, times production stepping on a
given platform+device (after a short warm-up), and reports ns/day. REMD mode times the 6-rung ladder
(all replicas stepped once per swap interval), the real per-swap MD cost.

    conda activate escort-ais && python -m escort_ais.experiments.misc.benchmark_platforms \
        --platform CUDA --device 2      # then --platform OpenCL --device 2
"""
from __future__ import annotations
import argparse, sys, time
from pathlib import Path
import numpy as np, parmed as pmd
from parmed.tools import changeRadii
import openmm as mm
from openmm import unit
from openmm.app import GBn2, NoCutoff, HBonds

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.openmm_system import build_rest2_scaled_system

LADDER = [1.0, 0.81, 0.64, 0.49, 0.36, 0.25]   # 6-rung REMD


def build_base(cfg):
    st = pmd.load_file(str(cfg.prmtop), xyz=str(cfg.inpcrd))
    changeRadii(st, "mbondi3").execute()
    base = st.createSystem(implicitSolvent=GBn2, nonbondedMethod=NoCutoff, constraints=HBonds,
                           removeCMMotion=True)
    excl = np.load(cfg.omega)
    solute = np.arange(st.topology.getNumAtoms())
    return st, base, excl, solute


def make_ctx(st, base, excl, solute, s, platform, device, dt_fs=2.0):
    system = build_rest2_scaled_system(base, solute, s, exclude_central_bonds=excl)
    plat = mm.Platform.getPlatformByName(platform)
    props = {"Precision": "mixed"}
    props["DeviceIndex" if platform == "CUDA" else "OpenCLDeviceIndex"] = str(device)
    integ = mm.LangevinMiddleIntegrator(300 * unit.kelvin, 1.0 / unit.picosecond, dt_fs * unit.femtoseconds)
    ctx = mm.Context(system, integ, plat, props)
    ctx.setPositions(st.positions)
    ctx.setVelocitiesToTemperature(300 * unit.kelvin)
    return ctx, integ


def timed_nsday(ctxs, integs, warmup, steps, dt_fs=2.0):
    for c, ig in zip(ctxs, integs):
        ig.step(warmup)
        c.getState(getEnergy=True)                 # sync
    t0 = time.time()
    for c, ig in zip(ctxs, integs):
        ig.step(steps)
        c.getState(getEnergy=True)                 # sync each
    wall = time.time() - t0
    ns = len(ctxs) * steps * dt_fs / 1e6           # total simulated ns across contexts
    return ns / (wall / 86400.0), wall


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--platform", required=True, choices=["CUDA", "OpenCL"])
    ap.add_argument("--device", default="2")
    ap.add_argument("--warmup", type=int, default=2000)     # 4 ps
    ap.add_argument("--steps", type=int, default=10000)     # 20 ps timed
    args = ap.parse_args()
    cfg = load_cfg(args.name)
    st, base, excl, solute = build_base(cfg)
    print(f"=== {args.platform} on device {args.device} ({st.topology.getNumAtoms()} atoms) ===", flush=True)

    # [1] cold MD (s=1.0), [2] hot MD (s=0.25) — single context
    for label, s in [("cold MD (s=1.0)", 1.0), ("hot MD  (s=0.25)", 0.25)]:
        ctx, ig = make_ctx(st, base, excl, solute, s, args.platform, args.device)
        nsday, wall = timed_nsday([ctx], [ig], args.warmup, args.steps)
        print(f"  [{label}] {nsday:7.1f} ns/day  ({nsday/24:.1f} ns/h; {args.steps*2/1000:.0f} ps in {wall:.1f}s)", flush=True)
        del ctx

    # [3] REMD — 6 rungs, aggregate stepping cost per swap interval
    ctxs, igs = [], []
    for s in LADDER:
        c, ig = make_ctx(st, base, excl, solute, s, args.platform, args.device)
        ctxs.append(c); igs.append(ig)
    nsday, wall = timed_nsday(ctxs, igs, args.warmup, args.steps)
    print(f"  [REMD 6-rung] {nsday:7.1f} ns/day aggregate ({nsday/6:.1f} ns/day per replica; "
          f"6x{args.steps*2/1000:.0f} ps in {wall:.1f}s)", flush=True)


if __name__ == "__main__":
    main()
