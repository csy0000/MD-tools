#!/usr/bin/env python3
"""test_reverse_coldlen.py -- does truncating the adaptive reservoir cold MD to a shorter length
restore the broad reverse work? Reuses the adaptive gen-0 FORWARD (fixed) and runs a fresh reverse AIS
from cold configs pooled over only the first --cold-ns of each reservoir seed. Prints reverse W_r std and
the endpoint-restricted BAR ddF (minor), so 1 ns vs 5 ns can be compared with everything else held fixed.
"""
from __future__ import annotations
import argparse, glob, json, shutil, sys
from pathlib import Path
import numpy as np, mdtraj as md, pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel
from escort_ais.methods.endpoint_bar import endpoint_restricted_bar
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.methods.run_macrocycle_seedsource_swap import run_leg, largest_remainder, write_seed_dir


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--reservoir", default="data/rgd/diagnostics/adaptive_run/cold_md")
    ap.add_argument("--fwd-dir", default="data/rgd/diagnostics/adaptive_run/gen0/fwd")
    ap.add_argument("--cold-ns", type=float, default=1.0, help="use only the first cold-ns of each seed")
    ap.add_argument("--cold-burn-ps", type=float, default=50.0)
    ap.add_argument("--k", type=int, default=800)
    ap.add_argument("--s-hot", type=float, default=0.25); ap.add_argument("--switch-ps", type=float, default=5.0)
    ap.add_argument("--n-shards", type=int, default=4); ap.add_argument("--device", default="2")
    ap.add_argument("--out-dir", required=True); ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    cfg = load_cfg("rgd"); top = str(cfg.top_pdb); rng = np.random.default_rng(args.seed)
    m = BasinModel.load("data/rgd/basins_tica/basin_model_backbone.pkl"); nb = m.n_basins
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)

    # fixed forward from the adaptive gen0
    W_f = -pd.read_csv(Path(args.fwd_dir) / "ais_trajectory_summary.csv")["final_logw"].to_numpy()
    b_f = m.assign(md.load_dcd(str(Path(args.fwd_dir) / "ais_final_coordinates.dcd"), top=top))
    land = np.bincount(b_f, minlength=nb).astype(float)

    # pool reservoir over ONLY the first cold-ns (1 ps/frame)
    burn = int(round(args.cold_burn_ps)); keep = int(round(args.cold_ns * 1000)) - burn
    xs, bs, top0 = [], [], None
    for s in sorted(glob.glob(args.reservoir + "/seed_*/trajectory.dcd")):
        t = md.load_dcd(s, top=top)[burn:burn + keep]
        xs.append(t.xyz); bs.append(m.assign(t)); top0 = t.topology
    res_xyz = np.concatenate(xs); res_basin = np.concatenate(bs)
    print(f"reservoir pooled over first {args.cold_ns} ns: {len(res_basin)} frames, "
          f"basins {np.bincount(res_basin, minlength=nb).tolist()}", flush=True)

    # reverse seeds matched to forward landing
    usable = np.array([b for b in range(nb) if land[b] > 0 and (res_basin == b).sum() > 0])
    alloc = largest_remainder(land[usable], args.k)
    rp, b_r0 = [], []
    for B, n in zip(usable, alloc):
        sel = rng.choice(np.where(res_basin == B)[0], int(n), replace=True); rp.append(res_xyz[sel]); b_r0 += [int(B)]*int(n)
    rseed = out / "seed_cold"; rseed.mkdir(parents=True, exist_ok=True)
    md.Trajectory(np.concatenate(rp), top0).save_dcd(str(rseed / "trajectory.dcd"))
    shutil.copy2(cfg.top_pdb, rseed / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(cfg.prmtop), inpcrd_path=str(cfg.inpcrd), gb_model="GBn2", gb_radii="mbondi3",
                   n_solute_atoms=cfg.n_solute_atoms, timestep_fs=2.0, friction_per_ps=1.0, temperature_k=300.0,
                   solvent="implicit"), open(rseed / "config.json", "w"), indent=2)

    logw, sel = run_leg(rseed, out / "rev", len(b_r0), 1.0, args.s_hot, args.switch_ps, args.n_shards,
                        10, "OpenCL", args.seed, cfg, devices=args.device)
    W_r = -logw; b_r = np.array(b_r0)[sel]
    print(f"\n=== cold-ns={args.cold_ns}: reverse W_r mean {W_r.mean():.0f} STD {W_r.std():.1f} "
          f"(minor std {W_r[b_r==1].std():.1f}, major std {W_r[b_r==0].std():.1f}) ===", flush=True)
    res = endpoint_restricted_bar(W_f, b_f, W_r, b_r, list(range(nb)), reference_basin=0,
                                  bootstrap=True, n_bootstrap=1000, rng=rng)
    ci = np.asarray(res["ddF"])  # ddF per basin
    print(f"BAR ddF (minor) = {res['ddF'][1]:.2f} kT   [reference 1.11]", flush=True)
    for B in (0, 1):
        d = res["diagnostics"][B]
        print(f"  basin {B}: overlap {d.get('overlap_score'):.2f}  ci [{d.get('bootstrap_95ci_low')},"
              f"{d.get('bootstrap_95ci_high')}]", flush=True)
    json.dump(dict(cold_ns=args.cold_ns, W_r_std=float(W_r.std()), ddF_minor=float(res["ddF"][1])),
              open(out / "result.json", "w"), indent=2)


if __name__ == "__main__":
    main()
