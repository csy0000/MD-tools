"""Cold reference p(x) for the conditional-BAR campaign, pooled over ALL REST2-REMD replicas.

Step 3 of the 2026-07-29 campaign protocol.  The single-replica cold reference
(``run_mixture_cft_oracle.load_cold_reference``) uses only the ``s=1`` slot and therefore throws
away 5/6 of the REMD sampling.  Here every frame from every replica slot enters a single MBAR
solve over the 6 REST2 states, and the resulting per-frame weights at ``s=1`` define the cold
probability ``p(x)``.  The rare substates gain the most: they are visited far more often at
``s<1``, so pooling raises their effective sample size without touching the estimand.

The reduced potential is ``u_l(x) = U_{s_l}(x) / (k_B T_base)`` with a single ``T_base = 300 K``
thermostat for every replica -- REST2 scales the *Hamiltonian*, not the temperature.

CRITICAL: the base system must be built through the same ``gb_radii='mbondi3'`` (parmed
``changeRadii``) branch as the AIS legs.  ``AmberPrmtopFile.createSystem`` differs by 16.6 kJ/mol
at identical radii, which would put ``p(x)`` on a different Hamiltonian than the works.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.methods.barrier_partition import assign_basins, partition_from_dict

ROOT = project_root()
REMD_DIR = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_mbondi3_6rep_300K_remd_100ns"
PRMTOP = ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.prmtop"
INPCRD = ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.inpcrd"
GB_RADII = "mbondi3"
N_SOLUTE = 22
T_BASE_K = 300.0
KB_KJ = 0.0083144621
KT_KJ = KB_KJ * T_BASE_K


def _build_base_system():
    """Base (unscaled) OpenMM system on the SAME builder branch as the AIS legs."""
    import parmed
    from openmm import app

    struct = parmed.load_file(str(PRMTOP), str(INPCRD))
    parmed.tools.changeRadii(struct, GB_RADII).execute()
    return struct.createSystem(implicitSolvent=app.GBn2, nonbondedMethod=app.NoCutoff,
                               constraints=app.HBonds, removeCMMotion=True)


def load_all_replicas(remd_dir: Path, burn_in: int, stride: int):
    """Pooled coordinates, torsions and per-frame origin replica over every REMD slot."""
    import mdtraj as md

    top = remd_dir / "start_structure_minimized.pdb"
    xyz, phi, psi, origin = [], [], [], []
    slots = sorted(p for p in remd_dir.glob("replica_*") if p.is_dir())
    for k, slot in enumerate(slots):
        t = md.load_dcd(str(slot / "trajectory.dcd"), top=str(top))[burn_in:][::stride]
        xyz.append(t.xyz)
        phi.append(md.compute_phi(t)[1][:, 0])
        psi.append(md.compute_psi(t)[1][:, 0])
        origin.append(np.full(t.n_frames, k, int))
        print(f"[cold-ref] {slot.name}: {t.n_frames} frames")
    return (np.concatenate(xyz), np.concatenate(phi), np.concatenate(psi),
            np.concatenate(origin), len(slots), top)


def reduced_potentials(xyz: np.ndarray, scale_factors, platform_name: str) -> np.ndarray:
    """``u_kn[l, n] = U_{s_l}(x_n) / kT`` -- one context per REST2 state, reused across frames."""
    from openmm import LangevinMiddleIntegrator, Platform, unit

    from escort_ais.systems.openmm_system import build_rest2_scaled_system

    base = _build_base_system()
    solute = np.arange(N_SOLUTE)
    platform = Platform.getPlatformByName(platform_name)
    props = {"Precision": "mixed"} if platform_name in ("CUDA", "OpenCL") else {}

    from openmm import Context
    u_kn = np.empty((len(scale_factors), len(xyz)), float)
    for l, s in enumerate(scale_factors):
        system = build_rest2_scaled_system(base, solute, float(s))
        integ = LangevinMiddleIntegrator(T_BASE_K, 1.0, 0.002)
        ctx = Context(system, integ, platform, props)
        for n in range(len(xyz)):
            ctx.setPositions(xyz[n])
            e = ctx.getState(getEnergy=True).getPotentialEnergy()
            u_kn[l, n] = e.value_in_unit(unit.kilojoule_per_mole) / KT_KJ
        print(f"[cold-ref] state s={s:.2f}: <u> = {u_kn[l].mean():+.3f} kT")
        del ctx, integ
    return u_kn


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--remd-dir", type=Path, default=REMD_DIR)
    ap.add_argument("--partition", type=Path,
                    default=ROOT / "reports/legacy/alanine/20260729_campaign_v1/basin_tree.json")
    ap.add_argument("--out", type=Path,
                    default=ROOT / "reports/alanine/remd_ground_truth/cold_reference.npz")
    ap.add_argument("--burn-in", type=int, default=100)
    ap.add_argument("--stride", type=int, default=2)
    ap.add_argument("--platform", default="CUDA")
    args = ap.parse_args(argv)

    cfg = json.loads((args.remd_dir / "config.json").read_text())
    scales = cfg["rest2_scale_factors"]
    print(f"[cold-ref] REST2 states: {scales}")

    xyz, phi, psi, origin, n_slots, _ = load_all_replicas(args.remd_dir, args.burn_in, args.stride)
    print(f"[cold-ref] pooled {len(phi)} frames over {n_slots} replicas")

    u_kn = reduced_potentials(xyz, scales, args.platform)
    n_k = np.array([(origin == k).sum() for k in range(n_slots)], int)

    from pymbar import MBAR
    mbar = MBAR(u_kn, n_k, solver_protocol="robust")
    # Per-frame weights in the COLD state (s = 1 is state 0).
    log_w = mbar.weights()[:, 0]
    w = np.asarray(log_w, float)
    w = w / w.sum()

    part = partition_from_dict(json.loads(args.partition.read_text()))
    labels = assign_basins(phi, psi, part)          # RADIANS -- PeriodicInterval works in radians
    if (labels < 0).any():
        raise RuntimeError(f"{int((labels < 0).sum())} frames fell outside an exhaustive partition")

    pi = np.array([w[labels == m].sum() for m in range(len(part))])
    ess = 1.0 / np.sum(w ** 2)
    # Single-replica reference for comparison (s=1 slot only, unweighted).
    cold_only = labels[origin == 0]
    pi_single = np.array([(cold_only == m).mean() for m in range(len(part))])

    f_kl = mbar.compute_free_energy_differences()["Delta_f"]
    print(f"\n[cold-ref] MBAR Kish ESS at s=1: {ess:.1f} of {len(w)} pooled frames "
          f"({len(cold_only)} in the s=1 slot alone)")
    print(" m    pi_m (ALL, MBAR)    pi_m (s=1 slot only)   ratio")
    for m in range(len(part)):
        print(f" B{m}   {pi[m]:.6f}            {pi_single[m]:.6f}          "
              f"{pi[m] / max(pi_single[m], 1e-30):.3f}")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    np.savez(args.out, pi=pi, pi_single=pi_single, weights=w, labels=labels, phi=phi, psi=psi,
             origin=origin, n_k=n_k, scales=np.asarray(scales), ess=ess, f_kl=f_kl,
             burn_in=args.burn_in, stride=args.stride)
    print(f"[cold-ref] wrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
