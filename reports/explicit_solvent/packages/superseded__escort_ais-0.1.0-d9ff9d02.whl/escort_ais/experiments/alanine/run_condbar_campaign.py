"""Iterative bidirectional AIS campaign for Disjoint-Substate Conditional BAR (step 6-7).

Per generation:
  (a) 200 forward AIS  H0 -> C0   at T_AIS = 1 ps, landings labelled by the 3 kT partition;
  (b) reverse AIS  C_m -> H0  from the hard-wall conditional ensemble pi_m, under two allocation
      arms sharing the SAME total reverse budget:
        equal-reverse : N_R,m = B / M            (100 per box at B = 300)
        ratio-reverse : N_R,m proportional to the forward landing counts of that generation;
  (c) per-box conditional BAR -> delta_m = f_H - f_m = -Delta_m.

Generation 0 is the forward-only Jarzynski landing estimate, so the plot starts from what the
landing weights alone would have said.

Reference: delta_m^ref = (f_H - f_C) + ln pi_m, with pi_m from the all-replica MBAR cold ensemble
and f_H - f_C = -DELTA_F_REF.  NOTE the sign: with the project convention f = -ln Z we have
pi_m = e^{f_C - f_m}, hence +ln pi_m (not -ln pi_m).

Reverse shots are drawn WITHOUT replacement from per-box banks of independent 1 ps legs, so no
generation reuses a trajectory and the arms never share a shot.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.methods.barrier_partition import assign_basins, partition_from_dict
from escort_ais.methods.conditional_bar import (conditional_bar_delta, jarzynski_delta,
                                                jensen_guard)

ROOT = project_root()
CAMPAIGN = ROOT / "reports/legacy/alanine/20260729_campaign_v1"
DATA = ROOT / "data/alanine_dipeptide/condbar_campaign"
HOT_SEED = ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"
REMD_DIR = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_mbondi3_6rep_300K_remd_100ns"

S_COLD, S_HOT = 1.0, 0.25
T_AIS, FREQ_AIS = 500, 1          # 500 steps x 2 fs = 1 ps
DELTA_F_REF = -48.18272933886123  # f_C - f_H  (REMD counting reference)
BANK_SIZES = {0: 4000, 1: 1100, 2: 1200}


def _cfg():
    from escort_ais.experiments.alanine.run_mixture_cft_oracle import (BASE_INPCRD, BASE_PRMTOP,
                                                                       GB_RADII)
    return dict(solvent="implicit", t_ais=T_AIS, freq_ais=FREQ_AIS, s_hot=S_HOT,
                omega_exclude=None, prmtop=BASE_PRMTOP, inpcrd=BASE_INPCRD,
                pdb=REMD_DIR / "start_structure_minimized.pdb",
                gb_radii=GB_RADII, n_solute_atoms=22, neq_integrator=True)


def _labels(phi_rad, psi_rad, part):
    return assign_basins(np.asarray(phi_rad), np.asarray(psi_rad), part)   # RADIANS


def load_partition():
    return partition_from_dict(json.loads((CAMPAIGN / "basin_tree.json").read_text()))


# ── step 6a: per-box reverse banks ───────────────────────────────────────────────────────────
def cmd_bank(args) -> int:
    """One bank of independent 1 ps reverse legs per box, seeded from the hard-wall pi_m."""
    import mdtraj as md

    from escort_ais.experiments.alanine.run_condbar_cold_reference import load_all_replicas
    from escort_ais.experiments.alanine.run_mixture_cft_oracle import SEED_CONFIG
    from escort_ais.methods.run_bais_standalone import _ais_leg

    part = load_partition()
    ref = np.load(CAMPAIGN / "cold_reference.npz")
    w, labels = ref["weights"], ref["labels"]

    xyz, phi, psi, _, _, top_path = load_all_replicas(REMD_DIR, int(ref["burn_in"]),
                                                      int(ref["stride"]))
    if len(xyz) != len(w):
        raise RuntimeError(f"pooled frames {len(xyz)} != cold-reference weights {len(w)}")
    ref_top = md.load(str(top_path))
    rng = np.random.default_rng(args.seed)
    out_root = Path(args.out or DATA / "reverse_banks")
    out_root.mkdir(parents=True, exist_ok=True)

    summary = {}
    for m in range(len(part)):
        n_shots = args.sizes.get(m, BANK_SIZES.get(m, 1000))
        inbox = np.flatnonzero(labels == m)
        p = w[inbox] / w[inbox].sum()
        ess_seed = 1.0 / np.sum(p ** 2)
        # Seed frames are drawn from pi_m = p(x | x in C_m) WITH replacement: the conditional
        # ensemble is only known through the finite REMD pool, so the seed ESS -- not n_shots --
        # bounds the independent information in the bank.  Reported, never hidden.
        pick = rng.choice(inbox, size=n_shots, replace=True, p=p)
        print(f"[bank] B{m}: {n_shots} legs from {len(inbox)} distinct frames "
              f"(seed ESS {ess_seed:.1f}, reuse factor {n_shots / ess_seed:.1f}x)")

        leg_dir = out_root / f"B{m}"
        if leg_dir.exists():
            shutil.rmtree(leg_dir)
        seed_dir = leg_dir / "seed"
        seed_dir.mkdir(parents=True, exist_ok=True)
        (seed_dir / "config.json").write_text(json.dumps(SEED_CONFIG))
        shutil.copy(top_path, seed_dir / "start_structure.pdb")
        md.Trajectory(xyz[pick], ref_top.topology).save_dcd(str(seed_dir / "trajectory.dcd"))

        W, _ = _ais_leg(seed_dir, leg_dir / "ais", _cfg(), n_shots, S_COLD, S_HOT,
                        args.platform, seed=70000 + 1000 * m, devices=args.devices)
        gj = jensen_guard(W, delta=-(-DELTA_F_REF + np.log(ref["pi"][m])))
        print(f"[bank] B{m}: <W_R> = {W.mean():+.3f} +/- {W.std() / np.sqrt(len(W)):.3f} kT   "
              f"(Jensen bound >= {gj['bound']:+.3f}; {'OK' if gj['ok'] else 'VIOLATED'})")
        np.savez(leg_dir / "bank.npz", W=W, seed_frames=pick, ess_seed=ess_seed)
        summary[f"B{m}"] = dict(n=int(n_shots), n_distinct=int(len(inbox)),
                                ess_seed=float(ess_seed), mean_W=float(W.mean()),
                                jensen_ok=bool(gj["ok"]), jensen_bound=float(gj["bound"]))
    (out_root / "bank_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return 0


# ── step 6b: the generation loop ─────────────────────────────────────────────────────────────
def _forward_generation(n_shots, platform, devices, seed):
    """One forward bank: reduced work + landing torsions.

    The scratch directory is keyed by n_shots as well as the seed: two campaigns differing only
    in --n-forward would otherwise rmtree and rewrite each other's legs if run concurrently.
    """
    import mdtraj as md

    from escort_ais.methods.run_bais_standalone import _ais_leg

    out = DATA / "gen_forward" / f"nf{n_shots}_seed{seed}"
    if out.exists():
        shutil.rmtree(out)
    W, land = _ais_leg(HOT_SEED, out, _cfg(), n_shots, S_HOT, S_COLD, platform,
                       seed=seed, devices=devices)
    phi = md.compute_phi(land)[1][:, 0]
    psi = md.compute_psi(land)[1][:, 0]
    return np.asarray(W, float), phi, psi


def _allocate(arm, counts, budget, n_boxes):
    if arm == "equal":
        base = budget // n_boxes
        return np.full(n_boxes, base, int)
    frac = counts / max(counts.sum(), 1)
    n = np.floor(frac * budget).astype(int)
    while n.sum() < budget:                       # hand out the remainder by largest fraction
        n[np.argmax(frac * budget - n)] += 1
    return n


def cmd_run(args) -> int:
    part = load_partition()
    n_boxes = len(part)
    ref = np.load(CAMPAIGN / "cold_reference.npz")
    pi_ref = ref["pi"]
    delta_ref = -DELTA_F_REF + np.log(pi_ref)     # f_H - f_C + ln pi_m

    banks, cursor = {}, {}
    for arm in ("equal", "ratio"):
        cursor[arm] = np.zeros(n_boxes, int)
    for m in range(n_boxes):
        b = np.load(DATA / "reverse_banks" / f"B{m}" / "bank.npz")
        W = np.asarray(b["W"], float)
        np.random.default_rng(1234 + m).shuffle(W)
        banks[m] = W

    print(f"reference  delta_m = {np.round(delta_ref, 4)}   pi = {np.round(pi_ref, 6)}")
    records, work_log = [], []
    for gen in range(args.generations + 1):
        seed = 90000 + 137 * gen
        Wf, phi, psi = _forward_generation(args.n_forward, args.platform, args.devices, seed)
        lab = _labels(phi, psi, part)
        counts = np.array([(lab == m).sum() for m in range(n_boxes)], int)
        work_log.append(dict(generation=gen, arm="-", box=-1, kind="forward",
                             work=Wf.copy(), labels=lab.copy(), phi=phi.copy(), psi=psi.copy()))

        # The forward-only Jarzynski landing estimate is recorded for EVERY generation, not just
        # gen 0: it is the baseline the conditional estimator is judged against, so it needs the
        # same number of independent replicates or the comparison is one draw against ten.
        dj = np.array([-jarzynski_delta(Wf, lab == m, n_forward=len(Wf))
                       for m in range(n_boxes)])
        row = dict(generation=gen, counts=counts.tolist(),
                   forward_mean_W=float(Wf.mean()), landing_delta=dj.tolist())
        if gen == 0:
            row["arms"] = {"landing": dict(delta=dj.tolist(),
                                           n_reverse=[0] * n_boxes)}
            print(f"\ngen 0  landing-only (Jarzynski): delta = {np.round(dj, 4)}  "
                  f"err = {np.round(dj - delta_ref, 4)}")
            records.append(row)
            continue

        row["arms"] = {}
        for arm in ("equal", "ratio"):
            alloc = _allocate(arm, counts, args.budget, n_boxes)
            deltas, n_rev, jok = [], [], []
            for m in range(n_boxes):
                take = int(alloc[m])
                c0, c1 = cursor[arm][m], cursor[arm][m] + take
                if c1 > len(banks[m]):
                    raise RuntimeError(f"bank B{m} exhausted for arm {arm} at generation {gen}: "
                                       f"needed {c1}, have {len(banks[m])}. Rebuild larger.")
                wr = banks[m][c0:c1]
                cursor[arm][m] = c1
                work_log.append(dict(generation=gen, arm=arm, box=m, kind="reverse",
                                     work=wr.copy()))
                if take == 0 or counts[m] == 0:
                    deltas.append(float("nan")); n_rev.append(take); jok.append(None)
                    continue
                d = conditional_bar_delta(Wf, lab == m, wr, n_forward=len(Wf))
                deltas.append(-d)                        # delta_m = f_H - f_m = -Delta_m
                n_rev.append(take)
                jok.append(bool(jensen_guard(wr, d)["ok"]))
            deltas = np.array(deltas, float)
            with np.errstate(over="ignore"):
                z = np.exp(deltas - np.nanmax(deltas))
            pi_hat = z / np.nansum(z)
            row["arms"][arm] = dict(delta=deltas.tolist(), n_reverse=n_rev, jensen_ok=jok,
                                    pi_hat=pi_hat.tolist(),
                                    rel_mass=(pi_hat / np.nanmax(pi_hat)).tolist())
            print(f"gen {gen} {arm:>5}  N_R={n_rev}  delta={np.round(deltas, 4)}  "
                  f"err={np.round(deltas - delta_ref, 4)}")
        records.append(row)

    out = dict(reference=dict(delta=delta_ref.tolist(), pi=pi_ref.tolist(),
                              rel_mass=(pi_ref / pi_ref.max()).tolist(),
                              delta_f_HC=DELTA_F_REF),
               protocol=dict(n_forward=args.n_forward, budget=args.budget,
                             generations=args.generations, t_ais_steps=T_AIS,
                             switch_ps=T_AIS * 0.002, s_hot=S_HOT, s_cold=S_COLD),
               generations=records)
    dest = Path(args.out or CAMPAIGN / "campaign_results.json")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(out, indent=2) + "\n")
    # Per-generation work arrays: the report shows the forward/reverse work distributions of
    # EVERY generation, which the JSON summary cannot carry.
    flat = {}
    for rec in work_log:
        key = f"{rec['kind']}_g{rec['generation']}_{rec['arm']}_b{rec['box']}"
        for field in ("work", "labels", "phi", "psi"):
            if field in rec:
                flat[f"{key}__{field}"] = rec[field]
    np.savez_compressed(dest.with_suffix(".works.npz"), **flat)
    print(f"\nwrote {dest} and {dest.with_suffix('.works.npz')}")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("bank", help="build the per-box reverse AIS banks")
    b.add_argument("--platform", default="CUDA")
    b.add_argument("--devices", default="0,1,2")
    b.add_argument("--seed", type=int, default=20260729)
    b.add_argument("--out", type=Path, default=None)
    b.add_argument("--sizes", default="")
    b.set_defaults(func=cmd_bank)

    r = sub.add_parser("run", help="run the generation loop")
    r.add_argument("--platform", default="CUDA")
    r.add_argument("--devices", default="0,1,2")
    r.add_argument("--generations", type=int, default=10)
    r.add_argument("--n-forward", type=int, default=200)
    r.add_argument("--budget", type=int, default=300)
    r.add_argument("--out", type=Path, default=None)
    r.set_defaults(func=cmd_run)

    args = ap.parse_args(argv)
    args.devices = [int(x) for x in str(args.devices).split(",")] if args.devices else None
    if getattr(args, "sizes", ""):
        args.sizes = {int(k): int(v) for k, v in (p.split(":") for p in args.sizes.split(","))}
    elif hasattr(args, "sizes"):
        args.sizes = {}
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
