#!/usr/bin/env python3
"""top100w_step12_select_seeds.py — Steps 1-2 of the top100w_diverse20_100ps test.

From the 1000 forward AIS endpoints (REMD-seeded forward leg):
  Step 1: rank by AIS weight e^{-W}=e^{lnw}, take the top-100, report weight-mass
          M_top100 and ESS diagnostics.
  Step 2: farthest-point-select 20 geometrically distinct seeds in the periodic
          cos/sin(phi,psi) feature space; export their endpoint structures (PDB)
          to seed cold MD.

Outputs -> results/top100w_diverse20_100ps/:
  ais_weight_diagnostics.json, selected_seeds.csv,
  plots/{ais_logweight_rank,ais_cumulative_weight,top100_selected20_phi_psi}.png,
  structures/seed_XXX.pdb (x20)

Usage:  python -m escort_ais.experiments.alanine.top100w_step12_select_seeds
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import load_phi_psi_dcd  # noqa: E402

# forward seed source + output dirs are experiment-specific (TOP100W_EXP):
#   diverse20_100ps -> REMD hot replica_03 forward;  remdfree_hot5ns -> 5 ns hot MD
from escort_ais.common.top100w_cfg import FWD, TOP_PDB, RESULTS as OUT  # noqa: E402
PLOTS = OUT / "plots"
STRUCT = OUT / "structures"
TOP_K, N_SEEDS = 100, 20


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--no-weight-gate", action="store_true",
                    help="farthest-point-select the 20 diverse seeds from ALL forward endpoints "
                         "(drop the top-100-by-weight gate; per the top100w REPORT recommendation)")
    args = ap.parse_args()

    for d in (OUT, PLOTS, STRUCT):
        d.mkdir(parents=True, exist_ok=True)

    logw = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].values  # lnw_f = -W_f
    Nf = len(logw)
    phi, psi = load_phi_psi_dcd(FWD / "ais_final_coordinates.dcd")
    order = np.argsort(logw)                      # ascending
    top = order[-TOP_K:]                          # top-100 by weight

    # ── Step 1: weight diagnostics ──
    lse_all = logsumexp(logw)
    M_top = float(np.exp(logsumexp(logw[top]) - lse_all))
    ess = lambda lw: float(np.exp(2 * logsumexp(lw) - logsumexp(2 * lw)))
    logw_sorted = np.sort(logw)
    diag = dict(
        N_forward=Nf, top_k=TOP_K, M_top100=M_top,
        ESS_all=ess(logw), ESS_top100=ess(logw[top]),
        logw_min_top100=float(logw[top].min()), logw_max_top100=float(logw[top].max()),
        logw_gap_100_101=float(logw_sorted[-TOP_K] - logw_sorted[-TOP_K - 1]),
    )
    (OUT / "ais_weight_diagnostics.json").write_text(json.dumps(diag, indent=2))
    print(f"  M_top100 = {M_top:.4f} | ESS_all = {diag['ESS_all']:.1f} | "
          f"ESS_top100 = {diag['ESS_top100']:.1f}")
    if M_top < 0.70:
        print("  WARNING: top-100 is a very aggressive truncation (M_top100 < 0.70).")
    elif M_top > 0.90:
        print("  PASS: top-100 captures most AIS weight (M_top100 > 0.90).")

    # ── Step 2: farthest-point selection on cos/sin(phi,psi) ──
    # pool = candidate endpoints for selection: top-100 by weight, or ALL (no gate)
    pool = np.arange(Nf) if args.no_weight_gate else top
    print(f"  seed-selection pool: {'ALL %d endpoints (no weight gate)' % Nf if args.no_weight_gate else 'top-%d by weight' % TOP_K}")
    feats_all = np.column_stack([np.cos(np.radians(phi)), np.sin(np.radians(phi)),
                                 np.cos(np.radians(psi)), np.sin(np.radians(psi))])
    F = feats_all[pool]
    lw_pool = logw[pool]
    sel = [int(np.argmax(lw_pool))]               # start at highest weight in the pool
    nearest = np.full(len(pool), np.inf)
    dist_at_pick = [0.0]
    for _ in range(1, N_SEEDS):
        d = np.linalg.norm(F - F[sel[-1]], axis=1)
        nearest = np.minimum(nearest, d)
        nearest[sel] = -1.0
        nxt = int(np.argmax(nearest))
        dist_at_pick.append(float(nearest[nxt]))
        sel.append(nxt)

    norm_w = np.exp(logw - lse_all)               # normalized weight over all 1000
    rank = np.empty(Nf, int); rank[order[::-1]] = np.arange(1, Nf + 1)   # 1=highest
    # export structures + table.  NOTE: ais_final_coordinates.dcd is written 10x too
    # small (nm values stored in the DCD's Angstrom field -> mdtraj reads them /10).
    # Dihedrals are scale-invariant so analyses were unaffected, but MD seeds need
    # the physical scale -> multiply xyz by 10.
    endpoints = md.load_dcd(str(FWD / "ais_final_coordinates.dcd"), top=str(TOP_PDB))
    endpoints.xyz = endpoints.xyz * 10.0
    rows = []
    for sid, j in enumerate(sel):
        fwd_idx = int(pool[j])
        sf = STRUCT / f"seed_{sid:03d}.pdb"
        endpoints[fwd_idx].save_pdb(str(sf))
        rows.append(dict(
            seed_id=sid, forward_index=fwd_idx, rank_by_weight=int(rank[fwd_idx]),
            logw=float(logw[fwd_idx]), normalized_weight=float(norm_w[fwd_idx]),
            phi=float(phi[fwd_idx]), psi=float(psi[fwd_idx]),
            feature_distance_to_nearest_selected=round(dist_at_pick[sid], 4),
            structure_file=str(sf.relative_to(ROOT)),
        ))
    pd.DataFrame(rows).to_csv(OUT / "selected_seeds.csv", index=False)
    print(f"  Selected {N_SEEDS} diverse seeds (phi/psi spread); structures -> {STRUCT.relative_to(ROOT)}")

    # ── plots ──
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(np.arange(1, Nf + 1), logw_sorted[::-1], lw=1.5)
    ax.axvline(TOP_K, color="r", ls="--", label=f"top {TOP_K}")
    ax.set_xlabel("rank by weight"); ax.set_ylabel("ln w (= -W)"); ax.legend()
    ax.set_title("AIS forward endpoint log-weights (sorted)")
    fig.tight_layout(); fig.savefig(str(PLOTS / "ais_logweight_rank.png"), dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4))
    w_sorted = np.exp(logw_sorted[::-1] - lse_all)
    ax.plot(np.arange(1, Nf + 1), np.cumsum(w_sorted), lw=2)
    ax.axvline(TOP_K, color="r", ls="--"); ax.axhline(M_top, color="g", ls=":")
    ax.set_xlabel("rank by weight"); ax.set_ylabel("cumulative normalized weight")
    ax.set_title(f"Cumulative AIS weight (top-100 = {M_top:.2f})"); ax.set_xlim(0, 300)
    fig.tight_layout(); fig.savefig(str(PLOTS / "ais_cumulative_weight.png"), dpi=130); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 5.5))
    ax.scatter(phi, psi, s=4, color="0.8", label="all 1000")
    ax.scatter(phi[pool], psi[pool], s=18, color="#4477AA",
               label=("pool (all)" if args.no_weight_gate else "top 100"))
    selp = [pool[j] for j in sel]
    ax.scatter(phi[selp], psi[selp], s=90, color="#EE6677", marker="*",
               edgecolor="k", label="selected 20")
    ax.set_xlabel(r"$\phi$ (deg)"); ax.set_ylabel(r"$\psi$ (deg)")
    ax.set_xlim(-180, 180); ax.set_ylim(-180, 180); ax.legend(fontsize=8)
    ax.set_title("Top-100 weighted endpoints + 20 diverse seeds")
    fig.tight_layout(); fig.savefig(str(PLOTS / "top100_selected20_phi_psi.png"), dpi=140); plt.close(fig)
    print(f"  Saved diagnostics, table, structures, plots -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
