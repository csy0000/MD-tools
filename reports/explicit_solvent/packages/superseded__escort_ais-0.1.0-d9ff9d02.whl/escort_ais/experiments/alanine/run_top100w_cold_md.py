#!/usr/bin/env python3
"""run_top100w_cold_md.py — Step 3: 20 x 100 ps cold MD from selected AIS endpoints.

Each selected diverse seed structure is relaxed at the cold physical Hamiltonian
(s=1.0, GBn2 implicit) for 100 ps, saving every 1 ps.  Single-seed mode (--seed N)
enables 10-wide GPU parallel launching (implicit MD ~88 MiB/worker).

Output: runs/top100w_diverse20_100ps/seed_XXX/{trajectory.dcd,states.csv,final_structure.pdb}
Usage:
  python -m escort_ais.experiments.alanine.run_top100w_cold_md --seed 0 --platform CUDA   # one seed
  python -m escort_ais.experiments.alanine.run_top100w_cold_md --platform CUDA            # all 20 (sequential)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import openmm
import openmm.app as app
import openmm.unit as u

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.top100w_cfg import RESULTS, RUNS  # noqa: E402
PRMTOP = ROOT / "data/topology/ff19sb_gbn2_even/system_scale_1p0.prmtop"
STRUCT = RESULTS / "structures"
N_SEEDS = 20
PROD_PS = 100.0
DT_FS = 2.0
SAVE_PS = 1.0
TEMP = 300.0


def run_seed(sid, platform, dt_fs=DT_FS, min_iter=500):
    seed_pdb = STRUCT / f"seed_{sid:03d}.pdb"
    out = RUNS / f"seed_{sid:03d}"
    out.mkdir(parents=True, exist_ok=True)
    prm = app.AmberPrmtopFile(str(PRMTOP))
    system = prm.createSystem(nonbondedMethod=app.NoCutoff, constraints=app.HBonds,
                              implicitSolvent=app.GBn2)
    integ = openmm.LangevinMiddleIntegrator(TEMP * u.kelvin, 1.0 / u.picosecond,
                                            dt_fs * u.femtoseconds)
    plat = openmm.Platform.getPlatformByName(platform)
    sim = app.Simulation(prm.topology, system, integ, plat)
    sim.context.setPositions(app.PDBFile(str(seed_pdb)).positions)
    sim.minimizeEnergy(maxIterations=min_iter)        # min_iter=0 -> until converged
    sim.context.setVelocitiesToTemperature(TEMP * u.kelvin, 1000 + sid)
    n_steps = int(round(PROD_PS * 1000 / dt_fs))      # 100 ps
    save_every = int(round(SAVE_PS * 1000 / dt_fs))   # 1 ps
    sim.reporters.append(app.DCDReporter(str(out / "trajectory.dcd"), save_every))
    sim.reporters.append(app.StateDataReporter(
        str(out / "states.csv"), save_every, step=True, time=True,
        potentialEnergy=True, temperature=True))
    sim.step(n_steps)
    state = sim.context.getState(getPositions=True)
    with open(out / "final_structure.pdb", "w") as fh:
        app.PDBFile.writeFile(prm.topology, state.getPositions(), fh)
    print(f"  seed {sid:03d}: {n_steps} steps ({PROD_PS:.0f} ps) -> {out.relative_to(ROOT)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seed", type=int, default=None, help="run ONLY this seed id")
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--dt-fs", type=float, default=DT_FS)
    ap.add_argument("--min-iter", type=int, default=500, help="0 = minimize to convergence")
    args = ap.parse_args()
    ids = [args.seed] if args.seed is not None else range(N_SEEDS)
    for sid in ids:
        run_seed(sid, args.platform, dt_fs=args.dt_fs, min_iter=args.min_iter)


if __name__ == "__main__":
    main()
