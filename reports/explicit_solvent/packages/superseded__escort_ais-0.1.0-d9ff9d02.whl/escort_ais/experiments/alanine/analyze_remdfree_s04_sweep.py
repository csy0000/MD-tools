#!/usr/bin/env python3
"""analyze_remdfree_s04_sweep.py — aggregate the REMD-free i-sweep into convergence plots.

Reads each i's geometric-4-basin estimators (results/remdfree_s04_sweep/i{ii}/
endpoint_estimators_summary_geo.csv) and compares, vs the converged 250 ns REMD
reference, on a cost-fair axis:
  B  (AIS, fwd-only)  cost = 3 + 5i ns
  C  (hot-unified BAR)   cost = 7 + 5i ns
  REMD (counting)     cost = 12i ns (= 3i ns/replica x 4)
Coverage = number of basins among {B1,B2,B3} actually resolved (finite).

Outputs -> results/remdfree_s04_sweep/:
  sweep_summary.csv, sweep_rmse_coverage.png, sweep_perbasin.png
Usage:  python -m escort_ais.experiments.alanine.analyze_remdfree_s04_sweep --imax 20
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import BURNIN_REMD, REMD_DIR, load_phi_psi_dcd  # noqa: E402
from escort_ais.analysis.remdfree_basins import assign as _assign, reference_ddF, NB as N_BASINS, BN, NAMES  # noqa: E402

SWEEP = ROOT / "results/remdfree_s04_sweep"
NS_PER_FRAME = 0.01


def rmse_cov(vals, ref):
    vals = np.asarray(vals, float); fin = np.isfinite(vals)
    rmse = float(np.sqrt(np.mean((vals[fin] - ref[fin]) ** 2))) if fin.any() else np.nan
    cov = int(np.isfinite(vals[1:]).sum())          # basins among B1,B2,B3 resolved
    return rmse, cov


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--imax", type=int, default=20)
    args = ap.parse_args()

    ref = reference_ddF()
    rph, rps = load_phi_psi_dcd(REMD_DIR / "replica_00/trajectory.dcd")
    rb = _assign(rph, rps)

    rows = []
    perb = {m: {b: [] for b in range(N_BASINS)} for m in ("C", "REMD")}
    Is = []
    for i in range(1, args.imax + 1):
        f = SWEEP / f"i{i:02d}/endpoint_estimators_summary_geo.csv"
        if not f.exists():
            print(f"  [i={i}] missing {f} -- skipping"); continue
        df = pd.read_csv(f, index_col=0)
        B = df.loc["AIS v2 (fwd-only, 8ns)"].to_numpy(float)[:N_BASINS]
        C = df.loc["hot-unified BAR (12ns)"].to_numpy(float)[:N_BASINS]
        # REMD baseline at 12i ns total = 3i ns/replica (counting)
        hi = BURNIN_REMD + int(round(3.0 * i / NS_PER_FRAME))
        pop = np.bincount(rb[BURNIN_REMD:hi], minlength=N_BASINS).astype(float)
        with np.errstate(divide="ignore"):
            R = -np.log(pop / pop[0])
        rmseB, covB = rmse_cov(B, ref); rmseC, covC = rmse_cov(C, ref); rmseR, covR = rmse_cov(R, ref)
        Is.append(i)
        rows.append(dict(i=i, hot_ns=5 * i, costB=3 + 5 * i, costC=7 + 5 * i, costREMD=12 * i,
                         rmseB=rmseB, covB=covB, rmseC=rmseC, covC=covC, rmseREMD=rmseR, covREMD=covR,
                         **{f"C_{BN[b]}": C[b] for b in range(N_BASINS)},
                         **{f"REMD_{BN[b]}": R[b] for b in range(N_BASINS)}))
        for b in range(N_BASINS):
            perb["C"][b].append(C[b]); perb["REMD"][b].append(R[b])
    sweep = pd.DataFrame(rows)
    sweep.round(3).to_csv(SWEEP / "sweep_summary.csv", index=False)
    print(sweep[["i", "hot_ns", "costB", "rmseB", "covB", "costC", "rmseC", "covC",
                 "costREMD", "rmseREMD", "covREMD"]].round(3).to_string(index=False))

    # ── RMSE + coverage vs cost ──
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 4.2))
    a1.plot(sweep.costB, sweep.rmseB, "o-", color="#0077BB", label="B: AIS (3+5i ns)")
    a1.plot(sweep.costC, sweep.rmseC, "s-", color="#CC3311", label="C: hot-unified BAR (7+5i ns)")
    a1.plot(sweep.costREMD, sweep.rmseREMD, "^-", color="black", label="REMD counting (12i ns)")
    a1.set_xlabel("total MD investment (ns)"); a1.set_ylabel("RMSE vs converged REMD (kT), covered basins")
    a1.set_title("Accuracy vs cost"); a1.grid(alpha=0.3); a1.legend(fontsize=9)
    a2.plot(sweep.costB, sweep.covB, "o-", color="#0077BB", label="B: AIS")
    a2.plot(sweep.costC, sweep.covC, "s-", color="#CC3311", label="C: hot-unified BAR")
    a2.plot(sweep.costREMD, sweep.covREMD, "^-", color="black", label="REMD")
    a2.set_xlabel("total MD investment (ns)"); a2.set_ylabel("basins resolved (of B1,B2,B3)")
    a2.set_yticks([0, 1, 2, 3]); a2.set_title("Coverage vs cost"); a2.grid(alpha=0.3); a2.legend(fontsize=9)
    fig.suptitle("REMD-free AIS vs REMD across hot-MD budget (i=1..%d, hot ensemble = 5i ns)" % args.imax,
                 fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(str(SWEEP / "sweep_rmse_coverage.png"), dpi=140); plt.close(fig)

    # ── per-basin ddF convergence (B1,B2,B3) vs hot-MD ns ──
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.8), squeeze=False)
    hot = np.array(Is) * 5
    for ax, b in zip(axes[0], range(1, N_BASINS)):
        ax.plot(hot, perb["C"][b], "s-", color="#CC3311", label="C: hot-unified BAR")
        ax.plot(np.array(Is) * 12, perb["REMD"][b], "^-", color="black", label="REMD @12i ns")
        ax.axhline(ref[b], color="0.5", ls=":", label="converged REMD")
        ax.set_title(f"{BN[b]} {NAMES[b]}"); ax.set_xlabel("MD investment (ns)")
        ax.grid(alpha=0.3); ax.set_ylim(0, 8)
    axes[0][0].set_ylabel(r"$\Delta\Delta F$ (kT)"); axes[0][0].legend(fontsize=8)
    fig.suptitle("Per-basin ddF convergence (geometric Ramachandran 4 basins)", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(str(SWEEP / "sweep_perbasin.png"), dpi=140); plt.close(fig)
    print(f"\n  Saved sweep_summary.csv + sweep_rmse_coverage.png + sweep_perbasin.png -> {SWEEP.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
