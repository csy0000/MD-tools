#!/usr/bin/env python3
"""analyze_top100w_rite_picking_variance.py — effect + variance of RITEWeight in
picking reverse-AIS start frames.

The reverse leg draws cold start frames from each basin's cold-MD pool.  Two ways:
  - RITE-weighted : draw ∝ w_i  (production)
  - uniform       : draw equal probability over the RITE support (w>0)
Both inject *stochastic-picking variance* into the estimator.  Using the cached
dense reverse AIS (reverse work per within-basin frame), we sweep the number of
frames drawn N_draw and, for each, take M independent resample draws -> the mean
ddF (the *effect* of the weighting) and the std of ddF over the M draws (the
*variance the picking adds*).  Forward leg is fixed; only the reverse is resampled.
v6 (endpoint-restricted BAR, bootstrap-free) is the per-basin estimator.

Outputs -> results/<exp>/:
  rite_picking_variance.csv, plots/rite_picking_variance.png, plots/rite_picking_effect.png
Usage:  TOP100W_EXP=diverse20_100ps \
          python -m escort_ais.experiments.alanine.analyze_top100w_rite_picking_variance
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_endpoint_partitioned import reference_ddF
from escort_ais.analysis.analyze_top100w_estimators import load_forward
from escort_ais.methods.endpoint_bar import endpoint_restricted_bar
from escort_ais.common.top100w_cfg import RESULTS as OUT, REVRUN

RITE = OUT / "rite"
PLOTS = OUT / "plots"
BN = ["B0", "B1", "B2", "B3"]
N_DRAWS = [25, 50, 100, 250, 500, 1000]
M_REP = 200
SCHEMES = {"RITE-weighted": "#EE7733", "uniform": "#0077BB"}


def ess(w):
    w = np.asarray(w, float)
    return float(w.sum() ** 2 / np.sum(w ** 2)) if w.sum() > 0 else 0.0


def main():
    PLOTS.mkdir(parents=True, exist_ok=True)
    ref = reference_ddF()
    W_f, a_f, b_f = load_forward()                       # forward fixed (cold-end basin = b_f)

    dz = np.load(REVRUN / "dense_reverse.npz")
    basins = sorted({int(k.split("_")[1]) for k in dz.files if k.startswith("W_")})
    dense = {B: dz[f"W_{B}"] for B in basins}
    weights, esss = {}, {}
    for B in basins:
        w = np.load(RITE / f"basin_{B}_default.npy").astype(float)
        ok = np.isfinite(dense[B])
        w = np.where(ok, w, 0.0)
        weights[B] = w
        esss[B] = ess(w)
    print(f"  basins {basins} | RITE ESS {{{', '.join(f'B{B}:{esss[B]:.0f}/{len(weights[B])}' for B in basins)}}}")

    rng = np.random.default_rng(11)
    rows = []
    for scheme in SCHEMES:
        for nd in N_DRAWS:
            dd = []                                       # (M_REP, N_BASINS) v6 ddF
            for _ in range(M_REP):
                W_r, b_r = [], []
                for B in basins:
                    w = weights[B]
                    if scheme == "RITE-weighted":
                        p = w / w.sum()
                    else:
                        sup = (w > 0).astype(float); p = sup / sup.sum()
                    pick = rng.choice(len(w), nd, replace=True, p=p)
                    W_r.append(dense[B][pick]); b_r.append(np.full(nd, B))
                W_r = np.concatenate(W_r); b_r = np.concatenate(b_r)
                res = endpoint_restricted_bar(W_f, b_f, W_r, b_r, basins, bootstrap=False)
                dd.append([res["ddF"].get(b, np.nan) for b in range(len(BN))])
            dd = np.array(dd)
            row = dict(scheme=scheme, N_draw=nd)
            for b in range(len(BN)):
                row[f"ddF_mean_{BN[b]}"] = float(np.nanmean(dd[:, b]))
                row[f"ddF_std_{BN[b]}"] = float(np.nanstd(dd[:, b]))
            # RMSE over covered basins (nan-penalized to ref)
            mean_dd = np.array([row[f"ddF_mean_{BN[b]}"] for b in range(len(BN))])
            e = np.where(np.isfinite(mean_dd), mean_dd, 0.0) - ref
            row["rmse"] = float(np.sqrt(np.mean(e ** 2)))
            rows.append(row)
            stds = ", ".join("B%d:%.3f" % (B, row["ddF_std_%s" % BN[B]]) for B in basins)
            print(f"  {scheme:13s} N={nd:4d}: rmse={row['rmse']:.3f} std={{{stds}}}")
    df = pd.DataFrame(rows)
    df.round(4).to_csv(OUT / "rite_picking_variance.csv", index=False)

    # reference basin (0) has ddF≡0 (std≡0) -> exclude from per-basin plots
    plot_basins = [B for B in basins if B != 0]

    # ── variance: std(ddF) vs N_draw (log-log) per basin ──
    nb = len(plot_basins)
    fig, axes = plt.subplots(1, nb, figsize=(4.2 * nb, 4), squeeze=False)
    for ax, B in zip(axes[0], plot_basins):
        for scheme, c in SCHEMES.items():
            s = df[df.scheme == scheme]
            ax.loglog(s.N_draw, s[f"ddF_std_{BN[B]}"], "o-", color=c, label=scheme)
        # 1/sqrt(N) guide anchored at the first uniform point
        s0 = df[(df.scheme == "uniform")]
        y0 = s0[f"ddF_std_{BN[B]}"].values[0]; n0 = s0.N_draw.values[0]
        ax.loglog(N_DRAWS, y0 * np.sqrt(n0 / np.array(N_DRAWS)), "k:", alpha=0.5, label=r"$\propto N^{-1/2}$")
        ax.axvline(esss[B], color="0.6", ls="--", alpha=0.7)
        ax.set_title(f"{BN[B]} (RITE ESS≈{esss[B]:.0f})"); ax.set_xlabel("N_draw / basin")
        ax.grid(alpha=0.3, which="both")
    axes[0][0].set_ylabel(r"std of v6 $\Delta\Delta F$ over resamples (kT)")
    axes[0][0].legend(fontsize=8)
    fig.suptitle(f"Variance from stochastic reverse-frame picking ({OUT.name})", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(str(PLOTS / "rite_picking_variance.png"), dpi=140); plt.close(fig)

    # ── effect: mean ddF ± std vs N_draw per basin ──
    fig, axes = plt.subplots(1, nb, figsize=(4.2 * nb, 4), squeeze=False)
    for ax, B in zip(axes[0], plot_basins):
        for scheme, c in SCHEMES.items():
            s = df[df.scheme == scheme]
            ax.errorbar(s.N_draw, s[f"ddF_mean_{BN[B]}"], yerr=s[f"ddF_std_{BN[B]}"],
                        fmt="o-", color=c, capsize=3, label=scheme)
        ax.axhline(ref[B], color="k", ls=":", label="REMD ref")
        ax.set_xscale("log"); ax.set_title(BN[B]); ax.set_xlabel("N_draw / basin"); ax.grid(alpha=0.3)
    axes[0][0].set_ylabel(r"v6 $\Delta\Delta F$ (kT)"); axes[0][0].legend(fontsize=8)
    fig.suptitle(f"Effect of RITE vs uniform reverse-frame picking ({OUT.name})", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(str(PLOTS / "rite_picking_effect.png"), dpi=140); plt.close(fig)
    print(f"  Saved rite_picking_variance.csv + 2 plots -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
