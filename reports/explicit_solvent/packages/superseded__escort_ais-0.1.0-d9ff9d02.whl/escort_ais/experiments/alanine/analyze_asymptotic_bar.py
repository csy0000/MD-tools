#!/usr/bin/env python3
"""analyze_asymptotic_bar.py — sequential AIS+BAR convergence on the existing remdfree_s04 sweep.

`--validate-existing-sweep` runs the asymptotic estimator over the 20 on-disk sweep rounds (i=1..20,
hot window [1,1+5i] ns, 2 ps switch), accumulating forward+reverse AIS works CUMULATIVELY and emitting,
per round, the combined-BAR and hot-unified BAR cold-basin ddF (with bootstrap CI), the per-basin BAR
overlap (confidence index), and ESS — versus the converged-REMD reference. This is a GPU-free sanity
check that the accumulator + both estimators converge; the user's production windowing ([20,100+5i] ns)
is run by scripts/run_asymptotic_bar.py.

Basins: geometric Ramachandran 4-basin model by default (src/escort_ais/analysis/remdfree_basins.py); --basis pcca uses
the fixed PCCA+ cold-MD model if built.

Usage:  python -m escort_ais.experiments.alanine.analyze_asymptotic_bar --validate-existing-sweep --imax 20
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import load_phi_psi_dcd  # noqa: E402
from escort_ais.methods.asymptotic_bar import Accumulator, RoundData, estimate  # noqa: E402
import escort_ais.analysis.remdfree_basins as geo  # noqa: E402

SWEEP = ROOT / "data/alanine_dipeptide/2026-06-18-remdfree-s04-sweep"
RUNS = ROOT / "data/runs/remdfree_s04_sweep"
RESULTS = ROOT / "results/remdfree_s04_sweep"
OUT = ROOT / "results/asymptotic_bar"
OUT.mkdir(parents=True, exist_ok=True)
BN = ["B0 C7eq", "B1 Lα", "B2 αR", "B3 C7ax"]


def load_round(i: int, assign) -> RoundData:
    fwd = SWEEP / f"i{i:02d}/step_forward_ais"
    logw_f = pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    W_f = -logw_f
    fidx = pd.read_csv(fwd / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    sph, sps = load_phi_psi_dcd(fwd.parent / "seed_hot/trajectory.dcd")
    a_f = assign(sph[fidx], sps[fidx])
    eph, eps = load_phi_psi_dcd(fwd / "ais_final_coordinates.dcd")
    b_f = assign(eph, eps)
    rev = SWEEP / f"i{i:02d}-revais"
    rvp = RESULTS / f"i{i:02d}/reverse_ais_results.npz"
    if rvp.exists():
        W_r = np.load(rvp)["reverse_work"]
    else:                                   # npz absent -> recover reduced reverse work from the revais AIS summary
        W_r = -pd.read_csv(rev / "step_reverse_ais/ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    cph, cps = load_phi_psi_dcd(rev / "seed_cold_uniform/trajectory.dcd")
    cold_basin = assign(cph, cps)
    sel = pd.read_csv(rev / "step_reverse_ais/selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    b_r = cold_basin[sel]
    reph, reps = load_phi_psi_dcd(rev / "step_reverse_ais/ais_final_coordinates.dcd")
    a_r = assign(reph, reps)
    return RoundData(W_f, a_f, b_f, W_r, b_r, a_r, hot_ns=5.0 * i)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--validate-existing-sweep", action="store_true")
    ap.add_argument("--imax", type=int, default=20)
    ap.add_argument("--basis", choices=["geometric", "pcca"], default="geometric")
    args = ap.parse_args()

    assign = geo.assign
    ref = geo.reference_ddF()
    nb = geo.NB
    print(f"reference ddF ({args.basis} basins): {np.round(ref, 3).tolist()}")

    acc = Accumulator()
    rng = np.random.default_rng(7)
    rows = []
    for i in range(1, args.imax + 1):
        try:
            acc.append(load_round(i, assign))
        except FileNotFoundError as e:
            print(f"  round i={i}: missing ({e}) — stop"); break
        res = estimate(acc, nb, reference_ddF=ref, bootstrap=True, n_bootstrap=150, rng=rng)
        rows.append(dict(
            round=i, hot_ns=5 * i, n_forward=res["n_forward"], n_reverse=res["n_reverse"],
            rmse_combined=res.get("rmse_combined_covered"), rmse_hotunified=res.get("rmse_hotunified_covered"),
            **{f"cmb_{BN[b][:2]}": res["ddF_combined"][b] for b in range(nb)},
            **{f"hub_{BN[b][:2]}": res["ddF_hotunified"][b] for b in range(nb)},
            **{f"ovl_{BN[b][:2]}": res["overlap"][b] for b in range(nb)},
            **{f"ess_{BN[b][:2]}": res["ess"][b] for b in range(nb)},
        ))
        conf = res["confidence"]
        print(f"  round {i:2d} (hot {5*i:3d}ns, {res['n_forward']} fwd): "
              f"RMSE cmb={rows[-1]['rmse_combined']:.3f} hub={rows[-1]['rmse_hotunified']:.3f} | "
              f"overlap={np.round(res['overlap'],2).tolist()} conf={conf}")
    df = pd.DataFrame(rows)
    df.round(4).to_csv(OUT / "asymptotic_validate_sweep.csv", index=False)

    # ── figures ──
    t = df["hot_ns"].to_numpy()
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.4))
    cmap = plt.cm.tab10
    for b in range(nb):
        axes[0].plot(t, df[f"cmb_{BN[b][:2]}"], "o-", color=cmap(b), label=BN[b])
        axes[0].plot(t, df[f"hub_{BN[b][:2]}"], "s--", color=cmap(b), alpha=0.6)
        axes[0].axhline(ref[b], color=cmap(b), ls=":", lw=1)
        axes[1].plot(t, df[f"ovl_{BN[b][:2]}"], "o-", color=cmap(b), label=BN[b])
    axes[0].set_title("Cold-basin ΔΔF vs cumulative hot-MD (● combined-BAR, □ hot-unified; : REMD ref)")
    axes[0].set_xlabel("cumulative hot ensemble (ns)"); axes[0].set_ylabel("ΔΔF (kT)")
    axes[0].legend(fontsize=8); axes[0].grid(alpha=0.3)
    axes[1].axhspan(0, 0.2, color="orange", alpha=0.12); axes[1].axhspan(0, 0.05, color="red", alpha=0.12)
    axes[1].set_title("BAR overlap (confidence index; <0.2 warn, <0.05 unreliable)")
    axes[1].set_xlabel("cumulative hot ensemble (ns)"); axes[1].set_ylabel("overlap score")
    axes[1].set_ylim(0, 1); axes[1].legend(fontsize=8); axes[1].grid(alpha=0.3)
    axes[2].plot(t, df["rmse_combined"], "o-", color="#0077BB", label="combined-BAR")
    axes[2].plot(t, df["rmse_hotunified"], "s-", color="#CC3311", label="hot-unified BAR")
    axes[2].set_title("RMSE vs converged REMD (covered basins)")
    axes[2].set_xlabel("cumulative hot ensemble (ns)"); axes[2].set_ylabel("RMSE (kT)")
    axes[2].legend(); axes[2].grid(alpha=0.3)
    fig.suptitle("Asymptotic AIS+BAR — cumulative convergence on the remdfree_s04 sweep "
                 "(estimator validation; switch fixed 2 ps)", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(OUT / "asymptotic_validate_sweep.png", dpi=150); plt.close(fig)
    print(f"\nSaved asymptotic_validate_sweep.csv + .png -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
