#!/usr/bin/env python3
"""run_remdfree_s04_forward_ais.py — forward AIS for the REMD-free s=0.4 experiment.

Seed forward AIS from the [1 ns, 5 ns] window of the standalone 250 ns single-walker
s=0.4 hot MD (10 ps/frame -> 400 frames in the window), anneal s=0.4 -> 1.0 with a
2 ps switch.  1000 trajectories are drawn WITH REPLACEMENT from the 400-frame window
(each AIS run reseeds velocities -> independent trajectories); cost = 1000 x 2 ps = 2 ns.
The whole method is REMD-free: the hot source is a plain single-walker MD.

Topology: the s=0.4 run shares the 22-atom ff19sb_gbn2_even (system_scale_1p0) system
with REMD, so build_seed_dir reuses the REMD pdb+config; we then replace the seed
trajectory with the sliced [1,5] ns window.

Usage:  TOP100W_EXP=remdfree_s04 \
          python -m escort_ais.experiments.alanine.run_remdfree_s04_forward_ais --platform CUDA
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

import mdtraj as md

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais  # noqa: E402
from run_remd_seeded_ais import build_seed_dir, REMD_DIR  # noqa: E402
from escort_ais.common.top100w_cfg import FWD, HOT_SRC  # noqa: E402   FWD=output dir; HOT_SRC=s0.4 250ns dcd

K_AIS, T_AIS, FREQ_AIS = 1000, 1000, 10        # 1000 trajs, 2 ps switch, 100 windows
NS_PER_FRAME = 0.01                            # 10 ps/frame
# seed window = [1 ns burn-in, 1 + 5*i ns]; i from REMDFREE_I (sweep), default i=1 -> [1,6] ns
_I = int(os.environ.get("REMDFREE_I", "1"))
WIN_NS = (1.0, 1.0 + 5.0 * _I)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    seed_dir = FWD.parent / "seed_hot"
    # build_seed_dir copies the REMD 22-atom pdb+config (shared system); symlinks full HOT_SRC
    build_seed_dir(HOT_SRC, REMD_DIR, seed_dir)
    lo, hi = int(round(WIN_NS[0] / NS_PER_FRAME)), int(round(WIN_NS[1] / NS_PER_FRAME))
    traj = md.load_dcd(str(HOT_SRC), top=str(seed_dir / "start_structure.pdb"))[lo:hi]
    link = seed_dir / "trajectory.dcd"
    if link.exists() or link.is_symlink():
        link.unlink()
    traj.save_dcd(str(link))
    print(f"  seed window [{WIN_NS[0]},{WIN_NS[1]}] ns = frames {lo}:{hi} ({traj.n_frames} frames); "
          f"k_ais={K_AIS} drawn with replacement -> {FWD}")

    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=K_AIS, t_ais=T_AIS, freq_ais=FREQ_AIS,
        s_hot=0.4, s_cold=1.0, seed=20260619,
        start_frame_offset=0, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=FWD,
        platform=args.platform, dry_run=args.dry_run, overwrite=True,
        save_traj_every_switch=False))


if __name__ == "__main__":
    main()
