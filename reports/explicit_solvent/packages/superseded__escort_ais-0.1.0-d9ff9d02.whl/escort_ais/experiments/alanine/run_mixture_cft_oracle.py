"""run_mixture_cft_oracle.py — Phase 2/4/5/7 driver for the alanine mixture-CFT validation.

Protocol (frozen inputs, seeds, blocks, conventions):
``docs/protocols/alanine_mixture_cft_validation.md``
Theory: ``docs/theory/alanine_cold_mixture_cft_theory.pdf``

The oracle stage replaces restrained MD by EXACT Zwanzig reweighting/resampling of the
converged REST2-REMD cold ensemble, so the proposal draws are exact and any discrepancy is
an estimator defect rather than a sampling defect.

Sub-commands
------------
``forward``       forward AIS (hot -> cold) with intermediate cold energies (save_switch_stride)
``reverse-bank``  reverse AIS (cold -> hot) bank over the block-B2 REMD frames, R replicates
                  per frame.  Built ONCE and reused for every allocation scenario, seed and
                  sample-size rung; a proposal draw consumes an unused (frame, replicate)
                  pair so no work value is ever reused within a scenario.
``analyze``       clustering -> frozen proposals -> tests 3a/3b -> ladder -> PMF -> report data

Run as::

    python -m escort_ais.experiments.alanine.run_mixture_cft_oracle forward      --k-ais 400
    python -m escort_ais.experiments.alanine.run_mixture_cft_oracle reverse-bank --replicates 3
    python -m escort_ais.experiments.alanine.run_mixture_cft_oracle analyze
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Sequence

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
from escort_ais.common.run_manifest import (RunManifest, config_hash, make_run_id,
                                            update_status, write_manifest)
from escort_ais.methods.mixture_cft import (crooks_residuals, effective_sample_size,
                                            fit_mixture_cft, je_initialization,
                                            normalized_mixture_weights, reweighted_pmf_2d,
                                            solve_delta_levelA, solve_offsets_mbar,
                                            zwanzig_offsets)

ROOT = project_root()

# ── frozen protocol constants (§1, §2, §4, §7 of the protocol document) ──────
KT_KJ = 2.4943387854
S_HOT, S_COLD = 0.25, 1.0
T_AIS, FREQ_AIS, SCALING_MODE = 2500, 1, "square"
DELTA_F_REF = -48.18272933886123          # REST2-REMD MBAR ladder, reduced
REMD_DIR = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_mbondi3_6rep_300K_remd_100ns"
HOT_DIR = ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"
PRMTOP = ROOT / "data/topology/ff19sb_gbn2_mbondi3/system_scale_1p0.prmtop"
INPCRD = ROOT / "data/topology/ff19sb_gbn2_mbondi3/system_scale_1p0.inpcrd"

# ── THE SYSTEM-BUILDER TRAP (see the 2026-07-27 protocol amendment) ─────────
# The RADII stored in the two prmtops are IDENTICAL, and `changeRadii mbondi3` changes
# nothing on disk.  What differs is the *builder*:
#   A: app.AmberPrmtopFile(...).createSystem(implicitSolvent=GBn2)
#   B: parmed.load_file(...) [+ changeRadii] .createSystem(implicitSolvent=GBn2)
# For alanine/GBn2 these differ by 16.6 kJ/mol, and because REST2 scales the GB term the
# difference does NOT cancel in the work: it injects 16.6 x (1-s) = 5.0 kT into every
# hot<->cold leg.  `ais_linear` selects B iff the seed config carries a "gb_radii" key.
# The forward AIS seed (the hot MD directory) carries it, so BOTH legs must.
BASE_PRMTOP = ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.prmtop"
BASE_INPCRD = ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.inpcrd"
GB_RADII = "mbondi3"
SEED_CONFIG = dict(prmtop_path=str(BASE_PRMTOP), inpcrd_path=str(BASE_INPCRD),
                   gb_radii=GB_RADII, gb_model="GBn2", n_solute_atoms=22)
OUT_ROOT = ROOT / "data/alanine_dipeptide/mixture_cft"
REPORT_ROOT = ROOT / "reports/alanine/mixture_cft"

REMD_BURN_IN, REMD_STRIDE = 100, 2
BLOCKS = {"B1": (0, 1650), "B2": (1650, 3300), "B3": (3300, 4950)}
SEED_FORWARD = 20260727
LADDER = (50, 100, 200, 500, 1000)


# ─────────────────────────────────────────────────────────────────────────────
# shared geometry: the flat-bottom proposal restraint (reused from bais_us)
# ─────────────────────────────────────────────────────────────────────────────
def dcv(angles_rad: np.ndarray, mu_rad: np.ndarray) -> np.ndarray:
    """D_m(x) = sum_t 2[1 - cos(theta_t - mu_t)] — bais_us.torsion_D, periodic."""
    from escort_ais.methods.bais_us import torsion_D
    return torsion_D(np.asarray(angles_rad, float), np.asarray(mu_rad, float))


def flat_bottom(angles_rad: np.ndarray, mu_rad, h: float, k: float) -> np.ndarray:
    """U_m = 1/2 k max(0, sqrt(D_m) - h)^2 in REDUCED units — bais_us.flatbottom_bias_D."""
    from escort_ais.methods.bais_us import flatbottom_bias_D
    return flatbottom_bias_D(dcv(angles_rad, mu_rad), h, k)


def rect_basin(p: dict):
    """Rebuild the :class:`RectangularBasin` carried by a ``rect_flatbottom`` proposal."""
    from escort_ais.methods.barrier_partition import partition_from_dict
    return partition_from_dict(dict(basins=[p["basin"]]))[0]


def proposal_bias(angles_rad: np.ndarray, p: dict) -> np.ndarray:
    """``U_m(x)`` in kT for one proposal, dispatching on its geometry.

    ``flatbottom_sqrtD`` — the circular torus window of the oracle_v1 design,
    ``U = 1/2 k max(0, sqrt(D) - h)^2``, whose flat core is a chord-radius disc.

    ``rect_flatbottom`` — a barrier-aligned periodic RECTANGLE (methods/barrier_partition.py),
    ``U = 1/2 k_phi d_out(phi)^2 + 1/2 k_psi d_out(psi)^2``, whose flat core is the rectangle
    itself and whose walls sit on the free-energy barriers rather than at a fitted radius.

    The cold substates are DISJOINT by construction; no intermediate/overlapping ensemble between
    them is admissible (2026-07-29 revision).
    """
    geom = p.get("geometry", "flatbottom_sqrtD")
    if geom == "flatbottom_sqrtD":
        return flat_bottom(angles_rad, np.asarray(p["mu"], float), p["h"], p["k"])
    if geom == "rect_flatbottom":
        from escort_ais.methods.rectangular_flatbottom import rect_bias_kT
        a = np.asarray(angles_rad, float)
        return rect_bias_kT(a[:, 0], a[:, 1], rect_basin(p))
    raise ValueError(f"unknown proposal geometry {geom!r}")


def proposal_core_mask(angles_rad: np.ndarray, p: dict) -> np.ndarray:
    """Boolean mask of the configurations inside a proposal's ZERO-force flat core."""
    geom = p.get("geometry", "flatbottom_sqrtD")
    a = np.asarray(angles_rad, float)
    if geom == "flatbottom_sqrtD":
        return np.sqrt(np.clip(dcv(a, np.asarray(p["mu"], float)), 0.0, None)) <= float(p["h"])
    if geom == "rect_flatbottom":
        return rect_basin(p).contains(a[:, 0], a[:, 1])
    raise ValueError(f"unknown proposal geometry {geom!r}")


def bias_matrix(angles_rad: np.ndarray, proposals: Sequence[dict]) -> np.ndarray:
    """(N, M) U_n(x_i) for EVERY proposal n — the balance-heuristic denominator input."""
    return np.column_stack([proposal_bias(angles_rad, p) for p in proposals])


# ─────────────────────────────────────────────────────────────────────────────
# REMD cold reference
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class ColdReference:
    phi: np.ndarray        # (N,) rad, post burn-in + stride
    psi: np.ndarray
    xyz: np.ndarray        # (N, natoms, 3) nm
    top_path: Path
    burn_in: int
    stride: int

    def angles(self, idx=None) -> np.ndarray:
        a = np.column_stack([self.phi, self.psi])
        return a if idx is None else a[idx]

    def block(self, name: str) -> np.ndarray:
        lo, hi = BLOCKS[name]
        return np.arange(lo, min(hi, len(self.phi)))


def load_cold_reference(remd_dir: Path = REMD_DIR, burn_in: int = REMD_BURN_IN,
                        stride: int = REMD_STRIDE, with_xyz: bool = True) -> ColdReference:
    import mdtraj as md
    remd_dir = Path(remd_dir)
    top = remd_dir / "start_structure_minimized.pdb"
    t = md.load_dcd(str(remd_dir / "replica_00/trajectory.dcd"), top=str(top))
    phi = md.compute_phi(t)[1][:, 0][burn_in:][::stride]
    psi = md.compute_psi(t)[1][:, 0][burn_in:][::stride]
    xyz = t.xyz[burn_in:][::stride] if with_xyz else np.zeros((len(phi), 0, 3))
    return ColdReference(phi=phi, psi=psi, xyz=np.asarray(xyz), top_path=top,
                         burn_in=burn_in, stride=stride)


def check_core_single_basin(proposals: Sequence[dict], cold_angles: np.ndarray,
                            basin_label=None, max_minority: float = 1e-3) -> list[dict]:
    """DESIGN CHECK: is each proposal's FLAT CORE inside a single kinetic basin?

    A flat-bottom window exerts **zero** restoring force inside ``sqrt(D_m) <= h_m``, so within
    the core the walker relaxes only as fast as unbiased cold MD.  If the core straddles a
    barrier, restrained MD cannot equilibrate across it in any affordable time and the realized
    ensemble is *not* pi_m — it is whichever sub-basin the seed landed in.

    Measured on alanine (2026-07-27): whether the core straddles the phi = 0 barrier predicted
    the Phase-8 gate-7 outcome perfectly — the three barrier-spanning windows had JS 0.043,
    0.069, 0.093 against the intended density, the three single-basin windows 0.024–0.037.
    Ensemble seeding does not rescue this: representing a minority basin of weight p needs
    ~log(0.05)/log(1-p) walkers (217 for p = 0.014), so such windows must be **split**.

    ``basin_label``: callable mapping (N,2) angles -> integer basin ids.  Default splits on the
    sign of phi, which is the relevant slow degree of freedom for alanine.
    Returns one record per proposal; ``ok`` False means "not realizable by restrained MD".
    """
    ang = np.asarray(cold_angles, float)
    if basin_label is None:
        def basin_label(a):
            return (np.asarray(a, float)[:, 0] > 0).astype(int)
    lab = np.asarray(basin_label(ang), int)
    out = []
    for p in proposals:
        core = proposal_core_mask(ang, p)
        n = int(core.sum())
        counts = np.bincount(lab[core], minlength=int(lab.max()) + 1) if n else np.array([0])
        minority = float((counts.sum() - counts.max()) / max(counts.sum(), 1)) if n else 0.0
        need = (int(np.ceil(np.log(0.05) / np.log(1 - minority)))
                if 0 < minority < 1 else 0)
        out.append(dict(proposal_id=p.get("proposal_id"),
                        geometry=p.get("geometry", "flatbottom_sqrtD"),
                        h=(float(p["h"]) if "h" in p else None), n_core_frames=n,
                        core_basin_counts=counts.tolist(), minority_weight=minority,
                        walkers_needed_for_minority=need,
                        ok=bool(minority <= max_minority)))
    return out


def check_jensen(reverse_work: np.ndarray, delta_f_ref: float = None,
                 n_sem: float = 5.0) -> dict:
    """PHYSICAL GUARD on a reverse (cold->hot) work sample: Jensen's inequality.

    ``<e^{-W^R}>_C = e^{+Delta f_HC}`` exactly, for ANY protocol length, so by Jensen

        <W^R>_C  >=  f_H - f_C  =  -Delta f_HC .

    A sample mean *below* that bound cannot be a favourable fluctuation — it means the leg is
    not sampling the ensemble/Hamiltonian it claims. This is exactly the check that exposed
    the GBn2 system-builder mismatch on 2026-07-27 (<W^R> = 43.5 vs the required 48.18); see
    Amendment 2 of the protocol document.

    Returns dict(ok, mean, sem, bound, reverse_je, deficit, message).
    """
    delta_f_ref = DELTA_F_REF if delta_f_ref is None else float(delta_f_ref)
    W = np.asarray(reverse_work, float).ravel()
    bound = -delta_f_ref
    mean = float(W.mean())
    sem = float(W.std() / np.sqrt(max(W.size, 1)))
    je = float(logsumexp(-W) - np.log(W.size))
    deficit = bound - mean
    ok = bool(mean >= bound - n_sem * max(sem, 1e-9))
    msg = ("Jensen bound satisfied." if ok else
           f"JENSEN VIOLATION: <W^R> = {mean:.3f} kT is {deficit:.3f} kT below "
           f"f_H - f_C = {bound:.3f} kT (SEM {sem:.3f}). The reverse leg is not sampling "
           f"pi_C under the reference Hamiltonian. Most likely cause: the seed config's "
           f"system builder does not match the forward leg — the 'gb_radii' key selects "
           f"parmed vs AmberPrmtopFile and shifts the GB energy by 16.6 kJ/mol for "
           f"alanine/GBn2, i.e. 16.6*(1-s) = 5.0 kT of spurious work.")
    return dict(ok=ok, mean=mean, sem=sem, bound=bound, reverse_je=je, deficit=deficit,
                message=msg)


def integrated_act(x: np.ndarray, n_max: int = 500) -> float:
    x = np.asarray(x, float) - np.mean(x)
    c0 = float(np.mean(x * x))
    if c0 <= 0:
        return 1.0
    ac = np.array([float(np.mean(x[:-k] * x[k:]) / c0) for k in range(1, min(n_max, len(x)))])
    neg = np.where(ac < 0)[0]
    cut = int(neg[0]) if len(neg) else len(ac)
    return float(1.0 + 2.0 * ac[:cut].sum())


# ─────────────────────────────────────────────────────────────────────────────
# proposal design (Phase 4) — FROZEN once written
# ─────────────────────────────────────────────────────────────────────────────
def design_proposals(mu: np.ndarray, h: np.ndarray, k: np.ndarray, source_model: str,
                     source_components: Sequence[Sequence[int]],
                     predicted_mass: np.ndarray) -> list[dict]:
    out = []
    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for m in range(len(mu)):
        out.append(dict(
            proposal_id=f"C{m:02d}",
            mu=[float(mu[m, 0]), float(mu[m, 1])],
            mu_deg=[float(np.degrees(mu[m, 0])), float(np.degrees(mu[m, 1]))],
            geometry="flatbottom_sqrtD",
            h=float(h[m]), k=float(k[m]),
            source_model=source_model,
            source_component_ids=[int(c) for c in source_components[m]],
            predicted_cold_mass=float(predicted_mass[m]),
            frozen_at=stamp,
        ))
    return out


def proposals_from_partition(partition: dict, source: str = "") -> list[dict]:
    """One RECTANGULAR flat-bottom proposal per basin of a barrier-aligned partition.

    The contrast with :func:`proposals_from_fit` is the whole point of the rectangular design.
    A mixture component gives a window *centre* and a radius fitted to the component's spread,
    so nothing stops the resulting disc from spilling across a free-energy barrier — which is
    what failed decision gate 7 in oracle_v1 (windows C00/C05, core minority 0.9 % and 33.8 %).
    A partition basin is bounded *by* the barriers, so its flat core cannot straddle one by
    construction; whether that is enough is exactly what the single-basin check now measures.

    Nothing here is fitted: geometry, walls and stiffnesses come from the partition JSON.
    """
    from escort_ais.methods.barrier_partition import partition_from_dict

    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    basins = partition_from_dict(partition)
    out = []
    for m, b in enumerate(basins):
        d = b.as_dict()
        out.append(dict(
            proposal_id=f"R{m:02d}",
            geometry="rect_flatbottom",
            basin=d,
            mu=[float(b.phi_interval.centre), float(b.psi_interval.centre)],
            mu_deg=[float(np.degrees(b.phi_interval.centre)),
                    float(np.degrees(b.psi_interval.centre))],
            half_width_deg=[float(np.degrees(b.phi_interval.half_width)),
                            float(np.degrees(b.psi_interval.half_width))],
            k=[b.k_phi, b.k_psi],
            active_walls=list(b.active_walls),
            source_model=f"barrier-partition:{partition.get('partition_mode', '?')}",
            source_component_ids=[int(b.basin_id)],
            predicted_cold_mass=float(b.mass),
            source_file=str(source),
            frozen_at=stamp,
        ))
    return out


def proposals_from_fit(fit, angles: np.ndarray, weights: np.ndarray, e_star: float = 5.0,
                       reach: float = 1.0, h_quantile: float = 0.90,
                       h_min: float = 0.35, k_min: float = 3.0, k_max: float = 50.0) -> list[dict]:
    """One flat-bottom proposal per mixture component.

    ``h_m`` is the ``h_quantile`` quantile of sqrt(D_m) over the samples MAP-assigned to
    component m (so the flat core covers the component's bulk); ``k_m`` is set so the wall
    reaches ``e_star`` kT at ``reach`` beyond the flat edge: 1/2 k reach^2 = e_star.
    """
    lab = fit.map_assign(angles[:, 0], angles[:, 1])
    mu = fit.mu.copy()
    M = len(mu)
    h = np.empty(M)
    for m in range(M):
        sel = lab == m
        if sel.sum() < 5:
            h[m] = h_min
            continue
        d = np.sqrt(np.clip(dcv(angles[sel], mu[m]), 0, None))
        w = weights[sel]
        order = np.argsort(d)
        cw = np.cumsum(w[order]) / max(w.sum(), 1e-300)
        h[m] = max(float(d[order][np.searchsorted(cw, h_quantile)]), h_min)
    k = np.clip(np.full(M, 2.0 * e_star / reach ** 2), k_min, k_max)
    mass = fit.basin_masses(angles[:, 0], angles[:, 1], weights)
    return design_proposals(mu, h, k, fit.model, [[m] for m in range(M)], mass)


# ─────────────────────────────────────────────────────────────────────────────
# oracle resampling
# ─────────────────────────────────────────────────────────────────────────────
def zwanzig_masses(pool_angles: np.ndarray, proposals: Sequence[dict]) -> dict:
    """Exact Z_m/Z_C and f_m - f_C on the discretized cold reference (§7.3 of the theory)."""
    B = bias_matrix(pool_angles, proposals)
    z = zwanzig_offsets(B)
    z["alpha_match"] = z["z"] / z["z"].sum()
    return z


def resample_proposal_indices(pool_angles: np.ndarray, proposal: dict, n: int,
                              rng: np.random.Generator) -> np.ndarray:
    """P_m(j) proportional to exp(-U_m(x_j)) — exact draws from the discretized proposal."""
    u = proposal_bias(pool_angles, proposal)
    p = np.exp(-(u - u.min()))
    p /= p.sum()
    return rng.choice(len(p), size=int(n), replace=True, p=p)


# ─────────────────────────────────────────────────────────────────────────────
# forward AIS (Phase 2)
# ─────────────────────────────────────────────────────────────────────────────
def cmd_forward(args) -> int:
    from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
    out = Path(args.out) if args.out else OUT_ROOT / args.run / "forward"
    out.mkdir(parents=True, exist_ok=True)
    cfg = LinearAISConfig(
        solvent="implicit", k_ais=args.k_ais, t_ais=T_AIS, freq_ais=FREQ_AIS,
        s_hot=S_HOT, s_cold=S_COLD, scaling_mode=SCALING_MODE, seed=args.seed,
        start_frame_offset=args.hot_burn_in, start_frame_stride=1,
        input_scaled_dir=HOT_DIR, output_dir=out, platform=args.platform,
        device_index=args.device, overwrite=True,
        save_traj_every_switch=True, save_switch_stride=args.save_stride)
    resolved = {k: (str(v) if isinstance(v, Path) else v)
                for k, v in asdict(cfg).items() if not isinstance(v, np.ndarray)}
    ch = config_hash(resolved)
    run_id = make_run_id("alanine", "mixture_cft_forward", ch)
    man = RunManifest.new(run_id=run_id, system="alanine", method="mixture_cft_forward",
                          config_hash=ch, command=" ".join(sys.argv), seeds=[args.seed],
                          backend=args.platform, retention="exploratory")
    man.started_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    man.status = "running"
    write_manifest(out, man, overwrite=True)
    (out / "config.json.resolved").write_text(json.dumps(resolved, indent=2, default=str) + "\n")
    (out / "command.txt").write_text(" ".join(sys.argv) + "\n")

    print(f"[forward] K_ais={args.k_ais} T_ais={T_AIS} stride={args.save_stride} -> {out}")
    run_linear_scaling_ais(cfg)
    update_status(out, "complete", completed_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                  output_paths=[str(out)])
    print(f"[forward] done: {out}")
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# reverse AIS bank (Phase 5)
# ─────────────────────────────────────────────────────────────────────────────
def cmd_reverse_bank(args) -> int:
    """Reverse AIS (cold s=1 -> hot s=0.25) from every block-B2 REMD frame, R replicates.

    The bank is the ONE piece of new MD the oracle needs.  Because every proposal is a
    resampling of the same frame pool, the bank is reused for all allocations, seeds and
    sample sizes; a scenario consumes unused (frame, replicate) pairs.
    """
    import mdtraj as md
    from escort_ais.methods.run_bais_standalone import _ais_leg

    out = Path(args.out) if args.out else OUT_ROOT / args.run / "reverse_bank"
    out.mkdir(parents=True, exist_ok=True)
    cold = load_cold_reference()
    idx = cold.block(args.block)
    if args.max_frames:
        idx = idx[:: max(1, len(idx) // args.max_frames)][: args.max_frames]
    print(f"[reverse-bank] block {args.block}: {len(idx)} frames x {args.replicates} replicates")

    ref_top = md.load(str(cold.top_path))
    cfg = dict(solvent="implicit", t_ais=T_AIS, freq_ais=FREQ_AIS, s_hot=S_HOT,
               omega_exclude=None, prmtop=BASE_PRMTOP, inpcrd=BASE_INPCRD, pdb=cold.top_path,
               gb_radii=GB_RADII, n_solute_atoms=22,
               neq_integrator=not args.no_neq)
    seed_dir = out / "seed_cold"
    seed_dir.mkdir(parents=True, exist_ok=True)
    # CRITICAL: the seed config must select the SAME system builder as the forward leg.
    # `gb_radii` is not cosmetic — it switches ais_linear from AmberPrmtopFile.createSystem to
    # the parmed changeRadii route, and for alanine/GBn2 the two differ by 16.6 kJ/mol
    # (16.6 x (1-s) = 5.0 kT of spurious reverse work).  Omitting it made the reverse works
    # violate <W^R> >= f_H - f_C.  See the 2026-07-27 amendment in the protocol document.
    (seed_dir / "config.json").write_text(json.dumps(SEED_CONFIG))
    shutil.copy(cold.top_path, seed_dir / "start_structure.pdb")
    md.Trajectory(cold.xyz[idx], ref_top.topology).save_dcd(str(seed_dir / "trajectory.dcd"))

    # ONE leg per replicate on a single device: the AIS runner permutes the seed frames, so
    # the shot -> seed-frame mapping must be read back from selected_initial_frames.csv and
    # the works reordered into seed-DCD (= block-frame) order.  Sharding across devices would
    # split that mapping across shard directories, so it is not used here.
    import pandas as pd
    W = np.full((len(idx), args.replicates), np.nan)
    for r in range(args.replicates):
        leg = out / f"rep{r:02d}"
        Wr, _ = _ais_leg(seed_dir, leg, cfg, len(idx), S_COLD, S_HOT, args.platform,
                         seed=40000 + 1000 * r, devices=None)
        sel = pd.read_csv(leg / "selected_initial_frames.csv")
        frame_of_shot = sel.sort_values("ais_trajectory_index")["initial_frame_index"].to_numpy(int)
        if len(np.unique(frame_of_shot)) != len(idx):
            raise RuntimeError(f"replicate {r}: seed frames were drawn WITH replacement "
                               f"({len(np.unique(frame_of_shot))} distinct of {len(idx)}); "
                               f"the bank requires one shot per block frame")
        W[frame_of_shot, r] = Wr
        print(f"[reverse-bank] replicate {r}: mean W_r = {np.mean(Wr):+.3f} kT "
              f"(sd {np.std(Wr):.3f})")
    if not np.isfinite(W).all():
        raise RuntimeError("reverse bank has missing entries after reordering")

    chk = check_jensen(W, DELTA_F_REF)
    print(f"[reverse-bank] <W^R> = {chk['mean']:+.3f} +/- {chk['sem']:.3f} kT   "
          f"(Jensen bound >= {chk['bound']:+.3f})")
    print(f"[reverse-bank] reverse JE Delta f_HC = {chk['reverse_je']:+.3f} kT  "
          f"(reference {DELTA_F_REF:+.3f})")
    if not chk["ok"]:
        raise RuntimeError(chk["message"] + " Nothing was written.")
    mean_w, je_rev, bound = chk["mean"], chk["reverse_je"], chk["bound"]

    np.savez(out / "bank.npz", W=W, frame_index=idx, phi=cold.phi[idx], psi=cold.psi[idx],
             block=np.array([args.block]), replicates=np.array([args.replicates]))
    meta = dict(block=args.block, n_frames=int(len(idx)), replicates=int(args.replicates),
                s_from=S_COLD, s_to=S_HOT, t_ais=T_AIS, freq_ais=FREQ_AIS,
                scaling_mode=SCALING_MODE, seeds=[40000 + 1000 * r for r in range(args.replicates)],
                remd_dir=str(REMD_DIR), burn_in=REMD_BURN_IN, stride=REMD_STRIDE,
                seed_config=SEED_CONFIG, neq_integrator=bool(cfg["neq_integrator"]),
                mean_reverse_work=mean_w, jensen_bound=bound, reverse_je_delta_f=je_rev)
    (out / "bank_metadata.json").write_text(json.dumps(meta, indent=2) + "\n")
    ch = config_hash(meta)
    man = RunManifest.new(run_id=make_run_id("alanine", "mixture_cft_reverse_bank", ch),
                          system="alanine", method="mixture_cft_reverse_bank", config_hash=ch,
                          command=" ".join(sys.argv), seeds=meta["seeds"], backend=args.platform,
                          retention="exploratory")
    man.status = "complete"
    man.completed_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    write_manifest(out, man, overwrite=True)
    print(f"[reverse-bank] done: {out}")
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# scenario machinery (Phase 5 tests 3a / 3b)
# ─────────────────────────────────────────────────────────────────────────────
class Bank:
    """(frame, replicate) reverse-work pool with without-replacement consumption.

    The LAST replicate is reserved for the direct-cold control, so the primary
    finite-switching reference never shares a work value with the proposal scenarios it is
    used to judge.  With ``n_rep = 3`` the scenarios draw from replicates {0, 1} and the
    control uses replicate 2.  (With ``n_rep = 1`` there is nothing to reserve and the
    control necessarily shares the single replicate; ``control_is_independent`` records this.)
    """

    def __init__(self, W: np.ndarray, phi: np.ndarray, psi: np.ndarray, frame_index: np.ndarray):
        self.W = np.asarray(W, float)
        self.phi, self.psi = np.asarray(phi), np.asarray(psi)
        self.frame_index = np.asarray(frame_index)
        self.n_frames, self.n_rep = self.W.shape
        self.control_rep = self.n_rep - 1
        self.control_is_independent = self.n_rep > 1
        self.n_scenario_rep = max(self.n_rep - 1, 1)

    def angles(self) -> np.ndarray:
        return np.column_stack([self.phi, self.psi])

    def control_works(self, frames: np.ndarray) -> np.ndarray:
        """Reverse works from the unbiased cold ensemble, on the reserved replicate."""
        return self.W[np.asarray(frames, int), self.control_rep]

    def draw(self, frames: np.ndarray, rng: np.random.Generator,
             used: dict) -> tuple[np.ndarray, float]:
        """One UNUSED replicate per requested frame, so no work value is reused within a
        scenario.  A frame drawn more than ``n_scenario_rep`` times exhausts its replicates and
        must recycle; the fraction of such draws is returned so the report can state it rather
        than hide it (recycled draws are exact duplicates and inflate the apparent count)."""
        rep = np.empty(len(frames), int)
        recycled = 0
        pool = list(range(self.n_scenario_rep))
        for i, f in enumerate(frames):
            taken = used.setdefault(int(f), set())
            free = [r for r in pool if r not in taken]
            if not free:
                taken.clear()
                free = list(pool)
                recycled += 1
            r = int(rng.choice(free))
            taken.add(r)
            rep[i] = r
        return rep, (recycled / max(len(frames), 1))


def run_scenario(bank: Bank, pool_angles: np.ndarray, proposals: Sequence[dict],
                 counts: np.ndarray, forward_work: np.ndarray, rng: np.random.Generator,
                 oracle_offsets: Optional[np.ndarray] = None, n_bootstrap: int = 0,
                 probe: Optional[tuple[np.ndarray, np.ndarray]] = None,
                 fixed_offsets: Optional[np.ndarray] = None) -> dict:
    """One allocation scenario: resample proposals from the bank's own frames, fit, compare."""
    used: dict = {}
    picks, srcs = [], []
    for m, n_m in enumerate(counts):
        if n_m <= 0:
            continue
        j = resample_proposal_indices(pool_angles, proposals[m], int(n_m), rng)
        picks.append(j)
        srcs.append(np.full(int(n_m), m, int))
    frames = np.concatenate(picks)
    src = np.concatenate(srcs)
    reps, reuse_fraction = bank.draw(frames, rng, used)
    wr = bank.W[frames, reps]
    ang = bank.angles()[frames]
    B = bias_matrix(ang, proposals)

    kw = dict(reverse_start_coordinates_or_cvs=ang, source_proposal_index=src,
              proposal_bias_matrix=B, proposal_sample_counts=np.asarray(counts, float),
              n_bootstrap=n_bootstrap, bootstrap_parent=frames, rng=rng)
    if probe is not None:
        kw.update(probe_bias=bias_matrix(probe[0], proposals), probe_weights=probe[1])

    fits = {}
    # ``fixed_offsets`` makes the PRIMARY fit use supplied f_m instead of fitting them from the
    # proposal samples -- the route that needs no overlap between windows at all.
    if fixed_offsets is None:
        fits["mixture_cft"] = fit_mixture_cft(forward_work, wr, offsets="mbar", **kw)
    else:
        fits["mixture_cft"] = fit_mixture_cft(forward_work, wr, offsets="fixed",
                                              fixed_offsets=np.asarray(fixed_offsets, float), **kw)
    if oracle_offsets is not None:
        fits["oracle_offsets"] = fit_mixture_cft(forward_work, wr, offsets="fixed",
                                                 fixed_offsets=oracle_offsets, **kw)

    # comparison ladder
    n_r = len(wr)
    uni = np.full(n_r, 1.0 / n_r)
    naive = solve_delta_levelA(forward_work, wr, uni, "nominal")["delta_f"]
    # source-only weighting: rho ~ exp(f_m - U_m) / alpha_m  with the fitted offsets
    f_hat = fits["mixture_cft"].proposal_offsets
    alpha = np.asarray(counts, float) / np.sum(counts)
    lw_src = f_hat[src] - B[np.arange(n_r), src] - np.log(alpha[src])
    om_src = np.exp(lw_src - lw_src.max())
    om_src /= om_src.sum()
    src_only = solve_delta_levelA(forward_work, wr, om_src, "ess")["delta_f"]

    return dict(
        delta_f=fits["mixture_cft"].delta_f,
        delta_f_se=fits["mixture_cft"].delta_f_se,
        delta_f_se_sandwich=fits["mixture_cft"].delta_f_se_sandwich,
        delta_f_oracle_offsets=(fits["oracle_offsets"].delta_f if "oracle_offsets" in fits
                                else float("nan")),
        delta_f_naive_pooling=float(naive),
        delta_f_source_only=float(src_only),
        delta_f_je=fits["mixture_cft"].delta_f_init_je,
        delta_f_reverse_je=float(logsumexp(-wr) - np.log(len(wr))),
        offsets=fits["mixture_cft"].proposal_offsets,
        offsets_minus_fC=fits["mixture_cft"].proposal_offsets_minus_fC,
        ess=fits["mixture_cft"].reverse_ess, ess_fraction=fits["mixture_cft"].reverse_ess / n_r,
        max_weight=fits["mixture_cft"].max_weight_fraction,
        warnings=fits["mixture_cft"].warnings,
        converged=fits["mixture_cft"].converged,
        crooks_slope=fits["mixture_cft"].crooks_residuals["slope"],
        bootstrap_ci=fits["mixture_cft"].bootstrap_results.get("ci95", np.array([np.nan, np.nan])),
        n_reverse=n_r, bank_reuse_fraction=float(reuse_fraction),
        n_distinct_parent_frames=int(len(np.unique(frames))),
        weights=fits["mixture_cft"].normalized_reverse_weights,
        angles=ang, source=src, reverse_work=wr, frames=frames,
        _fit=fits["mixture_cft"],
    )


def _counts_from_alpha(alpha: np.ndarray, n_total: int) -> np.ndarray:
    """Largest-remainder allocation of ``n_total`` reverse trajectories, floor of 1 per proposal."""
    a = np.asarray(alpha, float)
    a = a / a.sum()
    base = np.maximum(np.floor(a * n_total).astype(int), 1)
    while base.sum() > n_total and base.max() > 1:
        base[np.argmax(base)] -= 1
    rem = n_total - base.sum()
    if rem > 0:
        order = np.argsort(-(a * n_total - base))
        for i in range(rem):
            base[order[i % len(base)]] += 1
    return base.astype(float)


def _jsonable(o):
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, Path):
        return str(o)
    return str(o)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", default="oracle_v1", help="run label under data/.../mixture_cft/")
    sub = ap.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("forward", help="forward AIS with intermediate cold energies")
    f.add_argument("--k-ais", type=int, default=400)
    f.add_argument("--save-stride", type=int, default=25)
    f.add_argument("--hot-burn-in", type=int, default=500)
    f.add_argument("--seed", type=int, default=SEED_FORWARD)
    f.add_argument("--platform", default="CUDA")
    f.add_argument("--device", default=None)
    f.add_argument("--out", type=Path, default=None)
    f.set_defaults(func=cmd_forward)

    r = sub.add_parser("reverse-bank", help="reverse AIS bank over the REMD block frames")
    r.add_argument("--block", default="B2", choices=sorted(BLOCKS))
    r.add_argument("--replicates", type=int, default=3)
    r.add_argument("--max-frames", type=int, default=0, help="0 = use the whole block")
    r.add_argument("--platform", default="CUDA")
    r.add_argument("--no-neq", action="store_true",
                   help="use the manual per-interval work loop instead of the on-GPU\n                        openmmtools NEQ integrator (validated equivalent, ~3x slower)")
    r.add_argument("--devices", default=None, help="comma-separated GPU indices")
    r.add_argument("--out", type=Path, default=None)
    r.set_defaults(func=cmd_reverse_bank)

    a = sub.add_parser("analyze", help="clustering -> proposals -> oracle tests -> PMF")
    a.add_argument("--forward-dir", type=Path, default=None)
    a.add_argument("--bank-dir", type=Path, default=None)
    a.add_argument("--report", type=Path, default=None)
    a.add_argument("--k-max", type=int, default=8)
    a.add_argument("--n-bins", type=int, default=72)
    a.add_argument("--n-seeds", type=int, default=20)
    a.add_argument("--n-bootstrap", type=int, default=100)
    a.add_argument("--cluster-max-points", type=int, default=15000,
                   help="thin the time-slice pool to at most this many points for clustering")
    a.add_argument("--report-only", action="store_true",
                   help="rebuild report.md from the existing results.json without recomputing")
    a.add_argument("--refit-clustering", action="store_true",
                   help="redo the Phase-3 K sweep instead of reusing the cached\n                        clustering_comparison.csv")
    a.add_argument("--redesign-proposals", action="store_true",
                   help="re-derive the proposal windows into a NEW registry file; by default an\n                        existing proposals.json is reused verbatim (proposals are frozen)")
    a.add_argument("--e-star", type=float, default=5.0)
    a.add_argument("--reach", type=float, default=1.0)
    a.add_argument("--ladder", type=int, nargs="+", default=list(LADDER))
    a.add_argument("--quick", action="store_true", help="small K sweep / few seeds (smoke)")
    a.set_defaults(func=lambda args: _analyze(args))

    args = ap.parse_args(argv)
    return args.func(args)


def _analyze(args) -> int:
    """Imported lazily so `forward` / `reverse-bank` do not pull in the analysis stack."""
    from escort_ais.experiments.alanine import mixture_cft_analysis as A
    return A.run(args)


if __name__ == "__main__":
    raise SystemExit(main())
