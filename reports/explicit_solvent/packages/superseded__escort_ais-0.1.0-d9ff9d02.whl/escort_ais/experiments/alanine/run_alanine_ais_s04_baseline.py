"""Baseline AIS from REMD replica_03 (s=0.4) → U₀.

Uses the same efficient 20-window inner loop as the escort AIS (n_windows=20,
steps_per_window=125 for 5ps) rather than the 2500-window-per-step default
of run_openmm_ais, making wall-clock comparable to the escort run.

Usage
-----
python -m escort_ais.experiments.alanine.run_alanine_ais_s04_baseline \\
    --remd-dir data/alanine_dipeptide/md/ff19sb_gbn2_even_4rep_300K_remd_250ns \\
    --topology-dir data/topology/ff19sb_gbn2_even \\
    --output-dir data/alanine_dipeptide/gmm_escort/2026-06-10-s04-baseline-ais \\
    --platform OpenCL
"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import time
from pathlib import Path

import mdtraj as md
import numpy as np
from openmm import LangevinMiddleIntegrator, Platform, unit
from openmm import app
from scipy.special import logsumexp

BOLTZMANN_KJ_PER_MOL_K = 0.00831446261815324

# Hardcoded atom indices for ACE-ALA-NME (22 atoms, ff19SB topology):
#   phi: C(ACE)=4, N(ALA)=6, CA(ALA)=8, C(ALA)=14
#   psi: N(ALA)=6, CA(ALA)=8, C(ALA)=14, N(NME)=16
# See escort_ais.analysis.find_phi_psi_indices for the general case.
_PHI_IDX = (4, 6, 8, 14)
_PSI_IDX = (6, 8, 14, 16)


def _dihedral_deg(p1, p2, p3, p4):
    """IUPAC dihedral angle between 4 positions (any unit). Returns degrees."""
    b1 = p2 - p1
    b2 = p3 - p2
    b3 = p4 - p3
    n1 = np.cross(b1, b2)
    n2 = np.cross(b2, b3)
    b2_hat = b2 / (np.linalg.norm(b2) + 1e-30)
    m1 = np.cross(n1, b2_hat)
    x = np.dot(n1, n2)
    y = np.dot(m1, n2)
    return float(np.degrees(np.arctan2(y, x)))


def _get_phi_psi_deg(sim):
    """Read current positions and compute (phi, psi) in degrees."""
    pos = sim.context.getState(getPositions=True).getPositions(asNumpy=True).value_in_unit(
        unit.nanometer
    )
    phi = _dihedral_deg(pos[_PHI_IDX[0]], pos[_PHI_IDX[1]], pos[_PHI_IDX[2]], pos[_PHI_IDX[3]])
    psi = _dihedral_deg(pos[_PSI_IDX[0]], pos[_PSI_IDX[1]], pos[_PSI_IDX[2]], pos[_PSI_IDX[3]])
    return phi, psi


def _build_simulation(topology, system, temperature_k, friction_per_ps, timestep_fs, platform_name):
    integrator = LangevinMiddleIntegrator(
        temperature_k * unit.kelvin,
        friction_per_ps / unit.picosecond,
        (timestep_fs / 1000.0) * unit.picoseconds,
    )
    platform = Platform.getPlatformByName(platform_name)
    props = {}
    if platform_name in {"CUDA", "OpenCL"}:
        props["Precision"] = "mixed"
    return app.Simulation(topology, system, integrator, platform, props)


def _get_energy(sim):
    return sim.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(
        unit.kilojoules_per_mole
    )


def _set_positions(sim, pos_nm):
    sim.context.setPositions(pos_nm * unit.nanometer)


def _get_positions(sim):
    return sim.context.getState(getPositions=True).getPositions(asNumpy=True).value_in_unit(
        unit.nanometer
    )


def _ess(log_w):
    lw = log_w - np.max(log_w)
    w = np.exp(lw)
    return float(w.sum() ** 2 / (w ** 2).sum())


def _run_rest2_sample(
    sim, scaler, lambda_scales, beta0, temperature_k, positions_nm, steps_per_window,
    log_torsions=False,
):
    """Run one AIS sample switching REST2 scale from s_source to 1.0.

    Parameters
    ----------
    log_torsions : bool
        If True, record (phi, psi) in degrees at each schedule node (before
        the loop at s_0, and after propagation at s_1 … s_n_windows).

    Returns
    -------
    work : float
    final_pos : np.ndarray
    work_series : list[float]   cumulative work after each window
    torsion_series : list[tuple[float, float]] or None
        (phi_deg, psi_deg) at each of the n_windows+1 schedule nodes,
        or None when log_torsions=False.
    """
    n_windows = len(lambda_scales) - 1

    scaler.apply(lambda_scales[0], sim.context)
    _set_positions(sim, positions_nm)
    sim.context.setVelocitiesToTemperature(temperature_k * unit.kelvin)

    work = 0.0
    work_series = []
    torsion_series = [_get_phi_psi_deg(sim)] if log_torsions else None

    for k in range(n_windows):
        E_curr = _get_energy(sim)
        scaler.apply(lambda_scales[k + 1], sim.context)
        E_next = _get_energy(sim)
        work += beta0 * (E_next - E_curr)
        work_series.append(work)
        sim.context.getIntegrator().step(steps_per_window)
        if log_torsions:
            torsion_series.append(_get_phi_psi_deg(sim))

    return work, _get_positions(sim), work_series, torsion_series


def main():
    p = argparse.ArgumentParser(description="Baseline AIS from REMD s=0.4 → U₀")
    p.add_argument("--remd-dir", required=True)
    p.add_argument("--topology-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--source-scale", type=float, default=0.4)
    p.add_argument("--replica-idx", type=int, default=3)
    p.add_argument("--n-samples", type=int, default=1000)
    p.add_argument("--switching-time-ps", type=float, default=5.0)
    p.add_argument("--n-windows", type=int, default=20)
    p.add_argument("--timestep-fs", type=float, default=2.0)
    p.add_argument("--temperature-k", type=float, default=300.0)
    p.add_argument("--friction-per-ps", type=float, default=1.0)
    p.add_argument("--platform", default="OpenCL")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--log-torsion-per-window", action="store_true",
                   help="Record (phi, psi) at each schedule node and save "
                        "torsion_per_window.npy of shape (n_success, n_windows+1, 2). "
                        "Required for analyze_alanine_ladder_design.py.")
    args = p.parse_args()

    import sys

    from escort_ais.systems.openmm_system import Rest2ContextScaler, _clone_system

    output_dir = Path(args.output_dir)
    if output_dir.exists() and any(output_dir.iterdir()) and not args.overwrite:
        raise FileExistsError(f"{output_dir} exists. Use --overwrite.")
    output_dir.mkdir(parents=True, exist_ok=True)

    log_path = output_dir / "run.log"
    logger = logging.getLogger("s04_baseline_ais")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
    fh.setFormatter(fmt); ch.setFormatter(fmt)
    logger.addHandler(fh); logger.addHandler(ch)

    t_start = time.time()
    logger.info("=== Baseline AIS (s=%.2f → 1.0) ===", args.source_scale)

    topo_dir = Path(args.topology_dir)
    topo_cfg = json.loads((topo_dir / "config.json").read_text())
    n_solute_atoms = int(topo_cfg["n_solute_atoms"])
    prmtop_path = topo_dir / "system_scale_1p0.prmtop"
    if not prmtop_path.exists():
        prmtop_path = topo_dir / "system.prmtop"

    prmtop = app.AmberPrmtopFile(str(prmtop_path))
    base_system = prmtop.createSystem(
        nonbondedMethod=app.NoCutoff,
        constraints=app.HBonds,
        implicitSolvent=app.GBn2,
    )
    temperature_k = args.temperature_k
    beta0 = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * temperature_k)
    solute_indices = np.arange(n_solute_atoms, dtype=np.int64)
    logger.info("Built GBn2 system  n_atoms=%d  n_solute=%d", base_system.getNumParticles(), n_solute_atoms)

    if args.dry_run:
        n_nodes = args.n_windows + 1
        if args.log_torsion_per_window:
            logger.info(
                "DRY RUN — torsion_per_window.npy will have shape "
                "(n_success, %d, 2)  dtype=float32", n_nodes,
            )
        logger.info("DRY RUN — OK")
        print(f"DRY RUN: OK  (n_windows={args.n_windows}, n_nodes={n_nodes})")
        return

    sys_b = _clone_system(base_system)
    scaler = Rest2ContextScaler(sys_b, solute_indices)
    sim = _build_simulation(prmtop.topology, sys_b, temperature_k,
                            args.friction_per_ps, args.timestep_fs, args.platform)
    scaler.apply(args.source_scale, sim.context)
    logger.info("Simulation built on %s", args.platform)

    # Load REMD replica trajectory
    remd_dir = Path(args.remd_dir)
    source_traj_path = remd_dir / f"replica_{args.replica_idx:02d}" / "trajectory.dcd"
    logger.info("Loading source trajectory: %s", source_traj_path)
    traj = md.load_dcd(str(source_traj_path), top=str(prmtop_path))
    n_frames = traj.n_frames
    logger.info("Source trajectory: %d frames", n_frames)

    # Sample starting frames
    rng = np.random.default_rng(args.seed)
    n_samples = args.n_samples
    if n_samples <= n_frames:
        frame_indices = rng.choice(n_frames, size=n_samples, replace=False)
    else:
        frame_indices = rng.choice(n_frames, size=n_samples, replace=True)
    initial_positions = traj.xyz[frame_indices]
    np.save(output_dir / "initial_indices.npy", frame_indices)
    logger.info("Sampled %d frames from trajectory", n_samples)

    # Lambda schedule: scale from s_source → 1.0
    n_windows = args.n_windows
    steps_per_window = max(1, int(round(
        args.switching_time_ps * 1000 / (args.timestep_fs * n_windows)
    )))
    lambda_scales = np.linspace(args.source_scale, 1.0, n_windows + 1).tolist()
    np.save(output_dir / "lambda_schedule.npy", lambda_scales)
    logger.info("AIS: %d windows × %d steps, switching_time_ps=%.1f, s=%.2f→1.0",
                n_windows, steps_per_window, args.switching_time_ps, args.source_scale)

    config_dict = {
        "strategy": "rest2_scaling_interpolation",
        "remd_dir": str(remd_dir),
        "topology_dir": str(topo_dir),
        "source_scale": args.source_scale,
        "replica_idx": args.replica_idx,
        "n_samples": n_samples,
        "switching_time_ps": args.switching_time_ps,
        "n_windows": n_windows,
        "steps_per_window": steps_per_window,
        "timestep_fs": args.timestep_fs,
        "temperature_k": temperature_k,
        "beta_target": beta0,
        "platform": args.platform,
        "seed": args.seed,
        "solvent": "implicit",
        "n_solute_atoms": n_solute_atoms,
        "n_source_frames": n_frames,
    }
    (output_dir / "config.json").write_text(json.dumps(config_dict, indent=2))

    csv_path = output_dir / "ais_work.csv"
    csv_cols = [
        "sample_id", "initial_frame_index", "work_reduced", "work_kj_mol",
        "n_windows", "switching_time_ps", "source_scale", "success", "failure_reason",
    ]
    all_work = []
    final_positions_list = []
    work_timeseries_list = []
    torsion_per_window_list = []
    n_success = n_failed = 0

    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=csv_cols)
        writer.writeheader()

        for sid in range(n_samples):
            if sid % 100 == 0:
                logger.info("Sample %d / %d  (%.0f s elapsed)", sid, n_samples, time.time() - t_start)

            pos0 = initial_positions[sid]
            try:
                work, final_pos, ws, ts = _run_rest2_sample(
                    sim, scaler, lambda_scales, beta0, temperature_k, pos0, steps_per_window,
                    log_torsions=args.log_torsion_per_window,
                )
                n_success += 1
                all_work.append(work)
                final_positions_list.append(final_pos)
                work_timeseries_list.append(ws)
                if args.log_torsion_per_window and ts is not None:
                    torsion_per_window_list.append(ts)
                writer.writerow({
                    "sample_id": sid,
                    "initial_frame_index": int(frame_indices[sid]),
                    "work_reduced": f"{work:.8f}",
                    "work_kj_mol": f"{work / beta0:.8f}",
                    "n_windows": n_windows,
                    "switching_time_ps": args.switching_time_ps,
                    "source_scale": args.source_scale,
                    "success": True,
                    "failure_reason": "",
                })
            except Exception as exc:
                n_failed += 1
                logger.warning("Sample %d failed: %s", sid, exc)
                writer.writerow({
                    "sample_id": sid,
                    "initial_frame_index": int(frame_indices[sid]),
                    "work_reduced": "nan", "work_kj_mol": "nan",
                    "n_windows": n_windows,
                    "switching_time_ps": args.switching_time_ps,
                    "source_scale": args.source_scale,
                    "success": False,
                    "failure_reason": str(exc),
                })

    if final_positions_list:
        final_arr = np.stack(final_positions_list, axis=0)
        ref_top = md.load_prmtop(str(prmtop_path))
        md.Trajectory(final_arr, ref_top).save_dcd(str(output_dir / "final_samples.dcd"))

    if work_timeseries_list:
        max_len = max(len(w) for w in work_timeseries_list)
        wts = np.full((len(work_timeseries_list), max_len), float("nan"))
        for i, ws in enumerate(work_timeseries_list):
            wts[i, :len(ws)] = ws
        np.save(output_dir / "work_timeseries.npy", wts)

    if torsion_per_window_list:
        # Shape: (n_success, n_nodes, 2) where dim 2 = [phi_deg, psi_deg]
        tpw = np.array(torsion_per_window_list, dtype=np.float32)
        np.save(output_dir / "torsion_per_window.npy", tpw)
        logger.info("Saved torsion_per_window.npy  shape=%s", tpw.shape)

    works = np.array(all_work)
    if len(works) > 0:
        log_w = -works
        ess = _ess(log_w)
        ess_norm = ess / len(works)
        jar_df = float(-logsumexp(-works) + np.log(len(works)))
    else:
        ess = ess_norm = jar_df = float("nan")

    summary = {
        "n_attempted": n_samples,
        "n_success": n_success,
        "n_failed": n_failed,
        "work_reduced_mean": float(np.mean(works)) if len(works) else None,
        "work_reduced_std": float(np.std(works)) if len(works) else None,
        "work_reduced_min": float(np.min(works)) if len(works) else None,
        "work_reduced_max": float(np.max(works)) if len(works) else None,
        "ess": float(ess) if np.isfinite(ess) else None,
        "ess_normalized": float(ess_norm) if np.isfinite(ess_norm) else None,
        "jarzynski_delta_f_reduced": float(jar_df) if np.isfinite(jar_df) else None,
        "wall_time_s": time.time() - t_start,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2))

    logger.info("=== Done: %d success, %d failed  ESS=%.1f (%.1f%%)  wall=%.0f s ===",
                n_success, n_failed, ess, 100 * ess_norm, summary["wall_time_s"])


if __name__ == "__main__":
    main()
