#!/usr/bin/env python3
"""analyze_top100w_weighting_comparison.py — how the reverse-start weighting scheme
affects the endpoint ddF.

The cold-MD frames within a basin are NOT Boltzmann-distributed (short MD seeded from
AIS endpoints), so RITEWeight estimates each frame's equilibrium weight w_i.  Three
ways to turn the frame pool into a reverse-start ensemble are compared, all using the
SAME cached dense reverse AIS (reverse work per within-basin frame) so no new AIS runs:

  (1) RITE-prob          : draw frames proportional to w_i           (production method)
  (2) uniform            : draw frames with equal probability        (ignore RITE)
  (3) uniform + log-w    : draw uniform, shift work W_i -> W_i - ln(w_hat_i)
                           with w_hat normalized to UNIT MEAN per basin (importance
                           sampling in work space; uniform weights -> no shift).

All three draw N_DRAW/basin x N_REP repeats (same sample size; only the weighting
differs).  Reports v3/v5/v6 RMSE vs the REMD reference + per-basin ddF.

Usage:  TOP100W_EXP=diverse20_100ps \
          python -m escort_ais.experiments.alanine.analyze_top100w_weighting_comparison
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import N_BASINS, load_phi_psi_dcd
from escort_ais.analysis.analyze_ala_endpoint_partitioned import _assign, reference_ddF
from escort_ais.analysis.analyze_top100w_estimators import estimators, load_forward, rmse
from escort_ais.common.top100w_cfg import RESULTS as OUT, REVRUN, HOT_SRC, HOT_BURN

RITE = OUT / "rite"
PLOTS = OUT / "plots"
BN = ["B0", "B1", "B2", "B3"]
N_DRAW, N_REP = 250, 8
SCHEMES = ["RITE-prob", "uniform", "uniform+logw", "uniform+logw(support)"]
COLORS = {"RITE-prob": "#EE7733", "uniform": "#0077BB",
          "uniform+logw": "#AA3377", "uniform+logw(support)": "#117733"}


def draw_reverse(scheme, basins, dense, rng):
    """Return (W_r, b_r, a_r) for one resample under the given weighting scheme.

    RITE zeros out ~half the frames, so 'uniform+logw' (draw over ALL frames + add
    -ln w_hat) injects +inf-like work spikes on the zero-weight frames; the
    '(support)' variant draws only over frames with w>0 so the correction is finite.
    """
    W_r, b_r, a_r = [], [], []
    for B in basins:
        W_B, hot_B = dense[B]
        ok = np.isfinite(W_B)
        w = np.load(RITE / f"basin_{B}_default.npy").astype(float)
        w = np.where(ok, w, 0.0)
        if scheme == "RITE-prob":
            p = w / w.sum()
            pick = rng.choice(len(W_B), N_DRAW, replace=True, p=p)
            Wsel = W_B[pick]
        elif scheme == "uniform":
            unif = ok.astype(float); unif /= unif.sum()
            pick = rng.choice(len(W_B), N_DRAW, replace=True, p=unif)
            Wsel = W_B[pick]
        elif scheme == "uniform+logw":
            unif = ok.astype(float); unif /= unif.sum()
            pick = rng.choice(len(W_B), N_DRAW, replace=True, p=unif)
            what = w / w[ok].mean()                       # unit-mean within basin
            Wsel = W_B[pick] - np.log(np.clip(what[pick], 1e-300, None))
        else:  # uniform+logw(support): equal draw over the RITE support (w>0) + correction
            sup = (w > 0) & ok
            unif = sup.astype(float); unif /= unif.sum()
            pick = rng.choice(len(W_B), N_DRAW, replace=True, p=unif)
            what = w / w[sup].mean()
            Wsel = W_B[pick] - np.log(what[pick])
        W_r.append(Wsel); a_r.append(hot_B[pick]); b_r.append(np.full(N_DRAW, B))
    return np.concatenate(W_r), np.concatenate(b_r), np.concatenate(a_r)


def main():
    PLOTS.mkdir(parents=True, exist_ok=True)
    ref = reference_ddF()
    W_f, a_f, b_f = load_forward()
    hot = _assign(*load_phi_psi_dcd(HOT_SRC))[HOT_BURN:]

    dense_npz = np.load(REVRUN / "dense_reverse.npz")
    basins = sorted({int(k.split("_")[1]) for k in dense_npz.files if k.startswith("W_")})
    dense = {B: (dense_npz[f"W_{B}"], dense_npz[f"hot_{B}"]) for B in basins}

    rd = pd.read_csv(RITE / "rite_diagnostics.csv")
    ess = {B: float(rd[(rd.basin == B) & (rd.tau == 10)]["ESS_frac"].mean()) for B in basins}

    rng = np.random.default_rng(7)
    rows = []
    for scheme in SCHEMES:
        acc = {k: [] for k in ["v3", "v5", "v6"]}
        dd = {k: [] for k in ["v3", "v5", "v6"]}
        for _ in range(N_REP):
            W_r, b_r, a_r = draw_reverse(scheme, basins, dense, rng)
            est = estimators(W_f, a_f, b_f, W_r, b_r, a_r, hot, ref)
            for k in acc:
                acc[k].append(rmse(est[k], ref)); dd[k].append(np.asarray(est[k], float))
        row = dict(scheme=scheme)
        for k in acc:
            row[f"{k}_rmse_mean"] = float(np.nanmean(acc[k]))
            row[f"{k}_rmse_std"] = float(np.nanstd(acc[k]))
            m = np.nanmean(np.vstack(dd[k]), axis=0)
            for bi in range(N_BASINS):
                row[f"{k}_ddF_{BN[bi]}"] = float(m[bi])
        rows.append(row)
        print(f"  {scheme:13s}: v3={row['v3_rmse_mean']:.3f} v5={row['v5_rmse_mean']:.3f} "
              f"v6={row['v6_rmse_mean']:.3f}")
    tbl = pd.DataFrame(rows)
    tbl.round(3).to_csv(OUT / "weighting_comparison.csv", index=False)

    # ── RMSE grouped bars ──
    ns = len(SCHEMES)
    fig, ax = plt.subplots(figsize=(8.5, 4.4))
    x = np.arange(ns); w = 0.25
    for i, est_name in enumerate(["v3", "v5", "v6"]):
        ax.bar(x + (i - 1) * w, tbl[f"{est_name}_rmse_mean"], w,
               yerr=tbl[f"{est_name}_rmse_std"], capsize=3, label=est_name)
    ax.set_xticks(x); ax.set_xticklabels(SCHEMES, rotation=12, ha="right", fontsize=8)
    ax.set_ylabel("RMSE vs REMD ref (kT)"); ax.legend(title="estimator", fontsize=8)
    ax.set_title(f"Reverse-start weighting vs endpoint ddF accuracy ({OUT.name})")
    fig.tight_layout(); fig.savefig(str(PLOTS / "weighting_comparison_rmse.png"), dpi=140); plt.close(fig)

    # ── per-basin v6 ddF ──
    fig, ax = plt.subplots(figsize=(8.5, 4.4))
    bx = np.arange(N_BASINS); bw = 0.8 / ns
    for i, scheme in enumerate(SCHEMES):
        y = [tbl.loc[tbl.scheme == scheme, f"v6_ddF_{BN[b]}"].values[0] for b in range(N_BASINS)]
        ax.bar(bx + (i - (ns - 1) / 2) * bw, np.nan_to_num(y, nan=0.0), bw, label=scheme, color=COLORS[scheme])
    ax.plot(bx, ref, "k_", ms=22, mew=2.5, label="REMD ref")
    ax.set_xticks(bx); ax.set_xticklabels(BN)
    ax.set_ylabel(r"v6 $\Delta\Delta F_B$ (kT)"); ax.legend(fontsize=8)
    ax.set_title(f"Per-basin ddF by reverse-start weighting ({OUT.name})")
    fig.tight_layout(); fig.savefig(str(PLOTS / "weighting_comparison_ddF.png"), dpi=140); plt.close(fig)

    print(f"  RITE ESS frac (lag 10): {{{', '.join(f'B{B}:{ess[B]:.2f}' for B in basins)}}}")
    print(f"  Saved weighting_comparison.csv + 2 plots -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
