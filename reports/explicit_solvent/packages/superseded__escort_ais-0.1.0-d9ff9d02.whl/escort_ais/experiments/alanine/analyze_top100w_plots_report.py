#!/usr/bin/env python3
"""analyze_top100w_plots_report.py — Step 11-12: extra plots + cross-protocol table.

Adds the remaining diagnostic plots (cold-MD Ramachandran with seeds, pair-hit
matrices, cross-protocol RMSE bar) and assembles the cross-protocol comparison
CSV (old-RITE 5 ps production | REMD-seeded 5 ps | REMD-2ps gold | top100w 2 ps).
The REPORT.md narrative is written separately.

Usage:  python -m escort_ais.experiments.alanine.analyze_top100w_plots_report
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import N_BASINS, REMD_DIR, load_phi_psi_dcd
from escort_ais.analysis.analyze_ala_endpoint_partitioned import _assign, reference_ddF
from escort_ais.methods.endpoint_bar import endpoint_partitioned_pairwise_bar

from escort_ais.common.top100w_cfg import EXP, FWD, RUNS, TOP_PDB, HOT_SRC, RESULTS as OUT  # noqa: E402
PLOTS = OUT / "plots"
EP = ROOT / "results/endpoint_partitioned"
BN = ["B0", "B1", "B2", "B3"]
BURN = 20
# top100w protocol label + total-sim-time entry depend on the forward seed source
if EXP == "remdfree_hot5ns":
    TOP_LABEL = "top100w REMD-free"
    TOP_SIM = (5 + 2, "5 ns hot MD + 2 ns cold MD (no REMD)")   # md_ns, label (+ AIS added below)
else:
    TOP_LABEL = "top100w diverse-20"
    TOP_SIM = (250.0 * 4 + 2, "250 ns x4 REMD (fwd hot seeds) + 2 ns cold MD")


def cold_md_ramachandran():
    seeds = pd.read_csv(OUT / "selected_seeds.csv")
    ph, ps = [], []
    for s in range(20):
        a, b = load_phi_psi_dcd(RUNS / f"seed_{s:03d}/trajectory.dcd")
        ph.append(a[BURN:]); ps.append(b[BURN:])
    ph = np.concatenate(ph); ps = np.concatenate(ps)
    fig, ax = plt.subplots(figsize=(6, 5.5))
    ax.hexbin(ph, ps, gridsize=60, cmap="Blues", mincnt=1, extent=(-180, 180, -180, 180))
    ax.scatter(seeds["phi"], seeds["psi"], s=130, marker="*", color="#EE6677",
               edgecolor="k", label="20 AIS-endpoint seeds")
    ax.set_xlabel(r"$\phi$ (deg)"); ax.set_ylabel(r"$\psi$ (deg)")
    ax.set_xlim(-180, 180); ax.set_ylim(-180, 180); ax.legend(fontsize=8, loc="upper right")
    ax.set_title("20×100 ps cold MD reservoir (post 20 ps burn-in) + diverse seeds")
    fig.tight_layout(); fig.savefig(str(PLOTS / "cold_md_ramachandran_seeds.png"), dpi=140); plt.close(fig)


def pair_hit_matrices():
    # forward
    logw_f = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].values
    idx = pd.read_csv(FWD / "selected_initial_frames.csv")["initial_frame_index"].astype(int).values
    ph, ps = load_phi_psi_dcd(HOT_SRC)
    a_f = _assign(ph[idx], ps[idx])
    phe, pse = load_phi_psi_dcd(FWD / "ais_final_coordinates.dcd")
    b_f = _assign(phe, pse)
    Hf = np.zeros((N_BASINS, N_BASINS), int)
    for a, b in zip(a_f, b_f):
        Hf[a, b] += 1
    # reverse (top100w)
    rv = np.load(OUT / "reverse_ais_results.npz")
    Hr = np.zeros((N_BASINS, N_BASINS), int)
    for b, a in zip(rv["reverse_cold_start_basin"], rv["reverse_hot_end_basin"]):
        Hr[a, b] += 1
    for H, name, ttl in [(Hf, "pair_hit_matrix_forward", "forward: hot-start α → cold-end β"),
                         (Hr, "pair_hit_matrix_reverse_top100w", "top100w reverse: cold-start β → hot-end α")]:
        fig, ax = plt.subplots(figsize=(4.6, 4))
        im = ax.imshow(H, cmap="viridis")
        for i in range(N_BASINS):
            for j in range(N_BASINS):
                ax.text(j, i, str(H[i, j]), ha="center", va="center",
                        color="w" if H[i, j] < H.max() * 0.6 else "k", fontsize=9)
        ax.set_xticks(range(N_BASINS)); ax.set_xticklabels(BN)
        ax.set_yticks(range(N_BASINS)); ax.set_yticklabels(BN)
        ax.set_xlabel("cold basin β"); ax.set_ylabel("hot basin α")
        ax.set_title(ttl, fontsize=9); fig.colorbar(im, ax=ax, fraction=0.046)
        fig.tight_layout(); fig.savefig(str(PLOTS / f"{name}.png"), dpi=140); plt.close(fig)


# ── total simulation-time accounting (ns), REMD counted x n_replicas ──
# REMD production: 250 ns x 4 replicas = 1000 ns aggregate.
# standalone hot MD (old-RITE step1) = 5 ns; old-RITE basin MD = 100 x 50 ps = 5 ns.
# top100w cold reservoir = 20 x 100 ps = 2 ns.  AIS leg = n_traj(1000) x switch.
REMD_AGG = 250.0 * 4          # ns, the x4 REMD expense
AIS_2PS = 1000 * 0.002        # 2 ns per 2 ps leg (1000 trajs)
AIS_5PS = 1000 * 0.005        # 5 ns per 5 ps leg
SIM_NS = {
    # protocol -> (md_seed_ns, md_label, ais_ns)
    "old-RITE production": (5 + 5, "5 ns hot MD + 5 ns basin MD (no REMD)", AIS_5PS + AIS_5PS),
    "REMD-seeded":         (REMD_AGG, "250 ns x4 REMD", AIS_5PS + AIS_5PS),
    "REMD-2ps gold":       (REMD_AGG, "250 ns x4 REMD", AIS_2PS + AIS_2PS),
    TOP_LABEL:             (TOP_SIM[0], TOP_SIM[1], AIS_2PS + AIS_2PS),
}


def cross_protocol_table():
    ref = reference_ddF()
    cur = pd.read_csv(OUT / "endpoint_estimators_summary.csv", index_col=0)
    rite = pd.read_csv(EP / "summary_RITE.csv", index_col=0)
    remd5 = pd.read_csv(EP / "summary_REMD_seeded.csv", index_col=0)

    def cov(row):
        return int(np.isfinite(pd.to_numeric(row[BN], errors="coerce").values).sum())

    rows = []
    rows.append(dict(protocol="REMD reference", estimator="counting", switch="-",
                     **{b: round(float(ref[i]), 3) for i, b in enumerate(BN)}, RMSE=np.nan,
                     coverage=4, total_sim_ns=REMD_AGG, sim_breakdown="250 ns x4 REMD"))
    spec = [
        ("old-RITE production", "5 ps", rite, "v3 endpoint-BAR row-contrast", "v3"),
        ("old-RITE production", "5 ps", rite, "v5 hybrid endpoint+MSM", "v5"),
        ("REMD-seeded", "5 ps", remd5, "v3 endpoint-BAR row-contrast", "v3"),
        ("REMD-seeded", "5 ps", remd5, "v5 hybrid endpoint+MSM", "v5"),
        ("REMD-2ps gold", "2 ps", cur, "v3 [REMD-2ps reverse]", "v3"),
        ("REMD-2ps gold", "2 ps", cur, "v5 [REMD-2ps reverse]", "v5"),
        ("REMD-2ps gold", "2 ps", cur, "v6 [REMD-2ps reverse]", "v6"),
        (TOP_LABEL, "2 ps", cur, "v3 [top100w reverse]", "v3"),
        (TOP_LABEL, "2 ps", cur, "v4b [top100w reverse]", "v4b"),
        (TOP_LABEL, "2 ps", cur, "v5 [top100w reverse]", "v5"),
        (TOP_LABEL, "2 ps", cur, "v6 [top100w reverse]", "v6"),
    ]
    for proto, sw, df, rowname, est in spec:
        if rowname not in df.index:
            continue
        r = df.loc[rowname]
        vals = {b: (round(float(r[b]), 3) if pd.notna(r[b]) else np.nan) for b in BN}
        md_ns, md_lbl, ais_ns = SIM_NS[proto]
        rows.append(dict(protocol=proto, estimator=est, switch=sw, **vals,
                         RMSE=round(float(r["RMSE"]), 3) if pd.notna(r["RMSE"]) else np.nan,
                         coverage=cov(r), total_sim_ns=round(md_ns + ais_ns, 1),
                         sim_breakdown=f"{md_lbl} + {ais_ns:.0f} ns AIS"))
    tbl = pd.DataFrame(rows)
    tbl.to_csv(OUT / "cross_protocol_comparison.csv", index=False)
    print(tbl.to_string(index=False))

    # cross-protocol RMSE bar (full-coverage estimators)
    sub = tbl[tbl.protocol != "REMD reference"].copy()
    fig, ax = plt.subplots(figsize=(9.5, 4.2))
    labels = [f"{p}\n{e} ({s}) · {t:.0f} ns" for p, e, s, t in
              zip(sub.protocol, sub.estimator, sub.switch, sub.total_sim_ns)]
    colors = ["#CC3311" if "old-RITE" in p else "#0077BB" if "REMD-seeded" in p
              else "#228833" if "gold" in p else "#EE7733" for p in sub.protocol]
    ax.bar(range(len(sub)), sub.RMSE.values, color=colors)
    for i, (rm, c) in enumerate(zip(sub.RMSE.values, sub.coverage.values)):
        ax.text(i, rm + 0.03, f"{rm:.2f}\n{c}/4", ha="center", va="bottom", fontsize=7)
    ax.set_xticks(range(len(sub))); ax.set_xticklabels(labels, rotation=35, ha="right", fontsize=7)
    ax.set_ylabel("RMSE vs REMD ref (kT)")
    ax.set_title("Cross-protocol accuracy (label: RMSE / basin coverage; x-tick: total sim ns)")
    fig.tight_layout(); fig.savefig(str(PLOTS / "cross_protocol_rmse.png"), dpi=140); plt.close(fig)

    # accuracy vs cost (best full-coverage estimator per protocol)
    best = (sub[sub.coverage == 4].sort_values("RMSE")
            .groupby("protocol", as_index=False).first())
    fig, ax = plt.subplots(figsize=(7, 4.6))
    cmap = {"old-RITE production": "#CC3311", "REMD-seeded": "#0077BB",
            "REMD-2ps gold": "#228833", TOP_LABEL: "#EE7733"}
    for _, r in best.iterrows():
        ax.scatter(r.total_sim_ns, r.RMSE, s=120, color=cmap.get(r.protocol, "#EE7733"),
                   zorder=3, edgecolor="k")
        ax.annotate(f"{r.protocol}\n{r.estimator} ({r.RMSE:.2f} kT)",
                    (r.total_sim_ns, r.RMSE), fontsize=7,
                    xytext=(6, 6), textcoords="offset points")
    ax.set_xscale("log"); ax.set_xlabel("total simulation time (ns, REMD ×4 replicas)")
    ax.set_ylabel("best full-coverage RMSE vs REMD ref (kT)")
    ax.set_title("Endpoint ΔΔF accuracy vs total MD+AIS cost")
    ax.grid(alpha=0.3, which="both")
    fig.tight_layout(); fig.savefig(str(PLOTS / "accuracy_vs_cost.png"), dpi=140); plt.close(fig)
    return tbl


def main():
    cold_md_ramachandran()
    pair_hit_matrices()
    cross_protocol_table()
    print(f"\n  Saved extra plots + cross_protocol_comparison.csv -> {OUT.relative_to(ROOT)}")
    print("  plots:", sorted(p.name for p in PLOTS.glob("*.png")))


if __name__ == "__main__":
    main()
