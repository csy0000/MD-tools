#!/usr/bin/env python3
"""run_top100w_reverse_ais.py — Steps 7-8: RITE-weighted reverse-start sampling + reverse AIS.

For each included basin, draw n_reverse (default 250) reverse-start frames from that
basin's RITE-weighted cold-MD pool (with replacement ~ RITE weight), build one seed
DCD, and run reverse AIS (cold s=1.0 -> hot s=0.4) at the SAME 2 ps switch as the
forward leg.  Records reverse work + cold-start/hot-end basins.

Outputs -> results/top100w_diverse20_100ps/:
  reverse_start_table.csv, reverse_ais_results.npz, reverse_start_diag.json
Usage:  python -m escort_ais.experiments.alanine.run_top100w_reverse_ais [--n-reverse-per-basin 250] --platform CUDA
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
from escort_ais.analysis.analyze_ala_endpoint_partitioned import _assign
from escort_ais.analysis.analyze_ala_msk_all_solvers import load_phi_psi_dcd

from escort_ais.common.top100w_cfg import RESULTS as OUT, RUNS, TOP_PDB, REVRUN as RUN_DIR  # noqa: E402
RITE_IN = OUT / "rite_input"
RITE = OUT / "rite"
REMD_CFG = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_even_4rep_300K_remd_250ns/config.json"
T_AIS, FREQ = 1000, 10        # 2 ps switch, matches the 2 ps forward
_CFG_KEYS = ["prmtop_path", "inpcrd_path", "topology_solvent", "timestep_fs",
             "friction_per_ps", "temperature_k", "solvent", "n_solute_atoms"]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n-reverse-per-basin", type=int, default=250)
    ap.add_argument("--platform", default="CUDA")
    args = ap.parse_args()
    rng = np.random.default_rng(20260617)
    RUN_DIR.mkdir(parents=True, exist_ok=True)

    cold = {s: md.load_dcd(str(RUNS / f"seed_{s:03d}/trajectory.dcd"), top=str(TOP_PDB))
            for s in range(20)}
    basins = sorted(int(p.name.split("_")[1]) for p in RITE_IN.glob("basin_*"))

    xyz, rows, start_basin, diag = [], [], [], {}
    for B in basins:
        src = np.load(RITE_IN / f"basin_{B}/frame_src.npy")        # (n,2): seed, md_frame
        w = np.load(RITE / f"basin_{B}_default.npy"); w = w / w.sum()
        pick = rng.choice(len(src), args.n_reverse_per_basin, replace=True, p=w)
        uniq, counts = np.unique(pick, return_counts=True)
        diag[str(B)] = dict(n_reverse=int(args.n_reverse_per_basin),
                            n_unique=int(len(uniq)), max_dup=int(counts.max()),
                            ESS_resample=round(float(w.sum() ** 2 / np.sum(w ** 2)), 1))
        if diag[str(B)]["max_dup"] > 0.2 * args.n_reverse_per_basin:
            print(f"  WARNING: basin {B} reverse starts dominated by few RITE frames "
                  f"(max_dup={diag[str(B)]['max_dup']}).")
        for p in pick:
            s, mf = int(src[p, 0]), int(src[p, 1])
            xyz.append(cold[s].xyz[mf])
            start_basin.append(B)
            rows.append(dict(reverse_start_frame_id=len(rows), source_seed_simulation=s,
                             source_time_ps=mf, basin=B, RITE_weight=float(w[p])))
    pd.DataFrame(rows).to_csv(OUT / "reverse_start_table.csv", index=False)
    json.dump(diag, open(OUT / "reverse_start_diag.json", "w"), indent=2)
    start_basin = np.array(start_basin)
    print(f"  reverse starts: {len(rows)} ({[int((start_basin==B).sum()) for B in basins]} per basin)")

    # build seed dir with the resampled structures
    seed_dir = RUN_DIR / "seed_cold_rite"
    seed_dir.mkdir(parents=True, exist_ok=True)
    seed = md.Trajectory(np.array(xyz), cold[0].topology)
    seed.save_dcd(str(seed_dir / "trajectory.dcd"))
    shutil.copy2(TOP_PDB, seed_dir / "start_structure.pdb")
    cfg = json.loads(REMD_CFG.read_text())
    (seed_dir / "config.json").write_text(json.dumps({k: cfg[k] for k in _CFG_KEYS}, indent=2))

    # reverse AIS (cold s=1.0 -> hot s=0.4), 2 ps, one trajectory per seed frame
    out = RUN_DIR / "step_reverse_ais"
    print(f"  running reverse AIS: {len(xyz)} trajs, 2 ps (cold->hot) ...")
    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=len(xyz), t_ais=T_AIS, freq_ais=FREQ,
        s_hot=1.0, s_cold=0.4, seed=20260619,
        start_frame_offset=0, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=out,
        platform=args.platform, dry_run=False, overwrite=True))

    # map outputs back: cold-start basin via seed index; hot-end basin via final coords
    logw_r = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].values
    sel = pd.read_csv(out / "selected_initial_frames.csv")["initial_frame_index"].astype(int).values
    cold_start = start_basin[sel]
    phe, pse = load_phi_psi_dcd(out / "ais_final_coordinates.dcd")
    hot_end = _assign(phe, pse)
    np.savez(OUT / "reverse_ais_results.npz", reverse_lnw=logw_r, reverse_work=-logw_r,
             reverse_cold_start_basin=cold_start, reverse_hot_end_basin=hot_end,
             reverse_endpoint_phi=phe, reverse_endpoint_psi=pse)
    print(f"  reverse AIS done: {len(logw_r)} trajs. cold-start counts="
          f"{np.bincount(cold_start, minlength=4).tolist()} hot-end counts={np.bincount(hot_end, minlength=4).tolist()}")
    print(f"  Saved -> {OUT.relative_to(ROOT)}/reverse_ais_results.npz")


if __name__ == "__main__":
    main()
