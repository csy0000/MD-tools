#!/usr/bin/env python3
"""Barrier-aligned rectangular partitioning of alanine (phi, psi) from 20 HS slices.

    python -m escort_ais.experiments.alanine.run_barrier_partition --run-dir /tmp/disc_1ps

The default is ``--partition-mode basin-tree`` with ``stop_barrier = 3 kT`` and
``--min-basin-mass 0.001``: recursive peak splitting until no leaf has a valley deeper than 3 kT,
so K follows from the landscape instead of being chosen.  It writes ``basin_tree.json`` /
``basin_tree_arrays.npz`` / ``basin_tree_partition.png``.

Other modes: ``alanine-2state``, ``alanine-3state``, ``recursive-barrier`` (with ``--n-basins``),
and ``all`` which runs the comparison of §14 and writes
``reports/alanine/ais_performance/barrier_partition{,_<mode>}.json`` plus the figure arrays.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from escort_ais.methods.barrier_partition import (PeriodicInterval, RectangularBasin,
                                                  assign_basins, basin_masses,
                                                  build_basin_tree, circ_distance,
                                                  count_density_maxima, format_basin_tree,
                                                  hz_density, partition_alanine_2state,
                                                  partition_alanine_3state, partition_to_dict,
                                                  recursive_partition, verify_partition,
                                                  wall_stiffness_from_separation)
from escort_ais.methods.rectangular_flatbottom import rect_bias_kT, rect_bias_matrix

KT_KJ_300K = 0.00831446261815324 * 300.0


def out_root() -> Path:
    from escort_ais.common.paths import project_root
    d = project_root() / "reports/alanine/ais_performance"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ───────────────────────────── the weighted cloud ────────────────────────────
def load_cloud(run_dir: Path, s_min=None) -> dict:
    """HS observations + the weighted (phi, psi) cloud used for stiffness and diagnostics."""
    import pandas as pd

    from escort_ais.analysis.hz_reconstruction import hz_log_weights

    hz = pd.read_parquet(Path(run_dir) / "merged" / "hz_observations.parquet")
    sub = hz if s_min is None else hz[hz["s"] >= s_min]
    lw = np.asarray(hz_log_weights(sub["cumulative_reduced_work"], sub["u_current_reduced"],
                                   sub["u_cold_reduced"]), float)
    # per-slice normalisation, so one ESS-starved hot slice cannot dominate the cloud
    slice_col = "observation_id" if "observation_id" in sub.columns else "observation_index"
    w = np.zeros(len(sub))
    for sid in sub[slice_col].unique():
        m = (sub[slice_col] == sid).to_numpy()
        x = np.exp(lw[m] - lw[m].max())
        w[m] = x / max(x.sum(), 1e-300)
    return dict(hz=hz, phi=np.radians(sub["phi"].to_numpy()),
                psi=np.radians(sub["psi"].to_numpy()), weight=w / w.sum(),
                trajectory=sub[("trajectory_id" if "trajectory_id" in sub.columns
                                else "trajectory_index")].to_numpy())


# ───────────────────── walls: which dimensions, and how stiff ────────────────
def assign_walls(basins, cloud, dens, k_wall: float = 100.0, adaptive: bool = False,
                 E_wall=5.0, alpha=0.5, quantile=0.1, k_min=1.0, k_max=200.0) -> dict:
    """§8-§10: a basin is walled ONLY in a dimension that actually separates it.

    A dimension whose interval is the full circle is left unrestrained (no wall, no force).

    **Stiffness: a fixed ``k_wall`` (default 100 kT/rad^2), not the inter-cluster-separation
    rule.**  That rule sets ``k`` from the gap between neighbouring clouds, but leakage of the
    restrained proposal is governed by the *density ratio across the wall*, not by how far away
    the neighbouring mode is.  Measured on the alanine tree: at the adaptive value (k = 12-14 on
    the phi walls) the smallest basin -- 0.29 % of the mass, with neighbours ~100x denser --
    leaked **60 %** of its own proposal mass, because a wide empty corridor does not stop a dense
    neighbour flooding over a soft wall.  A fixed k = 100 keeps the worst-case leakage at 1.1 %,
    sits past the knee where the importance-sampling ESS stops improving (~30 for k >= 50), and
    is verified stable at 2 fs up to k = 200.

    ``adaptive=True`` restores the separation-based rule for comparison; the geometry it computes
    is recorded either way.
    """
    phi, psi, w = cloud["phi"], cloud["psi"], cloud["weight"]
    idx = assign_basins(phi, psi, basins)
    shared: dict[tuple, dict] = {}

    for b in basins:
        b.active_walls = []
        b.wall_geometry = {}
        for dim, iv in (("phi", b.phi_interval), ("psi", b.psi_interval)):
            if iv.full:
                continue                                    # nothing to separate here
            b.active_walls.append(dim)

    # wall geometry is recorded for provenance whether or not it drives the stiffness
    for b in basins:
        for dim in list(b.active_walls):
            iv = b.phi_interval if dim == "phi" else b.psi_interval
            theta = phi if dim == "phi" else psi
            mine = idx == b.basin_id
            for cut in (iv.lower, iv.upper):
                key = (dim, round(float(cut), 9))
                if key in shared:
                    continue
                other = (idx >= 0) & (~mine)
                near = circ_distance(theta, cut) < np.radians(90.0)
                g = wall_stiffness_from_separation(
                    theta[mine & near], w[mine & near], theta[other & near], w[other & near],
                    float(cut), E_wall=E_wall, alpha=alpha, quantile=quantile,
                    k_min=k_min, k_max=k_max)
                g.update(dimension=dim, cut_rad=float(cut), cut_deg=float(np.degrees(cut)),
                         k_separation_rule=g["k"], k_applied=None)
                shared[key] = g

    for b in basins:
        for dim in b.active_walls:
            iv = b.phi_interval if dim == "phi" else b.psi_interval
            if adaptive:
                ks = [shared[(dim, round(float(c), 9))]["k_separation_rule"]
                      for c in (iv.lower, iv.upper)
                      if (dim, round(float(c), 9)) in shared]
                k = float(max(ks)) if ks else float(k_max)
            else:
                k = float(k_wall)
            setattr(b, "k_phi" if dim == "phi" else "k_psi", k)
            for c in (iv.lower, iv.upper):
                key = (dim, round(float(c), 9))
                if key in shared:
                    shared[key]["k_applied"] = k
            b.wall_geometry[dim] = [shared[(dim, round(float(c), 9))]
                                    for c in (iv.lower, iv.upper)
                                    if (dim, round(float(c), 9)) in shared]
        if "phi" not in b.active_walls:
            b.k_phi = None
        if "psi" not in b.active_walls:
            b.k_psi = None
    return dict(mode=("separation-rule" if adaptive else "fixed"),
                k_wall=(None if adaptive else float(k_wall)),
                shared_walls={f"{k[0]}@{np.degrees(k[1]):.1f}": v for k, v in shared.items()})


def proposal_leakage(basins, dens) -> dict:
    """Mass of ``pi_m ~ p_cold * exp(-U_m)`` that falls OUTSIDE basin m -- the quantity the wall
    stiffness actually has to control."""
    C = dens["centres"]
    P, Q = np.meshgrid(C, C, indexing="ij")
    pc = dens["density"]
    out = {}
    for b in basins:
        q = pc * np.exp(-rect_bias_kT(P, Q, b))
        q = q / max(q.sum(), 1e-300)
        out[b.basin_id] = float(1.0 - q[b.contains(P, Q)].sum())
    return out


# ───────────────────────────── bootstrap stability ───────────────────────────
def _circ_sd(v: np.ndarray) -> tuple[float, float]:
    """(mean, circular SD) in radians of a set of angles."""
    s, c = np.mean(np.sin(v)), np.mean(np.cos(v))
    R = np.hypot(s, c)
    return float(np.arctan2(s, c)), float(np.sqrt(-2 * np.log(max(R, 1e-12))))


def _orient_pair(pair, ref):
    """Order a replicate's two boundaries to match the reference pair.

    Cutting a periodic coordinate produces TWO boundaries and the search returns them in whatever
    order it found them.  Comparing replicate boundary 0 against reference boundary 0 blindly mixes
    the two and reports a spurious ~70 deg SD for a cut that is in fact stable.
    """
    a, b = pair
    ra, rb = ref
    if b is None or rb is None:
        return a, b
    same = circ_distance(a, ra) + circ_distance(b, rb)
    swap = circ_distance(a, rb) + circ_distance(b, ra)
    return (a, b) if same <= swap else (b, a)


def bootstrap_cut_stability(cloud, dens_kw, partition_fn, n_boot=40, seed=0,
                            reference_cuts=None) -> dict:
    """Trajectory-level bootstrap of every selected cut and **both** of its boundaries (§5.3)."""
    import pandas as pd

    hz = cloud["hz"]
    traj_col = "trajectory_id" if "trajectory_id" in hz.columns else "trajectory_index"
    trajs = np.unique(hz[traj_col].to_numpy())
    ref = [(c["value_rad"], c.get("value2_rad")) for c in (reference_cuts or [])]
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(int(n_boot)):
        pick = rng.choice(trajs, size=trajs.size, replace=True)
        boot = pd.concat([hz[hz[traj_col] == t] for t in pick], ignore_index=True)
        try:
            d = hz_density(boot, **dens_kw)
            res = partition_fn(d)
            pairs = [(c["value_rad"], c.get("value2_rad")) for c in res["cuts"]]
            rows.append([_orient_pair(p, ref[j]) if j < len(ref) else p
                         for j, p in enumerate(pairs)])
        except Exception:
            continue
    if not rows:
        return dict(n_boot=0)
    # Ragged on purpose: a variable-K partition (the basin tree) can return a different number of
    # cuts per replicate, and taking min() over all of them lets ONE degenerate replicate erase the
    # whole bootstrap.  Cut j is instead averaged over the replicates that actually reached depth j,
    # with the coverage recorded.  Index matching is only meaningful while the tree shape is stable,
    # so the distribution of K is reported alongside.
    n_cuts = max(len(r) for r in rows)
    counts = {}
    for r in rows:
        counts[len(r)] = counts.get(len(r), 0) + 1
    out = []
    for j in range(n_cuts):
        got = [r[j] for r in rows if len(r) > j]
        v = np.array([p[0] for p in got], float)
        mean, sd = _circ_sd(v)
        v2 = np.array([p[1] for p in got if p[1] is not None], float)
        mean2, sd2 = _circ_sd(v2) if v2.size else (float("nan"), float("nan"))
        # The cut is only as stable as its LOOSER boundary -- both must land in a corridor.
        worst = max(sd, sd2) if v2.size else sd
        out.append(dict(cut_index=j, mean_rad=mean, mean_deg=float(np.degrees(mean)),
                        circular_sd_rad=float(worst),
                        circular_sd_deg=float(np.degrees(worst)),
                        boundary1_sd_deg=float(np.degrees(sd)),
                        boundary2_mean_deg=float(np.degrees(mean2)),
                        boundary2_sd_deg=float(np.degrees(sd2)),
                        n_boot=int(v.size),
                        frac_replicates=float(v.size / len(rows))))
    return dict(n_boot=int(len(rows)), cuts=out,
                n_cuts_histogram={str(k): int(n) for k, n in sorted(counts.items())},
                frac_same_n_cuts=float(max(counts.values()) / len(rows)))


# ──────────────────────────────── diagnostics ────────────────────────────────
def partition_diagnostics(basins, cloud, dens) -> dict:
    """§14 metrics that do not need new MD."""
    phi, psi, w = cloud["phi"], cloud["psi"], cloud["weight"]
    idx = assign_basins(phi, psi, basins)
    B = rect_bias_matrix(phi, psi, basins)                 # (N, M) in kT
    masses = basin_masses(dens, basins)

    rows = []
    for m, b in enumerate(basins):
        sel = idx == b.basin_id
        u = B[:, m]
        wm = w * np.exp(-u)
        wm = wm / max(wm.sum(), 1e-300)
        rows.append(dict(
            basin_id=b.basin_id, label=b.label,
            phi_interval_deg=[b.phi_interval.as_dict()["lower_deg"],
                              b.phi_interval.as_dict()["upper_deg"]],
            psi_interval_deg=[b.psi_interval.as_dict()["lower_deg"],
                              b.psi_interval.as_dict()["upper_deg"]],
            mass_grid=float(masses[m]), mass_samples=float(w[sel].sum()),
            n_samples=int(sel.sum()), area_fraction=b.area_fraction,
            active_walls=list(b.active_walls), k_phi=b.k_phi, k_psi=b.k_psi,
            n_density_maxima=int(count_density_maxima(dens, b)),
            restraint_energy_kT=dict(
                mean=float(np.average(u, weights=w)), median=float(np.median(u)),
                p90=float(np.quantile(u, 0.9)), max=float(u.max()),
                frac_zero=float(np.average((u == 0).astype(float), weights=w))),
            proposal_ess=float(1.0 / np.sum(wm ** 2)),
            proposal_ess_fraction=float(1.0 / np.sum(wm ** 2) / len(wm))))

    # pairwise proposal overlap (Bhattacharyya on the reweighted grid densities)
    p = dens["density"]
    C = dens["centres"]
    PH, PS = np.meshgrid(C, C, indexing="ij")
    dens_m = []
    for b in basins:
        q = p * np.exp(-rect_bias_kT(PH, PS, b))
        dens_m.append(q / max(q.sum(), 1e-300))
    M = len(basins)
    OV = np.eye(M)
    for i in range(M):
        for j in range(i + 1, M):
            OV[i, j] = OV[j, i] = float(np.sum(np.sqrt(dens_m[i] * dens_m[j])))
    leak = proposal_leakage(basins, dens)
    for r in rows:
        r["proposal_leakage"] = leak[r["basin_id"]]
    return dict(basins=rows, proposal_overlap=OV.tolist(),
                proposal_leakage=leak, worst_leakage=float(max(leak.values())),
                max_offdiag_overlap=float(OV[~np.eye(M, dtype=bool)].max()) if M > 1 else 0.0,
                total_mass_grid=float(masses.sum()))


def allocate_reverse(diag: dict, n_total: int = 600, n_min: int = 30) -> dict:
    """§15: pilot floor per basin, then N_m ~ sqrt(g_m Var(I_m)).

    Without reverse trajectories in hand, the influence variance is approximated by the
    within-basin variance of the restraint-weighted cold influence ``I_m = e^{-U_m}`` and the
    statistical inefficiency ``g_m = N_m / ESS_m``.  This is a *pilot allocation*; the report
    states plainly that it must be refreshed from real reverse works after the pilot.
    """
    rows = diag["basins"]
    g = np.array([max(r["n_samples"], 1) / max(r["proposal_ess"], 1e-9) for r in rows])
    var = np.array([max(r["restraint_energy_kT"]["p90"] - r["restraint_energy_kT"]["median"],
                        1e-3) for r in rows])
    score = np.sqrt(g * var)
    floor = np.full(len(rows), int(n_min))
    extra = max(int(n_total) - int(floor.sum()), 0)
    add = np.floor(extra * score / score.sum()).astype(int) if score.sum() > 0 else 0 * floor
    N = floor + add
    return dict(n_total_requested=int(n_total), n_min=int(n_min),
                allocation={int(r["basin_id"]): int(n) for r, n in zip(rows, N)},
                score=[float(x) for x in score], g=[float(x) for x in g],
                note=("pilot allocation: influence variance is proxied by the restraint-energy "
                      "spread and the statistical inefficiency; refresh from real reverse works "
                      "after the pilot"))


# ─────────────────────────────────── figures ─────────────────────────────────
def make_figure(dens, basins, cuts, diag, path: Path, title: str, cloud=None):
    """Three panels: the HS PMF, the barrier profiles that produced each cut, and the partition.

    A cut chosen *conditionally* inside a parent region is drawn only across that region, and its
    profile panel shows the CONDITIONAL marginal it was actually selected from — a global
    marginal would not show a minimum where the cut sits, which would misrepresent the method.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from escort_ais.methods.barrier_partition import conditional_marginal, projected_pmf

    C = np.degrees(dens["centres"])
    F = np.ma.masked_invalid(dens["free_energy"])
    fig, axes = plt.subplots(1, 3, figsize=(18.5, 5.6))
    cmap = plt.cm.viridis_r.copy()
    cmap.set_bad(cmap(1.0))                       # empty bins are HIGH free energy, not blank

    im = axes[0].pcolormesh(C, C, np.clip(F, 0, 8).T, cmap=cmap, shading="auto")
    plt.colorbar(im, ax=axes[0], label="F (kT)")
    axes[0].set_title(f"HS-reconstructed PMF ({dens['n_slices']} slices, "
                      f"s={min(dens['slice_s_values']):.2f}-{max(dens['slice_s_values']):.2f})")

    # ── panel 2: the profile each cut was actually selected from ────────────
    ax = axes[1]
    for ci, c in enumerate(cuts):
        ext = c.get("parent_extent")
        region = RectangularBasin(
            0,
            (PeriodicInterval.full_circle() if not ext or ext["phi"].get("full")
             else PeriodicInterval.from_bounds(ext["phi"]["lower"], ext["phi"]["upper"])),
            (PeriodicInterval.full_circle() if not ext or ext["psi"].get("full")
             else PeriodicInterval.from_bounds(ext["psi"]["lower"], ext["psi"]["upper"])))
        a, m = conditional_marginal(dens, region, c["dimension"])
        # Min-shifted, exactly as the barrier score sees it: F = 0 at that region's own mode, so
        # a curve's height IS the barrier above the deepest well of the region it was scored in.
        # Each curve is shifted by its OWN minimum, because the two are conditional on different
        # regions and a shared offset would make them incomparable.
        Fprof = projected_pmf(m)          # NOT `F` -- that name holds the 2-D map below
        lab = ("global" if c.get("parent_region", "root") == "root"
               else f"conditional on {c['parent_region']}")
        col = plt.cm.tab10(ci)
        o = np.argsort(a)
        ax.plot(np.degrees(a[o]), Fprof[o], color=col, label=f"F_{c['dimension']}  ({lab})")
        for key, style in (("value_deg", "--"), ("value2_deg", ":")):
            if key in c and c[key] is not None:
                ax.axvline(c[key], color=col, ls=style, lw=1.8)
                ax.annotate(f"{c['dimension']}={c[key]:.0f}°", (c[key], ax.get_ylim()[1]),
                            color=col, fontsize=7.5, va="top", ha="left", rotation=90)
    ax.axhline(0.0, color="0.6", lw=0.8, zorder=0)
    ax.set_xlabel("cut position (deg)")
    ax.set_ylabel("F = −log(marginal), min-shifted to 0  (kT)")
    ax.legend(fontsize=7.5, loc="lower right")
    ax.set_title("barrier profiles the cuts were selected from")

    # ── panel 3: the partition itself ───────────────────────────────────────
    ax = axes[2]
    ax.pcolormesh(C, C, np.clip(F, 0, 8).T, cmap="Greys", shading="auto", alpha=.5)
    if cloud is not None:
        ax.scatter(np.degrees(cloud["phi"]), np.degrees(cloud["psi"]), s=1.2, c="0.25",
                   alpha=.20, lw=0)
    cols = plt.cm.tab10(np.arange(len(basins)))
    for b, col, row in zip(basins, cols, diag["basins"]):
        pi_, ps_ = b.phi_interval, b.psi_interval
        for xoff in (-360, 0, 360):
            for yoff in (-360, 0, 360):
                ax.add_patch(plt.Rectangle((np.degrees(pi_.lower) + xoff,
                                            np.degrees(ps_.lower) + yoff),
                                           np.degrees(pi_.width), np.degrees(ps_.width),
                                           fill=False, ec=col, lw=2.6, zorder=4))
        walls = "+".join(row["active_walls"]) or "none"
        kk = "  ".join(f"k{d}={row['k_' + d]:.0f}" for d in row["active_walls"]
                       if row.get("k_" + d) is not None)
        ax.annotate(f"{b.label}  mass={row['mass_grid']:.3f}\nwalls: {walls}\n{kk}",
                    (np.degrees(pi_.centre), np.degrees(ps_.centre)), ha="center", va="center",
                    fontsize=7.5, zorder=6,
                    bbox=dict(fc="white", alpha=.85, ec=col, lw=1.4, boxstyle="round,pad=0.3"))
    # cuts: a conditional cut spans ONLY its parent region
    for c in cuts:
        ext = c.get("parent_extent") or {}
        for key in ("value_deg", "value2_deg"):
            if key not in c or c[key] is None:
                continue
            if c["dimension"] == "phi":
                pe = ext.get("psi")
                lo, hi = ((-180, 180) if not pe or pe.get("full")
                          else (pe["lower_deg"], pe["lower_deg"] + np.degrees(pe["width"])))
                ax.plot([c[key], c[key]], [lo, hi], color="crimson", ls="--", lw=2.2, zorder=5)
            else:
                pe = ext.get("phi")
                lo, hi = ((-180, 180) if not pe or pe.get("full")
                          else (pe["lower_deg"], pe["lower_deg"] + np.degrees(pe["width"])))
                ax.plot([lo, hi], [c[key], c[key]], color="crimson", ls="--", lw=2.2, zorder=5)
    ax.set_title(title)

    for a in axes:
        a.set_xlim(-180, 180); a.set_xticks([-180, -90, 0, 90, 180])
    for a in (axes[0], axes[2]):
        a.set_ylim(-180, 180); a.set_yticks([-180, -90, 0, 90, 180])
        a.set_xlabel("φ (deg)"); a.set_ylabel("ψ (deg)")
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close(fig)
    return path


def construction_trace(res: dict, bridges=None) -> list[dict]:
    """Replay the construction one step at a time: which region was split, on what evidence.

    Every number here is read back out of the tree that was actually built — nothing is
    recomputed, so the trace cannot drift from the partition it describes.  Steps are ordered by
    the id of the node that was split, which is the order the recursion created them.
    """
    tree = {int(k): v for k, v in res["tree"].items()}
    split_nodes = sorted((n for n in tree.values() if n.get("split")), key=lambda n: n["node_id"])
    steps = []
    regions = {0: tree[0]}                     # node_id -> node, as the frontier evolves
    for step, node in enumerate(split_nodes, start=1):
        sp = node["split"]
        kids = [tree[c] for c in node["children"]]
        regions.pop(node["node_id"], None)
        for k in kids:
            regions[k["node_id"]] = k
        steps.append(dict(
            step=step,
            node=f"n{node['node_id']}",
            node_mass=float(node["mass"]),
            depth=int(node["depth"]),
            dimension=sp["dimension"],
            n_peaks=int(sp.get("n_peaks", 0)),
            peak_angles_deg=[float(x) for x in sp.get("peak_angles_deg", [])],
            cuts_deg=[float(v["angle_deg"]) for v in sp.get("valleys", [])],
            barrier_kT=float(sp["barrier_height_kT"]),
            per_cut=[dict(cut_deg=float(v["angle_deg"]),
                          barrier_kT=float(v["barrier_height_kT"]),
                          F_valley_kT=float(v["F_valley_kT"]),
                          peak_left_deg=float(v["peak_left_deg"]),
                          peak_right_deg=float(v["peak_right_deg"]),
                          F_peak_left_kT=float(v["F_peak_left_kT"]),
                          F_peak_right_kT=float(v["F_peak_right_kT"]),
                          unsampled_valley=bool(v.get("unsampled_valley", False)))
                     for v in sp.get("valleys", [])],
            checks=dict(sp.get("checks", {})),
            children=[dict(node=f"n{k['node_id']}", mass=float(k["mass"]),
                           phi_deg=_iv_deg(k["phi_interval"]), psi_deg=_iv_deg(k["psi_interval"]),
                           is_leaf=bool(k["is_leaf"]),
                           stop_reason=k.get("stop_reason")) for k in kids],
            n_regions_after=len(regions)))
    for node in sorted((n for n in tree.values() if n.get("is_leaf")),
                       key=lambda n: n["node_id"]):
        steps.append(dict(step=None, node=f"n{node['node_id']}", terminal=True,
                          mass=float(node["mass"]), stop_reason=node.get("stop_reason")))
    if bridges:
        for b in bridges:
            steps.append(dict(step=None, bridge=b["proposal_id"], mu_deg=b["mu_deg"],
                              k=b["k"], on_cut=b.get("bridges_cut")))
    return steps


def format_construction_trace(trace: list[dict], bridges=None) -> str:
    """Render the trace as markdown: one section per split, then the leaves, then the bridges."""
    L = ["Every step below is read back out of the tree that was built, so the walkthrough and",
         "the partition cannot disagree.  A step answers four questions: *which region*, *which",
         "dimension*, *what evidence*, *what came out*.", ""]
    L += ["**Step 0 — one region.**  The construction starts from a single periodic rectangle "
          "covering the whole (φ, ψ) torus: φ ∈ full circle, ψ ∈ full circle, mass 1.  It is a "
          "leaf and a root at once, and the only candidate for splitting.", ""]
    for s in trace:
        if not s.get("step"):
            continue
        c = s["checks"]
        L.append(f"**Step {s['step']} — split `{s['node']}` (mass {s['node_mass']:.4f}) "
                 f"on {s['dimension']}.**")
        L.append("")
        L.append(f"- *Evidence.*  Project `{s['node']}`'s density onto {s['dimension']} alone, "
                 f"take `F = −log(marginal)`, and read its peaks: "
                 f"{len(s['peak_angles_deg'])} of them at "
                 + ", ".join(f"{a:+.0f}°" for a in s["peak_angles_deg"]) + ".")
        for pc in s["per_cut"]:
            L.append(f"- *Cut at {pc['cut_deg']:+.0f}°.*  The valley between the peaks at "
                     f"{pc['peak_left_deg']:+.0f}° (F = {pc['F_peak_left_kT']:.2f} kT) and "
                     f"{pc['peak_right_deg']:+.0f}° (F = {pc['F_peak_right_kT']:.2f} kT) sits at "
                     f"F = {pc['F_valley_kT']:.2f} kT, so the barrier is "
                     f"ΔF = {pc['barrier_kT']:.2f} kT"
                     + ("  (**unsampled valley** — this is a lower bound set by the "
                        "reconstruction floor)" if pc["unsampled_valley"] else "") + ".")
        if len(s["per_cut"]) == 2:
            L.append(f"  Two cuts, not one: {s['dimension']} is periodic, so separating a full "
                     f"circle needs **two** boundaries.  The split is only as good as its weaker "
                     f"side, ΔF = {s['barrier_kT']:.2f} kT.")
        L.append(f"- *Admissibility.*  peak separation {'ok' if c.get('peak_separation') else 'FAIL'}"
                 f", minimum width {'ok' if c.get('min_width') else 'FAIL'}"
                 f", mass on both sides {'ok' if c.get('mass_both_sides') else 'FAIL'}"
                 f"; barrier {s['barrier_kT']:.2f} kT clears the stopping threshold.")
        L.append("- *Result.*  " + "; ".join(
            f"`{k['node']}` φ {k['phi_deg']}, ψ {k['psi_deg']}, mass {k['mass']:.4f}"
            for k in s["children"]) + f".  The frontier now holds {s['n_regions_after']} regions.")
        L.append("")
    L.append("**Stopping.**  Splitting ends when no region on the frontier has an admissible "
             "valley deeper than the threshold:")
    L.append("")
    for s in trace:
        if s.get("terminal"):
            L.append(f"- `{s['node']}` (mass {s['mass']:.4f}) — {s['stop_reason']}")
    L.append("")
    if bridges:
        L.append("**Bridges.**  The leaves tile the torus and, with stiff walls, barely overlap; "
                 "the mixture reconstruction then cannot tie their free energies together.  One "
                 "*harmonic* window is added per cut boundary, centred ON the barrier — harmonic "
                 "and not flat-bottom, because a flat core exerts no restoring force exactly "
                 "where the crossing has to happen:")
        L.append("")
        for b in bridges:
            oc = b.get("on_cut") or {}
            L.append(f"- `{b['bridge']}` at (φ, ψ) = ({b['mu_deg'][0]:+.0f}°, "
                     f"{b['mu_deg'][1]:+.0f}°), k = {b['k'][0]:g} kT/rad², on the "
                     f"{oc.get('dimension')} cut of `{oc.get('parent_region')}` "
                     f"(ΔF = {oc.get('barrier_height_kT', float('nan')):.2f} kT)")
        L.append("")
    return "\n".join(L)


def _iv_deg(iv: dict) -> str:
    if iv.get("full"):
        return "full circle"
    return (f"[{iv['lower_deg']:+.0f}, {iv['upper_deg']:+.0f})"
            + (" wraps" if iv.get("wraps") else ""))


def make_step_figure(dens, res, path: Path):
    """One panel per construction step: the region being split, its marginal, and the cut."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from escort_ais.methods.barrier_partition import conditional_marginal, projected_pmf

    tree = {int(k): v for k, v in res["tree"].items()}
    split_nodes = sorted((n for n in tree.values() if n.get("split")), key=lambda n: n["node_id"])
    n_steps = len(split_nodes)
    C = np.degrees(dens["centres"])
    F2 = np.ma.masked_invalid(dens["free_energy"])
    cmap = plt.cm.viridis_r.copy()
    cmap.set_bad(cmap(1.0))

    fig, axes = plt.subplots(2, n_steps + 1, figsize=(5.4 * (n_steps + 1), 9.2))
    axes = np.atleast_2d(axes)

    def draw_map(ax, regions, title, highlight=None, cuts=None, dim=None):
        ax.pcolormesh(C, C, np.clip(F2, 0, 8).T, cmap=cmap, shading="auto")
        for nid, r in regions.items():
            pi_, ps_ = r["phi_interval"], r["psi_interval"]
            lo_p, w_p = pi_["lower_deg"], np.degrees(pi_["width"])
            lo_s, w_s = ps_["lower_deg"], np.degrees(ps_["width"])
            col = "crimson" if nid == highlight else "white"
            for xo in (-360, 0, 360):
                for yo in (-360, 0, 360):
                    ax.add_patch(plt.Rectangle((lo_p + xo, lo_s + yo), w_p, w_s, fill=False,
                                               ec=col, lw=(3.0 if nid == highlight else 1.8)))
            ax.annotate(f"n{nid}\n{r['mass']:.4f}", (lo_p + w_p / 2, lo_s + w_s / 2),
                        ha="center", va="center", fontsize=8, color="w",
                        bbox=dict(fc="k", alpha=.45, ec="none", boxstyle="round,pad=0.2"))
        for v in (cuts or []):
            if dim == "phi":
                ax.axvline(v, color="crimson", ls="--", lw=2.0)
            else:
                ax.axhline(v, color="crimson", ls="--", lw=2.0)
        ax.set_xlim(-180, 180); ax.set_ylim(-180, 180)
        ax.set_xticks([-180, -90, 0, 90, 180]); ax.set_yticks([-180, -90, 0, 90, 180])
        ax.set_xlabel("φ (deg)"); ax.set_ylabel("ψ (deg)")
        ax.set_title(title, fontsize=10)

    regions = {0: tree[0]}
    draw_map(axes[0, 0], regions, "step 0: one region, the whole torus")
    axes[1, 0].axis("off")
    axes[1, 0].text(0.02, 0.5, "start: a single periodic rectangle\ncovering the whole (φ, ψ) "
                    "torus,\nmass 1 by construction.", fontsize=11, va="center")

    from escort_ais.methods.barrier_partition import RectangularBasin  # noqa: F401
    for j, node in enumerate(split_nodes, start=1):
        sp = node["split"]
        cuts = [v["angle_deg"] for v in sp["valleys"]]
        draw_map(axes[0, j], regions, f"step {j}: split n{node['node_id']} on {sp['dimension']}",
                 highlight=node["node_id"], cuts=cuts, dim=sp["dimension"])
        # the conditional marginal the cut was read off
        basin = _node_region(node)
        ang, prof = conditional_marginal(dens, basin, sp["dimension"])
        F = projected_pmf(prof)
        F = F - F.min()
        ax = axes[1, j]
        ax.plot(np.degrees(ang), F, lw=1.8,
                label=f"F_{sp['dimension']} | n{node['node_id']}")
        for v in sp["valleys"]:
            ax.axvline(v["angle_deg"], color="crimson", ls="--", lw=2.0)
            ax.annotate(f"{v['angle_deg']:+.0f}°\nΔF={v['barrier_height_kT']:.2f} kT",
                        (v["angle_deg"], F.max() * 0.92), fontsize=8, ha="center",
                        bbox=dict(fc="w", alpha=.85, ec="crimson", boxstyle="round,pad=0.2"))
        for pk in sp.get("peak_angles_deg", []):
            ax.axvline(pk, color="tab:green", ls=":", lw=1.4)
        ax.set_xlim(-180, 180)
        ax.set_xlabel(f"{sp['dimension']} (deg)")
        ax.set_ylabel("F = −log(marginal), min-shifted (kT)")
        ax.set_title(f"peaks (green) and the valley cut from n{node['node_id']}", fontsize=9)
        ax.legend(fontsize=8)
        regions.pop(node["node_id"], None)
        for c in node["children"]:
            regions[c] = tree[c]

    plt.tight_layout()
    plt.savefig(path, dpi=140)
    plt.close(fig)
    return path


def _node_region(node: dict):
    from escort_ais.methods.barrier_partition import PeriodicInterval, RectangularBasin

    def _iv(x):
        return (PeriodicInterval.full_circle() if x.get("full")
                else PeriodicInterval.from_bounds(x["lower"], x["upper"]))
    return RectangularBasin(basin_id=int(node["node_id"]), phi_interval=_iv(node["phi_interval"]),
                            psi_interval=_iv(node["psi_interval"]), mass=float(node["mass"]),
                            label=f"n{node['node_id']}")


def make_landing_figure(cloud, basins, diag, path: Path, title: str):
    """The AIS landings themselves, coloured by the basin each one is assigned to.

    ``make_figure`` shows the *reconstructed density* the cuts were taken from; this shows what
    the partition does to the actual sample.  Marker area is proportional to the cold weight, so
    a landing that carries no weight cannot make a basin look populated.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    phi, psi, w = np.degrees(cloud["phi"]), np.degrees(cloud["psi"]), cloud["weight"]
    idx = assign_basins(cloud["phi"], cloud["psi"], basins)
    cols = plt.cm.tab10(np.arange(len(basins)))

    fig, axes = plt.subplots(1, 2, figsize=(13.5, 6.0))
    size = 2.0 + 900.0 * (w / max(w.max(), 1e-300))

    for ax, weighted in zip(axes, (False, True)):
        for b, col, row in zip(basins, cols, diag["basins"]):
            sel = idx == b.basin_id
            ax.scatter(phi[sel], psi[sel], s=(size[sel] if weighted else 3.0), color=col,
                       alpha=(0.55 if weighted else 0.35), lw=0,
                       label=(f"{b.label}  mass={row['mass_grid']:.4f}  "
                              f"n={int(sel.sum())}  ESS={row['proposal_ess']:.0f}"
                              if not weighted else None))
            pi_, ps_ = b.phi_interval, b.psi_interval
            for xoff in (-360, 0, 360):
                for yoff in (-360, 0, 360):
                    ax.add_patch(plt.Rectangle((np.degrees(pi_.lower) + xoff,
                                                np.degrees(ps_.lower) + yoff),
                                               np.degrees(pi_.width), np.degrees(ps_.width),
                                               fill=False, ec=col, lw=2.4, zorder=4))
        ax.set_xlim(-180, 180); ax.set_ylim(-180, 180)
        ax.set_xticks([-180, -90, 0, 90, 180]); ax.set_yticks([-180, -90, 0, 90, 180])
        ax.set_xlabel("φ (deg)"); ax.set_ylabel("ψ (deg)")
        ax.set_title("landings, marker area ∝ cold weight" if weighted
                     else "landings, one marker per HS observation")
    axes[0].legend(loc="lower left", fontsize=8, framealpha=.9, markerscale=3)
    fig.suptitle(title)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close(fig)
    return path


# ──────────────────────────────────── main ───────────────────────────────────
def build(mode: str, dens, cloud, args) -> dict:
    if mode == "alanine-2state":
        res = partition_alanine_2state(dens, search_deg=tuple(args.search_deg),
                                       fix_at_zero=args.fix_at_zero,
                                       min_basin_mass=args.min_basin_mass,
                                       min_width_deg=args.min_width_deg)
    elif mode == "alanine-3state":
        res = partition_alanine_3state(dens, search_deg=tuple(args.search_deg),
                                       fix_at_zero=args.fix_at_zero,
                                       min_basin_mass=args.min_basin_mass,
                                       min_width_deg=args.min_width_deg,
                                       barrier_threshold_kT=args.barrier_threshold)
    elif mode == "basin-tree":
        res = build_basin_tree(dens, stop_barrier_kT=(args.stop_barrier_kT
                                                      if args.stop_barrier_kT is not None else 3.0),
                               min_peak_separation_deg=args.min_peak_separation_deg,
                               min_basin_mass=args.min_basin_mass,
                               min_width_deg=args.min_width_deg,
                               max_basins=args.max_basins,
                               barrier_cap_kT=args.barrier_cap_kT,
                               ess=cloud.get("ess"))
        print(format_basin_tree(res))
    elif mode.startswith("recursive-barrier"):
        if args.stop_barrier_kT is not None:
            res = recursive_partition(dens, stop_barrier_kT=args.stop_barrier_kT,
                                      max_basins=args.max_basins,
                                      min_basin_mass=args.min_basin_mass,
                                      min_width_deg=args.min_width_deg)
            res["partition_mode"] = f"recursive-barrier-stop{args.stop_barrier_kT:g}kT"
        else:
            res = recursive_partition(dens, n_basins=args.n_basins,
                                      min_basin_mass=args.min_basin_mass,
                                      min_width_deg=args.min_width_deg,
                                      barrier_threshold_kT=args.barrier_threshold)
            res["partition_mode"] = f"recursive-barrier-K{args.n_basins}"
    else:
        raise SystemExit(f"unknown partition mode {mode!r}")

    basins = res["basins"]
    ver = verify_partition(basins, strict=True)
    walls = assign_walls(basins, cloud, dens, k_wall=args.k_wall, adaptive=args.adaptive_k,
                         E_wall=args.e_wall, alpha=args.alpha, quantile=args.quantile,
                         k_min=args.k_min, k_max=args.k_max)
    diag = partition_diagnostics(basins, cloud, dens)
    alloc = allocate_reverse(diag, n_total=args.n_reverse_total, n_min=args.n_min)
    res.update(verification=ver, walls=walls, diagnostics=diag, reverse_allocation=alloc)
    return res


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--run-dir", type=Path, required=True,
                    help="discovery run directory containing merged/hz_observations.parquet")
    ap.add_argument("--partition-mode", default="basin-tree",
                    choices=["alanine-2state", "alanine-3state", "recursive-barrier",
                             "basin-tree", "all"])
    ap.add_argument("--n-basins", type=int, default=3)
    ap.add_argument("--stop-barrier-kT", type=float, default=None,
                    help="Stop splitting when the best remaining barrier anywhere falls below "
                         "this (kT). The number of basins then follows from the landscape "
                         "instead of being chosen. Overrides --n-basins. In the default "
                         "basin-tree mode an unset value resolves to 3.0 kT; in "
                         "recursive-barrier it stays unset and --n-basins fixes K.")
    ap.add_argument("--max-basins", type=int, default=12,
                    help="Safety cap for --stop-barrier-kT.")
    ap.add_argument("--min-peak-separation-deg", type=float, default=30.0,
                    help="basin-tree: two density peaks closer than this are not split apart.")
    ap.add_argument("--barrier-cap-kT", type=float, default=None,
                    help="basin-tree: optional ceiling on the reported valley barrier. Off by "
                         "default -- capping makes the barrier a property of the sample size.")
    ap.add_argument("--ladder", action="store_true",
                    help="Also write the barrier ladder and the K produced by each threshold.")
    ap.add_argument("--bin-width-deg", type=float, default=4.0)
    ap.add_argument("--smooth-deg", type=float, default=4.0)
    ap.add_argument("--s-min", type=float, default=None,
                    help="drop HS slices below this REST2 scale (default: use all 20)")
    ap.add_argument("--search-deg", type=float, nargs=2, default=[-30.0, 30.0])
    ap.add_argument("--fix-at-zero", action="store_true")
    ap.add_argument("--min-basin-mass", type=float, default=0.001,
                    help="Smallest admissible basin (cold probability mass). 0.001 keeps the "
                         "alpha_L/C7ax split admissible; it also applies to the fixed-K modes.")
    ap.add_argument("--min-width-deg", type=float, default=30.0)
    ap.add_argument("--barrier-threshold", type=float, default=0.5)
    ap.add_argument("--k-wall", type=float, default=100.0,
                    help="Fixed wall stiffness in kT/rad^2 applied to every restrained "
                         "dimension (default 100: worst-case proposal leakage 1.1 %%, past the "
                         "IS-ESS knee, stable at 2 fs).")
    ap.add_argument("--adaptive-k", action="store_true",
                    help="Use the inter-cluster separation rule instead of --k-wall. Not "
                         "recommended: it under-stiffens walls next to a much denser neighbour.")
    ap.add_argument("--e-wall", type=float, default=5.0)
    ap.add_argument("--alpha", type=float, default=0.5)
    ap.add_argument("--quantile", type=float, default=0.1)
    ap.add_argument("--k-min", type=float, default=1.0)
    ap.add_argument("--k-max", type=float, default=200.0)
    ap.add_argument("--n-reverse-total", type=int, default=600)
    ap.add_argument("--n-min", type=int, default=30)
    ap.add_argument("--n-boot", type=int, default=40)
    ap.add_argument("--out-stem", default=None,
                    help="override the output file stem (default: basin_tree / "
                         "barrier_partition_<mode>). Use it to keep a variant partition "
                         "alongside the default one instead of overwriting it.")
    ap.add_argument("--trace", action="store_true",
                    help="basin-tree: also write the step-by-step construction trace (JSON) "
                         "and a per-step figure.")
    ap.add_argument("--no-figures", action="store_true")
    args = ap.parse_args(argv)

    cloud = load_cloud(args.run_dir, s_min=args.s_min)
    dens_kw = dict(bin_width_deg=args.bin_width_deg, smooth_deg=args.smooth_deg, s_min=args.s_min)
    dens = hz_density(cloud["hz"], **dens_kw)
    print(f"[partition] HS density: {dens['n_slices']} slices, s in "
          f"[{min(dens['slice_s_values']):.3f}, {max(dens['slice_s_values']):.3f}], "
          f"{args.bin_width_deg}° bins, smoothing {args.smooth_deg}°")

    modes = (["alanine-2state", "alanine-3state"] + [f"recursive-barrier:{k}" for k in (2, 3, 4, 5)]
             if args.partition_mode == "all" else [args.partition_mode])

    if args.ladder:
        from escort_ais.methods.barrier_partition import barrier_ladder_scan
        sc = barrier_ladder_scan(dens, max_basins=args.max_basins,
                                 min_basin_mass=args.min_basin_mass,
                                 min_width_deg=args.min_width_deg, pair_stride=2)
        (out_root() / "benchmark_data").mkdir(parents=True, exist_ok=True)
        (out_root() / "benchmark_data" / "barrier_ladder.json").write_text(
            json.dumps(sc, indent=2, default=str))
        print(f"[partition] barrier ladder (monotone: {sc['ladder_is_monotone']}):")
        for x in sc["ladder"]:
            v2 = (f" & {x['value2_deg']:+.0f}°" if x["value2_deg"] is not None else "")
            print(f"    K={x['n_basins']}  {x['dimension']}={x['value_deg']:+.0f}°{v2}"
                  f"  ΔF={x['barrier_height_kT']:5.2f} kT  (inside {x['parent']})")
        print("[partition] basins per stopping threshold:")
        for r in sc["k_vs_threshold"]:
            print(f"    stop_barrier = {r['threshold_kT']:5.2f} kT -> K = {r['n_basins']}")

    everything = {}
    for mode in modes:
        m, _, k = mode.partition(":")
        if k:
            args.n_basins = int(k)
        res = build(m, dens, cloud, args)
        tag = res.get("partition_mode", m)

        boot_fn = {"alanine-2state": lambda d: partition_alanine_2state(
                       d, search_deg=tuple(args.search_deg), fix_at_zero=args.fix_at_zero,
                       min_basin_mass=args.min_basin_mass, min_width_deg=args.min_width_deg),
                   "alanine-3state": lambda d: partition_alanine_3state(
                       d, search_deg=tuple(args.search_deg), fix_at_zero=args.fix_at_zero,
                       min_basin_mass=args.min_basin_mass, min_width_deg=args.min_width_deg,
                       barrier_threshold_kT=args.barrier_threshold),
                   "basin-tree": lambda d: build_basin_tree(
                       d, stop_barrier_kT=(args.stop_barrier_kT
                                           if args.stop_barrier_kT is not None else 3.0),
                       min_peak_separation_deg=args.min_peak_separation_deg,
                       min_basin_mass=args.min_basin_mass, min_width_deg=args.min_width_deg,
                       max_basins=args.max_basins, barrier_cap_kT=args.barrier_cap_kT),
                   }.get(m, lambda d: recursive_partition(
                       d, n_basins=args.n_basins, min_basin_mass=args.min_basin_mass,
                       min_width_deg=args.min_width_deg,
                       barrier_threshold_kT=args.barrier_threshold))
        res["bootstrap"] = bootstrap_cut_stability(cloud, dens_kw, boot_fn, n_boot=args.n_boot,
                                                   reference_cuts=res["cuts"])
        for c, bs in zip(res["cuts"], res["bootstrap"].get("cuts", [])):
            c["bootstrap_sd_rad"] = bs["circular_sd_rad"]
            c["bootstrap_sd_deg"] = bs["circular_sd_deg"]

        extra = dict(verification=res["verification"], walls=res["walls"],
                     diagnostics=res["diagnostics"],
                     reverse_allocation=res["reverse_allocation"],
                     bootstrap=res["bootstrap"], source_run=str(args.run_dir))
        if m == "basin-tree":                       # the tree IS the provenance of every wall
            extra.update(tree=res["tree"], stop_barrier_kT=res["stop_barrier_kT"],
                         barrier_cap_kT=res.get("barrier_cap_kT"), ess=res.get("ess"))
        payload = partition_to_dict(res, dens, partition_mode=tag, extra=extra)
        stem = (args.out_stem if args.out_stem else
                ("basin_tree" if m == "basin-tree" else f"barrier_partition_{tag}"))
        p = out_root() / f"{stem}.json"
        p.write_text(json.dumps(payload, indent=2, default=str))
        # barrier_partition.json is the CANONICAL contract other code consumes, so a variant run
        # must not overwrite it: --out-stem means "keep this alongside the default one".
        if not args.out_stem and (m == args.partition_mode
                                  or (args.partition_mode == "alanine-3state"
                                      and m == "alanine-3state")):
            (out_root() / "barrier_partition.json").write_text(
                json.dumps(payload, indent=2, default=str))
        everything[tag] = payload

        print(f"\n[{tag}] {len(res['basins'])} basins  "
              f"(exact single cover: {res['verification']['exact_single_cover']}, "
              f"periodic-invariant: {res['verification']['periodic_invariant']})")
        for c in res["cuts"]:
            second = (f" & {c['value2_deg']:+.1f}°"
                      if c.get("value2_deg") is not None else "")
            print(f"   cut {c['dimension']} = {c['value_deg']:+7.1f}°{second}"
                  f"  ΔF={c['barrier_height_kT']:5.2f} kT"
                  f"  parent={c.get('parent_region','root'):8s}"
                  f"  bootstrap SD={c.get('bootstrap_sd_deg', float('nan')):.1f}°")
        for r in res["diagnostics"]["basins"]:
            print(f"   {r['label']}: mass={r['mass_grid']:.4f} area={r['area_fraction']:.3f} "
                  f"walls={r['active_walls'] or 'none'} k_phi={r['k_phi']} k_psi={r['k_psi']} "
                  f"maxima={r['n_density_maxima']} ESS={r['proposal_ess']:.0f} "
                  f"N_rev={res['reverse_allocation']['allocation'][r['basin_id']]}")
        print(f"   max off-diagonal proposal overlap: {res['diagnostics']['max_offdiag_overlap']:.3f}")

        if not args.no_figures:
            fig = out_root() / (f"{stem}_partition.png" if m == "basin-tree"
                                else f"barrier_partition_{tag}.png")
            title = (f"basin tree, stop_barrier = {res['stop_barrier_kT']:g} kT"
                     if m == "basin-tree" else f"{tag}: barrier-aligned rectangular basins")
            make_figure(dens, res["basins"], res["cuts"], res["diagnostics"], fig,
                        title, cloud=cloud)
            land = out_root() / f"{stem}_landings.png"
            make_landing_figure(cloud, res["basins"], res["diagnostics"], land,
                                f"{tag}: AIS landings split into basins "
                                f"(1 ps switch, {dens['n_slices']} HS slices)")
            if m == "basin-tree" and args.trace:
                tr = construction_trace(res)
                (out_root() / f"{stem}_construction.json").write_text(
                    json.dumps(tr, indent=2, default=str))
                sfig = make_step_figure(dens, res, out_root() / f"{stem}_steps.png")
                print(f"   construction trace + {sfig.name} saved")
            np.savez_compressed(out_root() / f"{stem}_arrays.npz",
                                density=dens["density"], free_energy=dens["free_energy"],
                                centres=dens["centres"], edges=dens["edges"],
                                phi=cloud["phi"], psi=cloud["psi"], weight=cloud["weight"])
            print(f"   figures {fig.name}, {land.name} + arrays saved")

    if len(everything) > 1:
        (out_root() / "barrier_partition_comparison.json").write_text(
            json.dumps({k: dict(
                partition_mode=k, n_basins=len(v["basins"]),
                cuts=v["cuts"], verification=v["verification"],
                masses=[b["mass"] for b in v["basins"]],
                max_overlap=v["diagnostics"]["max_offdiag_overlap"],
                proposal_ess=[r["proposal_ess"] for r in v["diagnostics"]["basins"]],
                n_density_maxima=[r["n_density_maxima"] for r in v["diagnostics"]["basins"]],
                allocation=v["reverse_allocation"]["allocation"],
            ) for k, v in everything.items()}, indent=2, default=str))
        print(f"\n[partition] wrote comparison over {len(everything)} partitions")


if __name__ == "__main__":
    main()
