#!/usr/bin/env python3
"""analyze_remdfree_s04_reweight_vs_counting.py — does the AIS reweighting matter?

At 5 hot-MD budgets (sweep i = 1,5,10,15,20), compare the SAME cold-MD reservoir two ways
on the geometric Ramachandran 4 basins, both vs the converged 250 ns REMD:
  - RAW counting : histogram the reservoir with uniform weights (no AIS) -> seeding-biased
  - AIS-reweighted: weight each frame by p_{basin}/n_{basin}, p=softmax(-ddF_AIS)
For each: basin-ddF RMSE and the phi/psi surface total-variation distance vs converged REMD.
This isolates the value of the AIS free-energy reweighting (same data, same cost).

Outputs -> results/remdfree_s04_sweep/:
  reweight_vs_counting.csv, reweight_vs_counting.png
Usage:  python -m escort_ais.experiments.alanine.analyze_remdfree_s04_reweight_vs_counting
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import BURNIN_REMD, REMD_DIR, load_phi_psi_dcd  # noqa: E402
from escort_ais.analysis.remdfree_basins import assign as _assign, reference_ddF, NB as N_BASINS  # noqa: E402

FWD_ROOT = ROOT / "data/alanine_dipeptide/2026-06-18-remdfree-s04-sweep"
RUNS_ROOT = ROOT / "data/runs/remdfree_s04_sweep"
OUT = ROOT / "results/remdfree_s04_sweep"
IS = [1, 5, 10, 15, 20]
N_SEEDS, BURN_FRAMES = 20, 10
EDGES = np.linspace(-180, 180, 37)


def ddF_from_pops(pop):
    pop = np.asarray(pop, float)
    with np.errstate(divide="ignore", invalid="ignore"):
        return -np.log(pop / pop[0])


def rmse(v, ref):
    v = np.asarray(v, float); m = np.isfinite(v)
    return float(np.sqrt(np.mean((v[m] - ref[m]) ** 2))) if m.any() else np.nan


def hist2d(phi, psi, w):
    H, _, _ = np.histogram2d(phi, psi, bins=[EDGES, EDGES], weights=w, density=False)
    s = H.sum()
    return H / s if s > 0 else H


def main():
    ref = reference_ddF()
    rph, rps = load_phi_psi_dcd(REMD_DIR / "replica_00/trajectory.dcd")
    Href = hist2d(rph[BURNIN_REMD:], rps[BURNIN_REMD:], None)

    rows = []
    for i in IS:
        fdir = FWD_ROOT / f"i{i:02d}/step_forward_ais"
        logw_f = pd.read_csv(fdir / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
        eph, eps = load_phi_psi_dcd(fdir / "ais_final_coordinates.dcd")
        b_f = _assign(eph, eps)
        v2 = np.array([(-logsumexp(logw_f[b_f == b]) if (b_f == b).any() else np.nan)
                       for b in range(N_BASINS)]); v2 = v2 - v2[0]

        res_phi, res_psi = [], []
        for s in range(N_SEEDS):
            ph, ps = load_phi_psi_dcd(RUNS_ROOT / f"i{i:02d}/seed_{s:03d}/trajectory.dcd")
            res_phi.append(ph[BURN_FRAMES:]); res_psi.append(ps[BURN_FRAMES:])
        res_phi = np.concatenate(res_phi); res_psi = np.concatenate(res_psi)
        res_basin = _assign(res_phi, res_psi)
        res_pop = np.bincount(res_basin, minlength=N_BASINS).astype(float)

        # RAW counting (uniform reservoir weights)
        ddF_raw = ddF_from_pops(res_pop)
        w_raw = np.ones(len(res_basin)) / len(res_basin)
        # AIS-reweighted reservoir: p_b/n_b, p=softmax(-v2)
        fin = np.isfinite(v2); p = np.zeros(N_BASINS)
        p[fin] = np.exp(-v2[fin] - logsumexp(-v2[fin]))
        w_ais = np.zeros(len(res_basin))
        for b in range(N_BASINS):
            if p[b] > 0 and res_pop[b] > 0:
                w_ais[res_basin == b] = p[b] / res_pop[b]
        w_ais = w_ais / w_ais.sum() if w_ais.sum() > 0 else w_ais
        ddF_ais = ddF_from_pops(np.array([w_ais[res_basin == b].sum() for b in range(N_BASINS)]))

        rows.append(dict(
            i=i, hot_ns=5 * i, cost_ns=5 + 5 * i,
            rmse_raw=rmse(ddF_raw, ref), rmse_ais=rmse(ddF_ais, ref),
            tv_raw=float(0.5 * np.abs(hist2d(res_phi, res_psi, w_raw) - Href).sum()),
            tv_ais=float(0.5 * np.abs(hist2d(res_phi, res_psi, w_ais) - Href).sum())))
        print(f"  i={i:2d} cost={5+5*i:3d}ns | basin-RMSE raw={rows[-1]['rmse_raw']:.3f} "
              f"ais={rows[-1]['rmse_ais']:.3f} | surfaceTV raw={rows[-1]['tv_raw']:.3f} "
              f"ais={rows[-1]['tv_ais']:.3f}")
    df = pd.DataFrame(rows)
    df.round(4).to_csv(OUT / "reweight_vs_counting.csv", index=False)

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4))
    a1.plot(df.cost_ns, df.rmse_raw, "o--", color="0.5", label="raw counting (no AIS)")
    a1.plot(df.cost_ns, df.rmse_ais, "o-", color="#0077BB", label="AIS-reweighted")
    a1.set_xlabel("total cost (ns)"); a1.set_ylabel("basin ddF RMSE vs converged REMD (kT)")
    a1.set_title("Basin ddF: AIS reweighting vs raw counting"); a1.grid(alpha=0.3); a1.legend()
    a2.plot(df.cost_ns, df.tv_raw, "o--", color="0.5", label="raw counting (no AIS)")
    a2.plot(df.cost_ns, df.tv_ais, "o-", color="#0077BB", label="AIS-reweighted")
    a2.set_xlabel("total cost (ns)"); a2.set_ylabel("phi/psi surface TV vs converged REMD")
    a2.set_title("Surface: AIS reweighting vs raw counting"); a2.grid(alpha=0.3); a2.legend()
    fig.suptitle("Does the AIS free-energy reweighting matter? (same reservoir, 5 costs)", fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(str(OUT / "reweight_vs_counting.png"), dpi=140); plt.close(fig)
    print(f"\n  Saved reweight_vs_counting.csv + .png -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
