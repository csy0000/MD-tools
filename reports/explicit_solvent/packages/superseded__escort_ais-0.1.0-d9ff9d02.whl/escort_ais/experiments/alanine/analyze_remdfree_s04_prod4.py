#!/usr/bin/env python3
"""analyze_remdfree_s04_prod4.py — REMD-free results on the geometric Ramachandran 4 basins.

Re-evaluates the remdfree_s04 AIS data (forward + reverse, already on disk) on the fixed
geometric Ramachandran boxes (B0=C7eq/PPII, B1=Lalpha, B2=alphaR, B3=C7ax/rare; see
src/escort_ais/analysis/remdfree_basins.py) so the 4-basin free energies are directly comparable to the
converged-REMD reference computed on the SAME boxes. Shows where the short hot MD gives
coverage and where it does not (Lalpha/C7ax gated). Works/endpoints are unchanged; only the
basin assignment differs.

Outputs -> results/remdfree_s04/:
  endpoint_estimators_summary_geo.csv, geo_ddF.png (+ rama_samples_geo.npz, surface_tv_geo.csv
  for the single point)
Usage:  TOP100W_EXP=remdfree_s04 python -m escort_ais.experiments.alanine.analyze_remdfree_s04_prod4
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import BURNIN_REMD, REMD_DIR, load_phi_psi_dcd  # noqa: E402
from escort_ais.analysis.remdfree_basins import assign as _assign, reference_ddF, NB as N_BASINS, BN, NAMES  # noqa: E402
from escort_ais.methods.endpoint_bar import (  # noqa: E402
    endpoint_partitioned_pairwise_bar, endpoint_restricted_bar)
from escort_ais.common.top100w_cfg import FWD, RESULTS as OUT, RUNS, REVRUN  # noqa: E402

N_SEEDS, BURN_FRAMES = 20, 10
NS_PER_FRAME = 0.01


def ddF_from_pops(pop):
    pop = np.asarray(pop, float)
    with np.errstate(divide="ignore"):
        return -np.log(pop / pop[0])


def softmax_ddF(ddF):
    ddF = np.asarray(ddF, float); p = np.zeros_like(ddF); fin = np.isfinite(ddF)
    p[fin] = np.exp(-ddF[fin] - logsumexp(-ddF[fin])); return p


def main():
    NB = N_BASINS

    # forward
    logw_f = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    W_f = -logw_f
    fidx = pd.read_csv(FWD / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    sph, sps = load_phi_psi_dcd(FWD.parent / "seed_hot/trajectory.dcd")
    a_f = _assign(sph[fidx], sps[fidx])
    eph, eps = load_phi_psi_dcd(FWD / "ais_final_coordinates.dcd")
    b_f = _assign(eph, eps)
    hot_counts = np.bincount(_assign(sph, sps), minlength=NB).astype(float)
    g_counts = -np.log((hot_counts + 0.5) / (hot_counts[0] + 0.5))

    # reverse: re-assign cold-start basin from the seed_cold trajectory (geometric basins)
    rv = np.load(OUT / "reverse_ais_results.npz")
    W_r = rv["reverse_work"]
    cph, cps = load_phi_psi_dcd(REVRUN / "seed_cold_uniform/trajectory.dcd")
    cold_basin_seedorder = _assign(cph, cps)
    sel = pd.read_csv(REVRUN / "step_reverse_ais/selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    b_r = cold_basin_seedorder[sel]
    reph, reps = load_phi_psi_dcd(REVRUN / "step_reverse_ais/ais_final_coordinates.dcd")
    a_r = _assign(reph, reps)

    # estimators (geometric Ramachandran 4 basins)
    v2 = np.array([(-logsumexp(logw_f[b_f == b]) if (b_f == b).any() else np.nan) for b in range(NB)])
    v2 = v2 - v2[0]
    Delta, var, diag = endpoint_partitioned_pairwise_bar(
        W_f, a_f, b_f, W_r, b_r, a_r, NB, bootstrap=True, n_bootstrap=120,
        rng=np.random.default_rng(7))
    v6r = endpoint_restricted_bar(W_f, b_f, W_r, b_r, list(range(NB)))   # hot-unified (global-hot) BAR
    hub = np.array([v6r["ddF"].get(b, np.nan) for b in range(NB)])
    dd = np.array([Delta[i, i] for i in range(NB)])
    intra = (dd - dd[0]) + g_counts; intra[0] = 0.0

    # references
    ref = reference_ddF()
    rph, rps = load_phi_psi_dcd(REMD_DIR / "replica_00/trajectory.dcd")
    rb = _assign(rph, rps)
    hi12 = BURNIN_REMD + int(round(3.0 / NS_PER_FRAME))
    remd12 = ddF_from_pops(np.bincount(rb[BURNIN_REMD:hi12], minlength=NB))

    # reweighting in 4 basins
    wB = np.exp(logw_f - logsumexp(logw_f))
    ddF_B = ddF_from_pops(np.array([wB[b_f == b].sum() for b in range(NB)]))
    res_phi, res_psi = [], []
    for s in range(N_SEEDS):
        ph, ps = load_phi_psi_dcd(RUNS / f"seed_{s:03d}/trajectory.dcd")
        res_phi.append(ph[BURN_FRAMES:]); res_psi.append(ps[BURN_FRAMES:])
    res_phi = np.concatenate(res_phi); res_psi = np.concatenate(res_psi)
    res_basin = _assign(res_phi, res_psi)
    res_pop = np.bincount(res_basin, minlength=NB).astype(float)
    pC = softmax_ddF(hub); wC = np.zeros(len(res_basin))
    for b in range(NB):
        if pC[b] > 0 and res_pop[b] > 0:
            wC[res_basin == b] = pC[b] / res_pop[b]
    wC = wC / wC.sum() if wC.sum() > 0 else wC
    ddF_C = ddF_from_pops(np.array([wC[res_basin == b].sum() for b in range(NB)]))
    # AIS+localMD (10 ns): AIS between-basin ddF + local-MD reservoir within-basin (no reverse)
    pAL = softmax_ddF(v2); wAL = np.zeros(len(res_basin))
    for b in range(NB):
        if pAL[b] > 0 and res_pop[b] > 0:
            wAL[res_basin == b] = pAL[b] / res_pop[b]
    wAL = wAL / wAL.sum() if wAL.sum() > 0 else wAL
    ddF_AL = ddF_from_pops(np.array([wAL[res_basin == b].sum() for b in range(NB)]))

    methods = {"REMD reference (250ns)": ref, "REMD @12ns (3ns x4)": remd12,
               "AIS v2 (fwd-only, 8ns)": v2, "intra-BAR (12ns)": intra,
               "hot-unified BAR (12ns)": hub,
               "B reweight endpoints (8ns)": ddF_B, "AIS+localMD (10ns)": ddF_AL,
               "C reweight reservoir (12ns)": ddF_C}
    df = pd.DataFrame(methods, index=BN).T
    df["RMSE_vs_ref"] = [np.sqrt(np.nanmean((np.asarray(v, float) - ref) ** 2)) for v in methods.values()]
    df.loc["REMD reference (250ns)", "RMSE_vs_ref"] = np.nan
    df.round(3).to_csv(OUT / "endpoint_estimators_summary_geo.csv")
    print("  Geometric 4-basin free energies (kT), B0=C7eq B1=Lalpha B2=alphaR B3=C7ax/rare:")
    print(df.round(3).to_string())
    print(f"\n  forward cold-end basin counts: {np.bincount(b_f, minlength=NB).tolist()}")
    print(f"  reverse cold-start basin counts: {np.bincount(b_r, minlength=NB).tolist()}")

    # bar chart
    x = np.arange(NB); w = 0.13
    show = ["REMD reference (250ns)", "REMD @12ns (3ns x4)", "AIS v2 (fwd-only, 8ns)",
            "hot-unified BAR (12ns)", "C reweight reservoir (12ns)"]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    for i, m in enumerate(show):
        raw = np.asarray(methods[m], float)
        vals = np.where(np.isfinite(raw), raw, 0.0)       # gated/missing basins -> 0 (hatched)
        rmse = df.loc[m, "RMSE_vs_ref"]
        lab = m if m == "REMD reference (250ns)" else f"{m} (RMSE {rmse:.2f})" if np.isfinite(rmse) else f"{m} (B1 gated)"
        bars = ax.bar(x + (i - 2) * w, vals, w, label=lab, color="k" if i == 0 else None)
        for b in range(NB):
            if not np.isfinite(raw[b]):
                bars[b].set_hatch("xx"); bars[b].set_edgecolor("0.5")
    ax.set_xticks(x); ax.set_xticklabels([f"{BN[b]} {NAMES[b]}" for b in range(NB)])
    ax.set_ylabel(r"$\Delta\Delta F$ (kT)"); ax.axhline(0, color="0.6", lw=0.6)
    ax.legend(fontsize=7.5)
    ax.set_title("REMD-free methods on the geometric Ramachandran 4 basins (vs converged REMD)")
    fig.tight_layout(); fig.savefig(str(OUT / "geo_ddF.png"), dpi=140); plt.close(fig)
    print(f"\n  Saved endpoint_estimators_summary_geo.csv + geo_ddF.png -> {OUT.relative_to(ROOT)}")

    # single-point only (not the per-i sweep): emit phi/psi samples + surface TV for the notebook
    if not os.environ.get("REMDFREE_I"):
        np.savez(OUT / "rama_samples_geo.npz",
                 ref_phi=rph[BURNIN_REMD:], ref_psi=rps[BURNIN_REMD:], ref_basin=rb[BURNIN_REMD:],
                 remd12_phi=rph[BURNIN_REMD:hi12], remd12_psi=rps[BURNIN_REMD:hi12],
                 B_phi=eph, B_psi=eps, B_w=wB,
                 AL_phi=res_phi, AL_psi=res_psi, AL_w=wAL,
                 C_phi=res_phi, C_psi=res_psi, C_w=wC, n_basins=NB,
                 basin_names=np.array(NAMES),
                 fwd_counts=np.bincount(b_f, minlength=NB),        # forward cold-end endpoints per basin
                 ref_counts=np.bincount(rb[BURNIN_REMD:], minlength=NB))
        edges = np.linspace(-180, 180, 37)

        def _h(phi, psi, w):
            H, _, _ = np.histogram2d(phi, psi, bins=[edges, edges], weights=w, density=False)
            return H / H.sum()
        Href = _h(rph[BURNIN_REMD:], rps[BURNIN_REMD:], None)
        surf = {"REMD @12ns (3ns x4)": _h(rph[BURNIN_REMD:hi12], rps[BURNIN_REMD:hi12], None),
                "B endpoints (8ns)": _h(eph, eps, wB),
                "AIS+localMD (10ns)": _h(res_phi, res_psi, wAL),
                "C: hot-unified BAR reservoir (12ns)": _h(res_phi, res_psi, wC)}
        pd.DataFrame({"method": list(surf),
                      "TV_vs_converged_REMD": [float(0.5 * np.abs(H - Href).sum()) for H in surf.values()]}
                     ).round(4).to_csv(OUT / "surface_tv_geo.csv", index=False)
        print(f"  Saved rama_samples_geo.npz + surface_tv_geo.csv -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
