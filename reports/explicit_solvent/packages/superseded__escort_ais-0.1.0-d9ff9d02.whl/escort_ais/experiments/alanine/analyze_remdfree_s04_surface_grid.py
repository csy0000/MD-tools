#!/usr/bin/env python3
"""analyze_remdfree_s04_surface_grid.py — phi/psi free-energy surfaces at 5 hot-MD budgets.

For sweep budgets i = 1..5 (hot ensemble 5i ns), compute the cold phi/psi free-energy
surface for the AIS-based methods on the SAME footing as the single-point comparison:
  B            : forward-AIS cold endpoints, IS-weighted by Jarzynski work
  AIS+localMD  : cold reservoir reweighted by softmax(-ddF_AIS)
  C            : cold reservoir reweighted by softmax(-ddF_hot-unified-BAR)
plus the converged 250 ns REMD reference. The per-i basin ddF (v2 / hot-unified-BAR on the
geometric Ramachandran 4 basins) is read from the committed sweep _geo CSVs.

Outputs -> results/remdfree_s04_sweep/surface_grid.npz
  edges, ref_F, and {B,AL,C}_F_i (36x36 FES, kT) for i=1..5
Usage:  python -m escort_ais.experiments.alanine.analyze_remdfree_s04_surface_grid
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import BURNIN_REMD, REMD_DIR, load_phi_psi_dcd  # noqa: E402
from escort_ais.analysis.remdfree_basins import assign as _assign, NB as N_BASINS  # noqa: E402

FWD_ROOT = ROOT / "data/alanine_dipeptide/2026-06-18-remdfree-s04-sweep"
RUNS_ROOT = ROOT / "data/runs/remdfree_s04_sweep"
SWEEP = ROOT / "results/remdfree_s04_sweep"
IS = [1, 2, 3, 4, 5]
N_SEEDS, BURN_FRAMES = 20, 10
EDGES = np.linspace(-180, 180, 37)


def fes(phi, psi, w):
    H, _, _ = np.histogram2d(phi, psi, bins=[EDGES, EDGES], weights=w, density=True)
    F = -np.log(np.where(H.T > 0, H.T, np.nan))
    return F - np.nanmin(F)


def softmax_neg(ddF):
    ddF = np.asarray(ddF, float); p = np.zeros(N_BASINS); fin = np.isfinite(ddF)
    p[fin] = np.exp(-ddF[fin] - logsumexp(-ddF[fin])); return p


def reservoir_w(res_basin, res_pop, p):
    w = np.zeros(len(res_basin))
    for b in range(N_BASINS):
        if p[b] > 0 and res_pop[b] > 0:
            w[res_basin == b] = p[b] / res_pop[b]
    return w / w.sum() if w.sum() > 0 else w


def main():
    out = {"edges": EDGES}
    rph, rps = load_phi_psi_dcd(REMD_DIR / "replica_00/trajectory.dcd")
    out["ref_F"] = fes(rph[BURNIN_REMD:], rps[BURNIN_REMD:], None)

    for i in IS:
        prod = pd.read_csv(SWEEP / f"i{i:02d}/endpoint_estimators_summary_geo.csv", index_col=0)
        v2 = prod.loc["AIS v2 (fwd-only, 8ns)"].to_numpy(float)[:N_BASINS]
        comb = prod.loc["hot-unified BAR (12ns)"].to_numpy(float)[:N_BASINS]

        fdir = FWD_ROOT / f"i{i:02d}/step_forward_ais"
        logw_f = pd.read_csv(fdir / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
        eph, eps = load_phi_psi_dcd(fdir / "ais_final_coordinates.dcd")
        wB = np.exp(logw_f - logsumexp(logw_f))

        res_phi, res_psi = [], []
        for s in range(N_SEEDS):
            ph, ps = load_phi_psi_dcd(RUNS_ROOT / f"i{i:02d}/seed_{s:03d}/trajectory.dcd")
            res_phi.append(ph[BURN_FRAMES:]); res_psi.append(ps[BURN_FRAMES:])
        res_phi = np.concatenate(res_phi); res_psi = np.concatenate(res_psi)
        res_basin = _assign(res_phi, res_psi)
        res_pop = np.bincount(res_basin, minlength=N_BASINS).astype(float)

        out[f"B_F_{i}"] = fes(eph, eps, wB)
        out[f"AL_F_{i}"] = fes(res_phi, res_psi, reservoir_w(res_basin, res_pop, softmax_neg(v2)))
        out[f"C_F_{i}"] = fes(res_phi, res_psi, reservoir_w(res_basin, res_pop, softmax_neg(comb)))
        print(f"  i={i} (hot {5*i} ns): B/AIS+localMD/C surfaces done")
    np.savez(SWEEP / "surface_grid.npz", **out)
    print(f"\n  Saved surface_grid.npz -> {SWEEP.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
