"""REMD-free conditional BAR: PREP landings -> cold partition -> per-generation bidirectional NES.

Phase A (PREP, adaptive, >= G_PREP generations)
    per generation: 200 ps hot MD  +  N_AIS x 1 ps forward AIS (H->C)
    accumulate landings -> rebuild the basin tree -> convergence gate on
    (basin count unchanged) AND (TV between consecutive basin-mass vectors < tol).

Phase B (production, 10 generations)
    per generation, hot stream:  200 ps hot MD  +  N_AIS x 1 ps forward AIS (H->C)
    per generation, each box m:  200 ps restrained MD under U_m  +  N_AIS x 1 ps reverse AIS
    then per box: conditional BAR -> delta_m = f_H - f_m.

COMPARING THE TWO ESTIMATORS COSTS ONLY THE FORWARD LEGS (``--also-stratified``). The stratified
and unstratified forms share the hot walker, the box walkers, all of their MD, and the REVERSE legs
-- both seed reverse legs from box-interior frames by the same rule, and the stratified form merely
labels each landing by the hot region it returns to. Only the forward legs differ: N_AIS shots from
the whole hot state, versus N_AIS/M from each H_n (equal allocation is the point; proportional
draws starve the rare strata). One run therefore yields both estimates for ~6% extra cost on
alanine, where MD is ~88% of a generation, and the comparison is PAIRED rather than two runs whose
hot ensembles can silently differ -- which is exactly what happened when campaign_v3's stratified
arm was given ``--hot-preload`` and its normal arm was not.

NO REMD ANYWHERE IN THE ALGORITHM. REMD enters only as the validation yardstick
(``cold_reference.npz`` / ``DELTA_F_REF``), and only when ``--reference`` is passed.

Reverse legs are seeded from each box walker's INTERIOR frames, where U_m == 0 and the frames are
unbiased pi_m samples. Wall-region frames are discarded: they are distributed as
p(x) e^{-U_m(x)}, not as pi_m, and seeding from them would bias the reverse work (the Jensen guard
is the check).

DEFERRED BY DECISION: within-box equilibration. A flat-bottom core supplies no restoring force
inside itself, so a single continuing walker will not mix across a box's internal barriers -- B0
spans beta, C7eq and alpha_R. We measure this (``--diagnose-internal``) and do not fix it.

MD and AIS are executed sequentially here; the physical protocol runs them concurrently. The
statistics are unchanged -- the AIS of generation g seeds from hot frames accumulated through
generation g either way.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
from escort_ais.methods import condbar_walkers as CW
from escort_ais.analysis.hz_reconstruction import hs_sample_cloud
from escort_ais.methods.barrier_partition import (assign_basins, build_basin_tree, hz_density,
                                                  partition_from_dict, partition_to_dict)
from escort_ais.experiments.alanine.run_barrier_partition import assign_walls
from escort_ais.methods.conditional_bar import (conditional_bar_delta, endpoint_restricted_delta,
                                                jarzynski_delta, jensen_guard)

ROOT = project_root()
OUT_ROOT = ROOT / "reports/legacy/alanine/20260804_campaign_v2"
DATA = ROOT / "data/alanine_dipeptide/condbar_remdfree"
HOT_WALKER = ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"
TOP_PDB = HOT_WALKER / "start_structure.pdb"
S_COLD, S_HOT = 1.0, 0.25
T_AIS, FREQ_AIS = 500, 1                       # 1 ps at 2 fs
DELTA_F_REF = -48.18272933886123


def _cfg():
    from escort_ais.experiments.alanine.run_mixture_cft_oracle import (BASE_INPCRD, BASE_PRMTOP,
                                                                       GB_RADII)
    return dict(solvent="implicit", t_ais=T_AIS, freq_ais=FREQ_AIS, s_hot=S_HOT,
                omega_exclude=None, prmtop=BASE_PRMTOP, inpcrd=BASE_INPCRD, pdb=TOP_PDB,
                gb_radii=GB_RADII, n_solute_atoms=22, neq_integrator=True)


def _seed_config():
    from escort_ais.experiments.alanine.run_mixture_cft_oracle import SEED_CONFIG
    return SEED_CONFIG


def _landing_frame(phi_rad, psi_rad, work) -> pd.DataFrame:
    """An hz_density-compatible frame from AIS landing ENDPOINTS (s = 1, one slice)."""
    return pd.DataFrame(dict(phi=np.degrees(phi_rad), psi=np.degrees(psi_rad),
                             s=1.0, observation_id=0,
                             weight=np.exp(-(np.asarray(work, float) - np.min(work)))))


def _ais(seed_dir, out, k, s_from, s_to, platform, seed, devices):
    from escort_ais.methods.run_bais_standalone import _ais_leg
    if out.exists():
        shutil.rmtree(out)
    return _ais_leg(seed_dir, out, _cfg(), k, s_from, s_to, platform, seed=seed, devices=devices)


def _torsions(traj):
    import mdtraj as md
    return md.compute_phi(traj)[1][:, 0], md.compute_psi(traj)[1][:, 0]


def _box_device(args, m: int) -> str:
    """Device for box walker ``m`` -- round-robin over --md-devices so they can run concurrently."""
    devs = [d.strip() for d in str(getattr(args, "md_devices", "") or args.md_device).split(",")
            if d.strip()]
    return devs[m % len(devs)]


def _advance_boxes(boxes, md_ps, save_ps):
    """Advance every box walker CONCURRENTLY, one per device.

    The box walkers are completely independent -- separate Contexts, separate restraints -- but the
    driver used to step them in a serial ``for`` loop on one device. MD is ~88% of a generation's
    wall clock for alanine (1 ns takes ~50 s; 399 AIS shots take ~24 s), so serialising three
    walkers on one GPU was the dominant cost. OpenMM releases the GIL inside ``step()``, so threads
    genuinely overlap when the walkers sit on different devices.
    """
    from concurrent.futures import ThreadPoolExecutor

    if len(boxes) == 1:
        return [boxes[0].advance(md_ps, save_interval_ps=save_ps)]
    with ThreadPoolExecutor(max_workers=len(boxes)) as pool:
        return list(pool.map(lambda b: b.advance(md_ps, save_interval_ps=save_ps), boxes))


def _tv(a, b) -> float:
    a, b = np.asarray(a, float), np.asarray(b, float)
    if a.shape != b.shape:
        return float("inf")
    return float(0.5 * np.abs(a - b).sum())



def _discovery_ais(seed_dir: Path, out: Path, k: int, seed: int, args):
    """Forward AIS on the DISCOVERY path, so the partition gets the multi-slice HS cloud.

    The legacy ``_ais_leg`` returns endpoints only. One endpoint per trajectory leaves the 2D
    histogram too sparse for ``build_basin_tree`` to resolve a ~2%-mass basin (405 of 8100 bins
    filled at 500 landings, vs 1598 for a 20-slice cloud) -- this is what collapsed the first
    REMD-free run to a single basin. Discovery mode yields ~20 frames per trajectory from the SAME
    switching work, so the fix is free.

    Slices at s < 1 are legitimate for BUILDING the partition (a geometric device); only the
    reverse-leg seeds must be s = 1 frames, which phase_b enforces separately.

    Returns (hz_dataframe, phi_end_rad, psi_end_rad, W_end_reduced, xyz_end_nm).
    """
    import subprocess

    if out.exists():
        shutil.rmtree(out)
    cmd = [sys.executable, "-u", "-m",
           "escort_ais.experiments.alanine.run_alanine_ais_linear_scaling",
           "--solvent", "implicit", "--input-scaled-dir", str(seed_dir),
           "--k-ais", str(int(k)), "--t-ais", str(T_AIS), "--freq-ais", str(FREQ_AIS),
           "--s-hot", str(S_HOT), "--s-cold", str(S_COLD), "--scaling-mode", "square",
           "--mode", "discovery", "--hz-n-observations", str(int(args.hz_n_observations)),
           "--neq-integrator", "--leg", "forward", "--workers-per-gpu", "1",
           "--device-indices", ",".join(str(d) for d in args.devices),
           "--output-dir", str(out), "--seed", str(int(seed))]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"discovery AIS failed ({r.returncode}):\n{r.stdout[-2500:]}\n"
                           f"{r.stderr[-2500:]}")

    merged = out / "merged"
    hz = pd.read_parquet(merged / "hz_observations.parquet")
    ts = pd.read_parquet(merged / "trajectory_summary.parquet")
    z = np.load(merged / "sparse_coordinates.npz")
    xyz, ti, ii = z["xyz"], z["trajectory_index"], z["ais_interval_index"]
    last = int(ii.max())
    sel = ii == last                                    # the s = 1 endpoint of each trajectory
    order = np.argsort(ti[sel])
    xyz_end = xyz[sel][order]
    ts = ts.sort_values("trajectory_id")
    if len(xyz_end) != len(ts):
        raise RuntimeError(f"{len(xyz_end)} endpoint coordinates vs {len(ts)} trajectories")
    return (hz, np.radians(ts.final_phi.to_numpy(float)),
            np.radians(ts.final_psi.to_numpy(float)),
            ts.final_W_reduced.to_numpy(float), xyz_end)



def load_discovery_run(out: Path):
    """Landings from an EXISTING discovery run (phi/psi rad, reduced work, endpoint coords).

    Lets Phase B start from a partition and landing cloud already on disk, so the PREP phase is
    not repeated. Endpoint coordinates are taken at the final AIS interval, i.e. s = 1 -- the only
    frames admissible as reverse-leg seeds.
    """
    merged = Path(out) / "merged"
    ts = pd.read_parquet(merged / "trajectory_summary.parquet").sort_values("trajectory_id")
    z = np.load(merged / "sparse_coordinates.npz")
    xyz, ti, ii = z["xyz"], z["trajectory_index"], z["ais_interval_index"]
    sel = ii == int(ii.max())
    xyz_end = xyz[sel][np.argsort(ti[sel])]
    if len(xyz_end) != len(ts):
        raise RuntimeError(f"{len(xyz_end)} endpoint coordinates vs {len(ts)} trajectories")
    return dict(phi=np.radians(ts.final_phi.to_numpy(float)),
                psi=np.radians(ts.final_psi.to_numpy(float)),
                work=ts.final_W_reduced.to_numpy(float), xyz=xyz_end)


# ── Phase A ──────────────────────────────────────────────────────────────────────────────────
def phase_a(args, hot: CW.Walker, work_dir: Path) -> tuple[list, dict]:
    """PREP: burn-in hot MD, then grow the hot walker and shoot forward AIS until the
    partition settles.

    The burn-in generation runs MD with NO AIS: its purpose is to let the hot walker relax before
    any landing is recorded. Landings are accumulated as a multi-slice HS cloud.
    """
    for i in range(args.burn_in_gens):
        hot.advance(args.md_ps, save_interval_ps=args.md_save_ps)
        print(f"[prep] burn-in {i + 1}/{args.burn_in_gens}: "
              f"{hot.n_steps_run * CW.TIMESTEP_FS / 1000.0:.0f} ps hot MD, no AIS recorded")
    hot.frames.clear()                       # burn-in frames must not seed any AIS leg

    hzs, phis, psis, works, xyzs = [], [], [], [], []
    prev_mass, trace, tree = None, [], None
    prev_hot_torsions, prev_n, prev_cut_cvs, gate_run = None, None, None, 0

    g = 0
    while True:
        hot.advance(args.md_ps, save_interval_ps=args.md_save_ps)
        seed_dir = CW.write_seed_dir(work_dir / f"prep_g{g:02d}_hotseed", hot.all_frames(),
                                     _seed_config(), TOP_PDB)
        hz, p, s_, W, xyz = _discovery_ais(seed_dir, work_dir / f"prep_g{g:02d}_ais",
                                           args.n_ais, 50000 + 97 * g, args)
        hzs.append(hz); phis.append(p); psis.append(s_); works.append(W); xyzs.append(xyz)
        allhz = pd.concat(hzs, ignore_index=True)
        allw = np.concatenate(works)

        dens = hz_density(allhz, bin_width_deg=args.bin_width_deg, smooth_deg=args.smooth_deg,
                          s_min=args.s_min)
        # The reliability gate needs the HS SAMPLES and their originating shots: a cell's mass is
        # reliable or not according to the weights that produced it, which the density grid has
        # already summed away. Passing them makes a cut whose child would be unmeasurable get
        # rejected in favour of the next candidate, rather than vetoing the whole partition.
        gA, gW, gshot = hs_sample_cloud(allhz, ["phi", "psi"], args.s_min)
        res = build_basin_tree(dens, stop_barrier_kT=args.stop_barrier_kT,
                               min_basin_mass=args.min_basin_mass,
                               cloud=(dict(phi=gA[:, 0], psi=gA[:, 1], weights=gW,
                                           cluster_ids=gshot) if args.gate_cuts else None))
        # build_basin_tree leaves k_phi/k_psi unset; assign_walls applies the fixed k_wall. Without
        # it interval_wall_params returns k <= 0 and the restraint force is silently omitted.
        cloud = dict(phi=np.radians(allhz["phi"].to_numpy(float)),
                     psi=np.radians(allhz["psi"].to_numpy(float)),
                     weight=np.full(len(allhz), 1.0 / len(allhz)))
        assign_walls(res["basins"], cloud, dens, k_wall=args.k_wall, adaptive=False)
        tree = json.loads(json.dumps(partition_to_dict(res, dens, partition_mode="basin-tree"),
                                     default=str))
        part = partition_from_dict(tree)
        mass = np.array([b.mass for b in part], float)
        tv = _tv(mass, prev_mass) if prev_mass is not None and len(mass) == len(prev_mass) \
            else float("nan")

        # ── G_PREP gate (2026-07-31) ────────────────────────────────────────────────────────
        # Four conditions, ALL required, for K consecutive generations. Calibrated on alanine and
        # cyclo-(RGDfV); see reports/rgd/omega_prep_gate/report.md.
        #
        #  1. > 1 basin. A single-basin partition is degenerate, not converged: every mass ratio
        #     is identically 1 and TV is identically 0, so any mass gate certifies it. On alanine
        #     this fires for SEVEN consecutive generations without the guard.
        #  2. same basin COUNT as the previous generation.
        #  3. same set of cut CVs. Count alone is not enough -- alanine generations 4 and 5 both
        #     had 2 basins cut on DIFFERENT coordinates (psi then phi), and freezing the first
        #     would have locked in the wrong partition for the whole campaign.
        #  4. per-basin HOT-walker population ratio within [1-band, 1+band], for basins holding
        #     more than `--gate-mass-floor`. Counted on the hot walker (burn-in already dropped),
        #     not on the landing-derived basin mass: the hot ensemble is what Phase B reweights
        #     from, and it is far better sampled.
        #
        # The ratio is evaluated under the CURRENT partition for both generations, so only the
        # DATA differs -- comparing masses computed under two different partitions would confound
        # ensemble drift with partition change.
        hphi_g, hpsi_g = hot.torsions()
        hlab_g = assign_basins(hphi_g, hpsi_g, part)
        pi_hot = np.array([(hlab_g == n).mean() for n in range(len(part))], float)
        pi_prev = None
        if prev_hot_torsions is not None:
            lp = assign_basins(*prev_hot_torsions, part)
            pi_prev = np.array([(lp == n).mean() for n in range(len(part))], float)
        ratio_ok, r_lo, r_hi = False, float("nan"), float("nan")
        if pi_prev is not None:
            keep = np.maximum(pi_prev, pi_hot) > args.gate_mass_floor
            if keep.any():
                rr = pi_hot[keep] / np.where(pi_prev[keep] > 0, pi_prev[keep], np.inf)
                r_lo, r_hi = float(np.min(rr)), float(np.max(rr))
                ratio_ok = (r_lo >= 1.0 - args.gate_band) and (r_hi <= 1.0 + args.gate_band)
        cut_cvs = tuple(sorted({c["dimension"] for c in tree.get("cuts", [])}))
        step_ok = bool(len(part) > 1 and prev_n is not None and len(part) == prev_n
                       and cut_cvs == prev_cut_cvs and ratio_ok)
        gate_run = gate_run + 1 if step_ok else 0
        converged = gate_run >= args.gate_k
        n_pos = int((np.concatenate(phis) > 0).sum())
        trace.append(dict(generation=g, n_basins=int(len(part)), mass=mass.tolist(),
                          pi_hot=pi_hot.tolist(), cut_cvs=list(cut_cvs),
                          ratio_lo=(None if not np.isfinite(r_lo) else r_lo),
                          ratio_hi=(None if not np.isfinite(r_hi) else r_hi),
                          gate_step_ok=bool(step_ok), gate_run=int(gate_run),
                          tv_vs_prev=(None if not np.isfinite(tv) else float(tv)),
                          converged=converged, n_landings=int(len(allw)),
                          n_hz_frames=int(len(allhz)), n_landings_phi_pos=n_pos,
                          hot_ps=float(hot.n_steps_run * CW.TIMESTEP_FS / 1000.0)))
        print(f"[prep g{g}] basins={len(part)} cuts={','.join(cut_cvs) or '-'} "
              f"pi_hot={np.round(pi_hot, 4)} ratio=[{r_lo:.2f},{r_hi:.2f}] "
              f"step_ok={step_ok} run={gate_run}/{args.gate_k} landings={len(allw)} "
              f"(phi>0: {n_pos}) hs_frames={len(allhz)}")
        prev_mass = mass
        prev_hot_torsions, prev_n, prev_cut_cvs = (hphi_g, hpsi_g), len(part), cut_cvs
        g += 1
        if g >= args.g_prep and converged:
            print(f"[prep] converged after {g} generations (>= G_PREP={args.g_prep})")
            break
        if g > args.max_prep_gens:
            print(f"[prep] stopping at the {args.max_prep_gens}-generation cap WITHOUT "
                  f"convergence; the partition is NOT settled and every downstream number "
                  f"inherits that.")
            break

    landings = dict(phi=np.concatenate(phis), psi=np.concatenate(psis),
                    work=np.concatenate(works), xyz=np.concatenate(xyzs))
    return [tree, landings], dict(trace=trace, n_prep_generations=g,
                                  burn_in_gens=int(args.burn_in_gens),
                                  md_ps_per_generation=float(args.md_ps))


# ── Phase B ──────────────────────────────────────────────────────────────────────────────────
def _checkpoint(args, payload: dict) -> None:
    """Write a partial result after each generation, atomically.

    Rewritten whole via a temp file + replace, so a crash during the write leaves the previous
    generation's checkpoint intact rather than a truncated JSON.
    """
    out = Path(args.out) / "remdfree_results_partial.json"
    tmp = out.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2, default=str) + "\n")
    tmp.replace(out)


def phase_b(args, hot: CW.Walker, part, landings: dict, work_dir: Path) -> dict:
    import mdtraj as md

    n_boxes = len(part)
    lab = assign_basins(landings["phi"], landings["psi"], part)

    # seed each box walker from a PREP landing inside that box, chosen by AIS weight
    rng = np.random.default_rng(args.seed)
    boxes, seed_info = [], []
    for m in range(n_boxes):
        idx = np.flatnonzero(lab == m)
        if len(idx) == 0:
            raise RuntimeError(f"no PREP landing in box B{m}: cannot seed its walker. "
                               f"Increase --n-ais or --g-prep.")
        w = np.exp(-(landings["work"][idx] - landings["work"][idx].min()))
        pick = int(rng.choice(idx, p=w / w.sum()))
        boxes.append(CW.make_box_walker(landings["xyz"][pick], part[m], seed=args.seed + 811 * m,
                                        platform_name=args.platform, device=_box_device(args, m)))
        seed_info.append(dict(box=f"B{m}", n_landings_in_box=int(len(idx)),
                              seed_frame=pick))
        print(f"[phaseB] B{m} walker seeded from 1 of {len(idx)} PREP landings in box")

    # The forward bank ACCUMULATES: the PREP landings are the same forward process (same hot
    # ensemble, same 1 ps H->C protocol) as the production shots, so they belong in the bank that
    # conditional BAR solves against. Without them a 100-shot generation expects only ~1.3 landings
    # in B1 and frequently gets zero, leaving delta_1 undefined. M_m = log(N_F / N_R_m) uses this
    # TOTAL forward count.
    bank_W = [np.asarray(landings["work"], float)]
    bank_lab = [lab]
    print(f"[phaseB] forward bank seeded with {len(bank_W[0])} PREP landings "
          f"(per-box: {[int((lab == m).sum()) for m in range(n_boxes)]})")

    records = []
    for g in range(1, args.generations + 1):
        hot.advance(args.md_ps, save_interval_ps=args.md_save_ps)
        hs = CW.write_seed_dir(work_dir / f"g{g:02d}_hotseed", hot.all_frames(),
                               _seed_config(), TOP_PDB)
        Wf, land = _ais(hs, work_dir / f"g{g:02d}_fwd", args.n_ais, S_HOT, S_COLD,
                        args.platform, seed=60000 + 131 * g, devices=args.devices)
        bank_W.append(np.asarray(Wf, float))
        fp, fs = _torsions(land)
        bank_lab.append(assign_basins(fp, fs, part))
        Wf = np.concatenate(bank_W)                # PREP + every production generation so far
        flab = np.concatenate(bank_lab)
        counts_new = np.array([(bank_lab[-1] == m).sum() for m in range(n_boxes)], int)
        counts = np.array([(flab == m).sum() for m in range(n_boxes)], int)

        row = dict(generation=g, counts=counts.tolist(),
                   counts_this_generation=counts_new.tolist(), n_forward_total=int(len(Wf)),
                   landing_delta=[-jarzynski_delta(Wf, flab == m, n_forward=len(Wf))
                                  for m in range(n_boxes)], boxes=[])
        chunks = _advance_boxes(boxes, args.md_ps, args.md_save_ps)
        rev_store = []
        for m in range(n_boxes):
            chunk = chunks[m]
            bp, bs = boxes[m].torsions()                      # ALL accumulated frames
            inside = CW.interior_mask(bp, bs, part[m])
            xyz_in = boxes[m].all_frames()[inside]
            frac_out = float(1.0 - inside.mean())
            if len(xyz_in) == 0:
                raise RuntimeError(f"box B{m} walker has no interior frames at generation {g}")
            take = rng.choice(len(xyz_in), size=args.n_ais, replace=len(xyz_in) < args.n_ais)
            bsd = CW.write_seed_dir(work_dir / f"g{g:02d}_b{m}_seed", xyz_in[take],
                                    _seed_config(), TOP_PDB)
            # RETAIN THIS GENERATION'S COLD-WALKER CVs.
            #
            # The seed dir holds only the n_ais frames the reverse legs launch from -- a resample
            # of the walker's whole accumulated interior, so early frames recur and the distinct
            # coverage is far below the frame count. Campaign v5 kept 16.5% of what its confined
            # walkers integrated, which permanently capped the resolution of any within-substate
            # density built from that run.
            #
            # Nothing in the estimator needs these: the walkers live in memory for the whole
            # campaign and are consumed in-process. They are written so that p_m(x) -- the density
            # the reconstruction p = sum_m pi_m p_m needs -- survives the run at full resolution.
            # Only THIS generation's new frames are stored; `bp`/`bs` are ordered oldest-first, so
            # the tail is the new chunk and pooling g01..gG reconstructs the trajectory with no
            # duplication. Two float32 per frame: ~4 kB per box per generation.
            n_new = len(chunk)
            np.savez_compressed(
                work_dir / f"g{g:02d}_b{m}_cv.npz",
                phi=np.asarray(bp[-n_new:], np.float32), psi=np.asarray(bs[-n_new:], np.float32),
                interior=np.asarray(inside[-n_new:], bool),
                save_interval_ps=float(args.md_save_ps), generation=int(g), box=int(m))
            Wr, rland = _ais(bsd, work_dir / f"g{g:02d}_b{m}_rev", args.n_ais, S_COLD, S_HOT,
                             args.platform, seed=70000 + 313 * g + 7 * m, devices=args.devices)
            Wr = np.asarray(Wr, float)
            # The stratified estimator needs the SAME reverse legs, additionally labelled by which
            # hot region they land back in. Sharing them is exact -- both estimators seed reverse
            # legs by the identical rule (interior frames, n_ais shots) -- and it makes the two
            # arms a PAIRED comparison on one set of trajectories instead of two runs whose hot
            # ensembles can silently differ.
            rev_store.append((Wr, assign_basins(*_torsions(rland), part)
                              if args.also_stratified else None))

            d = conditional_bar_delta(Wf, flab == m, Wr, n_forward=len(Wf))
            delta = -d                                        # delta_m = f_H - f_m
            jg = jensen_guard(Wr, d)
            row["boxes"].append(dict(
                box=f"B{m}", delta=float(delta), n_landed=int(counts[m]), n_reverse=int(len(Wr)),
                n_md_frames=int(len(bp)), n_interior=int(inside.sum()),
                frac_frames_outside=frac_out, n_distinct_seeds=int(len(np.unique(take))),
                mean_reverse_work=float(Wr.mean()), jensen_ok=bool(jg["ok"]),
                jensen_bound=float(jg["bound"]),
                tau_int_phi=CW.integrated_act(bp), tau_int_psi=CW.integrated_act(bs),
                cold_ps=float(boxes[m].n_steps_run * CW.TIMESTEP_FS / 1000.0)))
        if args.also_stratified:
            # Same walkers, same MD, same reverse legs -- only the FORWARD legs differ: equal
            # allocation per hot stratum instead of proportional draws from the whole hot state.
            hphi, hpsi = hot.torsions()
            hlab = assign_basins(hphi, hpsi, part)
            n_hot = np.array([(hlab == n).sum() for n in range(n_boxes)], int)
            if np.any(n_hot == 0):
                raise RuntimeError(f"hot region H{int(np.argmin(n_hot))} empty at generation {g}")
            fH = -np.log(n_hot / n_hot[0])          # f^H_n - f^H_0, by counting
            per_region = max(1, args.n_ais // n_boxes)
            hxyz = hot.all_frames()
            sdelta, sinfo = np.full(n_boxes, np.nan), []
            for n in range(n_boxes):
                sel = np.flatnonzero(hlab == n)
                sd = CW.write_seed_dir(work_dir / f"g{g:02d}_H{n}_seed", hxyz[sel],
                                       _seed_config(), TOP_PDB)
                WfB, flandB = _ais(sd, work_dir / f"g{g:02d}_H{n}_fwd", per_region, S_HOT, S_COLD,
                                   args.platform, seed=61000 + 131 * g + 17 * n,
                                   devices=args.devices)
                WfB = np.asarray(WfB, float)
                flB = assign_basins(*_torsions(flandB), part)
                WrN, rlN = rev_store[n]
                sdelta[n] = endpoint_restricted_delta(WfB, flB == n, WrN, rlN == n,
                                                      n_forward=len(WfB), n_reverse=len(WrN))
                sinfo.append(dict(region=f"H{n}", n_hot_frames=int(n_hot[n]),
                                  n_distinct_hot_seeds=int(len(np.unique(sel))),
                                  n_forward=int(len(WfB)), p_forward_hit=float((flB == n).mean()),
                                  n_reverse=int(len(WrN)), p_reverse_hit=float((rlN == n).mean()),
                                  delta_CH=float(sdelta[n]), fH_minus_fH0=float(fH[n])))
            row["stratified"] = dict(f_rel=((sdelta - sdelta[0]) + fH).tolist(),
                                     delta_CH=sdelta.tolist(), fH=fH.tolist(), regions=sinfo)
            print(f"[gen {g}] STRAT f-f0={np.round(row['stratified']['f_rel'], 4)} "
                  f"p_hit_F={[round(i['p_forward_hit'], 2) for i in sinfo]}", flush=True)

        d_arr = np.array([b["delta"] for b in row["boxes"]], float)
        print(f"[gen {g}] N_F={len(Wf)} counts={counts.tolist()} "
              f"(new {counts_new.tolist()}) delta={np.round(d_arr, 4)} "
              f"jensen={[b['jensen_ok'] for b in row['boxes']]}")
        records.append(row)
        # CHECKPOINT EVERY GENERATION. `records` lives in memory and the final JSON is written
        # only after the last generation, so a 100-generation run that dies at generation 99 used
        # to lose every number while leaving the raw AIS dirs behind. Cheap insurance: the file is
        # a few hundred kB and is rewritten whole, so a crash mid-write costs one generation.
        _checkpoint(args, dict(generations=records, box_seeding=seed_info,
                               n_generations_completed=g, complete=False))

    return dict(generations=records, box_seeding=seed_info,
                boxes_final=[dict(box=f"B{m}",
                                  cold_ps=float(boxes[m].n_steps_run * CW.TIMESTEP_FS / 1000.0))
                             for m in range(n_boxes)],
                _walkers=boxes)



# ── Phase B, stratified variant ──────────────────────────────────────────────────────────────
def phase_b_stratified(args, hot: CW.Walker, part, landings: dict, work_dir: Path) -> dict:
    """Traceback-stratified estimator.

        f^C_n - f^C_m = (f^C_n - f^H_n) - (f^C_m - f^H_m) + (f^H_n - f^H_m)

    The hot ensemble is partitioned by the SAME box geometry applied to the hot configuration, so
    H_n is a deterministic rule rather than "wherever shots happened to land" (the hot->cold map is
    stochastic and does not induce a partition). Forward legs are launched from each H_n
    separately, which is the point: drawing from the whole hot state sends only ~1.5% of shots
    toward a rare cold basin, whereas 80-100% of shots from H_n land in C_n at 1 ps.

    The middle term is pure counting in the hot walker, which is well sampled. Only the matched
    terms need switching, and each is a doubly-conditioned BAR.
    """
    n_boxes = len(part)
    lab = assign_basins(landings["phi"], landings["psi"], part)
    rng = np.random.default_rng(args.seed)
    boxes = []
    for m in range(n_boxes):
        idx = np.flatnonzero(lab == m)
        if len(idx) == 0:
            raise RuntimeError(f"no PREP landing in box B{m}")
        w = np.exp(-(landings["work"][idx] - landings["work"][idx].min()))
        pick = int(rng.choice(idx, p=w / w.sum()))
        boxes.append(CW.make_box_walker(landings["xyz"][pick], part[m], seed=args.seed + 811 * m,
                                        platform_name=args.platform,
                                        device=_box_device(args, m)))
        print(f"[strat] B{m} walker seeded from 1 of {len(idx)} PREP landings "
              f"(device {_box_device(args, m)})")

    per_region = max(1, args.n_ais // n_boxes)
    records = []
    for g in range(1, args.generations + 1):
        hot.advance(args.md_ps, save_interval_ps=args.md_save_ps)
        hxyz = hot.all_frames()
        hphi, hpsi = hot.torsions()
        hlab = assign_basins(hphi, hpsi, part)
        n_hot = np.array([(hlab == n).sum() for n in range(n_boxes)], int)
        if np.any(n_hot == 0):
            raise RuntimeError(f"hot region H{int(np.argmin(n_hot))} is empty at generation {g}")
        # f^H_n - f^H_0 by counting: the hot ensemble is well sampled, so this term is free.
        fH = -np.log(n_hot / n_hot[0])

        delta = np.full(n_boxes, np.nan)          # f^C_n - f^H_n
        info = []
        chunks = _advance_boxes(boxes, args.md_ps, args.md_save_ps)  # all at once, one per device
        for n in range(n_boxes):
            sel = np.flatnonzero(hlab == n)
            sd = CW.write_seed_dir(work_dir / f"g{g:02d}_H{n}_seed", hxyz[sel],
                                   _seed_config(), TOP_PDB)
            Wf, fland = _ais(sd, work_dir / f"g{g:02d}_H{n}_fwd", per_region, S_HOT, S_COLD,
                             args.platform, seed=61000 + 131 * g + 17 * n, devices=args.devices)
            Wf = np.asarray(Wf, float)
            fl = assign_basins(*_torsions(fland), part)

            bp, bs = boxes[n].torsions()
            inside = CW.interior_mask(bp, bs, part[n])
            xyz_in = boxes[n].all_frames()[inside]
            take = rng.choice(len(xyz_in), size=args.n_ais, replace=len(xyz_in) < args.n_ais)
            bsd = CW.write_seed_dir(work_dir / f"g{g:02d}_C{n}_seed", xyz_in[take],
                                    _seed_config(), TOP_PDB)
            n_new = len(chunks[n])                            # see the note in phase_b
            np.savez_compressed(
                work_dir / f"g{g:02d}_C{n}_cv.npz",
                phi=np.asarray(bp[-n_new:], np.float32), psi=np.asarray(bs[-n_new:], np.float32),
                interior=np.asarray(inside[-n_new:], bool),
                save_interval_ps=float(args.md_save_ps), generation=int(g), region=int(n))
            Wr, rland = _ais(bsd, work_dir / f"g{g:02d}_C{n}_rev", args.n_ais, S_COLD, S_HOT,
                             args.platform, seed=71000 + 313 * g + 23 * n, devices=args.devices)
            Wr = np.asarray(Wr, float)
            rl = assign_basins(*_torsions(rland), part)

            delta[n] = endpoint_restricted_delta(Wf, fl == n, Wr, rl == n,
                                                 n_forward=len(Wf), n_reverse=len(Wr))
            info.append(dict(region=f"H{n}", n_forward=int(len(Wf)),
                             n_forward_hit=int((fl == n).sum()),
                             p_forward_hit=float((fl == n).mean()),
                             n_reverse=int(len(Wr)), n_reverse_hit=int((rl == n).sum()),
                             p_reverse_hit=float((rl == n).mean()),
                             n_hot_frames=int(n_hot[n]),
                             delta_CH=float(delta[n]), fH_minus_fH0=float(fH[n])))
        f_rel = (delta - delta[0]) + fH            # f^C_n - f^C_0
        print(f"[gen {g}] p_hit_F={[round(i['p_forward_hit'], 2) for i in info]} "
              f"p_hit_R={[round(i['p_reverse_hit'], 2) for i in info]} "
              f"f-f0={np.round(f_rel, 4)}")
        records.append(dict(generation=g, f_rel=f_rel.tolist(), delta_CH=delta.tolist(),
                            fH=fH.tolist(), regions=info))
        _checkpoint(args, dict(generations=records, estimator="stratified endpoint-restricted",
                               n_generations_completed=g, complete=False))
    return dict(generations=records, estimator="stratified endpoint-restricted",
                per_region_forward=int(per_region), _walkers=boxes)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=OUT_ROOT)
    ap.add_argument("--work-dir", type=Path, default=DATA)
    ap.add_argument("--md-ps", type=float, default=1000.0,
                    help="MD per stream per generation (T_gen)")
    ap.add_argument("--gate-k", type=int, default=3,
                    help="consecutive generations the whole G_PREP gate must hold")
    ap.add_argument("--gate-band", type=float, default=0.10,
                    help="per-basin hot-population ratio must lie in [1-band, 1+band]")
    ap.add_argument("--gate-mass-floor", type=float, default=0.01,
                    help="only basins above this hot mass are subject to the ratio band")
    ap.add_argument("--burn-in-gens", type=int, default=1,
                    help="hot MD generations run before any AIS is recorded")
    ap.add_argument("--hz-n-observations", type=int, default=61)
    ap.add_argument("--s-min", type=float, default=0.7)
    ap.add_argument("--md-save-ps", type=float, default=1.0)
    ap.add_argument("--n-ais", type=int, default=100, help="AIS shots per stream per generation")
    ap.add_argument("--generations", type=int, default=10)
    ap.add_argument("--g-prep", type=int, default=5, help="minimum PREP generations")
    ap.add_argument("--max-prep-gens", type=int, default=15)
    ap.add_argument("--prep-tv-tol", type=float, default=0.02)
    ap.add_argument("--stop-barrier-kT", type=float, default=3.0)
    ap.add_argument("--min-basin-mass", type=float, default=0.001)
    ap.add_argument("--no-gate-cuts", dest="gate_cuts", action="store_false",
                    help="build the PREP tree without the in-search reliability gate "
                         "(pre-2026-08-06 behaviour). By default a candidate cut is taken only if "
                         "both children clear --min-basin-mass with confidence; a cut that fails "
                         "is rejected and the search continues, so an unmeasurable cell costs its "
                         "own cut rather than the whole partition.")
    ap.add_argument("--k-wall", type=float, default=100.0)
    ap.add_argument("--bin-width-deg", type=float, default=4.0)
    ap.add_argument("--smooth-deg", type=float, default=4.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--devices", default="0,1,2", help="AIS shard devices")
    ap.add_argument("--md-devices", default=None,
                    help="comma list of devices for the COLD box walkers, one each, advanced "
                         "concurrently. MD is ~88%% of a generation; serialising the boxes on one "
                         "GPU was the dominant cost. Defaults to --md-device for all boxes.")
    ap.add_argument("--md-device", default="0")
    ap.add_argument("--seed", type=int, default=20260729)
    ap.add_argument("--allow-multiple-hot-walkers", action="store_true",
                    help="permit the seed pool to mix PREP frames with a DIFFERENT preload "
                         "trajectory. Refused by default since 2026-08-07: the two walkers used "
                         "by campaigns v5/v6 disagree by 23%% on the phi>0 hot population and "
                         "TV 0.0920 in (phi, psi), and pooling them makes the effective hot "
                         "ensemble drift across generations. Use only to reproduce v5/v6.")
    ap.add_argument("--hot-preload", action="store_true",
                    help="seed the hot ensemble with the existing 100 ns walker")
    ap.add_argument("--also-stratified", action="store_true",
                    help="compute BOTH estimators from one run: shared hot MD, shared cold MD and "
                         "SHARED reverse legs; only the forward legs differ (100 from the whole "
                         "hot state vs n_ais//n_boxes from each stratum). Paired comparison at "
                         "~6%% extra cost, instead of two runs that can differ in hot ensemble.")
    ap.add_argument("--stratified", action="store_true",
                    help="traceback-stratified endpoint-restricted estimator")
    ap.add_argument("--partition", type=Path, default=None,
                    help="use this basin_tree.json and SKIP Phase A")
    ap.add_argument("--prep-run", type=Path, default=None,
                    help="existing discovery run supplying the PREP landings")
    ap.add_argument("--prep-hot-seeds", action=argparse.BooleanOptionalAction, default=True,
                    help="with --partition/--prep-run, carry PREP's hot frames into the forward "
                         "seed pool (default). PREP's hot MD is already integrated, and excluding "
                         "it leaves generation 1 drawing from ~6 frames in each rare region -- a "
                         "finite-pool bias that does NOT average away over generations. Pass "
                         "--no-prep-hot-seeds to reproduce the pre-2026-08-04 behaviour.")
    ap.add_argument("--prep-hot-stride", type=int, default=1,
                    help="subsample the PREP hot frames by this stride before pooling them with "
                         "production frames. A hot region's population IS a frame count, so a "
                         "1 ps PREP block pooled with 2 ps production frames over-weights the "
                         "PREP region 2x per unit time. With --hot-preload on the 2 ps walker and "
                         "a PREP written at 1 ps, pass 2. The seed dirs do not record their own "
                         "interval, so this is never inferred.")
    ap.add_argument("--reference", type=Path,
                    default=ROOT / "reports/alanine/remd_ground_truth/cold_reference.npz")
    args = ap.parse_args(argv)
    args.devices = [int(x) for x in str(args.devices).split(",")] if args.devices else None

    args.out.mkdir(parents=True, exist_ok=True)
    if args.work_dir.exists():
        shutil.rmtree(args.work_dir)
    args.work_dir.mkdir(parents=True, exist_ok=True)

    import mdtraj as md
    hot_traj = md.load_dcd(str(HOT_WALKER / "trajectory.dcd"), top=str(TOP_PDB))
    hot = CW.make_hot_walker(hot_traj.xyz[-1], S_HOT, seed=args.seed,
                             platform_name=args.platform, device=args.md_device)
    if args.hot_preload:
        # PRELOAD IS A COMPUTE SHORTCUT, NOT A LARGER ENSEMBLE. Generation g must see exactly the
        # hot ensemble the protocol would have produced -- T_gen of new hot MD per generation --
        # only read off an existing equilibrated trajectory instead of being integrated again.
        #
        # It previously appended the WHOLE 100 ns walker, which handed the estimator a ~10x larger
        # hot ensemble from generation 1. That is a different experiment, not a cheaper one, and it
        # is what confounded the campaign_v3 arms. It also mixed frame spacings (2 ps preload vs
        # 1 ps generations), over-weighting the new frames 1.8x per unit time in every population
        # count -- and a hot region's population IS a frame count.
        cfg_ps = float(json.loads((HOT_WALKER / "config.json").read_text())
                       .get("traj_interval_ps", args.md_save_ps))
        if abs(cfg_ps - args.md_save_ps) > 1e-9:
            raise SystemExit(
                f"--hot-preload source saves every {cfg_ps} ps but --md-save-ps is "
                f"{args.md_save_ps}; pass --md-save-ps {cfg_ps} so the hot frames are uniformly "
                f"spaced (populations are frame counts)")
        per_gen = int(round(args.md_ps / cfg_ps))
        # Fail on the ARITHMETIC now, not on "preload source exhausted" hours in. Phase A
        # generations (burn-in + PREP) consume the cursor too, so they count against the budget
        # unless the partition is supplied and Phase A is skipped entirely.
        n_avail = hot_traj.n_frames // per_gen
        n_need = args.generations + (0 if args.partition
                                     else args.burn_in_gens + args.max_prep_gens)
        if n_need > n_avail:
            raise SystemExit(
                f"--hot-preload budget: {hot_traj.n_frames} frames / {per_gen} per generation = "
                f"{n_avail} generations available, but this run needs up to {n_need} "
                f"({args.generations} production"
                + ("" if args.partition else
                   f" + {args.burn_in_gens} burn-in + up to {args.max_prep_gens} PREP")
                + f"). Reduce --generations, shorten --md-ps, or supply --partition to skip "
                  f"Phase A.")
        hot.preload_source = np.asarray(hot_traj.xyz, np.float32)
        hot.preload_per_gen = per_gen
        hot.preload_cursor = 0
        print(f"[init] hot MD will be READ from {HOT_WALKER.name} in {per_gen}-frame "
              f"({args.md_ps:.0f} ps) slices per generation, not integrated; "
              f"{hot_traj.n_frames} frames available = {n_avail} generations, "
              f"this run needs {n_need}")
    print(f"[init] hot walker continued from the last frame of {HOT_WALKER.name} "
          f"({hot_traj.n_frames} frames)")

    if args.partition:
        tree = json.loads(Path(args.partition).read_text())
        landings = load_discovery_run(args.prep_run)
        prep = dict(skipped=True, partition=str(args.partition), prep_run=str(args.prep_run),
                    n_landings=int(len(landings["work"])))
        print(f"[prep] SKIPPED: partition from {args.partition}, "
              f"{len(landings['work'])} landings from {args.prep_run}")

        # SEED POOL: carry PREP's hot frames into the production walker.
        #
        # Forward legs draw their initial conditions from the walker's accumulated frames, so the
        # estimator samples that pool's EMPIRICAL measure, not pi_H. Consistency requires the
        # empirical measure to approach pi_H, and the finite-pool bias does NOT average away over
        # generations: ten estimates from a 1 ns pool carry a 1 ns pool's bias, not a 10 ns pool's.
        #
        # Starting Phase B from a single coordinate discards PREP's already-integrated hot MD, so
        # generation 1 sees 1 ns and the rare regions hold ~6 frames -- six delta functions, not a
        # distribution. Measured on alanine campaign_v3, carrying PREP in moved the unstratified
        # rare-substate bias from +0.402 to +0.036 kT and the stratified from +0.538 to +0.256,
        # at no additional cost: that MD was already run.
        #
        # This is NOT the withdrawn --hot-preload defect. That appended an unrelated 100 ns walker
        # (~10x the protocol ensemble, and at a different frame spacing). Here the frames come from
        # this campaign's own PREP, at the same spacing, under the same Hamiltonian.
        #
        # ONE HOT WALKER (2026-08-07). Same spacing and same Hamiltonian are NOT sufficient: the
        # pool must come from a SINGLE trajectory. Measured on this system, the two walkers that
        # campaigns v5/v6 pooled disagree by TV 0.0920 / JSD 0.0122 in (phi, psi) and by 23% on the
        # phi>0 hot population (40% on alpha_L) -- the same order as the recorded signature of a
        # trapped walker (JSD 0.0193 against an independent reference). Pooling them also makes the
        # effective hot ensemble DRIFT with generation, from PREP-dominated at g=1 to
        # preload-dominated by g=60, and a time-varying seed distribution is not what the
        # finite-pool argument assumes. See docs/decisions/2026-08-07_one-hot-walker.md.
        if args.prep_hot_seeds:
            pdirs = sorted(Path(args.prep_run).parent.glob("prep_g*_hotseed"))
            if not pdirs:
                raise SystemExit(
                    f"--prep-hot-seeds: no prep_g*_hotseed beside {args.prep_run}. Pass "
                    f"--no-prep-hot-seeds to reproduce the pre-2026-08-04 behaviour.")
            ptraj = md.load_dcd(str(pdirs[-1] / "trajectory.dcd"),
                                top=str(pdirs[-1] / "start_structure.pdb"))
            # SPACING MUST MATCH. A hot region's population IS a frame count, so pooling a 1 ps
            # PREP block with 2 ps production frames over-weights the PREP region 2x per unit
            # time -- the same defect that got --hot-preload withdrawn once. The seed dirs do not
            # record their own interval, so the stride is an explicit flag, never inferred.
            pxyz = np.asarray(ptraj.xyz, np.float32)[::max(int(args.prep_hot_stride), 1)]
            # .frames is a list of (n_frames, n_atoms, 3) CHUNKS that all_frames() concatenates,
            # so the PREP block is appended whole -- extending would flatten it to (N*n_atoms, 3).
            hot.frames.append(pxyz)
            prep.update(prep_hot_seeds=True, n_prep_hot_frames=int(len(pxyz)),
                        n_prep_hot_frames_raw=int(ptraj.n_frames),
                        prep_hot_stride=int(args.prep_hot_stride),
                        prep_hot_source=str(pdirs[-1]))
            # ONE HOT WALKER: the PREP frames must be part of the SAME trajectory the preload
            # reads, not an independent walker of the same protocol. Checked by identity, not by
            # provenance: a frame of one trajectory is never bit-close to a frame of another.
            src = getattr(hot, "preload_source", None)
            if src is not None and not args.allow_multiple_hot_walkers:
                d = np.abs(src - pxyz[0][None]).reshape(len(src), -1).max(axis=1).min()
                if d > 1e-5:
                    raise SystemExit(
                        f"TWO HOT WALKERS: the PREP frames in {pdirs[-1]} are not part of "
                        f"{HOT_WALKER.name} (closest frame differs by {d:.4f} nm). The seed pool "
                        f"must come from ONE trajectory -- the two walkers used by campaigns "
                        f"v5/v6 differ by 23% in the phi>0 hot population, and pooling them makes "
                        f"the effective hot ensemble drift with generation. Fix by re-running "
                        f"PREP with --hot-preload so PREP and production share the walker, or "
                        f"pass --no-prep-hot-seeds (loses the +0.402 -> +0.036 kT PREP benefit), "
                        f"or --allow-multiple-hot-walkers to reproduce v5/v6 exactly.")
            prep.update(single_hot_walker=True)
            print(f"[prep] seed pool carries {len(pxyz)} PREP hot frames from {pdirs[-1].name} "
                  f"(stride {args.prep_hot_stride} of {ptraj.n_frames}); generation 1 will draw "
                  f"from {len(pxyz)} + {int(args.md_ps / args.md_save_ps)} frames")
        else:
            prep.update(prep_hot_seeds=False)
            print("[prep] PREP hot frames NOT carried into the seed pool "
                  "(--no-prep-hot-seeds): generation 1 draws from one generation of MD only")
    else:
        (tree, landings), prep = phase_a(args, hot, args.work_dir)
    (args.out / "basin_tree.json").write_text(json.dumps(tree, indent=2) + "\n")
    (args.out / "prep_trace.json").write_text(json.dumps(prep, indent=2) + "\n")
    part = partition_from_dict(tree)
    print(f"[prep] partition has {len(part)} basins")

    res = (phase_b_stratified if args.stratified else phase_b)(
        args, hot, part, landings, args.work_dir)
    walkers = res.pop("_walkers")

    out = dict(protocol=dict(md_ps=args.md_ps, n_ais=args.n_ais, generations=args.generations,
                             g_prep=args.g_prep, prep_tv_tol=args.prep_tv_tol,
                             switch_ps=T_AIS * 0.002, s_hot=S_HOT, s_cold=S_COLD,
                             remd_free=True),
               prep=prep, **res)

    if args.reference and Path(args.reference).exists():
        ref = np.load(args.reference)
        rp, rs = ref["phi"], ref["psi"]
        rlab = assign_basins(rp, rs, part)
        w = ref["weights"]
        pi_ref = np.array([w[rlab == m].sum() for m in range(len(part))])
        out["reference"] = dict(pi=pi_ref.tolist(), delta_f_HC=DELTA_F_REF,
                                delta=(-DELTA_F_REF + np.log(pi_ref)).tolist(),
                                note="REMD is the yardstick only; it is not used by the algorithm")
        # internal-barrier diagnostic: box-conditional sub-populations, MD walker vs REMD
        diag = []
        for m, wk in enumerate(walkers):
            bp, bs = wk.torsions()
            ins = CW.interior_mask(bp, bs, part[m])
            sel = rlab == m
            diag.append(dict(box=f"B{m}",
                             md_mean_phi_deg=float(np.degrees(np.mean(bp[ins]))),
                             remd_mean_phi_deg=float(np.degrees(np.average(rp[sel],
                                                                           weights=w[sel]))),
                             md_frac_phi_pos=float(np.mean(bp[ins] > 0)),
                             remd_frac_phi_pos=float(np.average((rp[sel] > 0), weights=w[sel]))))
        out["internal_barrier_diagnostic"] = diag
        print("\n[diagnostic] box-conditional phi>0 fraction, MD walker vs REMD (deferred issue):")
        for d in diag:
            print(f"  {d['box']}: MD {d['md_frac_phi_pos']:.4f}  vs  "
                  f"REMD {d['remd_frac_phi_pos']:.4f}")

    dest = args.out / "remdfree_results.json"
    dest.write_text(json.dumps(out, indent=2) + "\n")
    print(f"\nwrote {dest}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
