#!/usr/bin/env python3
"""run_top100w_hotmd_forward_ais.py — REMD-free forward AIS from a standalone hot MD.

Replaces the REMD hot replica_03 forward-seed source with the 5 ns standalone hot
MD (step1_hot_md, s=0.4, GBn2 implicit, NOT from REMD).  Same 2 ps switch / 1000
trajectories as the default top100w forward leg, so the only changed variable is
the hot-ensemble origin.  The hot MD shares the ff19sb_gbn2_even 22-atom topology
with REMD, so build_seed_dir can reuse the REMD PDB/config (geometry + prmtop are
identical).

Output: data/alanine_dipeptide/2026-06-18-top100w-hotmd5ns/step_forward_ais/
Usage:  python -m escort_ais.experiments.alanine.run_top100w_hotmd_forward_ais --platform CUDA
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
from run_remd_seeded_ais import build_seed_dir, REMD_DIR

HOT_MD_DCD = ROOT / "data/alanine_dipeptide/2026-06-15-crooks-tram/step1_hot_md/trajectory.dcd"
RUN_DIR = ROOT / "data/alanine_dipeptide/2026-06-18-top100w-hotmd5ns"
K_AIS, T_AIS, FREQ_AIS = 1000, 1000, 10     # 1000 trajs, 2 ps switch, 100 windows
BURNIN = 500                                # 500 ps hot-MD burn-in (1 ps/frame)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    seed_dir = RUN_DIR / "seed_hot"
    # hot MD shares the 22-atom ff19sb_gbn2_even system with REMD -> reuse REMD pdb+config
    build_seed_dir(HOT_MD_DCD, REMD_DIR, seed_dir)
    out = RUN_DIR / "step_forward_ais"
    print(f"  REMD-free forward AIS: 5 ns hot MD seeds, 2 ps switch (s 0.4->1.0) -> {out}")
    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=K_AIS, t_ais=T_AIS, freq_ais=FREQ_AIS,
        s_hot=0.4, s_cold=1.0, seed=20260618,
        start_frame_offset=BURNIN, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=out,
        platform=args.platform, dry_run=args.dry_run, overwrite=True))


if __name__ == "__main__":
    main()
