#!/usr/bin/env python3
"""Final production benchmark of the accelerated alanine AIS workflow (report §14).

Runs, on all requested GPUs with one worker per GPU and the frozen production settings
(square-spaced REST2, ``Freq_AIS = 1``):

* a **discovery** leg (default 256 trajectories, 20 HS observations);
* a **production** leg (default 1000 trajectories, no HS observations);
* the **legacy** per-switch driver on a small matched subset, for the speed-up comparison.

Everything is written to ``reports/alanine/ais_performance/benchmark_data/final_benchmark.json``
plus a figure-data manifest.  No figures are produced.

  python -m escort_ais.experiments.alanine.run_final_alanine_benchmark --device-indices 0,1,2
"""
from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path

import numpy as np

S_HOT, S_COLD = 0.25, 1.0
SEED_DIR = "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"


def out_root() -> Path:
    from escort_ais.common.paths import project_root
    d = project_root() / "reports/alanine/ais_performance/benchmark_data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _dir_bytes(p: Path) -> int:
    return int(sum(f.stat().st_size for f in Path(p).rglob("*") if f.is_file()))


def _stage_fractions(metrics: dict) -> dict:
    """Percentage of worker time in switching / HS observation / frame loading / I/O."""
    groups = {
        "on_device_switching_md": "switching",
        "hz_position_readback": "hz_observation",
        "hz_work_readback": "hz_observation",
        "cold_context_position_assignment": "hz_observation",
        "cold_energy_evaluation": "hz_observation",
        "torsion_calculation": "hz_observation",
        "hz_record_buffering": "hz_observation",
        "initial_frame_loading": "frame_loading",
        "output_flush": "io",
        "context_initialization": "context_setup",
        "final_state_retrieval": "final_readback",
        "position_assignment": "context_setup",
        "velocity_initialization": "context_setup",
    }
    tot = {}
    for _w, stages in metrics.get("stage_timings", {}).items():
        for name, v in stages.items():
            key = groups.get(name, "other")
            tot[key] = tot.get(key, 0.0) + float(v.get("seconds", 0.0))
    grand = sum(tot.values())
    return dict(seconds=tot, grand_total_s=grand,
                percent={k: 100.0 * v / grand for k, v in tot.items()} if grand else {})


def _run_leg(mode: str, run_dir: Path, k_ais: int, t_ais: int, devices, seed: int,
             platform: str, workers_per_gpu: int, hz_n: int | None, stride: int) -> dict:
    from escort_ais.common.paths import project_root
    from escort_ais.methods.chunked_neq_ais import ChunkedNEQConfig
    from escort_ais.methods.chunked_neq_launcher import LaunchSpec, launch

    shutil.rmtree(run_dir, ignore_errors=True)
    cfg = ChunkedNEQConfig(s_hot=S_HOT, s_cold=S_COLD, scaling_mode="square", t_ais=t_ais,
                           freq_ais=1, mode=mode, platform=platform,
                           hz_n_observations=hz_n,
                           full_coordinate_interval_ps=(None if mode == "production" else "auto"))
    t0 = time.perf_counter()
    m = launch(LaunchSpec(cfg=cfg, input_scaled_dir=project_root() / SEED_DIR, run_dir=run_dir,
                          n_trajectories=k_ais, workers_per_gpu=workers_per_gpu,
                          device_indices=tuple(devices), base_seed=seed,
                          start_frame_stride=stride, command="final_alanine_benchmark"))
    m["wall_clock_s_measured"] = time.perf_counter() - t0
    return m


def _forward_metrics(run_dir: Path, ref_pmf, n_boot: int = 400) -> dict:
    """Everything the forward data supports: work stats, JE, ESS, PMF/basin error."""
    import pandas as pd

    from escort_ais.analysis.ais_acceleration_benchmark import (bootstrap_mse, ess_fraction,
                                                                jarzynski, landing_coverage)
    from escort_ais.analysis.chunked_output_schema import (load_discovery,
                                                           load_trajectory_summary)
    from escort_ais.analysis.hz_slice_study import (PHI_BINS, basin_population, pmf_rmse,
                                                    reconstruct_from_slices)

    summ = load_trajectory_summary(run_dir)
    w = summ["reduced_work"].to_numpy(float)
    out = dict(n_trajectories=int(len(w)), work_mean=float(w.mean()),
               work_variance=float(w.var(ddof=1)), work_std=float(w.std(ddof=1)),
               je_dF=jarzynski(w), je_ess_fraction=ess_fraction(w),
               **{f"je_{k}": v for k, v in bootstrap_mse(w, n_boot=n_boot).items()},
               coverage=landing_coverage(summ["final_phi"].to_numpy(float), w))
    try:
        hz = load_discovery(run_dir)
        ids = sorted(int(i) for i in hz[("observation_id" if "observation_id" in hz.columns
                                         else "observation_index")].unique())
        rec = reconstruct_from_slices(hz, ids)
        out["hz_pmf_rmse_kT"] = (pmf_rmse(rec["density"], ref_pmf) if ref_pmf is not None
                                 else float("nan"))
        out["hz_density"] = rec["density"].tolist()
        out["hz_total_ess"] = rec["total_ess"]
        out["basin_population_phi_gt_0"] = basin_population(hz, ids)
        if ref_pmf is not None:
            centres = 0.5 * (PHI_BINS[:-1] + PHI_BINS[1:])
            ref_pop = float(np.asarray(ref_pmf)[centres > 0].sum())
            out["basin_population_reference"] = ref_pop
            out["basin_population_error"] = out["basin_population_phi_gt_0"] - ref_pop
    except FileNotFoundError:
        out["hz"] = "production leg: no HS observations by design"
    return out


def _legacy_reference(work_dir: Path, k_ais: int, t_ais: int, device: str, platform: str,
                      seed: int, stride: int) -> dict:
    """The legacy per-switch driver, same physics, for the speed-up comparison."""
    import pandas as pd

    from escort_ais.analysis.ais_acceleration_benchmark import ess_fraction, jarzynski
    from escort_ais.common.paths import project_root
    from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais

    shutil.rmtree(work_dir, ignore_errors=True)
    cfg = LinearAISConfig(solvent="implicit", k_ais=k_ais, t_ais=t_ais, freq_ais=1,
                          s_hot=S_HOT, s_cold=S_COLD, platform=platform, seed=seed,
                          start_frame_stride=stride,
                          input_scaled_dir=project_root() / SEED_DIR, output_dir=work_dir,
                          overwrite=True, save_traj_every_switch=False, scaling_mode="square",
                          neq_integrator=False, device_index=device)
    t0 = time.perf_counter()
    run_linear_scaling_ais(cfg)
    wall = time.perf_counter() - t0
    df = pd.read_csv(work_dir / "ais_trajectory_summary.csv")
    w = -df["final_logw"].to_numpy(float)
    return dict(name="legacy_per_switch", k_ais=k_ais, wall_clock_s=wall,
                s_per_trajectory=wall / k_ais, trajectories_per_gpu_hour=k_ais / (wall / 3600.0),
                work_mean=float(w.mean()), work_std=float(w.std(ddof=1)),
                je_dF=jarzynski(w), je_ess_fraction=ess_fraction(w))


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device-indices", default="0", type=lambda s: tuple(s.split(",")))
    ap.add_argument("--workers-per-gpu", type=int, default=1)
    ap.add_argument("--k-discovery", type=int, default=256)
    ap.add_argument("--k-production", type=int, default=1000)
    ap.add_argument("--k-legacy", type=int, default=48)
    ap.add_argument("--t-ais", type=int, default=2500)
    ap.add_argument("--t-ais-discovery", type=int, default=None,
                    help="discovery switch length (default: same as --t-ais; §6 may set longer)")
    ap.add_argument("--seed", type=int, default=20260728)
    ap.add_argument("--scratch", default="/tmp/final_alanine_benchmark")
    ap.add_argument("--skip-legacy", action="store_true")
    args = ap.parse_args(argv)

    from escort_ais.analysis.ais_acceleration_benchmark import reference_phi_pmf
    ref = reference_phi_pmf()
    scratch = Path(args.scratch)
    t_disc = args.t_ais_discovery or args.t_ais
    payload = dict(name="final_benchmark", platform=args.platform,
                   device_indices=list(args.device_indices), n_gpus=len(args.device_indices),
                   workers_per_gpu=args.workers_per_gpu, scaling_mode="square", freq_ais=1,
                   t_ais_production=args.t_ais, t_ais_discovery=t_disc,
                   switch_duration_production_ps=args.t_ais * 2.0 / 1000.0,
                   switch_duration_discovery_ps=t_disc * 2.0 / 1000.0,
                   reference_available=ref is not None)

    print(f"[final] discovery leg: K={args.k_discovery}, 20 HS observations")
    d_dir = scratch / "discovery"
    m_disc = _run_leg("discovery", d_dir, args.k_discovery, t_disc, args.device_indices,
                      args.seed, args.platform, args.workers_per_gpu, 20, stride=97)
    payload["discovery"] = dict(
        launch=m_disc, stage_fractions=_stage_fractions(m_disc),
        output_bytes=_dir_bytes(d_dir), metrics=_forward_metrics(d_dir, ref))
    print(f"   {m_disc['trajectories_per_gpu_hour']:.0f} traj/GPU-h, "
          f"{m_disc['wall_clock_s']:.1f} s, "
          f"RMSE {payload['discovery']['metrics'].get('hz_pmf_rmse_kT', float('nan')):.3f} kT")

    print(f"[final] production leg: K={args.k_production}, no HS observations")
    p_dir = scratch / "production"
    m_prod = _run_leg("production", p_dir, args.k_production, args.t_ais, args.device_indices,
                      args.seed + 7, args.platform, args.workers_per_gpu, None, stride=31)
    payload["production"] = dict(
        launch=m_prod, stage_fractions=_stage_fractions(m_prod),
        output_bytes=_dir_bytes(p_dir), metrics=_forward_metrics(p_dir, ref))
    print(f"   {m_prod['trajectories_per_gpu_hour']:.0f} traj/GPU-h, "
          f"{m_prod['wall_clock_s']:.1f} s")

    if not args.skip_legacy:
        print(f"[final] legacy per-switch driver: K={args.k_legacy} (one GPU)")
        leg = _legacy_reference(scratch / "legacy", args.k_legacy, args.t_ais,
                                args.device_indices[0], args.platform, args.seed, stride=97)
        payload["legacy"] = leg
        payload["speedup_production_vs_legacy"] = (
            leg["s_per_trajectory"] /
            (m_prod["wall_clock_s"] / max(m_prod["n_trajectories_completed"], 1)
             * len(args.device_indices)))
        print(f"   legacy {leg['s_per_trajectory']:.3f} s/traj -> speed-up "
              f"{payload['speedup_production_vs_legacy']:.2f}x per GPU")

    payload["failures"] = dict(
        discovery=m_disc["partitions"]["n_missing"],
        production=m_prod["partitions"]["n_missing"])
    payload["mixture_cft"] = dict(
        status="not evaluated by this benchmark",
        reason=("Delta f_HC from mixture-CFT requires REVERSE legs started from umbrella "
                "proposal ensembles; this benchmark measures the forward workflow only. The "
                "reverse plumbing (leg/proposal_id/source_window_id, starting coordinates) is "
                "in place and schema-tested, but no reverse production set was generated here."),
        forward_je_dF_production=payload["production"]["metrics"]["je_dF"],
        forward_je_bootstrap_std=payload["production"]["metrics"].get("je_boot_std"))

    p = out_root() / "final_benchmark.json"
    p.write_text(json.dumps(payload, indent=2, default=str))
    print(f"[final] wrote {p}")


if __name__ == "__main__":
    main()
