#!/usr/bin/env python3
"""Run 4-replica REST2-REMD with a linear scale ladder for alanine dipeptide.

Workflow (per --solvent invocation):
  1. Resolve topology dir (explicit → data/topology/ff19sb_opc;
                           implicit → data/topology/ff19sb_gbn2).
  2. Build the OPC topology if it does not yet exist (explicit only).
  3. Build the linear REST2 REMD ladder (rest2/ladder.json + per-replica XMLs).
  4. Run REMD via md_run.run_remd.

Ensemble is selected automatically:
  explicit (OPC) → NPT at 1 bar
  implicit (GBn2) → NVT

Usage examples
--------------
  # Dry run — no files written, no simulation started
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_rest2_remd_linear \\
      --solvent implicit --dry-run

  # Build topologies + ladders only (no production MD)
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_rest2_remd_linear \\
      --solvent explicit --build-only

  # Short smoke run (0.05 ns) before committing to the full 250 ns
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_rest2_remd_linear \\
      --solvent implicit --duration-ns 0.05 --platform OpenCL

  # Full production
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_rest2_remd_linear \\
      --solvent implicit --duration-ns 250 --platform OpenCL

NOTE: 4 replicas × 250 ns explicit OPC is a multi-day single-GPU job.
The two solvents should be launched independently (or sequentially via the
accompanying .sh orchestrator) as each run can occupy the GPU for days.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Allow running without installing the package (is still
# required for the full conda-env invocation; this is a belt-and-suspenders
# guard for direct python calls from the repo root).


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

from escort_ais.common.paths import project_root
_REPO_ROOT = project_root()
_DATA_TOPO = _REPO_ROOT / "data" / "topology"

_TOPO_DIRS = {
    "explicit": _DATA_TOPO / "ff19sb_opc",
    "implicit": _DATA_TOPO / "ff19sb_gbn2",
}

_PROTEIN_SEQUENCE = ["ACE", "ALA", "NME"]


def _parse_scales(raw: str) -> list[float]:
    """Parse a comma-separated string of floats, e.g. '0.25,0.5,0.75,1.0'."""
    parts = [p.strip() for p in raw.split(",")]
    try:
        return [float(p) for p in parts if p]
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"--scales must be comma-separated floats, e.g. '0.25,0.5,0.75,1.0'; got {raw!r}"
        ) from exc


def _pick_platform(preferred: str | None) -> str:
    from escort_ais.systems.openmm_system import available_platform_names

    available = set(available_platform_names())
    if preferred is not None:
        if preferred not in available:
            raise ValueError(
                f"Requested platform '{preferred}' not available. "
                f"Available: {sorted(available)}"
            )
        return preferred
    for candidate in ["CUDA", "OpenCL", "CPU", "Reference"]:
        if candidate in available:
            return candidate
    raise RuntimeError("No OpenMM platform is available.")


def _build_opc_topology(output_dir: Path) -> None:
    """Build ACE-ALA-NME ff19SB+OPC topology if it does not exist."""
    from escort_ais.systems.topology_prep import build_topology

    print(f"Building explicit OPC topology → {output_dir} …")
    result = build_topology(
        output_dir=output_dir,
        protein_sequence=_PROTEIN_SEQUENCE,
        forcefield="ff19sb",
        solvent="opc",
        salt_concentration_molar=0.15,
        box_padding_angstrom=12.0,
    )
    print(f"  prmtop         : {result['prmtop']}")
    print(f"  inpcrd         : {result['inpcrd']}")
    print(f"  n_solute_atoms : {result['n_solute_atoms']}")
    print(f"  n_ions         : {result.get('n_ions', 'n/a')}")


def _build_linear_ladder(
    topology_dir: Path,
    scales: list[float],
    base_temperature_k: float,
    dry_run: bool = False,
    gb_radii: str | None = "mbondi3",
) -> dict:
    """Call build_rest2_systems with the explicit scale list."""
    from escort_ais.systems.topology_prep import build_rest2_systems, resolve_remd_scale_ladder

    sorted_scales, t_effs = resolve_remd_scale_ladder(scales, base_temperature_k)
    if dry_run:
        return {"scale_factors": sorted_scales, "effective_temperatures_k": t_effs}

    print("Building REST2 replica ladder …")
    for i, (s, t) in enumerate(zip(sorted_scales, t_effs)):
        print(f"  replica {i:02d}  scale={s:.4f}  T_eff={t:.1f} K")

    result = build_rest2_systems(
        topology_dir,
        mode="remd",
        scale_factors=scales,
        base_temperature_k=base_temperature_k,
        gb_radii=gb_radii,
    )
    print(f"  ladder.json    : {result['ladder_json']}")
    return result


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description=(
            "4-replica REST2-REMD with a linear scale ladder for alanine dipeptide "
            "(explicit OPC or implicit GBn2 solvent)."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument(
        "--solvent",
        required=True,
        choices=["explicit", "implicit"],
        help="Solvent model: 'explicit' (OPC/NPT) or 'implicit' (GBn2/NVT).",
    )
    p.add_argument(
        "--duration-ns",
        type=float,
        default=250.0,
        metavar="NS",
        help="Production MD duration in ns per replica.",
    )
    p.add_argument(
        "--scales",
        type=_parse_scales,
        default="0.25,0.5,0.75,1.0",
        metavar="S1,S2,...",
        help=(
            "Comma-separated REST2 scale factors. The list is sorted descending "
            "(replica 0 = physical s=1.0) before use."
        ),
    )
    p.add_argument(
        "--temperature-k",
        type=float,
        default=300.0,
        metavar="K",
        help="Bath / physical temperature in K.",
    )
    p.add_argument(
        "--exchange-interval-ps",
        type=float,
        default=1.0,
        metavar="PS",
        help="Replica-exchange attempt interval in ps.",
    )
    p.add_argument(
        "--platform",
        default="OpenCL",
        help="OpenMM platform. Use 'CPU' as fallback if GPU init fails.",
    )
    p.add_argument("--seed", type=int, default=20260606)
    p.add_argument(
        "--gb-radii",
        type=str,
        default="mbondi3",
        metavar="SET",
        help=(
            "GB radii set applied via parmed changeRadii before building the GBn2 base "
            "system (e.g. 'mbondi3'). Implicit GBn2 only; matches the macrocycle/BAIS "
            "Hamiltonian. Default None = OpenMM built-in radii."
        ),
    )
    p.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Override the auto-named output directory under data/md/.",
    )
    p.add_argument(
        "--topology-dir",
        type=Path,
        default=None,
        help=(
            "Override the default topology directory. "
            "Defaults to data/topology/ff19sb_opc or data/topology/ff19sb_gbn2."
        ),
    )
    p.add_argument(
        "--build-only",
        action="store_true",
        help="Build topology and ladder only — do not run any MD.",
    )
    p.add_argument(
        "--skip-build",
        action="store_true",
        help=(
            "Assume the topology dir and rest2/ladder.json already exist; "
            "skip build steps and go straight to REMD."
        ),
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help=(
            "Print resolved parameters (topology dir, ladder, output dir) and exit. "
            "No files are created and no simulation is started."
        ),
    )
    return p.parse_args()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    args = parse_args()

    topology_dir = args.topology_dir or _TOPO_DIRS[args.solvent]

    # Resolve ladder (pure, no OpenMM)
    from escort_ais.systems.topology_prep import resolve_remd_scale_ladder
    sorted_scales, t_effs = resolve_remd_scale_ladder(args.scales, args.temperature_k)
    n_replicas = len(sorted_scales)

    # Auto output-dir name mirrors md_run.run_remd's convention
    if args.output_dir is not None:
        output_dir_display = args.output_dir
    else:
        dur_label = f"{args.duration_ns:g}".replace(".", "p") + "ns"
        output_dir_display = (
            _REPO_ROOT / "data" / "md"
            / f"{topology_dir.name}_{n_replicas}rep_{args.temperature_k:g}K_remd_{dur_label}"
        )

    # ── Dry run ──────────────────────────────────────────────────────────────
    if args.dry_run:
        print("=== DRY RUN ===")
        print(f"solvent            : {args.solvent}")
        print(f"topology_dir       : {topology_dir}")
        print(f"topology_exists    : {topology_dir.exists()}")
        print(f"n_replicas         : {n_replicas}")
        for i, (s, t) in enumerate(zip(sorted_scales, t_effs)):
            print(f"  replica {i:02d}  scale={s:.4f}  T_eff={t:.1f} K")
        print(f"duration_ns        : {args.duration_ns}")
        print(f"exchange_interval  : {args.exchange_interval_ps} ps")
        print(f"temperature_k      : {args.temperature_k}")
        print(f"platform           : {args.platform}  (not checked in dry-run)")
        print(f"seed               : {args.seed}")
        print(f"output_dir         : {output_dir_display}")
        ladder_path = topology_dir / "rest2" / "ladder.json"
        print(f"ladder.json_exists : {ladder_path.exists()}")
        return

    # ── Pick platform ─────────────────────────────────────────────────────────
    platform = _pick_platform(args.platform)
    print(f"Platform: {platform}")

    # ── Build topology if needed ──────────────────────────────────────────────
    if not args.skip_build:
        if not topology_dir.exists():
            if args.solvent == "explicit":
                _build_opc_topology(topology_dir)
            else:
                raise FileNotFoundError(
                    f"Implicit topology dir not found: {topology_dir}. "
                    "Build it first with escort_ais/experiments/prep/step00_build_topology.py --solvent gbn2."
                )
        else:
            print(f"Topology dir found: {topology_dir}")

        # ── Build the linear REST2 ladder ─────────────────────────────────────
        _build_linear_ladder(topology_dir, args.scales, args.temperature_k, gb_radii=args.gb_radii)

    if args.build_only:
        print("--build-only set; skipping REMD run.")
        return

    # ── Run REMD ──────────────────────────────────────────────────────────────
    from escort_ais.methods import md_run

    print(
        f"\nStarting REST2-REMD: {n_replicas} replicas × {args.duration_ns} ns "
        f"({args.solvent} / {platform})"
    )
    summary = md_run.run_remd(
        topology_dir,
        duration_ns=args.duration_ns,
        temperature_k=args.temperature_k,
        exchange_interval_ps=args.exchange_interval_ps,
        platform=platform,
        seed=args.seed,
        output_dir=args.output_dir,
    )
    print("\n=== REMD summary ===")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
