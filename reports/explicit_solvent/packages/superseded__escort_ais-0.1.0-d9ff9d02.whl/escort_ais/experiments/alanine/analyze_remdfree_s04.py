#!/usr/bin/env python3
"""analyze_remdfree_s04.py — estimators + reweighting for the REMD-free experiment.

On the FRESH kinetic basins (results/remdfree_s04/basins), compute cold-basin ddF by
AIS (v2, forward-only), intra-BAR, and combined-BAR, then reweight to recover the cold
ensemble two ways:
  B (8 ns) : IS-reweight the 1000 forward-AIS cold endpoints by Jarzynski weights
             e^{lnw_f}  (hot MD + forward AIS only; no cold MD, no reverse).
  C (12 ns): reweight the 20x100 ps cold-MD reservoir by per-basin combined-BAR ddF
             (w_i ∝ p_{basin(i)}/n_{basin(i)}, p = softmax(-ddF)).
Reference: converged REMD replica_00 (250 ns) on the same fresh basins; matched-cost
baseline: REMD @12 ns total = 3 ns/replica (counting).

Outputs -> results/remdfree_s04/:
  endpoint_estimators_summary.csv   (ddF per method + RMSE vs converged REMD)
  rama_samples.npz                  (phi/psi/weights per method, for the notebook)
Usage:  TOP100W_EXP=remdfree_s04 python -m escort_ais.experiments.alanine.analyze_remdfree_s04
"""
from __future__ import annotations

import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import BURNIN_REMD, REMD_DIR, load_phi_psi_dcd  # noqa: E402
from escort_ais.methods.kinetic_basin import assign_level1  # noqa: E402
from escort_ais.methods.endpoint_bar import (  # noqa: E402
    endpoint_partitioned_pairwise_bar, endpoint_restricted_bar)
from escort_ais.common.top100w_cfg import FWD, RESULTS as OUT, RUNS  # noqa: E402

BASINS = OUT / "basins"
N_SEEDS, BURN_FRAMES = 20, 10
REMD12_NS_PER_REPLICA = 3.0          # 12 ns total / 4 replicas
NS_PER_FRAME = 0.01


def softmax_ddF(ddF):
    """p_b = exp(-ddF_b)/Z over finite basins; gated (nan) basins get 0."""
    ddF = np.asarray(ddF, float); p = np.zeros_like(ddF)
    fin = np.isfinite(ddF)
    p[fin] = np.exp(-ddF[fin] - logsumexp(-ddF[fin]))
    return p


def ddF_from_pops(pop):
    pop = np.asarray(pop, float)
    with np.errstate(divide="ignore"):
        return -np.log(pop / pop[0])


def main():
    with open(BASINS / "kmeans.pkl", "rb") as f:
        KM = pickle.load(f)
    M2B = np.load(BASINS / "microstate_to_basin.npy")
    NB = int(M2B.max()) + 1
    assign = lambda ph, ps: assign_level1(ph, ps, KM, M2B).astype(int)
    BN = [f"B{b}" for b in range(NB)]

    # ── forward leg ──
    logw_f = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    W_f = -logw_f
    fidx = pd.read_csv(FWD / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    sph, sps = load_phi_psi_dcd(FWD.parent / "seed_hot/trajectory.dcd")   # sliced [1,5]ns hot window
    a_f = assign(sph[fidx], sps[fidx])                                    # forward hot-start basin
    eph, eps = load_phi_psi_dcd(FWD / "ais_final_coordinates.dcd")
    b_f = assign(eph, eps)                                                # forward cold-end basin
    hot_counts = np.bincount(assign(sph, sps), minlength=NB).astype(float)  # hot ensemble counts
    g_counts = -np.log((hot_counts + 0.5) / (hot_counts[0] + 0.5))

    # ── reverse leg ──
    rv = np.load(OUT / "reverse_ais_results.npz")
    W_r, b_r, a_r = rv["reverse_work"], rv["reverse_cold_start_basin"], rv["reverse_hot_end_basin"]

    # ── estimators (fresh basins) ──
    v2 = np.array([(-logsumexp(logw_f[b_f == b]) if (b_f == b).any() else np.nan) for b in range(NB)])
    v2 = v2 - v2[0]
    Delta, var, diag = endpoint_partitioned_pairwise_bar(
        W_f, a_f, b_f, W_r, b_r, a_r, NB, bootstrap=True, n_bootstrap=120,
        rng=np.random.default_rng(7))
    # hot-unified (global-hot) BAR: walls only the cold end, unified hot reference; AIS
    # is its N_r->0 limit. Needs fwd-into-beta + rev-from-beta, NO matched hot alpha.
    v6r = endpoint_restricted_bar(W_f, b_f, W_r, b_r, list(range(NB)))
    hub = np.array([v6r["ddF"].get(b, np.nan) for b in range(NB)])
    dd = np.array([Delta[i, i] for i in range(NB)])
    intra = (dd - dd[0]) + g_counts; intra[0] = 0.0

    # ── REMD reference (converged 250 ns) + matched-cost REMD @12 ns ──
    rph, rps = load_phi_psi_dcd(REMD_DIR / "replica_00/trajectory.dcd")
    rb = assign(rph, rps)
    ref = ddF_from_pops(np.bincount(rb[BURNIN_REMD:], minlength=NB))
    hi12 = BURNIN_REMD + int(round(REMD12_NS_PER_REPLICA / NS_PER_FRAME))
    remd12 = ddF_from_pops(np.bincount(rb[BURNIN_REMD:hi12], minlength=NB))

    # ── reweighting ──
    # B (8 ns): forward-AIS endpoints by Jarzynski weight
    wB = np.exp(logw_f - logsumexp(logw_f))
    ddF_B = ddF_from_pops(np.array([wB[b_f == b].sum() for b in range(NB)]))
    # C (12 ns): cold reservoir reweighted by hot-unified (global-hot) BAR ddF
    res_phi, res_psi, res_basin = [], [], []
    for s in range(N_SEEDS):
        ph, ps = load_phi_psi_dcd(RUNS / f"seed_{s:03d}/trajectory.dcd")
        res_phi.append(ph[BURN_FRAMES:]); res_psi.append(ps[BURN_FRAMES:])
    res_phi = np.concatenate(res_phi); res_psi = np.concatenate(res_psi)
    res_basin = assign(res_phi, res_psi)
    res_pop = np.bincount(res_basin, minlength=NB).astype(float)

    def reservoir_weights(ddF):
        p = softmax_ddF(ddF); w = np.zeros(len(res_basin))
        for b in range(NB):
            if p[b] > 0 and res_pop[b] > 0:
                w[res_basin == b] = p[b] / res_pop[b]
        return w / w.sum() if w.sum() > 0 else w
    wC = reservoir_weights(hub)
    ddF_C = ddF_from_pops(np.array([wC[res_basin == b].sum() for b in range(NB)]))
    # AIS+localMD (10 ns): between-basin ddF from AIS (v2), within-basin from the cold
    # reservoir (local equilibrium); no reverse leg. Intermediate between AIS and BAR.
    wAL = reservoir_weights(v2)
    ddF_AL = ddF_from_pops(np.array([wAL[res_basin == b].sum() for b in range(NB)]))

    # ── summary table ──
    methods = {
        "REMD reference (250ns)": ref, "REMD @12ns (3ns x4)": remd12,
        "AIS v2 (fwd-only, 8ns)": v2, "intra-BAR (12ns)": intra,
        "hot-unified BAR (12ns)": hub,
        "B reweight endpoints (8ns)": ddF_B,
        "AIS+localMD (10ns)": ddF_AL, "C reweight reservoir (12ns)": ddF_C,
    }
    df = pd.DataFrame(methods, index=BN).T
    df["RMSE_vs_ref"] = [np.sqrt(np.nanmean((np.asarray(v, float) - ref) ** 2)) for v in methods.values()]
    df.loc["REMD reference (250ns)", "RMSE_vs_ref"] = np.nan
    df.round(3).to_csv(OUT / "endpoint_estimators_summary.csv")
    print(df.round(3).to_string())

    # ── samples for Ramachandran panels (phi/psi + weights) ──
    np.savez(OUT / "rama_samples.npz",
             ref_phi=rph[BURNIN_REMD:], ref_psi=rps[BURNIN_REMD:],
             remd12_phi=rph[BURNIN_REMD:hi12], remd12_psi=rps[BURNIN_REMD:hi12],
             B_phi=eph, B_psi=eps, B_w=wB,
             AL_phi=res_phi, AL_psi=res_psi, AL_w=wAL,
             C_phi=res_phi, C_psi=res_psi, C_w=wC,
             n_basins=NB)

    # ── phi/psi surface distance vs the converged-REMD surface (total variation) ──
    edges = np.linspace(-180, 180, 37)

    def hist2d(phi, psi, w):
        H, _, _ = np.histogram2d(phi, psi, bins=[edges, edges], weights=w, density=False)
        return H / H.sum()
    Href = hist2d(rph[BURNIN_REMD:], rps[BURNIN_REMD:], None)
    tv = lambda H: float(0.5 * np.abs(H - Href).sum())
    surf = {
        "REMD @12ns (3ns x4)": tv(hist2d(rph[BURNIN_REMD:hi12], rps[BURNIN_REMD:hi12], None)),
        "B endpoints (8ns)": tv(hist2d(eph, eps, wB)),
        "AIS+localMD (10ns)": tv(hist2d(res_phi, res_psi, wAL)),
        "C: hot-unified BAR reservoir (12ns)": tv(hist2d(res_phi, res_psi, wC)),
    }
    pd.DataFrame({"method": list(surf), "TV_vs_converged_REMD": list(surf.values())}).round(4).to_csv(
        OUT / "surface_tv.csv", index=False)
    print("\n  phi/psi surface TV vs converged REMD (0=identical, lower=better):")
    for k, v in surf.items():
        print(f"    {k:22s}: {v:.4f}")
    print(f"\n  Saved endpoint_estimators_summary.csv + rama_samples.npz + surface_tv.csv "
          f"-> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
