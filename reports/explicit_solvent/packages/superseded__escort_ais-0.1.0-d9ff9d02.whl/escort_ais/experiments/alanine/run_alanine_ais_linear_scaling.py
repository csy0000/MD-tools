#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


from escort_ais.methods.ais_linear import LinearAISConfig, default_output_dir, resolve_tail_intervals, run_linear_scaling_ais, validate_ais_lengths


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run alanine-dipeptide AIS with linear scaling-factor interpolation.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--solvent", required=True, choices=["implicit", "explicit"])
    parser.add_argument("--k-ais", required=True, type=int)
    parser.add_argument("--t-ais", required=True, type=int)
    parser.add_argument("--freq-ais", required=True, type=int)
    parser.add_argument("--s-hot", type=float, default=0.188)
    parser.add_argument("--s-cold", type=float, default=1.0)
    parser.add_argument("--temperature", type=float, default=300.0)
    parser.add_argument("--platform", default=None)
    parser.add_argument("--seed", type=int, default=20260603)
    parser.add_argument("--start-frame-stride", type=int, default=1)
    parser.add_argument("--start-frame-offset", type=int, default=0)
    parser.add_argument("--input-scaled-dir", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--device-index", default=None)
    parser.add_argument(
        "--save-traj-every-switch",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Save one coordinate frame to ais_work_coordinates.dcd at every switch.",
    )
    parser.add_argument(
        "--save-tail-ps",
        type=float,
        default=None,
        metavar="PS",
        help=(
            "Save coordinates only for the last PS picoseconds of each switching path "
            "(near-target tail). When set, overrides --save-traj-every-switch. "
            "Reduces disk usage while keeping the most informative samples for "
            "per-window reweighting. Example: --save-tail-ps 0.5"
        ),
    )
    # ── accelerated chunked-NEQ path (discovery / production modes; report §10) ──────────────
    accel = parser.add_argument_group(
        "accelerated chunked-NEQ AIS",
        "Multi-worker on-device switching. --mode selects WHAT is recorded; it does not change "
        "the physical protocol, the work convention or the schedule.")
    accel.add_argument(
        "--mode", choices=["legacy", "validation", "discovery", "production"], default="legacy",
        help="legacy = the single-process per-switch driver (unchanged default). "
             "validation = small run with every diagnostic on (manual-vs-NEQ work, determinism, "
             "force-contamination checks). "
             "discovery = chunked NEQ + 20 sparse Hummer-Szabo observations. "
             "production = chunked NEQ, final work + endpoints only.")
    accel.add_argument("--scaling-mode", choices=["linear", "square"], default="linear",
                       help="REST2 schedule spacing: even in s, or even in sqrt(s).")
    accel.add_argument("--neq-integrator", action=argparse.BooleanOptionalAction, default=None,
                       help="Accumulate the protocol work on-device in an openmmtools NEQ "
                            "integrator (forced on for --mode discovery/production).")
    accel.add_argument("--hz-n-observations", type=int, default=None,
                       help="Number of square-spaced Hummer-Szabo observation states (discovery "
                            "mode). Independent of M_ais and of Freq_ais.")
    accel.add_argument("--hz-s-min", type=float, default=None,
                       help="Place all --hz-n-observations inside s in [HZ_S_MIN, s_cold] instead "
                            "of spreading them over the whole switch. Only the cold end carries "
                            "usable HS weight, so without this a caller wanting N slices above "
                            "s_min must request ~3N and let the reconstruction discard the rest.")
    accel.add_argument("--full-coordinate-interval-ps", type=float, default=None,
                       help="Physical-time interval between FULL coordinate frames. Independent "
                            "of the HS observation schedule; <=0 disables sparse frames.")
    accel.add_argument("--save-intermediate", action=argparse.BooleanOptionalAction, default=None,
                       help="--no-save-intermediate (the production default) records only the "
                            "final work and endpoints: no HS observations, no sparse frames.")
    accel.add_argument("--cv-definition", default=None,
                       help="system slug, or path to systems/<slug>/cv_definition.json. Records "
                            "ALL declared CVs on every HS observation. REQUIRED for macrocycles: "
                            "without it only mdtraj phi/psi are stored, and those are NaN on a "
                            "cyclic topology (183k all-NaN rows were written for RGD this way).")
    accel.add_argument("--omega-exclude-npy", default=None,
                       help="npy of secondary-amide bonds left UNSCALED by REST2 (macrocycles).")
    accel.add_argument("--workers-per-gpu", type=int, default=1,
                       help="Worker processes per GPU. Each owns its context, seeds and output dir.")
    accel.add_argument("--device-indices", default=None, metavar="I,J",
                       help="Comma-separated GPU indices, e.g. 0,1. Defaults to --device-index or 0.")
    accel.add_argument("--base-seed", type=int, default=None,
                       help="Seed base for worker/trajectory seeds (default: --seed).")
    accel.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True,
                       help="Skip global trajectory ids already flushed to the run directory.")
    accel.add_argument("--rerun-failed", action="store_true",
                       help="Replay ONLY the ids in <output-dir>/failed_partitions.json, keeping "
                            "their original global trajectory ids and seeds.")
    accel.add_argument("--leg", choices=["forward", "reverse"], default="forward",
                       help="Recorded on every row; reverse legs also carry proposal ids.")
    accel.add_argument("--proposal-id", default=None,
                       help="Reverse legs: identifier of the proposal ensemble that seeded them.")
    accel.add_argument("--source-window-id", default=None,
                       help="Reverse legs: identifier of the umbrella window the proposal came from.")
    return parser.parse_args()


def _pick_platform(preferred: str | None) -> str:
    from escort_ais.systems.openmm_system import available_platform_names

    available = set(available_platform_names())
    if preferred is not None:
        if preferred not in available:
            raise ValueError(f"Requested platform '{preferred}' not available. Available: {sorted(available)}")
        return preferred
    for candidate in ["CUDA", "OpenCL", "CPU", "Reference"]:
        if candidate in available:
            return candidate
    raise RuntimeError("No OpenMM platform is available.")


def _run_chunked(args, platform: str, m_ais: int) -> None:
    """--mode discovery / production: multi-worker chunked-NEQ AIS (report §7, §10)."""
    from escort_ais.common import run_manifest as rm
    from escort_ais.common.paths import project_root, run_dir
    from escort_ais.methods.ais_linear import default_input_scaled_dir
    from escort_ais.methods.chunked_neq_ais import ChunkedNEQConfig
    from escort_ais.methods.chunked_neq_launcher import LaunchSpec, launch

    devices = tuple((args.device_indices or str(args.device_index or "0")).split(","))
    base_seed = args.base_seed if args.base_seed is not None else args.seed
    input_dir = args.input_scaled_dir or default_input_scaled_dir(project_root(), args.solvent)

    # ── §2: reject incompatible combinations up front, with an actionable message ────────
    if args.mode == "production":
        if args.save_intermediate:
            raise SystemExit("--mode production is incompatible with --save-intermediate: "
                             "production records only the final work and endpoints. "
                             "Use --mode discovery.")
        if args.hz_n_observations:
            raise SystemExit(f"--mode production is incompatible with --hz-n-observations="
                             f"{args.hz_n_observations}. Use --mode discovery.")
        if args.full_coordinate_interval_ps and args.full_coordinate_interval_ps > 0:
            raise SystemExit("--mode production is incompatible with "
                             "--full-coordinate-interval-ps: no intermediate coordinates are "
                             "written. Use --mode discovery.")
        if args.save_traj_every_switch and "--save-traj-every-switch" in sys.argv:
            raise SystemExit("--mode production is incompatible with --save-traj-every-switch "
                             "(that is the legacy per-switch DCD path).")
    if args.mode in ("discovery", "validation") and args.save_intermediate is False:
        raise SystemExit(f"--mode {args.mode} exists to record intermediate observations; "
                         "--no-save-intermediate contradicts it. Use --mode production.")
    if args.scaling_mode != "square":
        print(f"[warn] --scaling-mode {args.scaling_mode}: the frozen production schedule is "
              "'square' (even in sqrt(s)).", file=sys.stderr)
    if args.freq_ais != 1:
        print(f"[warn] --freq-ais {args.freq_ais}: the frozen production setting is 1 "
              "(benchmarked as the most precise per GPU-hour).", file=sys.stderr)
    if args.workers_per_gpu != 1:
        print(f"[warn] --workers-per-gpu {args.workers_per_gpu}: 1 is optimal for alanine "
              "without CUDA MPS (see the acceleration report §7).", file=sys.stderr)

    hz = args.hz_n_observations                        # None -> frozen preset for the mode
    coord_ps = args.full_coordinate_interval_ps
    if args.mode == "production":
        hz, coord_ps = 0, None
    elif coord_ps is not None and coord_ps <= 0:
        coord_ps = None
    cfg = ChunkedNEQConfig(
        s_hot=args.s_hot, s_cold=args.s_cold, scaling_mode=args.scaling_mode,
        t_ais=args.t_ais, freq_ais=args.freq_ais, temperature_k=args.temperature,
        mode=args.mode, hz_n_observations=hz,
        hz_s_min=(None if args.mode == "production" else args.hz_s_min),
        full_coordinate_interval_ps=("auto" if coord_ps is None and args.mode != "production"
                                     else coord_ps),
        save_final_coordinates=True, platform=platform, device_index=devices[0],
        leg=args.leg, proposal_id=args.proposal_id, source_window_id=args.source_window_id,
        save_initial_coordinates=(args.leg == "reverse"))

    cfg_for_hash = dict(mode=args.mode, solvent=args.solvent, k_ais=args.k_ais, t_ais=args.t_ais,
                        freq_ais=args.freq_ais, s_hot=args.s_hot, s_cold=args.s_cold,
                        scaling_mode=args.scaling_mode, temperature=args.temperature,
                        seed=base_seed, hz_n_observations=cfg.hz_n_observations,
                        hz_s_min=cfg.hz_s_min,
                        full_coordinate_interval_ps=cfg.full_coordinate_interval_ps,
                        start_frame_stride=args.start_frame_stride,
                        start_frame_offset=args.start_frame_offset)
    method = f"chunked_neq_ais_{args.mode}"
    run_id = rm.make_run_id("alanine_dipeptide", method, rm.config_hash(cfg_for_hash))
    d = Path(args.output_dir) if args.output_dir else run_dir(run_id)
    manifest = rm.RunManifest.new(
        run_id=run_id, system="alanine_dipeptide", method=method,
        config_hash=rm.config_hash(cfg_for_hash),
        command="python -m escort_ais.experiments.alanine.run_alanine_ais_linear_scaling "
                f"--mode {args.mode}",
        seeds=[base_seed], backend=platform, retention="production")

    if args.dry_run:
        rm.write_manifest(d, manifest)
        print("=== DRY RUN (chunked NEQ) ===")
        print(f"run_id                 : {run_id}")
        print(f"mode                   : {args.mode}")
        print(f"platform               : {platform}")
        print(f"K_ais / M_ais          : {args.k_ais} / {m_ais}")
        print(f"Freq_ais               : {args.freq_ais}")
        print(f"scaling_mode           : {args.scaling_mode}")
        print(f"hz_n_observations      : {cfg.hz_n_observations}")
        print(f"full_coord_interval_ps : {cfg.full_coordinate_interval_ps}")
        print(f"workers/gpu × devices  : {args.workers_per_gpu} × {list(devices)}")
        print(f"base_seed              : {base_seed}")
        print(f"input_scaled_dir       : {input_dir}")
        print(f"output_dir             : {d}")
        return

    rm.write_manifest(d, manifest)
    rm.update_status(d, "running")
    spec = LaunchSpec(
        cfg=cfg, input_scaled_dir=Path(input_dir), run_dir=d, n_trajectories=args.k_ais,
        workers_per_gpu=args.workers_per_gpu, device_indices=devices, base_seed=base_seed,
        solvent=args.solvent, start_frame_stride=args.start_frame_stride,
        start_frame_offset=args.start_frame_offset, resume=args.resume,
        cv_definition=args.cv_definition, omega_exclude_bonds=_omega_bonds(args),
        command=" ".join([sys.executable, "-m",
                          "escort_ais.experiments.alanine.run_alanine_ais_linear_scaling",
                          *sys.argv[1:]]))
    try:
        if args.rerun_failed:
            from escort_ais.methods.chunked_neq_launcher import rerun_failed_partitions
            metrics = rerun_failed_partitions(d, spec)
        else:
            metrics = launch(spec)
    except Exception as exc:
        rm.update_status(d, "failed", failure_reason=str(exc)[:500])
        raise
    rm.update_status(d, "completed", output_paths=[str(d / "merged")])
    print(f"run manifest       : {d / 'manifest.json'}")
    print(json.dumps({k: v for k, v in metrics.items()
                      if k not in ("stage_timings", "per_worker")}, indent=2))


def _omega_bonds(args):
    """Omega bonds excluded from REST2 scaling; None for a dipeptide."""
    if not getattr(args, "omega_exclude_npy", None):
        return None
    import numpy as _np
    return _np.load(args.omega_exclude_npy)


def main() -> None:
    args = parse_args()
    m_ais, n_ais = validate_ais_lengths(args.k_ais, args.t_ais, args.freq_ais)
    platform = args.platform or "CPU"
    if not args.dry_run:
        platform = _pick_platform(args.platform)
    if args.mode != "legacy":
        _run_chunked(args, platform, m_ais)
        return
    config = LinearAISConfig(
        solvent=args.solvent,
        k_ais=args.k_ais,
        t_ais=args.t_ais,
        freq_ais=args.freq_ais,
        s_hot=args.s_hot,
        s_cold=args.s_cold,
        temperature_k=args.temperature,
        platform=platform,
        seed=args.seed,
        start_frame_stride=args.start_frame_stride,
        start_frame_offset=args.start_frame_offset,
        input_scaled_dir=args.input_scaled_dir,
        output_dir=args.output_dir,
        overwrite=args.overwrite,
        dry_run=args.dry_run,
        save_traj_every_switch=args.save_traj_every_switch,
        save_tail_ps=args.save_tail_ps,
        device_index=args.device_index,
        scaling_mode=args.scaling_mode,
        neq_integrator=bool(args.neq_integrator),
    )

    # --- run provenance (see docs/protocols/report_and_run_provenance.md) ---
    from escort_ais.common.paths import project_root, run_dir
    from escort_ais.common import run_manifest as rm
    cfg = {k: getattr(args, k) for k in ("solvent", "k_ais", "t_ais", "freq_ais", "s_hot", "s_cold",
                                         "temperature", "seed", "start_frame_stride", "start_frame_offset")}
    run_id = rm.make_run_id("alanine_dipeptide", "linear_ais", rm.config_hash(cfg))
    manifest = rm.RunManifest.new(
        run_id=run_id, system="alanine_dipeptide", method="linear_ais", config_hash=rm.config_hash(cfg),
        command="python -m escort_ais.experiments.alanine.run_alanine_ais_linear_scaling",
        seeds=[args.seed], backend=platform, retention="production")

    if args.dry_run:
        repo_root = project_root()
        rm.write_manifest(run_dir(run_id), manifest)                 # planned manifest (dry-run records intent)
        print(f"run_id             : {run_id}")
        print(f"manifest           : {run_dir(run_id) / 'manifest.json'}")
        # timestep_fs comes from the input-scaled-dir config; use 2.0 as default for dry-run display
        _timestep_fs_dry = 2.0
        n_tail = None
        if args.save_tail_ps is not None:
            try:
                n_tail = resolve_tail_intervals(args.save_tail_ps, m_ais, args.freq_ais, _timestep_fs_dry)
            except ValueError:
                n_tail = "INVALID"
        resolved_output = default_output_dir(repo_root, config)
        print("=== DRY RUN ===")
        print(f"solvent            : {args.solvent}")
        print(f"platform           : {platform}")
        print(f"K_ais              : {args.k_ais}")
        print(f"T_ais              : {args.t_ais}")
        print(f"Freq_ais           : {args.freq_ais}")
        print(f"M_ais              : {m_ais}")
        print(f"N_ais              : {n_ais}")
        print(f"s_hot              : {args.s_hot}")
        print(f"s_cold             : {args.s_cold}")
        print(f"temperature        : {args.temperature}")
        print(f"seed               : {args.seed}")
        if args.save_tail_ps is not None:
            print(f"save_tail_ps       : {args.save_tail_ps} ps  →  {n_tail} tail intervals")
        else:
            print(f"save_every_switch  : {args.save_traj_every_switch}")
        print(f"output_dir         : {resolved_output}")
        return

    d = run_dir(run_id)
    rm.write_manifest(d, manifest)                                   # planned
    rm.update_status(d, "running")
    try:
        summary = run_linear_scaling_ais(config)
    except Exception as exc:                                         # record failure, then re-raise
        rm.update_status(d, "failed", failure_reason=str(exc)[:500])
        raise
    rm.update_status(d, "completed", output_paths=[str(default_output_dir(project_root(), config))])
    print(f"run manifest       : {d / 'manifest.json'}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
