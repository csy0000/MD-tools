#!/usr/bin/env python3
"""analyze_top100w_prep.py — Steps 4-5: basins + AIS-weight table + RITE inputs.

Collects the 20 x 100 ps cold MD (drops burn-in), assigns frames AND the 1000
forward AIS endpoints to the PRODUCTION basin model (so ddF is comparable to the
REMD reference and old-RITE), computes the AIS-reweighted basin probabilities,
and writes per-included-basin arrays for RITEWeight.

A fresh k-means (k=50) on the new cold MD is also reported as a Step-4 diagnostic
(number of discovered states / population) but is NOT used for the estimator
pipeline (consistent basins are required for the comparison).

Outputs -> results/top100w_diverse20_100ps/:
  ais_basin_weight_table.csv, cold_md_basin_diag.json,
  rite_input/basin_{B}/{phi_all.npy,psi_all.npy,traj_boundaries.npy}
Usage:  python -m escort_ais.experiments.alanine.analyze_top100w_prep [--min-basin-weight 0.005]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import N_BASINS, load_phi_psi_dcd  # noqa: E402
from escort_ais.analysis.analyze_ala_endpoint_partitioned import _assign  # noqa: E402

from escort_ais.common.top100w_cfg import FWD as FWD2PS, TOP_PDB, RUNS, RESULTS as OUT  # noqa: E402
SEED_PDB = OUT / "structures"
N_SEEDS = 20
BURN_FRAMES = 20      # 20 ps at 1 ps/frame


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--min-basin-weight", type=float, default=0.005)
    args = ap.parse_args()
    (OUT / "rite_input").mkdir(parents=True, exist_ok=True)

    # ── collect cold MD frames (post burn-in), per seed ──
    seed_phi, seed_psi = [], []
    for s in range(N_SEEDS):
        dcd = RUNS / f"seed_{s:03d}/trajectory.dcd"
        ph, ps = load_phi_psi_dcd(dcd)        # uses production PRMTOP top (22 atoms)
        seed_phi.append(ph[BURN_FRAMES:]); seed_psi.append(ps[BURN_FRAMES:])
    phi = np.concatenate(seed_phi); psi = np.concatenate(seed_psi)
    bl = _assign(phi, psi)                    # production basins
    print(f"  cold MD frames (post {BURN_FRAMES} ps burn-in): {len(phi)} "
          f"({[int((bl==b).sum()) for b in range(N_BASINS)]} per production basin)")

    # ── Step-4 diagnostic: fresh k-means on the new cold MD ──
    feats = np.column_stack([np.cos(np.radians(phi)), np.sin(np.radians(phi)),
                             np.cos(np.radians(psi)), np.sin(np.radians(psi))])
    k = min(50, len(phi))
    km = KMeans(n_clusters=k, n_init=4, random_state=0).fit(feats)
    occ = np.bincount(km.labels_, minlength=k)
    json.dump(dict(n_microstates=int(k), n_occupied=int((occ > 0).sum()),
                   cold_md_frames=int(len(phi)),
                   prod_basin_pop=[int((bl == b).sum()) for b in range(N_BASINS)]),
              open(OUT / "cold_md_basin_diag.json", "w"), indent=2)

    # ── Step 5: AIS endpoints -> production basins, AIS-reweighted prob ──
    logw = pd.read_csv(FWD2PS / "ais_trajectory_summary.csv")["final_logw"].values
    eph, eps = load_phi_psi_dcd(FWD2PS / "ais_final_coordinates.dcd")
    eb = _assign(eph, eps)
    lse_all = logsumexp(logw)
    rows = []
    for b in range(N_BASINS):
        msk = eb == b
        sw = float(np.exp(logsumexp(logw[msk]) - lse_all)) if msk.any() else 0.0
        rows.append(dict(basin=b, n_endpoints=int(msk.sum()), sum_weight_lse=(
            float(logsumexp(logw[msk])) if msk.any() else float("-inf")), p_AIS=sw))
    pA = np.array([r["p_AIS"] for r in rows])
    for b, r in enumerate(rows):
        r["deltaF_vs_basin0"] = (float(-np.log(pA[b] / pA[0]))
                                 if pA[b] > 0 and pA[0] > 0 else float("nan"))
        r["included_for_reverse_sampling"] = bool(pA[b] >= args.min_basin_weight)
    pd.DataFrame(rows).to_csv(OUT / "ais_basin_weight_table.csv", index=False)
    print(f"  AIS-reweighted basin p = {pA.round(4)}  "
          f"(included p>= {args.min_basin_weight}: {[r['basin'] for r in rows if r['included_for_reverse_sampling']]})")

    # ── per-included-basin RITE inputs (within-basin contiguous segments) ──
    included = [r["basin"] for r in rows if r["included_for_reverse_sampling"]]
    for B in included:
        ph_b, ps_b, bnds, src = [], [], [0], []
        for s in range(N_SEEDS):
            m = _assign(seed_phi[s], seed_psi[s]) == B
            idx = np.where(m)[0]              # post-burn local indices into this seed
            if len(idx) == 0:
                continue
            splits = np.where(np.diff(idx) > 1)[0] + 1
            for seg in np.split(idx, splits):
                ph_b.append(seed_phi[s][seg]); ps_b.append(seed_psi[s][seg])
                bnds.append(bnds[-1] + len(seg))
                # provenance: (seed_id, cold-MD frame index) for each frame
                src.extend([(s, BURN_FRAMES + int(fi)) for fi in seg])
        d = OUT / "rite_input" / f"basin_{B}"
        d.mkdir(parents=True, exist_ok=True)
        np.save(d / "phi_all.npy", np.concatenate(ph_b))
        np.save(d / "psi_all.npy", np.concatenate(ps_b))
        np.save(d / "traj_boundaries.npy", np.array(bnds))
        np.save(d / "frame_src.npy", np.array(src))     # (n_frames, 2): seed_id, md_frame
        print(f"    basin {B}: {bnds[-1]} frames, {len(bnds)-1} within-basin segments -> rite_input/basin_{B}")
    print(f"  Saved basin table + RITE inputs -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
