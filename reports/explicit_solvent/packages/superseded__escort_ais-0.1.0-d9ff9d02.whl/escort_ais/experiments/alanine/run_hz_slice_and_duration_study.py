#!/usr/bin/env python3
"""Run the HS slice-count sweep (§4) and the switch-duration bias/variance sweep (§5, §6).

Both write machine-readable JSON to ``reports/alanine/ais_performance/benchmark_data/``; no
figures are produced (a figure-data manifest is written for later plotting).

  python -m escort_ais.experiments.alanine.run_hz_slice_and_duration_study \\
      --which all --device-indices 0,1,2 --k-ais 256
"""
from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path

import numpy as np

from escort_ais.analysis.hz_slice_study import (
    PHI_BINS,
    bias_variance_decomposition,
    basin_population,
    plateau_decision,
    pmf_rmse,
    reconstruct_from_slices,
    slice_count_study,
    subset_slice_ids,
)

S_HOT, S_COLD = 0.25, 1.0
SEED_DIR = "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"


def out_root() -> Path:
    from escort_ais.common.paths import project_root
    d = project_root() / "reports/alanine/ais_performance/benchmark_data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _write(name: str, payload: dict) -> Path:
    p = out_root() / f"{name}.json"
    p.write_text(json.dumps(payload, indent=2, default=str))
    print(f"[study] wrote {p}")
    return p


def _reference_phi_pmf():
    from escort_ais.analysis.ais_acceleration_benchmark import reference_phi_pmf
    return reference_phi_pmf()


def _run_discovery(run_dir: Path, k_ais: int, t_ais: int, hz_n: int, devices, seed: int,
                   platform: str = "CUDA", workers_per_gpu: int = 1,
                   stride: int = 97) -> dict:
    """One discovery leg; returns the merged HS table plus timing."""
    import pandas as pd

    from escort_ais.common.paths import project_root
    from escort_ais.methods.chunked_neq_ais import ChunkedNEQConfig
    from escort_ais.methods.chunked_neq_launcher import LaunchSpec, launch

    shutil.rmtree(run_dir, ignore_errors=True)
    cfg = ChunkedNEQConfig(s_hot=S_HOT, s_cold=S_COLD, scaling_mode="square", t_ais=t_ais,
                           freq_ais=1, mode="discovery", hz_n_observations=hz_n,
                           full_coordinate_interval_ps=None, platform=platform)
    m = launch(LaunchSpec(cfg=cfg, input_scaled_dir=project_root() / SEED_DIR, run_dir=run_dir,
                          n_trajectories=k_ais, workers_per_gpu=workers_per_gpu,
                          device_indices=tuple(devices), base_seed=seed,
                          start_frame_stride=stride,
                          command="hz_slice_and_duration_study"))
    hz = pd.read_parquet(run_dir / "merged" / "hz_observations.parquet")
    summ = pd.read_parquet(run_dir / "merged" / "trajectory_summary.parquet")
    return dict(hz=hz, summary=summ, metrics=m)


# ───────────────────────────────── §4 ────────────────────────────────────────
def study_slice_count(args, ref) -> dict:
    scratch = Path(args.scratch) / "L_sweep"
    print(f"[study] §4 slice-count: one L={max(args.L)} discovery set, "
          f"K={args.k_ais}, then paired subsets")
    run = _run_discovery(scratch / "L40", args.k_ais, args.t_ais, max(args.L),
                         args.device_indices, args.seed, args.platform, args.workers_per_gpu)
    study = slice_count_study(run["hz"], ref, L_values=tuple(args.L), n_boot=args.n_boot)
    study["source_run"] = dict(k_ais=args.k_ais, t_ais=args.t_ais,
                               switch_duration_ps=args.t_ais * 2.0 / 1000.0,
                               wall_clock_s=run["metrics"]["wall_clock_s"],
                               traj_per_gpu_hour=run["metrics"]["trajectories_per_gpu_hour"])

    # wall-clock / file-size overhead is NOT obtainable from subsets: time each L for real
    print("[study] §4 overhead: timing each L on a short run")
    overhead = {}
    for L in args.L:
        if L < 2:
            overhead[str(L)] = dict(note="L=1 is the production path (no HS observations)")
            continue
        d = scratch / f"time_L{L}"
        r = _run_discovery(d, args.k_overhead, args.t_ais, L, args.device_indices[:1],
                           args.seed + L, args.platform, 1)
        hz_bytes = (d / "merged" / "hz_observations.parquet").stat().st_size
        overhead[str(L)] = dict(
            k_ais=args.k_overhead, wall_clock_s=r["metrics"]["wall_clock_s"],
            s_per_trajectory=r["metrics"]["wall_clock_s"] / max(args.k_overhead, 1),
            traj_per_gpu_hour=r["metrics"]["trajectories_per_gpu_hour"],
            hz_parquet_bytes=int(hz_bytes),
            hz_bytes_per_trajectory=float(hz_bytes) / max(args.k_overhead, 1),
            n_hz_rows=int(len(r["hz"])))
        print(f"   L={L:>2}: {overhead[str(L)]['s_per_trajectory']:.3f} s/traj, "
              f"{hz_bytes/1024:.1f} KiB")
    study["overhead"] = overhead
    study["plateau"] = plateau_decision(study)
    print(f"[study] §4 decision: {study['plateau']['decision']}")
    return study


# ───────────────────────────────── §5/§6 ─────────────────────────────────────
def study_duration(args, ref) -> dict:
    """Sweep the physical switch duration at Freq_AIS=1 and split MSE into bias² + variance."""
    scratch = Path(args.scratch) / "duration_sweep"
    per_batch = max(args.k_ais // args.n_batches, 8)
    print(f"[study] §5 duration sweep: {args.durations_ps} ps, {args.n_batches} independent "
          f"batches of {per_batch} trajectories each")

    rows = {}
    for ps in args.durations_ps:
        t_ais = int(round(ps * 1000.0 / 2.0))            # Freq_AIS=1, 2 fs timestep
        batch_rmse, batch_pop, batch_dF, batch_ess, wall = [], [], [], [], 0.0
        densities = []
        for b in range(args.n_batches):
            d = scratch / f"ps{ps:g}_b{b}"
            r = _run_discovery(d, per_batch, t_ais, 20, args.device_indices, args.seed + 1000 * b,
                               args.platform, args.workers_per_gpu,
                               stride=97 + 7 * b)          # disjoint seed-bank strides
            wall += r["metrics"]["wall_clock_s"]
            hz, summ = r["hz"], r["summary"]
            ids = sorted(int(i) for i in
                         hz[("observation_id" if "observation_id" in hz.columns
                             else "observation_index")].unique())
            rec = reconstruct_from_slices(hz, ids)
            densities.append(rec["density"].tolist())
            batch_rmse.append(pmf_rmse(rec["density"], ref) if ref is not None else float("nan"))
            batch_pop.append(basin_population(hz, ids))
            w = summ["final_W_reduced"].to_numpy()
            from escort_ais.analysis.ais_acceleration_benchmark import ess_fraction, jarzynski
            batch_dF.append(jarzynski(w))
            batch_ess.append(ess_fraction(w))

        ref_pop = float(np.nan)
        if ref is not None:
            centres = 0.5 * (PHI_BINS[:-1] + PHI_BINS[1:])
            ref_pop = float(np.asarray(ref)[centres > 0].sum())

        w_all = np.concatenate([np.asarray(batch_dF)])
        rows[f"{ps:g}"] = dict(
            switch_duration_ps=float(ps), t_ais=t_ais, m_ais=t_ais, freq_ais=1,
            n_batches=args.n_batches, k_per_batch=per_batch,
            wall_clock_s=wall, gpu_hours=wall / 3600.0 * len(args.device_indices),
            hz_pmf_rmse_batches=batch_rmse,
            hz_pmf_rmse_mean=float(np.nanmean(batch_rmse)),
            basin_population_batches=batch_pop,
            basin_population_mean=float(np.nanmean(batch_pop)),
            basin_population_reference=ref_pop,
            je_dF_batches=batch_dF, je_dF_mean=float(np.mean(batch_dF)),
            je_work_variance=float(np.var(batch_dF, ddof=1)) if len(batch_dF) > 1 else float("nan"),
            je_ess_fraction_mean=float(np.mean(batch_ess)),
            pmf_error_per_gpu_hour=(float(np.nanmean(batch_rmse)) /
                                    max(wall / 3600.0 * len(args.device_indices), 1e-12)),
            densities=densities,
        )
        # MSE = bias^2 + variance, against the converged REMD reference
        if ref is not None and np.isfinite(ref_pop):
            rows[f"{ps:g}"]["population_decomposition"] = bias_variance_decomposition(
                batch_pop, ref_pop)
        rows[f"{ps:g}"]["pmf_rmse_decomposition"] = bias_variance_decomposition(
            batch_rmse, 0.0)      # target for an RMSE is 0: any residual mean IS bias
        print(f"   {ps:>5g} ps: RMSE {np.nanmean(batch_rmse):.3f} kT, "
              f"P(phi>0) {np.nanmean(batch_pop):.4f} (ref {ref_pop:.4f}), "
              f"{wall:.0f} s")
    return dict(name="duration_sweep", rows=rows, durations_ps=list(args.durations_ps),
                reference_phi_pmf_available=ref is not None,
                design="independent trajectory batches; MSE = bias^2 + variance")


def recommend_lengths(duration_study: dict) -> dict:
    """§6: pick discovery and production switch lengths independently from the benchmark."""
    rows = duration_study["rows"]
    disc = min(rows.items(), key=lambda kv: (kv[1]["hz_pmf_rmse_mean"]
                                             if np.isfinite(kv[1]["hz_pmf_rmse_mean"])
                                             else np.inf))
    # production wants precision in dF per GPU-hour: variance of the JE estimate x GPU time
    def eff(v):
        var = v.get("je_work_variance", np.nan)
        gh = max(v.get("gpu_hours", np.nan), 1e-12)
        return (1.0 / (var * gh)) if (np.isfinite(var) and var > 0) else -np.inf
    prod = max(rows.items(), key=lambda kv: eff(kv[1]))
    return dict(
        discovery=dict(switch_duration_ps=disc[1]["switch_duration_ps"],
                       reason="lowest HS PMF RMSE",
                       hz_pmf_rmse_kT=disc[1]["hz_pmf_rmse_mean"]),
        production=dict(switch_duration_ps=prod[1]["switch_duration_ps"],
                        reason="best 1/(Var(dF_hat) x GPU-hour)",
                        efficiency=eff(prod[1]), je_variance=prod[1]["je_work_variance"]),
        same_length=disc[1]["switch_duration_ps"] == prod[1]["switch_duration_ps"],
        efficiency_by_duration={k: eff(v) for k, v in rows.items()},
        rmse_by_duration={k: v["hz_pmf_rmse_mean"] for k, v in rows.items()})


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--which", nargs="+", default=["all"], choices=["all", "slices", "duration"])
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device-indices", default="0", type=lambda s: tuple(s.split(",")))
    ap.add_argument("--workers-per-gpu", type=int, default=1)
    ap.add_argument("--k-ais", type=int, default=256)
    ap.add_argument("--k-overhead", type=int, default=32)
    ap.add_argument("--t-ais", type=int, default=2500)
    ap.add_argument("--L", type=int, nargs="+", default=[1, 5, 10, 20, 40])
    ap.add_argument("--durations-ps", type=float, nargs="+", default=[2.5, 5, 10, 20, 50])
    ap.add_argument("--n-batches", type=int, default=4)
    ap.add_argument("--n-boot", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20260728)
    ap.add_argument("--scratch", default="/tmp/hz_study")
    args = ap.parse_args(argv)

    which = set(args.which)
    if "all" in which:
        which = {"slices", "duration"}
    ref = _reference_phi_pmf()
    if ref is None:
        print("[study] WARNING: converged REMD reference unavailable; bias cannot be estimated")

    if "slices" in which:
        _write("hz_slice_count_study", study_slice_count(args, ref))
    if "duration" in which:
        st = study_duration(args, ref)
        st["length_recommendation"] = recommend_lengths(st)
        _write("switch_duration_study", st)
        print(f"[study] §6 recommendation: {json.dumps(st['length_recommendation'], indent=2)}")


if __name__ == "__main__":
    main()
