#!/usr/bin/env python3
"""build_remdfree_basins.py — fresh kinetic basins from the REMD-free cold MD (PCCA+).

Builds a self-contained kinetic basin model from the 20x100 ps cold-MD reservoir
(no REMD, no production model):
  - drop first 10 ps of each seed,
  - KMeans microstates on the 4-D torus embedding of phi/psi,
  - reversible MSM (deeptime) on the per-seed discrete trajectories,
  - PCCA+ into N_BASINS metastable basins (proper kinetic coarse-graining;
    connected-components over-merges short continuous MD into a single basin).
Microstates outside the MSM active set are mapped to the nearest active basin.
Saves the model so every later step assigns on the SAME fresh coordinate.

Cold-MD source: by default the single-point reservoir (top100w_cfg RUNS). Override with
the REMDFREE_BASIN_RUNS env var (path to a dir of seed_NNN/trajectory.dcd) to build from a
different budget -- e.g. the i=4 sweep reservoir runs/remdfree_s04_sweep/i04 (hot 20 ns),
whose cold MD reaches positive-phi/Lalpha so PCCA+ can resolve a 4th well.

Outputs -> results/remdfree_s04/basins/:
  kmeans.pkl, microstate_to_basin.npy, basin_assign.npz, ramachandran.png

Usage:  TOP100W_EXP=remdfree_s04 python -m escort_ais.experiments.alanine.build_remdfree_basins
        REMDFREE_BASIN_RUNS=runs/remdfree_s04_sweep/i04 TOP100W_EXP=remdfree_s04 \
            python -m escort_ais.experiments.alanine.build_remdfree_basins
"""
from __future__ import annotations

import os
import pickle
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.analysis.analyze_ala_msk_all_solvers import load_phi_psi_dcd  # noqa: E402
from escort_ais.methods.kinetic_basin import basin_summary, fit_kmeans_torus, predict_microstates  # noqa: E402
from escort_ais.methods.msm_estimation import fit_reversible_msm, pcca_basins  # noqa: E402
from escort_ais.common.top100w_cfg import RUNS, RESULTS as OUT  # noqa: E402

N_SEEDS = 20
BURN_FRAMES = 10        # drop first 10 ps (1 ps/frame cold MD)
N_MICRO = 30
LAG = 1
N_BASINS = 4            # PCCA+ target (Ramachandran wells: C7eq/PPII, alphaR, Lalpha, rare)
SEED = 20260618
BASINS = OUT / "basins"
# cold-MD reservoir to fit on (default: single-point RUNS; override for a sweep budget)
SRC_RUNS = Path(os.environ["REMDFREE_BASIN_RUNS"]) if os.environ.get("REMDFREE_BASIN_RUNS") else RUNS
if not SRC_RUNS.is_absolute():
    SRC_RUNS = ROOT / SRC_RUNS


def main():
    BASINS.mkdir(parents=True, exist_ok=True)
    print(f"  cold-MD source: {SRC_RUNS.relative_to(ROOT) if SRC_RUNS.is_relative_to(ROOT) else SRC_RUNS}")
    phi_segs, psi_segs, bounds = [], [], [0]
    for s in range(N_SEEDS):
        ph, ps = load_phi_psi_dcd(SRC_RUNS / f"seed_{s:03d}/trajectory.dcd")
        phi_segs.append(ph[BURN_FRAMES:]); psi_segs.append(ps[BURN_FRAMES:])
        bounds.append(bounds[-1] + len(ph) - BURN_FRAMES)
    phi = np.concatenate(phi_segs); psi = np.concatenate(psi_segs)
    boundaries = np.array(bounds, dtype=int)
    print(f"  cold-MD reservoir: {len(phi)} frames over {N_SEEDS} seeds (dropped first {BURN_FRAMES} ps)")

    km = fit_kmeans_torus(phi, psi, n_clusters=N_MICRO, seed=SEED)
    micro = predict_microstates(phi, psi, km)
    dtrajs = [micro[boundaries[i]:boundaries[i + 1]] for i in range(N_SEEDS)]

    msm = fit_reversible_msm(dtrajs, lag=LAG)
    msm = pcca_basins(msm, n_basins=N_BASINS)
    active = np.asarray(msm.model.count_model.state_symbols, dtype=int)   # original micro ids
    basin_active = np.asarray(msm.basin_of_microstate, dtype=int)         # per active state
    print(f"  microstates={N_MICRO} lag={LAG} | MSM active set={len(active)}/{N_MICRO} "
          f"| PCCA+ -> {len(np.unique(basin_active))} basins")

    # full microstate -> basin map; inactive micros -> nearest active basin (by torus center)
    micro2basin = np.full(N_MICRO, -1, dtype=int)
    micro2basin[active] = basin_active
    centers = km.cluster_centers_
    for m in np.where(micro2basin < 0)[0]:
        d = np.linalg.norm(centers[active] - centers[m], axis=1)
        micro2basin[m] = basin_active[int(np.argmin(d))]

    # relabel basins by population (0 = largest = reference)
    bl = micro2basin[micro]
    nb = int(micro2basin.max()) + 1
    pops = np.array([(bl == b).sum() for b in range(nb)])
    order = np.argsort(-pops)
    remap = np.empty(nb, int); remap[order] = np.arange(nb)
    micro2basin = remap[micro2basin]
    bl = micro2basin[micro]
    n_basins = int(micro2basin.max()) + 1

    with open(BASINS / "kmeans.pkl", "wb") as f:
        pickle.dump(km, f)
    np.save(BASINS / "microstate_to_basin.npy", micro2basin)
    np.savez(BASINS / "basin_assign.npz", phi=phi, psi=psi, basin=bl, boundaries=boundaries)
    basin_summary(phi, psi, bl.astype(str), boundaries)
    print(f"  per-basin populations (relabeled, 0=largest): "
          f"{[int((bl == b).sum()) for b in range(n_basins)]}")

    fig, ax = plt.subplots(figsize=(6, 5.5))
    sc = ax.scatter(phi, psi, c=bl, s=6, cmap="tab10", vmin=0, vmax=9)
    ax.set_xlabel(r"$\phi$ (deg)"); ax.set_ylabel(r"$\psi$ (deg)")
    ax.set_xlim(-180, 180); ax.set_ylim(-180, 180)
    ax.set_title(f"REMD-free PCCA+ kinetic basins (n={n_basins}) from cold MD")
    fig.colorbar(sc, ax=ax, label="basin"); fig.tight_layout()
    fig.savefig(str(BASINS / "ramachandran.png"), dpi=140); plt.close(fig)
    print(f"  Saved fresh PCCA+ basin model -> {BASINS.relative_to(ROOT)} (n_basins={n_basins})")


if __name__ == "__main__":
    main()
