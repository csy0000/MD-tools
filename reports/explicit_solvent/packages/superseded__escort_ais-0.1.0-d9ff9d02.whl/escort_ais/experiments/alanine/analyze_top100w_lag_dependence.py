#!/usr/bin/env python3
"""analyze_top100w_lag_dependence.py — how the endpoint ddF depends on the RITE lag.

The reverse-AIS work of a cold frame is independent of the RITE weights (those only
decide which frames seed reverse AIS).  So we run reverse AIS ONCE over EVERY
within-basin cold frame (cached), then for each lag tau in {2,5,10,20} ps resample
250/basin proportional to that lag's RITE weights and recompute v3/v5/v6 + RMSE.
N_REP resamples give a mean +/- band.  This isolates the lag dependence at fixed AIS.

Outputs -> results/<exp>/:
  lag_dependence.csv, plots/lag_dependence_rmse.png, plots/lag_dependence_ddF.png
Usage:  TOP100W_EXP=diverse20_100ps \
          python -m escort_ais.experiments.alanine.analyze_top100w_lag_dependence --platform CUDA
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
from escort_ais.analysis.analyze_ala_msk_all_solvers import N_BASINS, load_phi_psi_dcd
from escort_ais.analysis.analyze_ala_endpoint_partitioned import _assign, reference_ddF
from escort_ais.analysis.analyze_top100w_estimators import estimators, load_forward, rmse
from escort_ais.common.top100w_cfg import RESULTS as OUT, RUNS, TOP_PDB, REVRUN, HOT_SRC, HOT_BURN

RITE_IN = OUT / "rite_input"
RITE = OUT / "rite"
PLOTS = OUT / "plots"
LAGS = [2, 5, 10, 20]
N_DRAW, N_REP = 250, 8
BN = ["B0", "B1", "B2", "B3"]
T_AIS, FREQ = 1000, 10


def build_or_load_dense_reverse(platform):
    """Reverse AIS over every within-basin cold frame (cached).  Returns per-basin
    dict basin -> (W_by_local, hot_end_by_local) aligned to frame_weights order."""
    cache = REVRUN / "dense_reverse.npz"
    basins = sorted(int(p.name.split("_")[1]) for p in RITE_IN.glob("basin_*"))
    if cache.exists():
        d = np.load(cache)
        return basins, {B: (d[f"W_{B}"], d[f"hot_{B}"]) for B in basins}

    cold = {s: md.load_dcd(str(RUNS / f"seed_{s:03d}/trajectory.dcd"), top=str(TOP_PDB))
            for s in range(20)}
    xyz, dense_basin, dense_local = [], [], []
    for B in basins:
        src = np.load(RITE_IN / f"basin_{B}/frame_src.npy")          # (n,2) seed, md_frame; frame_weights order
        for i, (s, mf) in enumerate(src):
            xyz.append(cold[int(s)].xyz[int(mf)])
            dense_basin.append(B); dense_local.append(i)
    dense_basin = np.array(dense_basin); dense_local = np.array(dense_local)
    seed_dir = REVRUN / "seed_cold_dense"; seed_dir.mkdir(parents=True, exist_ok=True)
    md.Trajectory(np.array(xyz), cold[0].topology).save_dcd(str(seed_dir / "trajectory.dcd"))
    import shutil, json
    shutil.copy2(TOP_PDB, seed_dir / "start_structure.pdb")
    cfg = json.loads((ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_even_4rep_300K_remd_250ns/config.json").read_text())
    keys = ["prmtop_path", "inpcrd_path", "topology_solvent", "timestep_fs",
            "friction_per_ps", "temperature_k", "solvent", "n_solute_atoms"]
    (seed_dir / "config.json").write_text(json.dumps({k: cfg[k] for k in keys}, indent=2))

    out = REVRUN / "step_dense_reverse_ais"
    print(f"  dense reverse AIS: {len(xyz)} trajs (all within-basin frames), 2 ps ...")
    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=len(xyz), t_ais=T_AIS, freq_ais=FREQ,
        s_hot=1.0, s_cold=0.4, seed=20260620, start_frame_offset=0, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=out, platform=platform, dry_run=False, overwrite=True))

    logw = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].values
    sel = pd.read_csv(out / "selected_initial_frames.csv")["initial_frame_index"].astype(int).values
    phe, pse = load_phi_psi_dcd(out / "ais_final_coordinates.dcd")
    hot_end_out = _assign(phe, pse)
    n = len(dense_basin)
    W_by_seed = np.full(n, np.nan); hot_by_seed = np.full(n, -1, int)
    W_by_seed[sel] = -logw; hot_by_seed[sel] = hot_end_out
    res = {}
    save = {}
    for B in basins:
        order = np.where(dense_basin == B)[0]            # already in local order
        res[B] = (W_by_seed[order], hot_by_seed[order])
        save[f"W_{B}"] = res[B][0]; save[f"hot_{B}"] = res[B][1]
    np.savez(cache, **save)
    print(f"  cached dense reverse -> {cache.relative_to(ROOT)}")
    return basins, res


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--platform", default="CUDA")
    args = ap.parse_args()
    PLOTS.mkdir(parents=True, exist_ok=True)
    ref = reference_ddF()
    W_f, a_f, b_f = load_forward()
    hot = _assign(*load_phi_psi_dcd(HOT_SRC))[HOT_BURN:]
    basins, dense = build_or_load_dense_reverse(args.platform)

    rng = np.random.default_rng(2026)
    rows = []
    for tau in LAGS:
        accum = {k: [] for k in ["v3", "v5", "v6"]}
        ddF_accum = {k: [] for k in ["v3", "v5", "v6"]}
        for rep in range(N_REP):
            W_r, b_r, a_r = [], [], []
            for B in basins:
                w = np.load(RITE / f"basin_{B}_tau{tau}/frame_weights.npy"); w = w / w.sum()
                W_B, hot_B = dense[B]
                ok = np.isfinite(W_B)                      # guard any failed AIS frame
                wv = np.where(ok, w, 0.0); wv = wv / wv.sum()
                pick = rng.choice(len(W_B), N_DRAW, replace=True, p=wv)
                W_r.append(W_B[pick]); a_r.append(hot_B[pick]); b_r.append(np.full(N_DRAW, B))
            W_r = np.concatenate(W_r); b_r = np.concatenate(b_r); a_r = np.concatenate(a_r)
            est = estimators(W_f, a_f, b_f, W_r, b_r, a_r, hot, ref)
            for k in accum:
                accum[k].append(rmse(est[k], ref)); ddF_accum[k].append(np.asarray(est[k], float))
        row = dict(lag_ps=tau)
        for k in accum:
            row[f"{k}_rmse_mean"] = float(np.nanmean(accum[k]))
            row[f"{k}_rmse_std"] = float(np.nanstd(accum[k]))
            dd = np.nanmean(np.vstack(ddF_accum[k]), axis=0)
            for bi in range(N_BASINS):
                row[f"{k}_ddF_{BN[bi]}"] = float(dd[bi])
        # also record the per-basin RITE ESS at this lag
        rd = pd.read_csv(RITE / "rite_diagnostics.csv")
        row["ESS_frac_mean"] = float(rd[rd.tau == tau]["ESS_frac"].mean())
        rows.append(row)
        print(f"  lag {tau:2d} ps: v3={row['v3_rmse_mean']:.3f} v5={row['v5_rmse_mean']:.3f} "
              f"v6={row['v6_rmse_mean']:.3f}  (ESS_frac~{row['ESS_frac_mean']:.2f})")
    tbl = pd.DataFrame(rows)
    tbl.round(3).to_csv(OUT / "lag_dependence.csv", index=False)

    # ── RMSE vs lag ──
    fig, ax = plt.subplots(figsize=(6.5, 4.4))
    for k, c in [("v3", "#4477AA"), ("v5", "#AA3377"), ("v6", "#228833")]:
        ax.errorbar(tbl.lag_ps, tbl[f"{k}_rmse_mean"], yerr=tbl[f"{k}_rmse_std"],
                    marker="o", capsize=3, color=c, label=k)
    ax2 = ax.twinx()
    ax2.plot(tbl.lag_ps, tbl.ESS_frac_mean, ls="--", color="0.5", marker="s", label="RITE ESS frac")
    ax2.set_ylabel("RITE ESS fraction (dashed)", color="0.4")
    ax.set_xlabel("RITE lag τ (ps)"); ax.set_ylabel("RMSE vs REMD ref (kT)")
    ax.set_xticks(LAGS); ax.set_title("Endpoint ΔΔF accuracy vs RITE lag")
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout(); fig.savefig(str(PLOTS / "lag_dependence_rmse.png"), dpi=140); plt.close(fig)

    # ── per-basin ddF vs lag (v6) ──
    fig, ax = plt.subplots(figsize=(6.5, 4.4))
    for bi in range(N_BASINS):
        y = [r[f"v6_ddF_{BN[bi]}"] for r in rows]
        if np.isfinite(y).any():
            ax.plot(tbl.lag_ps, y, marker="o", label=BN[bi])
            ax.axhline(ref[bi], ls=":", color=ax.lines[-1].get_color(), alpha=0.5)
    ax.set_xlabel("RITE lag τ (ps)"); ax.set_ylabel(r"v6 $\Delta\Delta F_B$ (kT)")
    ax.set_xticks(LAGS); ax.set_title("Per-basin ΔΔF vs RITE lag (dotted = REMD ref)")
    ax.legend(fontsize=8, title="basin")
    fig.tight_layout(); fig.savefig(str(PLOTS / "lag_dependence_ddF.png"), dpi=140); plt.close(fig)
    print(f"\n  Saved lag_dependence.csv + 2 plots -> {OUT.relative_to(ROOT)}")
    print(tbl.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
