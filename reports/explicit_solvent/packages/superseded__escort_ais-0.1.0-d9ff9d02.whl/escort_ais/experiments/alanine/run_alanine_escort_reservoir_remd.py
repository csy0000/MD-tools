"""run_alanine_escort_reservoir_remd.py — Escort Reservoir Replica Exchange for alanine dipeptide.

Implements the Roitberg Reservoir REMD where:
  - The hot replica is frozen (no dynamics), replaced by a pre-generated Boltzmann
    reservoir at H_hot = U_{s=0.8} + u₁ (softcap d2.0, γ12).
  - Live replicas (N−1) are distributed along the escort path from H_hot → U₀.
  - Ladder placement: equal thermodynamic length derived from existing AIS work data.

Workflow
--------
  1. Load AIS work_timeseries.npy + alpha_schedule.npy from --ais-work-dir.
  2. Compute equal-thermodynamic-length ladder (n_replicas rungs).
  3. Load reservoir.dcd + reservoir_energies.npy from --reservoir-dir.
  4. Run Escort-RRE via reservoir_remd.run_escort_reservoir_remd.

Usage
-----
  # Emit the .sh wrapper first (convention), then run:
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_escort_reservoir_remd \\
      --ais-work-dir data/alanine_dipeptide/gmm_escort/2026-06-11-gmm-escort-softcap-d2p0-g12p0-ais \\
      --reservoir-dir data/alanine_dipeptide/md/2026-06-11-escort-reservoir-s0p8-softcap-d2g12-md \\
      --topology-dir data/topology/ff19sb_gbn2_even \\
      --output-dir data/alanine_dipeptide/md/2026-06-11-escort-reservoir-remd-4rep \\
      --duration-ns 250 --n-replicas 4 --platform OpenCL

  # Dry run (resolve paths and print ladder; no MD)
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_escort_reservoir_remd \\
      --ais-work-dir ... --reservoir-dir ... --topology-dir ... \\
      --duration-ns 1 --dry-run

  # 1 ps smoke test
  conda run -n openmm python -m escort_ais.experiments.alanine.run_alanine_escort_reservoir_remd \\
      --ais-work-dir ... --reservoir-dir ... --topology-dir ... \\
      --output-dir data/alanine_dipeptide/md/test_escort_remd_smoke \\
      --duration-ns 0.001 --platform CPU --exchange-interval-ps 0.002
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


import numpy as np

# Default paths
from escort_ais.common.paths import project_root
_REPO_ROOT = project_root()
_AIS_WORK_DIR_DEFAULT = (
    _REPO_ROOT / "data" / "alanine_dipeptide" / "gmm_escort"
    / "2026-06-11-gmm-escort-softcap-d2p0-g12p0-ais"
)
_RESERVOIR_DIR_DEFAULT = (
    _REPO_ROOT / "data" / "alanine_dipeptide" / "md"
    / "2026-06-11-escort-reservoir-s0p8-softcap-d2g12-md"
)
_TOPOLOGY_DIR_DEFAULT = _REPO_ROOT / "data" / "topology" / "ff19sb_gbn2_even"
_OUTPUT_DIR_DEFAULT = (
    _REPO_ROOT / "data" / "alanine_dipeptide" / "md"
    / "2026-06-11-escort-reservoir-remd-4rep"
)


def _parse_args(argv=None):
    p = argparse.ArgumentParser(description="Escort Reservoir Replica Exchange for alanine dipeptide")
    p.add_argument("--ais-work-dir", default=str(_AIS_WORK_DIR_DEFAULT),
                   help="Dir with work_timeseries.npy + alpha_schedule.npy from escort AIS")
    p.add_argument("--reservoir-dir", default=str(_RESERVOIR_DIR_DEFAULT),
                   help="Dir with reservoir.dcd + reservoir_energies.npy")
    p.add_argument("--topology-dir", default=str(_TOPOLOGY_DIR_DEFAULT),
                   help="build_topology output dir (prmtop/inpcrd/config.json)")
    p.add_argument("--output-dir", default=str(_OUTPUT_DIR_DEFAULT),
                   help="Where to write all outputs")
    p.add_argument("--n-replicas", type=int, default=4,
                   help="Total replicas including the frozen reservoir (default 4)")
    p.add_argument("--s-mid", type=float, default=0.8,
                   help="Hot-end REST2 scale (default 0.8)")
    p.add_argument("--duration-ns", type=float, default=250.0,
                   help="Production length in ns (default 250 to match baseline)")
    p.add_argument("--exchange-interval-ps", type=float, default=1.0)
    p.add_argument("--timestep-fs", type=float, default=2.0)
    p.add_argument("--traj-interval-ps", type=float, default=10.0)
    p.add_argument("--checkpoint-interval-ps", type=float, default=100.0)
    p.add_argument("--temperature-k", type=float, default=300.0)
    p.add_argument("--friction-per-ps", type=float, default=1.0)
    p.add_argument("--minimize-steps", type=int, default=10_000)
    p.add_argument("--equilibration-ps", type=float, default=100.0)
    p.add_argument("--u1-variant", default="softcap",
                   choices=["log", "log1p", "capped", "softcap"])
    p.add_argument("--u1-target-depth-kt", type=float, default=2.0)
    p.add_argument("--u1-cap-sharpness", type=float, default=12.0)
    p.add_argument("--platform", default=None,
                   help="OpenMM platform (CUDA/OpenCL/CPU). Auto-selects if omitted.")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--ladder", default=None,
                   help="Path to a pre-built escort_ladder.json (skips ladder derivation)")
    p.add_argument("--dry-run", action="store_true",
                   help="Print ladder and paths; do not start MD")
    return p.parse_args(argv)


def _emit_sh_wrapper(output_dir: Path, argv_repr: str) -> None:
    """Write a .sh wrapper so the run is reproducible from the command line."""
    sh_path = output_dir / "run_escort_reservoir_remd.sh"
    sh_path.write_text(
        "#!/bin/bash\n"
        "# Auto-generated by run_alanine_escort_reservoir_remd.py\n"
        "set -euo pipefail\n"
        "REPO_ROOT=\"$(cd \"$(dirname \"${BASH_SOURCE[0]}\")/../..\" && pwd)\"\n"
        f"PYTHONPATH=\"$REPO_ROOT/src\" conda run -n openmm python "
        f"\"$REPO_ROOT/src/escort_ais/experiments/alanine/run_alanine_escort_reservoir_remd.py\" \\\n"
        f"  {argv_repr}\n",
        encoding="utf-8",
    )
    sh_path.chmod(0o755)
    print(f"Wrapper written: {sh_path}")


def main(argv=None):
    args = _parse_args(argv)

    ais_work_dir = Path(args.ais_work_dir)
    reservoir_dir = Path(args.reservoir_dir)
    topology_dir = Path(args.topology_dir)
    output_dir = Path(args.output_dir)

    # ── validate inputs ───────────────────────────────────────────────────────
    if not ais_work_dir.exists():
        print(f"ERROR: AIS work dir not found: {ais_work_dir}", file=sys.stderr)
        sys.exit(1)
    if not topology_dir.exists():
        print(f"ERROR: topology dir not found: {topology_dir}", file=sys.stderr)
        sys.exit(1)

    # ── build or load ladder ──────────────────────────────────────────────────
    if args.ladder:
        ladder_path = Path(args.ladder)
        print(f"Loading pre-built ladder from {ladder_path}")
        ladder = json.loads(ladder_path.read_text(encoding="utf-8"))
    else:
        work_path = ais_work_dir / "work_timeseries.npy"
        alpha_path = ais_work_dir / "alpha_schedule.npy"
        if not work_path.exists():
            print(f"ERROR: work_timeseries.npy not found in {ais_work_dir}", file=sys.stderr)
            sys.exit(1)
        if not alpha_path.exists():
            print(f"ERROR: alpha_schedule.npy not found in {ais_work_dir}", file=sys.stderr)
            sys.exit(1)

        work_ts = np.load(str(work_path))
        alpha_sched = np.load(str(alpha_path))
        print(f"Loaded work_timeseries: shape {work_ts.shape}")
        print(f"Loaded alpha_schedule:  shape {alpha_sched.shape}, "
              f"range [{alpha_sched.min():.3f}, {alpha_sched.max():.3f}]")

        from escort_ais.methods.reservoir_remd import escort_ladder_from_work  # noqa: PLC0415
        ladder = escort_ladder_from_work(work_ts, alpha_sched, args.n_replicas, s_mid=args.s_mid)

    print("\nEscort ladder (descending s, replica 0 = physical U₀):")
    print(f"  {'rep':>3}  {'alpha':>6}  {'s':>6}  {'lambda_u1':>9}  {'T_eff [K]':>10}")
    for entry in ladder:
        print(f"  {entry['replica']:>3}  {entry['alpha']:>6.4f}  {entry['s']:>6.4f}"
              f"  {entry['lambda_u1']:>9.4f}  {entry['effective_temperature_k']:>10.2f}")
    print(f"\n  Note: replica {ladder[-1]['replica']} is the FROZEN reservoir "
          f"(s={ladder[-1]['s']:.4f}, λ={ladder[-1]['lambda_u1']:.4f})")

    # Validate reservoir dir
    if not args.dry_run:
        if not reservoir_dir.exists():
            print(f"ERROR: reservoir dir not found: {reservoir_dir}", file=sys.stderr)
            sys.exit(1)
        if not (reservoir_dir / "reservoir.dcd").exists():
            print(f"ERROR: reservoir.dcd not found in {reservoir_dir}", file=sys.stderr)
            sys.exit(1)
        if not (reservoir_dir / "reservoir_energies.npy").exists():
            print(f"ERROR: reservoir_energies.npy not found in {reservoir_dir}", file=sys.stderr)
            sys.exit(1)
        res_energies = np.load(str(reservoir_dir / "reservoir_energies.npy"))
        print(f"\nReservoir: {len(res_energies)} frames, "
              f"E_hot range [{res_energies.min():.1f}, {res_energies.max():.1f}] kJ/mol")

    if args.dry_run:
        print("\nDRY RUN: paths and ladder resolved. No MD started.")
        # Save the ladder even in dry-run for inspection
        output_dir.mkdir(parents=True, exist_ok=True)
        ladder_path = output_dir / "escort_ladder.json"
        ladder_path.write_text(json.dumps(ladder, indent=2) + "\n", encoding="utf-8")
        print(f"Ladder written to {ladder_path}")
        return

    # ── prepare output dir + .sh wrapper ─────────────────────────────────────
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save the ladder
    ladder_path = output_dir / "escort_ladder.json"
    ladder_path.write_text(json.dumps(ladder, indent=2) + "\n", encoding="utf-8")
    print(f"Ladder written to {ladder_path}")

    # Emit .sh wrapper
    argv_repr = " \\\n  ".join([
        f"--ais-work-dir {args.ais_work_dir}",
        f"--reservoir-dir {args.reservoir_dir}",
        f"--topology-dir {args.topology_dir}",
        f"--output-dir {args.output_dir}",
        f"--n-replicas {args.n_replicas}",
        f"--duration-ns {args.duration_ns}",
        f"--platform {args.platform or 'OpenCL'}",
        f"--seed {args.seed}",
    ])
    _emit_sh_wrapper(output_dir, argv_repr)

    # ── load GMM dir from AIS config ──────────────────────────────────────────
    ais_cfg_path = ais_work_dir / "config.json"
    ais_cfg = json.loads(ais_cfg_path.read_text(encoding="utf-8"))
    gmm_dir = Path(ais_cfg["gmm_dir"])
    print(f"\nGMM dir: {gmm_dir}")

    # ── run ──────────────────────────────────────────────────────────────────
    from escort_ais.methods.reservoir_remd import run_escort_reservoir_remd  # noqa: PLC0415

    print(f"\nStarting Escort-RRE: {len(ladder)} replicas ({len(ladder)-1} live), "
          f"{args.duration_ns} ns ...")

    summary = run_escort_reservoir_remd(
        topology_dir=topology_dir,
        gmm_dir=gmm_dir,
        reservoir_dir=reservoir_dir,
        ladder=ladder,
        duration_ns=args.duration_ns,
        output_dir=output_dir,
        temperature_k=args.temperature_k,
        exchange_interval_ps=args.exchange_interval_ps,
        timestep_fs=args.timestep_fs,
        platform=args.platform,
        seed=args.seed,
        friction_per_ps=args.friction_per_ps,
        minimize_steps=args.minimize_steps,
        equilibration_nvt_ps=args.equilibration_ps,
        traj_interval_ps=args.traj_interval_ps,
        checkpoint_interval_ps=args.checkpoint_interval_ps,
        u1_variant=args.u1_variant,
        u1_target_depth_kt=args.u1_target_depth_kt,
        u1_cap_sharpness=args.u1_cap_sharpness,
        s_mid=args.s_mid,
    )

    print("\n=== Summary ===")
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == "__main__":
    main()
    sys.exit(0)
