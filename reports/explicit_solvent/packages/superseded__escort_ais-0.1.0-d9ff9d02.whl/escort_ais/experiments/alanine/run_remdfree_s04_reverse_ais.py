#!/usr/bin/env python3
"""run_remdfree_s04_reverse_ais.py — reverse AIS for the REMD-free s=0.4 experiment.

Uses the FRESH kinetic basin model (results/remdfree_s04/basins). Reverse starts are
drawn UNIFORMLY within each basin (NO RITE) from the 20x100 ps cold-MD reservoir (drop
first 10 ps), with a total of 1000 trajectories allocated across basins in proportion
to the forward-AIS cold-endpoint landing ratio ("same ratio as hot->cold AIS"). Runs
reverse AIS (cold s=1.0 -> hot s=0.4, 2 ps switch).

Outputs -> results/remdfree_s04/:
  reverse_start_table.csv, reverse_ais_results.npz, reverse_start_diag.json
Usage:  TOP100W_EXP=remdfree_s04 \
          python -m escort_ais.experiments.alanine.run_remdfree_s04_reverse_ais --platform CUDA
"""
from __future__ import annotations

import argparse
import json
import pickle
import shutil
import sys
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais  # noqa: E402
from escort_ais.methods.kinetic_basin import assign_level1  # noqa: E402
from escort_ais.analysis.analyze_ala_msk_all_solvers import load_phi_psi_dcd  # noqa: E402
from escort_ais.common.top100w_cfg import FWD, RESULTS as OUT, RUNS, TOP_PDB, REVRUN as RUN_DIR  # noqa: E402

REMD_CFG = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_even_4rep_300K_remd_250ns/config.json"
BASINS = OUT / "basins"
N_SEEDS, BURN_FRAMES = 20, 10        # cold MD: 20 seeds, drop first 10 ps
N_REVERSE_TOTAL = 1000
T_AIS, FREQ = 1000, 10               # 2 ps switch
_CFG_KEYS = ["prmtop_path", "inpcrd_path", "topology_solvent", "timestep_fs",
             "friction_per_ps", "temperature_k", "solvent", "n_solute_atoms"]


def largest_remainder(weights, total):
    w = np.asarray(weights, float); w = w / w.sum()
    raw = w * total
    base = np.floor(raw).astype(int)
    rem = total - base.sum()
    for i in np.argsort(-(raw - base))[:rem]:
        base[i] += 1
    return base


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n-reverse-total", type=int, default=N_REVERSE_TOTAL)
    ap.add_argument("--basins", choices=["fresh", "production"], default="fresh",
                    help="fresh = PCCA+ model in RESULTS/basins; production = fixed 4-basin model "
                         "(for the i-sweep, a common coordinate across hot-MD budgets)")
    ap.add_argument("--platform", default="CUDA")
    args = ap.parse_args()
    rng = np.random.default_rng(20260617)
    RUN_DIR.mkdir(parents=True, exist_ok=True)

    if args.basins == "production":
        from escort_ais.analysis.analyze_ala_endpoint_partitioned import _assign  # production kmeans + microstate_to_basin
        from escort_ais.analysis.analyze_ala_msk_all_solvers import N_BASINS
        n_basins = N_BASINS
        assign = _assign
    else:
        with open(BASINS / "kmeans.pkl", "rb") as f:
            KM = pickle.load(f)
        M2B = np.load(BASINS / "microstate_to_basin.npy")
        n_basins = int(M2B.max()) + 1
        assign = lambda ph, ps: assign_level1(ph, ps, KM, M2B).astype(int)

    # cold-MD reservoir: frames + provenance + fresh-basin labels (drop first 10 ps)
    cold = {s: md.load_dcd(str(RUNS / f"seed_{s:03d}/trajectory.dcd"), top=str(TOP_PDB))
            for s in range(N_SEEDS)}
    res_xyz, res_basin, res_prov = [], [], []
    for s in range(N_SEEDS):
        ph, ps = load_phi_psi_dcd(RUNS / f"seed_{s:03d}/trajectory.dcd")
        b = assign(ph[BURN_FRAMES:], ps[BURN_FRAMES:])
        for k, mf in enumerate(range(BURN_FRAMES, cold[s].n_frames)):
            res_xyz.append(cold[s].xyz[mf]); res_basin.append(int(b[k])); res_prov.append((s, mf))
    res_basin = np.array(res_basin); res_prov = np.array(res_prov)
    res_xyz = np.array(res_xyz)
    reservoir_pop = np.bincount(res_basin, minlength=n_basins)

    # forward landing: forward-AIS cold endpoints assigned to fresh basins
    fph, fps = load_phi_psi_dcd(FWD / "ais_final_coordinates.dcd")
    land = np.bincount(assign(fph, fps), minlength=n_basins).astype(float)

    # allocate N_total reverse trajs proportional to forward landing, only over basins
    # that have both forward landing AND a cold reservoir to draw from
    usable = np.array([b for b in range(n_basins) if land[b] > 0 and reservoir_pop[b] > 0])
    alloc_u = largest_remainder(land[usable], args.n_reverse_total)
    n_for = {int(b): int(a) for b, a in zip(usable, alloc_u)}
    print(f"  fresh basins={n_basins} | reservoir_pop={reservoir_pop.tolist()} | "
          f"forward landing={land.astype(int).tolist()}")
    print(f"  reverse allocation (forward-ratio, uniform draws): {n_for}")

    xyz, rows, start_basin, diag = [], [], [], {}
    for B in usable:
        idx_B = np.where(res_basin == B)[0]
        pick = rng.choice(idx_B, n_for[int(B)], replace=True)     # UNIFORM within basin, no RITE
        uniq, counts = np.unique(pick, return_counts=True)
        diag[str(int(B))] = dict(n_reverse=n_for[int(B)], pool=int(len(idx_B)),
                                 n_unique=int(len(uniq)), max_dup=int(counts.max()))
        for p in pick:
            s, mf = int(res_prov[p, 0]), int(res_prov[p, 1])
            xyz.append(res_xyz[p]); start_basin.append(int(B))
            rows.append(dict(reverse_start_frame_id=len(rows), source_seed_simulation=s,
                             source_time_ps=mf, basin=int(B), weight=1.0 / len(idx_B)))
    pd.DataFrame(rows).to_csv(OUT / "reverse_start_table.csv", index=False)
    json.dump(diag, open(OUT / "reverse_start_diag.json", "w"), indent=2)
    start_basin = np.array(start_basin)
    print(f"  reverse starts: {len(rows)} total "
          f"({[int((start_basin == B).sum()) for B in usable]} per usable basin)")

    # build seed dir + run reverse AIS (cold 1.0 -> hot 0.4)
    seed_dir = RUN_DIR / "seed_cold_uniform"
    seed_dir.mkdir(parents=True, exist_ok=True)
    md.Trajectory(np.array(xyz), cold[0].topology).save_dcd(str(seed_dir / "trajectory.dcd"))
    shutil.copy2(TOP_PDB, seed_dir / "start_structure.pdb")
    cfg = json.loads(REMD_CFG.read_text())
    (seed_dir / "config.json").write_text(json.dumps({k: cfg[k] for k in _CFG_KEYS}, indent=2))

    out = RUN_DIR / "step_reverse_ais"
    print(f"  running reverse AIS: {len(xyz)} trajs, 2 ps (cold->hot) ...")
    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=len(xyz), t_ais=T_AIS, freq_ais=FREQ,
        s_hot=1.0, s_cold=0.4, seed=20260619,
        start_frame_offset=0, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=out,
        platform=args.platform, dry_run=False, overwrite=True, save_traj_every_switch=False))

    logw_r = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].values
    sel = pd.read_csv(out / "selected_initial_frames.csv")["initial_frame_index"].astype(int).values
    cold_start = start_basin[sel]
    phe, pse = load_phi_psi_dcd(out / "ais_final_coordinates.dcd")
    hot_end = assign(phe, pse)
    np.savez(OUT / "reverse_ais_results.npz", reverse_lnw=logw_r, reverse_work=-logw_r,
             reverse_cold_start_basin=cold_start, reverse_hot_end_basin=hot_end,
             reverse_endpoint_phi=phe, reverse_endpoint_psi=pse)
    print(f"  reverse AIS done: {len(logw_r)} trajs. cold-start counts="
          f"{np.bincount(cold_start, minlength=n_basins).tolist()}")
    print(f"  Saved -> {OUT.relative_to(ROOT)}/reverse_ais_results.npz")


if __name__ == "__main__":
    main()
