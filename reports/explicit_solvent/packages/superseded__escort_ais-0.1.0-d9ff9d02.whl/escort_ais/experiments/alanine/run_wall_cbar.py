"""Wall-stratified conditional BAR on alanine: both AIS endpoints confined, the wall annealed.

Normal cBAR switches an UNCONFINED hot state to a confined cold cell, so the reverse leg starts in
a cell whose hot-side counterpart is the whole hot ensemble. Traceback-stratified partitions the hot
state by the same geometry but leaves the hot walker unrestrained. Wall-stratified restrains BOTH
endpoints and anneals the wall along the switch::

    k(t) = (1 - sqrt(t)) * k_hot  +  sqrt(t) * k_cold

so the leg runs H_m (hot, soft wall) -> C_m (cold, production wall) inside one cell.

WHY A SOFT HOT WALL. ``k_hot`` is solved so that adjacent hot cells retain a BAR overlap
of 0.4 (``wall_stratified.solve_k_hot``, criterion='bar' since 2026-08-11 -- the older
Bhattacharyya target picked a systematically STIFFER wall and is kept only for re-analysis).
On alanine the Bhattacharyya target gave k_hot = 5.96 kT/rad^2 against the
production 100: overlap 0.400 versus 0.0104, a 38x improvement at the hot endpoint. A hot cell
walled at the production stiffness is effectively disjoint from its neighbour, which is what makes
the matched leg hard to solve.

ESTIMAND -- WINDOW TO WINDOW, three components::

    C_m - C_n = (C_m - H_m)  +  (H_m - H_n)  +  (H_n - C_n)
                \__ co-switch NES __/  \_ MBAR _/  \__ co-switch NES __/

* ``C_m - H_m`` and ``H_n - C_n``: bidirectional co-switch NES legs, solved by BAR. Each leg runs
  entirely inside one cell, from the walled hot window to the production cold cell.
* ``H_m - H_n``: MBAR ACROSS THE WALLED HOT WINDOWS, using the analytic wall energies.

  This is the step ``solve_k_hot`` exists for. Targeting a BAR overlap on the MST
  BOTTLENECK keeps the window graph CONNECTED, which is exactly MBAR's requirement -- with
  disjoint windows there is no path between the far cells. An earlier version of this driver
  obtained the hot term by reweighting the UNCONFINED hot ensemble instead; that is a different
  estimator, it needs no window overlap at all, and it made the 0.4 target look decorative.

A soft-wall-turn-on term ``f^H_m(k_hot) - f^H`` appears in neither: it cancels in the
window-to-window difference, which is the point of chaining through H_m rather than through the
unconfined hot state.

DEPARTURE FROM A SCIENTIFIC INVARIANT, APPROVED AND SCOPED. CLAUDE.md requires that the system
carrying AIS work contain no restraint. Here the wall IS part of the Hamiltonian along the switch --
that is the method. The invariant continues to hold unchanged for normal and traceback-stratified
cBAR. What makes this safe rather than a silent redefinition is that ``k(1) = k_cold`` exactly, so
the cold endpoint is the SAME confined ensemble the production estimator uses; the annealing changes
the path, not the target. See docs/decisions/2026-08-10_wall-stratified-restraint-in-work.md.

STATUS. The estimator, the hot-term reweighting and the wall construction are implemented and
checked here. Executing the annealed leg needs the AIS engine to ramp a flat-bottom wall the way it
already ramps a von-Mises umbrella; ``--check`` runs everything except that and reports what the
legs would be, so the design is verifiable before any GPU time is spent.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root

ROOT = project_root()
S_HOT, S_COLD = 0.25, 1.0


def hot_wall_turn_on(angles_rad, cells, k_hot: float) -> np.ndarray:
    """``f^H_m(k_hot) - f^H``: turning the soft wall ON in the unconfined hot state.

    DIAGNOSTIC ONLY. It is NOT the ``H_m - H_n`` term of the window-to-window identity -- that one
    comes from MBAR across the walled hot windows (``wall_stratified.hot_window_mbar``). Kept
    because it says how much unconfined hot weight each window retains, which is a useful check on
    whether a window is reachable at all, and because conflating the two is the mistake this
    docstring exists to prevent.
    """
    from escort_ais.methods.nd_flatbottom import nd_bias_kT
    from escort_ais.methods.wall_stratified import as_nd_cells
    nd = as_nd_cells(cells)
    lz = np.array([logsumexp(-nd_bias_kT(angles_rad, c, k_hot)) for c in nd])
    return -(lz - lz[0])


def hot_term_ess(angles_rad, cells, k_hot: float) -> np.ndarray:
    """Kish ESS of each cell's reweighting, the diagnostic that says whether the hot term is real."""
    from escort_ais.methods.nd_flatbottom import nd_bias_kT
    from escort_ais.methods.wall_stratified import as_nd_cells
    out = []
    for c in as_nd_cells(cells):
        lw = -nd_bias_kT(angles_rad, c, k_hot)
        ln = lw - logsumexp(lw)
        out.append(float(np.exp(-logsumexp(2.0 * ln))))
    return np.array(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--partition", type=Path,
                    default=ROOT / "reports/alanine/conditional_bar/campaign_v8/basin_tree.json")
    ap.add_argument("--hot-seed-dir", type=Path,
                    default=ROOT / "data/alanine_dipeptide/prep_v8_bank_g002_g012/prep_g012_hotseed",
                    help="hot frames collected between the burn-in generation and G_PREP; these "
                         "design the wall and supply the hot-term reweighting")
    ap.add_argument("--target-overlap", type=float, default=0.4,
                    help="BAR overlap the hot wall is solved to (2026-08-11 onward)")
    ap.add_argument("--overlap-criterion", default="bar", choices=("bar", "omega"))
    ap.add_argument("--k-cold", type=float, default=100.0)
    ap.add_argument("--n-ais", type=int, default=100)
    ap.add_argument("--generations", type=int, default=3)
    ap.add_argument("--window-ps", type=float, default=1000.0,
                    help="MD per umbrella window per generation = T_gen. Default 1000 ps to match "
                         "the T_gen every other arm uses; the protocol cost is then "
                         "4 windows x (1.0 ns + 100 legs x 1 ps) = 4.4 ns per generation, i.e. "
                         "1.33x normal cBAR. An earlier run used 20 ps here -- 9.2x cheaper, with "
                         "windows that never equilibrated (B1 leaked to 0%% occupancy and the "
                         "MBAR hot term wandered 1.40-3.13 kT). Do not lower this to buy "
                         "generations; it buys unconverged ones.")
    ap.add_argument("--t-ais", type=int, default=500, help="switch length in steps x 2 fs")
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--devices", default=None,
                    help="comma-separated GPU indices for the AIS shots")
    ap.add_argument("--hot-only", action="store_true",
                    help="advance ONLY the walled hot windows and report f^H_m - f^H_0 by MBAR: "
                         "no cold windows are built and no switching legs are fired. Isolates the "
                         "hot term, which on cilengitide came out +0.203 kT from REMD under the "
                         "retired Bhattacharyya wall. Output of such a run is NOT a wall-cBAR "
                         "result and must not be pooled with one.")
    ap.add_argument("--check", action="store_true",
                    help="design and verify only; run no legs and touch no GPU")
    ap.add_argument("--out", type=Path,
                    default=ROOT / "data/alanine_dipeptide/wall_cbar_v8")
    a = ap.parse_args(argv)
    a.devices = [int(x) for x in a.devices.split(",")] if a.devices else None

    import mdtraj as md
    from escort_ais.methods import wall_stratified as WS
    from escort_ais.methods.barrier_partition import partition_from_dict
    from escort_ais.methods.nd_flatbottom import nd_bias_kT
    from escort_ais.systems.cv_definition import load_cv_definition

    cells = partition_from_dict(json.loads(a.partition.read_text()))
    labels = [c.label for c in cells]
    cv = load_cv_definition("alanine_dipeptide")
    t = md.load_dcd(str(a.hot_seed_dir / "trajectory.dcd"),
                    top=str(a.hot_seed_dir / "start_structure.pdb"))
    ang = cv.compute(t)
    print(f"[design] {len(ang)} hot frames from {a.hot_seed_dir.name}; cells {labels}")

    sol = WS.solve_k_hot(ang, cells, target_overlap=a.target_overlap,
                         criterion=a.overlap_criterion)
    k_hot = float(sol.get("k_hot", sol.get("k")))
    om_hot = WS.omega_matrix(ang, cells, k_hot)
    om_cold = WS.omega_matrix(ang, cells, a.k_cold)
    print(f"[design] k_hot = {k_hot:.3f} kT/rad^2  "
          f"(criterion {sol['criterion']}, target {sol['target']:.2f}, "
          f"bottleneck {sol['bottleneck']:.4f})")
    print(f"[design] Omega hot  {om_hot[0, 1]:.4f}   Omega cold {om_cold[0, 1]:.4f}   "
          f"gain {om_hot[0, 1] / max(om_cold[0, 1], 1e-12):.0f}x")
    print(f"[design] anneal k(t) = {WS.sqrt_wall_schedule(k_hot, a.k_cold)}")

    # --- the wall must be EXACTLY the production wall at t = 1 -------------------------------
    nd = WS.as_nd_cells(cells)
    u_end = nd_bias_kT(ang, nd[0], k_hot + (a.k_cold - k_hot) * 1.0)
    u_prod = nd_bias_kT(ang, nd[0], a.k_cold)
    same = np.allclose(u_end, u_prod, atol=1e-12)
    print(f"[check ] k(t=1) reproduces the production wall exactly: {same}")
    if not same:
        raise SystemExit("the annealed wall does not close onto the production wall at t=1; the "
                         "cold endpoint would not be the ensemble the campaign reports")

    ht = hot_wall_turn_on(ang, cells, k_hot)
    ess = hot_term_ess(ang, cells, k_hot)
    print(f"[diag  ] soft-wall turn-on f^H_m(k_hot) - f^H = {np.round(ht, 4).tolist()} kT "
          f"(DIAGNOSTIC, not the H_m-H_n term)")
    print(f"[hot   ] reweighting ESS per cell = {np.round(ess, 1).tolist()} of {len(ang)}")
    # the same quantity at the production stiffness, to show what the soft wall buys
    ht_cold = hot_wall_turn_on(ang, cells, a.k_cold)
    ess_cold = hot_term_ess(ang, cells, a.k_cold)
    print(f"[hot   ] at k_cold it would be {np.round(ht_cold, 4).tolist()} kT with ESS "
          f"{np.round(ess_cold, 1).tolist()}")

    design = dict(k_hot=k_hot, k_cold=a.k_cold,
                  overlap_criterion=sol["criterion"], overlap_target=sol["target"],
                  bar_overlap=sol["bar_overlap"], omega=sol["omega"],
                  omega_hot=om_hot.tolist(), omega_cold=om_cold.tolist(),
                  schedule=WS.sqrt_wall_schedule(k_hot, a.k_cold),
                  hot_wall_turn_on_kT=ht.tolist(), hot_term_ess=ess.tolist(),
                  hot_wall_turn_on_kT_at_k_cold=ht_cold.tolist(), hot_term_ess_at_k_cold=ess_cold.tolist(),
                  cells=labels, n_hot_frames=int(len(ang)),
                  hot_seed_dir=str(a.hot_seed_dir), partition=str(a.partition),
                  alchemical_functions={c.label: WS.wall_alchemical_functions(
                      nd[i], k_hot, 1.0, a.k_cold) for i, c in enumerate(cells)})
    a.out.mkdir(parents=True, exist_ok=True)
    (a.out / "wall_design.json").write_text(json.dumps(design, indent=2) + "\n")
    print(f"\nwrote {a.out}/wall_design.json")

    if a.check:
        print(f"\n[check ] would run {a.generations} generations x {a.n_ais} legs per cell, "
              f"both directions, s {S_HOT} <-> {S_COLD} with the wall annealed alongside")
        print("[check ] no legs run, no GPU touched")
        return 0

    # ---- confined hot windows H_m ---------------------------------------------------------
    # These did not exist before and are the fix: the legs for cell m MUST start from H_m. Seeding
    # from the unconfined hot ensemble put 94% of B1's legs outside B1, so the switch measured the
    # cost of dragging a configuration across the barrier (27 kT dissipation) instead of the free
    # energy difference.
    import mdtraj as _md
    from escort_ais.methods import condbar_walkers as CW
    from escort_ais.methods.run_bais_standalone import _ais_leg

    topo = ROOT / "data/alanine_dipeptide/topology"
    tpdb = a.hot_seed_dir / "start_structure.pdb"
    ref = _md.load(str(tpdb))
    quartets = np.vstack([_md.compute_phi(ref)[0][0], _md.compute_psi(ref)[0][0]])
    kT_kj = 2.4943387854
    seed_cfg = json.loads((a.hot_seed_dir / "config.json").read_text())
    lab_all = np.array([np.argmax([c.contains(x[0], x[1]) for c in cells]) for x in ang])

    a.out.mkdir(parents=True, exist_ok=True)
    hot_w, hot_samples = [], []
    for m, lab in enumerate(labels):
        inside = np.flatnonzero(lab_all == m)
        if inside.size == 0:
            raise SystemExit(f"no hot frame lies in {lab}; cannot start its window")
        w = WS.make_hot_walled_walker(t.xyz[inside[0]], cells[m], k_hot, S_HOT,
                                      seed=4200 + 13 * m, platform_name=a.platform,
                                      device=(str(a.devices[0]) if a.devices else None))
        hot_w.append(w)
        print(f"[window] H_{lab} built at k_hot={k_hot:.3f}, seeded from a frame inside {lab}",
              flush=True)

    # cold windows C_m: the production wall at k_cold. Reverse legs seed from these, unfiltered --
    # C_m is defined WITH its wall, so every frame is a legitimate C_m sample.
    cold_w = []
    if a.hot_only:
        print("[hot-only] cold windows NOT built and no legs will be fired; this run measures "
              "f^H_m - f^H_0 alone", flush=True)
    else:
        for m, lab in enumerate(labels):
            inside = np.flatnonzero(lab_all == m)
            cw = CW.make_box_walker(t.xyz[inside[0]], cells[m], seed=7700 + 13 * m,
                                    platform_name=a.platform,
                                    device=(str(a.devices[0]) if a.devices else None))
            cold_w.append(cw)
            print(f"[window] C_{lab} built at k_cold={a.k_cold:g}", flush=True)

    rows = []
    for g in range(1, a.generations + 1):
        # advance each hot window, collect its samples for MBAR and its leg seeds
        gen_samples = []
        for m, lab in enumerate(labels):
            fr = hot_w[m].advance(a.window_ps)
            gen_samples.append(fr)
            hot_samples.append((m, cv.compute(_md.Trajectory(fr, ref.topology))))
        by_cell = [np.concatenate([x for mm, x in hot_samples if mm == m]) for m in range(len(labels))]
        f_hot = WS.hot_window_mbar(by_cell, cells, k_hot)
        print(f"[gen {g}] MBAR over hot windows: f^H_m - f^H_0 = "
              f"{np.round(f_hot, 4).tolist()} kT  (n per window "
              f"{[len(x) for x in by_cell]})", flush=True)

        if a.hot_only:
            inbox = [float(np.mean([cells[m].contains(x[0], x[1])
                                    for x in cv.compute(_md.Trajectory(gen_samples[m],
                                                                       ref.topology))]))
                     for m in range(len(labels))]
            rows.append(dict(generation=g, f_hot_mbar=f_hot.tolist(),
                             n=[int(len(x)) for x in by_cell], inbox=inbox))
            (a.out / "hot_windows.json").write_text(json.dumps(rows, indent=2) + "\n")
            print(f"[gen {g}] in-box {[round(x, 3) for x in inbox]}", flush=True)
            continue

        for m, lab in enumerate(labels):
            fr = gen_samples[m]
            pick = np.random.default_rng(g * 17 + m).choice(
                len(fr), a.n_ais, replace=len(fr) < a.n_ais)
            sd = CW.write_seed_dir(a.out / f"g{g:02d}_{lab}_hotseed", fr[pick], seed_cfg, tpdb)
            cfg = dict(solvent="implicit", t_ais=a.t_ais, freq_ais=1, s_hot=S_HOT,
                       omega_exclude=None,
                       prmtop=topo / "system_scale_1p0.prmtop",
                       inpcrd=topo / "system_scale_1p0.inpcrd", neq_integrator=False,
                       wall_quartets=quartets, wall_cell=nd[m],
                       wall_k_hot=k_hot, wall_k_cold=a.k_cold, wall_kT_kj=kT_kj)
            Wf, _ = _ais_leg(sd, a.out / f"g{g:02d}_{lab}_fwd", cfg, a.n_ais, S_HOT, S_COLD,
                             a.platform, seed=90000 + 7 * g + m, devices=a.devices)
            Wf = np.asarray(Wf, float)
            # DESCRIPTIVE ONLY -- not a validity criterion, and NOT a filter.
            #
            # H_m is defined WITH its wall, so every frame the window walker produces is a
            # legitimate H_m sample, including frames in the wall region where U_m > 0. Seeds are
            # therefore drawn from the whole umbrella pool, unfiltered. That differs from normal
            # cBAR, whose reverse legs must seed from U_m == 0 frames only -- there the AIS system
            # carries no restraint, so the target is the HARD cell and wall-region frames would
            # bias it. Here the restraint is part of the Hamiltonian, so the walled ensemble IS
            # the target.
            #
            # The fraction is still printed because a window sitting mostly in its wall region is
            # worth seeing; it just is not a threshold anything is gated on.
            sa = cv.compute(_md.Trajectory(fr[pick], ref.topology))
            frac = float(np.mean([cells[m].contains(x[0], x[1]) for x in sa]))
            rows.append(dict(generation=g, cell=lab, n=int(len(Wf)),
                             W_mean=float(Wf.mean()), W_min=float(Wf.min()),
                             W_max=float(Wf.max()), seed_in_cell=frac,
                             f_hot_mbar=f_hot.tolist(), finite=bool(np.isfinite(Wf).all())))
            # REVERSE leg C_m -> H_m. The engine ramps umbrella_lambda 1 -> 0 on a cold->hot leg,
            # so the same wall expression anneals k_cold -> k_hot without any extra plumbing.
            cfr = cold_w[m].advance(a.window_ps)
            cpick = np.random.default_rng(g * 31 + m).choice(
                len(cfr), a.n_ais, replace=len(cfr) < a.n_ais)
            csd = CW.write_seed_dir(a.out / f"g{g:02d}_{lab}_coldseed", cfr[cpick], seed_cfg, tpdb)
            Wr, _ = _ais_leg(csd, a.out / f"g{g:02d}_{lab}_rev", cfg, a.n_ais, S_COLD, S_HOT,
                             a.platform, seed=60000 + 7 * g + m, devices=a.devices)
            Wr = np.asarray(Wr, float)

            # BAR on the matched pair: forward H_m->C_m and reverse C_m->H_m of the SAME switch.
            # This is what forward-only Jarzynski cannot do at 5 kT dissipation.
            # solve_bar_with_infinite_works is the correct MLE (CLAUDE.md flags
            # reverse_ais_bar.bar_free_energy as WRONG -- it balances log-sigmoid sums instead).
            # No endpoint restriction here: every leg runs H_m <-> C_m inside one cell, so all
            # legs count and n_f_total/n_r_total are simply the leg counts.
            from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works
            try:
                # returns (DeltaF, converged) -- a bare float() on the tuple raises
                dF_, ok_ = solve_bar_with_infinite_works(Wf, Wr, len(Wf), len(Wr))
                dF = float(dF_) if ok_ else float("nan")
                if not ok_:
                    print(f"[gen {g}] {lab} BAR did not converge", flush=True)
            except Exception as exc:
                dF = float("nan")
                print(f"[gen {g}] {lab} BAR failed: {exc}", flush=True)
            rows[-1].update(n_rev=int(len(Wr)), W_rev_mean=float(Wr.mean()),
                            delta_bar=dF,
                            delta_jarzynski=float(-(logsumexp(-Wf) - np.log(len(Wf)))))
            print(f"[gen {g}] {lab} fwd: {len(Wf)} legs <W>={Wf.mean():+.3f}  "
                  f"rev: {len(Wr)} legs <W>={Wr.mean():+.3f}  "
                  f"BAR dF={dF:+.3f} kT  (Jarz {rows[-1]['delta_jarzynski']:+.3f})  "
                  f"seeds in hard cell {frac:.1%}", flush=True)
        (a.out / "wall_legs.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(f"\nwrote {a.out}/wall_legs.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
