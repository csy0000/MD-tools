"""Figures for the Disjoint-Substate Conditional BAR campaign report.

  fig1  landing density (raw vs AIS/HS-reweighted)
  fig2  the 3 kT box partition drawn on the AIS-weighted landing density
  fig3  forward and reverse work distributions for EVERY generation
  fig4  convergence of delta_m against the REMD reference
  fig5  reconstructed (phi, psi) PMF vs the REMD reference

CIRCULARITY NOTE (fig5).  The reverse legs are seeded by resampling REMD frames, so their
configurations are not independent of the reference.  Using them to build the within-box density
would smuggle the answer into the estimate.  The within-box densities therefore come from the
FORWARD multi-slice cloud only; the reverse legs enter solely through the conditional-BAR weights
pi_m.  The reconstruction is p(x) = sum_m pi_m p_m(x) -- conditional_bar.reconstruct_density.

Multi-slice reweighting follows Minh & Chodera, J. Chem. Phys. 134, 024111 (2011): configurations
recorded at intermediate time slices of a driven nonequilibrium process, weighted by the work
accumulated up to that slice, estimate the equilibrium ensemble at the corresponding lambda.  Here
the forward slices with s >= S_MIN are pooled, each weighted by exp(-w_t) (the Hummer-Szabo form),
which is the forward half of their bidirectional estimator.  The reverse half is deliberately
omitted for the circularity reason above, and that omission is stated in the report.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.methods.barrier_partition import assign_basins, partition_from_dict

ROOT = project_root()
CAMPAIGN = ROOT / "reports/legacy/alanine/20260729_campaign_v1"
DATA = ROOT / "data/alanine_dipeptide/condbar_campaign"
FIGS = CAMPAIGN / "figures"
S_MIN = 0.7
NBIN = 60
DELTA_F_REF = -48.18272933886123


def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.titlesize": 8, "figure.dpi": 200,
                         "savefig.bbox": "tight"})
    return plt


def _edges():
    return np.linspace(-180, 180, NBIN + 1)


def hist2d(phi_deg, psi_deg, weights=None):
    e = _edges()
    H, _, _ = np.histogram2d(phi_deg, psi_deg, bins=[e, e], weights=weights)
    return H / H.sum()


def pmf(H, floor_kT=8.0):
    """-ln p, referenced to the global minimum, with empty bins capped for display."""
    with np.errstate(divide="ignore"):
        F = -np.log(np.where(H > 0, H, np.nan))
    F -= np.nanmin(F)
    return np.where(np.isfinite(F), np.minimum(F, floor_kT), np.nan)


def forward_cloud(run_dir: Path, s_min: float = S_MIN):
    """Multi-slice forward cloud: torsions (deg) and Minh-Chodera/HS log-weights."""
    import pandas as pd
    hz = pd.read_parquet(Path(run_dir) / "merged/hz_observations.parquet")
    hz = hz[hz.s >= s_min]
    lw = -hz.cumulative_reduced_work.to_numpy(float)
    lw -= lw.max()
    # hz_observations stores phi/psi in DEGREES (unlike mdtraj, which returns radians).
    phi, psi = hz.phi.to_numpy(float), hz.psi.to_numpy(float)
    if max(np.abs(phi).max(), np.abs(psi).max()) <= 2 * np.pi:
        raise RuntimeError("hz phi/psi look like radians; the degree assumption is wrong")
    return phi, psi, np.exp(lw), hz.s.to_numpy(float)


def remd_reference():
    ref = np.load(CAMPAIGN / "cold_reference.npz")
    return np.degrees(ref["phi"]), np.degrees(ref["psi"]), ref["weights"], ref


def _boxes_deg(part):
    """Rectangles (in degrees) for drawing, splitting any wrapped interval into two pieces."""
    out = []
    for b in part:
        pi_, ps_ = b.phi_interval, b.psi_interval
        pl, pu = np.degrees(pi_.lower), np.degrees(pi_.upper)
        sl, su = np.degrees(ps_.lower), np.degrees(ps_.upper)
        ph = [(pl, pu)] if not pi_.wraps else [(pl, 180.0), (-180.0, pu)]
        ps = [(sl, su)] if not ps_.wraps else [(sl, 180.0), (-180.0, su)]
        if pi_.full:
            ph = [(-180.0, 180.0)]
        if ps_.full:
            ps = [(-180.0, 180.0)]
        for a in ph:
            for c in ps:
                out.append((b.basin_id, a, c))
    return out


def fig1_landing_density(part):
    plt = _mpl()
    phi, psi, w, s = forward_cloud(DATA / "mc_forward")
    fig, ax = plt.subplots(1, 3, figsize=(9.0, 2.7))
    e = _edges()
    for a, (H, t) in zip(ax, [(hist2d(phi, psi), "raw landing density (unweighted)"),
                              (hist2d(phi, psi, w), "AIS/HS-reweighted (cold estimate)")]):
        im = a.pcolormesh(e, e, pmf(H).T, cmap="viridis_r", vmin=0, vmax=8)
        a.set_title(t); a.set_xlabel(r"$\phi$ (deg)"); a.set_ylabel(r"$\psi$ (deg)")
        fig.colorbar(im, ax=a, label=r"$-\ln p$ ($k_BT$)")
    rp, rs, rw, _ = remd_reference()
    im = ax[2].pcolormesh(e, e, pmf(hist2d(rp, rs, rw)).T, cmap="viridis_r", vmin=0, vmax=8)
    ax[2].set_title("REMD reference (all replicas, MBAR)")
    ax[2].set_xlabel(r"$\phi$ (deg)"); ax[2].set_ylabel(r"$\psi$ (deg)")
    fig.colorbar(im, ax=ax[2], label=r"$-\ln p$ ($k_BT$)")
    for a in ax:
        a.set_xlim(-180, 180); a.set_ylim(-180, 180); a.set_aspect("equal")
    fig.savefig(FIGS / "fig1_landing_density.pdf")
    n_slices = len(np.unique(s))
    return dict(n_frames=int(len(phi)), n_slices=int(n_slices),
                ess=float(w.sum() ** 2 / np.sum(w ** 2)))


def fig2_boxes(part):
    plt = _mpl()
    from matplotlib.patches import Rectangle
    phi, psi, w, _ = forward_cloud(DATA / "mc_forward")
    e = _edges()
    fig, ax = plt.subplots(figsize=(4.2, 3.4))
    im = ax.pcolormesh(e, e, pmf(hist2d(phi, psi, w)).T, cmap="viridis_r", vmin=0, vmax=8)
    fig.colorbar(im, ax=ax, label=r"$-\ln p$ ($k_BT$)")
    cols = ["#e6194b", "#3cb44b", "#4363d8", "#f58231"]
    lab = assign_basins(np.radians(phi), np.radians(psi), part)
    mass = np.array([w[lab == m].sum() / w.sum() for m in range(len(part))])
    for bid, (p0, p1), (s0, s1) in _boxes_deg(part):
        ax.add_patch(Rectangle((p0, s0), p1 - p0, s1 - s0, fill=False,
                               ec=cols[bid % len(cols)], lw=1.6))
    for m in range(len(part)):
        ax.plot([], [], color=cols[m % len(cols)], lw=1.6,
                label=f"B{m}: AIS mass {mass[m]:.4f}")
    ax.legend(loc="upper right", fontsize=6, framealpha=0.9)
    ax.set_xlim(-180, 180); ax.set_ylim(-180, 180); ax.set_aspect("equal")
    ax.set_xlabel(r"$\phi$ (deg)"); ax.set_ylabel(r"$\psi$ (deg)")
    ax.set_title("3 kT box partition on the AIS-weighted landing density")
    fig.savefig(FIGS / "fig2_box_partition.pdf")
    return dict(ais_mass=mass.tolist())


def fig3_works(n_boxes):
    plt = _mpl()
    z = np.load(CAMPAIGN / "campaign_results_nf200.works.npz")
    gens = sorted({int(k.split("_g")[1].split("_")[0]) for k in z.files})
    gens = [g for g in gens if g >= 1]
    fig, axes = plt.subplots(len(gens), n_boxes, figsize=(2.5 * n_boxes, 1.5 * len(gens)),
                             sharex=True)
    for r, g in enumerate(gens):
        wf = z[f"forward_g{g}_-_b-1__work"]
        lab = z[f"forward_g{g}_-_b-1__labels"]
        for m in range(n_boxes):
            a = axes[r, m]
            f_in = wf[lab == m]
            wr = z.get(f"reverse_g{g}_equal_b{m}__work") if hasattr(z, "get") else None
            key = f"reverse_g{g}_equal_b{m}__work"
            wr = z[key] if key in z.files else np.array([])
            if len(f_in):
                a.hist(f_in, bins=18, density=True, alpha=0.6, color="#4363d8",
                       label=f"fwd landed ({len(f_in)})")
            if len(wr):
                a.hist(-wr, bins=18, density=True, alpha=0.6, color="#e6194b",
                       label=f"$-W^R$ ({len(wr)})")
            a.set_yticks([])
            if r == 0:
                a.set_title(f"B{m}")
            if m == 0:
                a.set_ylabel(f"gen {g}", fontsize=7)
            if r == 0 and m == n_boxes - 1:
                a.legend(fontsize=5, loc="upper right")
    for m in range(n_boxes):
        axes[-1, m].set_xlabel(r"reduced work ($k_BT$)", fontsize=7)
    fig.suptitle(r"Forward (landed) and reverse work distributions, every generation "
                 r"($N_F=200$, equal-reverse arm)", fontsize=9)
    fig.savefig(FIGS / "fig3_work_distributions.pdf")
    return dict(generations=gens)


def fig4_convergence():
    plt = _mpl()
    from scipy.special import logsumexp
    fig, axes = plt.subplots(2, 3, figsize=(9.5, 5.0), sharex=True)
    out = {}
    for row, tag in enumerate(("200", "800")):
        r = json.loads((CAMPAIGN / f"campaign_results_nf{tag}.json").read_text())
        ref = np.array(r["reference"]["delta"]); g = r["generations"][1:]
        gi = np.array([x["generation"] for x in g])
        series = {"landing": np.array([x["landing_delta"] for x in g]),
                  "equal": np.array([x["arms"]["equal"]["delta"] for x in g]),
                  "ratio": np.array([x["arms"]["ratio"]["delta"] for x in g])}
        for m in range(3):
            a = axes[row, m]
            a.axhline(ref[m], color="k", ls="--", lw=1.2, label="REMD reference")
            for nm, c in (("landing", "#999999"), ("equal", "#4363d8"), ("ratio", "#e6194b")):
                a.plot(gi, series[nm][:, m], "o-", ms=3, lw=1.1, color=c, label=nm)
                cum = np.cumsum(series[nm][:, m]) / np.arange(1, len(gi) + 1)
                a.plot(gi, cum, "-", lw=2.0, alpha=0.45, color=c)
            a.set_title(f"B{m}   " + r"$\delta_m^{\rm ref}$" + f" = {ref[m]:.3f}")
            if row == 1:
                a.set_xlabel("generation")
            if m == 0:
                a.set_ylabel(r"$\delta_m$ ($k_BT$)" + f"\n$N_F$ = {tag}")
            if row == 0 and m == 0:
                a.legend(fontsize=6)
        d = series["equal"]
        out[tag] = dict(delta_f_HC=float((-logsumexp(d, axis=1)).mean()))
    fig.suptitle(r"Convergence of $\delta_m = f_H - f_m$ against the REMD reference "
                 r"(thin: per generation, thick: running mean)", fontsize=9)
    fig.savefig(FIGS / "fig4_convergence.pdf")
    return out


def fig5_pmf(part):
    """PMF comparison.

    NOTE ON WHAT THIS FIGURE CAN AND CANNOT SHOW.  The reconstruction is
    sum_m pi_hat_m p_m with p_m the forward landing density restricted to box m and renormalised
    within it.  It therefore differs from the plain landing PMF by a PER-BOX CONSTANT factor
    pi_hat_m / mass_m and by nothing else: the shape inside each box is identical.  Those offsets
    are 0.006 / -0.074 / -0.215 kT here, under 3% of an 0-8 kT colour range, so side-by-side PMF
    panels necessarily look the same.  The bottom row therefore plots the signed errors against
    REMD and the box masses, which is where the estimator actually acts.
    """
    plt = _mpl()
    from escort_ais.methods.conditional_bar import reconstruct_density
    phi, psi, w, _ = forward_cloud(DATA / "mc_forward")
    lab = assign_basins(np.radians(phi), np.radians(psi), part)
    r = json.loads((CAMPAIGN / "campaign_results_nf800.json").read_text())
    g = r["generations"][1:]
    delta = np.array([x["arms"]["equal"]["delta"] for x in g]).mean(0)
    pi_hat = np.exp(delta - delta.max()); pi_hat /= pi_hat.sum()
    pi_ref = np.array(r["reference"]["pi"])

    dens, mass = {}, np.zeros(len(part))
    for m in range(len(part)):
        sel = lab == m
        mass[m] = w[sel].sum() / w.sum()
        dens[f"B{m}"] = hist2d(phi[sel], psi[sel], w[sel]).ravel()
    recon = reconstruct_density({f"B{m}": float(pi_hat[m]) for m in range(len(part))},
                                dens).reshape(NBIN, NBIN)
    landing = hist2d(phi, psi, w)
    rp, rs, rw, _ = remd_reference()
    ref = hist2d(rp, rs, rw)

    e = _edges()
    fig, ax = plt.subplots(2, 3, figsize=(10.5, 6.2))
    for a, (H, t) in zip(ax[0], [(landing, "AIS landing weights only"),
                                 (recon, r"conditional BAR  $\sum_m \hat\pi_m p_m$"),
                                 (ref, "REMD reference")]):
        im = a.pcolormesh(e, e, pmf(H).T, cmap="viridis_r", vmin=0, vmax=8)
        fig.colorbar(im, ax=a, label=r"$-\ln p$ ($k_BT$)")
        a.set_title(t, fontsize=8)
    for a, (H, t) in zip(ax[1], [(landing, "landing $-$ REMD"), (recon, "conditional BAR $-$ REMD")]):
        d = pmf(H) - pmf(ref)
        im = a.pcolormesh(e, e, d.T, cmap="RdBu_r", vmin=-2, vmax=2)
        fig.colorbar(im, ax=a, label=r"$\Delta(-\ln p)$ ($k_BT$)")
        a.set_title(t + f"   (RMSE {np.sqrt(np.nanmean(d**2)):.2f} $k_BT$)", fontsize=8)
    for a in ax.ravel()[:5]:
        a.set_xlim(-180, 180); a.set_ylim(-180, 180); a.set_aspect("equal")
        a.set_xlabel(r"$\phi$ (deg)"); a.set_ylabel(r"$\psi$ (deg)")

    b = ax[1, 2]
    x = np.arange(len(part)); wd = 0.27
    b.bar(x - wd, mass / pi_ref, wd, label="landing only", color="#999999")
    b.bar(x, pi_hat / pi_ref, wd, label="conditional BAR", color="#4363d8")
    b.axhline(1.0, color="k", ls="--", lw=1.0)
    b.set_xticks(x); b.set_xticklabels([f"B{m}" for m in range(len(part))])
    b.set_ylabel(r"box mass / REMD reference"); b.set_title("where the estimator acts", fontsize=8)
    b.legend(fontsize=6); b.set_aspect("auto")
    for m in range(len(part)):
        b.text(m - wd, mass[m] / pi_ref[m] + .02, f"{100*(mass[m]/pi_ref[m]-1):+.0f}%",
               ha="center", fontsize=5.5)
        b.text(m, pi_hat[m] / pi_ref[m] + .02, f"{100*(pi_hat[m]/pi_ref[m]-1):+.0f}%",
               ha="center", fontsize=5.5)
    fig.savefig(FIGS / "fig5_pmf.pdf")

    ok = (ref > 0) & (recon > 0)
    return dict(pi_hat=pi_hat.tolist(), pi_ref=pi_ref.tolist(), landing_mass=mass.tolist(),
                per_box_offset_kT=(-np.log(pi_hat / mass)).tolist(),
                tv_landing=float(0.5 * np.abs(landing - ref).sum()),
                tv_recon=float(0.5 * np.abs(recon - ref).sum()),
                rmse_pmf_landing=float(np.sqrt(np.mean((pmf(landing)[ok] - pmf(ref)[ok]) ** 2))),
                rmse_pmf_recon=float(np.sqrt(np.mean((pmf(recon)[ok] - pmf(ref)[ok]) ** 2))))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only", default="")
    args = ap.parse_args(argv)
    FIGS.mkdir(parents=True, exist_ok=True)
    part = partition_from_dict(json.loads((CAMPAIGN / "basin_tree.json").read_text()))
    stats = {}
    todo = args.only.split(",") if args.only else ["1", "2", "3", "4", "5"]
    if "1" in todo:
        stats["fig1"] = fig1_landing_density(part); print("fig1", stats["fig1"])
    if "2" in todo:
        stats["fig2"] = fig2_boxes(part); print("fig2", stats["fig2"])
    if "3" in todo:
        stats["fig3"] = fig3_works(len(part)); print("fig3 ok")
    if "4" in todo:
        stats["fig4"] = fig4_convergence(); print("fig4", stats["fig4"])
    if "5" in todo:
        stats["fig5"] = fig5_pmf(part); print("fig5", stats["fig5"])
    p = CAMPAIGN / "figure_stats.json"
    old = json.loads(p.read_text()) if p.exists() else {}
    old.update(stats)
    p.write_text(json.dumps(old, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
