#!/usr/bin/env python3
"""run_top100w_rite.py — Step 6: RITEWeight within each discovered basin, lag scan.

For each included basin, runs RITEWeight (rite_weight conda env, via
run_riteweight_step.py) on that basin's within-basin cold-MD frames at lags
tau = 2,5,10,20 ps, records ESS / weight-concentration diagnostics, and picks a
default lag for reverse sampling.  Basins with no transition pairs (e.g. all
single-frame visits) get uniform weights.

Outputs -> results/top100w_diverse20_100ps/rite/:
  basin{B}_tau{tau}/frame_weights.npy, rite_diagnostics.csv, rite_chosen.json
Usage:  python -m escort_ais.experiments.alanine.run_top100w_rite
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.top100w_cfg import RESULTS as OUT  # noqa: E402
RITE_IN = OUT / "rite_input"
RITE = OUT / "rite"
LAGS = [2, 5, 10, 20]
DEFAULT_LAG = 10
RITE_ENV = "rite_weight"
# Fixed average cluster SIZE (frames per microstate): N_clusters = N_frames / SIZE.
# Each microstate gets ~the same population across basins, instead of an arbitrary
# min(30, n//10) cap that over-clustered small basins.  Clipped to [CMIN, CMAX].
CLUSTER_SIZE = 30
CMIN, CMAX = 5, 40
RITE_TIMEOUT_S = 120        # safety net: at high lag the transition PAIRS (not frames)
                            # can go scarce -> rank-deficient solve -> hang -> uniform


def ess(w):
    w = np.asarray(w, float)
    return float(w.sum() ** 2 / np.sum(w ** 2)) if w.sum() > 0 else 0.0


def main():
    RITE.mkdir(parents=True, exist_ok=True)
    basins = sorted(int(p.name.split("_")[1]) for p in RITE_IN.glob("basin_*"))
    rows, chosen = [], {}
    for B in basins:
        d_in = RITE_IN / f"basin_{B}"
        phi = np.load(d_in / "phi_all.npy")
        bnds = np.load(d_in / "traj_boundaries.npy")
        seglen = np.diff(bnds)
        n = len(phi)
        per_lag_w = {}
        for tau in LAGS:
            pairs = int(np.maximum(0, seglen - tau).sum())
            out = RITE / f"basin_{B}_tau{tau}"
            out.mkdir(parents=True, exist_ok=True)
            if pairs < 1:
                w = np.full(n, 1.0 / n)               # uniform fallback (no transitions)
                np.save(out / "frame_weights.npy", w)
                note = "uniform-fallback(no-pairs)"
            else:
                # fixed average cluster size -> N_clusters = N_frames / CLUSTER_SIZE
                clusters = int(np.clip(round(n / CLUSTER_SIZE), CMIN, CMAX))
                cmd = ["conda", "run", "-n", RITE_ENV, "python",
                       "-m", "escort_ais.experiments.remd.run_riteweight_step",
                       "--phi-npy", str(d_in / "phi_all.npy"),
                       "--psi-npy", str(d_in / "psi_all.npy"),
                       "--boundaries-npy", str(d_in / "traj_boundaries.npy"),
                       "--output-dir", str(out), "--clusters", str(clusters),
                       "--iterations", "300", "--lag-frames", str(tau)]
                fw = out / "frame_weights.npy"
                try:
                    r = subprocess.run(cmd, capture_output=True, text=True, timeout=RITE_TIMEOUT_S)
                    if r.returncode == 0 and fw.exists():
                        w = np.load(fw); note = f"rite(c={clusters})"
                    else:
                        w = np.full(n, 1.0 / n); np.save(fw, w)
                        note = f"rite-failed->uniform ({r.stderr.strip().splitlines()[-1][:60] if r.stderr.strip() else ''})"
                except subprocess.TimeoutExpired:
                    w = np.full(n, 1.0 / n); np.save(fw, w)
                    note = f"rite-timeout({RITE_TIMEOUT_S}s)->uniform"
            per_lag_w[tau] = w
            wn = w / w.sum()
            rows.append(dict(basin=B, tau=tau, n_frames=n, n_segments=len(seglen),
                             pairs=pairs, ESS=round(ess(w), 1),
                             ESS_frac=round(ess(w) / n, 3),
                             w_max=float(wn.max()), w_median=float(np.median(wn)),
                             w_max_over_median=round(float(wn.max() / max(np.median(wn), 1e-12)), 1),
                             n_eff_unique=int((wn > 1e-6).sum()), note=note))
        # choose default lag: prefer DEFAULT_LAG unless its ESS_frac < 0.05; else best ESS
        sub = {tau: ess(per_lag_w[tau]) for tau in LAGS}
        pick = DEFAULT_LAG if sub[DEFAULT_LAG] / n >= 0.05 else max(sub, key=sub.get)
        chosen[str(B)] = dict(lag=pick, ESS=round(sub[pick], 1), ESS_frac=round(sub[pick] / n, 3),
                              uncertain=bool(sub[DEFAULT_LAG] / n < 0.05))
        np.save(RITE / f"basin_{B}_default.npy", per_lag_w[pick])
        print(f"  basin {B}: n={n} seg={len(seglen)} -> chosen lag={pick} ps "
              f"(ESS={sub[pick]:.0f}, {100*sub[pick]/n:.0f}%)")

    pd.DataFrame(rows).to_csv(RITE / "rite_diagnostics.csv", index=False)
    json.dump(chosen, open(RITE / "rite_chosen.json", "w"), indent=2)
    print(f"  Saved RITE weights + diagnostics -> {RITE.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
