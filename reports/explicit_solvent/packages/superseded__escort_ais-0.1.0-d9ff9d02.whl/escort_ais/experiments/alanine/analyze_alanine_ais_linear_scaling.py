#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import logsumexp

from escort_ais.methods.ais_linear import summarize_final_log_weights


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze alanine-dipeptide AIS linear scaling outputs.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("input_path", type=Path, help="AIS run directory or parent directory containing multiple run directories.")
    return parser.parse_args()


def discover_run_dirs(input_path: Path) -> list[Path]:
    if (input_path / "ais_metadata.json").exists():
        return [input_path]
    return sorted(path.parent for path in input_path.rglob("ais_metadata.json"))


def weighted_hist2d(phi_deg: np.ndarray, psi_deg: np.ndarray, weights: np.ndarray, bins: np.ndarray) -> np.ndarray:
    hist, _, _ = np.histogram2d(phi_deg, psi_deg, bins=[bins, bins], weights=weights)
    return hist


def analyze_run(run_dir: Path) -> dict[str, float | int | str]:
    work_samples = pd.read_csv(run_dir / "ais_work_samples.csv")
    trajectory_summary = pd.read_csv(run_dir / "ais_trajectory_summary.csv")
    metadata = json.loads((run_dir / "ais_metadata.json").read_text())

    final_logw = trajectory_summary["final_logw"].to_numpy(float)
    logw_norm = final_logw - logsumexp(final_logw)
    final_weights = np.exp(logw_norm)
    ess_summary = summarize_final_log_weights(final_logw)
    ess_summary.update({
        "run_dir": str(run_dir),
        "K_ais": int(metadata["K_ais"]),
        "T_ais": int(metadata["T_ais"]),
        "Freq_ais": int(metadata["Freq_ais"]),
        "M_ais": int(metadata["M_ais"]),
        "N_ais": int(metadata["N_ais"]),
    })

    plt.figure(figsize=(6, 4))
    plt.hist(final_logw, bins=40, color="#1f77b4", alpha=0.85)
    plt.xlabel("final log weight")
    plt.ylabel("count")
    plt.title("Final log-weight histogram")
    plt.tight_layout()
    plt.savefig(run_dir / "log_weight_histogram.png")
    plt.close()

    plt.figure(figsize=(6, 4))
    plt.hist(work_samples["delta_W"], bins=50, color="#d62728", alpha=0.85)
    plt.xlabel("delta W (kJ/mol)")
    plt.ylabel("count")
    plt.title("Work increment histogram")
    plt.tight_layout()
    plt.savefig(run_dir / "work_increment_histogram.png")
    plt.close()

    plt.figure(figsize=(8, 5))
    for traj_idx, frame in work_samples.groupby("ais_trajectory_index"):
        if int(traj_idx) >= 10:
            break
        subset = frame.sort_values("ais_interval_index")
        plt.plot(subset["ais_interval_index"], subset["cumulative_W"], alpha=0.8, label=f"traj {traj_idx}")
    plt.xlabel("AIS interval index")
    plt.ylabel("cumulative W (kJ/mol)")
    plt.title("Cumulative work examples")
    if trajectory_summary["ais_trajectory_index"].nunique() <= 10:
        plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(run_dir / "cumulative_work_examples.png")
    plt.close()

    plt.figure(figsize=(6, 5))
    plt.scatter(trajectory_summary["final_phi"], trajectory_summary["final_psi"], s=20 + 250 * final_weights, c=final_weights, cmap="viridis", alpha=0.85)
    plt.xlabel("phi (deg)")
    plt.ylabel("psi (deg)")
    plt.xlim(-180, 180)
    plt.ylim(-180, 180)
    plt.title("Final phi/psi scatter")
    plt.tight_layout()
    plt.savefig(run_dir / "phi_psi_final_scatter.png")
    plt.close()

    bins = np.linspace(-180.0, 180.0, 37)
    hist = weighted_hist2d(
        trajectory_summary["final_phi"].to_numpy(float),
        trajectory_summary["final_psi"].to_numpy(float),
        final_weights,
        bins,
    )
    plt.figure(figsize=(6, 5))
    plt.imshow(hist.T, origin="lower", extent=[-180, 180, -180, 180], aspect="auto", cmap="magma")
    plt.xlabel("phi (deg)")
    plt.ylabel("psi (deg)")
    plt.title("Weighted final phi/psi histogram")
    plt.tight_layout()
    plt.savefig(run_dir / "phi_psi_weighted_histogram.png")
    plt.close()

    (run_dir / "ess_summary.json").write_text(json.dumps(ess_summary, indent=2) + "\n", encoding="utf-8")
    return ess_summary


def main() -> None:
    args = parse_args()
    run_dirs = discover_run_dirs(args.input_path)
    if not run_dirs:
        raise FileNotFoundError(f"No AIS run directories found under {args.input_path}")
    summaries = [analyze_run(run_dir) for run_dir in run_dirs]
    summary_df = pd.DataFrame(summaries).sort_values(["K_ais", "T_ais", "Freq_ais"])
    print(summary_df.to_string(index=False))
    if len(summary_df) > 1:
        comparison_path = args.input_path / "ais_linear_scaling_comparison.csv"
        summary_df.to_csv(comparison_path, index=False)


if __name__ == "__main__":
    main()
