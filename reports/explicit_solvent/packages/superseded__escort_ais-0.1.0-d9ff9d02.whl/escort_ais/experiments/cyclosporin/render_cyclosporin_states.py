"""render_cyclosporin_states.py — PyMOL static renders of the aligned cyclosporin state medoids.

Run headless:  pymol -cq -r src/escort_ais/experiments/cyclosporin/render_cyclosporin_states.py
Produces results/cyclosporin/fig_states3d_{cold,hot}.png (overlay of the top aligned states,
backbone macrocycle as licorice coloured by state) for the PDF report. The medoid PDBs were
already superposed (on the backbone ring) by analyze_cyclosporin_three_sims.py.
"""
import glob
import os

from pymol import cmd

ROOT = os.environ.get("CSA_ROOT", "/home/chen0040/localhome/projects/escort-ais-alanine")
_T = os.environ.get("CSA_TORSION", "backbone")
OUT = os.path.join(ROOT, "results/cyclosporin") if _T == "backbone" else os.path.join(ROOT, "results/cyclosporin", _T)
COLORS = ["marine", "orange", "forest", "red", "purple", "teal", "yellow", "deepsalmon"]


def render(tag, n_max=5):
    cmd.reinitialize()
    pdbs = sorted(glob.glob(os.path.join(OUT, "states", f"{tag}_state*.pdb")))[:n_max]
    if not pdbs:
        print(f"  no PDBs for {tag}"); return
    for k, p in enumerate(pdbs):
        obj = f"{tag}_s{k}"
        cmd.load(p, obj)
        cmd.hide("everything", obj)
        cmd.remove(f"{obj} and hydro")
        cmd.show("sticks", obj)
        cmd.set_bond("stick_radius", 0.13, obj)
        cmd.color(COLORS[k % len(COLORS)], obj)
    cmd.bg_color("white")
    cmd.set("ray_opaque_background", 1)
    cmd.set("ray_shadows", 0)
    cmd.set("antialias", 2)
    cmd.orient()
    out = os.path.join(OUT, f"fig_states3d_{tag}.png")
    cmd.ray(1400, 1000)
    cmd.png(out, dpi=150)
    print(f"  rendered {len(pdbs)} aligned states -> {os.path.relpath(out, ROOT)}")

    # per-state small panels (one structure each) for a side-by-side strip
    for k, p in enumerate(pdbs):
        cmd.disable("all"); cmd.enable(f"{tag}_s{k}")
        cmd.orient(f"{tag}_s{k}")
        cmd.ray(700, 600)
        cmd.png(os.path.join(OUT, f"state_{tag}_{k}.png"), dpi=130)
    cmd.enable("all")


render("cold")
render("hot")
print("done")
