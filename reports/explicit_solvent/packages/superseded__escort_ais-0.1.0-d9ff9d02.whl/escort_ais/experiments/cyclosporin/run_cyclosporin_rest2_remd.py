#!/usr/bin/env python3
"""run_cyclosporin_rest2_remd.py — 8-replica REST2 REMD for cyclosporin (implicit GBn2).

REST2 scale ladder s = 1.0 -> 0.4 (minimal s=0.4), 8 replicas, 250 ns, implicit GBn2.
OMEGA-SELECTIVE: the 4 secondary-amide peptide-bond torsions are kept physical (not
scaled), while the 7 N-methyl tertiary amides (incl. the native cis MeLeu9-MeLeu10) are
scaled -- so the hot replicas enhance the relevant cis/trans isomerization without
artificially flipping ordinary peptide bonds.  Reads omega_exclude_bonds.npy.

Outputs -> data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns/
  replica_NN/{trajectory.dcd, state.csv}, exchange_attempts.csv, config.json
Usage:  python -m escort_ais.experiments.cyclosporin.run_cyclosporin_rest2_remd \
          [--duration-ns 250] [--platform CUDA]
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
import parmed as pmd
from parmed.tools import changeRadii

import openmm
from openmm import LangevinMiddleIntegrator, Platform, unit
from openmm.app import DCDReporter, GBn2, HBonds, NoCutoff, PDBFile, Simulation, StateDataReporter

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.openmm_system import BOLTZMANN_KJ_PER_MOL_K, build_rest2_scaled_system  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"
OUT = ROOT / "data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns"


def scale_ladder(s_min, n):
    """s = 1.0 -> s_min over n replicas, evenly spaced in sqrt-scale (REST2 convention).

    Took an unused ``base_t`` first argument until 2026-08-11: the ladder is defined by the SCALE
    range and the replica count alone, and the base temperature never entered it."""
    sqrt_s = np.linspace(1.0, math.sqrt(s_min), n)
    return (sqrt_s ** 2).tolist()


def sha256_of(path):
    """SHA-256 of a file, or None if it is absent. Inputs must be hashed, not merely named."""
    import hashlib
    q = Path(path)
    if not q.is_file():
        return None
    h = hashlib.sha256()
    with q.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def topology_provenance(topo_dir) -> dict:
    """What the TOPOLOGY says about itself, or explicit nulls.

    The driver hard-coded forcefield="sage", solvent="gbn2" and gb_model="GBn2" into config.json
    regardless of --topo-dir, so a run on any other topology recorded three claims it had never
    established. Metadata must not assert facts it cannot read.
    """
    topo = Path(topo_dir)
    out = dict(forcefield=None, solvent=None, gb_model=None, gb_radii=None,
               system_name=None, provenance_source=None)
    for cand in ("topology_config.json", "config.json", "manifest.json", "prep_config.json"):
        f = topo / cand
        if not f.is_file():
            continue
        try:
            d = json.loads(f.read_text())
        except Exception:
            continue
        for k in ("forcefield", "solvent", "gb_model", "gb_radii", "system_name"):
            if k in d:
                out[k] = d[k]
        out["provenance_source"] = str(f)
        break
    if out["system_name"] is None:
        out["system_name"] = topo.parent.name      # a directory name is a fact, not a claim
    return out


def seed_schedule(master_seed: int, n_replicas: int) -> dict:
    """Deterministic, collision-free seeds: per-replica integrator and velocity, plus exchange.

    OpenMM ignores setRandomNumberSeed once the Context exists, so the integrator seed must be set at
    construction. It must also not collide with the velocity seed: velocities used master + r, so
    deriving integrator seeds the same way would hand replica r+1's velocity stream to replica r's
    dynamics. Distinct offsets keep the three streams independent; OpenMM requires a positive int.
    """
    return dict(exchange=int(master_seed),
                velocity=[int(master_seed + r) for r in range(n_replicas)],
                integrator=[int(master_seed + 1_000_003 + 101 * r) for r in range(n_replicas)])


def exchange_pairs(n, phase):
    return [(i, i + 1) for i in range(phase % 2, n - 1, 2)]


def attempt_exchange(sim_i, sim_j, beta0, rng):
    si = sim_i.context.getState(getPositions=True, getVelocities=True, getEnergy=True)
    sj = sim_j.context.getState(getPositions=True, getVelocities=True, getEnergy=True)
    xi, xj = si.getPositions(asNumpy=True), sj.getPositions(asNumpy=True)
    vi, vj = si.getVelocities(asNumpy=True), sj.getVelocities(asNumpy=True)
    kj = unit.kilojoule_per_mole
    e_ii = si.getPotentialEnergy().value_in_unit(kj)
    e_jj = sj.getPotentialEnergy().value_in_unit(kj)
    sim_i.context.setPositions(xj)
    e_ij = sim_i.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(kj)
    sim_j.context.setPositions(xi)
    e_ji = sim_j.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(kj)
    delta = (e_ij + e_ji) - (e_ii + e_jj)
    accepted = (-beta0 * delta) >= 0.0 or math.log(rng.random()) < (-beta0 * delta)
    if accepted:
        sim_i.context.setVelocities(vj); sim_j.context.setVelocities(vi)
    else:
        sim_i.context.setPositions(xi); sim_j.context.setPositions(xj)
    return accepted


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--n-replicas", type=int, default=8)
    ap.add_argument("--s-min", type=float, default=0.4)
    ap.add_argument("--temperature-k", type=float, default=300.0)
    ap.add_argument("--duration-ns", type=float, default=250.0)
    ap.add_argument("--equilibration-ps", type=float, default=100.0)
    ap.add_argument("--exchange-interval-ps", type=float, default=1.0)
    ap.add_argument("--traj-interval-ps", type=float, default=10.0)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--friction-per-ps", type=float, default=1.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--seed", type=int, default=20260618)
    ap.add_argument("--devices", default="0",
                    help="comma-separated GPU device indices; replicas are round-robined across them")
    ap.add_argument("--topo-dir", default=str(TOPO), help="topology dir (default: cyclosporin)")
    ap.add_argument("--out-dir", default=str(OUT), help="output dir for the REMD ensembles")
    args = ap.parse_args()
    topo = Path(args.topo_dir)
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    # base implicit GBn2 system (mbondi3 radii required by GBn2)
    st = pmd.load_file(str(topo / "system_scale_1p0.prmtop"), xyz=str(topo / "system_scale_1p0.inpcrd"))
    changeRadii(st, "mbondi3").execute()
    base_system = st.createSystem(implicitSolvent=GBn2, nonbondedMethod=NoCutoff,
                                  constraints=HBonds, removeCMMotion=True)
    topology = st.topology
    n_atoms = topology.getNumAtoms()
    solute = np.arange(n_atoms)
    excl = np.load(topo / "omega_exclude_bonds.npy")
    scales = scale_ladder(args.s_min, args.n_replicas)
    eff_T = [args.temperature_k / s for s in scales]
    print(f"  {topo.parent.name} REST2 REMD: {args.n_replicas} replicas, s={[round(s,3) for s in scales]}")
    print(f"  omega-exclude (secondary amides): {excl.tolist()}  ({len(excl)} excluded)")

    plat = Platform.getPlatformByName(args.platform)
    devices = [d.strip() for d in str(args.devices).split(",") if d.strip() != ""]
    dev_key = {"CUDA": "DeviceIndex", "OpenCL": "OpenCLDeviceIndex"}.get(args.platform)
    print(f"  replicas round-robined across devices {devices} on {args.platform}")
    seeds = seed_schedule(args.seed, len(scales))
    sims = []
    for r, s in enumerate(scales):
        scaled = build_rest2_scaled_system(base_system, solute, s, exclude_central_bonds=excl)
        integ = LangevinMiddleIntegrator(args.temperature_k * unit.kelvin,
                                         args.friction_per_ps / unit.picosecond,
                                         args.timestep_fs * unit.femtoseconds)
        # BEFORE Simulation(): setRandomNumberSeed after the Context exists is ignored.
        integ.setRandomNumberSeed(seeds["integrator"][r])
        if dev_key:
            props = {"Precision": "mixed", dev_key: devices[r % len(devices)]}
        else:
            props = {}
        sim = Simulation(topology, scaled, integ, plat, props)
        sims.append(sim)

    steps = lambda ps: max(1, int(round(ps * 1000.0 / args.timestep_fs)))
    equil = steps(args.equilibration_ps)
    prod = steps(args.duration_ns * 1000.0)
    xchg = steps(args.exchange_interval_ps)
    traj = steps(args.traj_interval_ps)

    # minimize on replica 0, distribute positions
    sims[0].context.setPositions(st.positions)
    sims[0].minimizeEnergy()
    x0 = sims[0].context.getState(getPositions=True).getPositions()
    PDBFile.writeFile(topology, x0, open(out / "start_structure_minimized.pdb", "w"))
    for r, sim in enumerate(sims):
        rdir = out / f"replica_{r:02d}"; rdir.mkdir(exist_ok=True)
        sim.context.setPositions(x0)
        sim.context.setVelocitiesToTemperature(args.temperature_k * unit.kelvin,
                                              seeds["velocity"][r])
        # Reporters are NOT attached here; see after step_all(equil). Until 2026-08-11 they were,
        # so trajectory.dcd and state.csv carried equilibration while exchange_attempts.csv began at
        # production. Verified on the 1 us run: state.csv starts at step 5000 against a 50000-step
        # equilibration, while the exchange log starts at 50500 -- any analysis aligning frames to
        # exchange rounds by index was off by the equilibration length.

    prov = topology_provenance(topo)
    if prov["provenance_source"] is None:
        print(f"  WARNING: no topology provenance under {topo}; forcefield/solvent/"
              f"gb_model recorded as null rather than assumed", flush=True)
    (out / "config.json").write_text(json.dumps(dict(
        metadata_schema="cyclosporin_rest2_remd/2",
        system=prov["system_name"], forcefield=prov["forcefield"], solvent=prov["solvent"],
        topology_provenance_source=prov["provenance_source"], n_solute_atoms=n_atoms,
        n_replicas=args.n_replicas, temperature_k=args.temperature_k,
        rest2_scale_factors=scales, effective_temperatures_k=eff_T,
        omega_exclude_bonds=excl.tolist(), omega_selective=True,
        production_duration_ns=args.duration_ns, equilibration_ps=args.equilibration_ps,
        exchange_interval_ps=args.exchange_interval_ps, timestep_fs=args.timestep_fs,
        friction_per_ps=args.friction_per_ps, seed=args.seed,
        prmtop_path=str(topo / "system_scale_1p0.prmtop"), gb_model=prov["gb_model"],
        gb_radii=prov["gb_radii"], seeds=seeds,
        input_sha256={n: sha256_of(topo / n) for n in
                      ("system_scale_1p0.prmtop", "system_scale_1p0.inpcrd",
                       "omega_exclude_bonds.npy")},
    ), indent=2))

    beta0 = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * args.temperature_k)
    rng = np.random.default_rng(seeds["exchange"])
    print(f"  equilibrating {args.equilibration_ps} ps then {args.duration_ns} ns production "
          f"(exchange every {args.exchange_interval_ps} ps) ...")

    # Concurrent stepping: OpenMM releases the GIL inside step(), so replicas placed on different
    # devices run in parallel. This is a barrier (all replicas finish the block before exchanges).
    # Exchanges below stay single-threaded, so the algorithm is unchanged — only the per-block
    # integration is parallelized across GPUs.
    pool = ThreadPoolExecutor(max_workers=len(sims))

    def step_all(n):
        # materializing the map result is the barrier; any per-thread exception re-raises here
        list(pool.map(lambda s: s.step(n), sims))

    step_all(equil)

    # ---- PRODUCTION STARTS HERE. Reporters attach now, so frame 0 of trajectory.dcd/state.csv is
    # the first production frame and needs no offset to align with exchange_attempts.csv.
    production_start_step = int(sims[0].currentStep)
    for r, sim in enumerate(sims):
        rdir = out / f"replica_{r:02d}"
        sim.reporters.append(DCDReporter(str(rdir / "trajectory.dcd"), traj))
        sim.reporters.append(StateDataReporter(str(rdir / "state.csv"), traj, step=True, time=True,
                                               potentialEnergy=True, temperature=True, speed=True,
                                               progress=True, remainingTime=True, totalSteps=prod,
                                               separator=","))
    _cfg = json.loads((out / "config.json").read_text())
    _cfg.update(production_start_step=production_start_step,
                expected_production_frames=int(prod // traj),
                reporters_attached_after_equilibration=True)
    (out / "config.json").write_text(json.dumps(_cfg, indent=2))
    print(f"  equilibration done at step {production_start_step}; production reporters attached "
          f"({prod} steps, every {traj} -> {prod // traj} frames)", flush=True)

    try:
        with open(out / "exchange_attempts.csv", "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["step", "phase", "i", "j", "accepted"])
            remaining, phase, n_acc, n_att = prod, 0, 0, 0
            while remaining > 0:
                block = min(xchg, remaining)
                step_all(block)
                cur = sims[0].currentStep
                for i, j in exchange_pairs(args.n_replicas, phase):
                    acc = attempt_exchange(sims[i], sims[j], beta0, rng)
                    n_att += 1; n_acc += int(acc)
                    w.writerow([cur, phase, i, j, int(acc)])
                remaining -= block; phase += 1
                if phase % 50 == 0:
                    fh.flush()
        for r, sim in enumerate(sims):
            sim.saveState(str(out / f"replica_{r:02d}/final_state.xml"))
        disp = out.relative_to(ROOT) if out.resolve().is_relative_to(ROOT) else out
        print(f"  DONE. exchange acceptance = {n_acc}/{n_att} = {n_acc/max(1,n_att):.2%} -> {disp}")
    finally:
        # explicit shutdown on BOTH paths: a leaked executor keeps non-daemon threads alive
        # and the process hangs at exit instead of surfacing the error that killed the run.
        pool.shutdown(wait=True)


if __name__ == "__main__":
    main()
