#!/usr/bin/env python3
"""run_cyclosporin_remd_validation.py — validate AIS+BAR reweighting between the CONVERGED REMD ensembles.

Instead of single-walker seeds, this draws AIS endpoints directly from the demuxed 500 ns REST2-REMD
ensembles (state-indexed: replica_07 = s=0.4 HOT, replica_00 = s=1.0 COLD — verified: attempt_exchange
swaps coordinates between fixed-Hamiltonian contexts):

  forward AIS : k frames sampled from replica_07 (hot s=0.4) -> anneal s=0.4 -> 1.0  -> W_f
  reverse AIS : k frames from replica_00 (cold s=1.0), per-basin uniform, allocated by forward landing
                -> anneal s=1.0 -> 0.4  -> W_r

Then combined-BAR + hot-unified BAR on the fixed torsion-PCCA+ basins, compared to the REMD cold
reference ΔΔF (replica_00 populations). If AIS reweighting between the two converged REMD ensembles
REPRODUCES the REMD cold ΔΔF, the estimator is correct and the standard-protocol offset is attributable
to single-walker seed under-sampling. Same GBn2/mbondi3 + omega-selective Hamiltonian, switch 10 ps.

Output -> <out-dir>/{step_forward_ais/, reverse/, validation_summary.json}
Usage:
  python -m escort_ais.experiments.cyclosporin.run_cyclosporin_remd_validation \
      --k 1000 --switch-ps 10 --burn-ns 50 --platform CUDA \
      --out-dir data/cyclosporin/2026-06-23-remd-ensemble-validation
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.asymptotic_bar import Accumulator, RoundData, estimate  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel  # noqa: E402
from escort_ais.methods.ais_shard import run_sharded_ais  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"
TOP_PDB = TOPO / "topology.pdb"
OMEGA_PATH = TOPO / "omega_exclude_bonds.npy"
REMD = ROOT / "data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns"
NS_PER_FRAME = 0.01  # 10 ps/frame in the REMD trajectories


def load_remd_ensemble(replica: str, burn_frames: int) -> md.Trajectory:
    d = REMD / replica
    parts = [str(d / "trajectory.dcd")] + [str(p) for p in sorted(d.glob("trajectory_ext*.dcd"))]
    return md.load(parts, top=str(TOP_PDB))[burn_frames:]


def write_seed_dir(seed_dir: Path, traj: md.Trajectory, timestep_fs: float):
    seed_dir.mkdir(parents=True, exist_ok=True)
    traj.save_dcd(str(seed_dir / "trajectory.dcd"))
    shutil.copy2(TOP_PDB, seed_dir / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(TOPO / "system_scale_1p0.prmtop"),
                   inpcrd_path=str(TOPO / "system_scale_1p0.inpcrd"),
                   gb_model="GBn2", gb_radii="mbondi3", n_solute_atoms=196,
                   timestep_fs=timestep_fs, friction_per_ps=1.0, temperature_k=300.0,
                   solvent="implicit"),
              open(seed_dir / "config.json", "w"), indent=2)


def largest_remainder(weights, total):
    w = np.asarray(weights, float); w = w / w.sum()
    raw = w * total; base = np.floor(raw).astype(int)
    for i in np.argsort(-(raw - base))[: total - base.sum()]:
        base[i] += 1
    return base


def run_leg(seed_dir, out, k, s_hot, s_cold, switch_ps, n_shards, freq, platform, seed):
    # n_shards parallel processes (drop-in: output dir is shaped like a single AIS run)
    run_sharded_ais(seed_dir, out, k, s_hot, s_cold, switch_ps, n_shards,
                    omega_exclude=OMEGA_PATH, freq_ais=freq, platform=platform,
                    seed=seed, top_pdb=TOP_PDB)
    logw = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    sel = pd.read_csv(out / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    return logw, sel


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--k", type=int, default=1000)
    ap.add_argument("--switch-ps", type=float, default=10.0)
    ap.add_argument("--burn-ns", type=float, default=50.0, help="discard this much of each REMD ensemble")
    ap.add_argument("--basin-model", default=str(ROOT / "data/cyclosporin/basins/basin_model_backbone.pkl"))
    ap.add_argument("--freq-ais", type=int, default=10)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--n-shards", type=int, default=1, help="parallel AIS shards per leg (GPU time-slice)")
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--seed", type=int, default=20260623)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    model = BasinModel.load(Path(args.basin_model)); nb = model.n_basins
    burn = int(round(args.burn_ns / NS_PER_FRAME))

    # REMD cold reference ΔΔF (replica_00 populations on the fixed basins)
    cold = load_remd_ensemble("replica_00", burn)
    cold_basin = model.assign(cold)
    p = np.bincount(cold_basin, minlength=nb).astype(float); p /= p.sum()
    with np.errstate(divide="ignore"):
        ref = -np.log(p / p[0])
    print(f"REMD cold (replica_00) pop={np.round(p,3).tolist()} -> reference ΔΔF={np.round(ref,3).tolist()}")

    # ── forward: k hot frames from replica_07 -> AIS s=0.4 -> 1.0 ──
    hot = load_remd_ensemble("replica_07", burn)
    fpick = rng.choice(hot.n_frames, args.k, replace=args.k > hot.n_frames)
    fseed = out_dir / "seed_hot"; write_seed_dir(fseed, hot[fpick], args.timestep_fs)
    print(f"forward: {args.k} hot seeds from replica_07 ({hot.n_frames} frames) -> AIS 0.4->1.0 "
          f"({args.switch_ps} ps) ...")
    logw_f, sel_f = run_leg(fseed, out_dir / "step_forward_ais", args.k, 0.4, 1.0, args.switch_ps,
                            args.n_shards, args.freq_ais, args.platform, args.seed)
    W_f = -logw_f
    a_f = model.assign(hot[fpick])[sel_f]                                   # hot-START basin
    b_f = model.assign(md.load_dcd(str(out_dir / "step_forward_ais/ais_final_coordinates.dcd"),
                                   top=str(TOP_PDB)))                       # cold-END basin
    land = np.bincount(b_f, minlength=nb).astype(float)
    print(f"  forward done: W_f={W_f.mean():.1f}±{W_f.std():.1f} kJ/mol, cold-end landing={land.astype(int).tolist()}")

    # ── reverse: k cold frames from replica_00, per-basin uniform, allocated by forward landing ──
    usable = np.array([b for b in range(nb) if land[b] > 0 and (cold_basin == b).any()])
    alloc = largest_remainder(land[usable], args.k)
    rpick, b_r = [], []
    for B, n in zip(usable, alloc):
        idx = np.where(cold_basin == B)[0]
        sel = rng.choice(idx, int(n), replace=True)
        rpick.extend(sel.tolist()); b_r.extend([int(B)] * int(n))
    rpick = np.array(rpick); b_r = np.array(b_r)
    rseed = out_dir / "reverse/seed_cold"; write_seed_dir(rseed, cold[rpick], args.timestep_fs)
    print(f"reverse: {len(rpick)} cold seeds from replica_00 (alloc {dict(zip(usable.tolist(), alloc.tolist()))}) "
          f"-> AIS 1.0->0.4 ...")
    logw_r, sel_r = run_leg(rseed, out_dir / "reverse/step_reverse_ais", len(rpick), 1.0, 0.4,
                            args.switch_ps, args.n_shards, args.freq_ais, args.platform, args.seed + 1)
    W_r = -logw_r
    b_r = b_r[sel_r]                                                        # cold-START basin
    a_r = model.assign(md.load_dcd(str(out_dir / "reverse/step_reverse_ais/ais_final_coordinates.dcd"),
                                   top=str(TOP_PDB)))                       # hot-END basin
    print(f"  reverse done: W_r={W_r.mean():.1f}±{W_r.std():.1f} kJ/mol")

    # ── BAR estimate vs REMD cold reference ──
    acc = Accumulator(); acc.append(RoundData(W_f, a_f, b_f, W_r, b_r, a_r, hot_ns=float(hot.n_frames * NS_PER_FRAME)))
    res = estimate(acc, nb, reference_ddF=ref, bootstrap=True, n_bootstrap=400, rng=rng)
    summary = dict(
        k=args.k, switch_ps=args.switch_ps, burn_ns=args.burn_ns,
        remd_cold_pop=p.tolist(), reference_ddF=ref.tolist(),
        ddF_ais=res["ddF_ais"].tolist(),
        ddF_combined=res["ddF_combined"].tolist(), ddF_hotunified=res["ddF_hotunified"].tolist(),
        overlap=res["overlap"].tolist(), confidence=res["confidence"],
        rmse_combined=res.get("rmse_combined_covered"), rmse_hotunified=res.get("rmse_hotunified_covered"),
        W_f_mean=float(W_f.mean()), W_f_std=float(W_f.std()),
        W_r_mean=float(W_r.mean()), W_r_std=float(W_r.std()))
    json.dump(summary, open(out_dir / "validation_summary.json", "w"), indent=2)
    print("\n=== REMD-ENSEMBLE VALIDATION ===")
    print(f"  reference ΔΔF (REMD cold) = {np.round(ref,3).tolist()}")
    print(f"  AIS forward-only ΔΔF     = {np.round(res['ddF_ais'],3).tolist()}")
    print(f"  hot-unified BAR  ΔΔF     = {np.round(res['ddF_hotunified'],3).tolist()}")
    print(f"  overlap                   = {np.round(res['overlap'],2).tolist()}  conf={res['confidence']}")
    print(f"  RMSE: hot-unified={summary['rmse_hotunified']:.3f} kT")
    print(f"  -> {out_dir}/validation_summary.json")


if __name__ == "__main__":
    main()
