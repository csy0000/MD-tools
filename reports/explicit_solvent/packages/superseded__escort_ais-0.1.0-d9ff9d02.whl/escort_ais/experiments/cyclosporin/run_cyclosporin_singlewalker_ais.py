#!/usr/bin/env python3
"""run_cyclosporin_singlewalker_ais.py — the FULL single-walker AIS+BAR protocol (no REMD seeding).

The realistic production protocol, seeded only from the 1 us single-walker hot (s=0.4) reference:
  (1) randomly draw k=1000 hot configs from 20-1000 ns of the hot trajectory;
  (2) forward AIS hot->cold (s 0.4->1.0) at the chosen switch length;
  (3) of the 100 highest-weight cold endpoints, pick the 20 most distinct by macrocycle-backbone RMSD
      (farthest-point sampling);
  (4) run 1 ns cold MD (s=1.0) from each of the 20 -> cold reservoir;
  (5) reverse AIS cold->hot, reverse starts drawn per basin in proportion to the step-2 forward landing.
Then hot-unified BAR vs the 500 ns REMD cold reference. AIS legs are sharded (run_sharded_ais); cold MD
seeds run in a small parallel pool. This mirrors run_cyclosporin_remd_validation.py but with single-walker
seeds + a real cold-MD reservoir, to measure what the method achieves WITHOUT a REMD ensemble.

Output -> <out-dir>/{seed_hot/, step_forward_ais/, cold_md/seed_XXX/, reverse/, validation_summary.json}
Usage:  python -m escort_ais.experiments.cyclosporin.run_cyclosporin_singlewalker_ais \
          --switch-ps 20 --k 1000 --n-shards 4 --cold-parallel 8 --out-dir <dir>
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd
from openmm.app import PDBFile

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.asymptotic_bar import Accumulator, RoundData, estimate  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel, load_quartets  # noqa: E402
from escort_ais.methods.ais_shard import run_sharded_ais  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"
TOP_PDB = TOPO / "topology.pdb"
OMEGA_PATH = TOPO / "omega_exclude_bonds.npy"
HOT_REF = ROOT / "data/cyclosporin/2026-06-19-ref-singlewalker-hot-s0p4-1000ns/trajectory.dcd"
REMD = ROOT / "data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns"
NS_PER_FRAME = 0.01   # 10 ps/frame in the references


def write_seed_dir(seed_dir, traj):
    seed_dir.mkdir(parents=True, exist_ok=True)
    traj.save_dcd(str(seed_dir / "trajectory.dcd"))
    shutil.copy2(TOP_PDB, seed_dir / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(TOPO / "system_scale_1p0.prmtop"),
                   inpcrd_path=str(TOPO / "system_scale_1p0.inpcrd"),
                   gb_model="GBn2", gb_radii="mbondi3", n_solute_atoms=196,
                   timestep_fs=2.0, friction_per_ps=1.0, temperature_k=300.0, solvent="implicit"),
              open(seed_dir / "config.json", "w"), indent=2)


def leg(seed_dir, out, k, s_hot, s_cold, switch_ps, n_shards, seed):
    run_sharded_ais(seed_dir, out, k, s_hot, s_cold, switch_ps, n_shards,
                    omega_exclude=OMEGA_PATH, platform="CUDA", seed=seed, top_pdb=TOP_PDB)
    logw = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    sel = pd.read_csv(out / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    return logw, sel


def farthest_point_rmsd(traj, ring, n_pick, seed0):
    """Pick n_pick most distinct frames by macrocycle-backbone RMSD (farthest-point sampling)."""
    sel = [int(seed0)]
    dmin = md.rmsd(traj, traj, sel[0], atom_indices=ring)
    while len(sel) < min(n_pick, traj.n_frames):
        nxt = int(np.argmax(dmin))
        if nxt in sel:
            dmin[nxt] = -1; continue
        sel.append(nxt)
        dmin = np.minimum(dmin, md.rmsd(traj, traj, nxt, atom_indices=ring))
    return sel


def parallel_cold_md(seed_pdbs, cold_dir, prod_ps, cap):
    """Run len(seed_pdbs) cold-MD seeds via run_cold_md_seed.py, ≤cap concurrent."""
    cold_dir.mkdir(parents=True, exist_ok=True)
    env = {**os.environ, "PYTHONPATH": "src"}
    pending = list(enumerate(seed_pdbs)); running = []; failed = []
    while pending or running:
        while pending and len(running) < cap:
            sid, pdb = pending.pop(0)
            cmd = [sys.executable, "-m", "escort_ais.experiments.macrocycle.run_cold_md_seed",
                   "--seed-pdb", str(pdb), "--out-dir", str(cold_dir), "--sid", str(sid),
                   "--prod-ps", str(prod_ps), "--platform", "CUDA"]
            log = open(cold_dir / f"seed_{sid:03d}.log", "w")
            running.append((subprocess.Popen([str(c) for c in cmd], cwd=ROOT, env=env, stdout=log,
                                             stderr=subprocess.STDOUT), log, sid))
        still = []
        for p, log, sid in running:
            if p.poll() is None:
                still.append((p, log, sid))
            else:
                log.close()
                if p.returncode != 0:
                    failed.append(sid)
        running = still
        time.sleep(2)
    if failed:
        raise RuntimeError(f"cold-MD seeds failed: {sorted(failed)}")


def largest_remainder(weights, total):
    w = np.asarray(weights, float); w = w / w.sum()
    raw = w * total; base = np.floor(raw).astype(int)
    for i in np.argsort(-(raw - base))[: total - base.sum()]:
        base[i] += 1
    return base


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--switch-ps", type=float, required=True)
    ap.add_argument("--k", type=int, default=1000)
    ap.add_argument("--n-top", type=int, default=100, help="highest-weight pool for cold-MD seeding")
    ap.add_argument("--n-cold-seeds", type=int, default=20)
    ap.add_argument("--cold-ns", type=float, default=1.0)
    ap.add_argument("--cold-burn-ps", type=float, default=100.0)
    ap.add_argument("--hot-lo-ns", type=float, default=20.0)
    ap.add_argument("--hot-hi-ns", type=float, default=1000.0)
    ap.add_argument("--n-shards", type=int, default=4)
    ap.add_argument("--cold-parallel", type=int, default=8)
    ap.add_argument("--basin-model", default=str(ROOT / "data/cyclosporin/basins/basin_model_backbone.pkl"))
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--seed", type=int, default=20260625)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    model = BasinModel.load(Path(args.basin_model)); nb = model.n_basins
    _, _, ring = load_quartets(TOPO, "backbone"); ring = np.asarray(ring, int)

    # REMD cold reference ΔΔF (replica_00)
    rep0 = [str(REMD / "replica_00/trajectory.dcd")] + [str(p) for p in sorted((REMD / "replica_00").glob("trajectory_ext*.dcd"))]
    cb = model.assign(md.load(rep0, top=str(TOP_PDB))[5000:])
    pr = np.bincount(cb, minlength=nb).astype(float); pr /= pr.sum()
    with np.errstate(divide="ignore"):
        ref = -np.log(pr / pr[0])
    print(f"REMD cold ref ΔΔF={np.round(ref,3).tolist()}  switch={args.switch_ps}ps", flush=True)

    # (1) random k hot configs from [hot-lo, hot-hi] ns of the single-walker hot trajectory
    lo, hi = int(args.hot_lo_ns / NS_PER_FRAME), int(args.hot_hi_ns / NS_PER_FRAME)
    hot = md.load(str(HOT_REF), top=str(TOP_PDB))[lo:hi]
    fpick = rng.choice(hot.n_frames, args.k, replace=args.k > hot.n_frames)
    fseed = out / "seed_hot"; write_seed_dir(fseed, hot[fpick])
    print(f"(1) {args.k} random hot seeds from [{args.hot_lo_ns},{args.hot_hi_ns}]ns ({hot.n_frames} frames)", flush=True)

    # (2) forward AIS
    logw_f, sel_f = leg(fseed, out / "step_forward_ais", args.k, 0.4, 1.0, args.switch_ps, args.n_shards, args.seed)
    W_f = -logw_f
    a_f = model.assign(hot[fpick])[sel_f]
    fep = md.load_dcd(str(out / "step_forward_ais/ais_final_coordinates.dcd"), top=str(TOP_PDB))
    b_f = model.assign(fep)
    land = np.bincount(b_f, minlength=nb).astype(float)
    print(f"(2) forward W_f={W_f.mean():.1f}±{W_f.std():.1f}  landing={land.astype(int).tolist()}", flush=True)

    # (3) top-N highest weight -> n_cold_seeds most distinct by backbone RMSD
    top = np.argsort(logw_f)[-args.n_top:]
    top_traj = fep[top]
    fps = farthest_point_rmsd(top_traj, ring, args.n_cold_seeds, seed0=int(np.argmax(logw_f[top])))
    seed_idx = top[fps]
    struct_dir = out / "cold_seeds"; struct_dir.mkdir(exist_ok=True)
    seed_pdbs = []
    for j, gi in enumerate(seed_idx):
        p = struct_dir / f"seed_{j:03d}.pdb"; fep[gi].save_pdb(str(p)); seed_pdbs.append(p)
    print(f"(3) selected {len(seed_pdbs)} distinct seeds from top-{args.n_top} weights (backbone-RMSD FPS)", flush=True)

    # (4) cold MD reservoir (parallel)
    cold_dir = out / "cold_md"
    print(f"(4) {len(seed_pdbs)} x {args.cold_ns}ns cold MD ({args.cold_parallel}-wide) ...", flush=True)
    parallel_cold_md(seed_pdbs, cold_dir, args.cold_ns * 1000.0, args.cold_parallel)

    # (5) reverse AIS: cold reservoir, allocated by forward landing ratio
    burn = int(round(args.cold_burn_ps / 1.0))  # 1 ps/frame
    res_xyz, res_basin = [], []
    seeds = sorted(cold_dir.glob("seed_*/trajectory.dcd"))
    for dcd in seeds:
        tr = md.load_dcd(str(dcd), top=str(TOP_PDB))[burn:]
        res_xyz.append(tr.xyz); res_basin.append(model.assign(tr))
    top0 = md.load_dcd(str(seeds[0]), top=str(TOP_PDB)).topology
    res_xyz = np.concatenate(res_xyz); res_basin = np.concatenate(res_basin)
    rpop = np.bincount(res_basin, minlength=nb)
    usable = np.array([b for b in range(nb) if land[b] > 0 and rpop[b] > 0])
    alloc = largest_remainder(land[usable], args.k)
    xyz, b_r = [], []
    for B, n in zip(usable, alloc):
        idx = np.where(res_basin == B)[0]
        pick = rng.choice(idx, int(n), replace=True)
        xyz.extend(res_xyz[pick]); b_r.extend([int(B)] * int(n))
    b_r = np.array(b_r)
    rseed = out / "reverse/seed_cold"; rseed.mkdir(parents=True, exist_ok=True)
    md.Trajectory(np.array(xyz), top0).save_dcd(str(rseed / "trajectory.dcd"))
    shutil.copy2(TOP_PDB, rseed / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(TOPO / "system_scale_1p0.prmtop"), inpcrd_path=str(TOPO / "system_scale_1p0.inpcrd"),
                   gb_model="GBn2", gb_radii="mbondi3", n_solute_atoms=196, timestep_fs=2.0,
                   friction_per_ps=1.0, temperature_k=300.0, solvent="implicit"),
              open(rseed / "config.json", "w"), indent=2)
    print(f"(5) reverse: reservoir pop={rpop.tolist()} alloc={dict(zip(usable.tolist(),alloc.tolist()))}", flush=True)
    logw_r, sel_r = leg(rseed, out / "reverse/step_reverse_ais", len(xyz), 1.0, 0.4, args.switch_ps, args.n_shards, args.seed + 1)
    W_r = -logw_r
    b_r = b_r[sel_r]
    a_r = model.assign(md.load_dcd(str(out / "reverse/step_reverse_ais/ais_final_coordinates.dcd"), top=str(TOP_PDB)))

    # BAR estimate vs REMD
    acc = Accumulator(); acc.append(RoundData(W_f, a_f, b_f, W_r, b_r, a_r))
    res = estimate(acc, nb, reference_ddF=ref, bootstrap=True, n_bootstrap=400, rng=rng)
    summary = dict(protocol="singlewalker", k=args.k, switch_ps=args.switch_ps,
                   remd_cold_pop=pr.tolist(), reference_ddF=ref.tolist(),
                   forward_landing=land.astype(int).tolist(),
                   ddF_ais=res["ddF_ais"].tolist(), ddF_hotunified=res["ddF_hotunified"].tolist(),
                   overlap=res["overlap"].tolist(), confidence=res["confidence"],
                   rmse_hotunified=res.get("rmse_hotunified_covered"),
                   W_f_mean=float(W_f.mean()), W_f_std=float(W_f.std()),
                   W_r_mean=float(W_r.mean()), W_r_std=float(W_r.std()))
    json.dump(summary, open(out / "validation_summary.json", "w"), indent=2)
    print(f"\n=== SINGLE-WALKER {args.switch_ps}ps ===")
    print(f"  reference ΔΔF   = {np.round(ref,3).tolist()}")
    print(f"  AIS forward     = {np.round(res['ddF_ais'],3).tolist()}")
    print(f"  hot-unified BAR = {np.round(res['ddF_hotunified'],3).tolist()}")
    print(f"  overlap         = {np.round(res['overlap'],2).tolist()}  RMSE_hub={summary['rmse_hotunified']:.3f} kT")
    print(f"  -> {out}/validation_summary.json", flush=True)


if __name__ == "__main__":
    main()
