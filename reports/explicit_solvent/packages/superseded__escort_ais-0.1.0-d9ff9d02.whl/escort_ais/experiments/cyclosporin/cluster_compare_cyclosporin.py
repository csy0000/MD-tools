#!/usr/bin/env python3
"""cluster_compare_cyclosporin.py — DBSCAN vs HDBSCAN vs DBSCAN++ on the 250 ns REMD (cold replica).

Clusters the physical (s=1.0, replica_00) REMD ensemble in the backbone-torsion PCA space (same
33-dihedral / 8-PC coordinate as analyze_cyclosporin_three_sims.py) with three density methods and
compares them (cluster counts, noise, pairwise ARI/AMI agreement). Then, for each method's TOP 4
clusters, writes the medoid structures aligned to a common orientation (NOT overlaid) and the list of
intramolecular H-bonds in each, for element-coloured per-panel rendering.

Reads ONLY replica_00/trajectory.dcd (the original 250 ns) — never the in-progress _ext parts.

Outputs -> results/cyclosporin/cluster250/:
  fig_cluster_compare.png, metrics.csv, medoids/<method>_c<k>.pdb, hbonds.json, view.json
Usage:  python -m escort_ais.experiments.cyclosporin.cluster_compare_cyclosporin
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.sparse.csgraph import connected_components
from sklearn.cluster import DBSCAN, HDBSCAN
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_mutual_info_score, adjusted_rand_score
from sklearn.neighbors import NearestNeighbors, radius_neighbors_graph
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.analysis.analyze_cyclosporin_three_sims import (CSA, TOP, dihedrals_deg, get_torsions,  # noqa: E402
                                            macrocycle_quartets, sincos)
from escort_ais.systems.peptide_torsions import classify_amide_bonds  # noqa: E402

TORSION = os.environ.get("CSA_TORSION", "backbone")   # 'backbone' or 'allatom' (see analyze script)


def backbone_NH_O():
    """Backbone amide donor-N set and carbonyl-O acceptor set (RDKit==mdtraj atom indices)."""
    from openff.toolkit import Molecule
    rd = Molecule.from_smiles(CSA, allow_undefined_stereo=True).to_rdkit()
    amides = classify_amide_bonds(rd)
    bb_N = {int(n) for _c, n, _t in amides}                 # the 11 backbone amide nitrogens
    bb_O = set()
    for c, _n, _t in amides:                                # the carbonyl O on each amide carbon
        bb_O |= {int(a.GetIdx()) for a in rd.GetAtomWithIdx(int(c)).GetNeighbors()
                 if a.GetSymbol() == "O"}
    return bb_N, bb_O

REMD = ROOT / "data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns"
OUT = (ROOT / "results/cyclosporin/cluster250" if TORSION == "backbone"
       else ROOT / "results/cyclosporin" / TORSION / "cluster250")
(OUT / "medoids").mkdir(parents=True, exist_ok=True)
CMAP = plt.cm.tab20


def auto_eps_kdist(Z, min_samples):
    kd = np.sort(NearestNeighbors(n_neighbors=min_samples).fit(Z).kneighbors(Z)[0][:, -1])
    base = float(np.median(kd))
    best = None
    for f in np.linspace(0.5, 4.0, 36):
        eps = base * f
        lab = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=-1).fit_predict(Z)
        k = len(set(lab)) - (1 if -1 in lab else 0)
        cov = float(np.mean(lab != -1))
        score = (5 <= k <= 12 and cov >= 0.6, k if cov >= 0.6 else 0, cov)
        if best is None or score > best[0]:
            best = (score, eps, lab)
    return best[1], best[2]


def dbscan_pp(Z, eps, min_pts, m_frac=0.3, seed=0):
    """DBSCAN++ (Jang & Jiang 2019), uniform-init variant: core points found on a sampled subset,
    clusters = connected components of cores within eps, then label all points by nearest core."""
    rng = np.random.default_rng(seed)
    n = len(Z); m = max(min_pts + 1, int(m_frac * n))
    S = rng.choice(n, m, replace=False)
    nn = NearestNeighbors(radius=eps, n_jobs=-1).fit(Z)
    cnt = nn.radius_neighbors(Z[S], return_distance=False)         # neighbours in full set within eps
    core = S[np.array([len(c) >= min_pts for c in cnt])]
    labels = np.full(n, -1)
    if len(core):
        G = radius_neighbors_graph(Z[core], radius=eps, mode="connectivity", include_self=True)
        _, comp = connected_components(G, directed=False)
        d, idx = NearestNeighbors(n_neighbors=1, n_jobs=-1).fit(Z[core]).kneighbors(Z)
        within = d[:, 0] <= eps
        labels[within] = comp[idx[within, 0]]
    return labels


def relabel_by_pop(lab):
    order = [c for c, _ in pd.Series(lab[lab != -1]).value_counts().items()]
    remap = {c: i for i, c in enumerate(order)}
    out = np.array([remap.get(x, -1) for x in lab])
    return out, len(order)


def main():
    quartets, is_omega, ring = get_torsions()
    print(f"torsion set = {TORSION}: {len(quartets)} dihedrals -> {OUT.relative_to(ROOT)}")
    print("loading 250 ns REMD cold replica (replica_00/trajectory.dcd only) ...")
    tr = md.load(str(REMD / "replica_00/trajectory.dcd"), top=str(TOP))
    print(f"  {tr.n_frames} frames")
    X = sincos(dihedrals_deg(tr, quartets))
    sub = np.random.default_rng(0).choice(len(X), min(15000, len(X)), replace=False)
    pca = PCA(n_components=8, svd_solver="full").fit(X[sub])
    Z = StandardScaler().fit(pca.transform(X[sub])).transform(pca.transform(X))

    ms = 50
    eps, lab_db = auto_eps_kdist(Z, ms)
    methods = {}
    methods["DBSCAN"] = relabel_by_pop(lab_db)[0]
    methods["HDBSCAN"] = relabel_by_pop(
        HDBSCAN(min_cluster_size=150, min_samples=ms).fit_predict(Z))[0]
    methods["DBSCAN++"] = relabel_by_pop(dbscan_pp(Z, eps, ms, m_frac=0.3))[0]

    # ── per-frame BACKBONE amide N-H...O=C H-bond count (Wernet–Nilsson), strided ──
    bb_N, bb_O = backbone_NH_O()

    def bb_pairs(hbtrip):                                   # keep donor in backbone-N, acceptor in carbonyl-O
        return [[int(h), int(a)] for d, h, a in hbtrip if int(d) in bb_N and int(a) in bb_O]

    HB_STRIDE = 2
    hidx = np.arange(0, tr.n_frames, HB_STRIDE)
    print(f"  counting BACKBONE amide N-H...O=C H-bonds over {len(hidx)} frames (stride {HB_STRIDE}) ...")
    hbc = np.array([len(bb_pairs(x)) for x in md.wernet_nilsson(tr[hidx])])
    print(f"  mean backbone H-bonds/frame (whole ensemble): {hbc.mean():.2f}")

    def avg_hb(lab, c):                       # cluster-average number of intramolecular H-bonds
        sel = lab[hidx] == c
        return float(hbc[sel].mean()) if sel.any() else float("nan")

    # ── comparison metrics ──
    rows = []
    for name, lab in methods.items():
        k = int(lab.max() + 1) if (lab >= 0).any() else 0
        rows.append(dict(method=name, n_clusters=k, noise_pct=round(100 * np.mean(lab == -1), 1),
                         eps=(round(eps, 2) if name != "HDBSCAN" else None),
                         top4_pct=[round(100 * np.mean(lab == c), 1) for c in range(min(4, k))],
                         top4_avg_hb=[round(avg_hb(lab, c), 2) for c in range(min(4, k))]))
    mdf = pd.DataFrame(rows); mdf.to_csv(OUT / "metrics.csv", index=False)
    names = list(methods)
    print("\n  cluster comparison:")
    print(mdf.to_string(index=False))
    print("\n  pairwise agreement (ARI / AMI):")
    agree = {}
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = methods[names[i]], methods[names[j]]
            ari = adjusted_rand_score(a, b); ami = adjusted_mutual_info_score(a, b)
            agree[f"{names[i]}–{names[j]}"] = (round(ari, 3), round(ami, 3))
            print(f"    {names[i]:9s} vs {names[j]:9s}: ARI={ari:.3f}  AMI={ami:.3f}")
    json.dump({"metrics": rows, "agreement": {k: list(v) for k, v in agree.items()},
               "eps": float(eps), "n_frames": int(tr.n_frames)}, open(OUT / "summary.json", "w"), indent=2)

    # ── comparison figure: PCA scatter coloured by each method ──
    fig, axes = plt.subplots(1, 3, figsize=(16, 5), sharex=True, sharey=True)
    for ax, name in zip(axes, names):
        lab = methods[name]
        ax.scatter(Z[lab == -1, 0][::4], Z[lab == -1, 1][::4], s=2, color="0.8", label="noise")
        for c in range(int(lab.max() + 1) if (lab >= 0).any() else 0):
            m = lab == c
            ax.scatter(Z[m, 0][::4], Z[m, 1][::4], s=3, color=CMAP(c % 20), alpha=0.5)
        kk = int(lab.max() + 1) if (lab >= 0).any() else 0
        ax.set_title(f"{name}: {kk} clusters, {100*np.mean(lab==-1):.0f}% noise")
        ax.set_xlabel("torsion PC1")
    axes[0].set_ylabel("torsion PC2")
    fig.suptitle(f"Density clustering of the 250 ns cold REMD ensemble ({TORSION}-torsion PCA)",
                 fontsize=13)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    fig.savefig(OUT / "fig_cluster_compare.png", dpi=150); plt.close(fig)

    # ── top-4 medoids per method, aligned to a common orientation; + intramolecular H-bonds ──
    # `ring` (backbone macrocycle atoms) comes from get_torsions() — always backbone for superposition
    # global reference for orientation = DBSCAN top-1 medoid
    def medoid_frame(lab, c):
        idx = np.where(lab == c)[0]
        cen = Z[idx].mean(0)
        return int(idx[np.argmin(np.linalg.norm(Z[idx] - cen, axis=1))])
    ref_fr = medoid_frame(methods["DBSCAN"], 0)
    ref = tr[ref_fr]
    hbonds = {}
    for name, lab in methods.items():
        for c in range(min(4, int(lab.max() + 1) if (lab >= 0).any() else 0)):
            fr = medoid_frame(lab, c)
            frame = tr[fr]
            frame.superpose(ref, atom_indices=ring)               # same orientation, not overlaid in render
            rel = f"medoids/{name.replace('+','p')}_c{c}.pdb"
            frame.save_pdb(str(OUT / rel))
            # intramolecular H-bonds in this medoid (Wernet–Nilsson): columns donor, H, acceptor
            pairs = bb_pairs(md.wernet_nilsson(frame)[0])         # backbone amide (H, acceptor-O) pairs
            hbonds[rel] = dict(pairs=pairs, pop_pct=round(100 * np.mean(lab == c), 1),
                               medoid_hb=len(pairs), avg_hb=round(avg_hb(lab, c), 2))
    json.dump(hbonds, open(OUT / "hbonds.json", "w"), indent=2)

    # ── bar chart: average intramolecular H-bonds per top cluster, by method ──
    fig, ax = plt.subplots(figsize=(8, 4))
    nb = 4; w = 0.26
    for i, name in enumerate(names):
        lab = methods[name]
        vals = [avg_hb(lab, c) for c in range(nb)]
        ax.bar(np.arange(nb) + (i - 1) * w, vals, w, label=name, color=CMAP(2 * i))
        for c, v in enumerate(vals):
            ax.text(c + (i - 1) * w, v + 0.03, f"{v:.1f}", ha="center", fontsize=7)
    ax.set_xticks(range(nb)); ax.set_xticklabels([f"cluster {c}" for c in range(nb)])
    ax.set_ylabel("avg. backbone N-H...O=C H-bonds / frame"); ax.legend()
    ax.set_title(r"Average backbone amide N-H$\cdots$O=C H-bonds per top cluster (250 ns cold REMD)")
    fig.tight_layout(); fig.savefig(OUT / "fig_hbond_avg.png", dpi=150); plt.close(fig)
    print(f"\n  saved comparison fig + {len(hbonds)} aligned medoid PDBs (+ H-bonds) -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
