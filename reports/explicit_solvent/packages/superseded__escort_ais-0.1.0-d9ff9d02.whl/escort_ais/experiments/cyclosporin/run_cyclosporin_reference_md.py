#!/usr/bin/env python3
"""run_cyclosporin_reference_md.py — single-walker REFERENCE MD for cyclosporin (implicit GBn2).

Long single-walker reference trajectories that mirror the 8-replica REST2 REMD's EXACT system
construction (run_cyclosporin_rest2_remd.py), one walker, no exchange:
  HOT  : --scale-factor 0.4  -> REST2 omega-selective hot Hamiltonian (the 7 tertiary/N-methyl
         amides scaled; the 4 secondary amides kept physical, from omega_exclude_bonds.npy).
  COLD : --scale-factor 1.0  -> physical unscaled system (build_rest2_scaled_system returns the
         base system unchanged at s=1.0; the exclude set is then inert).
Both: mbondi3 radii + GBn2, LangevinMiddle (bath 300 K; heating is Hamiltonian), 2 fs.

Outputs -> --output-dir :  trajectory.dcd, state.csv, final_state.xml, final_checkpoint.chk,
                           config.json, summary.json
Usage:
  python -m escort_ais.experiments.cyclosporin.run_cyclosporin_reference_md \
      --scale-factor 0.4 --duration-ns 1000 --platform CUDA \
      --output-dir data/cyclosporin/2026-06-19-ref-singlewalker-hot-s0p4-1000ns
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import parmed as pmd
from parmed.tools import changeRadii

from openmm import LangevinMiddleIntegrator, Platform, unit
from openmm.app import (CheckpointReporter, DCDReporter, GBn2, HBonds, NoCutoff, PDBFile,
                        Simulation, StateDataReporter)

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.openmm_system import build_rest2_scaled_system  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--scale-factor", type=float, required=True, help="REST2 scale s (0.4 hot, 1.0 cold)")
    ap.add_argument("--duration-ns", type=float, default=1000.0)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--temperature-k", type=float, default=300.0)
    ap.add_argument("--equilibration-ps", type=float, default=100.0)
    ap.add_argument("--traj-interval-ps", type=float, default=10.0)
    ap.add_argument("--checkpoint-interval-ns", type=float, default=1.0)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--friction-per-ps", type=float, default=1.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--seed", type=int, default=20260619)
    ap.add_argument("--device", type=int, default=0, help="GPU device index (CUDA/OpenCL)")
    ap.add_argument("--topo-dir", default=str(TOPO), help="topology dir (default: cyclosporin)")
    ap.add_argument("--start-pdb", default=None,
                    help="start a fresh run from this PDB's coordinates (must match the prmtop atom "
                         "order, e.g. a frame sliced from a trajectory of this system) instead of the "
                         "topology inpcrd; the run is then minimized + equilibrated as usual")
    ap.add_argument("--start-state", default=None,
                    help="label for the starting basin (e.g. major/minor); recorded in config.json")
    ap.add_argument("--resume", action="store_true",
                    help="extend an existing run: load <output-dir>/final_state.xml, skip minimize/equil, "
                         "append production to the next trajectory_ext<N>.dcd")
    args = ap.parse_args()
    topo = Path(args.topo_dir)
    OUT = Path(args.output_dir)
    if not OUT.is_absolute():
        OUT = ROOT / OUT
    OUT.mkdir(parents=True, exist_ok=True)

    # base implicit GBn2 system (mbondi3 radii required by GBn2) -- identical to the REMD script
    st = pmd.load_file(str(topo / "system_scale_1p0.prmtop"), xyz=str(topo / "system_scale_1p0.inpcrd"))
    changeRadii(st, "mbondi3").execute()
    base_system = st.createSystem(implicitSolvent=GBn2, nonbondedMethod=NoCutoff,
                                  constraints=HBonds, removeCMMotion=True)
    topology = st.topology
    n_atoms = topology.getNumAtoms()
    solute = np.arange(n_atoms)
    excl = np.load(topo / "omega_exclude_bonds.npy")
    s = float(args.scale_factor)
    scaled = build_rest2_scaled_system(base_system, solute, s, exclude_central_bonds=excl)
    eff_T = args.temperature_k / s
    label = "HOT" if s < 1.0 else "COLD"
    print(f"  {topo.parent.name} single-walker {label} reference: s={s} (effective T={eff_T:.0f} K), "
          f"{args.duration_ns} ns, omega-exclude={excl.tolist()}")

    plat = Platform.getPlatformByName(args.platform)
    props = {}
    if args.platform == "CUDA":
        props = {"Precision": "mixed", "DeviceIndex": str(args.device)}
    elif args.platform == "OpenCL":
        props = {"Precision": "mixed", "OpenCLDeviceIndex": str(args.device)}
    integ = LangevinMiddleIntegrator(args.temperature_k * unit.kelvin,
                                     args.friction_per_ps / unit.picosecond,
                                     args.timestep_fs * unit.femtoseconds)
    sim = Simulation(topology, scaled, integ, plat, props)

    steps = lambda ps: max(1, int(round(ps * 1000.0 / args.timestep_fs)))
    equil = steps(args.equilibration_ps)
    prod = steps(args.duration_ns * 1000.0)
    traj = steps(args.traj_interval_ps)
    chk = steps(args.checkpoint_interval_ns * 1000.0)

    if args.resume:
        # ── extend an existing run: load the saved end-state, skip minimize/equil ──
        state_xml = OUT / "final_state.xml"
        if not state_xml.exists():
            raise FileNotFoundError(f"--resume needs {state_xml}")
        sim.loadState(str(state_xml))
        n_ext = len(list(OUT.glob("trajectory_ext*.dcd"))) + 1
        traj_path = OUT / f"trajectory_ext{n_ext}.dcd"
        summary_path = OUT / f"summary_ext{n_ext}.json"
        print(f"  RESUME from {state_xml.name}: +{args.duration_ns} ns -> {traj_path.name}")
        sim.reporters.append(DCDReporter(str(traj_path), traj))
        sim.reporters.append(StateDataReporter(str(OUT / f"state_ext{n_ext}.csv"), traj, step=True,
                                               time=True, potentialEnergy=True, temperature=True,
                                               speed=True, progress=True, remainingTime=True,
                                               totalSteps=prod, separator=","))
    else:
        if args.start_pdb:
            start_positions = PDBFile(args.start_pdb).getPositions()
            if len(start_positions) != n_atoms:
                raise ValueError(f"--start-pdb has {len(start_positions)} atoms, expected {n_atoms}")
            sim.context.setPositions(start_positions)
            print(f"  start conformation from {args.start_pdb} (state={args.start_state})")
        else:
            sim.context.setPositions(st.positions)
        print("  minimizing ...")
        sim.minimizeEnergy()
        x0 = sim.context.getState(getPositions=True).getPositions()
        PDBFile.writeFile(topology, x0, open(OUT / "start_structure_minimized.pdb", "w"))
        sim.context.setVelocitiesToTemperature(args.temperature_k * unit.kelvin, args.seed)

        (OUT / "config.json").write_text(json.dumps(dict(
            system=topo.parent.name, run_type=f"single_walker_reference_{label.lower()}",
            forcefield="sage", solvent="gbn2", gb_model="GBn2", n_solute_atoms=n_atoms,
            rest2_scale_factor=s, effective_temperature_k=eff_T, temperature_k=args.temperature_k,
            omega_exclude_bonds=excl.tolist(), omega_selective=True,
            production_duration_ns=args.duration_ns, equilibration_ps=args.equilibration_ps,
            traj_interval_ps=args.traj_interval_ps, timestep_fs=args.timestep_fs,
            friction_per_ps=args.friction_per_ps, seed=args.seed, platform=args.platform,
            prmtop_path=str(topo / "system_scale_1p0.prmtop"),
            start_pdb=args.start_pdb, start_state=args.start_state,
        ), indent=2))

        print(f"  equilibrating {args.equilibration_ps} ps ...")
        sim.step(equil)
        traj_path = OUT / "trajectory.dcd"
        summary_path = OUT / "summary.json"
        sim.reporters.append(DCDReporter(str(traj_path), traj))
        sim.reporters.append(StateDataReporter(str(OUT / "state.csv"), traj, step=True, time=True,
                                               potentialEnergy=True, temperature=True, speed=True,
                                               progress=True, remainingTime=True, totalSteps=equil + prod,
                                               separator=","))
        sim.reporters.append(CheckpointReporter(str(OUT / "final_checkpoint.chk"), chk))

    print(f"  production {args.duration_ns} ns ({prod} steps) ...")
    t0 = time.time()
    sim.step(prod)
    wall_h = (time.time() - t0) / 3600.0
    sim.saveState(str(OUT / "final_state.xml"))
    n_frames = prod // traj
    summary_path.write_text(json.dumps(dict(
        completed=True, rest2_scale_factor=s, effective_temperature_k=eff_T,
        production_duration_ns=args.duration_ns, n_frames=int(n_frames),
        traj_interval_ps=args.traj_interval_ps, wall_clock_hours=round(wall_h, 2),
        ns_per_day=round(args.duration_ns / max(wall_h, 1e-9) * 24.0, 1),
    ), indent=2))
    disp = OUT.relative_to(ROOT) if OUT.is_relative_to(ROOT) else OUT
    print(f"  DONE {label} s={s}: {n_frames} frames in {wall_h:.1f} h "
          f"({args.duration_ns / max(wall_h,1e-9) * 24:.0f} ns/day) -> {disp}")


if __name__ == "__main__":
    main()
