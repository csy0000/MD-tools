#!/usr/bin/env python3
"""build_cyclosporin_topology.py — parameterize cyclosporin A + compute the omega-exclude set.

Cyclosporin A (PubChem CID 5284373, C62H111N11O12): cyclic 11-mer, 7 N-methylated.
Built as an OpenFF **Sage** ligand from its isomeric SMILES (ETKDG conformer), then the
secondary-amide omega (peptide-bond) central bonds are detected and saved so the REST2 hot
ensemble can leave them unscaled (the 7 N-methyl tertiary amides — incl. the native cis
MeLeu9-MeLeu10 bond — stay scaled).

Outputs -> data/cyclosporin/topology/:
  system_scale_1p0.prmtop, .inpcrd, topology.pdb, config.json, omega_exclude_bonds.npy
Usage:  python -m escort_ais.experiments.cyclosporin.build_cyclosporin_topology [--forcefield sage] [--solvent gbn2]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from rdkit import Chem

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.topology_prep import build_topology  # noqa: E402
from escort_ais.systems.peptide_torsions import amide_census, omega_exclude_bonds  # noqa: E402

# Cyclosporin A isomeric SMILES (PubChem CID 5284373)
CSA_SMILES = ("CC[C@H]1C(=O)N(CC(=O)N([C@H](C(=O)N[C@H](C(=O)N([C@H](C(=O)N[C@H](C(=O)N[C@@H]"
              "(C(=O)N([C@H](C(=O)N([C@H](C(=O)N([C@H](C(=O)N([C@H](C(=O)N1)[C@@H]([C@H](C)C/C=C/C)O)"
              "C)C(C)C)C)CC(C)C)C)CC(C)C)C)C)C)CC(C)C)C)C(C)C)CC(C)C)C)C")
OUT = ROOT / "data/cyclosporin/topology"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--forcefield", default="sage", choices=["sage", "gaff"])
    ap.add_argument("--solvent", default="gbn2")
    ap.add_argument("--skip-build", action="store_true",
                    help="reuse an existing topology in the output dir (only recompute omega bonds)")
    args = ap.parse_args()

    cen = amide_census(Chem.MolFromSmiles(CSA_SMILES))
    print(f"  CsA amide census: {cen}  (expect 11 amide, 7 tertiary, 4 secondary)")
    assert cen == {"n_amide": 11, "n_tertiary": 7, "n_secondary": 4}, "unexpected amide census"

    top_pdb = OUT / "topology.pdb"
    if args.skip_build and top_pdb.exists():
        print(f"  reusing existing topology in {OUT.relative_to(ROOT)}")
    else:
        print(f"  building topology ({args.forcefield} / {args.solvent}) -> {OUT.relative_to(ROOT)} ...")
        info = build_topology(output_dir=OUT, ligand_smiles=CSA_SMILES,
                              forcefield=args.forcefield, solvent=args.solvent)
        print(f"  topology built: n_solute_atoms={int(info.get('n_solute_atoms', 0))}")

    # The OpenFF molecule's RDKit atom order == the OpenMM topology order (verified
    # element-by-element), so the OpenMM<->RDKit map is the identity.
    from openff.toolkit import Molecule  # noqa: E402  (deferred; heavy import)
    from openmm.app import PDBFile
    offmol = Molecule.from_smiles(CSA_SMILES, allow_undefined_stereo=True)
    rdmol = offmol.to_rdkit()
    top_elems = [a.element.symbol for a in PDBFile(str(top_pdb)).topology.atoms()]
    rd_elems = [a.GetSymbol() for a in rdmol.GetAtoms()]
    assert rd_elems == top_elems, "OpenFF/OpenMM atom order mismatch -- identity map invalid"
    n_solute = len(top_elems)

    excl = omega_exclude_bonds(rdmol, np.arange(n_solute))   # (4, 2) secondary amides, OpenMM idx
    np.save(OUT / "omega_exclude_bonds.npy", excl)
    print(f"  omega_exclude_bonds (secondary amides, OpenMM indices), shape {excl.shape}:")
    print(excl)
    print(f"  Saved omega_exclude_bonds.npy -> {OUT.relative_to(ROOT)}  "
          f"({len(excl)} excluded; {cen['n_tertiary']} tertiary amides stay scaled)")


if __name__ == "__main__":
    main()
