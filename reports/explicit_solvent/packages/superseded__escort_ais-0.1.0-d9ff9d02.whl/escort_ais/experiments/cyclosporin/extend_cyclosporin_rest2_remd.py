#!/usr/bin/env python3
"""extend_cyclosporin_rest2_remd.py — resume the 8-replica REST2 REMD and run more production.

Reloads each replica's saved final_state.xml (positions, velocities, step count) from the existing
run dir, rebuilds the same omega-selective REST2 scaled systems, and continues the exchange loop for
`--additional-ns` more, APPENDING frames to each replica_NN/trajectory.dcd and rows to
exchange_attempts.csv (so the run dir holds the full extended trajectory). Updates config.json.

No minimisation / equilibration — it is a true continuation of the finished 250 ns run.

Usage:  python -m escort_ais.experiments.cyclosporin.extend_cyclosporin_rest2_remd \
          [--additional-ns 250] [--platform CUDA]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import parmed as pmd
from parmed.tools import changeRadii

from openmm import LangevinMiddleIntegrator, Platform, unit
from openmm.app import DCDReporter, GBn2, HBonds, NoCutoff, Simulation, StateDataReporter

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.openmm_system import BOLTZMANN_KJ_PER_MOL_K, build_rest2_scaled_system  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"
OUT = ROOT / "data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns"


def scale_ladder(s_min, n):
    return (np.linspace(1.0, math.sqrt(s_min), n) ** 2).tolist()


def exchange_pairs(n, phase):
    return [(i, i + 1) for i in range(phase % 2, n - 1, 2)]


def attempt_exchange(sim_i, sim_j, beta0, rng):
    si = sim_i.context.getState(getPositions=True, getVelocities=True, getEnergy=True)
    sj = sim_j.context.getState(getPositions=True, getVelocities=True, getEnergy=True)
    xi, xj = si.getPositions(asNumpy=True), sj.getPositions(asNumpy=True)
    vi, vj = si.getVelocities(asNumpy=True), sj.getVelocities(asNumpy=True)
    kj = unit.kilojoule_per_mole
    e_ii = si.getPotentialEnergy().value_in_unit(kj)
    e_jj = sj.getPotentialEnergy().value_in_unit(kj)
    sim_i.context.setPositions(xj)
    e_ij = sim_i.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(kj)
    sim_j.context.setPositions(xi)
    e_ji = sim_j.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(kj)
    delta = (e_ij + e_ji) - (e_ii + e_jj)
    accepted = (-beta0 * delta) >= 0.0 or math.log(rng.random()) < (-beta0 * delta)
    if accepted:
        sim_i.context.setVelocities(vj); sim_j.context.setVelocities(vi)
    else:
        sim_i.context.setPositions(xi); sim_j.context.setPositions(xj)
    return accepted


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--additional-ns", type=float, default=250.0)
    ap.add_argument("--n-replicas", type=int, default=8)
    ap.add_argument("--s-min", type=float, default=0.4)
    ap.add_argument("--temperature-k", type=float, default=300.0)
    ap.add_argument("--exchange-interval-ps", type=float, default=1.0)
    ap.add_argument("--traj-interval-ps", type=float, default=10.0)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--friction-per-ps", type=float, default=1.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--sequential", action="store_true",
                    help="step replicas one-at-a-time (default: concurrent threads, ~5x on GPU)")
    ap.add_argument("--seed", type=int, default=20260620)
    args = ap.parse_args()

    cfg = json.loads((OUT / "config.json").read_text())
    for r in range(args.n_replicas):
        if not (OUT / f"replica_{r:02d}/final_state.xml").exists():
            raise SystemExit(f"missing replica_{r:02d}/final_state.xml — run must be finished to extend")

    # continuation part index (crash-safe: originals untouched; each extension writes new _ext files)
    part = len(list((OUT / "replica_00").glob("trajectory_ext*.dcd"))) + 1

    def latest_state(r):
        cands = sorted((OUT / f"replica_{r:02d}").glob("final_state_ext*.xml"))
        return cands[-1] if cands else (OUT / f"replica_{r:02d}/final_state.xml")

    st = pmd.load_file(str(TOPO / "system_scale_1p0.prmtop"), xyz=str(TOPO / "system_scale_1p0.inpcrd"))
    changeRadii(st, "mbondi3").execute()
    base_system = st.createSystem(implicitSolvent=GBn2, nonbondedMethod=NoCutoff,
                                  constraints=HBonds, removeCMMotion=True)
    topology = st.topology
    solute = np.arange(topology.getNumAtoms())
    excl = np.load(TOPO / "omega_exclude_bonds.npy")
    scales = scale_ladder(args.s_min, args.n_replicas)
    plat = Platform.getPlatformByName(args.platform)

    steps = lambda ps: max(1, int(round(ps * 1000.0 / args.timestep_fs)))
    add_prod = steps(args.additional_ns * 1000.0)
    xchg = steps(args.exchange_interval_ps)
    traj = steps(args.traj_interval_ps)

    sims = []
    for r, s in enumerate(scales):
        scaled = build_rest2_scaled_system(base_system, solute, s, exclude_central_bonds=excl)
        integ = LangevinMiddleIntegrator(args.temperature_k * unit.kelvin,
                                         args.friction_per_ps / unit.picosecond,
                                         args.timestep_fs * unit.femtoseconds)
        props = {"Precision": "mixed"} if args.platform in ("CUDA", "OpenCL") else {}
        sim = Simulation(topology, scaled, integ, plat, props)
        sim.loadState(str(latest_state(r)))   # positions + velocities + step count from the last endpoint
        rdir = OUT / f"replica_{r:02d}"
        sim.reporters.append(DCDReporter(str(rdir / f"trajectory_ext{part}.dcd"), traj))
        sim.reporters.append(StateDataReporter(str(rdir / f"state_ext{part}.csv"), traj, step=True,
                                               time=True, potentialEnergy=True, temperature=True,
                                               speed=True))
        sims.append(sim)

    beta0 = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * args.temperature_k)
    rng = np.random.default_rng(args.seed)
    # The 8 replicas are independent between exchanges; OpenMM releases the GIL during step(), so we
    # step them CONCURRENTLY in threads (filling the otherwise ~15%-utilised GPU) and barrier at each
    # exchange. --sequential reverts to one-at-a-time (for validating identical exchange physics).
    pool = None if args.sequential else cf.ThreadPoolExecutor(max_workers=args.n_replicas)
    mode = "sequential" if args.sequential else f"PARALLEL ({args.n_replicas} threads)"
    print(f"  RESUMING REST2 REMD [{mode}]: +{args.additional_ns} ns/replica "
          f"(was {cfg['production_duration_ns']} ns), {args.n_replicas} replicas, "
          f"exchange every {args.exchange_interval_ps} ps ...")

    with open(OUT / f"exchange_attempts_ext{part}.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["step", "phase", "i", "j", "accepted"])
        remaining, phase, n_acc, n_att = add_prod, 0, 0, 0
        while remaining > 0:
            block = min(xchg, remaining)
            if pool is None:
                for sim in sims:
                    sim.step(block)
            else:
                list(pool.map(lambda s: s.step(block), sims))   # concurrent step; barrier on map()
            cur = sims[0].currentStep
            for i, j in exchange_pairs(args.n_replicas, phase):
                acc = attempt_exchange(sims[i], sims[j], beta0, rng)
                n_att += 1; n_acc += int(acc)
                w.writerow([cur, phase, i, j, int(acc)])
            remaining -= block; phase += 1
            if phase % 50 == 0:
                fh.flush()
    if pool is not None:
        pool.shutdown()
    for r, sim in enumerate(sims):
        sim.saveState(str(OUT / f"replica_{r:02d}/final_state_ext{part}.xml"))
    cfg["production_duration_ns"] = float(cfg["production_duration_ns"]) + args.additional_ns
    cfg["extended_parts"] = part
    (OUT / "config.json").write_text(json.dumps(cfg, indent=2))
    print(f"  DONE extension. acceptance = {n_acc}/{n_att} = {n_acc/max(1,n_att):.2%} ; "
          f"total now {cfg['production_duration_ns']} ns/replica -> {OUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
