#!/usr/bin/env python3
"""run_cyclosporin_forward_ais.py — forward AIS for cyclosporin (hot s=0.4 -> cold s=1.0).

Draws hot configurations from a window of the s=0.4 single-walker reference trajectory, anneals each
linearly in the REST2 scale s=0.4->1.0 with OMEGA-SELECTIVE scaling (the 4 secondary-amide peptide
bonds kept physical via omega_exclude_bonds.npy), on the SAME GBn2/mbondi3 Hamiltonian as the REMD
(the seed config carries gb_radii="mbondi3", engaging the parmed changeRadii path in ais_linear).

Outputs (in --output-dir): ais_trajectory_summary.csv (final_logw -> W_f=-final_logw), the cold
endpoints ais_final_coordinates.dcd, selected_initial_frames.csv, ais_metadata.json. BAR input is
W_f = -final_logw, identical to the alanine pipeline.

Usage:  python -m escort_ais.experiments.cyclosporin.run_cyclosporin_forward_ais \
          --hot-window-ns 20 100 --k-ais 1000 --switch-ps 2 --platform CUDA --output-dir <dir>
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import mdtraj as md
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"
HOT_REF = ROOT / "data/cyclosporin/2026-06-19-ref-singlewalker-hot-s0p4-1000ns/trajectory.dcd"
NS_PER_FRAME = 0.01  # 10 ps/frame in the reference trajectory


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hot-window-ns", type=float, nargs=2, default=[20.0, 100.0],
                    metavar=("LO", "HI"), help="hot s=0.4 reference window [lo, hi] ns to draw from")
    ap.add_argument("--k-ais", type=int, default=1000, help="number of forward AIS trajectories")
    ap.add_argument("--switch-ps", type=float, default=10.0, help="annealing switch length (ps)")
    ap.add_argument("--freq-ais", type=int, default=10, help="MD steps per AIS lambda window")
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--seed", type=int, default=20260623)
    ap.add_argument("--output-dir", required=True)
    args = ap.parse_args()

    base = Path(args.output_dir); base.mkdir(parents=True, exist_ok=True)
    seed_dir = base / "seed_hot"; seed_dir.mkdir(exist_ok=True)   # sibling of the AIS output
    out = base / "step_forward_ais"                              # AIS output (overwrite=True clears only this)
    lo, hi = args.hot_window_ns
    lo_f, hi_f = int(round(lo / NS_PER_FRAME)), int(round(hi / NS_PER_FRAME))

    # 1) seed window of the hot s=0.4 reference
    hot = md.load(str(HOT_REF), top=str(TOPO / "topology.pdb"))[lo_f:hi_f]
    hot.save_dcd(str(seed_dir / "trajectory.dcd"))
    shutil.copy2(TOPO / "topology.pdb", seed_dir / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(TOPO / "system_scale_1p0.prmtop"),
                   inpcrd_path=str(TOPO / "system_scale_1p0.inpcrd"),
                   gb_model="GBn2", gb_radii="mbondi3", n_solute_atoms=196,
                   timestep_fs=args.timestep_fs, friction_per_ps=1.0, temperature_k=300.0,
                   solvent="implicit"),
              open(seed_dir / "config.json", "w"), indent=2)

    excl = np.load(TOPO / "omega_exclude_bonds.npy")
    t_ais = max(1, int(round(args.switch_ps * 1000.0 / args.timestep_fs)))
    print(f"  cyclosporin forward AIS: window [{lo},{hi}] ns ({hi_f-lo_f} hot frames), "
          f"k={args.k_ais}, switch={args.switch_ps} ps ({t_ais} steps / {t_ais//args.freq_ais} windows), "
          f"omega-exclude {excl.tolist()}, platform={args.platform}")

    res = run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=args.k_ais, t_ais=t_ais, freq_ais=args.freq_ais,
        s_hot=0.4, s_cold=1.0, omega_exclude_bonds=excl,
        input_scaled_dir=seed_dir, output_dir=out, platform=args.platform,
        seed=args.seed, overwrite=True, save_traj_every_switch=False))
    disp = out.resolve().relative_to(ROOT) if out.resolve().is_relative_to(ROOT) else out
    print(f"  DONE forward AIS -> {disp} : "
          f"mean final_logw={res.get('mean_final_logw', float('nan')):.2f}, "
          f"ESS={res.get('ess', float('nan')):.1f}/{args.k_ais}")


if __name__ == "__main__":
    main()
