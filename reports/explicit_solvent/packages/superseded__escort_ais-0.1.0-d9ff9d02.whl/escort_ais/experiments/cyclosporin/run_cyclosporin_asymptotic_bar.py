#!/usr/bin/env python3
"""run_cyclosporin_asymptotic_bar.py — sequential AIS+BAR campaign for cyclosporin cold ΔΔF.

Each round grows the hot s=0.4 ensemble window, then runs forward AIS (1000 x 10 ps, hot->cold) ->
cold-MD reservoir (20 x 500 ps, s=1.0) -> reverse AIS (1000 x 10 ps, cold->hot) -> assigns endpoints
to the FIXED torsion-PCCA+ cold basins -> accumulates into the asymptotic estimator (combined-BAR +
hot-unified BAR with the per-basin BAR-overlap confidence index). Switch time fixed (default 10 ps);
overlap is a confidence/warning index only. ΔΔF is tracked live against the 500 ns REMD cold ensemble.

Resumable: each round's outputs live in <campaign>/round_XX/; a round whose reverse_ais_results.npz
exists is reused. After every round the estimator re-runs over ALL completed rounds and rewrites
asymptotic_estimates.csv + round_data.npz.

Usage:
  nohup python -m escort_ais.experiments.cyclosporin.run_cyclosporin_asymptotic_bar \
      --campaign data/cyclosporin/2026-06-23-asymptotic-bar --n-rounds 19 \
      --hot-lo 20 --hot-hi0 100 --hot-incr 50 --k 1000 --switch-ps 10 --platform CUDA \
      > <campaign>/driver.log 2>&1 &
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.asymptotic_bar import Accumulator, RoundData, estimate  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel  # noqa: E402

PY = sys.executable
TOPO = ROOT / "data/cyclosporin/topology"
TOP_PDB = TOPO / "topology.pdb"
REMD = ROOT / "data/cyclosporin/2026-06-18-rest2-remd-8rep-s0p4-250ns"


def sh(cmd: list[str], log: Path):
    """Run a pipeline step, streaming to a per-step log; raise on failure."""
    print(f"    $ {' '.join(str(c) for c in cmd)}  (-> {log.name})", flush=True)
    with open(log, "w") as fh:
        subprocess.run([str(c) for c in cmd], cwd=ROOT, check=True, stdout=fh, stderr=subprocess.STDOUT,
                       env={"PYTHONPATH": "src", "PATH": __import__("os").environ.get("PATH", "")})


def reference_ddF(model: BasinModel) -> np.ndarray:
    """REMD cold-ensemble ΔΔF on the fixed basins: -ln(p_b / p_0) from replica_00 (s=1.0)."""
    dcd = REMD / "replica_00/trajectory.dcd"
    if not dcd.exists():
        return None
    parts = [str(dcd)] + [str(p) for p in sorted((REMD / "replica_00").glob("trajectory_ext*.dcd"))]
    b = model.assign(md.load(parts, top=str(TOP_PDB)))
    p = np.bincount(b, minlength=model.n_basins).astype(float)
    p = p / p.sum()
    with np.errstate(divide="ignore"):
        return -np.log(p / p[0])


def load_round(rdir: Path, model: BasinModel) -> RoundData:
    fwd = rdir / "step_forward_ais"
    W_f = -pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    fidx = pd.read_csv(fwd / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    a_f = model.assign(md.load_dcd(str(fwd / "seed_hot/trajectory.dcd"), top=str(TOP_PDB)))[fidx] \
        if (fwd / "seed_hot/trajectory.dcd").exists() \
        else model.assign(md.load_dcd(str(rdir / "seed_hot/trajectory.dcd"), top=str(TOP_PDB)))[fidx]
    b_f = model.assign(md.load_dcd(str(fwd / "ais_final_coordinates.dcd"), top=str(TOP_PDB)))
    rev = np.load(rdir / "reverse/reverse_ais_results.npz")
    return RoundData(W_f, a_f, b_f, rev["reverse_work"], rev["reverse_cold_start_basin"],
                     rev["reverse_hot_end_basin"], hot_ns=float(np.load(rdir / "_hot_hi.npy")))


def run_round(i, rdir, args, model_path):
    rdir.mkdir(parents=True, exist_ok=True)
    hot_hi = args.hot_hi0 + args.hot_incr * i
    np.save(rdir / "_hot_hi.npy", float(hot_hi))
    fwd = rdir / "step_forward_ais"; cold = rdir / "cold_md"; rev = rdir / "reverse"

    if not (fwd / "ais_trajectory_summary.csv").exists():
        # forward runner writes seed_hot + step_forward_ais under --output-dir
        sh([PY, "src/escort_ais/experiments/cyclosporin/run_cyclosporin_forward_ais.py", "--hot-window-ns", args.hot_lo, hot_hi,
            "--k-ais", args.k, "--switch-ps", args.switch_ps, "--platform", args.platform,
            "--output-dir", rdir], rdir / "log_forward.txt")
        # forward writes step_forward_ais inside rdir already (its --output-dir==rdir)
    if not (cold / "seed_019/trajectory.dcd").exists():
        sh([PY, "src/escort_ais/systems/run_cyclosporin_cold_md.py", "--forward-dir", fwd, "--out-dir", cold,
            "--basin-model", model_path, "--n-seeds", 20, "--prod-ps", args.cold_ps,
            "--platform", args.platform], rdir / "log_cold.txt")
    if not (rev / "reverse_ais_results.npz").exists():
        sh([PY, "src/escort_ais/experiments/cyclosporin/run_cyclosporin_reverse_ais.py", "--cold-dir", cold, "--forward-dir", fwd,
            "--out-dir", rev, "--basin-model", model_path, "--n-reverse", args.k,
            "--switch-ps", args.switch_ps, "--platform", args.platform], rdir / "log_reverse.txt")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--campaign", required=True)
    ap.add_argument("--n-rounds", type=int, default=19)
    ap.add_argument("--hot-lo", type=float, default=20.0)
    ap.add_argument("--hot-hi0", type=float, default=100.0)
    ap.add_argument("--hot-incr", type=float, default=50.0)
    ap.add_argument("--k", type=int, default=1000)
    ap.add_argument("--cold-ps", type=float, default=500.0)
    ap.add_argument("--switch-ps", type=float, default=10.0)
    ap.add_argument("--torsion", choices=["backbone", "allatom"], default="backbone")
    ap.add_argument("--platform", default="CUDA")
    args = ap.parse_args()

    camp = Path(args.campaign); camp.mkdir(parents=True, exist_ok=True)
    model_path = str(ROOT / f"data/cyclosporin/basins/basin_model_{args.torsion}.pkl")
    model = BasinModel.load(Path(model_path)); nb = model.n_basins
    ref = reference_ddF(model)
    print(f"campaign={camp.name} | torsion={args.torsion} nb={nb} | "
          f"REMD reference ΔΔF={None if ref is None else np.round(ref,3).tolist()}", flush=True)

    acc = Accumulator(); rng = np.random.default_rng(20260623); rows = []
    for i in range(args.n_rounds):
        rdir = camp / f"round_{i:02d}"
        print(f"\n=== round {i:02d}  hot window [{args.hot_lo}, {args.hot_hi0+args.hot_incr*i}] ns ===", flush=True)
        run_round(i, rdir, args, model_path)
        acc.append(load_round(rdir, model))
        res = estimate(acc, nb, reference_ddF=ref, bootstrap=True, n_bootstrap=200, rng=rng)
        conf = res["confidence"]
        rows.append(dict(round=i, hot_hi_ns=args.hot_hi0 + args.hot_incr * i,
                         n_forward=res["n_forward"], n_reverse=res["n_reverse"],
                         rmse_combined=res.get("rmse_combined_covered"),
                         rmse_hotunified=res.get("rmse_hotunified_covered"),
                         **{f"cmb_b{b}": res["ddF_combined"][b] for b in range(nb)},
                         **{f"hub_b{b}": res["ddF_hotunified"][b] for b in range(nb)},
                         **{f"ovl_b{b}": res["overlap"][b] for b in range(nb)},
                         **{f"conf_b{b}": conf[b] for b in range(nb)}))
        pd.DataFrame(rows).to_csv(camp / "asymptotic_estimates.csv", index=False)
        np.savez(camp / "round_data.npz", **{f"round{i}_{k}": v for i, r in enumerate(acc.rounds)
                                             for k, v in r.__dict__.items()})
        print(f"  round {i:02d}: combined ΔΔF={np.round(res['ddF_combined'],3).tolist()} | "
              f"hot-unified={np.round(res['ddF_hotunified'],3).tolist()} | overlap="
              f"{np.round(res['overlap'],2).tolist()} | conf={conf} | "
              f"RMSE cmb={rows[-1]['rmse_combined']} hub={rows[-1]['rmse_hotunified']}", flush=True)
    print(f"\nDONE: {len(rows)} rounds -> {camp}/asymptotic_estimates.csv", flush=True)


if __name__ == "__main__":
    main()
