"""render_cyclosporin_centroids.py — element-coloured, H-bond-highlighted centroid panels (PyMOL).

Run with the open-source PyMOL in the pymol-os env:
    xvfb-run -a $PYMOL_OS_PY -m pymol -cq -r src/escort_ais/experiments/cyclosporin/render_cyclosporin_centroids.py

For each top-4 medoid (per clustering method) saved by cluster_compare_cyclosporin.py, render the
structure in a COMMON orientation (the medoids are already superposed) as a SEPARATE panel:
  * atoms coloured by element (CPK: C grey, N blue, O red, polar H white; non-polar H hidden);
  * the donor / H / acceptor of each intramolecular H-bond shown as thicker sticks;
  * the H-bond itself drawn as a bold yellow dashed line (polar-H -> acceptor) with a black outline.
H-bonds come from hbonds.json (Wernet-Nilsson, mdtraj). One PNG per medoid -> cluster250/img/.
"""
import json
import os

from pymol import cmd

ROOT = os.environ.get("CSA_ROOT", "/home/chen0040/localhome/projects/escort-ais-alanine")
_T = os.environ.get("CSA_TORSION", "backbone")
OUT = (os.path.join(ROOT, "results/cyclosporin/cluster250") if _T == "backbone"
       else os.path.join(ROOT, "results/cyclosporin", _T, "cluster250"))
IMG = os.path.join(OUT, "img"); os.makedirs(IMG, exist_ok=True)
hb = json.load(open(os.path.join(OUT, "hbonds.json")))
pdbs = sorted(hb.keys())


def cpk(obj):
    cmd.hide("everything", obj)
    cmd.show("sticks", obj)
    cmd.set("stick_radius", 0.09, obj)
    cmd.color("grey80", f"{obj} and elem C")
    cmd.color("marine", f"{obj} and elem N")
    cmd.color("red", f"{obj} and elem O")
    cmd.color("white", f"{obj} and elem H")
    cmd.hide("sticks", f"{obj} and elem H and (neighbor elem C)")   # hide non-polar H, keep polar


def base_settings():
    cmd.bg_color("white")
    cmd.set("ray_opaque_background", 1)
    cmd.set("ray_shadows", 0)
    cmd.set("antialias", 2)
    cmd.set("ray_trace_mode", 1)            # clean black outline (illustration style)
    cmd.set("ray_trace_color", "black")
    cmd.set("stick_ball", 0)
    cmd.set("dash_color", "yellow")
    cmd.set("dash_radius", 0.13)
    cmd.set("dash_gap", 0.30)
    cmd.set("dash_round_ends", 1)


# ── pass 1: common camera from all aligned medoids ──
cmd.reinitialize()
for i, rel in enumerate(pdbs):
    cmd.load(os.path.join(OUT, rel), f"m{i}")
cmd.hide("everything"); cmd.show("sticks"); cmd.orient()
VIEW = cmd.get_view()

# ── pass 2: one panel per medoid, same view ──
for rel in pdbs:
    cmd.reinitialize()
    base_settings()
    cmd.load(os.path.join(OUT, rel), "m")
    cpk("m")
    atoms = []
    for n, (h, a) in enumerate(hb[rel]["pairs"]):                  # (polar-H, acceptor) 0-based
        cmd.distance(f"hb{n}", f"m and index {h+1}", f"m and index {a+1}")
        cmd.hide("labels", f"hb{n}")
        atoms += [h + 1, a + 1]
    if atoms:
        sel = "m and index " + "+".join(str(x) for x in atoms)
        # emphasise donor/H/acceptor (and the donor heavy atom bonded to each polar H)
        cmd.show("sticks", f"({sel}) or (m and neighbor ({sel}))")
        cmd.set("stick_radius", 0.17, f"({sel}) or (m and (neighbor ({sel})) and not elem C)")
    cmd.set_view(VIEW)
    out = os.path.join(IMG, os.path.basename(rel).replace(".pdb", ".png"))
    cmd.ray(1100, 950); cmd.png(out, dpi=150)
    print(f"  rendered {os.path.basename(out)}  ({len(hb[rel]['pairs'])} H-bonds)")
print("done")
