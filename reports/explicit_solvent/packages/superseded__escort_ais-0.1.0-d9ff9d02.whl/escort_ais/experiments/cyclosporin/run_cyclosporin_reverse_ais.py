#!/usr/bin/env python3
"""run_cyclosporin_reverse_ais.py — reverse AIS for cyclosporin (cold s=1.0 -> hot s=0.4).

Reverse starts are drawn UNIFORMLY within each fixed torsion-PCCA+ cold basin (no RITE) from the
20 x 500 ps cold-MD reservoir (first 50 ps of each seed discarded), with the total N_REVERSE
trajectories allocated across basins in proportion to the forward-AIS cold-endpoint landing ratio.
Runs reverse AIS on the SAME GBn2/mbondi3, omega-selective Hamiltonian as the forward leg (10 ps
switch by default). Produces W_r = -final_logw for the two-sided BAR.

Output: <out-dir>/{seed_cold_uniform/, step_reverse_ais/, reverse_ais_results.npz, reverse_start_table.csv}
Usage:
  python -m escort_ais.experiments.cyclosporin.run_cyclosporin_reverse_ais \
      --cold-dir data/cyclosporin/<round>/cold_md \
      --forward-dir data/cyclosporin/<round>/step_forward_ais \
      --out-dir data/cyclosporin/<round>/reverse --switch-ps 10 --platform CUDA
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel  # noqa: E402

TOPO = ROOT / "data/cyclosporin/topology"
TOP_PDB = TOPO / "topology.pdb"
BURN_PS = 50          # discard first 50 ps of each 500 ps cold seed
N_REVERSE = 1000


def largest_remainder(weights, total):
    w = np.asarray(weights, float); w = w / w.sum()
    raw = w * total; base = np.floor(raw).astype(int)
    for i in np.argsort(-(raw - base))[: total - base.sum()]:
        base[i] += 1
    return base


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cold-dir", required=True, help="cold-MD reservoir dir (seed_XXX/)")
    ap.add_argument("--forward-dir", required=True, help="step_forward_ais dir (cold endpoints -> landing)")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--basin-model", default=str(ROOT / "data/cyclosporin/basins/basin_model_backbone.pkl"))
    ap.add_argument("--n-reverse", type=int, default=N_REVERSE)
    ap.add_argument("--switch-ps", type=float, default=10.0)
    ap.add_argument("--freq-ais", type=int, default=10)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--seed", type=int, default=20260623)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    model = BasinModel.load(Path(args.basin_model))
    nb = model.n_basins
    burn = int(round(BURN_PS / 1.0))   # 1 ps/frame

    # cold-MD reservoir: pooled frames + torsion-basin labels (drop burn-in)
    res_xyz, res_basin = [], []
    seeds = sorted((Path(args.cold_dir)).glob("seed_*/trajectory.dcd"))
    for dcd in seeds:
        tr = md.load_dcd(str(dcd), top=str(TOP_PDB))[burn:]
        res_xyz.append(tr.xyz); res_basin.append(model.assign(tr))
    top0 = md.load_dcd(str(seeds[0]), top=str(TOP_PDB)).topology
    res_xyz = np.concatenate(res_xyz); res_basin = np.concatenate(res_basin)
    reservoir_pop = np.bincount(res_basin, minlength=nb)

    # forward landing ratio (forward cold endpoints assigned to the same fixed basins)
    fep = md.load_dcd(str(Path(args.forward_dir) / "ais_final_coordinates.dcd"), top=str(TOP_PDB))
    land = np.bincount(model.assign(fep), minlength=nb).astype(float)

    usable = np.array([b for b in range(nb) if land[b] > 0 and reservoir_pop[b] > 0])
    alloc = largest_remainder(land[usable], args.n_reverse)
    n_for = {int(b): int(a) for b, a in zip(usable, alloc)}
    print(f"  basins={nb} | reservoir_pop={reservoir_pop.tolist()} | forward landing={land.astype(int).tolist()}")
    print(f"  reverse allocation (forward-ratio, uniform draws): {n_for}")

    xyz, rows, start_basin = [], [], []
    for B in usable:
        idx_B = np.where(res_basin == B)[0]
        pick = rng.choice(idx_B, n_for[int(B)], replace=True)
        for p in pick:
            xyz.append(res_xyz[p]); start_basin.append(int(B))
            rows.append(dict(reverse_start_frame_id=len(rows), basin=int(B), pool=int(len(idx_B))))
    pd.DataFrame(rows).to_csv(out_dir / "reverse_start_table.csv", index=False)
    start_basin = np.array(start_basin)
    print(f"  reverse starts: {len(rows)} ({[int((start_basin == B).sum()) for B in usable]} per usable basin)")

    # seed dir + config carrying gb_radii so ais_linear engages the parmed/mbondi3 path
    seed_dir = out_dir / "seed_cold_uniform"; seed_dir.mkdir(parents=True, exist_ok=True)
    md.Trajectory(np.array(xyz), top0).save_dcd(str(seed_dir / "trajectory.dcd"))
    shutil.copy2(TOP_PDB, seed_dir / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(TOPO / "system_scale_1p0.prmtop"),
                   inpcrd_path=str(TOPO / "system_scale_1p0.inpcrd"),
                   gb_model="GBn2", gb_radii="mbondi3", n_solute_atoms=196,
                   timestep_fs=args.timestep_fs, friction_per_ps=1.0, temperature_k=300.0,
                   solvent="implicit"),
              open(seed_dir / "config.json", "w"), indent=2)

    excl = np.load(TOPO / "omega_exclude_bonds.npy")
    t_ais = max(1, int(round(args.switch_ps * 1000.0 / args.timestep_fs)))
    out = out_dir / "step_reverse_ais"
    print(f"  running reverse AIS: {len(xyz)} trajs, {args.switch_ps} ps (cold s=1.0 -> hot s=0.4) ...")
    run_linear_scaling_ais(LinearAISConfig(
        solvent="implicit", k_ais=len(xyz), t_ais=t_ais, freq_ais=args.freq_ais,
        s_hot=1.0, s_cold=0.4, omega_exclude_bonds=excl,
        start_frame_offset=0, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=out, platform=args.platform,
        seed=args.seed, overwrite=True, save_traj_every_switch=False))

    logw_r = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    sel = pd.read_csv(out / "selected_initial_frames.csv")["initial_frame_index"].astype(int).to_numpy()
    cold_start = start_basin[sel]
    hot_end = model.assign(md.load_dcd(str(out / "ais_final_coordinates.dcd"), top=str(TOP_PDB)))
    np.savez(out_dir / "reverse_ais_results.npz", reverse_lnw=logw_r, reverse_work=-logw_r,
             reverse_cold_start_basin=cold_start, reverse_hot_end_basin=hot_end)
    print(f"  reverse AIS done: {len(logw_r)} trajs. cold-start counts={np.bincount(cold_start, minlength=nb).tolist()}")


if __name__ == "__main__":
    main()
