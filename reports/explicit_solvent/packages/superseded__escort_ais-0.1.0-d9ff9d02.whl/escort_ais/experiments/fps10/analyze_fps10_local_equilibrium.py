#!/usr/bin/env python3
"""analyze_fps10_local_equilibrium.py — per-basin (intra-basin) JS of the FPS-10x100ns runs vs REMD.

Within each reference basin B (major/minor, GeometricBasinModel), define sub-wells by KMeans on REMD's own
frames in B (the reference fine partition), then measure JS( P(sub-well | B) , P_REMD(sub-well | B) ) for
  - each finished 100 ns run (frames it has in B),
  - the pooled 100 ns runs,
  - the pooled 86x5 ns reservoir  (apples-to-apples baseline: same basins, same sub-wells).
Low JS => the run reached intra-basin local equilibrium; JS -> ln2 (0.693) => frozen in a disjoint sub-well.

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_local_equilibrium
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pickle
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

EXP_ROOT = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
KSUB = 12
BURN = 50                                                            # ps burn (1 ps/frame)


def js(a, b, e=1e-12):
    a = np.asarray(a, float) + e; a /= a.sum(); b = np.asarray(b, float) + e; b /= b.sum()
    m = 0.5 * (a + b)
    return float(0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m)))


def process(NAME):
    EXP = EXP_ROOT / NAME
    COLD5 = BE / NAME / "cold_md"                                    # the ~86 x 5 ns reservoir
    cfg = load_cfg(NAME); q, _, _ = load_quartets(cfg.topo, "backbone")
    ref = pickle.load(open(cfg.basin_model_path, "rb"))
    NB = ref.n_basins
    remd = load_remd_ensemble(REMD[NAME], "replica_00", cfg.top_pdb, 0)
    rlab = ref.assign(remd); rX = featurize(remd, q)

    # per-basin sub-well partition on REMD's own frames + REMD reference histogram
    subkm, pr_ref = {}, {}
    for B in range(NB):
        XB = rX[rlab == B]
        subkm[B] = KMeans(KSUB, n_init=6, random_state=0).fit(XB)
        pr_ref[B] = np.bincount(subkm[B].predict(XB), minlength=KSUB)

    def basin_js(dcds, top_of):
        """pooled sub-well histogram per basin over a set of trajectories -> JS vs REMD; also per-traj."""
        pooled = {B: np.zeros(KSUB) for B in range(NB)}
        per = []
        for d in dcds:
            top = top_of(d)
            tr = md.load_dcd(str(Path(d) / "trajectory.dcd"), top=top)[BURN:]
            lab = ref.assign(tr); X = featurize(tr, q)
            rec = {"seed": Path(d).name}
            for B in range(NB):
                XB = X[lab == B]
                if len(XB) >= 300:
                    hB = np.bincount(subkm[B].predict(XB), minlength=KSUB)
                    pooled[B] += hB
                    rec[f"js_B{B}"] = round(js(hB, pr_ref[B]), 3)
                    rec[f"n_B{B}"] = int(len(XB))
            per.append(rec)
        pooled_js = {B: round(js(pooled[B], pr_ref[B]), 4) for B in range(NB) if pooled[B].sum() > 0}
        return pooled_js, per, pooled

    finished = sorted(d for d in glob.glob(str(EXP / "cold_md/seed_*"))
                      if Path(d, "final_structure.pdb").exists())
    seeds5 = sorted(glob.glob(str(COLD5 / "seed_*")))

    top100 = lambda d: str(Path(d) / "final_structure.pdb")
    top5 = lambda d: str(Path(d) / "final_structure.pdb")
    js100, per100, _ = basin_js(finished, top100)
    js5, _, _ = basin_js(seeds5, top5)

    bname = {0: "major", 1: "minor"}
    print(f"REMD basins: {[round(x,3) for x in np.bincount(rlab,minlength=NB)/len(rlab)]}  "
          f"(sub-wells KSUB={KSUB} on REMD)\n", file=sys.stderr)
    print("PER-BASIN JS (pooled) — lower = closer to REMD local equilibrium (ln2=0.693 ceiling):", file=sys.stderr)
    for B in range(NB):
        j100 = js100.get(B); j5 = js5.get(B)
        print(f"  basin {B} ({bname.get(B,B)}):  100ns pooled JS = {j100}   |   5ns reservoir pooled JS = {j5}",
              file=sys.stderr)
    print("\nPER-RUN JS (100 ns runs):", file=sys.stderr)
    for r in per100:
        cols = "  ".join(f"B{B}={r.get(f'js_B{B}')}(n={r.get(f'n_B{B}')})" for B in range(NB) if f'js_B{B}' in r)
        print(f"  {r['seed']}: {cols}", file=sys.stderr)

    out = dict(name=NAME, ksub=KSUB, remd_basin_pop=[round(x, 3) for x in np.bincount(rlab, minlength=NB) / len(rlab)],
               pooled_js_100ns={bname.get(B, B): v for B, v in js100.items()},
               pooled_js_5ns={bname.get(B, B): v for B, v in js5.items()},
               per_run_100ns=per100)
    (EXP / "local_equilibrium_vs_remd.json").write_text(json.dumps(out, indent=2))


def main():
    for name in (sys.argv[1:] or ["rgd"]):
        print(f"\n===== {name} =====", file=sys.stderr)
        process(name)


if __name__ == "__main__":
    main()
