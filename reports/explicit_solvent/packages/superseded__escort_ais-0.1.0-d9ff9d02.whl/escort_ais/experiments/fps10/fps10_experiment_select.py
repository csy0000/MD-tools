#!/usr/bin/env python3
"""fps10_experiment_select.py — torsional-FPS selection of 10 distinct states from the 1000x5ps AIS landings.

Experiment (any of rgd / cilengitide / rgd_redPheVal): after the first AIS landing at 60 ns hot, 1000 AIS
trajectories x 5 ps switch were run (reused from data/rgd/diagnostics/bais_eval/<name>/gen0/fwd/,
generations.json gen0: hot_ns=60, switch_ps=5, k_fwd=1000). This step does torsional farthest-point sampling
(FPS in sin/cos backbone-dihedral space) on those 1000 cold landings to pick the 10 MOST DISTINCT conformers,
and writes them as seed PDBs for 100 ns cold MD from each.

    conda activate escort-ais && python -m escort_ais.experiments.fps10.fps10_experiment_select <name>
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.systems.build_macrocycle_cold_reservoir import fps_indices  # noqa: E402

EXP_ROOT = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
BE = ROOT / "data/rgd/diagnostics/bais_eval"
N_PICK = 10


def select(name):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone")
    fwd = BE / name / "gen0/fwd"
    exp = EXP_ROOT / name
    landings = md.load_dcd(str(fwd / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    logw = pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    assert len(landings) == len(logw), (len(landings), len(logw))
    print(f"[{name}] {len(landings)} AIS landings (5 ps switch); logw [{logw.min():.1f},{logw.max():.1f}]",
          file=sys.stderr)

    X = featurize(landings, np.asarray(q))
    seed0 = int(np.argmax(logw))
    sel = fps_indices(X, N_PICK, seed0)

    dmin_trace = []; dmin = np.linalg.norm(X - X[sel[0]], axis=1)
    for gi in sel[1:]:
        dmin_trace.append(round(float(dmin[gi]), 4))
        dmin = np.minimum(dmin, np.linalg.norm(X - X[gi], axis=1))

    seed_dir = exp / "cold_seeds"; seed_dir.mkdir(parents=True, exist_ok=True)
    for j, gi in enumerate(sel):
        landings[int(gi)].save_pdb(str(seed_dir / f"seed_{j:03d}.pdb"))
    (exp / "fps_selection.json").write_text(json.dumps(dict(
        name=name, source=str(fwd.relative_to(ROOT)), n_landings=int(len(landings)), n_pick=N_PICK,
        fps_space="backbone sin/cos dihedrals (torsional FPS)", seed0_landing=seed0,
        selected_landing_idx=[int(x) for x in sel],
        selected_logw=[round(float(logw[i]), 3) for i in sel], fps_min_distance_at_pick=dmin_trace), indent=2))
    print(f"[{name}] selected {N_PICK} -> {seed_dir}  idx={[int(x) for x in sel]}  "
          f"dmin@pick={dmin_trace}", file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd"]):
        select(name)


if __name__ == "__main__":
    main()
