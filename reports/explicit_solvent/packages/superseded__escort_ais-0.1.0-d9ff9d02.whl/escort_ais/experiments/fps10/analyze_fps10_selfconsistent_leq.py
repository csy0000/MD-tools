#!/usr/bin/env python3
"""analyze_fps10_selfconsistent_leq.py — Phase 2: REMD-free JSD-consistency LEQ estimator (rgd, budget T=5+5i).

Architecture (per the user's spec, corrected):
  * KMeans(k=100) sub-wells fit on the pooled first 5 ns (fixed).
  * KCC = strongly-connected components of the cold-MD transition matrix (lag 20) SPLIT the data into basins;
    discard trap SCCs (≈0 forward-AIS landing). For rgd this yields ONE real basin (the SCC holding all the
    REMD population); the trap SCCs are dropped. (PCCA+ inside a basin would further split it, but the rgd
    basin has no kinetic sub-structure.)
  * NO residence gate. Instead, per basin, fragment each seed's 0→T ns into continuous basin-residence pieces,
    SORT by residence (longest first), and grow p̂ as a running (frame-weighted) mean of fragment sub-well
    histograms; **STOP** at the first fragment with JSD(p̂, p_i) > 0.1 (leading consistent block). Also compute
    the **SKIP** variant (skip divergent, keep scanning). The JSD-consistency replaces the residence gate: long
    mixing fragments have broad, mutually-consistent histograms and accumulate; frozen fragments are spiky and
    are rejected.
  * Validate: JSD(p̂(·|B), REMD(·|B)) vs the budget T (REMD used ONLY for validation).

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_selfconsistent_leq [name]
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.ndimage import median_filter
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.common.artifact_quarantine import forward_weight_per_microstate  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_rite_local_equilibrium import _js  # noqa: E402

EXP = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"}
OUT = ROOT / "results/rgd/report"
KMICRO, LAG, FPN, WFRAC = 100, 20, 1000, 1e-3
SMOOTH, MINFRAG, JSD_CUT = 51, 300, 0.1        # 51 ps median filter; 300-frame min fragment; consistency cut
TS = [5, 10, 20, 30, 50, 75, 100]


def count_matrix(dtrajs):
    C = np.zeros((KMICRO, KMICRO))
    for d in dtrajs:
        if len(d) > LAG:
            np.add.at(C, (d[:-LAG], d[LAG:]), 1.0)
    return C


def fragments_in_basin(dtrajs, bmicros):
    """continuous-residence fragments (sub-well histogram + residence length) for basin = set bmicros."""
    frags = []
    for d in dtrajs:
        inB = median_filter(np.isin(d, bmicros).astype(int), size=SMOOTH, mode="nearest") > 0
        i = 0
        while i < len(inB):
            if not inB[i]:
                i += 1; continue
            j = i
            while j < len(inB) and inB[j]:
                j += 1
            if j - i >= MINFRAG:
                h = np.bincount(d[i:j], minlength=KMICRO).astype(float)
                frags.append((j - i, h))                       # (residence frames, histogram)
            i = j
    return frags


def accumulate(frags, mode):
    """sort by residence desc; grow p̂ as frame-weighted running mean; STOP or SKIP at JSD>JSD_CUT."""
    order = sorted(range(len(frags)), key=lambda k: -frags[k][0])
    acc = None; kept = 0
    for k in order:
        h = frags[k][1]
        if acc is None:
            acc = h.copy(); kept = 1; continue
        if _js(acc, h) > JSD_CUT:
            if mode == "stop":
                break
            continue                                            # skip
        acc = acc + h; kept += 1
    return (acc / acc.sum() if acc is not None else None), kept


def process(name):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone")
    seeds = sorted(d for d in glob.glob(str(EXP / name / "cold_md/seed_*"))
                   if Path(d, "final_structure.pdb").exists())
    feats = [featurize(md.load_dcd(str(Path(d) / "trajectory.dcd"), top=str(Path(d) / "final_structure.pdb")), q)
             for d in seeds]
    km = KMeans(KMICRO, n_init=4, random_state=0).fit(np.concatenate([f[:5 * FPN] for f in feats]))
    dfull = [km.predict(f) for f in feats]
    fwd = BE / name / "gen0/fwd"
    land = md.load_dcd(str(fwd / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    logw = pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    p_land = forward_weight_per_microstate(km, featurize(land, q), logw)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    rm = km.predict(featurize(remd, q))

    rows = []
    for T in TS:
        d = [dd[:T * FPN] for dd in dfull]
        n, comp = connected_components(csr_matrix(count_matrix(d) > 0), directed=True, connection="strong")
        cold = np.bincount(np.concatenate(d), minlength=KMICRO)
        pl_scc = np.array([p_land[comp == c].sum() for c in range(n)])
        cold_scc = np.array([cold[comp == c].sum() for c in range(n)])
        basins = [c for c in range(n) if pl_scc[c] >= WFRAC and cold_scc[c] > 0]
        dom = basins[int(np.argmax([pl_scc[c] for c in basins]))]     # the real (forward-heavy) basin
        bmicros = np.where(comp == dom)[0]
        remd_hist = np.bincount(rm[np.isin(rm, bmicros)], minlength=KMICRO).astype(float)
        frags = fragments_in_basin(d, bmicros)
        rec = {"T": T, "n_scc": int(n), "n_basins": len(basins), "dom_size": int(len(bmicros)),
               "dom_p_land": round(float(pl_scc[dom]), 3), "n_fragments": len(frags)}
        for mode in ("stop", "skip"):
            phat, kept = accumulate(frags, mode)
            rec[f"js_{mode}"] = round(_js(phat, remd_hist), 4) if phat is not None else None
            rec[f"kept_{mode}"] = kept
        # baseline: unweighted pool of ALL basin frames vs REMD
        allh = np.sum([h for _, h in frags], axis=0) if frags else np.zeros(KMICRO)
        rec["js_allpool"] = round(_js(allh, remd_hist), 4) if frags else None
        rows.append(rec)
        print(f"  T={T:3d}ns  basin {len(bmicros)} micro (p_land {pl_scc[dom]:.2f}) | {len(frags)} frags | "
              f"JSD→REMD  all={rec['js_allpool']}  STOP={rec['js_stop']}(n={rec['kept_stop']})  "
              f"SKIP={rec['js_skip']}(n={rec['kept_skip']})", file=sys.stderr)
    (EXP / name / "selfconsistent_leq.json").write_text(json.dumps({"name": name, "rows": rows}, indent=2))
    make_figure(name, rows)


def make_figure(name, rows):
    T = [r["T"] for r in rows]
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    ax[0].plot(T, [r["js_allpool"] for r in rows], "-o", c="0.6", label="all basin frames (no selection)")
    ax[0].plot(T, [r["js_stop"] for r in rows], "-o", c="C0", label="JSD-consistency STOP")
    ax[0].plot(T, [r["js_skip"] for r in rows], "-s", c="C2", label="JSD-consistency SKIP")
    ax[0].axhline(0.1, ls=":", c="0.4", lw=1); ax[0].set_xlabel("adaptive budget T (ns)")
    ax[0].set_ylabel(r"JSD($\hat p$, REMD($\cdot|B$))"); ax[0].set_title(f"{name}: does $\\hat p$ converge to REMD?")
    ax[0].legend(fontsize=8)
    ax[1].plot(T, [r["n_fragments"] for r in rows], "-o", c="C1", label="# fragments")
    ax[1].plot(T, [r["kept_stop"] for r in rows], "-o", c="C0", label="kept (STOP)")
    ax[1].plot(T, [r["kept_skip"] for r in rows], "-s", c="C2", label="kept (SKIP)")
    ax[1].set_xlabel("adaptive budget T (ns)"); ax[1].set_ylabel("# fragments")
    ax[1].set_title("fragments available vs accepted"); ax[1].legend(fontsize=8)
    fig.tight_layout(); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_selfconsistent_leq.png", dpi=140); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_selfconsistent_leq.png'}", file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd"]):
        print(f"\n===== {name} =====", file=sys.stderr)
        process(name)


if __name__ == "__main__":
    main()
