#!/usr/bin/env python3
"""analyze_fps10_selfconsistent_leq_diagnose.py — Phase 1: look before cutting.

Self-consistent, REMD-free LEQ pipeline DIAGNOSTIC on the 100 ns FPS runs (rgd). Runs the definition steps at
the full T=100 ns and characterizes the fragment population so we can CHOOSE the sub-well gate from the data
instead of hard-coding 1 ns:
  1. KMeans(k=100) sub-wells fit on the pooled first 5 ns (fixed fine partition).
  2. cold-MD transition counts (lag 20) -> deeptime largest connected set = the ergodic core; the rest are
     kinetically ISOLATED microstates (KCC). Of the isolated, flag those with ~0 forward-AIS landing weight
     (artifacts).
  3. PCCA+ on the connected core -> n_B metastable basins (n_B from the spectral gap, clamp 2..4).
  4. Fragment each seed's 5->100 ns into continuous basin-residence pieces (median-filtered, no gate).
  5. PLOT: R_sw & R_basin distributions; per-fragment JSD-to-REMD(.|B) vs R_sw (where is the knee? is 1 ns
     right/too strict?); candidate p_hat(.|B) shapes vs REMD. REMD is used for VALIDATION only.

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_selfconsistent_leq_diagnose [name]
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.ndimage import median_filter
from sklearn.cluster import KMeans
from deeptime.markov import TransitionCountEstimator
from deeptime.markov.msm import MaximumLikelihoodMSM

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.common.artifact_quarantine import forward_weight_per_microstate  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_rite_local_equilibrium import _js  # noqa: E402
from escort_ais.analysis.analyze_fps10_residence_vs_leq import segment_episodes  # noqa: E402

EXP = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"}
OUT = ROOT / "results/rgd/report"
KMICRO, LAG, FPN = 100, 20, 1000        # 100 microstates, lag 20 ps, 1000 frames/ns (1 ps/frame)
DEF_NS, SMOOTH, TAU_MIN, WFRAC = 5, 51, 200, 1e-3   # first 5 ns defines KMeans; 51 ps median; 200 ps dwell


def maxrun(a):
    b = cur = 1
    for i in range(1, len(a)):
        cur = cur + 1 if a[i] == a[i - 1] else 1; b = max(b, cur)
    return b


def pick_nB(msm, lo=2, hi=4):
    ev = np.real(msm.eigenvalues(min(hi + 2, msm.n_states)))
    ev = np.sort(ev)[::-1]
    gaps = {n: ev[n - 1] - ev[n] for n in range(lo, min(hi, len(ev) - 1) + 1)}
    return max(gaps, key=gaps.get), {int(k): round(float(v), 3) for k, v in gaps.items()}


def process(name):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone")
    seeds = sorted(d for d in glob.glob(str(EXP / name / "cold_md/seed_*"))
                   if Path(d, "final_structure.pdb").exists())
    feats = [featurize(md.load_dcd(str(Path(d) / "trajectory.dcd"), top=str(Path(d) / "final_structure.pdb")), q)
             for d in seeds]
    # 1. KMeans on pooled first DEF_NS
    first = np.concatenate([f[:DEF_NS * FPN] for f in feats])
    km = KMeans(KMICRO, n_init=4, random_state=0).fit(first)
    dtrajs = [km.predict(f) for f in feats]                             # full-length microstate trajs

    # 2. connected core (largest SCC) via deeptime; isolated = the rest
    counts = TransitionCountEstimator(lagtime=LAG, count_mode="sliding").fit_fetch(dtrajs)
    sub = counts.submodel_largest()
    connected = set(int(s) for s in sub.state_symbols)
    isolated = [m for m in range(KMICRO) if m not in connected]
    # forward-AIS landing weight per microstate
    fwd = BE / name / "gen0/fwd"
    land = md.load_dcd(str(fwd / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    logw = pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    p_land = forward_weight_per_microstate(km, featurize(land, q), logw)
    artifacts = [m for m in isolated if p_land[m] < WFRAC]

    # 3. PCCA+ on connected core
    msm = MaximumLikelihoodMSM(reversible=True).fit_fetch(sub)
    n_B, gaps = pick_nB(msm)
    pcca = msm.pcca(n_B)
    basin_of = np.full(KMICRO, -1, int)
    for i, sym in enumerate(sub.state_symbols):
        basin_of[int(sym)] = int(pcca.assignments[i])

    # REMD reference per microstate / basin (validation only)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    rm = km.predict(featurize(remd, q))
    remd_hist = {B: np.bincount(rm[basin_of[rm] == B], minlength=KMICRO).astype(float) for B in range(n_B)}
    basin_pop = {B: int((basin_of[rm] == B).sum()) for B in range(n_B)}

    # 4. fragment 5->100 ns by continuous basin residence (no gate); per-fragment R_sw, R_basin, JSD-to-REMD
    frags = []
    for d in dtrajs:
        rest = d[DEF_NS * FPN:]
        bseq = median_filter(basin_of[rest], size=SMOOTH, mode="nearest")
        _, eps = segment_episodes(bseq, TAU_MIN)
        for (B, s, L) in eps:
            micros = rest[s:s + L]
            h = np.bincount(micros, minlength=KMICRO).astype(float)
            frags.append(dict(basin=int(B), r_sw=maxrun(micros) / FPN, r_basin=L / FPN,
                              jsd=round(_js(h, remd_hist[B]), 4), hist=h))
    print(f"\n===== {name} @ T=100 ns =====", file=sys.stderr)
    print(f"  connected microstates {len(connected)}/{KMICRO} | isolated {len(isolated)} "
          f"(artifacts, ~0 fwd-landing: {len(artifacts)}) | PCCA n_B={n_B} gaps={gaps}", file=sys.stderr)
    print(f"  REMD basin pops (frames): {basin_pop}", file=sys.stderr)
    print(f"  fragments: {len(frags)} | R_sw med {np.median([f['r_sw'] for f in frags]):.2f} ns, "
          f"R_basin med {np.median([f['r_basin'] for f in frags]):.2f} ns", file=sys.stderr)

    make_figure(name, frags, remd_hist, basin_of, n_B, len(connected), len(isolated), len(artifacts))
    summary = dict(name=name, n_connected=len(connected), n_isolated=len(isolated), n_artifacts=len(artifacts),
                   n_B=n_B, gaps=gaps, basin_pop=basin_pop, n_fragments=len(frags),
                   fragments=[{k: v for k, v in f.items() if k != "hist"} for f in frags])
    (EXP / name / "selfconsistent_leq_diagnose.json").write_text(json.dumps(summary, indent=2))


def make_figure(name, frags, remd_hist, basin_of, n_B, nc, niso, nart):
    R_sw = np.array([f["r_sw"] for f in frags]); R_bas = np.array([f["r_basin"] for f in frags])
    JS = np.array([f["jsd"] for f in frags]); Bs = np.array([f["basin"] for f in frags])
    fig, ax = plt.subplots(2, 2, figsize=(12, 9))
    ax[0, 0].hist(R_sw, bins=30, color="C0", alpha=0.8)
    ax[0, 0].axvline(1.0, c="C1", lw=2, label="1 ns (proposed cut)")
    ax[0, 0].set_xlabel("fragment sub-well residence $R_{sw}$ (ns)"); ax[0, 0].set_ylabel("# fragments")
    ax[0, 0].set_title("(a) $R_{sw}$ distribution"); ax[0, 0].legend(fontsize=8)
    ax[0, 1].hist(R_bas, bins=30, color="C2", alpha=0.8)
    ax[0, 1].set_xlabel("fragment basin residence $R_{basin}$ (ns)"); ax[0, 1].set_ylabel("# fragments")
    ax[0, 1].set_title("(b) $R_{basin}$ distribution")
    cols = plt.cm.tab10(np.linspace(0, 1, n_B))
    for B in range(n_B):
        m = Bs == B
        ax[1, 0].scatter(R_sw[m], JS[m], s=22, color=cols[B], alpha=0.7, edgecolor="k", lw=0.2,
                         label=f"basin {B}")
    ax[1, 0].axvline(1.0, c="C1", lw=2); ax[1, 0].axhline(0.1, c="0.4", ls="--", lw=1, label="JSD=0.1")
    ax[1, 0].set_xlabel("fragment $R_{sw}$ (ns)"); ax[1, 0].set_ylabel("fragment JSD to REMD(.|B)")
    ax[1, 0].set_title("(c) per-fragment JSD vs $R_{sw}$ — where is the knee? is 1 ns too strict?")
    ax[1, 0].legend(fontsize=7)
    # (d) candidate p_hat: pooled fragment hist per basin vs REMD, over that basin's microstates
    for B in range(n_B):
        micros = np.where(basin_of == B)[0]
        if not len(micros):
            continue
        pooled = np.sum([f["hist"] for f in frags if f["basin"] == B], axis=0)
        o = np.argsort(-remd_hist[B][micros])
        pr = remd_hist[B][micros][o]; pc = pooled[micros][o]
        ax[1, 1].plot(np.arange(len(micros)), pr / pr.sum(), "-", color=cols[B], lw=2,
                      label=f"REMD B{B}")
        ax[1, 1].plot(np.arange(len(micros)), pc / pc.sum(), "--", color=cols[B], lw=1.4, alpha=0.7,
                      label=f"cold-frag B{B}")
    ax[1, 1].set_xlabel("within-basin microstate (sorted by REMD)"); ax[1, 1].set_ylabel("population")
    ax[1, 1].set_title("(d) candidate $\\hat p(\\cdot|B)$: pooled cold fragments vs REMD"); ax[1, 1].legend(fontsize=7)
    fig.suptitle(f"{name} self-consistent LEQ — Phase-1 diagnostics @ T=100 ns  "
                 f"(connected {nc}/100, isolated {niso}, artifacts {nart}, n_B={n_B})", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.97]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_selfconsistent_leq_diagnose.png", dpi=130); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_selfconsistent_leq_diagnose.png'}", file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd"]):
        process(name)


if __name__ == "__main__":
    main()
