#!/usr/bin/env python3
"""analyze_fps10_coverage.py — did the FPS-10x100ns cold runs COVER every REMD-populated region?

Population TV to REMD (basins_vs_remd.json) says nothing about coverage: a basin can be visited but mis-
weighted, or a small REMD region missed entirely. This audits coverage directly, at two granularities, using
REMD as the ground truth for "what should be covered":

  BASIN level  -- REMD density basins (HDBSCAN, sin/cos backbone dihedrals; same as analyze_fps10_leq_
    convergence). For each REMD basin: its REMD population, the pooled-100ns cold population, and how many of
    the 10 seeds ever visit it (>= MINSEED frames). A REMD basin with ~0 cold population is a MISSED basin.
  MICROSTATE level -- KMeans(K=30) on REMD frames (finer regions). A REMD microstate is COVERED if the pooled
    cold frames put >= MINC frames there (nearest-centroid). "Missed REMD mass" = sum of REMD populations of
    uncovered microstates = the fraction of the REMD equilibrium distribution the 100 ns runs never sampled.

Also reports the reverse (cold-only regions REMD never visits) for completeness -- those are the known trap
artifacts, not a coverage gap.

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_coverage [name...]
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_fps10_leq_convergence import density_basins, REMD, EXP_ROOT, OUT, BURN  # noqa: E402

KFINE = 30                      # REMD microstates (fine coverage grid)
MINC = 50                       # min pooled-cold frames for a REMD microstate to count as covered
MINSEED = 300                   # min frames for a seed to "visit" a basin
REMD_FLOOR = 0.005              # a REMD microstate/basin is "important" if its REMD pop >= this


def process(NAME):
    rng = np.random.default_rng(0)
    cfg = load_cfg(NAME); q, _, _ = load_quartets(cfg.topo, "backbone")
    remd = load_remd_ensemble(REMD[NAME], "replica_00", cfg.top_pdb, 0)
    Xr = featurize(remd, q)
    rlab, knn, NB, noise = density_basins(Xr, rng)
    pop_b = np.bincount(rlab, minlength=NB) / len(rlab)
    # fine REMD microstates
    km = KMeans(KFINE, n_init=6, random_state=0).fit(Xr)
    rmicro = km.predict(Xr)
    pop_m = np.bincount(rmicro, minlength=KFINE) / len(rmicro)

    # pool all finished 100 ns cold seeds
    finished = sorted(d for d in glob.glob(str(EXP_ROOT / NAME / "cold_md/seed_*"))
                      if Path(d, "final_structure.pdb").exists())
    cold_b = np.zeros(NB); cold_m = np.zeros(KFINE); ncold = 0
    seed_hits = np.zeros(NB, int)                                    # seeds visiting each basin
    for d in finished:
        tr = md.load_dcd(str(Path(d) / "trajectory.dcd"), top=str(Path(d) / "final_structure.pdb"))[BURN:]
        X = featurize(tr, q)
        b = knn.predict(X); m = km.predict(X)
        cold_b += np.bincount(b, minlength=NB); cold_m += np.bincount(m, minlength=KFINE); ncold += len(X)
        for B in range(NB):
            if (b == B).sum() >= MINSEED:
                seed_hits[B] += 1
    cold_bp = cold_b / cold_b.sum(); cold_mp = cold_m / cold_m.sum()

    # coverage verdicts
    imp_b = [B for B in range(NB) if pop_b[B] >= REMD_FLOOR]
    missed_b = [B for B in imp_b if cold_b[B] < MINC]
    imp_m = [k for k in range(KFINE) if pop_m[k] >= REMD_FLOOR]
    covered_m = [k for k in imp_m if cold_m[k] >= MINC]
    missed_m = [k for k in imp_m if cold_m[k] < MINC]
    missed_mass = float(sum(pop_m[k] for k in missed_m))            # REMD equilibrium mass never sampled
    # reverse: cold-only microstates REMD never visits (known trap artifacts)
    cold_only = [k for k in range(KFINE) if cold_m[k] >= MINC and pop_m[k] < 0.001]
    cold_only_mass = float(sum(cold_mp[k] for k in cold_only))

    out = dict(
        name=NAME, n_remd_frames=int(len(Xr)), n_cold_frames=int(ncold), n_seeds=len(finished),
        n_basins=NB, kfine=KFINE, minc=MINC, remd_floor=REMD_FLOOR,
        remd_basin_pop=np.round(pop_b, 3).tolist(), cold_basin_pop=np.round(cold_bp, 3).tolist(),
        seeds_visiting_basin=seed_hits.tolist(),
        important_basins=len(imp_b), missed_basins=len(missed_b),
        important_micro=len(imp_m), covered_micro=len(covered_m), missed_micro=len(missed_m),
        missed_remd_mass=round(missed_mass, 4),
        cold_only_micro=len(cold_only), cold_only_mass=round(cold_only_mass, 4),
        missed_micro_detail=[dict(k=int(k), remd_pop=round(float(pop_m[k]), 4),
                                  cold_frac=round(float(cold_mp[k]), 5)) for k in
                             sorted(missed_m, key=lambda k: -pop_m[k])],
    )
    (EXP_ROOT / NAME / "coverage_vs_remd.json").write_text(json.dumps(out, indent=2))

    print(f"\n===== {NAME} =====  REMD {len(Xr)} fr | cold {ncold} fr ({len(finished)} seeds)", file=sys.stderr)
    print(f"  BASIN coverage (density basins, NB={NB}):", file=sys.stderr)
    for B in range(NB):
        mark = "  <-- MISSED" if (pop_b[B] >= REMD_FLOOR and cold_b[B] < MINC) else ""
        print(f"    B{B}: REMD {pop_b[B]:.3f}  cold {cold_bp[B]:.3f}  seeds-visiting {seed_hits[B]}/{len(finished)}{mark}",
              file=sys.stderr)
    print(f"  MICROSTATE coverage (K={KFINE}, important = REMD pop >= {REMD_FLOOR}):", file=sys.stderr)
    print(f"    important REMD microstates: {len(imp_m)} | covered: {len(covered_m)} | "
          f"MISSED: {len(missed_m)}  -> missed REMD equilibrium mass = {missed_mass:.3f}", file=sys.stderr)
    if missed_m:
        for k in sorted(missed_m, key=lambda k: -pop_m[k])[:6]:
            print(f"      microstate {k}: REMD pop {pop_m[k]:.3f}  cold frac {cold_mp[k]:.5f}", file=sys.stderr)
    print(f"  (reverse: {len(cold_only)} cold-only microstates REMD never visits, "
          f"{cold_only_mass:.1%} of cold mass = trap artifacts)", file=sys.stderr)
    return out


def make_figure(rows):
    n = len(rows)
    fig, axes = plt.subplots(1, n, figsize=(4.6 * n, 4.2), squeeze=False)
    for ax, r in zip(axes[0], rows):
        NB = r["n_basins"]; xb = np.arange(NB); w = 0.38
        ax.bar(xb - w / 2, r["remd_basin_pop"], w, color="crimson", label="REMD")
        ax.bar(xb + w / 2, r["cold_basin_pop"], w, color="C0", label="100ns cold (pooled)")
        for B in range(NB):
            ax.text(B, max(r["remd_basin_pop"][B], r["cold_basin_pop"][B]) + 0.01,
                    f"{r['seeds_visiting_basin'][B]}/{r['n_seeds']}", ha="center", fontsize=8, color="0.3")
        ax.set_xticks(xb); ax.set_xticklabels([f"B{B}" for B in range(NB)])
        ax.set_ylabel("population"); ax.set_ylim(0, 1.08)
        ax.set_title(f"{r['name']}\nmissed REMD mass (K={r['kfine']}) = {r['missed_remd_mass']:.1%}", fontsize=9)
        ax.legend(fontsize=8)
    fig.suptitle("100 ns cold-MD basin coverage vs REMD  (n/N = seeds visiting each basin)", fontsize=11)
    fig.tight_layout(); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_fps10_coverage.png", dpi=140); plt.close(fig)
    print(f"\nwrote {OUT / 'fig_fps10_coverage.png'}", file=sys.stderr)


def main():
    rows = [process(n) for n in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"])]
    make_figure(rows)
    print("\n=== SUMMARY: missed REMD equilibrium mass (100 ns cold pool) ===", file=sys.stderr)
    for r in rows:
        print(f"  {r['name']:16s} basins missed {r['missed_basins']}/{r['important_basins']} | "
              f"micro missed {r['missed_micro']}/{r['important_micro']} | "
              f"missed REMD mass {r['missed_remd_mass']:.3f}", file=sys.stderr)


if __name__ == "__main__":
    main()
