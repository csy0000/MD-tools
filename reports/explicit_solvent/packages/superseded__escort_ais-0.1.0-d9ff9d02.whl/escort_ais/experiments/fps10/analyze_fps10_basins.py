#!/usr/bin/env python3
"""analyze_fps10_basins.py — basins visited by the FPS-10x100ns cold runs vs REMD.

For each FINISHED 100 ns cold run (final_structure.pdb present), assign frames to basins two ways and compare
its distribution (and the pooled distribution over finished runs) to REMD replica_00:
  (A) reference GeometricBasinModel (major/minor -- the ground-truth REMD ddF definition);
  (B) full-torsional-space "empty-trough barrier" scaffold defined ON REMD (split only along torsions REMD
      shows bimodal-with-an-empty-trough), applied to the runs with the same cuts.
Also reports whether each run crossed the major<->minor barrier in 100 ns (trap test).

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_basins
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pickle
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

EXP_ROOT = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}


def tv(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    return float(0.5 * np.abs(a / a.sum() - b / b.sum()).sum())


def js(a, b, e=1e-12):
    a = np.asarray(a, float) + e; a /= a.sum(); b = np.asarray(b, float) + e; b /= b.sum()
    m = 0.5 * (a + b)
    return float(0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m)))


# ---- (B) empty-trough barrier scaffold, defined on REMD -------------------------------------------
def barrier_cuts(x, trough_max=0.12, peak_min=0.15):
    h, e = np.histogram(x, bins=np.linspace(-180, 180, 73), density=True); cen = 0.5 * (e[:-1] + e[1:])
    hs = gaussian_filter1d(h, 1.5, mode="wrap"); hs /= hs.max()
    ext = np.concatenate([hs, hs, hs]); pk, _ = find_peaks(ext, height=peak_min, distance=6)
    peaks = sorted(set(p - 72 for p in pk if 72 <= p < 144))
    if len(peaks) < 2:
        return None
    cuts = []
    for a, b in zip(peaks, peaks[1:] + [peaks[0] + 72]):
        seg = np.arange(a, b) % 72; d = hs[seg]
        if d.min() < trough_max:
            cuts.append(float(cen[seg[d.argmin()]]))
    return cuts or None


def well_label(x, cuts):
    c = sorted(cuts); xm = (x - c[0]) % 360; edges = [(cc - c[0]) % 360 for cc in c[1:]]
    return np.searchsorted(edges, xm)


def build_scaffold(remd_dih):
    """Return (assign(dih)->state, remd_state_labels, ordered populated combos). States ordered by REMD pop."""
    cut_map = {}
    for j in range(remd_dih.shape[1]):
        cuts = barrier_cuts(remd_dih[:, j])
        if cuts:
            cut_map[j] = cuts
    if not cut_map:
        return (lambda d: np.zeros(len(d), int)), np.zeros(len(remd_dih), int), [()]

    def combo(dih):
        return np.stack([well_label(dih[:, j], cut_map[j]) for j in cut_map], axis=1)

    rc = combo(remd_dih)
    uniq, inv, counts = np.unique(rc, axis=0, return_inverse=True, return_counts=True)
    p = counts / counts.sum()
    big = np.where(p >= 0.01)[0]
    order = big[np.argsort(-p[big])]                      # populated combos, most-populated first
    ref_combos = uniq[order]                              # (n_state, n_barrier)

    def assign(dih):
        c = combo(dih)
        # nearest populated combo by Hamming distance
        ham = (c[:, None, :] != ref_combos[None, :, :]).sum(2)   # (n, n_state)
        return ham.argmin(1)

    return assign, assign(remd_dih), [tuple(int(v) for v in row) for row in ref_combos]


def count_flips(lab, min_dwell=200):
    """number of major<->minor crossings with a dwell filter (frames; 1 ps/frame -> 200 ps)."""
    # collapse runs shorter than min_dwell into their neighbours, then count label changes
    runs = []
    cur, n = lab[0], 1
    for v in lab[1:]:
        if v == cur:
            n += 1
        else:
            runs.append([cur, n]); cur, n = v, 1
    runs.append([cur, n])
    seq = [r[0] for r in runs if r[1] >= min_dwell]
    return int(sum(1 for a, b in zip(seq, seq[1:]) if a != b))


def process(NAME):
    EXP = EXP_ROOT / NAME
    cfg = load_cfg(NAME); q, _, _ = load_quartets(cfg.topo, "backbone")
    ref = pickle.load(open(cfg.basin_model_path, "rb"))               # GeometricBasinModel major/minor
    remd = load_remd_ensemble(REMD[NAME], "replica_00", cfg.top_pdb, 0)
    remd_dih = np.degrees(md.compute_dihedrals(remd, q))

    p_remd_ref = np.bincount(ref.assign(remd), minlength=ref.n_basins).astype(float); p_remd_ref /= p_remd_ref.sum()
    assign_scaf, remd_scaf, ref_combos = build_scaffold(remd_dih)
    nS = len(ref_combos)
    p_remd_scaf = np.bincount(remd_scaf, minlength=nS).astype(float); p_remd_scaf /= p_remd_scaf.sum()

    # finished runs = those with final_structure.pdb
    finished = sorted(d for d in glob.glob(str(EXP / "cold_md/seed_*"))
                      if Path(d, "final_structure.pdb").exists())
    print(f"REMD major/minor = {np.round(p_remd_ref, 3).tolist()} | REMD scaffold({nS}) = "
          f"{np.round(p_remd_scaf, 3).tolist()}", file=sys.stderr)
    print(f"{len(finished)} finished runs\n", file=sys.stderr)

    rows, pooled_ref, pooled_scaf = [], np.zeros(ref.n_basins), np.zeros(nS)
    for d in finished:
        sid = Path(d).name
        top = str(Path(d) / "final_structure.pdb")
        tr = md.load_dcd(str(Path(d) / "trajectory.dcd"), top=top)[50:]        # 50 ps burn
        dih = np.degrees(md.compute_dihedrals(tr, q))
        lab_ref = ref.assign(tr); lab_scaf = assign_scaf(dih)
        pr = np.bincount(lab_ref, minlength=ref.n_basins).astype(float); pooled_ref += pr; pr /= pr.sum()
        ps = np.bincount(lab_scaf, minlength=nS).astype(float); pooled_scaf += ps; ps /= ps.sum()
        flips = count_flips(lab_ref)
        rows.append(dict(seed=sid, n_ns=round(tr.n_frames / 1000.0, 1),
                         major_minor=np.round(pr, 3).tolist(), flips=flips,
                         scaffold=np.round(ps, 3).tolist(),
                         tv_ref=round(tv(pr, p_remd_ref), 3)))
        print(f"{sid}: {tr.n_frames/1000:5.1f}ns  major/minor={np.round(pr,3).tolist()}  "
              f"flips={flips}  scaffold={np.round(ps,3).tolist()}  TV_ref={tv(pr,p_remd_ref):.3f}",
              file=sys.stderr)

    pr = pooled_ref / pooled_ref.sum(); ps = pooled_scaf / pooled_scaf.sum()
    out = dict(name=NAME, n_finished=len(finished),
               remd_major_minor=np.round(p_remd_ref, 3).tolist(),
               remd_scaffold=np.round(p_remd_scaf, 3).tolist(), scaffold_states=ref_combos,
               pooled_major_minor=np.round(pr, 3).tolist(),
               pooled_scaffold=np.round(ps, 3).tolist(),
               pooled_tv_ref=round(tv(pr, p_remd_ref), 3), pooled_js_ref=round(js(pr, p_remd_ref), 4),
               pooled_tv_scaffold=round(tv(ps, p_remd_scaf), 3), per_run=rows)
    (EXP / "basins_vs_remd.json").write_text(json.dumps(out, indent=2))
    print(f"\nPOOLED ({len(finished)} runs): major/minor={np.round(pr,3).tolist()} vs REMD "
          f"{np.round(p_remd_ref,3).tolist()}  TV={tv(pr,p_remd_ref):.3f} JS={js(pr,p_remd_ref):.4f}",
          file=sys.stderr)
    print(f"POOLED scaffold({nS}) ={np.round(ps,3).tolist()} vs REMD {np.round(p_remd_scaf,3).tolist()}  "
          f"TV={tv(ps,p_remd_scaf):.3f}", file=sys.stderr)
    n_maj = sum(1 for r in rows if r["major_minor"][0] >= 0.5)
    print(f"\nseeds majority-MAJOR: {n_maj}/{len(rows)} ; majority-MINOR: {len(rows)-n_maj}/{len(rows)} ; "
          f"seeds that crossed the barrier (>=1 flip): {sum(1 for r in rows if r['flips']>0)}/{len(rows)}",
          file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd"]):
        print(f"\n===== {name} =====", file=sys.stderr)
        process(name)


if __name__ == "__main__":
    main()
