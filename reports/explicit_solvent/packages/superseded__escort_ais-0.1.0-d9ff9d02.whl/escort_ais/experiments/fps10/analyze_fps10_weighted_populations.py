#!/usr/bin/env python3
"""analyze_fps10_weighted_populations.py — does AIS-landing-weight weighting fix the FPS-10x100ns populations?

The FPS-10x100ns experiment reaches intra-basin local equilibrium but its *populations* are off REMD
(TV 0.19-0.23) because equal-weight pooling over 10 FPS seeds reflects seed PLACEMENT, not Boltzmann weight.
The `cold_artifact_identification.md` record names one open lever: "weight pooled runs by AIS landing weight."
This script tests that lever and puts it next to the already-validated forward-AIS estimator, on the SAME
reference major/minor basins used by the experiment (apples-to-apples with basins_vs_remd.json).

Three population estimates per compound, all on the GeometricBasinModel major/minor basins:
  (a) EQUAL   — equal-weight pool of the 10 finished 100 ns runs (= basins_vs_remd.json pooled_major_minor).
  (b) SEEDW   — weight each run by softmax(logw) of its source FPS landing; report ESS (10 = uniform, 1 = one
                seed dominates). This is the literal "weight pooled runs by AIS landing weight" lever.
  (c) FWDAIS  — forward-AIS Jarzynski population over ALL 1000 gen0 landings: p(B) = Σ_{land in B} e^{logw}.
                This is the reference-side estimator already shown to match REMD at TV 0.02-0.07 on isolated
                states (analyze_state_populations.py); here reduced onto the same major/minor split.
REMD replica_00 is the ground truth. Reports TV(each, REMD).

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_weighted_populations
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd
import pickle

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

EXP_ROOT = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}


def tv(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    return float(0.5 * np.abs(a / a.sum() - b / b.sum()).sum())


def process(NAME):
    cfg = load_cfg(NAME)
    ref = pickle.load(open(cfg.basin_model_path, "rb"))
    NB = ref.n_basins

    # REMD ground truth on the reference basins
    remd = load_remd_ensemble(REMD[NAME], "replica_00", cfg.top_pdb, 0)
    p_remd = np.bincount(ref.assign(remd), minlength=NB).astype(float); p_remd /= p_remd.sum()

    # (a) EQUAL and per-seed basin fractions from the existing basins_vs_remd.json
    bvr = json.loads((EXP_ROOT / NAME / "basins_vs_remd.json").read_text())
    p_equal = np.asarray(bvr["pooled_major_minor"], float)
    per = sorted(bvr["per_run"], key=lambda r: r["seed"])            # seed_000..009
    P_seed = np.asarray([r["major_minor"] for r in per], float)      # (n_run, NB)

    # (b) SEEDW — softmax(logw) over the SELECTED seeds, in seed order
    sel = json.loads((EXP_ROOT / NAME / "fps_selection.json").read_text())
    logw_seed = np.asarray(sel["selected_logw"], float)[:len(per)]
    w = np.exp(logw_seed - logw_seed.max()); w /= w.sum()
    ess = float(1.0 / np.sum(w ** 2))
    p_seedw = (w[:, None] * P_seed).sum(0); p_seedw /= p_seedw.sum()

    # (c) FWDAIS — Jarzynski population over all 1000 gen0 landings, same basins
    fwd = BE / NAME / "gen0/fwd"
    landings = md.load_dcd(str(fwd / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))  # dihedral-scale-invariant
    logw = pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    lab = ref.assign(landings)
    wl = np.exp(logw - logw.max())
    p_fwd = np.asarray([wl[lab == B].sum() for B in range(NB)]); p_fwd /= p_fwd.sum()
    ess_fwd = float(np.sum(wl) ** 2 / np.sum(wl ** 2))

    out = dict(
        name=NAME, n_basins=NB, remd=np.round(p_remd, 3).tolist(),
        equal=dict(pop=np.round(p_equal, 3).tolist(), tv=round(tv(p_equal, p_remd), 3)),
        seedw=dict(pop=np.round(p_seedw, 3).tolist(), tv=round(tv(p_seedw, p_remd), 3),
                   ess=round(ess, 2), n_seeds=len(per),
                   logw_span=round(float(logw_seed.max() - logw_seed.min()), 1)),
        fwdais=dict(pop=np.round(p_fwd, 3).tolist(), tv=round(tv(p_fwd, p_remd), 3),
                    ess=round(ess_fwd, 1), n_landings=int(len(logw))),
    )
    (EXP_ROOT / NAME / "weighted_populations.json").write_text(json.dumps(out, indent=2))

    print(f"\n===== {NAME} =====", file=sys.stderr)
    print(f"  REMD              {np.round(p_remd,3).tolist()}", file=sys.stderr)
    print(f"  (a) EQUAL  pool   {np.round(p_equal,3).tolist()}   TV={tv(p_equal,p_remd):.3f}", file=sys.stderr)
    print(f"  (b) SEEDW  pool   {np.round(p_seedw,3).tolist()}   TV={tv(p_seedw,p_remd):.3f}   "
          f"ESS={ess:.2f}/{len(per)}  (logw span {logw_seed.max()-logw_seed.min():.1f} kT)", file=sys.stderr)
    print(f"  (c) FWDAIS 1000   {np.round(p_fwd,3).tolist()}   TV={tv(p_fwd,p_remd):.3f}   "
          f"ESS={ess_fwd:.1f}/{len(logw)}", file=sys.stderr)
    return out


def main():
    rows = [process(n) for n in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"])]
    print("\n=== SUMMARY (TV vs REMD; lower = better) ===", file=sys.stderr)
    print(f"{'compound':16s} {'EQUAL':>7s} {'SEEDW':>7s} {'ESS':>6s} {'FWDAIS':>7s}", file=sys.stderr)
    for r in rows:
        print(f"{r['name']:16s} {r['equal']['tv']:7.3f} {r['seedw']['tv']:7.3f} "
              f"{r['seedw']['ess']:6.2f} {r['fwdais']['tv']:7.3f}", file=sys.stderr)


if __name__ == "__main__":
    main()
