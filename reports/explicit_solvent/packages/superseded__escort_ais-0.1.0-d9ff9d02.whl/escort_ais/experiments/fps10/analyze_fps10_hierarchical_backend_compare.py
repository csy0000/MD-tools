#!/usr/bin/env python3
"""analyze_fps10_hierarchical_backend_compare.py — compare 3 split backends for the hierarchical LEQ (rgd).

Variants (per adaptive budget T), all sharing the KCC de-trapping + 10*t2_eff>T equilibration rule + dead-leaf
pruning + within-leaf mixing-gate LEQ — only the transition-matrix estimator and the split-LOCATION differ:
  symcount+density : current — symmetrized-count spectral bisection (X=C+Cᵀ) + psi2 density-valley cut
  deeptime+density : deeptime DEFAULT reversible-MLE t2/psi2 + psi2 density-valley cut  (isolates the estimator)
  deeptime+pcca    : deeptime reversible-MLE + genuine PCCA+(2) split location
Loads the system ONCE, runs all three, writes a comparison JSON + figure. REMD is validation-only.

    conda activate escort-ais && python -m escort_ais.experiments.fps10.analyze_fps10_hierarchical_backend_compare [name]
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.analysis.analyze_fps10_hierarchical_leq import load_system, run_budgets, EXP, OUT, FPN  # noqa: E402

VARIANTS = [("symcount", "density"), ("deeptime", "density"), ("deeptime", "pcca")]
COL = {"symcount+density": "C0", "deeptime+density": "C1", "deeptime+pcca": "C2"}


def _major(rows, T):
    r = next((x for x in rows if x["T"] == T), None)
    return (r["leaves"][0] if (r and r["leaves"]) else None)          # leaves are sorted by fwd_pop desc


def process(name):
    data = load_system(name)
    out = {f"{b}+{s}": run_budgets(name, data, backend=b, split=s) for b, s in VARIANTS}
    (EXP / name / "hierarchical_backend_compare.json").write_text(
        json.dumps({"name": name, "variants": list(out.keys()), "rows": out}, indent=2))
    make_figure(name, out)
    print_table(name, out)


def make_figure(name, out):
    keys = list(out.keys())
    Ts = [r["T"] for r in out[keys[0]]]
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
    for key in keys:
        rows, c = out[key], COL.get(key)
        ax[0].plot(Ts, [r["n_leaves"] for r in rows], "-o", c=c, label=key)
        ax[1].plot(Ts, [(_major(rows, T) or {}).get("js_mix") for T in Ts], "-o", c=c, label=key)
        ax[2].plot(Ts, [(_major(rows, T) or {}).get("t2_eff_ns") for T in Ts], "-o", c=c, label=key)
    ax[0].set_ylabel("# live leaves (BAR states)"); ax[0].set_title("hierarchy vs backend")
    ax[1].axhline(0.1, ls=":", c="0.5", lw=1); ax[1].set_ylabel(r"major-leaf JSD($\hat p$,REMD)")
    ax[1].set_title("major-leaf within-leaf LEQ")
    ax[2].plot(Ts, [T / 10 for T in Ts], "k--", lw=1, alpha=0.6, label="split threshold  t₂ = T/10")
    ax[2].set_yscale("log"); ax[2].set_ylabel("major-leaf t₂_eff (ns)")
    ax[2].set_title("resolved t₂ vs split threshold")
    for a in ax:
        a.set_xlabel("adaptive budget T (ns)"); a.legend(fontsize=7)
    fig.suptitle(f"{name}: split-backend comparison  (symcount vs deeptime reversible-MLE vs deeptime PCCA+)",
                 fontsize=12)
    from escort_ais.common.figutil import panel_labels
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.96]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_hierarchical_backend_compare.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_hierarchical_backend_compare.png'}", file=sys.stderr)


def print_table(name, out):
    keys = list(out.keys())
    Ts = [r["T"] for r in out[keys[0]]]
    print(f"\n=== {name}: backend comparison — n_leaves / major t₂_eff / major JSmix ===", file=sys.stderr)
    print("   T  |  " + " | ".join(f"{k:^26}" for k in keys), file=sys.stderr)
    for T in Ts:
        cells = []
        for k in keys:
            r = next((x for x in out[k] if x["T"] == T), None)
            mj = _major(out[k], T) or {}
            cells.append(f"{r['n_leaves']:>2} lv  t2={str(mj.get('t2_eff_ns')):>5}  JS={str(mj.get('js_mix')):>6}")
        print(f"  {T:>3} |  " + " | ".join(f"{c:^26}" for c in cells), file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd"]):
        process(name)


if __name__ == "__main__":
    main()
