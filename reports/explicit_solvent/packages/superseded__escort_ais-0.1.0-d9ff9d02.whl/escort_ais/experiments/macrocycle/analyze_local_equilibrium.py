#!/usr/bin/env python3
"""analyze_local_equilibrium.py — does the cold reservoir reach LOCAL (intra-basin) equilibrium?

Between metastable states the cold populations are wrong (cold MD can't cross barriers -> reweighting fixes
them). This asks the sharper question: WITHIN each real state B, does the cold reservoir reproduce the REMD
conditional P_REMD(x|B)?  Equivalently -- is merging the cold MD frames WITHOUT weights a valid equilibrium
sample of the basin?  Unweighted pooling is correct iff the equal-weight pool of seed-frames reproduces
P_REMD(x|B). Failure mode: seeds trapped in disjoint sub-wells -> the pool is weighted by seed selection, not
equilibrium.

Per compound, states = isolated metastable states (TICA-on-hot, cold-population order, as in the reports),
comparison over BACKBONE torsions. For each real state B (REMD pop >= 1%):
  (Q1) js_pool   = JS( cold(.|B) sub-populations, REMD(.|B) sub-populations )  [union KMeans, K_sub microstates]
       js_floor  = JS between two independent halves of REMD(.|B) (finite-sampling floor)
  (Q2) per-seed  = each contributing seed's JS to REMD(.|B); mean pairwise JS between seeds (disjointness)
  (Q3) ess       = effective-sample-size fraction if cold(.|B) is reweighted to REMD(.|B) (1 = no reweight
                   needed / unweighted merge fine; ->0 = heavy reweight needed)
  (bonus) early/late halves of each seed -> is the within-B mismatch shrinking over the 5 ns or stuck?

Verdict: js_pool~js_floor -> unweighted merge correct; js_pool>>floor with disjoint-but-tiling seeds ->
accidentally OK (ess quantifies the needed reweight); js_pool>>floor + cold missing REMD regions -> incorrect.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_local_equilibrium
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
OUT = ROOT / "results/rgd/report"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
HOT = {"rgd": ROOT / "data/rgd/2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701/trajectory.dcd",
       "cilengitide": ROOT / "data/cilengitide/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
       "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide", "rgd_redPheVal": "rgd_redPheVal"}
NSTATE, KSUB, MINN = 5, 12, 300


def _js(a, b, eps=1e-12):
    """Symmetric-KL (Jensen-Shannon) divergence between two population/histogram vectors."""
    a = np.asarray(a, float) + eps; a /= a.sum()
    b = np.asarray(b, float) + eps; b /= b.sum()
    m = 0.5 * (a + b)
    return float(0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m)))


def _ess(w):
    w = np.asarray(w, float)
    return float(w.sum() ** 2 / (len(w) * (w ** 2).sum())) if w.sum() > 0 else 0.0


def process(name, ksub=KSUB):
    rng = np.random.default_rng(0)
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone"); nq = q.shape[0]
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NSTATE,
                                   lag=20, n_tic=4, burn_frames=1000, stride=2, seed=0)

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    lab0 = model.assign(remd)
    p0 = np.bincount(lab0, minlength=NSTATE).astype(float); p0 /= p0.sum()
    perm = np.argsort(-p0); inv = np.empty(NSTATE, int); inv[perm] = np.arange(NSTATE)  # cold-order relabel
    remd_state = inv[lab0]; remdX = featurize(remd, q)
    p_remd = p0[perm]

    # cold reservoir: per-seed features + state labels (relabeled)
    cX, cstate, cseed = [], [], []
    for i, s in enumerate(sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))):
        tr = md.load_dcd(s, top=top)[50:]
        cX.append(featurize(tr, q)); cstate.append(inv[model.assign(tr)]); cseed.append(np.full(tr.n_frames, i))
    cX = np.concatenate(cX); cstate = np.concatenate(cstate); cseed = np.concatenate(cseed)
    nseeds = int(cseed.max()) + 1
    # per-seed home (dominant) state + dwell -> seeds trapped per basin ("initiated == trapped", no crossing)
    dom = np.array([np.bincount(cstate[cseed == i], minlength=NSTATE).argmax() for i in range(nseeds)])
    dwell = np.array([float(np.bincount(cstate[cseed == i], minlength=NSTATE).max() / max((cseed == i).sum(), 1))
                      for i in range(nseeds)])

    def ang(X, j):  # recover dihedral j (deg) from sin/cos features
        return np.degrees(np.arctan2(X[:, j], X[:, nq + j]))

    rows = []
    for B in range(NSTATE):
        if p_remd[B] < 0.01:
            continue
        Xr = remdX[remd_state == B]; Xc = cX[cstate == B]; sc = cseed[cstate == B]
        if len(Xr) < MINN or len(Xc) < MINN:
            continue
        # sub-cluster the union of B, then size-controlled comparison
        km = KMeans(min(ksub, len(Xr) // 25 + 2), n_init=6, random_state=0).fit(np.concatenate([Xr, Xc]))
        K = km.n_clusters
        n = min(len(Xr), len(Xc))
        ir = rng.permutation(len(Xr)); ic = rng.permutation(len(Xc))
        lr = km.predict(Xr[ir[:n]]); lc = km.predict(Xc[ic[:n]])
        pr = np.bincount(lr, minlength=K); pc = np.bincount(lc, minlength=K)
        js_pool = _js(pc, pr)
        h = n // 2
        js_floor = _js(np.bincount(km.predict(Xr[ir[:h]]), minlength=K),
                       np.bincount(km.predict(Xr[ir[h:2 * h]]), minlength=K))
        js_floor_cold = _js(np.bincount(km.predict(Xc[ic[:h]]), minlength=K),
                            np.bincount(km.predict(Xc[ic[h:2 * h]]), minlength=K))

        # per-backbone-torsion marginal JS (worst torsion)
        BINS = np.linspace(-180, 180, 37)
        tj = [_js(np.histogram(ang(Xc[ic[:n]], j), BINS)[0], np.histogram(ang(Xr[ir[:n]], j), BINS)[0])
              for j in range(nq)]
        worst = int(np.argmax(tj))

        # per-seed equilibration: each seed TRAPPED (homed) in B, its JS vs REMD(.|B); + pairwise disjointness
        pr_full = np.bincount(km.predict(Xr), minlength=K).astype(float)
        occ, sjs = [], []
        for sid in np.where(dom == B)[0]:
            Xs = Xc[sc == sid]
            if len(Xs) < 100:
                continue
            ps = np.bincount(km.predict(Xs), minlength=K).astype(float)
            occ.append(ps / ps.sum()); sjs.append(_js(ps, pr_full))
        occ = np.array(occ); sjs = np.array(sjs)
        pair = float(np.mean([_js(occ[i], occ[k]) for i in range(len(occ)) for k in range(i + 1, len(occ))])) \
            if len(occ) > 1 else 0.0
        n_trapped = int((dom == B).sum())
        n_near = int((sjs < 0.05).sum())        # seeds that actually reach the REMD basin conditional

        # ESS if cold(.|B) reweighted to REMD(.|B) at the sub-cluster level
        lc_full = km.predict(Xc); pc_full = np.bincount(lc_full, minlength=K).astype(float)
        pc_full /= pc_full.sum(); prn = pr_full / pr_full.sum()
        w = (prn / np.where(pc_full > 0, pc_full, 1.0))[lc_full]
        ess = _ess(w)

        # time convergence: early vs late half of each seed's B-frames
        e_lab, l_lab = [], []
        for sid in np.unique(sc):
            idx = np.where(sc == sid)[0]
            if len(idx) < 20:
                continue
            m = len(idx) // 2
            e_lab.append(km.predict(Xc[idx[:m]])); l_lab.append(km.predict(Xc[idx[m:]]))
        je = _js(np.bincount(np.concatenate(e_lab), minlength=K), pr_full) if e_lab else np.nan
        jl = _js(np.bincount(np.concatenate(l_lab), minlength=K), pr_full) if l_lab else np.nan

        med, mean, mn = (round(float(np.median(sjs)), 4), round(float(np.mean(sjs)), 4),
                         round(float(np.min(sjs)), 4)) if len(sjs) else (np.nan, np.nan, np.nan)
        rows.append(dict(state=B, p_remd=round(float(p_remd[B]), 3), n_cold=int(len(Xc)), n_remd=int(len(Xr)),
                         n_trapped=n_trapped, n_seeds=len(occ), js_pool=round(js_pool, 4),
                         js_floor=round(js_floor, 4), js_floor_cold=round(js_floor_cold, 4),
                         ratio=round(js_pool / max(js_floor, 1e-6), 1),
                         perseed_js_median=med, perseed_js_mean=mean, perseed_js_min=mn,
                         n_near_equil=n_near, seed_disjointness=round(pair, 4), ess_reweight=round(ess, 3),
                         worst_tor=worst, worst_tor_js=round(tj[worst], 4),
                         js_early=round(float(je), 4), js_late=round(float(jl), 4),
                         _occ=occ, _Xc=Xc, _Xr=Xr, _ic=ic, _ir=ir, _n=n))
    make_figure(name, rows, nq, ang)
    _print(name, rows)
    (BE / name / "local_equilibrium.json").write_text(
        json.dumps([{k: v for k, v in r.items() if not k.startswith("_")} for r in rows], indent=2))
    return rows


def make_figure(name, rows, nq, ang):
    real = [r for r in rows if r["n_seeds"] > 0]
    if not real:
        return
    fig, ax = plt.subplots(len(real), 2, figsize=(11, 3.2 * len(real)), squeeze=False)
    BINS = np.linspace(-180, 180, 37)
    for i, r in enumerate(real):
        j = r["worst_tor"]; n = r["_n"]
        ax[i, 0].hist(ang(r["_Xc"][r["_ic"][:n]], j), BINS, density=True, alpha=0.45, color="#4477AA",
                      label=f"cold(.|S{r['state']})")
        ax[i, 0].hist(ang(r["_Xr"][r["_ir"][:n]], j), BINS, density=True, histtype="step", lw=2.0,
                      color="#CC3311", label="REMD(.|B)")
        ax[i, 0].set_title(f"S{r['state']} (REMD {r['p_remd']:.2f}) — worst backbone tor#{j}: "
                           f"JS_pool {r['js_pool']:.3f} vs floor {r['js_floor']:.3f} ({r['ratio']:.0f}x)",
                           fontsize=9)
        ax[i, 0].set_xlabel(f"tor#{j} (deg)"); ax[i, 0].set_yticks([]); ax[i, 0].legend(fontsize=8)
        im = ax[i, 1].imshow(r["_occ"], aspect="auto", cmap="viridis", vmin=0)
        ax[i, 1].set_title(f"per-seed sub-well occupancy — {r['n_seeds']} seeds; "
                           f"disjointness {r['seed_disjointness']:.3f}, ESS {r['ess_reweight']:.2f}", fontsize=9)
        ax[i, 1].set_xlabel("sub-microstate"); ax[i, 1].set_ylabel("seed")
        fig.colorbar(im, ax=ax[i, 1], fraction=0.046)
    fig.suptitle(f"[{NICE[name]}] intra-state local equilibrium: cold(.|B) vs REMD(.|B) on backbone torsions",
                 y=1.005, fontsize=12)
    fig.tight_layout()
    fig.savefig(OUT / f"fig_{name}_local_equilibrium.png", dpi=140, bbox_inches="tight")
    plt.close(fig)


def _print(name, rows):
    print(f"\n===== {NICE[name]} — intra-basin local equilibrium (cold(.|B) vs REMD(.|B), backbone tor) =====",
          file=sys.stderr)
    print(f"  state | REMD trapped | JS_pool floor | per-seed JS min/med/max  near-equil<0.05 | disjoint ESS | "
          f"early->late", file=sys.stderr)
    for r in rows:
        mx = "0.693"  # ln2 ceiling for a fully-disjoint seed
        print(f"   S{r['state']}   | {r['p_remd']:.2f}  {r['n_trapped']:5d} | {r['js_pool']:.3f} "
              f"{r['js_floor']:.3f} | {r['perseed_js_min']:.3f}/{r['perseed_js_median']:.3f}/{mx}   "
              f"{r['n_near_equil']:2d}/{r['n_seeds']:<2d} | {r['seed_disjointness']:.3f} {r['ess_reweight']:.2f} | "
              f"{r['js_early']:.3f}->{r['js_late']:.3f}", file=sys.stderr)


def main():
    args = sys.argv[1:]
    ksub = KSUB
    names = ["rgd", "cilengitide", "rgd_redPheVal"]
    if args and args[0].startswith("ksub="):
        ksub = int(args[0].split("=")[1]); args = args[1:]
    for nm in (args or names):
        process(nm, ksub=ksub)


if __name__ == "__main__":
    main()
