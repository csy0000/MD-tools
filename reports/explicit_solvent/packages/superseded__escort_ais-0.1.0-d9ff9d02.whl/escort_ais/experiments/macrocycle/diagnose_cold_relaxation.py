#!/usr/bin/env python
"""Why did the 5 ns cold reservoir kill the reverse-work signal? (no GPU, structural only)

Uses the controlled 20-seed cold-MD set saved at 1 ns and 10 ns (same seeds), the forward-AIS landing
ensemble that seeded it, and the physical REMD replica_00 ensemble. For the MINOR basin (the one that
carries ddF) we track, as a function of cold-MD time, how the reverse-start ensemble moves relative to
(i) the forward-AIS minor landings it is supposed to be conjugate to, and (ii) the physical REMD minor
basin -- distinguishing "5 ns breaks the forward/reverse pairing" (A) from "5 ns drifts into a
non-physical substate" (B).

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.diagnose_cold_relaxation
"""
from __future__ import annotations
import sys, warnings
from pathlib import Path

import numpy as np
import mdtraj as md

warnings.filterwarnings("ignore")
from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel, load_quartets, featurize
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble

DATA = ROOT / "data/rgd/2026-06-29-reservoir-sw-s0p25"
REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
OUT = ROOT / "results/rgd/report"
MINOR = 1
NS = 1000  # frames per ns (cold MD, 1 ps/frame)


def spread(X):
    """RMS distance of rows to their centroid in feature space (isotropic ensemble width)."""
    if len(X) < 2:
        return np.nan
    return float(np.sqrt(((X - X.mean(0)) ** 2).sum(1).mean()))


def main():
    cfg = load_cfg("rgd")
    top = str(cfg.top_pdb)
    quartets, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.topo.parent / "basins_tica" / "basin_model_backbone.pkl")

    # --- reference ensembles (minor basin) ---
    fwd = md.load_dcd(str(DATA / "step_forward_ais/ais_final_coordinates.dcd"), top=top)
    Xf_all = featurize(fwd, quartets); bf = model.assign(fwd)
    Xf_min = Xf_all[bf == MINOR]
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 3000)   # burn 30 ns
    Xr_all = featurize(remd, quartets); br = model.assign(remd)
    Xr_min = Xr_all[br == MINOR]
    cF, cR = Xf_min.mean(0), Xr_min.mean(0)
    print(f"forward-AIS minor landings: {len(Xf_min)}  |  REMD minor: {len(Xr_min)}")
    print(f"reference gap ||fwd_minor - remd_minor|| = {np.linalg.norm(cF - cR):.3f}\n")

    # --- cold MD (10 ns), minor frames only, per 1-ns window ---
    seeds = sorted((DATA / "cold_md_10ns").glob("seed_*/trajectory.dcd"))
    win_feats = {w: [] for w in range(10)}   # window index -> list of minor-frame feature rows
    minor_seed0 = 0
    for s in seeds:
        tr = md.load_dcd(str(s), top=top)
        X = featurize(tr, quartets); b = model.assign(tr)
        if b[0] == MINOR:
            minor_seed0 += 1
        for w in range(10):
            fr = X[w * NS:(w + 1) * NS]
            bb = b[w * NS:(w + 1) * NS]
            win_feats[w].append(fr[bb == MINOR])
    print(f"seeds starting in MINOR: {minor_seed0}/{len(seeds)}\n")

    print(f"{'window(ns)':>10} {'n_minor':>8} {'spread':>7} {'d->fwd_land':>11} {'d->REMD':>8}  minor_frac")
    rows = []
    for w in range(10):
        Xw = np.concatenate(win_feats[w]) if win_feats[w] else np.zeros((0, Xf_min.shape[1]))
        n = len(Xw)
        d_fwd = float(np.linalg.norm(Xw.mean(0) - cF)) if n else np.nan
        d_remd = float(np.linalg.norm(Xw.mean(0) - cR)) if n else np.nan
        sp = spread(Xw)
        # minor fraction in this window across all seeds (denominator = total frames this window)
        tot = sum(len(win_feats[w][i]) for i in range(len(seeds)))  # only minor counted; get frac below
        rows.append((w, n, sp, d_fwd, d_remd))
        print(f"{w}-{w+1:>2}     {n:8d} {sp:7.3f} {d_fwd:11.3f} {d_remd:8.3f}")

    rows = np.array(rows, float)
    print("\n--- interpretation ---")
    d0f, d5f, d9f = rows[0, 3], rows[4, 3], rows[9, 3]
    d0r, d5r, d9r = rows[0, 4], rows[4, 4], rows[9, 4]
    s0, s5, s9 = rows[0, 2], rows[4, 2], rows[9, 2]
    print(f"spread minor:  0-1ns {s0:.3f} -> 4-5ns {s5:.3f} -> 9-10ns {s9:.3f}  "
          f"({'narrows' if s9 < s0 else 'broadens'})")
    print(f"dist->fwd_land:0-1ns {d0f:.3f} -> 4-5ns {d5f:.3f} -> 9-10ns {d9f:.3f}  "
          f"({'DRIFTS AWAY from forward landings' if d5f > d0f else 'stays near forward landings'})")
    print(f"dist->REMD:    0-1ns {d0r:.3f} -> 4-5ns {d5r:.3f} -> 9-10ns {d9r:.3f}  "
          f"({'toward physical REMD' if d5r < d0r else 'AWAY from physical REMD too'})")

    # figure
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        x = rows[:, 0] + 0.5
        fig, ax = plt.subplots(1, 2, figsize=(9, 3.4))
        ax[0].plot(x, rows[:, 2], "o-", color="C3")
        ax[0].axvline(1, ls=":", c="green"); ax[0].axvline(5, ls=":", c="gray")
        ax[0].set(xlabel="cold-MD time (ns)", ylabel="minor-basin ensemble spread",
                  title="minor basin narrows as it relaxes")
        ax[1].plot(x, rows[:, 3], "o-", label="→ forward-AIS minor landings")
        ax[1].plot(x, rows[:, 4], "s-", label="→ physical REMD minor")
        ax[1].axvline(1, ls=":", c="green"); ax[1].axvline(5, ls=":", c="gray")
        ax[1].set(xlabel="cold-MD time (ns)", ylabel="dist. of minor centroid",
                  title="where does the reverse-start ensemble go?")
        ax[1].legend(fontsize=8)
        fig.tight_layout()
        OUT.mkdir(parents=True, exist_ok=True)
        fig.savefig(OUT / "fig_cold_relaxation.png", dpi=140)
        print(f"\nsaved {OUT / 'fig_cold_relaxation.png'}")
    except Exception as e:
        print(f"(no figure: {e})")


if __name__ == "__main__":
    main()
