#!/usr/bin/env python3
"""Crooks-CFT inter-basin free-energy protocol for alanine dipeptide.

Protocol
--------
1. Hot MD          : 5 ns NVT at s=0.4 (hot/scaled potential)
2. Forward AIS     : 1000 trajectories, 5 ps switching s=0.4→s=1.0
3. Basin assignment: GMM on φ/ψ of AIS endpoints; load per-basin work values
4. Basin MD        : 100 × 50 ps NVT at s=1.0 seeded from AIS endpoints
5. RITE-weight     : stationary weights + inter-basin connectivity (rite_weight env)
6. Backward AIS    : 1000 trajectories, 5 ps switching s=1.0→s=0.4
7. Crooks BAR      : per-basin ΔF(H→C) and pairwise inter-basin ΔΔF

Usage
-----
python -m escort_ais.experiments.macrocycle.run_crooks_basin_protocol [--skip STEP ...]
    --skip 1     skip hot MD (reuse existing)
    --skip 2     skip forward AIS
    ...
    --platform   OpenCL | CPU  (default OpenCL)
    --run-tag    date string for output dir (default: 2026-06-15-crooks-basin)
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd
from sklearn.mixture import GaussianMixture
from scipy.special import logsumexp


from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
from escort_ais.methods.crooks_bar import per_basin_crooks, inter_basin_delta_f
from escort_ais.methods.kinetic_basin import (
    fit_kmeans_torus, predict_microstates, build_transition_counts,
    find_level1_basins, assign_level1, filter_basin_trajectories,
    basin_original_indices, basin_summary,
)
from escort_ais.methods.md_run import run_single_md
from escort_ais.common.paths import ensure_dir

# ── atom indices for alanine dipeptide φ/ψ ────────────────────────────────
PHI_IDX = [4, 6, 8, 14]
PSI_IDX = [6, 8, 14, 16]

TOPOLOGY_DIR = Path("data/topology/ff19sb_gbn2_even")
PRMTOP       = TOPOLOGY_DIR / "system_scale_1p0.prmtop"

# ── protocol parameters (defaults; overridable via CLI) ────────────────────
S_HOT          = 0.4
S_COLD         = 1.0
HOT_MD_NS      = 5.0
AIS_K          = 1000        # number of AIS trajectories
AIS_T_PS       = 5.0         # switching time (ps)
AIS_TIMESTEP   = 2.0         # fs
AIS_FREQ       = 10          # steps per switching window → M = T/dt/freq = 250 windows
BASIN_N_MD     = 100         # number of basin MD runs
BASIN_MD_PS    = 50.0        # duration per basin MD run (ps)
BASIN_TRAJ_PS  = 1.0         # save interval (→ 50 frames per run)
GMM_N          = 6           # GMM components for basin-MD seeding only
N_KMEANS       = 50          # KMeans microstates for kinetic-basin analysis
MIN_TRANS      = 5           # min symmetrised transition count to keep an edge
TEMPERATURE_K  = 300.0
HOT_TRAJ_PS    = 10.0        # hot-MD frame save interval (ps); override via --hot-out-ps

# ── rite_weight binary ─────────────────────────────────────────────────────
RITEWEIGHT_PYTHON = Path(
    "/home/chen0040/localhome/software/miniforge3/envs/rite_weight/bin/python"
)

# ── helpers ────────────────────────────────────────────────────────────────

def load_phi_psi(dcd: Path, prmtop: Path = PRMTOP, stride: int = 1):
    traj = md.load_dcd(str(dcd), top=str(prmtop), stride=stride)
    phi = np.degrees(md.compute_dihedrals(traj, [PHI_IDX]).ravel())
    psi = np.degrees(md.compute_dihedrals(traj, [PSI_IDX]).ravel())
    return phi, psi


def torus_feats(phi_deg: np.ndarray, psi_deg: np.ndarray) -> np.ndarray:
    phi = np.radians(phi_deg)
    psi = np.radians(psi_deg)
    return np.column_stack([np.cos(phi), np.sin(phi), np.cos(psi), np.sin(psi)])


def fit_gmm(phi: np.ndarray, psi: np.ndarray, n: int = GMM_N, seed: int = 0) -> GaussianMixture:
    X = torus_feats(phi, psi)
    gmm = GaussianMixture(n_components=n, covariance_type="full", random_state=seed, n_init=5)
    gmm.fit(X)
    return gmm


def assign_basins(gmm: GaussianMixture, phi: np.ndarray, psi: np.ndarray) -> np.ndarray:
    return gmm.predict(torus_feats(phi, psi)).astype(str)


def load_ais_logw(summary_csv: Path) -> np.ndarray:
    df = pd.read_csv(summary_csv)
    col = [c for c in df.columns if "logw" in c.lower() or "log_w" in c.lower()][0]
    return df[col].values.astype(float)


def concat_dcds(dcd_paths: list[Path], prmtop: Path, out_dcd: Path) -> None:
    traj = md.load_dcd(str(dcd_paths[0]), top=str(prmtop))
    for p in dcd_paths[1:]:
        traj = md.join([traj, md.load_dcd(str(p), top=str(prmtop))])
    traj.save_dcd(str(out_dcd))


def ais_t_steps(t_ps: float, dt_fs: float, freq: int) -> tuple[int, int]:
    """Return (t_ais steps, freq_ais steps) from wall-clock ps and fs timestep."""
    return int(t_ps * 1000 / dt_fs), freq


# ── step implementations ───────────────────────────────────────────────────

def step1_hot_md(out_dir: Path, platform: str) -> Path:
    """5 ns NVT MD at s=0.4.  Returns directory containing trajectory.dcd."""
    print("\n=== Step 1: Hot MD (s=0.4, 5 ns) ===")
    ensure_dir(out_dir)
    run_single_md(
        TOPOLOGY_DIR,
        duration_ns=HOT_MD_NS,
        scale_factor=S_HOT,
        temperature_k=TEMPERATURE_K,
        platform=platform,
        seed=1,
        output_dir=out_dir,
        minimize_steps=2000,
        equilibration_nvt_ps=0.0,
        traj_interval_ps=HOT_TRAJ_PS,
    )
    print(f"  Hot MD done → {out_dir}/trajectory.dcd")
    return out_dir


def step2_forward_ais(hot_md_dir: Path, out_dir: Path, platform: str) -> Path:
    """1000 AIS trajectories, 5 ps, s=0.4→s=1.0.  Returns output dir."""
    print("\n=== Step 2: Forward AIS (s=0.4→1.0, 1000 traj, 5 ps) ===")
    ensure_dir(out_dir)
    t_ais, freq_ais = ais_t_steps(AIS_T_PS, AIS_TIMESTEP, AIS_FREQ)
    cfg = LinearAISConfig(
        solvent="implicit",
        k_ais=AIS_K,
        t_ais=t_ais,
        freq_ais=freq_ais,
        s_hot=S_HOT,
        s_cold=S_COLD,
        temperature_k=TEMPERATURE_K,
        platform=platform,
        seed=2,
        input_scaled_dir=hot_md_dir,
        output_dir=out_dir,
        save_traj_every_switch=False,
        overwrite=True,
    )
    summary = run_linear_scaling_ais(cfg)
    print(f"  Forward AIS done. ESS={summary['ess']:.1f} ({summary['ess_over_k']*100:.1f}%)")
    return out_dir


def step3_basin_assignment(fwd_ais_dir: Path, out_dir: Path) -> tuple[GaussianMixture, np.ndarray, np.ndarray]:
    """Fit GMM on AIS endpoints, assign basins, return (gmm, labels, logw)."""
    print("\n=== Step 3: Basin assignment (GMM on φ/ψ endpoints) ===")
    ensure_dir(out_dir)

    final_dcd = fwd_ais_dir / "ais_final_coordinates.dcd"
    phi_end, psi_end = load_phi_psi(final_dcd)
    logw = load_ais_logw(fwd_ais_dir / "ais_trajectory_summary.csv")

    gmm = fit_gmm(phi_end, psi_end)
    labels = assign_basins(gmm, phi_end, psi_end)

    # Summary
    for b in sorted(set(labels)):
        mask = labels == b
        phi_c = np.degrees(np.arctan2(gmm.means_[int(b)][1], gmm.means_[int(b)][0]))
        psi_c = np.degrees(np.arctan2(gmm.means_[int(b)][3], gmm.means_[int(b)][2]))
        prob = float(np.exp(logsumexp(logw[mask]) - logsumexp(logw)))
        print(f"  Basin {b}: n={mask.sum():4d}  φ_c={phi_c:6.1f}°  ψ_c={psi_c:6.1f}°  P_AIS={prob:.3f}")

    np.save(str(out_dir / "basin_labels_f.npy"), labels)
    np.save(str(out_dir / "final_logw_f.npy"),   logw)
    np.save(str(out_dir / "phi_end_f.npy"),       phi_end)
    np.save(str(out_dir / "psi_end_f.npy"),       psi_end)
    import pickle
    (out_dir / "gmm.pkl").write_bytes(pickle.dumps(gmm))
    print(f"  Saved GMM + basin labels → {out_dir}")
    return gmm, labels, logw


def step4_basin_md(fwd_ais_dir: Path, gmm: GaussianMixture,
                   labels_f: np.ndarray, out_dir: Path, platform: str) -> list[Path]:
    """Run BASIN_N_MD short MD segments (50 ps each) seeded from AIS endpoints."""
    print(f"\n=== Step 4: Basin MD ({BASIN_N_MD} × {BASIN_MD_PS:.0f} ps at s=1.0) ===")
    ensure_dir(out_dir)

    # Load AIS endpoint positions (in nm)
    final_dcd = fwd_ais_dir / "ais_final_coordinates.dcd"
    traj = md.load_dcd(str(final_dcd), top=str(PRMTOP))
    all_positions_nm = traj.xyz   # (K, n_atoms, 3) in nm

    # Select BASIN_N_MD diverse seeds: stratified by basin, then random within
    basins = sorted(set(labels_f))
    per_basin = max(1, BASIN_N_MD // len(basins))
    rng = np.random.default_rng(seed=3)
    selected_indices = []
    for b in basins:
        idx_b = np.where(labels_f == b)[0]
        n_pick = min(per_basin, len(idx_b))
        chosen = rng.choice(idx_b, size=n_pick, replace=False)
        selected_indices.extend(chosen.tolist())
    # Fill up to BASIN_N_MD if needed
    remaining = BASIN_N_MD - len(selected_indices)
    if remaining > 0:
        extra = rng.choice(len(labels_f), size=remaining, replace=False)
        selected_indices.extend(extra.tolist())
    selected_indices = selected_indices[:BASIN_N_MD]

    run_dirs = []
    for i, frame_idx in enumerate(selected_indices):
        run_dir = out_dir / f"run_{i:03d}"
        if (run_dir / "trajectory.dcd").exists():
            run_dirs.append(run_dir)
            continue
        ensure_dir(run_dir)
        start_pos = all_positions_nm[frame_idx]   # (n_atoms, 3)
        run_single_md(
            TOPOLOGY_DIR,
            duration_ns=BASIN_MD_PS / 1000.0,
            scale_factor=S_COLD,
            temperature_k=TEMPERATURE_K,
            platform=platform,
            seed=4 + i,
            output_dir=run_dir,
            start_positions_nm=start_pos,
            minimize_steps=500,
            equilibration_nvt_ps=0.0,
            traj_interval_ps=BASIN_TRAJ_PS,
        )
        if (i + 1) % 10 == 0:
            print(f"  Completed {i+1}/{BASIN_N_MD} basin MD runs")
        run_dirs.append(run_dir)

    print(f"  Basin MD done. {len(run_dirs)} trajectories in {out_dir}")
    return run_dirs


def _downsample_trajectories(
    phi_all: np.ndarray,
    psi_all: np.ndarray,
    boundaries: np.ndarray,
    basin_labels: np.ndarray,
    stride: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Take every stride-th frame within each trajectory.

    Returns (phi_ds, psi_ds, bounds_ds, labels_ds, orig_indices) where
    orig_indices[i] is the index into the original full-resolution arrays
    for downsampled frame i.
    """
    phi_segs, psi_segs, lbl_segs, idx_segs, bounds_ds = [], [], [], [], [0]
    for i in range(len(boundaries) - 1):
        s, e = int(boundaries[i]), int(boundaries[i + 1])
        idx = np.arange(s, e, stride)
        if len(idx) == 0:
            continue
        phi_segs.append(phi_all[idx])
        psi_segs.append(psi_all[idx])
        lbl_segs.append(basin_labels[idx])
        idx_segs.append(idx)
        bounds_ds.append(bounds_ds[-1] + len(idx))
    if not phi_segs:
        empty = np.array([], dtype=float)
        return empty, empty, np.array([0], dtype=int), np.array([], dtype=str), np.array([], dtype=int)
    return (
        np.concatenate(phi_segs),
        np.concatenate(psi_segs),
        np.array(bounds_ds, dtype=int),
        np.concatenate(lbl_segs),
        np.concatenate(idx_segs).astype(int),
    )


def _precompute_phi_psi(basin_md_dirs: list[Path], out_dir: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load phi/psi for all basin MD frames (cached after first call)."""
    ensure_dir(out_dir)
    phi_npy   = out_dir / "phi_all.npy"
    psi_npy   = out_dir / "psi_all.npy"
    bound_npy = out_dir / "traj_boundaries.npy"
    if not phi_npy.exists():
        traj_paths = [d / "trajectory.dcd" for d in basin_md_dirs
                      if (d / "trajectory.dcd").exists()]
        phi_list, psi_list, boundaries = [], [], [0]
        for dcd in traj_paths:
            phi, psi = load_phi_psi(dcd)
            phi_list.append(phi); psi_list.append(psi)
            boundaries.append(boundaries[-1] + len(phi))
        np.save(str(phi_npy),   np.concatenate(phi_list))
        np.save(str(psi_npy),   np.concatenate(psi_list))
        np.save(str(bound_npy), np.array(boundaries))
        print(f"  Pre-computed phi/psi for {len(traj_paths)} trajectories.")
    return (np.load(str(phi_npy)),
            np.load(str(psi_npy)),
            np.load(str(bound_npy)).astype(int))


def step5a_kinetic_basins(
    phi_all: np.ndarray,
    psi_all: np.ndarray,
    boundaries: np.ndarray,
    phi_f: np.ndarray,
    psi_f: np.ndarray,
    out_dir: Path,
) -> tuple[object, np.ndarray, np.ndarray, np.ndarray]:
    """KMeans + connected components → Level-1 basin labels.

    Returns (kmeans, microstate_to_basin, basin_labels_frame, basin_labels_f).
    """
    print("\n=== Step 5a: Kinetic basin analysis ===")
    ensure_dir(out_dir)
    import pickle

    km_path  = out_dir / "kmeans.pkl"
    m2b_path = out_dir / "microstate_to_basin.npy"
    lf_path  = out_dir / "basin_labels_frame.npy"
    lfais_path = out_dir / "basin_labels_f.npy"

    if not km_path.exists():
        km = fit_kmeans_torus(phi_all, psi_all, n_clusters=N_KMEANS)
        km_path.write_bytes(pickle.dumps(km))
    else:
        km = pickle.loads(km_path.read_bytes())

    micro = predict_microstates(phi_all, psi_all, km)
    C = build_transition_counts(micro, boundaries, lag=1)
    n_basins, m2b = find_level1_basins(C, min_count=MIN_TRANS)
    np.save(str(m2b_path), m2b)

    basin_labels_frame = m2b[micro].astype(str)
    np.save(str(lf_path), basin_labels_frame)

    basin_labels_f = assign_level1(phi_f, psi_f, km, m2b)
    np.save(str(lfais_path), basin_labels_f)

    print(f"  KMeans microstates: {N_KMEANS}  →  Level-1 basins: {n_basins}")
    basin_summary(phi_all, psi_all, basin_labels_frame, boundaries)
    return km, m2b, basin_labels_frame, basin_labels_f


def step5b_riteweight_per_basin(
    phi_all: np.ndarray,
    psi_all: np.ndarray,
    boundaries: np.ndarray,
    basin_labels_frame: np.ndarray,
    out_dir: Path,
    orig_indices: np.ndarray | None = None,
) -> None:
    """Run RITE-weight independently within each Level-1 basin.

    phi_all / psi_all / boundaries / basin_labels_frame may be downsampled
    (option B).  orig_indices[i] maps downsampled frame i back to its index
    in the full-resolution basin MD frame pool; saved as rite_orig_indices.npy
    so that step 6 can build the RITE-weighted source DCD correctly.
    """
    print("\n=== Step 5b: Per-basin RITE-weight ===")
    ensure_dir(out_dir)

    basins = sorted(set(basin_labels_frame))
    for B in basins:
        basin_out = out_dir / f"basin_{B}"
        done_flag = basin_out / "frame_weights.npy"
        if done_flag.exists():
            print(f"  Basin {B}: already done, skipping.")
            continue

        ensure_dir(basin_out)
        phi_B, psi_B, bounds_B = filter_basin_trajectories(
            phi_all, psi_all, basin_labels_frame, boundaries, B)

        # Save original-frame indices for this basin's filtered frames
        if orig_indices is not None:
            ds_idx_B = basin_original_indices(basin_labels_frame, boundaries, B)
            np.save(str(basin_out / "rite_orig_indices.npy"), orig_indices[ds_idx_B])

        n_frames = len(phi_B)
        n_segs   = len(bounds_B) - 1
        if n_frames < 10 or n_segs < 2:
            print(f"  Basin {B}: {n_frames} frames / {n_segs} segments — too few, using uniform weights.")
            np.save(str(done_flag), np.ones(n_frames) / max(n_frames, 1))
            np.save(str(basin_out / "phi_all.npy"), phi_B)
            np.save(str(basin_out / "psi_all.npy"), psi_B)
            np.save(str(basin_out / "traj_boundaries.npy"), bounds_B)
            continue

        phi_npy   = basin_out / "phi_all.npy"
        psi_npy   = basin_out / "psi_all.npy"
        bound_npy = basin_out / "traj_boundaries.npy"
        np.save(str(phi_npy),   phi_B)
        np.save(str(psi_npy),   psi_B)
        np.save(str(bound_npy), bounds_B)

        n_clusters = max(10, min(30, n_frames // 20))
        cmd = [
            str(RITEWEIGHT_PYTHON),
            str(Path(__file__).parent / "run_riteweight_step.py"),
            "--phi-npy",        str(phi_npy),
            "--psi-npy",        str(psi_npy),
            "--boundaries-npy", str(bound_npy),
            "--output-dir",     str(basin_out),
            "--clusters",       str(n_clusters),
            "--iterations",     "300",
            "--lag-frames",     "1",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"  Basin {B} RITE-weight failed:\n{result.stderr[-500:]}")
            np.save(str(done_flag), np.ones(n_frames) / n_frames)
        else:
            print(f"  Basin {B}: {n_frames} frames / {n_segs} segs — {result.stdout.strip()}")


def detect_unconnected_basins(
    phi_all: np.ndarray,
    psi_all: np.ndarray,
    gmm: GaussianMixture,
    traj_boundaries: np.ndarray,
) -> pd.DataFrame:
    """Count inter-basin transitions in basin MD and report connectivity."""
    basin_all = assign_basins(gmm, phi_all, psi_all)
    basins = sorted(set(basin_all))
    n = len(basins)
    idx_map = {b: i for i, b in enumerate(basins)}
    trans_count = np.zeros((n, n), dtype=int)

    for i in range(len(traj_boundaries) - 1):
        start, end = traj_boundaries[i], traj_boundaries[i + 1]
        seq = basin_all[start:end]
        for t in range(len(seq) - 1):
            a, b = idx_map[seq[t]], idx_map[seq[t + 1]]
            if a != b:
                trans_count[a, b] += 1
                trans_count[b, a] += 1

    rows = []
    for i, bi in enumerate(basins):
        for j, bj in enumerate(basins):
            if i < j:
                rows.append({
                    "basin_A": bi, "basin_B": bj,
                    "transitions": int(trans_count[i, j]),
                    "connected": trans_count[i, j] > 0,
                })
    df = pd.DataFrame(rows)
    print("\n  Inter-basin transition counts:")
    print(df.to_string(index=False))
    return df


def _build_rite_weighted_source(
    basin_md_dirs: list[Path],
    basin_labels_frame: np.ndarray,
    boundaries: np.ndarray,
    per_basin_dir: Path,
    out_dcd: Path,
    k: int,
    seed: int,
) -> np.ndarray:
    """Draw k frames stratified equally across basins, weighted by RITE within each basin.

    Each basin receives exactly k // n_basins samples (remainder distributed to the
    first basins). Within a basin the sampling probability is proportional to the
    RITE-weight for that frame.  This gives every basin equal representation in the
    backward AIS pool regardless of its raw frame count, so BAR has equal statistical
    power per basin.

    Returns the original frame indices (into the full concatenated DCD) of the
    k selected frames, written to out_dcd in the order drawn.
    """
    basins  = sorted(set(basin_labels_frame))
    n_total = len(basin_labels_frame)
    n_basins = len(basins)
    rng = np.random.default_rng(seed)

    # k_per_basin: equal allocation; remainder goes to the first few basins
    k_base  = k // n_basins
    k_extra = k % n_basins
    k_alloc = {B: k_base + (1 if i < k_extra else 0) for i, B in enumerate(basins)}

    all_selected = []
    for B in basins:
        # Resolve RITE weight → original frame index mapping
        rw_path  = per_basin_dir / f"basin_{B}" / "frame_weights.npy"
        ori_path = per_basin_dir / f"basin_{B}" / "rite_orig_indices.npy"
        if rw_path.exists():
            rw = np.load(str(rw_path))
            if ori_path.exists():
                orig_idx = np.load(str(ori_path))
            else:
                orig_idx = basin_original_indices(basin_labels_frame, boundaries, B)
            if len(orig_idx) != len(rw):
                print(f"  WARNING basin {B}: index/weight length mismatch "
                      f"({len(orig_idx)} vs {len(rw)}), using uniform.")
                rw = np.ones(len(orig_idx))
        else:
            # No RITE result — fall back to uniform within basin
            orig_idx = basin_original_indices(basin_labels_frame, boundaries, B)
            rw = np.ones(len(orig_idx))

        total = rw.sum()
        if total <= 0.0 or not np.isfinite(total) or len(orig_idx) == 0:
            rw = np.ones(max(len(orig_idx), 1))
        p = rw / rw.sum()
        ess = 1.0 / (p ** 2).sum()

        chosen_local = rng.choice(len(orig_idx), size=k_alloc[B], replace=True, p=p)
        chosen_global = orig_idx[chosen_local]
        all_selected.append(chosen_global)
        print(f"  Basin {B}: {k_alloc[B]} samples drawn  "
              f"(RITE ESS={ess:.0f}/{len(orig_idx)})")

    selected = np.concatenate(all_selected).astype(int)

    # Write selected frames to a new DCD (in the order drawn: basin 0, 1, 2, ...)
    all_dcds = [d / "trajectory.dcd" for d in basin_md_dirs if (d / "trajectory.dcd").exists()]
    full_traj = md.load_dcd(str(all_dcds[0]), top=str(PRMTOP))
    for p in all_dcds[1:]:
        full_traj = md.join([full_traj, md.load_dcd(str(p), top=str(PRMTOP))])
    full_traj[selected].save_dcd(str(out_dcd))

    print(f"  Total: {len(selected)} frames written to {out_dcd.name} "
          f"({k_base} per basin, equal allocation)")
    return selected


def step6_backward_ais(
    basin_md_dirs: list[Path],
    basin_labels_frame: np.ndarray,
    boundaries: np.ndarray,
    per_basin_dir: Path,
    km, m2b: np.ndarray,
    out_dir: Path,
    platform: str,
) -> tuple[np.ndarray, np.ndarray]:
    """1000 backward AIS from s=1.0→s=0.4, seeded from RITE-weighted basin MD frames."""
    print(f"\n=== Step 6: Backward AIS (s=1.0→{S_HOT}, {AIS_K} traj, {AIS_T_PS} ps) ===")
    ensure_dir(out_dir)

    import shutil

    # Build RITE-weighted source DCD (replaces the old uniform concatenation)
    source_dcd = out_dir / "backward_source_rite.dcd"
    selected_orig = None
    if not source_dcd.exists():
        print("  Building RITE-weighted backward source DCD …")
        selected_orig = _build_rite_weighted_source(
            basin_md_dirs, basin_labels_frame, boundaries,
            per_basin_dir, source_dcd, k=AIS_K, seed=60,
        )
        np.save(str(out_dir / "rite_selected_orig_indices.npy"), selected_orig)
    else:
        selected_orig = np.load(str(out_dir / "rite_selected_orig_indices.npy"))

    # Source dir layout expected by ais_linear
    source_dir = out_dir / "source_dir"
    ensure_dir(source_dir)
    link = source_dir / "trajectory.dcd"
    if not link.exists():
        link.symlink_to(source_dcd.resolve())
    first_run = next(d for d in basin_md_dirs if (d / "config.json").exists())
    if not (source_dir / "config.json").exists():
        shutil.copy(str(first_run / "config.json"), str(source_dir / "config.json"))
    if not (source_dir / "start_structure.pdb").exists():
        shutil.copy(str(first_run / "start_structure.pdb"), str(source_dir / "start_structure.pdb"))

    # Record basin labels for each frame in the resampled source DCD
    phi_src, psi_src = load_phi_psi(source_dcd)
    basin_src = assign_level1(phi_src, psi_src, km, m2b)
    np.save(str(out_dir / "basin_labels_source.npy"), basin_src)

    t_ais, freq_ais = ais_t_steps(AIS_T_PS, AIS_TIMESTEP, AIS_FREQ)
    ais_dir = out_dir / "ais_out"
    cfg = LinearAISConfig(
        solvent="implicit",
        k_ais=AIS_K,
        t_ais=t_ais,
        freq_ais=freq_ais,
        s_hot=S_COLD,         # reversed: start at s=1.0
        s_cold=S_HOT,         # reversed: end at s=0.4
        temperature_k=TEMPERATURE_K,
        platform=platform,
        seed=6,
        input_scaled_dir=source_dir,
        output_dir=ais_dir,
        save_traj_every_switch=False,
        overwrite=True,
    )
    summary = run_linear_scaling_ais(cfg)
    print(f"  Backward AIS done. ESS={summary['ess']:.1f} ({summary['ess_over_k']*100:.1f}%)")

    # Each AIS trajectory i started from frame i of source_dcd (sequential, since
    # the resampled DCD has exactly AIS_K frames and ais_linear samples them in order)
    logw_r = load_ais_logw(ais_dir / "ais_trajectory_summary.csv")
    start_frames = pd.read_csv(ais_dir / "selected_initial_frames.csv")
    frame_col = [c for c in start_frames.columns if "frame" in c.lower()][0]
    start_idx = start_frames[frame_col].values.astype(int)
    basin_r = basin_src[start_idx]

    np.save(str(out_dir / "final_logw_r.npy"),   logw_r)
    np.save(str(out_dir / "basin_labels_r.npy"), basin_r)
    return logw_r, basin_r


def step7_crooks_bar(
    logw_f: np.ndarray, basin_f: np.ndarray,
    logw_r: np.ndarray, basin_r: np.ndarray,
    out_dir: Path,
) -> pd.DataFrame:
    """Per-basin Crooks BAR and inter-basin ΔΔF table."""
    print("\n=== Step 7: Per-basin Crooks BAR ===")
    ensure_dir(out_dir)

    df_basin = per_basin_crooks(logw_f, basin_f, logw_r, basin_r, temperature_k=TEMPERATURE_K)
    df_inter = inter_basin_delta_f(df_basin, estimator="bar")

    print("\n  Per-basin ΔF (H→C):")
    print(df_basin[["n_f","n_r","dF_jar_f_kT","dF_bar_kT","ddf_bar_kT"]].to_string())
    print("\n  Inter-basin ΔΔF (BAR):")
    print(df_inter.to_string())

    df_basin.to_csv(str(out_dir / "per_basin_crooks.csv"))
    df_inter.to_csv(str(out_dir / "inter_basin_ddf.csv"))
    return df_basin


# ── main ──────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="Crooks inter-basin ΔF protocol for ACE-ALA-NME.")
    p.add_argument("--skip", nargs="*", type=int, default=[], metavar="N",
                   help="Steps to skip (e.g. --skip 1 2 if hot MD and forward AIS are done).")
    p.add_argument("--platform", default="OpenCL", choices=["OpenCL", "CPU", "CUDA"],
                   help="OpenMM platform.")
    p.add_argument("--run-tag", default="2026-06-15-crooks-basin",
                   help="Tag for output directories under data/alanine_dipeptide/.")
    p.add_argument("--s-hot", type=float, default=S_HOT,
                   help=f"Scaling factor for hot MD and forward AIS start (default {S_HOT}).")
    p.add_argument("--ais-ps", type=float, default=AIS_T_PS,
                   help=f"AIS switching duration in ps, applied to both fwd and bwd (default {AIS_T_PS}).")
    p.add_argument("--basin-out-ps", type=float, default=BASIN_TRAJ_PS,
                   help=f"Frame save interval for basin MD in ps (default {BASIN_TRAJ_PS}).")
    p.add_argument("--n-kmeans", type=int, default=N_KMEANS,
                   help=f"KMeans microstates for kinetic basin analysis (default {N_KMEANS}).")
    p.add_argument("--min-trans", type=int, default=MIN_TRANS,
                   help=f"Min symmetrised transition count to keep an edge (default {MIN_TRANS}).")
    p.add_argument("--rite-stride", type=int, default=1,
                   help="Downsample basin MD by this stride before RITE-weight (default 1 = no downsample). "
                        "Step 5a (kinetic basins) always uses the full-resolution trajectories.")
    p.add_argument("--hot-out-ps", type=float, default=HOT_TRAJ_PS,
                   help=f"Frame save interval for hot MD in ps (default {HOT_TRAJ_PS}). "
                        "Set to 1.0 for the v4 TRAM estimator to densify B1/B3 basin sampling.")
    return p.parse_args()


def main():
    args = parse_args()
    skip = set(args.skip)
    tag  = args.run_tag
    plat = args.platform

    # Apply CLI overrides to module-level parameters
    global S_HOT, AIS_T_PS, BASIN_TRAJ_PS, N_KMEANS, MIN_TRANS, HOT_TRAJ_PS
    S_HOT         = args.s_hot
    AIS_T_PS      = args.ais_ps
    BASIN_TRAJ_PS = args.basin_out_ps
    N_KMEANS      = args.n_kmeans
    MIN_TRANS     = args.min_trans
    HOT_TRAJ_PS   = args.hot_out_ps

    print(f"  s_hot={S_HOT}  ais_ps={AIS_T_PS}  basin_out_ps={BASIN_TRAJ_PS}  "
          f"n_kmeans={N_KMEANS}  min_trans={MIN_TRANS}  hot_out_ps={HOT_TRAJ_PS}")

    base = Path("data/alanine_dipeptide") / tag
    HOT_MD_DIR   = base / "step1_hot_md"
    FWD_AIS_DIR  = base / "step2_forward_ais"
    BASIN_INFO   = base / "step3_basin_info"
    BASIN_MD_DIR = base / "step4_basin_md"
    RW_DIR       = base / "step5_riteweight"       # phi/psi cache shared with step 5a
    KINETIC_DIR  = base / "step5_kinetic"           # KMeans + connected-component results
    PER_BASIN_DIR = base / "step5_riteweight_per_basin"  # per-Level-1-basin RITE-weight
    BWD_AIS_DIR  = base / "step6_backward_ais"
    BAR_DIR      = base / "step7_bar_results"

    t0 = time.time()

    import pickle

    # Step 1: Hot MD
    if 1 not in skip:
        step1_hot_md(HOT_MD_DIR, plat)
    else:
        print("  [skip] Step 1")

    # Step 2: Forward AIS
    if 2 not in skip:
        step2_forward_ais(HOT_MD_DIR, FWD_AIS_DIR, plat)
    else:
        print("  [skip] Step 2")

    # Step 3: Basin assignment (GMM, used only for step-4 seeding)
    if 3 not in skip:
        gmm, labels_f_gmm, logw_f = step3_basin_assignment(FWD_AIS_DIR, BASIN_INFO)
    else:
        print("  [skip] Step 3 — loading saved GMM + forward AIS data")
        gmm         = pickle.loads((BASIN_INFO / "gmm.pkl").read_bytes())
        labels_f_gmm = np.load(str(BASIN_INFO / "basin_labels_f.npy"), allow_pickle=True)
        logw_f      = np.load(str(BASIN_INFO / "final_logw_f.npy"))
    phi_end_f = np.load(str(BASIN_INFO / "phi_end_f.npy"))
    psi_end_f = np.load(str(BASIN_INFO / "psi_end_f.npy"))

    # Step 4: Basin MD
    if 4 not in skip:
        run_dirs = step4_basin_md(FWD_AIS_DIR, gmm, labels_f_gmm, BASIN_MD_DIR, plat)
    else:
        print("  [skip] Step 4")
        run_dirs = sorted(BASIN_MD_DIR.glob("run_*"))

    # Step 5: Two-level kinetic basin analysis + per-basin RITE-weight
    rite_stride = args.rite_stride
    if 5 not in skip:
        phi_all, psi_all, boundaries = _precompute_phi_psi(run_dirs, RW_DIR)
        # 5a: kinetic basins at FULL resolution (needs dense intra-run transitions)
        km, m2b, basin_labels_frame, labels_f_kin = step5a_kinetic_basins(
            phi_all, psi_all, boundaries, phi_end_f, psi_end_f, KINETIC_DIR)
        # 5b: RITE-weight on optionally downsampled frames (option B)
        if rite_stride > 1:
            print(f"  Downsampling basin MD by stride {rite_stride} for RITE-weight …")
            phi_rw, psi_rw, bounds_rw, labels_rw, orig_idx_rw = _downsample_trajectories(
                phi_all, psi_all, boundaries, basin_labels_frame, rite_stride)
            print(f"  Full-res frames: {len(phi_all)}  →  RITE frames: {len(phi_rw)}")
        else:
            phi_rw, psi_rw, bounds_rw, labels_rw, orig_idx_rw = (
                phi_all, psi_all, boundaries, basin_labels_frame, None)
        step5b_riteweight_per_basin(
            phi_rw, psi_rw, bounds_rw, labels_rw, PER_BASIN_DIR, orig_idx_rw)
    else:
        print("  [skip] Step 5 — loading kinetic basin results")
        km                 = pickle.loads((KINETIC_DIR / "kmeans.pkl").read_bytes())
        m2b                = np.load(str(KINETIC_DIR / "microstate_to_basin.npy"))
        basin_labels_frame = np.load(str(KINETIC_DIR / "basin_labels_frame.npy"), allow_pickle=True)
        labels_f_kin       = np.load(str(KINETIC_DIR / "basin_labels_f.npy"), allow_pickle=True)
        phi_all            = np.load(str(RW_DIR / "phi_all.npy"))
        psi_all            = np.load(str(RW_DIR / "psi_all.npy"))
        boundaries         = np.load(str(RW_DIR / "traj_boundaries.npy")).astype(int)

    # Step 6: Backward AIS seeded from RITE-weighted basin MD frames
    if 6 not in skip:
        logw_r, basin_r = step6_backward_ais(
            run_dirs, basin_labels_frame, boundaries, PER_BASIN_DIR,
            km, m2b, BWD_AIS_DIR, plat,
        )
    else:
        print("  [skip] Step 6 — loading backward AIS results")
        logw_r   = np.load(str(BWD_AIS_DIR / "final_logw_r.npy"))
        basin_r  = np.load(str(BWD_AIS_DIR / "basin_labels_r.npy"), allow_pickle=True).astype(str)

    # Step 7: Per-basin Crooks BAR using kinetic Level-1 labels
    if 7 not in skip:
        df_result = step7_crooks_bar(logw_f, labels_f_kin, logw_r, basin_r, BAR_DIR)

    elapsed = (time.time() - t0) / 60
    print(f"\n✓ Protocol complete in {elapsed:.1f} min. Results in {BAR_DIR}")


if __name__ == "__main__":
    main()
