#!/usr/bin/env python3
"""analyze_r0_dih0_dih6_2dhist.py — R0 internal structure in (dih#0, dih#6): REMD vs AIS weighted landings.

dih#0 and dih#6 are the ONLY two backbone dihedrals that are bimodal within R0 in REMD (dih#0 ~84/16, dih#6
~55/45), so their JOINT (dih#0, dih#6) carries R0's real internal structure. This draws two matched 2D histograms
of R0 frames — one from REMD (equilibrium), one from the forward-AIS landings weighted by exp(final_logw) — to
test whether the AIS reweighting reproduces R0's internal (dih#0, dih#6) populations.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_r0_dih0_dih6_2dhist
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
FWD = ROOT / "data/rgd/diagnostics/bais_eval/rgd/gen0/fwd"
OUT = ROOT / "results/rgd/report"
SEP = 14
A, B = 0, 6                                          # the two bimodal-within-R0 dihedrals


def in_major(D):
    return (D[:, SEP] >= -180) & (D[:, SEP] <= -15)


def process(name="rgd", bins=48):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone"); Q = np.asarray(q)

    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    Dr = np.degrees(md.compute_dihedrals(remd, Q)); r0 = in_major(Dr)

    land = md.load_dcd(str(FWD / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    Dl = np.degrees(md.compute_dihedrals(land, Q)); l0 = in_major(Dl)
    logw = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    w = np.exp(logw - logw.max()); wl = w[l0]
    ess = float(wl.sum() ** 2 / np.sum(wl ** 2))

    rng = [[-180, 180], [-180, 180]]
    Hr, xe, ye = np.histogram2d(Dr[r0, A], Dr[r0, B], bins=bins, range=rng, density=True)
    Hl, _, _ = np.histogram2d(Dl[l0, A], Dl[l0, B], bins=bins, range=rng, weights=wl, density=True)

    # R0's bimodality is in dih#6: two wells at ~+75 deg and ~+140 deg (both at dih#0>0), so split dih#6 at +110
    # to quantify the two-well populations and whether AIS reproduces them.
    def dih6_wells(dB, ww=None, cut=110.0):
        ww = np.ones(len(dB)) if ww is None else ww; tot = ww.sum()
        lo = float(ww[(dB > 0) & (dB < cut)].sum() / tot)          # dih6 ~ +75 well
        up = float(ww[dB >= cut].sum() / tot)                      # dih6 ~ +140 well
        return round(lo, 3), round(up, 3)
    r_wells = dih6_wells(Dr[r0, B]); l_wells = dih6_wells(Dl[l0, B], wl)
    print(f"REMD-R0 frames {int(r0.sum())} | AIS-R0 landings {int(l0.sum())} (ESS {ess:.1f})", file=sys.stderr)
    print(f"  REMD dih6 wells: lower(+75)={r_wells[0]}  upper(+140)={r_wells[1]}", file=sys.stderr)
    print(f"  AIS  dih6 wells: lower(+75)={l_wells[0]}  upper(+140)={l_wells[1]}", file=sys.stderr)

    make_figure(name, Hr, Hl, xe, ye, r_wells, l_wells, int(r0.sum()), int(l0.sum()), ess)


def make_figure(name, Hr, Hl, xe, ye, r_wells, l_wells, n_remd, n_ais, ess):
    fig, ax = plt.subplots(1, 2, figsize=(13, 5.6))
    ext = [xe[0], xe[-1], ye[0], ye[-1]]
    for axi, H, title in [(ax[0], Hr, f"REMD-R0 (equilibrium, n={n_remd})"),
                          (ax[1], Hl, f"AIS weighted landings, R0 (n={n_ais}, ESS={ess:.1f})")]:
        im = axi.imshow(H.T, origin="lower", extent=ext, aspect="auto", cmap="viridis",
                        vmin=0, vmax=H.max() if H.max() > 0 else 1)
        axi.set_xlabel(f"dih #{A} (deg)"); axi.set_ylabel(f"dih #{B} (deg)")
        axi.axhline(110, color="w", ls="--", lw=0.7, alpha=0.6)     # dih#6 well split (+75 vs +140)
        axi.set_title(title, fontsize=10)
        fig.colorbar(im, ax=axi, fraction=0.046, pad=0.04, label="density (own scale)")
    # annotate the two dih#6 wells (both at dih#0>0; they are density-CONNECTED, not two clusters)
    for axi, wells in [(ax[0], r_wells), (ax[1], l_wells)]:
        axi.text(130, 68, f"dih6≈+75\n{wells[0]:.0%}", color="w", fontsize=9, fontweight="bold",
                 va="center", ha="center")
        axi.text(130, 148, f"dih6≈+140\n{wells[1]:.0%}", color="w", fontsize=9, fontweight="bold",
                 va="center", ha="center")
    fig.suptitle(f"{name}: R0 in (dih#0, dih#6) — dih#6 is bimodal (two wells at +75/+140, both dih#0>0) but the "
                 f"wells are density-CONNECTED (bridge), so HDBSCAN keeps R0 as one cluster.  Does AIS reproduce it?",
                 fontsize=10)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_r0_dih0_dih6_2dhist.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_r0_dih0_dih6_2dhist.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
