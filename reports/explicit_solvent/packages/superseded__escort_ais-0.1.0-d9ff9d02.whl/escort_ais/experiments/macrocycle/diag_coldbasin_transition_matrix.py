import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
trs=[md.load_dcd(s,top=top)[50:] for s in seeds]
Xs=[featurize(t,q) for t in trs]; Xall=np.concatenate(Xs)
gt=np.concatenate([fz.assign(t) for t in trs])
DI=[2,12,14]
dih=[np.degrees(md.compute_dihedrals(t,q[DI])) for t in trs]; dall=np.concatenate(dih)  # (N,3) deg
def mdwell(d,D):
    out=d.copy(); cur=d[0]
    for i in range(1,len(d)):
        if d[i]!=cur and i+D<=len(d) and np.all(d[i:i+D]==d[i]): cur=d[i]
        out[i]=cur
    return out
K=24
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(K,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
dtr=[mdwell(km.predict(sc.transform(pca.transform(X))).astype(int),50) for X in Xs]
full=np.concatenate(dtr)
pop=np.bincount(full,minlength=K).astype(float); pop/=pop.sum()
minorf=np.array([gt[full==k].mean() for k in range(K)])
order=np.argsort(-pop); remap=np.empty(K,int); remap[order]=np.arange(K)
full_r=remap[full]; pop_r=pop[order]; minorf_r=minorf[order]
C=np.zeros((K,K),int)
for d in dtr:
    dd=remap[d]
    for a,b in zip(dd[:-1],dd[1:]):
        if a!=b: C[a,b]+=1
def cmean(ang):  # circular mean in deg
    r=np.radians(ang); return np.degrees(np.arctan2(np.sin(r).mean(),np.cos(r).mean()))
cent=np.array([[cmean(dall[full_r==k,d]) for d in range(3)] for k in range(K)])

fig=plt.figure(figsize=(12,10))
# transition matrix
ax=fig.add_subplot(2,2,1)
M=np.ma.masked_where(C==0,C)
im=ax.imshow(M,cmap='viridis',norm=LogNorm(vmin=1,vmax=C.max()))
ax.set(title=f'24-state crossing matrix (min-dwell 50 ps)\ntotal off-diag = {C.sum()}',xlabel='to state j',ylabel='from state i')
ax.set_xticks(range(0,K,2)); ax.set_yticks(range(0,K,2)); ax.tick_params(labelsize=7)
fig.colorbar(im,ax=ax,label='crossings',shrink=.8)
# dihedral projections
lbl=['dih2 (tor2, fast)','dih12','dih14 (major/minor, slow)']
pairs=[(0,2),(1,2),(0,1)]
for pi,(a,b) in enumerate(pairs):
    ax=fig.add_subplot(2,2,pi+2)
    ax.hist2d(dall[:,a],dall[:,b],bins=80,range=[[-180,180],[-180,180]],cmap='Greys',cmin=1)
    s=ax.scatter(cent[:,a],cent[:,b],s=40+pop_r*4000,c=minorf_r,cmap='coolwarm',vmin=0,vmax=1,edgecolor='k',lw=.6,zorder=3)
    for k in range(K):
        ax.text(cent[k,a],cent[k,b],str(k),fontsize=6,ha='center',va='center',zorder=4)
    ax.set(xlabel=lbl[a],ylabel=lbl[b],xlim=(-180,180),ylim=(-180,180))
    if pi==0: fig.colorbar(s,ax=ax,label='minor fraction (0=major,1=minor)',shrink=.8)
fig.suptitle('geo-cold 24 microstates: transition matrix + location in dihedral space (size ∝ population)',y=1.0)
fig.tight_layout()
p='results/rgd/report/fig_geocold_24states.png'; fig.savefig(p,dpi=140,bbox_inches='tight')
print('saved',p)
print('state 15/16 dih (the fast pair):', np.round(cent[15],0), np.round(cent[16],0))
