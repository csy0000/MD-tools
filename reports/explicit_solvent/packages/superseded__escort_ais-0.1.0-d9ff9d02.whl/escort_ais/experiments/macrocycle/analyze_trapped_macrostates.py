#!/usr/bin/env python3
"""analyze_trapped_macrostates.py — per-seed >60% dwell filter at the kinetic-macrostate level.

Trapped-basin / artifact identification for the bAIS cold reservoirs. Pipeline per compound:
  1. featurize cold-MD frames, KMeans(100) microstates, per-seed discrete trajectories (no cross-seam).
  2. cold-MD transition count matrix (lag) -> strongly-connected components. Largest = ergodic set;
     smaller components = kinetically-isolated traps.
  3. PCCA+ the largest-component MSM into N kinetic macrostates; each disconnected component = its own
     trap macrostate. -> micro->macro map.
  4. per-seed dwell fraction in each macrostate; a seed is "trapped in M" iff dwell(seed,M) > threshold
     (default 0.60). Seeds with no macrostate above threshold are "mixed/untrapped" (attributed nowhere).
  5. per macrostate: #trapped seeds, trapped-seed population, REMD population, forward-AIS landing weight;
     classify real basin (REMD>0.5%) / artifact trap (REMD~0 & fwd~0) / mixed.

Writes data/rgd/diagnostics/bais_eval/<name>/trapped_macrostates.json + a figure per compound.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_trapped_macrostates
"""
from __future__ import annotations

import argparse
import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from scipy.special import logsumexp
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.four_state_msm import reversible_transition_matrix  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from deeptime.markov.msm import MarkovStateModel  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
OUT = ROOT / "results/rgd/report"
REMD = {
    "rgd": "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
    "cilengitide": "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
    "rgd_redPheVal": "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns",
}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide (N-Me)", "rgd_redPheVal": "RGD reduced-PheVal amide"}
ART_REMD = 0.005          # REMD < 0.5% -> not physically populated


def _count_matrix(dtrajs, lag, K):
    C = np.zeros((K, K))
    for d in dtrajs:
        if len(d) > lag:
            np.add.at(C, (d[:-lag], d[lag:]), 1.0)
    return C


def _spectral_gap_n(T, nmax=8):
    ev = np.sort(np.abs(np.linalg.eigvals(T)))[::-1].real
    ev = ev[:min(nmax + 1, len(ev))]
    if len(ev) < 3:
        return max(2, len(ev))
    gaps = ev[1:-1] - ev[2:]              # gaps among the slow (non-stationary) eigenvalues
    return int(np.argmax(gaps) + 2)


def process(name, lag, kmicro, nmacro, thr):
    cfg = load_cfg(name)
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")

    seeds = sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))
    seedX = [featurize(md.load_dcd(s, top=top)[50:], q) for s in seeds]
    Xall = np.concatenate(seedX)
    km = KMeans(kmicro, n_init=8, random_state=0).fit(Xall)
    dtrajs = [km.predict(x) for x in seedX]

    # transition matrix -> strongly connected components
    C = _count_matrix(dtrajs, lag, kmicro)
    ncomp, comp = connected_components(csr_matrix(C > 0), directed=True, connection="strong")
    sizes = np.bincount(comp, weights=np.bincount(np.concatenate(dtrajs), minlength=kmicro))
    largest = int(np.argmax(sizes))
    conn = np.where(comp == largest)[0]

    # PCCA the largest component into kinetic macrostates
    Csub = C[np.ix_(conn, conn)] + 1e-9
    Tsub, pi = reversible_transition_matrix(Csub)
    N = nmacro if nmacro else _spectral_gap_n(Tsub)
    N = int(min(max(N, 2), len(conn)))
    pcca = MarkovStateModel(Tsub, stationary_distribution=pi).pcca(N)
    micro2macro = -np.ones(kmicro, int)
    micro2macro[conn] = pcca.assignments
    # each disconnected component -> its own trap macrostate
    mid = N
    trap_macros = []
    for c in range(ncomp):
        if c == largest:
            continue
        micro2macro[comp == c] = mid
        trap_macros.append(mid)
        mid += 1
    # any never-visited microstate -> nearest connected micro's macro
    for m in np.where(micro2macro < 0)[0]:
        d = ((km.cluster_centers_[conn] - km.cluster_centers_[m]) ** 2).sum(1)
        micro2macro[m] = micro2macro[conn[int(d.argmin())]]
    nmac = mid

    # per-seed dwell fraction per macrostate -> trapped assignment
    seed_macro = [micro2macro[d] for d in dtrajs]
    dwell = np.array([np.bincount(sm, minlength=nmac) / len(sm) for sm in seed_macro])  # (nseed, nmac)
    trapped_in = np.where(dwell.max(1) > thr, dwell.argmax(1), -1)                       # -1 = mixed
    n_mixed = int((trapped_in < 0).sum())

    # REMD population + forward-AIS weight per macrostate
    remd = load_remd_ensemble(Path(ROOT / REMD[name]), "replica_00", cfg.top_pdb, 0)
    p_remd_micro = np.bincount(km.predict(featurize(remd, q)), minlength=kmicro) / len(remd)
    lw, lx = [], []
    for gd in sorted((BE / name).glob("gen*/fwd")):
        s = pd.read_csv(gd / "ais_trajectory_summary.csv")
        t = md.load_dcd(str(gd / "ais_final_coordinates.dcd"), top=top)
        nn = min(len(s), t.n_frames)
        lw.append(s["final_logw"].to_numpy()[:nn]); lx.append(featurize(t[:nn], q))
    lw = np.concatenate(lw); ml = km.predict(np.concatenate(lx))
    pl_micro = np.array([np.exp(logsumexp(lw[ml == S])) if (ml == S).any() else 0.0 for S in range(kmicro)])
    pl_micro /= pl_micro.sum()

    def macro_sum(v):
        return np.array([v[micro2macro == M].sum() for M in range(nmac)])
    remd_macro = macro_sum(p_remd_micro)
    fwd_macro = macro_sum(pl_micro)
    cold_macro = macro_sum(np.bincount(np.concatenate(dtrajs), minlength=kmicro) / sum(len(d) for d in dtrajs))

    rows = []
    for M in range(nmac):
        nt = int((trapped_in == M).sum())
        if remd_macro[M] >= ART_REMD:
            cls = "real basin"
        elif nt > 0:
            cls = "artifact trap"
        else:
            cls = "minor/empty"
        rows.append(dict(macro=M, kind=("trap-component" if M in trap_macros else "PCCA"),
                         n_trapped_seeds=nt, trapped_seed_frac=round(nt / len(seeds), 3),
                         cold_pop=round(float(cold_macro[M]), 4), remd_pop=round(float(remd_macro[M]), 4),
                         fwd_weight=round(float(fwd_macro[M]), 4), classification=cls))
    rows.sort(key=lambda r: -r["n_trapped_seeds"])
    result = dict(name=name, n_seeds=len(seeds), lag=lag, n_microstates=kmicro, n_macrostates=nmac,
                  n_pcca=N, n_trap_components=len(trap_macros), dwell_threshold=thr,
                  n_mixed_untrapped=n_mixed, connected_frac=round(float(sizes[largest] / sizes.sum()), 3),
                  macrostates=rows)
    (BE / name / "trapped_macrostates.json").write_text(json.dumps(result, indent=2))

    # figure: trapped-seed count per macrostate (coloured by REMD pop) + per-seed max-dwell histogram
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))
    order = np.argsort(-np.array([r["n_trapped_seeds"] for r in rows]))
    labels = [f"M{rows[i]['macro']}\n{rows[i]['kind'][:4]}" for i in order]
    nt = [rows[i]["n_trapped_seeds"] for i in order]
    rp = [rows[i]["remd_pop"] for i in order]
    bars = ax[0].bar(range(len(rows)), nt, color=plt.cm.viridis(np.clip(np.array(rp) / 0.05, 0, 1)))
    ax[0].set_xticks(range(len(rows))); ax[0].set_xticklabels(labels, fontsize=7)
    ax[0].set_ylabel(f"# seeds trapped (>{int(thr*100)}% dwell)")
    ax[0].set_title(f"{NICE[name]}: seeds trapped per kinetic macrostate\n(colour = REMD population; dark = artifact)",
                    fontsize=10)
    for i, r in enumerate([rows[j] for j in order]):
        if r["classification"] == "artifact trap":
            ax[0].text(i, nt[i], "art", ha="center", va="bottom", fontsize=7, color="crimson")
    ax[1].hist(dwell.max(1), bins=np.linspace(0, 1, 26), color="#4477AA", edgecolor="k", lw=0.4)
    ax[1].axvline(thr, ls="--", color="crimson", label=f">{int(thr*100)}% = trapped")
    ax[1].set_xlabel("per-seed max dwell fraction (in any macrostate)")
    ax[1].set_ylabel("# seeds"); ax[1].legend(fontsize=8)
    ax[1].set_title(f"per-seed trapping: {len(seeds)-n_mixed}/{len(seeds)} trapped, {n_mixed} mixed", fontsize=10)
    fig.suptitle(f"[{NICE[name]}] {nmac} kinetic macrostates ({N} PCCA + {len(trap_macros)} trap components); "
                 f"connected {result['connected_frac']:.0%}", y=1.02, fontsize=11)
    fig.tight_layout()
    fig.savefig(OUT / f"fig_{name}_trapped_macrostates.png", dpi=140, bbox_inches="tight")
    plt.close(fig)

    art = [r for r in rows if r["classification"] == "artifact trap"]
    print(f"[{name}] {nmac} macros ({N} PCCA + {len(trap_macros)} traps); {len(seeds)-n_mixed}/{len(seeds)} seeds "
          f"trapped, {n_mixed} mixed; {len(art)} artifact-trap macros hold "
          f"{sum(r['n_trapped_seeds'] for r in art)} seeds at REMD {sum(r['remd_pop'] for r in art):.3f} / "
          f"fwd {sum(r['fwd_weight'] for r in art):.3f}", file=sys.stderr)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--compounds", default="rgd,cilengitide,rgd_redPheVal")
    ap.add_argument("--n-microstates", type=int, default=100)
    ap.add_argument("--lag", type=int, default=20)
    ap.add_argument("--n-macrostates", type=int, default=0, help="0 = pick from MSM spectral gap")
    ap.add_argument("--dwell-threshold", type=float, default=0.60)
    args = ap.parse_args()
    for name in args.compounds.split(","):
        process(name.strip(), args.lag, args.n_microstates, args.n_macrostates or None, args.dwell_threshold)


if __name__ == "__main__":
    main()
