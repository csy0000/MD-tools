"""run_basin_hot_walkers.py — Stage 1b: run K independent hot MD walkers at s_hot.

Reads seed_positions.npy from a stage-01 seeds dir, runs K independent
MD walkers at scale_factor=s_hot via multi_walker_md.run_independent_walkers,
and writes per-walker DCDs + walker_index.npy / frame_index.npy.

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_basin_hot_walkers \\
        --seeds-dir data/.../01_seeds \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/.../01_hot \\
        --scale-factor 0.4 --duration-ns 1.0 --temperature-k 300.0 \\
        --platform OpenCL --traj-interval-ps 10.0 [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np



def main() -> None:
    parser = argparse.ArgumentParser(description="Run K independent hot MD walkers.")
    parser.add_argument("--seeds-dir", required=True, type=Path,
                        help="Stage-01 seeds dir containing seed_positions.npy.")
    parser.add_argument("--topology-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--scale-factor", type=float, default=0.4,
                        help="REST2 hot scale factor (e.g. 0.4).")
    parser.add_argument("--duration-ns", type=float, default=1.0)
    parser.add_argument("--temperature-k", type=float, default=300.0)
    parser.add_argument("--timestep-fs", type=float, default=2.0)
    parser.add_argument("--friction-per-ps", type=float, default=1.0)
    parser.add_argument("--traj-interval-ps", type=float, default=10.0)
    parser.add_argument("--platform", default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-walkers", type=int, default=None,
                        help="Limit to first N walkers (useful for testing).")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    from escort_ais.methods.md_run import steps_from_time

    seeds_dir = Path(args.seeds_dir)
    output_dir = ensure_dir(args.output_dir)

    seed_positions_nm = np.load(seeds_dir / "seed_positions.npy")
    if args.n_walkers is not None:
        seed_positions_nm = seed_positions_nm[: args.n_walkers]
    K = seed_positions_nm.shape[0]

    duration_steps = steps_from_time(args.duration_ns * 1000.0, args.timestep_fs)
    traj_interval_steps = max(1, steps_from_time(args.traj_interval_ps, args.timestep_fs))

    print(f"Running {K} hot walkers at s={args.scale_factor:.3f} ...")
    print(f"  duration: {args.duration_ns} ns  ({duration_steps} steps)")
    print(f"  traj_interval: {args.traj_interval_ps} ps ({traj_interval_steps} steps)")

    from escort_ais.methods.multi_walker_md import run_independent_walkers

    summary = run_independent_walkers(
        args.topology_dir,
        seed_positions_nm=seed_positions_nm,
        scale_factor=args.scale_factor,
        duration_steps=duration_steps,
        temperature_k=args.temperature_k,
        timestep_fs=args.timestep_fs,
        friction_per_ps=args.friction_per_ps,
        traj_interval_steps=traj_interval_steps,
        platform=args.platform,
        seed=args.seed,
        output_dir=output_dir,
        dry_run=args.dry_run,
    )

    print(f"\nDone. {summary['n_walkers']} walkers, "
          f"{summary.get('total_frames', 0)} total frames.")
    print(f"  Output: {output_dir}")


if __name__ == "__main__":
    main()
