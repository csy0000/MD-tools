#!/usr/bin/env python3
"""make_leq_2dgate_illustration.py — the 2-D residence gate (sub-well AND basin residence) vs the 1-D gate.

Extends the single-basin toy to TWO basins: S1 (three connected sub-wells S1C/S1B/S1A) and a second basin S2
across a moderate inter-basin barrier. Seeds are started in S1 (S1A-heavy, near the boundary). Some stay and
hop among S1's sub-wells (MIXING -> sample P_eq(.|S1)); some leave S1 for S2 early (ESCAPEES -> their S1 sample
is partial/S1A-biased). Both have SHORT sub-well residence, so the 1-D rule (keep short sub-well residence)
cannot tell them apart. Only a 2-D gate -- short sub-well residence AND long *basin* residence -- keeps the
truly ergodic seeds.

Answers: is short sub-well residence sufficient? No -- a seed can be short in a sub-well because it HOPPED
(good) or because it LEFT the basin (bad). You also need it to have RESIDED in the basin.

Writes results/rgd/report/fig_leq_2d_*.png for a new section of docs/theory/leq_residence_rule.tex.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.make_leq_2dgate_illustration
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

OUT = Path(__file__).resolve().parent.parent / "results/rgd/report"

MU = np.array([-5.5, -4.0, -2.5, -1.0])        # S1C, S1B, S1A, S2
SIG = np.array([0.40, 0.40, 0.40, 0.48])
W = np.array([0.34, 0.26, 0.20, 0.20])
XB = -1.75                                      # S1 | S2 boundary
DT, TOTAL = 0.002, 10.0
START = np.array([60, 70, 100])                # seeds started in S1C, S1B, S1A (S1A-heavy placement)
T_SW, T_BASIN = 2.0, 5.0                        # gate thresholds: sub-well <= T_SW, basin >= T_BASIN
S1BINS = np.linspace(-7.0, XB, 42); S1CEN = 0.5 * (S1BINS[:-1] + S1BINS[1:])


def _g(x, m, s):
    return np.exp(-0.5 * ((x - m) / s) ** 2) / (s * np.sqrt(2 * np.pi))


def p_eq(x):
    return sum(w * _g(x, m, s) for w, m, s in zip(W, MU, SIG))


def U(x):
    return -np.log(p_eq(x))


def dU(x):
    return sum(w * _g(x, m, s) * (x - m) / s ** 2 for w, m, s in zip(W, MU, SIG)) / p_eq(x)


def js(p, q, e=1e-12):
    p = p + e; p = p / p.sum(); q = q + e; q = q / q.sum()
    m = 0.5 * (p + q)
    return float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))


def maxrun_bool(a):
    b = cur = 0
    for v in a:
        cur = cur + 1 if v else 0; b = max(b, cur)
    return b * DT


def maxrun_subwell(sub, ins1):
    b = cur = 0; prev = -9
    for i in range(len(sub)):
        if ins1[i]:
            cur = cur + 1 if sub[i] == prev else 1; prev = sub[i]
        else:
            cur = 0; prev = -9
        b = max(b, cur)
    return b * DT


def run():
    n = int(TOTAL / DT); c = np.sqrt(2 * DT); rng = np.random.default_rng(0)
    x0 = np.concatenate([np.full(k, m) for k, m in zip(START, MU[:3])]).astype(float)
    N = len(x0); X = np.empty((N, n)); X[:, 0] = x0; x = x0.copy()
    for t in range(1, n):
        x = x - dU(x) * DT + c * rng.standard_normal(N); X[:, t] = x
    inS1 = X < XB
    sub = np.argmin(np.abs(X[:, :, None] - MU[None, None, :3]), axis=2)
    Rbasin = np.array([maxrun_bool(inS1[i]) for i in range(N)])
    Rsw = np.array([maxrun_subwell(sub[i], inS1[i]) for i in range(N)])
    REF = p_eq(S1CEN)                                          # equilibrium restricted to S1
    Js = np.array([js(np.histogram(X[i][inS1[i]], S1BINS)[0], REF) if inS1[i].sum() > 20 else np.nan
                   for i in range(N)])
    cand = inS1.mean(1) >= 0.15                                # seeds with real S1 presence

    def pool(mask):
        idx = np.where(mask & cand)[0]
        if not len(idx):
            return np.zeros_like(S1CEN)
        return np.histogram(np.concatenate([X[i][inS1[i]] for i in idx]), S1BINS, density=True)[0]

    g_all = cand
    g_1d = cand & (Rsw <= T_SW)
    g_2d = cand & (Rsw <= T_SW) & (Rbasin >= T_BASIN)
    res = {k: dict(n=int(m.sum()), pool_js=round(js(pool(m), REF), 3),
                   med_js=round(float(np.nanmedian(Js[m])), 3)) for k, m in
           [("all", g_all), ("1D", g_1d), ("2D", g_2d)]}
    print(f"[2d] barriers intra-S1 {[round(float(U((MU[i]+MU[i+1])/2)-U(MU[i+1])),1) for i in range(2)]} "
          f"S1A->S2 {round(float(U(XB)-U(MU[2])),1)} | {res}")

    # -------------------------------------------------------- Fig 1: two-basin potential
    grid = np.linspace(-7.2, 1.2, 500)
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].plot(grid, U(grid), "k", lw=2); ax[0].axvline(XB, ls="--", c="0.5")
    ax[0].axvspan(-7.2, XB, color="C2", alpha=0.07); ax[0].axvspan(XB, 1.2, color="C1", alpha=0.07)
    ax[0].set_ylim(U(grid).min() - 0.3, U(grid).min() + 6)
    for m, lab in zip(MU[:3], ["S1C", "S1B", "S1A"]):
        ax[0].annotate(lab, (m, U(m) - 0.15), ha="center", va="top", fontsize=8, color="C2")
    ax[0].annotate("S2", (MU[3], U(MU[3]) - 0.15), ha="center", va="top", fontsize=8, color="C1")
    ax[0].set_xlabel("$x$"); ax[0].set_ylabel(r"$U(x)$  [$k_BT$]")
    ax[0].set_title("(a) two basins: S1 (3 connected sub-wells) | S2")
    ax[1].plot(grid, p_eq(grid), "C0", lw=2); ax[1].axvline(XB, ls="--", c="0.5")
    ax[1].set_xlabel("$x$"); ax[1].set_ylabel(r"$P_{\rm eq}(x)$")
    ax[1].set_title(r"(b) we want $P_{\rm eq}(x\,|\,S1)$ (left of the boundary)")
    fig.tight_layout(); fig.savefig(OUT / "fig_leq_2d_potential.png", dpi=140); plt.close(fig)

    # -------------------------------------------------------- Fig 2: mixing vs escapee trajectory
    mix_c = cand & (Rbasin >= T_BASIN) & (Rsw <= T_SW)
    esc_c = cand & (Rbasin < T_BASIN) & (Rsw <= T_SW)
    i_mix = int(np.where(mix_c)[0][np.argmin(Js[mix_c])])
    i_esc = int(np.where(esc_c)[0][np.argmax(Js[esc_c])])
    tg = np.arange(n) * DT
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8), sharey=True)
    for a, i, name in [(ax[0], i_mix, "MIXING (stays in S1, hops)"), (ax[1], i_esc, "ESCAPEE (leaves S1 early)")]:
        a.plot(tg, X[i], lw=0.5, c=("C2" if "MIX" in name else "C3"))
        a.axhline(XB, ls="--", c="0.5", lw=1); a.axhspan(XB, 1.5, color="C1", alpha=0.08)
        for m in MU[:3]:
            a.axhline(m, ls=":", c="0.85", lw=1)
        a.set_xlabel("time $t$")
        a.set_title(f"{name}\n$R_{{\\rm sw}}={Rsw[i]:.2f}$, $R_{{\\rm basin}}={Rbasin[i]:.2f}$, "
                    f"JS$(\\cdot|S1)={Js[i]:.2f}$", fontsize=9)
    ax[0].set_ylabel("$x(t)$   (S2 shaded)")
    fig.suptitle("Both have SHORT sub-well residence -- but the escapee never sampled S1B/S1C", fontsize=10.5)
    fig.tight_layout(rect=[0, 0, 1, 0.94]); fig.savefig(OUT / "fig_leq_2d_trajectories.png", dpi=140)
    plt.close(fig)

    # -------------------------------------------------------- Fig 3: the 2-D residence scatter
    fig, ax = plt.subplots(figsize=(6.6, 5.2))
    m = cand & np.isfinite(Js)
    sc = ax.scatter(Rsw[m], Rbasin[m], c=Js[m], cmap="viridis_r", s=34, edgecolor="k", lw=0.3, vmin=0, vmax=0.45)
    ax.axvline(T_SW, c="C1", ls="-", lw=1.5); ax.axhline(T_BASIN, c="C0", ls="-", lw=1.5)
    ax.add_patch(plt.Rectangle((0, T_BASIN), T_SW, Rbasin.max() * 1.05 - T_BASIN, fill=False,
                               edgecolor="lime", lw=2.5))
    ax.annotate("2-D gate = LEQ corner\n(short sub-well AND long basin)", (T_SW * 0.5, T_BASIN + 1.4),
                ha="center", fontsize=8.5, color="green")
    ax.annotate("1-D gate keeps this whole column\n(admits the escapees below)", (T_SW * 0.5, 1.2),
                ha="center", fontsize=8, color="C1")
    ax.annotate("ESCAPEES\n(short sub-well, SHORT basin)", (0.9, 2.2), fontsize=8, color="C3")
    ax.set_xlabel(r"sub-well residence  $R_{\rm sw}$"); ax.set_ylabel(r"basin residence  $R_{\rm basin}$")
    ax.set_title("Within-basin JS is low ONLY in the (small $R_{\\rm sw}$, large $R_{\\rm basin}$) corner")
    fig.colorbar(sc, label=r"JS$(P_s(\cdot|S1),\,P_{\rm eq}(\cdot|S1))$")
    fig.tight_layout(); fig.savefig(OUT / "fig_leq_2d_scatter.png", dpi=140); plt.close(fig)

    # -------------------------------------------------------- Fig 4: 1-D vs 2-D gate
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].plot(S1CEN, REF / REF.sum() / (S1CEN[1] - S1CEN[0]), "C0", lw=2.4, label=r"true $P_{\rm eq}(\cdot|S1)$")
    ax[0].plot(S1CEN, pool(g_all), "0.5", lw=1.6, label=f"all S1-present seeds (JS {res['all']['pool_js']})")
    ax[0].plot(S1CEN, pool(g_1d), "C1", lw=1.8, ls="--", label=f"1-D gate (JS {res['1D']['pool_js']})")
    ax[0].plot(S1CEN, pool(g_2d), "C2", lw=2.0, label=f"2-D gate (JS {res['2D']['pool_js']})")
    ax[0].set_xlabel("$x$"); ax[0].set_ylabel("density"); ax[0].set_title("(a) pooled $P(\\cdot|S1)$ by gate")
    ax[0].legend(fontsize=7.5)
    labels = ["all\nS1-present", "1-D gate\n($R_{sw}\\leq T$)", "2-D gate\n($R_{sw}\\leq T$ &\n$R_{bas}\\geq T$)"]
    xb = np.arange(3)
    ax[1].bar(xb - 0.2, [res[k]["med_js"] for k in ("all", "1D", "2D")], 0.38, color="0.6",
              label="median per-seed JS")
    ax[1].bar(xb + 0.2, [res[k]["pool_js"] for k in ("all", "1D", "2D")], 0.38, color="C2", label="pooled JS")
    ax[1].set_xticks(xb); ax[1].set_xticklabels(labels, fontsize=8); ax[1].set_ylabel("JS to $P_{eq}(\\cdot|S1)$")
    ax[1].set_title("(b) the 2-D gate gives the lowest error"); ax[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(OUT / "fig_leq_2d_gatecompare.png", dpi=140); plt.close(fig)
    print(f"wrote 4 figures to {OUT}/fig_leq_2d_*.png")


if __name__ == "__main__":
    run()
