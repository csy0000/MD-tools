"""run_basin_ais_resample.py — Stage 4: resample AIS cold endpoints by AIS weights.

Reads work_timeseries.npy + final_samples.dcd from the forward-AIS run dir,
computes final_logw = -W[:, -1], then systematically resamples cold start positions.

After resampling:
  - Only parent_indices.npy and resampled_cold_starts.npy are written.
  - Old weights are DROPPED — the output is equal-weight.

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_basin_ais_resample \\
        --ais-dir data/.../03_fwd_ais \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/.../04_ais_resampled \\
        --n-out 1000 [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np



def _load_ais_endpoints_from_dcd(dcd_path: Path, prmtop_path: Path) -> np.ndarray:
    """Load (K, n_atoms, 3) positions in nm from a DCD file."""
    import mdtraj as md

    traj = md.load_dcd(str(dcd_path), top=str(prmtop_path))
    return traj.xyz  # already in nm


def main() -> None:
    parser = argparse.ArgumentParser(description="Resample AIS cold endpoints by AIS weights.")
    parser.add_argument("--ais-dir", required=True, type=Path,
                        help="Forward-AIS output dir with work_timeseries.npy and final_samples.dcd.")
    parser.add_argument("--topology-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--n-out", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    from escort_ais.common.resampling import resample_positions, effective_sample_size

    output_dir = ensure_dir(args.output_dir)
    ais_dir = Path(args.ais_dir)
    topology_dir = Path(args.topology_dir)

    # Load AIS log-weights
    wt_path = ais_dir / "work_timeseries.npy"
    if not wt_path.exists():
        raise FileNotFoundError(f"work_timeseries.npy not found in {ais_dir}")
    wt = np.load(wt_path)
    final_logw = -wt[:, -1].astype(np.float64)
    # NaN work → zero weight (ignore failed walkers)
    final_logw[~np.isfinite(final_logw)] = -np.inf
    K = len(final_logw)

    ess = effective_sample_size(final_logw)
    print(f"AIS walkers: K={K}, ESS={ess:.1f} ({100*ess/K:.1f}%)")

    config = {
        "ais_dir": str(ais_dir.resolve()),
        "topology_dir": str(topology_dir.resolve()),
        "n_input": K,
        "n_out": args.n_out,
        "seed": args.seed,
        "dry_run": args.dry_run,
        "output_dir": str(output_dir.resolve()),
    }
    (output_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    if args.dry_run:
        print("dry_run=True: skipping resampling.")
        summary = {**config, "ess": float(ess), "n_actual": 0}
        (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return

    # Load cold endpoint positions
    prmtop_candidates = ["system_scale_1p0.prmtop", "system.prmtop"]
    prmtop_path = None
    for name in prmtop_candidates:
        candidate = topology_dir / name
        if candidate.exists():
            prmtop_path = candidate
            break
    if prmtop_path is None:
        raise FileNotFoundError(f"No prmtop in {topology_dir}")

    dcd_path = ais_dir / "final_samples.dcd"
    if not dcd_path.exists():
        raise FileNotFoundError(f"final_samples.dcd not found in {ais_dir}")

    print("Loading cold AIS endpoint positions ...")
    positions_nm = _load_ais_endpoints_from_dcd(dcd_path, prmtop_path)

    rng = np.random.default_rng(args.seed)
    resampled, parent_idx = resample_positions(
        positions_nm, final_logw, args.n_out, rng, method="systematic"
    )

    np.save(output_dir / "parent_indices.npy", parent_idx)
    np.save(output_dir / "resampled_cold_starts.npy", resampled)

    summary = {
        **config,
        "ess": float(ess),
        "ess_fraction": float(ess / K),
        "n_actual": len(parent_idx),
        "unique_parents": int(len(np.unique(parent_idx))),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"Resampled {K} → {len(parent_idx)} equal-weight cold starts "
          f"({len(np.unique(parent_idx))} unique parents).")
    print(f"  Output: {output_dir}")


if __name__ == "__main__":
    main()
