#!/usr/bin/env python3
"""compute_permicrostate_convergence.py — per-microstate BAR + logsumexp ddF convergence.

Recomputes the bAIS Task-2 ddF at every hot-length checkpoint using the per-microstate estimator
(24 microstates instead of the 2 major/minor basins): endpoint-restricted BAR per microstate, then
combine to the major/minor basins by logsumexp of the per-microstate free energies, ddF = F_minor - F_major.
Microstates are fixed (PCA(8)->KMeans(24) on the full forward-AIS landings) so only the estimator changes
across checkpoints, not the state definition. Reuses the stored per-generation AIS works (no new MD).

Writes data/rgd/diagnostics/bais_eval/<name>/permicro_convergence.json:
  [{gen, hot_ns, ddF_permicro, ddF_2basin, n_states_defined}]

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.compute_permicrostate_convergence
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel  # noqa: E402
from escort_ais.methods.endpoint_bar import endpoint_restricted_bar  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
K = 24
NGEN = 37
GEN0_HOT, STEP = 60.0, 20.0


def _load_fwd(d, top, q, bm):
    s = pd.read_csv(d / "ais_trajectory_summary.csv")
    W = -s["final_logw"].to_numpy()
    t = md.load_dcd(str(d / "ais_final_coordinates.dcd"), top=top)
    n = min(len(W), t.n_frames)
    return W[:n], featurize(t[:n], q), bm.assign(t[:n])


def _load_rev(d, top, q, bm):
    s = pd.read_csv(d / "step/ais_trajectory_summary.csv")
    W = -s["final_logw"].to_numpy()
    ifi = s["initial_frame_index"].to_numpy()
    seed = md.load_dcd(str(d / "seed_cold/trajectory.dcd"), top=top)
    ok = ifi < seed.n_frames
    starts = seed[ifi[ok]]
    return W[ok], featurize(starts, q), bm.assign(starts)


def process(name):
    cfg = load_cfg(name)
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    bm = BasinModel.load(cfg.basin_model_path)
    sysdir = BE / name

    fwd = [_load_fwd(sysdir / "gen0/fwd", top, q, bm)]
    for g in range(1, NGEN + 1):
        fwd.append(_load_fwd(sysdir / f"gen{g}/fwd", top, q, bm))
    rev = [_load_rev(next(sysdir.glob("gen0_sw*")) / "rev", top, q, bm)]
    for g in range(1, NGEN + 1):
        rev.append(_load_rev(sysdir / f"gen{g}/rev", top, q, bm))

    # fixed microstates on ALL forward landings; microstate -> basin by majority forward landing
    allXf = np.concatenate([x for _, x, _ in fwd])
    allbf = np.concatenate([b for _, _, b in fwd])
    pca = PCA(8, random_state=0).fit(allXf)
    scal = StandardScaler().fit(pca.transform(allXf))
    km = KMeans(K, n_init=10, random_state=0).fit(scal.transform(pca.transform(allXf)))
    def micro(X):
        return km.predict(scal.transform(pca.transform(X)))
    allmf = micro(allXf)
    micro_basin = np.array([int(round(allbf[allmf == S].mean())) if (allmf == S).any() else -1 for S in range(K)])
    ref = int(np.bincount(allmf, minlength=K).argmax())

    rows = []
    for g in range(NGEN + 1):
        Wf = np.concatenate([fwd[i][0] for i in range(g + 1)])
        Xf = np.concatenate([fwd[i][1] for i in range(g + 1)])
        bf = np.concatenate([fwd[i][2] for i in range(g + 1)])
        Wr = np.concatenate([rev[i][0] for i in range(g + 1)])
        Xr = np.concatenate([rev[i][1] for i in range(g + 1)])
        br = np.concatenate([rev[i][2] for i in range(g + 1)])
        mf, mr = micro(Xf), micro(Xr)
        rK = endpoint_restricted_bar(Wf, mf, Wr, mr, list(range(K)), reference_basin=ref, bootstrap=False)
        ddS = np.array([rK["ddF"].get(S, np.nan) for S in range(K)])
        F = {}
        for basin in (0, 1):
            v = ddS[(micro_basin == basin) & np.isfinite(ddS)]
            F[basin] = -logsumexp(-v) if len(v) else np.nan
        ddF_pm = float(F[1] - F[0])
        r2 = endpoint_restricted_bar(Wf, bf, Wr, br, [0, 1], reference_basin=0, bootstrap=False)
        rows.append(dict(gen=g, hot_ns=GEN0_HOT + g * STEP, ddF_permicro=ddF_pm,
                         ddF_2basin=float(r2["ddF"][1]), n_states_defined=int(np.isfinite(ddS).sum())))
    out = sysdir / "permicro_convergence.json"
    out.write_text(json.dumps(rows, indent=2))
    print(f"[{name}] wrote {out.name}: final ddF permicro {rows[-1]['ddF_permicro']:.2f} "
          f"vs 2-basin {rows[-1]['ddF_2basin']:.2f}", file=sys.stderr)


def main():
    for name in ["rgd", "cilengitide", "rgd_redPheVal"]:
        process(name)


if __name__ == "__main__":
    main()
