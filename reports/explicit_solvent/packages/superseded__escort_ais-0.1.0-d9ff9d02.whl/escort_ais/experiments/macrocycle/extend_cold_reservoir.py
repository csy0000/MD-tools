#!/usr/bin/env python3
"""extend_cold_reservoir.py -- run the FPS-selected cold-MD reservoir seeds out to a longer duration
(e.g. 10 ns) to characterize the ns-scale slow torsional axes that 1 ns cannot resolve.

Fresh continuous cold MD (s=1.0, GBn2/mbondi3) from each original seed conformation
(cold_seeds/seed_XXX.pdb), 1 ps/frame; a 5 ns prefix is analyzable from the 10 ns run. Runs a seed
range so several workers can share one GPU.

Usage (4 workers on GPU 2):
  for r in 0:5 5:10 10:15 15:20; do
    python -m escort_ais.experiments.macrocycle.extend_cold_reservoir --out-dir <dir> \
        --seed-start ${r%:*} --seed-end ${r#*:} --prod-ns 10 --device 2 &
  done
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import mdtraj as md

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.common.macrocycle_cfg import load as load_cfg                                   # noqa: E402
from escort_ais.systems.build_macrocycle_cold_reservoir import build_cold_system, run_cold_seed  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--src-seeds", default="data/rgd/2026-06-29-reservoir-sw-s0p25/cold_seeds",
                    help="dir with the original seed_XXX.pdb starting conformations")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--seed-start", type=int, default=0)
    ap.add_argument("--seed-end", type=int, default=20)
    ap.add_argument("--prod-ns", type=float, default=10.0)
    ap.add_argument("--device", type=int, default=2)
    ap.add_argument("--platform", default="OpenCL")
    args = ap.parse_args()

    cfg = load_cfg(args.name)
    st, system = build_cold_system(cfg)
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    src = Path(args.src_seeds)
    for sid in range(args.seed_start, args.seed_end):
        pdb = src / f"seed_{sid:03d}.pdb"
        if not pdb.exists():
            print(f"  skip seed {sid}: {pdb} missing", flush=True); continue
        xyz = md.load(str(pdb)).xyz[0]
        run_cold_seed(sid, xyz, st, system, out, args.prod_ns * 1000.0, args.platform, args.device)
    print(f"  worker seeds [{args.seed_start},{args.seed_end}) done -> {out}", flush=True)


if __name__ == "__main__":
    main()
