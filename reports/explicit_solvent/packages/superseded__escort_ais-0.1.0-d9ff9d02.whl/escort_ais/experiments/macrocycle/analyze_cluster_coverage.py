#!/usr/bin/env python3
"""analyze_cluster_coverage.py — is the bAIS-vs-REMD ddF gap a clustering/coverage problem?

For each compound, cluster the UNION of REMD + cold-reservoir + forward-AIS-landing configurations in
backbone-dihedral space, then diagnose:

  Q2  Are the bAIS-populated clusters geometrically real/separated in REMD?
        - per cluster: REMD pop vs bAIS forward weight p_land; flag bAIS-only clusters (p_land>0, REMD~0).
        - silhouette of the clustering on REMD frames (how isolated the clusters are in the REMD ensemble).
  Q3  Are there REMD-populated clusters NOT covered by bAIS?
        - (a) not sampled at all: REMD>=0.5% but 0 cold AND 0 landing frames.
        - (b) sampled but weight-starved: REMD>=0.5% but p_land<0.5% (reweighting zeroes a real region).
        report the missed REMD population, split by major/minor basin (the state-defining torsion).
  Q1  Is rgd's undershoot a clustering artifact?
        - reweighted-torsion p_minor at K = 12/24/48 (sensitivity), and
        - a CLUSTERING-FREE estimate: pure forward-AIS landing population on the defining torsion
          (weight each landing by exp(logw), threshold on its own torsion) -- no clusters, no cold reservoir.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_cluster_coverage
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide", "rgd_redPheVal": "rgd_redPheVal"}


def in_window(deg, lo, hi):
    return (deg >= lo) & (deg <= hi) if lo <= hi else (deg >= lo) | (deg <= hi)


def ddF(pmin):
    pmin = min(max(float(pmin), 1e-9), 1 - 1e-9)
    return -float(np.log(pmin / (1 - pmin)))


def p_land_per_cluster(labels_land, logw, K):
    lp = np.full(K, -np.inf)
    for c in range(K):
        m = labels_land == c
        if m.any():
            lp[c] = logsumexp(logw[m])
    lp -= logsumexp(lp)
    return np.exp(lp)


def reweighted_pminor(coldX, cold_tor, landX, logw, lo, hi, K, pca_scal_km=None):
    """p_minor from the reweighted cold reservoir at K clusters (the canonical estimator)."""
    if pca_scal_km is None:
        pca = PCA(8, random_state=0).fit(coldX)
        scal = StandardScaler().fit(pca.transform(coldX))
        km = KMeans(K, n_init=10, random_state=0).fit(scal.transform(pca.transform(coldX)))
    else:
        pca, scal, km = pca_scal_km
    proj = lambda X: km.predict(scal.transform(pca.transform(X)))
    mc = proj(coldX); ml = proj(landX)
    pl = p_land_per_cluster(ml, logw, K)
    ncold = np.bincount(mc, minlength=K)
    W = np.array([pl[S] / ncold[S] if ncold[S] > 0 else 0.0 for S in mc])
    tot = W.sum()
    return float(W[in_window(cold_tor, lo, hi)].sum() / tot) if tot > 0 else np.nan


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.basin_model_path)
    qi, lo, hi = model.rules[0]; qi = int(qi)

    # ---- load the three ensembles ----
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remdX = featurize(remd, q); remd_tor = np.degrees(md.compute_dihedrals(remd, q))[:, qi]
    coldX, cold_tor = [], []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        t = md.load_dcd(s, top=top)[50:]
        coldX.append(featurize(t, q)); cold_tor.append(np.degrees(md.compute_dihedrals(t, q))[:, qi])
    coldX = np.concatenate(coldX); cold_tor = np.concatenate(cold_tor)
    landX, logw, land_tor = [], [], []
    for csv in sorted((BE / name).glob("gen*/fwd/ais_trajectory_summary.csv")):
        dcd = csv.parent / "ais_final_coordinates.dcd"
        if not dcd.exists():
            continue
        d = pd.read_csv(csv); t = md.load_dcd(str(dcd), top=top); n = min(len(d), t.n_frames)
        landX.append(featurize(t[:n], q)); logw.append(d["final_logw"].to_numpy()[:n])
        land_tor.append(np.degrees(md.compute_dihedrals(t[:n], q))[:, qi])
    landX = np.concatenate(landX); logw = np.concatenate(logw); land_tor = np.concatenate(land_tor)

    # ---- union clustering (K=30) on REMD + cold + landings ----
    K = 30
    U = np.concatenate([remdX, coldX, landX])
    pca = PCA(8, random_state=0).fit(U)
    scal = StandardScaler().fit(pca.transform(U))
    km = KMeans(K, n_init=10, random_state=0).fit(scal.transform(pca.transform(U)))
    proj = lambda X: km.predict(scal.transform(pca.transform(X)))
    cr, cc, cl = proj(remdX), proj(coldX), proj(landX)

    p_remd = np.bincount(cr, minlength=K) / len(remdX)
    n_cold = np.bincount(cc, minlength=K); n_land = np.bincount(cl, minlength=K)
    pl = p_land_per_cluster(cl, logw, K)
    # cluster basin by majority defining-torsion side of its union members
    utor = np.concatenate([remd_tor, cold_tor, land_tor]); ulab = np.concatenate([cr, cc, cl])
    clus_minor = np.array([in_window(utor[ulab == c], lo, hi).mean() > 0.5 if (ulab == c).any() else False
                           for c in range(K)])

    # ---- Q3: REMD-populated clusters not covered by bAIS ----
    remd_pop = p_remd >= 0.005
    not_sampled = remd_pop & (n_cold == 0) & (n_land == 0)
    weight_starved = remd_pop & (~not_sampled) & (pl < 0.005)
    bais_only = (pl >= 0.005) & (p_remd < 0.005)

    def bybasin(mask):
        return dict(minor=round(float(p_remd[mask & clus_minor].sum()), 3),
                    major=round(float(p_remd[mask & ~clus_minor].sum()), 3), n=int(mask.sum()))

    # ---- Q2: geometric isolation of clusters in REMD (silhouette on REMD frames) ----
    sil = float(silhouette_score(scal.transform(pca.transform(remdX)), cr,
                                 sample_size=min(3000, len(remdX)), random_state=0))
    n_bais_real = int(((pl >= 0.005) & remd_pop).sum())
    n_bais_art = int(bais_only.sum())

    # ---- Q1: clustering sensitivity + clustering-free forward-AIS population ----
    pmin_K = {k: reweighted_pminor(coldX, cold_tor, landX, logw, lo, hi, k) for k in (12, 24, 48)}
    w = np.exp(logw - logsumexp(logw))                     # normalized forward-AIS importance weights
    pmin_free = float(w[in_window(land_tor, lo, hi)].sum())  # pure forward population on the torsion, NO clusters
    pmin_remd = float(in_window(remd_tor, lo, hi).mean())

    print(f"\n================ {NICE[name]}  (tor#{qi}, minor window ({lo:g},{hi:g})) ================")
    print(f"  frames: REMD {len(remdX)}, cold {len(coldX)}, landings {len(landX)}")
    print(f"  [Q2] silhouette of the {K}-cluster partition on REMD frames = {sil:+.3f}  "
          f"(>0.25 well-separated / ~0 continuous)")
    print(f"       bAIS-weighted clusters: {n_bais_real} are REMD-real (REMD>=0.5%), "
          f"{n_bais_art} are bAIS-only (REMD~0 -> artifacts, reweight-suppressed)")
    print(f"  [Q3] REMD-populated clusters NOT covered by bAIS:")
    print(f"       (a) not sampled at all (0 cold & 0 landings): {bybasin(not_sampled)}")
    print(f"       (b) sampled but forward-weight-starved (p_land<0.5%): {bybasin(weight_starved)}")
    print(f"  [Q1] clustering sensitivity of reweighted p_minor -> ddF:")
    for k, pm in pmin_K.items():
        print(f"       K={k:2d}: p_minor={pm:.3f}  ddF={ddF(pm):+.2f}")
    print(f"       clustering-FREE forward-AIS population: p_minor={pmin_free:.3f}  ddF={ddF(pmin_free):+.2f}")
    print(f"       REMD reference:                          p_minor={pmin_remd:.3f}  ddF={ddF(pmin_remd):+.2f}")


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
