"""run_basin_hot_resample.py — Stage 2: resample hot walkers by AIS hot weights.

Reads u_hot.npy (reduced hot energies, shape (K,)) from stage-01 output,
computes log-weights log w_k ∝ -u_hot_k (or equal-weight if not available),
then systematically resamples to n_out equal-weight start positions.

After resampling:
  - Only parent_indices.npy and resampled_seed_positions.npy are written.
  - Old weights are DROPPED — the output is equal-weight.

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_basin_hot_resample \\
        --hot-dir data/.../01_hot \\
        --seeds-dir data/.../01_seeds \\
        --output-dir data/.../02_hot_resampled \\
        --n-out 1000 [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np



def main() -> None:
    parser = argparse.ArgumentParser(description="Resample hot walkers by hot weights.")
    parser.add_argument("--hot-dir", required=True, type=Path,
                        help="Stage-01 hot dir containing walker trajectories.")
    parser.add_argument("--seeds-dir", required=True, type=Path,
                        help="Stage-01 seeds dir containing seed_positions.npy.")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--n-out", type=int, default=1000,
                        help="Number of resampled start positions.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    from escort_ais.common.resampling import resample_positions, effective_sample_size

    output_dir = ensure_dir(args.output_dir)

    # Load seed positions (final state of hot run ≈ last conformer in each walker)
    seeds_path = args.seeds_dir / "seed_positions.npy"
    if seeds_path.exists():
        seed_positions_nm = np.load(seeds_path)
        K = seed_positions_nm.shape[0]
    elif args.dry_run:
        seed_positions_nm = None
        K = args.n_out
        print("  seed_positions.npy not found (dry_run -- OK).")
    else:
        raise FileNotFoundError(f"seed_positions.npy not found in {args.seeds_dir}")

    # Load hot log-weights if available; otherwise treat as equal-weight
    u_hot_path = args.hot_dir / "u_hot.npy"
    if u_hot_path.exists():
        u_hot = np.load(u_hot_path)
        log_weights = -u_hot.astype(np.float64)
    else:
        print("  u_hot.npy not found — using equal weights (logw=0).")
        log_weights = np.zeros(K)

    ess = effective_sample_size(log_weights)
    print(f"Hot walkers: K={K}, ESS={ess:.1f} ({100*ess/K:.1f}%)")

    config = {
        "hot_dir": str(args.hot_dir.resolve()),
        "seeds_dir": str(args.seeds_dir.resolve()),
        "n_input": K,
        "n_out": args.n_out,
        "seed": args.seed,
        "dry_run": args.dry_run,
        "output_dir": str(output_dir.resolve()),
    }
    (output_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    if args.dry_run:
        print("dry_run=True: skipping resampling.")
        summary = {**config, "ess": float(ess), "n_actual": 0}
        (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return

    rng = np.random.default_rng(args.seed)
    resampled, parent_idx = resample_positions(
        seed_positions_nm, log_weights, args.n_out, rng, method="systematic"
    )

    np.save(output_dir / "parent_indices.npy", parent_idx)
    np.save(output_dir / "resampled_seed_positions.npy", resampled)

    summary = {
        **config,
        "ess": float(ess),
        "ess_fraction": float(ess / K),
        "n_actual": len(parent_idx),
        "unique_parents": int(len(np.unique(parent_idx))),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"Resampled {K} → {len(parent_idx)} equal-weight starts "
          f"({len(np.unique(parent_idx))} unique parents).")
    print(f"  Output: {output_dir}")


if __name__ == "__main__":
    main()
