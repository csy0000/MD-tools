#!/usr/bin/env python3
"""make_analog_reservoir_reweight_figs.py — cold vs REMD vs STATE-reweighted per-torsion histograms
for the bAIS adaptive reservoirs of the analog compounds (cilengitide, rgd_redPheVal).

Same per-configuration state-reweighting as the RGD artifact report (fix #3), applied to each analog's
existing bais_eval cold reservoir (forward-landing-seeded, ~86 seeds x 5 ns).  No new MD, no per-seed
provenance needed: cluster the pooled forward landings + cold frames into microstates, give each
microstate S the forward-AIS landing weight p_land(S) (softmax of the importance weights of landings in S),
and weight each cold frame by p_land(S)/n_cold(S).  Trapped-artifact microstates -> ~0 weight.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.make_analog_reservoir_reweight_figs
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

OUT = ROOT / "results/rgd/report"
BINS = np.linspace(-180, 180, 73)
NMICRO = 24
BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {
    "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
    "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns",
}
NICE = {"cilengitide": "cilengitide (N-Me)", "rgd_redPheVal": "RGD reduced-PheVal amide"}


def _js(h1, h2):
    a = h1 / h1.sum() + 1e-12
    b = h2 / h2.sum() + 1e-12
    m = 0.5 * (a + b)
    return 0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m))


def process(name):
    cfg = load_cfg(name)
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")

    # pooled forward-AIS landings + logw across all generations
    land, logw = [], []
    for csv in sorted((BE / name).glob("gen*/fwd/ais_trajectory_summary.csv")):
        dcd = csv.parent / "ais_final_coordinates.dcd"
        if not dcd.exists():
            continue
        d = pd.read_csv(csv)
        t = md.load_dcd(str(dcd), top=top)
        n = min(len(d), t.n_frames)
        land.append(featurize(t[:n], q))
        logw.append(d["final_logw"].to_numpy()[:n])
    landX = np.concatenate(land)
    logw = np.concatenate(logw)

    # cold reservoir frames (after 50 ps burn)
    Xseed, DIH = [], []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        try:
            t = md.load_dcd(s, top=top)[50:]
        except Exception:
            continue
        Xseed.append(featurize(t, q))
        DIH.append(np.degrees(md.compute_dihedrals(t, q)))
    Xall = np.concatenate(Xseed)
    DIH = np.concatenate(DIH)

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remdd = np.degrees(md.compute_dihedrals(remd, q))
    remdX = featurize(remd, q)

    pca = PCA(8, random_state=0).fit(Xall)
    scal = StandardScaler().fit(pca.transform(Xall))
    km = KMeans(NMICRO, n_init=10, random_state=0).fit(scal.transform(pca.transform(Xall)))
    micro_land = km.predict(scal.transform(pca.transform(landX)))
    micro_cold = km.predict(scal.transform(pca.transform(Xall)))
    micro_remd = km.predict(scal.transform(pca.transform(remdX)))
    lp = np.full(NMICRO, -np.inf)
    for S in range(NMICRO):
        m = micro_land == S
        if m.any():
            lp[S] = logsumexp(logw[m])
    lp -= logsumexp(lp)
    p_land = np.exp(lp)
    ncold = np.bincount(micro_cold, minlength=NMICRO)
    W = np.array([p_land[S] / ncold[S] if ncold[S] > 0 else 0.0 for S in micro_cold])
    W /= W.sum()
    p_remd = np.bincount(micro_remd, minlength=NMICRO) / len(remd)
    suppressed = sum(p_land[S] for S in range(NMICRO) if p_remd[S] < 0.005)

    nq = q.shape[0]
    jsu = np.array([_js(np.histogram(DIH[:, j], BINS, density=True)[0],
                        np.histogram(remdd[:, j], BINS, density=True)[0]) for j in range(nq)])
    jsw = np.array([_js(np.histogram(DIH[:, j], BINS, weights=W)[0],
                        np.histogram(remdd[:, j], BINS, density=True)[0]) for j in range(nq)])

    fig, axes = plt.subplots(3, 5, figsize=(16, 8.5))
    for j, ax in zip(np.argsort(-jsu), axes.flat):
        ax.hist(DIH[:, j], BINS, density=True, alpha=0.45, color="#4477AA", label="cold (unweighted)")
        hw, _ = np.histogram(DIH[:, j], BINS, weights=W, density=True)
        ax.stairs(hw, BINS, color="#117733", lw=2.2, label="cold (STATE-reweighted)")
        ax.hist(remdd[:, j], BINS, density=True, histtype="step", lw=2.0, color="#CC3311", label="REMD")
        ax.set_title(f"tor {j}  JS: {jsu[j]:.3f}→{jsw[j]:.3f}", fontsize=9)
        ax.set_xlim(-180, 180); ax.set_yticks([])
        if j == np.argsort(-jsu)[0]:
            ax.legend(fontsize=8)
    fig.suptitle(f"[{NICE[name]}] bAIS cold reservoir: unweighted vs STATE-reweighted vs REMD  "
                 f"(mean JS {jsu.mean():.3f} → {jsw.mean():.3f}; artifact-state weight suppressed = {suppressed:.3f})",
                 fontsize=13, y=1.005)
    fig.tight_layout()
    p = OUT / f"fig_{name}_cold_stateweighted_vs_remd.png"
    fig.savefig(p, dpi=140, bbox_inches="tight"); plt.close(fig)

    # per-microstate population vs REMD: before (unweighted) and after (state-reweighted)
    pu = ncold / ncold.sum()
    pw = p_land
    pr = p_remd
    figs, axs = plt.subplots(figsize=(6.4, 6.4))
    axs.plot([1e-4, 1], [1e-4, 1], "k--", lw=0.8, zorder=1)
    for S in range(NMICRO):
        if pu[S] > 0 or pw[S] > 0:
            axs.annotate("", xy=(max(pw[S], 1e-4), max(pr[S], 1e-4)),
                         xytext=(max(pu[S], 1e-4), max(pr[S], 1e-4)),
                         arrowprops=dict(arrowstyle="->", color="0.65", lw=0.7), zorder=2)
    axs.scatter(pu + 1e-4, pr + 1e-4, s=48, c="#4477AA", edgecolor="k", lw=0.4,
                label="cold unweighted (before)", zorder=3)
    axs.scatter(pw + 1e-4, pr + 1e-4, s=48, c="#117733", edgecolor="k", lw=0.4,
                label="state-reweighted (after)", zorder=3)
    axs.set(xscale="log", yscale="log", xlim=(8e-4, .7), ylim=(8e-4, .7),
            xlabel="reservoir microstate population", ylabel="REMD microstate population",
            title=f"[{NICE[name]}] microstate population vs REMD\nbefore (blue) $\\to$ after reweighting (green); on the diagonal = matches REMD")
    axs.legend(loc="upper left", fontsize=9)
    figs.tight_layout()
    ps = OUT / f"fig_{name}_states_reweighted_vs_remd.png"
    figs.savefig(ps, dpi=140); plt.close(figs)

    print(f"[{name}] {len(logw)} landings, {len(Xall)} cold frames; "
          f"meanJS {jsu.mean():.3f}->{jsw.mean():.3f}  artifact-wt-suppressed {suppressed:.3f}  -> +{ps.name}",
          file=sys.stderr)


def main():
    for name in ["cilengitide", "rgd_redPheVal"]:
        process(name)


if __name__ == "__main__":
    main()
