import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob, pandas as pd
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.special import logsumexp
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
RES='data/rgd/2026-06-29-reservoir-sw-s0p25'
fdf=pd.read_csv(f'{RES}/step_forward_ais/ais_trajectory_summary.csv'); logw=fdf['final_logw'].to_numpy()
landX=featurize(md.load_dcd(f'{RES}/step_forward_ais/ais_final_coordinates.dcd',top=top),q)
seeds=sorted(glob.glob(f'{RES}/cold_md_10ns/seed_*/trajectory.dcd'))
# map each seed -> its forward landing logw (nearest in torsion space to the seed's start pdb)
seedpdbs=sorted(glob.glob(f'{RES}/cold_seeds/seed_*.pdb'))
seed_logw=[]
for sp in seedpdbs:
    x=featurize(md.load(sp),q)[0]
    j=int(np.argmin(((landX-x)**2).sum(1))); seed_logw.append(logw[j])
seed_logw=np.array(seed_logw)
lw=seed_logw-logsumexp(seed_logw); wS=np.exp(lw)   # per-seed normalized weight
ess=1.0/np.sum(wS**2)
print(f"20 seed landing logw: {np.round(seed_logw-seed_logw.max(),1).tolist()}",flush=True)
print(f"per-seed weights (norm): {np.round(wS,3).tolist()}",flush=True)
print(f"effective sample size (seeds): {ess:.1f} / 20",flush=True)
# build per-frame arrays
DIH=[]; W=[]; GT=[]
for i,s in enumerate(seeds):
    t=md.load_dcd(s,top=top)[50:]
    DIH.append(np.degrees(md.compute_dihedrals(t,q))); GT.append(fz.assign(t))
    W.append(np.full(t.n_frames, wS[i]/t.n_frames))   # seed weight spread over its frames
DIH=np.concatenate(DIH); W=np.concatenate(W)/np.sum(np.concatenate(W)); GT=np.concatenate(GT)
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
remdd=np.degrees(md.compute_dihedrals(remd,q)); rgt=fz.assign(remd)
wmin=np.sum(W[GT==1]); print(f"\nminor frac: cold-unweighted {GT.mean():.3f}  cold-AISweighted {wmin:.3f}  REMD {rgt.mean():.3f}",flush=True)
nq=q.shape[0]; bins=np.linspace(-180,180,73)
def js(h1,h2):
    a=h1/h1.sum()+1e-12; b=h2/h2.sum()+1e-12; m=.5*(a+b); return .5*np.sum(a*np.log(a/m))+.5*np.sum(b*np.log(b/m))
tags={2:'dih2',6:'tor6',8:'tor8',12:'dih12',14:'dih14(sep)'}
jsl=[]
for j in range(nq):
    hw,_=np.histogram(DIH[:,j],bins,weights=W); hr,_=np.histogram(remdd[:,j],bins,density=True); jsl.append(js(hw,hr))
jsl=np.array(jsl)
fig,axes=plt.subplots(3,5,figsize=(15,8))
for j,ax in zip(np.argsort(-jsl),axes.flat):
    ax.hist(DIH[:,j],bins,density=True,alpha=.4,color='#88AACC',label='cold unweighted')
    ax.hist(DIH[:,j],bins,weights=W,histtype='step',lw=1.6,color='#117733',label='cold AIS-weighted')
    ax.hist(remdd[:,j],bins,density=True,histtype='step',lw=1.6,color='#CC3311',label='REMD')
    ax.set_title(f"tor {j} {tags.get(j,'')}  JS(w)={jsl[j]:.3f}",fontsize=8); ax.set_xlim(-180,180); ax.set_yticks([])
    if j==np.argsort(-jsl)[0]: ax.legend(fontsize=7)
fig.suptitle(f'Cold reservoir reweighted by forward-AIS seed weights vs REMD (ESS={ess:.1f}/20 seeds)',fontsize=13,y=1.01)
fig.tight_layout(); p='results/rgd/report/fig_cold_aisweighted_vs_remd.png'; fig.savefig(p,dpi=140,bbox_inches='tight'); print('saved',p,flush=True)
