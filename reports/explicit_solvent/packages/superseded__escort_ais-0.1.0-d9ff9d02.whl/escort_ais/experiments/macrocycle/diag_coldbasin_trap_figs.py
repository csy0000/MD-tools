import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob, sys, json
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
RES='data/rgd/2026-06-29-reservoir-sw-s0p25'
seeds=sorted(glob.glob(f'{RES}/cold_md_10ns/seed_*/trajectory.dcd'))
Xseed=[featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds]; Xall=np.concatenate(Xseed)
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(24,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
dtrajs=[km.predict(sc.transform(pca.transform(X))) for X in Xseed]
res_micro=np.concatenate(dtrajs); npop=np.bincount(res_micro,minlength=24)
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
rp=np.bincount(km.predict(sc.transform(pca.transform(featurize(remd,q)))),minlength=24).astype(float); rp/=rp.sum()
minorf=np.array([fz.assign(md.load_dcd(s,top=top)[50:]).mean() for s in seeds])  # unused
real=[k for k in range(24) if rp[k]>=0.005]; artifact=[k for k in range(24) if rp[k]<0.005 and npop[k]>0]
is_min=lambda k: fz.assign(remd[km.predict(sc.transform(pca.transform(featurize(remd,q))))==k][:1])[0]==1 if (km.predict(sc.transform(pca.transform(featurize(remd,q))))==k).any() else False

# ---- FIG 1: per-seed microstate timeline ----
fig,ax=plt.subplots(figsize=(13,6))
# color: real states greyscale-ish by basin; artifacts in hot colors
cmap=plt.cm.tab20
for i,d in enumerate(dtrajs):
    t=np.arange(len(d))/1000.0  # ns
    # draw as colored line segments by state; simplest: scatter thin
    ax.scatter(t[::5], np.full(len(t[::5]),i), c=[cmap(s%20) for s in d[::5]], s=4, marker='s', lw=0)
ax.set(xlabel='cold-MD time (ns)', ylabel='seed index',
       title='Per-seed microstate timeline (20 x 10 ns). A single flat color across a seed = trapped in one microstate.',
       yticks=range(20), ylim=(-0.5,19.5))
ax.tick_params(labelsize=7)
fig.tight_layout(); fig.savefig('results/rgd/report/fig_trap_timeline.png',dpi=140); print('saved timeline')

# ---- FIG 2: dwell-time distributions for artifact states ----
def runs_of(k):
    R=[]; 
    for d in dtrajs:
        idx=np.where(d==k)[0]
        if idx.size:
            brk=np.where(np.diff(idx)>1)[0]; s=np.r_[idx[0],idx[brk+1]]; e=np.r_[idx[brk],idx[-1]]; R+=list(e-s+1)
    return np.array(R)
art_sorted=sorted(artifact,key=lambda k:-npop[k])[:12]
fig,axes=plt.subplots(3,4,figsize=(15,8))
for k,axx in zip(art_sorted,axes.flat):
    r=runs_of(k); mx=r.max()
    axx.hist(np.clip(r,1,10000),bins=np.logspace(0,4,25),color='#CC3311',alpha=.75)
    axx.axvline(200,ls=':',c='gray'); axx.axvline(2000,ls='--',c='k')
    v='TRAPPED' if mx>=2000 else ('semi' if mx>=200 else 'transient')
    axx.set_title(f"state {k}: cold {100*npop[k]/len(res_micro):.1f}% REMD {100*rp[k]:.1f}%\n"
                  f"max dwell {mx} ps -> {v}",fontsize=8)
    axx.set_xscale('log'); axx.set_xlabel('dwell (ps)',fontsize=7); axx.set_yticks([])
fig.suptitle('Dwell-time distribution of artifact microstates (REMD~0%). '
             'Dashed=2 ns (trapped), dotted=200 ps. Long dwells => kinetic traps, not transient flickers.',y=1.01,fontsize=12)
fig.tight_layout(); fig.savefig('results/rgd/report/fig_trap_dwell.png',dpi=140,bbox_inches='tight'); print('saved dwell')
