#!/usr/bin/env python3
"""make_state_torsion_contours.py — 2D torsion contour map of the metastable states per compound.

For each compound, draw each metastable state's REMD density as contours on TWO raw backbone dihedrals,
chosen so all states separate: axis A = the dihedral that best separates some state pair (e.g. minor vs
major); axis B = the dihedral that best separates the pair A leaves overlapping (e.g. the two major-side
states). Interpretable angle axes. States = TICA-on-hot (cold-population order, as in bais_convergence_<name>.pdf).
Writes results/rgd/report/fig_<name>_state_torsion_2d.png (embedded as a page in the convergence PDF).

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.make_state_torsion_contours
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
from scipy.ndimage import gaussian_filter, gaussian_filter1d

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

OUT = ROOT / "results/rgd/report"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
HOT = {"rgd": ROOT / "data/rgd/2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701/trajectory.dcd",
       "cilengitide": ROOT / "data/cilengitide/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
       "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide (N-Me)", "rgd_redPheVal": "RGD reduced-PheVal amide"}
NS = 5
COLORS = ["#4477AA", "#EE6677", "#228833", "#CCBB44", "#AA3377"]


def _pair_sep(ang0_deg, ang1_deg):
    """circular separation of two states along one dihedral: chord dist between mean-vectors / total spread
    (high = separated along this dihedral; low = overlapping)."""
    a0, a1 = np.radians(ang0_deg), np.radians(ang1_deg)
    m0 = np.array([np.sin(a0).mean(), np.cos(a0).mean()]); m1 = np.array([np.sin(a1).mean(), np.cos(a1).mean()])
    spread = (1 - np.hypot(*m0)) + (1 - np.hypot(*m1)) + 1e-6
    return float(np.hypot(*(m0 - m1)) / spread)


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb); q, _, _ = load_quartets(cfg.topo, "backbone")
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NS, lag=20, n_tic=4,
                                   burn_frames=1000, stride=2, seed=0)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    lab0 = model.assign(remd)
    p0 = np.bincount(lab0, minlength=NS).astype(float); p0 /= p0.sum()
    perm = np.argsort(-p0); inv = np.empty(NS, int); inv[perm] = np.arange(NS)
    state = inv[lab0]; p_remd = p0[perm]
    dih = np.degrees(md.compute_dihedrals(remd, q))                 # (n_frames, n_dih)
    real = [B for B in np.argsort(-p_remd) if p_remd[B] >= 0.01]

    # choose 2 raw dihedrals that JOINTLY separate all states: per-dihedral separation for every state pair;
    # axis A = best overall separator; axis B = best separator of the pair A leaves most overlapping.
    pairs = [(a, b) for i, a in enumerate(real) for b in real[i + 1:]]
    sep = np.array([[_pair_sep(dih[state == a][:, j], dih[state == b][:, j]) for (a, b) in pairs]
                    for j in range(dih.shape[1])])                  # (n_dih, n_pair)
    jA = int(sep.max(1).argmax())
    worst = int(sep[jA].argmin())                                  # pair least separated by axis A
    jB = int(sep[:, worst].argmax())
    if jB == jA:                                                   # degenerate: pick 2nd-best for that pair
        jB = int(np.argsort(-sep[:, worst])[1])
    j1, j2 = jA, jB
    a, b = pairs[worst]

    # re-center each axis's branch cut at its lowest-density angle so no state's density wraps/splits
    def cut_at_gap(col):
        h, e = np.histogram(dih[np.isin(state, real), col], bins=np.linspace(-180, 180, 73))
        h = gaussian_filter1d(h.astype(float), 2.0, mode="wrap")
        return float((0.5 * (e[:-1] + e[1:]))[int(h.argmin())])
    cut1, cut2 = cut_at_gap(j1), cut_at_gap(j2)
    sh = lambda a, c: (a - c) % 360                     # shift so the empty gap sits at 0/360 (no wrap)

    edges = np.linspace(0, 360, 49); cen = 0.5 * (edges[:-1] + edges[1:])
    fig, ax = plt.subplots(figsize=(7.6, 6.6))
    for B in real:
        m = state == B
        H, _, _ = np.histogram2d(sh(dih[m, j1], cut1), sh(dih[m, j2], cut2), bins=[edges, edges])
        H = gaussian_filter(H, 1.2); H = H / (H.max() + 1e-12)
        col = COLORS[B % len(COLORS)]
        ax.contour(cen, cen, H.T, levels=[0.1, 0.35, 0.7], colors=col, linewidths=[1.0, 1.6, 2.2])
        ax.plot([], [], color=col, lw=2.0, label=f"S{B}  (REMD {p_remd[B]:.2f})")
    ax.set_xlabel(f"backbone dihedral #{j1} (deg)"); ax.set_ylabel(f"backbone dihedral #{j2} (deg)")
    ax.set_xlim(0, 360); ax.set_ylim(0, 360)
    tp = np.array([0, 90, 180, 270, 360])
    ax.set_xticks(tp); ax.set_xticklabels([f"{int(((t + cut1 + 180) % 360) - 180)}" for t in tp])
    ax.set_yticks(tp); ax.set_yticklabels([f"{int(((t + cut2 + 180) % 360) - 180)}" for t in tp])
    ax.set_title(f"{NICE.get(name, name)} — metastable states in 2D torsion space (REMD density)\n"
                 f"dih#{j1} separates the most-distinct pair; dih#{j2} separates S{a}/S{b} "
                 f"(contours at 10/35/70% of each state's peak)", fontsize=10)
    ax.legend(fontsize=9, loc="best"); ax.grid(alpha=0.3)
    fig.tight_layout()
    p = OUT / f"fig_{name}_state_torsion_2d.png"
    fig.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    print(f"[{name}] states {real} on dih#{j1}/#{j2} (separates S{a}/S{b}) -> {p.name}", file=sys.stderr)


def main():
    for nm in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(nm)


if __name__ == "__main__":
    main()
