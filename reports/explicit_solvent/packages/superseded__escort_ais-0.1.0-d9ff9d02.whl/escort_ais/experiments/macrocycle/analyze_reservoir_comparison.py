#!/usr/bin/env python
"""Repeat the RGD_cold_basin_problem analyses on a given cold reservoir; emit figures + a metrics JSON.

Parametrized by --reservoir so it runs identically on the RMSD-seeded and torsion-seeded reservoirs, for a
controlled RMSD-vs-torsion comparison. Reproduces the figure families of docs/RGD_cold_basin_problem.pdf:
  1 all-torsion x 24-microstate heatmap        4 states-vs-REMD populations (artifact detection)
  2 24x24 dwell-filtered crossing matrix       5 cold-vs-REMD per-torsion distributions (JS)
  3 minor states in tor6/tor8                  6 artifact dwell/trapping (+ per-seed timeline)
Writes results/rgd/report/fig_<tag>_*.png and results/rgd/report/reservoir_metrics_<tag>.json.
Use --compare <tagA> <tagB> to emit the side-by-side comparison table/figure.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_reservoir_comparison \
        --reservoir data/rgd/2026-07-06-reservoir-torsion-s0p25/cold_md_10ns --tag torsion \
        --forward data/rgd/2026-06-29-reservoir-sw-s0p25/step_forward_ais
"""
from __future__ import annotations
import argparse, glob, json, sys, warnings
from pathlib import Path
import numpy as np, pandas as pd, mdtraj as md
warnings.filterwarnings("ignore")
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from scipy.special import logsumexp
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble

OUT = ROOT / "results/rgd/report"
REMD_DIR = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
K, MINOR, MAJOR = 24, 1, 0
BINS = np.linspace(-180, 180, 73)


def mdwell(d, D):
    out = d.copy(); cur = d[0]
    for i in range(1, len(d)):
        if d[i] != cur and i + D <= len(d) and np.all(d[i:i + D] == d[i]): cur = d[i]
        out[i] = cur
    return out


def js(a, b):
    ha, _ = np.histogram(a, BINS, density=True); hb, _ = np.histogram(b, BINS, density=True)
    ha = ha / ha.sum() + 1e-12; hb = hb / hb.sum() + 1e-12; m = .5 * (ha + hb)
    return .5 * np.sum(ha * np.log(ha / m)) + .5 * np.sum(hb * np.log(hb / m))


def analyze(reservoir, tag, forward, name="rgd"):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    fz = BasinModel.load(cfg.topo.parent / "basins_tica" / "basin_model_backbone.pkl")
    seeds = sorted(glob.glob(f"{reservoir}/seed_*/trajectory.dcd"))
    assert seeds, f"no seeds under {reservoir}"
    trs = [md.load_dcd(s, top=top)[50:] for s in seeds]
    Xs = [featurize(t, q) for t in trs]; Xall = np.concatenate(Xs)
    dih = [np.degrees(md.compute_dihedrals(t, q)) for t in trs]; DIH = np.concatenate(dih)
    gt = np.concatenate([fz.assign(t) for t in trs])                       # frozen dih#14 per frame
    nq = q.shape[0]

    # 24-microstate model (identical build)
    pca = PCA(8, random_state=0).fit(Xall); sc = StandardScaler().fit(pca.transform(Xall))
    km = KMeans(K, n_init=10, random_state=0).fit(sc.transform(pca.transform(Xall)))
    dtr = [mdwell(km.predict(sc.transform(pca.transform(X))).astype(int), 50) for X in Xs]  # min-dwell 50 ps
    full = np.concatenate(dtr)                                    # min-dwell labels: for crossings/trapping only
    raw = np.concatenate([km.predict(sc.transform(pca.transform(X))) for X in Xs])  # raw labels: for populations
    pop = np.bincount(raw, minlength=K).astype(float); pop /= pop.sum()             # matches deep-dive states_vs_remd
    minorf = np.array([gt[raw == k].mean() if (raw == k).any() else np.nan for k in range(K)])

    # REMD reference
    remd = load_remd_ensemble(REMD_DIR, "replica_00", cfg.top_pdb, 3000)
    remdd = np.degrees(md.compute_dihedrals(remd, q)); rgt = fz.assign(remd)
    rmic = km.predict(sc.transform(pca.transform(featurize(remd, q))))
    rp = np.bincount(rmic, minlength=K).astype(float); rp /= rp.sum()

    # forward-AIS landings (same file both reservoirs) -> per-state landing support
    fdf = pd.read_csv(f"{forward}/ais_trajectory_summary.csv"); logw = fdf["final_logw"].to_numpy()
    land = md.load_dcd(f"{forward}/ais_final_coordinates.dcd", top=top)
    lmic = km.predict(sc.transform(pca.transform(featurize(land, q))))
    land_cnt = np.bincount(lmic, minlength=K)

    # ---- metrics ----
    # thresholds matched to docs/RGD_cold_basin_problem (deep-dive): artifact = cold>1% AND REMD<0.5%;
    # real = both >0.5%; the rest ("tiny", cold<1% AND REMD~0) are counted separately.
    artifacts = [int(k) for k in range(K) if rp[k] < 0.005 and pop[k] > 0.01]        # cold-only (REMD~0)
    real = [int(k) for k in range(K) if rp[k] >= 0.005 and pop[k] > 0.005]
    tiny = [int(k) for k in range(K) if rp[k] < 0.005 and 0 < pop[k] <= 0.01]
    # crossing matrix (min-dwell 50 ps)
    C = np.zeros((K, K), int)
    for d in dtr:
        for a, b in zip(d[:-1], d[1:]):
            if a != b: C[a, b] += 1
    n_isolated = int(np.sum((C.sum(0) + C.sum(1)) == 0))
    # per-seed minor coverage & trapping (max single-seed occupancy per artifact)
    seed_minor = sum(1 for t in trs if (fz.assign(t) == MINOR).any())
    def trap_stats(k):
        runs = []; maxocc = 0
        for d in dtr:
            inS = (d == k); occ = inS.sum()
            if occ: maxocc = max(maxocc, occ / len(d))
            idx = np.where(inS)[0]
            if idx.size:
                brk = np.where(np.diff(idx) > 1)[0]
                s = np.r_[idx[0], idx[brk + 1]]; e = np.r_[idx[brk], idx[-1]]; runs += list(e - s + 1)
        return (max(runs) if runs else 0), maxocc
    trapped = sum(1 for k in artifacts if trap_stats(k)[0] >= 2000)
    jsd = np.array([js(DIH[:, j], remdd[:, j]) for j in range(nq)])

    metrics = dict(
        tag=tag, reservoir=str(reservoir), n_seeds=len(seeds),
        n_frames=int(len(full)), minor_frac_cold=float(gt.mean()), minor_frac_remd=float((rgt == MINOR).mean()),
        seed_minor_coverage=int(seed_minor),
        n_states_occupied=int(np.sum(pop > 0)), n_artifact_states=len(artifacts), n_real_states=len(real),
        n_tiny_states=len(tiny),
        n_isolated_microstates=n_isolated, total_crossings=int(C.sum()),
        n_trapped_artifacts=int(trapped),
        mean_js_cold_vs_remd=float(jsd.mean()),
        artifact_states=artifacts,
    )
    OUT.mkdir(parents=True, exist_ok=True)
    Path(OUT / f"reservoir_metrics_{tag}.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2), flush=True)

    # ---- figures (tagged) ----
    # (4) states-vs-REMD scatter
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.plot([1e-4, 1], [1e-4, 1], "k--", lw=.8)
    ax.scatter(pop + 1e-4, rp + 1e-4, s=40 + pop * 3000, c=np.nan_to_num(minorf), cmap="coolwarm", vmin=0, vmax=1, edgecolor="k", lw=.5)
    for k in range(K):
        if pop[k] > 0: ax.text(pop[k] + 1e-4, rp[k] + 1e-4, str(k), fontsize=7, ha="center", va="center")
    ax.set(xscale="log", yscale="log", xlim=(8e-4, .4), ylim=(8e-4, .4),
           xlabel="cold-reservoir population", ylabel="REMD population",
           title=f"[{tag}] states vs REMD: {len(real)} real, {len(artifacts)} cold-only artifacts")
    fig.tight_layout(); fig.savefig(OUT / f"fig_{tag}_states_vs_remd.png", dpi=140); plt.close(fig)

    # (2) crossing matrix
    fig, ax = plt.subplots(figsize=(6, 5.5))
    order = np.argsort(-pop); Cr = C[np.ix_(order, order)]
    M = np.ma.masked_where(Cr == 0, Cr)
    im = ax.imshow(M, cmap="viridis", norm=LogNorm(vmin=1, vmax=max(C.max(), 2)))
    ax.set(title=f"[{tag}] 24-state crossing matrix (dwell 50 ps)\ntotal off-diag={C.sum()}, isolated={n_isolated}/24",
           xlabel="to state", ylabel="from state")
    fig.colorbar(im, ax=ax, shrink=.8); fig.tight_layout()
    fig.savefig(OUT / f"fig_{tag}_transition_matrix.png", dpi=140); plt.close(fig)

    # (5) cold-vs-REMD per-torsion distributions (top-divergence 15)
    fig, axes = plt.subplots(3, 5, figsize=(15, 8))
    tags = {2: "dih2", 6: "tor6", 8: "tor8", 12: "dih12", 14: "dih14(sep)"}
    for j, axx in zip(np.argsort(-jsd), axes.flat):
        axx.hist(DIH[:, j], BINS, density=True, alpha=.5, color="#4477AA", label="cold")
        axx.hist(remdd[:, j], BINS, density=True, histtype="step", lw=1.6, color="#CC3311", label="REMD")
        axx.set_title(f"tor {j} {tags.get(j,'')} JS={jsd[j]:.3f}", fontsize=8); axx.set_xlim(-180, 180); axx.set_yticks([])
        if j == np.argsort(-jsd)[0]: axx.legend(fontsize=7)
    fig.suptitle(f"[{tag}] cold-MD vs REMD backbone-torsion distributions (mean JS {jsd.mean():.3f})", y=1.01)
    fig.tight_layout(); fig.savefig(OUT / f"fig_{tag}_cold_vs_remd_torsions.png", dpi=140, bbox_inches="tight"); plt.close(fig)

    # (6) per-seed microstate timeline
    fig, ax = plt.subplots(figsize=(13, 6)); cmap = plt.cm.tab20
    for i, d in enumerate(dtr):
        t = np.arange(len(d)) / 1000.0
        ax.scatter(t[::5], np.full(len(t[::5]), i), c=[cmap(s % 20) for s in d[::5]], s=4, marker="s", lw=0)
    ax.set(xlabel="cold-MD time (ns)", ylabel="seed", yticks=range(len(dtr)),
           title=f"[{tag}] per-seed microstate timeline (flat color = trapped in one state)")
    fig.tight_layout(); fig.savefig(OUT / f"fig_{tag}_trap_timeline.png", dpi=140); plt.close(fig)

    print(f"[{tag}] figures + metrics written to {OUT}", flush=True)
    return metrics


def compare(tagA, tagB):
    a = json.loads(Path(OUT / f"reservoir_metrics_{tagA}.json").read_text())
    b = json.loads(Path(OUT / f"reservoir_metrics_{tagB}.json").read_text())
    rows = [("seeds in minor basin", "seed_minor_coverage"), ("occupied microstates", "n_states_occupied"),
            ("real states (REMD>0.5%)", "n_real_states"), ("cold-only ARTIFACT states", "n_artifact_states"),
            ("trapped artifacts (>=2ns dwell)", "n_trapped_artifacts"),
            ("isolated microstates", "n_isolated_microstates"), ("total crossings", "total_crossings"),
            ("cold minor fraction", "minor_frac_cold"), ("mean JS(cold vs REMD)", "mean_js_cold_vs_remd")]
    print(f"\n{'metric':<34}{tagA:>12}{tagB:>12}")
    out = []
    for label, key in rows:
        va, vb = a[key], b[key]
        fa = f"{va:.3f}" if isinstance(va, float) else str(va)
        fb = f"{vb:.3f}" if isinstance(vb, float) else str(vb)
        print(f"{label:<34}{fa:>12}{fb:>12}")
        out.append(dict(metric=label, **{tagA: va, tagB: vb}))
    print(f"\nREMD reference minor fraction: {a['minor_frac_remd']:.3f}")
    Path(OUT / f"reservoir_compare_{tagA}_vs_{tagB}.json").write_text(json.dumps(out, indent=2))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--reservoir", help="cold_md dir with seed_*/trajectory.dcd")
    ap.add_argument("--tag", help="label for outputs, e.g. rmsd / torsion")
    ap.add_argument("--forward", default="data/rgd/2026-06-29-reservoir-sw-s0p25/step_forward_ais")
    ap.add_argument("--compare", nargs=2, metavar=("tagA", "tagB"))
    args = ap.parse_args()
    if args.compare:
        compare(*args.compare)
    else:
        analyze(args.reservoir, args.tag, args.forward)


if __name__ == "__main__":
    main()
