#!/usr/bin/env python3
"""analyze_2dgate_real.py — apply the 1-D vs 2-D residence gate to the REAL cold reservoir.

Per metastable basin B (TICA-on-hot, cold-ordered), for each homed 5 ns cold seed compute BOTH:
  R_sw    = longest continuous SUB-WELL residence while inside B (KMeans sub-wells on REMD+cold in B),
  R_basin = longest continuous stay INSIDE basin B.
Then pool the within-B frames and compare JS(P(.|B), REMD(.|B)) for:
  all homed seeds  |  1-D gate (R_sw <= T_sw)  |  2-D gate (R_sw <= T_sw AND R_basin > T_basin).
Also report the basin-residence distribution -- at s=1 seeds barely leave B, so R_basin is expected near the
full run length and the 2-D gate should collapse onto the 1-D gate.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_2dgate_real [name...]
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np
import mdtraj as md
from scipy.ndimage import median_filter
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_rite_local_equilibrium import HOT, REMD, NSTATE, STRIDE, _js  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
KSUB, MINSEED, MINPOOL = 12, 100, 300
PS = STRIDE * 1.0                                   # ps per (strided) frame -> 5 ps
SMOOTH = 21                                         # median-filter frames (~105 ps) to kill boundary flicker
T_SW, T_BASIN = 1.0, 2.0                            # ns: sub-well <= 1, basin > 2


def maxrun_bool(a):
    b = cur = 0
    for v in a:
        cur = cur + 1 if v else 0; b = max(b, cur)
    return b * PS / 1000.0


def maxrun_subwell(sub, ins):
    b = cur = 0; prev = -9
    for i in range(len(sub)):
        if ins[i]:
            cur = cur + 1 if sub[i] == prev else 1; prev = sub[i]
        else:
            cur = 0; prev = -9
        b = max(b, cur)
    return b * PS / 1000.0


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb); q, _, _ = load_quartets(cfg.topo, "backbone")
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NSTATE, lag=20, n_tic=4,
                                   burn_frames=1000, stride=2, seed=0)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    p0 = np.bincount(model.assign(remd), minlength=NSTATE).astype(float); p0 /= p0.sum()
    perm = np.argsort(-p0); inv = np.empty(NSTATE, int); inv[perm] = np.arange(NSTATE); p_remd = p0[perm]
    rstate = inv[model.assign(remd)]; remdX = featurize(remd, q)
    seedX, seedb = [], []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        tr = md.load_dcd(s, top=top)[50::STRIDE]
        seedX.append(featurize(tr, q)); seedb.append(inv[model.assign(tr)])   # per-frame basin
    dom = np.array([np.bincount(b, minlength=NSTATE).argmax() for b in seedb])

    print(f"\n===== {name} =====", file=sys.stderr)
    out = {"name": name, "t_sw": T_SW, "t_basin": T_BASIN, "basins": []}
    for B in range(NSTATE):
        if p_remd[B] < 0.01:
            continue
        homed = np.where(dom == B)[0]
        Xr = remdX[rstate == B]
        if len(Xr) < MINPOOL or len(homed) < 2:
            continue
        allcold = np.concatenate([seedX[i][seedb[i] == B] for i in homed])
        km = KMeans(min(KSUB, len(Xr) // 25 + 2), n_init=6, random_state=0).fit(np.concatenate([Xr, allcold]))
        pr = np.bincount(km.predict(Xr), minlength=km.n_clusters).astype(float)
        Rsw, Rbasin, keep = {}, {}, []
        for i in homed:
            bsm = median_filter(seedb[i], size=SMOOTH, mode="nearest")     # denoise basin assignment
            ins = bsm == B
            if ins.sum() < MINSEED:
                continue
            sub = median_filter(km.predict(seedX[i]), size=SMOOTH, mode="nearest")
            Rsw[i] = maxrun_subwell(sub, ins); Rbasin[i] = maxrun_bool(ins)
            keep.append(i)
        keep = np.array(keep)
        rsw = np.array([Rsw[i] for i in keep]); rbas = np.array([Rbasin[i] for i in keep])

        def pooljs(mask):
            ii = keep[mask]
            if not len(ii):
                return None, 0
            X = np.concatenate([seedX[i][seedb[i] == B] for i in ii])
            return round(_js(np.bincount(km.predict(X), minlength=km.n_clusters), pr), 4), int(len(ii))

        g_all = np.ones(len(keep), bool)
        g_1d = rsw <= T_SW
        g_2d = (rsw <= T_SW) & (rbas > T_BASIN)
        j_all, n_all = pooljs(g_all); j_1d, n_1d = pooljs(g_1d); j_2d, n_2d = pooljs(g_2d)
        dropped = int(g_1d.sum() - g_2d.sum())
        rec = dict(state=B, p_remd=round(float(p_remd[B]), 3), n_seeds=len(keep),
                   rbasin_min=round(float(rbas.min()), 2), rbasin_med=round(float(np.median(rbas)), 2),
                   frac_rbasin_gt2=round(float((rbas > T_BASIN).mean()), 3),
                   js_all=j_all, n_all=n_all, js_1d=j_1d, n_1d=n_1d, js_2d=j_2d, n_2d=n_2d,
                   n_1d_only_dropped_by_2d=dropped)
        out["basins"].append(rec)
        print(f"  S{B} (pop {p_remd[B]:.2f}, {len(keep)} seeds): R_basin min/med {rbas.min():.1f}/{np.median(rbas):.1f} ns, "
              f"frac(R_basin>2ns)={(rbas>T_BASIN).mean():.2f}", file=sys.stderr)
        print(f"     JS:  all(n={n_all})={j_all}   1D R_sw<=1(n={n_1d})={j_1d}   "
              f"2D +R_basin>2(n={n_2d})={j_2d}   [2D drops {dropped} of the 1D seeds]", file=sys.stderr)
    (BE / name / "twod_gate_real.json").write_text(json.dumps(out, indent=2))
    return out


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
