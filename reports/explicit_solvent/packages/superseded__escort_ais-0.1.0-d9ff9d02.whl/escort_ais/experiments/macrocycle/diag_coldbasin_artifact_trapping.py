import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob, sys
import mdtraj as md
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
RES='data/rgd/2026-06-29-reservoir-sw-s0p25'
seeds=sorted(glob.glob(f'{RES}/cold_md_10ns/seed_*/trajectory.dcd'))
# build 24-state model + per-seed microstate trajectories (1 ps/frame, keep TEMPORAL order, no min-dwell)
Xseed=[featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds]; Xall=np.concatenate(Xseed)
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(24,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
dtrajs=[km.predict(sc.transform(pca.transform(X))) for X in Xseed]
res_micro=np.concatenate(dtrajs); npop=np.bincount(res_micro,minlength=24)
# REMD pop for classifying artifact
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
rp=np.bincount(km.predict(sc.transform(pca.transform(featurize(remd,q)))),minlength=24).astype(float); rp/=rp.sum()
artifacts=[k for k in range(24) if rp[k]<0.005 and npop[k]>0]   # ~0% in REMD but present in cold
print(f"artifact microstates (REMD<0.5%): {sorted(artifacts)}",flush=True)
print(f"\n{'st':>3} {'cold%':>6} {'REMD%':>6} {'#visits':>7} {'#seeds':>6} {'medDwell':>8} {'maxDwell':>8} {'maxSeedOcc':>10} verdict",flush=True)
for k in sorted(artifacts, key=lambda k:-npop[k]):
    runs=[]; seeds_hit=0; maxocc=0
    for d in dtrajs:
        inS=(d==k)
        occ=inS.sum()
        if occ>0: seeds_hit+=1; maxocc=max(maxocc, occ/len(d))
        # continuous run lengths
        idx=np.where(inS)[0]
        if idx.size:
            brk=np.where(np.diff(idx)>1)[0]
            starts=np.r_[idx[0], idx[brk+1]]; ends=np.r_[idx[brk], idx[-1]]
            runs += list((ends-starts+1))   # frames == ps
    runs=np.array(runs)
    med=np.median(runs); mx=runs.max()
    # trapped if a single visit lasts >>flicker (say >500 ps) or one seed spends >50% there; transient if all short
    if mx>=2000 or maxocc>0.5: v="TRAPPED (long single visit)"
    elif mx>=200: v="semi-trapped"
    else: v="transient (flickers)"
    print(f"{k:3d} {100*npop[k]/len(res_micro):6.1f} {100*rp[k]:6.1f} {len(runs):7d} {seeds_hit:6d} "
          f"{med:8.0f} {mx:8.0f} {maxocc:10.2f} {v}",flush=True)
print("\nDwell in ps (cold MD = 1 ps/frame). TRAPPED: one seed sits there for a long continuous stretch.",flush=True)
print("transient: only short (<200 ps) flickers, the state is a passage region, not a trap.",flush=True)
