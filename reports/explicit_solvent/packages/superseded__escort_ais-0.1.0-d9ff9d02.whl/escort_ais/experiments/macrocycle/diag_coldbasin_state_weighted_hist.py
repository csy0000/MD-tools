import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob, sys
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.special import logsumexp
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
RES='data/rgd/2026-06-29-reservoir-sw-s0p25'
import pandas as pd
fdf=pd.read_csv(f'{RES}/step_forward_ais/ais_trajectory_summary.csv'); logw=fdf['final_logw'].to_numpy()
landX=featurize(md.load_dcd(f'{RES}/step_forward_ais/ais_final_coordinates.dcd',top=top),q)
seeds=sorted(glob.glob(f'{RES}/cold_md_10ns/seed_*/trajectory.dcd'))
Xseed=[featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds]; Xall=np.concatenate(Xseed)
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(24,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
micro_f=km.predict(sc.transform(pca.transform(landX)))       # landing -> state
res_micro=km.predict(sc.transform(pca.transform(Xall)))      # cold frame -> state
# STATE landing weight (drift-free): p_land(S) = sum exp(logw) over landings in S
lp=np.full(24,-np.inf)
for S in range(24):
    m=micro_f==S
    if m.any(): lp[S]=logsumexp(logw[m])
lp-=logsumexp(lp); p_land=np.exp(lp)   # per-state population from forward-AIS weights
ncold=np.bincount(res_micro,minlength=24)
# each cold frame weight = p_land(state)/ncold(state)
wframe=np.array([p_land[S]/ncold[S] if ncold[S]>0 else 0.0 for S in res_micro]); wframe/=wframe.sum()
DIH=np.concatenate([np.degrees(md.compute_dihedrals(md.load_dcd(s,top=top)[50:],q)) for s in seeds])
gt=fz.assign(md.load_dcd(seeds[0],top=top)[:1]) # dummy
GT=np.concatenate([fz.assign(md.load_dcd(s,top=top)[50:]) for s in seeds])
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
remdd=np.degrees(md.compute_dihedrals(remd,q)); rgt=fz.assign(remd)
ess=1.0/np.sum(wframe**2)/len(wframe)   # ESS fraction
wmin=wframe[GT==1].sum()
print(f"minor frac: cold-unweighted {GT.mean():.3f}  STATE-weighted {wmin:.3f}  REMD {rgt.mean():.3f}",flush=True)
print(f"suppressed weight in artifact states (REMD<0.5%): {sum(p_land[S] for S in range(24) if (np.bincount(km.predict(sc.transform(pca.transform(featurize(remd,q)))),minlength=24)/len(remd))[S]<0.005):.3f}",flush=True)
nq=q.shape[0]; bins=np.linspace(-180,180,73)
def js(h1,h2):
    a=h1/h1.sum()+1e-12; b=h2/h2.sum()+1e-12; m=.5*(a+b); return .5*np.sum(a*np.log(a/m))+.5*np.sum(b*np.log(b/m))
jsl=[]
for j in range(nq):
    hw,_=np.histogram(DIH[:,j],bins,weights=wframe); hr,_=np.histogram(remdd[:,j],bins,density=True); jsl.append(js(hw,hr))
jsl=np.array(jsl); print(f"mean JS(state-weighted vs REMD) {jsl.mean():.3f}  (per-seed scheme was 0.15-0.27; unweighted ~0.10)",flush=True)
tags={2:'dih2',6:'tor6',8:'tor8',12:'dih12',14:'dih14(sep)'}
fig,axes=plt.subplots(3,5,figsize=(15,8))
for j,ax in zip(np.argsort(-jsl),axes.flat):
    ax.hist(DIH[:,j],bins,density=True,alpha=.4,color='#88AACC',label='cold unweighted')
    hw,_=np.histogram(DIH[:,j],bins,weights=wframe,density=True); ax.stairs(hw,bins,color="#117733",lw=1.6,label="STATE-weighted")
    ax.hist(remdd[:,j],bins,density=True,histtype='step',lw=1.6,color='#CC3311',label='REMD')
    ax.set_title(f"tor {j} {tags.get(j,'')} JS={jsl[j]:.3f}",fontsize=8); ax.set_xlim(-180,180); ax.set_yticks([])
    if j==np.argsort(-jsl)[0]: ax.legend(fontsize=7)
fig.suptitle(f'Cold reservoir weighted PER-CONFIGURATION by state landing-weight vs REMD (minor {wmin:.2f}, mean JS {jsl.mean():.3f})',fontsize=12,y=1.01)
fig.tight_layout(); fig.savefig('results/rgd/report/fig_cold_stateweighted_vs_remd.png',dpi=140,bbox_inches='tight'); print('saved',flush=True)
