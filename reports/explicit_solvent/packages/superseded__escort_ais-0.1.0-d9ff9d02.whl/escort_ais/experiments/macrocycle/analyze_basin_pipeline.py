"""analyze_basin_pipeline.py — Stage 8: full basin free-energy comparison table.

Assembles all available estimators (forward-AIS, MSM-only, reverse-BAR, hybrid)
from the staged basin pipeline outputs and reports them SEPARATELY in one table.

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.analyze_basin_pipeline \\
        --ais-dir data/.../03_fwd_ais \\
        --cold-local-dir data/.../05_cold_local \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/.../08_analysis \\
        --n-basins 4 --n-clusters 50 --tica-lag 5 --msm-lag 5 \\
        [--rev-ais-dir data/.../07_rev_ais] \\
        [--n-boot 500] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd



def _load_ais_work(ais_dir: Path) -> tuple[np.ndarray, int]:
    wt = np.load(ais_dir / "work_timeseries.npy")
    final_logw = -wt[:, -1].astype(np.float64)
    final_logw[~np.isfinite(final_logw)] = -np.inf
    return final_logw, len(final_logw)


def _load_phi_psi_from_cold_local(cold_local_dir: Path, prmtop_path: Path, stride: int = 1):
    """Load phi/psi from all per-walker DCDs in cold_local_dir."""
    from escort_ais.methods.basin_assignment import load_phi_psi_from_dcd
    walker_dirs = sorted(cold_local_dir.glob("walker_????"))
    phi_list, psi_list, wid_list = [], [], []
    for k, wd in enumerate(walker_dirs):
        dcd = wd / "trajectory.dcd"
        if not dcd.exists():
            continue
        phi, psi = load_phi_psi_from_dcd(dcd, prmtop_path, stride=stride)
        phi_list.append(phi)
        psi_list.append(psi)
        wid_list.extend([k] * len(phi))
    return np.concatenate(phi_list), np.concatenate(psi_list), np.array(wid_list, dtype=np.int64)


def _fit_msm(phi_cold, psi_cold, walker_ids, n_clusters, tica_lag, msm_lag, n_basins):
    from escort_ais.systems.torsion_features import sincos_features, build_lagged_pairs
    from escort_ais.methods.msm_estimation import fit_tica, cluster_kmeans, fit_reversible_msm, pcca_basins, msm_basin_weights

    features = sincos_features(phi_cold, psi_cold)
    frame_ids = np.zeros(len(phi_cold), dtype=np.int64)
    # Build per-walker frame indices
    unique_walkers = np.unique(walker_ids)
    for w in unique_walkers:
        mask = walker_ids == w
        frame_ids[mask] = np.arange(mask.sum())

    t_idx, tl_idx = build_lagged_pairs(walker_ids, frame_ids, tica_lag)
    print(f"  TICA: {len(t_idx)} lagged pairs (lag={tica_lag})")

    tica_result = fit_tica(features, t_idx, tl_idx, n_dims=2)
    proj = tica_result.projection
    print(f"  TICA eigenvalues: {tica_result.eigenvalues}")

    km_labels = cluster_kmeans(proj, n_clusters)
    print(f"  k-means: {n_clusters} micro-states")

    # Per-walker discretized trajectories for MSM
    dtrajs = []
    for w in unique_walkers:
        mask = walker_ids == w
        dtrajs.append(km_labels[mask])

    msm_result = fit_reversible_msm(dtrajs, msm_lag)
    n_components = len(msm_result.connected_sets)
    print(f"  MSM: {n_components} connected component(s)")

    msm_result = pcca_basins(msm_result, n_basins)
    basin_weights = msm_basin_weights(msm_result)

    # Cluster centers for endpoint assignment
    unique_centers = np.array([proj[km_labels == k].mean(axis=0)
                               for k in range(n_clusters)])

    return tica_result.model, unique_centers, msm_result, basin_weights


def main() -> None:
    parser = argparse.ArgumentParser(description="Basin free-energy comparison table.")
    parser.add_argument("--ais-dir", required=True, type=Path)
    parser.add_argument("--cold-local-dir", required=True, type=Path)
    parser.add_argument("--topology-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--n-basins", type=int, default=4)
    parser.add_argument("--n-clusters", type=int, default=50)
    parser.add_argument("--tica-lag", type=int, default=5)
    parser.add_argument("--msm-lag", type=int, default=5)
    parser.add_argument("--cold-stride", type=int, default=1)
    parser.add_argument("--rev-ais-dir", type=Path, default=None,
                        help="Stage-07 reverse AIS dir (optional; enables BAR).")
    parser.add_argument("--n-boot", type=int, default=0,
                        help="Bootstrap replicates (0 = skip bootstrap).")
    parser.add_argument("--temperature-k", type=float, default=300.0)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    from escort_ais.methods.basin_assignment import load_phi_psi_from_dcd, assign_msm_basins_with_centers
    from escort_ais.methods.basin_estimators import (
        forward_ais_basin_probs, msm_only_basin_probs, hybrid_basin_probs,
        verify_forward_ais, comparison_table,
    )

    output_dir = ensure_dir(args.output_dir)

    # Resolve prmtop
    topo_dir = Path(args.topology_dir)
    prmtop_path = None
    for name in ("system_scale_1p0.prmtop", "system.prmtop"):
        candidate = topo_dir / name
        if candidate.exists():
            prmtop_path = candidate
            break
    if prmtop_path is None:
        raise FileNotFoundError(f"No prmtop in {topo_dir}")

    print("Loading forward-AIS work ...")
    final_logw, K = _load_ais_work(args.ais_dir)
    print(f"  K={K} walkers")

    # Load AIS cold endpoints
    from escort_ais.methods.basin_assignment import load_phi_psi_from_dcd as _lpp
    phi_ep, psi_ep = _lpp(args.ais_dir / "final_samples.dcd", prmtop_path)
    print(f"  {len(phi_ep)} cold endpoints")

    if args.dry_run:
        print("dry_run=True: skipping TICA/MSM fitting.")
        summary = {"dry_run": True}
        (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print(f"  Output: {output_dir}")
        return

    print("Loading cold local trajectories ...")
    phi_cold, psi_cold, walker_ids = _load_phi_psi_from_cold_local(
        args.cold_local_dir, prmtop_path, stride=args.cold_stride
    )
    print(f"  Cold trajectory: {len(phi_cold)} frames")

    print("Fitting TICA + MSM ...")
    tica_model, cluster_centers, msm_result, basin_weights = _fit_msm(
        phi_cold, psi_cold, walker_ids,
        args.n_clusters, args.tica_lag, args.msm_lag, args.n_basins
    )

    # Assign AIS endpoints to basins
    from escort_ais.methods.msm_estimation import connected_components
    all_connected_micro = [m for comp in connected_components(msm_result) for m in comp]
    basin_labels_ep = assign_msm_basins_with_centers(
        phi_ep, psi_ep, tica_model, cluster_centers,
        msm_result.basin_of_microstate,
        connected_microstates=all_connected_micro,
    )

    # Forward-AIS estimator
    ais_verify = verify_forward_ais(final_logw, basin_labels_ep)
    print(f"\n  ESS: {ais_verify['ess']:.1f} / {K} ({100*ais_verify['ess_fraction']:.1f}%)")
    print(f"  Partition sum invariant: {'PASS' if ais_verify['partition_sum_ok'] else 'FAIL'}")

    if not ais_verify["partition_sum_ok"]:
        print("ERROR: Partition sum invariant failed. Exiting.")
        sys.exit(1)

    fwd_probs = ais_verify["basin_probs"]
    msm_probs = msm_only_basin_probs(basin_weights)
    hyb_probs = hybrid_basin_probs(fwd_probs, msm_probs)

    # Optional: BAR from reverse AIS
    bar_probs = None
    if args.rev_ais_dir is not None and (args.rev_ais_dir / "work_timeseries.npy").exists():
        from escort_ais.methods.reverse_ais_bar import basin_restricted_bar
        rev_logw, K_rev = _load_ais_work(args.rev_ais_dir)
        rev_w = -rev_logw  # W^{C→H}
        fwd_w = -final_logw  # W^{H→C}

        # Need basin labels for reverse walkers too
        phi_rev_ep, psi_rev_ep = _lpp(args.rev_ais_dir / "final_samples.dcd", prmtop_path)
        basin_labels_rev = assign_msm_basins_with_centers(
            phi_rev_ep, psi_rev_ep, tica_model, cluster_centers,
            msm_result.basin_of_microstate, connected_microstates=all_connected_micro,
        )
        all_basins = sorted(set(basin_labels_ep) | set(basin_labels_rev))
        bar_df_dict = basin_restricted_bar(fwd_w, rev_w, basin_labels_ep, basin_labels_rev,
                                           all_basin_names=all_basins)
        # Convert ΔF → probabilities: P_bar(B) ∝ exp(-ΔF_B)
        finite_basins = {b: v for b, v in bar_df_dict.items() if np.isfinite(v)}
        if finite_basins:
            import scipy.special
            log_z_bar = scipy.special.logsumexp([-v for v in finite_basins.values()])
            bar_probs = {b: float(np.exp(-v - log_z_bar)) for b, v in finite_basins.items()}
        print(f"  BAR: {len(finite_basins)}/{len(all_basins)} basins have finite ΔF")

    # Build comparison table
    df = comparison_table(fwd_probs, msm_probs, reverse_bar=bar_probs, hybrid=hyb_probs)

    print("\n" + "=" * 70)
    print("BASIN FREE-ENERGY COMPARISON TABLE")
    print("=" * 70)
    print(df.to_string(index=False, float_format=lambda x: f"{x:.4f}"))

    df.to_csv(output_dir / "comparison_table.csv", index=False)

    summary = {
        "ess": ais_verify["ess"],
        "ess_fraction": ais_verify["ess_fraction"],
        "n_walkers": K,
        "n_basins": args.n_basins,
        "n_clusters": args.n_clusters,
        "partition_sum_ok": ais_verify["partition_sum_ok"],
        "n_connected_components": len(connected_components(msm_result)),
        "forward_ais": fwd_probs,
        "msm_only": {str(k): float(v) for k, v in msm_probs.items()},
        "hybrid": hyb_probs,
    }
    if bar_probs:
        summary["bar"] = bar_probs
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"\nTable written to {output_dir}/comparison_table.csv")
    print(f"Summary written to {output_dir}/summary.json")


if __name__ == "__main__":
    main()
