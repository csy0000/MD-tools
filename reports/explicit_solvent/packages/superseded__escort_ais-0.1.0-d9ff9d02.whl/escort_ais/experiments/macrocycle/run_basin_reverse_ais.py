"""run_basin_reverse_ais.py — Stage 7: reverse AIS s:1.0→s_hot for BAR estimator.

Runs reverse AIS from cold basin-resampled start positions (stage 4 output)
switching direction s_cold=1.0 → s_hot=0.4.  Records W^{C→H} per walker.

Uses ais_linear.run_linear_scaling_ais with s_hot<→s_cold swapped:
  scale_schedule = linspace(1.0, s_hot, n_windows+1)

Outputs mirror forward AIS:
  work_timeseries.npy     — (K, n_windows) cumulative reduced work W^{C→H}
  final_samples.dcd        — hot endpoint positions after switching
  ais_work.csv            — per-walker summary

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_basin_reverse_ais \\
        --cold-starts data/.../04_ais_resampled/resampled_cold_starts.npy \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/.../07_rev_ais \\
        --s-hot 0.4 --n-windows 20 --switching-time-ps 100.0 \\
        --temperature-k 300.0 --platform OpenCL [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np



def main() -> None:
    parser = argparse.ArgumentParser(description="Run reverse AIS s:1.0→s_hot.")
    parser.add_argument("--cold-starts", required=True, type=Path,
                        help="(K, n_atoms, 3) npy file of equal-weight cold start positions.")
    parser.add_argument("--topology-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--s-hot", type=float, default=0.4,
                        help="Hot (high-temperature) scale factor (target of reverse switch).")
    parser.add_argument("--n-windows", type=int, default=20,
                        help="Number of AIS switching windows.")
    parser.add_argument("--switching-time-ps", type=float, default=100.0)
    parser.add_argument("--temperature-k", type=float, default=300.0)
    parser.add_argument("--timestep-fs", type=float, default=2.0)
    parser.add_argument("--friction-per-ps", type=float, default=1.0)
    parser.add_argument("--platform", default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-walkers", type=int, default=None,
                        help="Limit to first N walkers (for testing).")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    output_dir = ensure_dir(args.output_dir)

    config = {
        "cold_starts": str(args.cold_starts.resolve()),
        "topology_dir": str(args.topology_dir.resolve()),
        "s_cold": 1.0,
        "s_hot": args.s_hot,
        "n_windows": args.n_windows,
        "switching_time_ps": args.switching_time_ps,
        "temperature_k": args.temperature_k,
        "timestep_fs": args.timestep_fs,
        "friction_per_ps": args.friction_per_ps,
        "seed": args.seed,
        "dry_run": args.dry_run,
        "output_dir": str(output_dir.resolve()),
    }
    (output_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    if args.dry_run:
        print("dry_run=True: skipping reverse AIS.")
        cold_starts_path = args.cold_starts
        K = np.load(cold_starts_path).shape[0] if cold_starts_path.exists() else args.n_walkers or 0
        summary = {**config, "n_walkers": K, "n_windows": args.n_windows}
        (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        print(f"  Config written to {output_dir}/config.json")
        return

    # Load cold starts
    cold_starts_nm = np.load(args.cold_starts)
    if args.n_walkers is not None:
        cold_starts_nm = cold_starts_nm[: args.n_walkers]
    K = cold_starts_nm.shape[0]

    from escort_ais.methods.ais_linear import run_linear_scaling_ais  # type: ignore[attr-defined]

    # Reverse direction: 1.0 → s_hot
    scale_schedule = np.linspace(1.0, args.s_hot, args.n_windows + 1)

    print(f"Running reverse AIS: s_cold=1.0 → s_hot={args.s_hot:.3f}")
    print(f"  K={K} walkers, {args.n_windows} windows, {args.switching_time_ps} ps each")

    results = run_linear_scaling_ais(
        topology_dir=args.topology_dir,
        seed_positions_nm=cold_starts_nm,
        scale_schedule=scale_schedule,
        temperature_k=args.temperature_k,
        timestep_fs=args.timestep_fs,
        friction_per_ps=args.friction_per_ps,
        switching_time_ps=args.switching_time_ps,
        platform=args.platform,
        seed=args.seed,
        output_dir=output_dir,
    )

    summary = {**config, "n_walkers": K, **results.get("summary", {})}
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"\nDone. Output: {output_dir}")


if __name__ == "__main__":
    main()
