#!/usr/bin/env python3
"""compute_state_population_convergence.py — per-hot-length convergence of the bAIS state populations
over isolated metastable states (threshold-free replacement for the single-torsion ddF convergence).

State definition: isolated metastable states from TICA on the transition-rich HOT ensemble (fixed model,
so only the accumulated forward-AIS landings change across checkpoints). At each checkpoint g:
  p_bAIS(state) = sum_{landings in gen 0..g} e^{logw} / sum e^{logw}   (forward-AIS Jarzynski population)
  dG_bAIS(state) = -ln( p_bAIS(state) / p_bAIS(ref) ),  ref = most-populated REMD state
  TV = 0.5 * sum_state | p_bAIS - p_REMD |
The REMD population vector and the raw (unweighted) cold-reservoir population vector are stored once (header).

Writes data/rgd/diagnostics/bais_eval/<name>/state_population_convergence.json.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.compute_state_population_convergence
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.metrics import silhouette_score

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
HOT = {"rgd": ROOT / "data/rgd/2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701/trajectory.dcd",
       "cilengitide": ROOT / "data/cilengitide/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
       "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd"}
NSTATE = 5


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NSTATE,
                                   lag=20, n_tic=4, burn_frames=1000, stride=2, seed=0)

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remd_lab = model.assign(remd)
    p_remd = np.bincount(remd_lab, minlength=NSTATE).astype(float); p_remd /= p_remd.sum()
    # RELABEL the states by COLD (REMD) population so S0 = most populated in the reference, S1 = 2nd, ...
    # (the TICABasinModel numbers by HOT-fit population; hot<->cold rank inversions make that confusing).
    perm = np.argsort(-p_remd)
    p_remd = p_remd[perm]; ref = 0
    Yremd = model.tica.transform(featurize(remd, q))[:, :model.n_tic]
    sil = float(silhouette_score(Yremd, remd_lab, sample_size=min(3000, len(remd)), random_state=0))

    cold_lab = np.concatenate([model.assign(md.load_dcd(s, top=top)[50:])
                               for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))])
    p_cold = np.bincount(cold_lab, minlength=NSTATE).astype(float)[perm]; p_cold /= p_cold.sum()

    # per-generation forward landings (assign + logw)
    ledger = json.load(open(BE / name / "generations.json"))["generations"]
    labg, lwg = [], []
    for g in range(len(ledger)):
        d = pd.read_csv(BE / name / f"gen{g}/fwd/ais_trajectory_summary.csv")
        t = md.load_dcd(str(BE / name / f"gen{g}/fwd/ais_final_coordinates.dcd"), top=top)
        n = min(len(d), t.n_frames)
        labg.append(model.assign(t[:n])); lwg.append(d["final_logw"].to_numpy()[:n])

    def dG(p):
        return list(np.round(-np.log(np.clip(p, 1e-9, None) / max(p[ref], 1e-9)), 3))

    checkpoints = []
    for g in range(len(ledger)):
        lab = np.concatenate(labg[:g + 1]); lw = np.concatenate(lwg[:g + 1])
        pb = np.array([np.exp(logsumexp(lw[lab == s])) if (lab == s).any() else 0.0 for s in range(NSTATE)])
        pb /= pb.sum(); pb = pb[perm]                          # cold-order relabel (see perm above)
        checkpoints.append(dict(gen=g, hot_ns=float(ledger[g]["hot_ns"]),
                                p_bais=list(np.round(pb, 4)), dG_bais=dG(pb),
                                tv=round(float(0.5 * np.abs(pb - p_remd).sum()), 4)))

    # REMD reference convergence vs cumulative REMD length T (state dG, cold-ordered, 10-block SEM)
    FPN = 100  # REMD frames per ns (10 ps/frame)
    remd_conv = []
    for T in range(50, 501, 50):
        m = min(int(T * FPN), len(remd_lab)); sub = remd_lab[:m]
        p = np.bincount(sub, minlength=NSTATE).astype(float); p = (p / p.sum())[perm]
        L = m // 10; blk = []
        for b in range(10):
            pb = np.bincount(sub[b * L:(b + 1) * L], minlength=NSTATE).astype(float)
            if pb.sum() > 0:
                pb = (pb / pb.sum())[perm]
                blk.append(-np.log(np.clip(pb, 1e-9, None) / max(pb[0], 1e-9)))
        blk = np.array(blk)
        sem = (blk.std(0) / np.sqrt(len(blk))) if len(blk) > 1 else np.zeros(NSTATE)
        remd_conv.append(dict(T=T, dG=list(np.round(dG(p), 3)), sem=list(np.round(sem, 3))))

    out = dict(name=name, n_states=NSTATE, ref_state=ref, silhouette=round(sil, 3),
               p_remd=list(np.round(p_remd, 4)), dG_remd=dG(p_remd),
               p_cold_raw=list(np.round(p_cold, 4)), checkpoints=checkpoints,
               remd_convergence=remd_conv)
    (BE / name / "state_population_convergence.json").write_text(json.dumps(out, indent=2))
    print(f"[{name}] {NSTATE} states, sil {sil:+.2f}, ref S{ref}; final TV {checkpoints[-1]['tv']:.3f}; "
          f"REMD pops {out['p_remd']} -> state_population_convergence.json", file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
