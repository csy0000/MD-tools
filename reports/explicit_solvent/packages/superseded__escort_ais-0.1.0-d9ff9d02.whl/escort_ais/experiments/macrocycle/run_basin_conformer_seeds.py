"""run_basin_conformer_seeds.py — Stage 1a: generate diverse conformer seeds for hot walkers.

Produces:
  output_dir/conformer_pool.sdf      — full pool (SDF with MMFF-optimised conformers)
  output_dir/picked_ids.npy          — (K,) int array of selected conformer IDs
  output_dir/seed_positions.npy      — (K, n_atoms, 3) float64 in nm, Amber atom order
  output_dir/atom_map.npy            — openmm_to_rdkit mapping array
  output_dir/config.json             — run parameters
  output_dir/summary.json            — K_actual, n_pool, ...

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_basin_conformer_seeds \\
        --smiles "CC(=O)N[C@@H](C)C(=O)NC" \\
        --leap-pdb data/alanine_dipeptide/openmm/ace_ala_nme_leap.pdb \\
        --output-dir data/alanine_dipeptide/basin_pipeline/2026-06-12-phase-c/01_seeds \\
        --n-pick 1000 --n-pool 5000 --seed 42 [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np



def main() -> None:
    parser = argparse.ArgumentParser(description="Generate diverse conformer seeds.")
    parser.add_argument("--smiles", default="CC(=O)N[C@@H](C)C(=O)NC")
    parser.add_argument("--leap-pdb", required=True, type=Path,
                        help="Canonical tleap PDB for atom-order mapping.")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--n-pick", type=int, default=1000,
                        help="Number of diverse conformers to keep.")
    parser.add_argument("--n-pool", type=int, default=5000,
                        help="Pool size before MaxMin diversity selection.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--no-nvmolkit", action="store_true",
                        help="Force RDKit ETKDG even if nvMolKit is available.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Validate args and exit without computation.")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    output_dir = ensure_dir(args.output_dir)

    config = {
        "smiles": args.smiles,
        "leap_pdb": str(args.leap_pdb.resolve()),
        "n_pick": args.n_pick,
        "n_pool": args.n_pool,
        "seed": args.seed,
        "use_nvmolkit": not args.no_nvmolkit,
        "dry_run": args.dry_run,
        "output_dir": str(output_dir.resolve()),
    }
    (output_dir / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    if args.dry_run:
        print("dry_run=True: skipping conformer generation.")
        summary = {**config, "n_actual": 0, "wall_time_s": 0.0}
        (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return

    import time
    from escort_ais.systems.conformer_seeding import (
        generate_conformer_pool,
        maxmin_diversify,
        conformers_to_openmm_seeds,
    )
    from escort_ais.systems.openmm_system import map_rdkit_atoms_to_openmm_topology
    from rdkit.Chem import SDWriter

    t0 = time.time()

    print(f"Generating conformer pool (n_pool={args.n_pool}) ...")
    mol = generate_conformer_pool(
        args.smiles, n_pool=args.n_pool, seed=args.seed,
        use_nvmolkit=not args.no_nvmolkit,
    )
    n_pool_actual = mol.GetNumConformers()
    print(f"  Generated {n_pool_actual} conformers.")

    print(f"MaxMin diversity picking {args.n_pick} from {n_pool_actual} ...")
    picked_ids = maxmin_diversify(mol, n_pick=args.n_pick, seed=args.seed)
    print(f"  Selected {len(picked_ids)} diverse conformers.")

    print("Converting to OpenMM seed positions (atom reorder + Å→nm) ...")
    seed_positions_nm = conformers_to_openmm_seeds(mol, picked_ids, args.leap_pdb)

    # Save atom map
    atom_map = map_rdkit_atoms_to_openmm_topology(mol, args.leap_pdb)

    # Save outputs
    np.save(output_dir / "picked_ids.npy", np.array(picked_ids, dtype=np.int64))
    np.save(output_dir / "seed_positions.npy", seed_positions_nm)
    np.save(output_dir / "atom_map.npy", atom_map)

    # Write conformer pool SDF (for inspection)
    with SDWriter(str(output_dir / "conformer_pool.sdf")) as writer:
        for cid in picked_ids:
            writer.write(mol, confId=cid)

    wall_time_s = time.time() - t0
    summary = {
        **config,
        "n_pool_actual": n_pool_actual,
        "n_actual": len(picked_ids),
        "seed_positions_shape": list(seed_positions_nm.shape),
        "wall_time_s": wall_time_s,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print(f"\nDone in {wall_time_s:.1f}s.")
    print(f"  seed_positions.npy  shape: {seed_positions_nm.shape}")
    print(f"  Output: {output_dir}")


if __name__ == "__main__":
    main()
