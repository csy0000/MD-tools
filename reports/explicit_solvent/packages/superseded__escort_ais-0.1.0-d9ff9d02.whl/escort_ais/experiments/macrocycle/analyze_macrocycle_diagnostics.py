#!/usr/bin/env python3
"""analyze_macrocycle_diagnostics.py — collate the 3-method diagnostic runs into a table + plots.

Reads the validation_summary.json written by run_macrocycle_seedsource_swap.py across the 2x2 swap
cells and the k/switch/reservoir sweeps, and reports the three methods we compare:
  (1) REMD  = converged baseline / reference ddF
  (2) AIS + cold MD = forward-AIS Jarzynski ddF (summary key ddF_ais)
  (3) BAR + cold MD = endpoint-restricted BAR ddF (summary key ddF_bar) with bootstrap CIs
RMSE of (2) and (3) is scored vs (1) over the covered basins. For the 2x2 swap it also prints the
decision-matrix attribution (cold reservoir vs hot vs estimator).

Usage:
  python -m escort_ais.experiments.macrocycle.analyze_macrocycle_diagnostics --name rgd \
      --runs data/rgd/diagnostics/swap_RR data/rgd/diagnostics/swap_SS \
             data/rgd/diagnostics/swap_RS data/rgd/diagnostics/swap_SR
  # or by glob:
  python -m escort_ais.experiments.macrocycle.analyze_macrocycle_diagnostics --name rgd \
      --glob 'data/rgd/diagnostics/*'
"""
from __future__ import annotations

import argparse
import glob as globlib
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()


def _rmse(vals, ref, mask):
    vals = np.asarray(vals, float); ref = np.asarray(ref, float)
    m = np.isfinite(vals) & np.isfinite(ref) & np.asarray(mask, bool)
    return float(np.sqrt(np.mean((vals[m] - ref[m]) ** 2))) if m.any() else float("nan")


def load_summary(d: Path) -> dict | None:
    f = d / "validation_summary.json"
    if not f.exists():
        return None
    s = json.loads(f.read_text())
    ref = np.asarray(s.get("reference_ddF", []), float)
    nb = len(ref)
    covered = s.get("covered_basins")
    covered = np.asarray(covered, bool) if covered is not None else np.ones(nb, bool)
    ais = np.asarray(s.get("ddF_ais", [np.nan] * nb), float)
    bar = np.asarray(s.get("ddF_bar", s.get("ddF_hotunified", [np.nan] * nb)), float)
    s["_label"] = d.name
    s["_n_basins"] = nb
    s["_ref"] = ref
    s["_ais"] = ais
    s["_bar"] = bar
    s["_covered"] = covered
    s["_rmse_ais"] = _rmse(ais, ref, covered)
    s["_rmse_bar"] = s.get("rmse_bar_covered", _rmse(bar, ref, covered))
    s["_rmse_bar_ci"] = s.get("rmse_bar_covered_ci")
    return s


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--runs", nargs="*", default=None, help="explicit run dirs")
    ap.add_argument("--glob", default=None, help="glob for run dirs (each holding validation_summary.json)")
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    dirs = []
    if args.runs:
        dirs += [Path(r) for r in args.runs]
    if args.glob:
        dirs += [Path(p) for p in sorted(globlib.glob(args.glob))]
    dirs = [d for d in dirs if d.is_dir()]
    summaries = [s for s in (load_summary(d) for d in dirs) if s is not None]
    if not summaries:
        print("No validation_summary.json found in the given run dirs."); sys.exit(1)

    out_dir = Path(args.out_dir) if args.out_dir else ROOT / "results" / args.name / "diagnostics"
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── table ──
    def fmt_ci(ci):
        return f"[{ci[0]:.3f},{ci[1]:.3f}]" if ci else "—"
    print(f"\n  3-method diagnostic summary ({args.name})  —  RMSE vs REMD over covered basins (kT)\n")
    hdr = f"  {'run':<22} {'k':>5} {'switch':>6} {'fwd/rev':>8} {'RMSE_AIS':>9} {'RMSE_BAR':>9} {'BAR 95% CI':>16} {'min_ovl':>8}"
    print(hdr); print("  " + "-" * (len(hdr) - 2))
    rows = []
    for s in summaries:
        ovl = np.asarray(s.get("overlap", []), float)
        min_ovl = float(np.nanmin(ovl)) if ovl.size else float("nan")
        fr = f"{s.get('forward_source','?')[:1]}/{s.get('reverse_source','?')[:1]}".upper()
        print(f"  {s['_label']:<22} {s.get('k','?'):>5} {s.get('switch_ps','?'):>6} {fr:>8} "
              f"{s['_rmse_ais']:>9.3f} {s['_rmse_bar']:>9.3f} {fmt_ci(s['_rmse_bar_ci']):>16} {min_ovl:>8.3f}")
        rows.append(dict(run=s["_label"], k=s.get("k"), switch_ps=s.get("switch_ps"),
                         forward=s.get("forward_source"), reverse=s.get("reverse_source"),
                         rmse_ais=s["_rmse_ais"], rmse_bar=s["_rmse_bar"],
                         rmse_bar_ci_lo=(s["_rmse_bar_ci"] or [None, None])[0],
                         rmse_bar_ci_hi=(s["_rmse_bar_ci"] or [None, None])[1],
                         min_overlap=min_ovl))

    # CSV
    import csv
    with open(out_dir / "diagnostics_table.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

    # ── 2x2 swap attribution ──
    by_cell = {s.get("cell"): s for s in summaries if s.get("cell") in ("RR", "SS", "RS", "SR")}
    if {"RR", "SS", "RS", "SR"} <= set(by_cell):
        e = {c: by_cell[c]["_rmse_bar"] for c in ("RR", "SS", "RS", "SR")}
        print(f"\n  === 2x2 seed-source swap (BAR RMSE vs REMD, kT) ===")
        print(f"    RR (remd/remd) = {e['RR']:.3f}   [estimator floor]")
        print(f"    SS (sw/sw)     = {e['SS']:.3f}   [full single-walker]")
        print(f"    RS (remd/sw)   = {e['RS']:.3f}   [SW cold reservoir only]")
        print(f"    SR (sw/remd)   = {e['SR']:.3f}   [SW hot only]")
        cold_effect = e["RS"] - e["RR"]
        hot_effect = e["SR"] - e["RR"]
        print(f"\n    cold-reservoir effect (RS-RR) = {cold_effect:+.3f} kT")
        print(f"    hot-ensemble  effect (SR-RR) = {hot_effect:+.3f} kT")
        if cold_effect > 2 * max(hot_effect, 0.0) and hot_effect < cold_effect:
            print("    => VERDICT: error dominated by the COLD RESERVOIR (hyp. 4); hot + estimator cleared.")
        elif hot_effect > 2 * max(cold_effect, 0.0):
            print("    => VERDICT: error dominated by the HOT ensemble (hyp. 1).")
        else:
            print("    => VERDICT: error split between hot and cold (inspect per-basin).")

    # ── plots ──
    # (a) RMSE per run, BAR with CI + AIS point
    fig, ax = plt.subplots(figsize=(max(6, 1.1 * len(summaries)), 4))
    x = np.arange(len(summaries))
    bar = np.array([s["_rmse_bar"] for s in summaries])
    ais = np.array([s["_rmse_ais"] for s in summaries])
    yerr = np.array([[max(0, s["_rmse_bar"] - (s["_rmse_bar_ci"][0] if s["_rmse_bar_ci"] else s["_rmse_bar"])),
                      max(0, (s["_rmse_bar_ci"][1] if s["_rmse_bar_ci"] else s["_rmse_bar"]) - s["_rmse_bar"])]
                     for s in summaries]).T
    ax.bar(x - 0.2, ais, width=0.4, label="AIS + cold MD", color="tab:gray")
    ax.bar(x + 0.2, bar, width=0.4, yerr=yerr, capsize=3, label="BAR + cold MD", color="tab:blue")
    ax.set_xticks(x); ax.set_xticklabels([s["_label"] for s in summaries], rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("RMSE vs REMD (kT)"); ax.set_title(f"{args.name}: AIS vs BAR (covered basins)")
    ax.legend(); fig.tight_layout(); fig.savefig(out_dir / "fig_rmse_by_run.png", dpi=130)

    # (b) per-basin ddF for each run: REMD vs AIS vs BAR
    n = len(summaries)
    fig2, axes = plt.subplots(1, n, figsize=(3.2 * n, 3.4), squeeze=False)
    for i, s in enumerate(summaries):
        nb = s["_n_basins"]; xb = np.arange(nb)
        a = axes[0][i]
        a.bar(xb - 0.25, s["_ref"], width=0.25, label="REMD", color="black")
        a.bar(xb, s["_ais"], width=0.25, label="AIS+coldMD", color="tab:gray")
        a.bar(xb + 0.25, s["_bar"], width=0.25, label="BAR+coldMD", color="tab:blue")
        a.set_title(s["_label"], fontsize=9); a.set_xlabel("basin")
        if i == 0:
            a.set_ylabel("ddF (kT)"); a.legend(fontsize=7)
    fig2.tight_layout(); fig2.savefig(out_dir / "fig_perbasin_ddF.png", dpi=130)

    disp = out_dir.relative_to(ROOT) if out_dir.resolve().is_relative_to(ROOT) else out_dir
    print(f"\n  -> {disp}/ (diagnostics_table.csv, fig_rmse_by_run.png, fig_perbasin_ddF.png)")


if __name__ == "__main__":
    main()
