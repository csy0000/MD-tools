#!/usr/bin/env python
"""Build a TORSION-seeded cold-MD reservoir for cyclo-(RGDfV), reusing the existing forward-AIS landings.

Controlled comparison to the RMSD-seeded reservoir (data/rgd/2026-06-29-reservoir-sw-s0p25): the ONLY change
is the seed-selection metric. Same 1000 forward-AIS landings + weights, same top-100-by-weight pool, same
cold-MD length/system — but seeds are chosen by farthest-point sampling in sin/cos torsion space
(`farthest_point_torsion`) instead of macrocycle-ring Cartesian RMSD (`farthest_point_rmsd`). No hot MD or
forward AIS is rerun; we read the saved landings and only run new cold MD.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.build_torsion_seeded_reservoir \
        --cold-device 2
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path
import numpy as np, pandas as pd, mdtraj as md

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets, featurize, BasinModel
from escort_ais.systems.build_macrocycle_cold_reservoir import farthest_point_torsion, build_cold_system, run_cold_seed

# the RMSD-seeded reservoir supplies the forward-AIS landings we re-seed from
SRC = ROOT / "data/rgd/2026-06-29-reservoir-sw-s0p25/step_forward_ais"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--src-forward", default=str(SRC), help="dir with ais_final_coordinates.dcd + summary")
    ap.add_argument("--out-dir", default="data/rgd/2026-07-06-reservoir-torsion-s0p25")
    ap.add_argument("--n-top", type=int, default=100, help="highest-weight landing pool (mirror RMSD build)")
    ap.add_argument("--n-seeds", type=int, default=20)
    ap.add_argument("--cold-ns", type=float, default=10.0)
    ap.add_argument("--cold-device", type=int, default=2)
    ap.add_argument("--platform", default="OpenCL")
    args = ap.parse_args()

    cfg = load_cfg(args.name)
    quartets, _om, _ring = load_quartets(cfg.topo, "backbone")
    src = Path(args.src_forward)
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)

    # (1) load the saved forward-AIS landings + weights (no rerun)
    logw = pd.read_csv(src / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    fep = md.load_dcd(str(src / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    print(f"(1) reusing {len(logw)} forward-AIS landings from {src}", flush=True)

    # (2) top-N by weight -> n_seeds most distinct by TORSIONAL FPS (sin/cos), seed0 = top weight
    n_top = min(args.n_top, len(logw))
    top = np.argsort(logw)[-n_top:]
    top_traj = fep[top]
    fps = farthest_point_torsion(top_traj, quartets, min(args.n_seeds, n_top),
                                 seed0=int(np.argmax(logw[top])))
    seed_idx = top[fps]
    sdir = out / "cold_seeds"; sdir.mkdir(exist_ok=True)
    for j, gi in enumerate(seed_idx):
        fep[int(gi)].save_pdb(str(sdir / f"seed_{j:03d}.pdb"))
    print(f"(2) selected {len(seed_idx)} cold seeds from top-{n_top} weights (TORSION-FPS, sin/cos)",
          flush=True)
    print(f"    seed landing indices: {seed_idx.tolist()}", flush=True)

    # sanity: how do the seeds split across the frozen dih#14 major/minor partition?
    try:
        model = BasinModel.load(cfg.topo.parent / "basins_tica" / "basin_model_backbone.pkl")
        seed_basins = model.assign(fep[[int(g) for g in seed_idx]])
        print(f"    seed basins (frozen dih#14): {seed_basins.tolist()} "
              f"(minor={int((seed_basins==1).sum())}/{len(seed_basins)})", flush=True)
    except Exception as e:
        print(f"    (basin sanity skipped: {e})", flush=True)

    # (3) 20 x cold-ns cold MD on the free GPU
    cold_dir = out / "cold_md_10ns"; cold_dir.mkdir(exist_ok=True)
    print(f"(3) {len(seed_idx)} x {args.cold_ns} ns cold MD (s=1.0, GBn2/mbondi3) on device "
          f"{args.cold_device} ...", flush=True)
    st, system = build_cold_system(cfg)
    for j, gi in enumerate(seed_idx):
        run_cold_seed(j, fep.xyz[int(gi)], st, system, cold_dir, args.cold_ns * 1000.0,
                      args.platform, args.cold_device)
    print(f"DONE: torsion-seeded reservoir -> {cold_dir} ({len(seed_idx)} seeds x {args.cold_ns} ns)",
          flush=True)


if __name__ == "__main__":
    main()
