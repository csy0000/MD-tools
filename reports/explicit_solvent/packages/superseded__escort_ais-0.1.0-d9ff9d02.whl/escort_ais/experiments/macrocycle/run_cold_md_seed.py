#!/usr/bin/env python3
"""run_cold_md_seed.py — one cold-MD seed (s=1.0, GBn2/mbondi3) from a structure, as a standalone process.

Thin CLI around the cold-system build + single-seed MD in run_cyclosporin_cold_md.py, so the 20 cold-MD
reservoir simulations can be fanned out across processes (each its own CUDA context). Writes
<out-dir>/seed_<sid>/{trajectory.dcd, state.csv, final_structure.pdb}.

Usage:  python -m escort_ais.experiments.macrocycle.run_cold_md_seed --seed-pdb s.pdb --out-dir <dir> --sid 0 --prod-ps 1000
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from openmm.app import PDBFile

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.systems.run_cyclosporin_cold_md import build_cold_system, run_seed  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--seed-pdb", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--sid", type=int, required=True)
    ap.add_argument("--prod-ps", type=float, default=1000.0)
    ap.add_argument("--platform", default="CUDA")
    args = ap.parse_args()
    xyz = np.array(PDBFile(args.seed_pdb).getPositions().value_in_unit(__import__("openmm").unit.nanometer))
    st, system = build_cold_system()
    run_seed(args.sid, xyz, st, system, Path(args.out_dir), args.prod_ps, args.platform)


if __name__ == "__main__":
    main()
