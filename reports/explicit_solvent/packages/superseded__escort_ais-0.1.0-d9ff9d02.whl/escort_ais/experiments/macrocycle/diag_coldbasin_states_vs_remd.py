import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
Xs=[featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds]; Xall=np.concatenate(Xs)
gt=np.concatenate([fz.assign(md.load_dcd(s,top=top)[50:]) for s in seeds])
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
Xr=featurize(remd,q)
K=24
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(K,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
cs=km.predict(sc.transform(pca.transform(Xall))); rs=km.predict(sc.transform(pca.transform(Xr)))
minorf=np.array([gt[cs==k].mean() for k in range(K)])
cp=np.bincount(cs,minlength=K)/len(cs); rp=np.bincount(rs,minlength=K)/len(rs)
print(f"cold minor frac {gt.mean():.3f} vs REMD minor frac {fz.assign(remd).mean():.3f}",flush=True)
print(f"\n{'state':>5} {'cold%':>7} {'REMD%':>7} {'minor?':>6}  {'verdict':>18}",flush=True)
art=gap=real=0
for k in np.argsort(-cp):
    v = 'REAL' if (rp[k]>0.005 and cp[k]>0.005) else ('COLD ARTIFACT (~0 in REMD)' if cp[k]>0.01 and rp[k]<0.005 else 'tiny')
    if rp[k]>0.005 and cp[k]>0.005: real+=1
    elif cp[k]>0.01 and rp[k]<0.005: art+=1
    print(f"{k:5d} {100*cp[k]:7.2f} {100*rp[k]:7.2f} {'min' if minorf[k]>.5 else 'maj':>6}  {v:>26}",flush=True)
# REMD states missed by cold
gapstates=[k for k in range(K) if rp[k]>0.01 and cp[k]<0.005]
print(f"\nsummary: {real} states real (in both), {art} cold-only artifacts (~0 in REMD), "
      f"{len(gapstates)} REMD states poorly covered by cold {gapstates}",flush=True)
print(f"population correlation cold vs REMD (Pearson): {np.corrcoef(cp,rp)[0,1]:.2f}",flush=True)
# figure
fig,ax=plt.subplots(figsize=(6.5,6))
ax.plot([1e-4,1],[1e-4,1],'k--',lw=.8)
ax.scatter(cp+1e-4,rp+1e-4,s=40+cp*3000,c=minorf,cmap='coolwarm',vmin=0,vmax=1,edgecolor='k',lw=.5)
for k in range(K): ax.text(cp[k]+1e-4,rp[k]+1e-4,str(k),fontsize=7,ha='center',va='center')
ax.set(xscale='log',yscale='log',xlim=(8e-4,0.3),ylim=(8e-4,0.3),
       xlabel='cold-reservoir population',ylabel='REMD population',
       title='Are the 24 cold states real?\n(on diagonal=consistent; below=cold artifact; above=cold under-sampled)')
fig.colorbar(ax.collections[0],label='minor fraction',shrink=.8); fig.tight_layout()
p='results/rgd/report/fig_states_vs_remd.png'; fig.savefig(p,dpi=140); print('saved',p,flush=True)
