#!/usr/bin/env python3
"""analyze_seed_coverage.py — how many cold-MD seeds, which basin they cover, and when.

For each compound's bAIS reservoir (data/rgd/diagnostics/bais_eval/<name>/cold_md/seed_*), classify every
cold-MD seed by where it spends its run:
  - real-MAJOR / real-MINOR  (majority of frames on that side of the state-defining torsion, AND its dominant
                              microstate is REMD-populated),
  - ARTIFACT trap            (dominant microstate has REMD population < 0.5% -- a kinetically-isolated well).
Since cold MD at s=1 never crosses the major<->minor barrier, a seed's basin == where it is trapped, so
"initiated in" and "trapped in" are the same label.

Reports:
  (Q1) total cold-MD seeds initiated.
  (Q3) how many seeds sit in each basin (major / minor / artifact).
  (Q2) coverage vs generation: cumulative major/minor/artifact seed counts as generations are added
       (seed j is added at the generation where n_cold_seeds first exceeds j), and the generation at which
       the minor state is first covered and reaches >=3 / >=5 seeds.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_seed_coverage
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide", "rgd_redPheVal": "rgd_redPheVal"}
ART = 0.005


def in_window(deg, lo, hi):
    return (deg >= lo) & (deg <= hi) if lo <= hi else (deg >= lo) | (deg <= hi)


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.basin_model_path)
    qi, lo, hi = model.rules[0]; qi = int(qi)

    seed_files = sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))
    seedX, seed_tor = [], []
    for s in seed_files:
        t = md.load_dcd(s, top=top)[50:]
        seedX.append(featurize(t, q)); seed_tor.append(np.degrees(md.compute_dihedrals(t, q))[:, qi])

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remdX = featurize(remd, q)

    # union clustering to get per-microstate REMD population (for the artifact test)
    K = 30
    U = np.concatenate([np.concatenate(seedX), remdX])
    pca = PCA(8, random_state=0).fit(U)
    scal = StandardScaler().fit(pca.transform(U))
    km = KMeans(K, n_init=6, random_state=0).fit(scal.transform(pca.transform(U)))
    proj = lambda X: km.predict(scal.transform(pca.transform(X)))
    remd_micro_pop = np.bincount(proj(remdX), minlength=K) / len(remdX)

    # ROBUST classification: defining-torsion basin (clustering-free, matches the state definition)
    labels = np.array(["minor" if in_window(tor, lo, hi).mean() > 0.5 else "major" for tor in seed_tor])
    # secondary (caveated, clustering-sensitive): dominant microstate REMD-sparse -> in a REMD~0 region
    remd_sparse = np.array([remd_micro_pop[np.bincount(proj(X), minlength=K).argmax()] < ART for X in seedX])

    # seed -> generation from the ledger's cumulative n_cold_seeds
    ledger = json.load(open(BE / name / "generations.json"))["generations"]
    cum = [int(e["n_cold_seeds"]) for e in ledger]
    seed_gen = np.empty(len(seed_files), int); prev = 0
    for g, c in enumerate(cum):
        seed_gen[prev:c] = g; prev = c

    n = len(labels)
    nmaj = int((labels == "major").sum()); nmin = int((labels == "minor").sum())
    nsparse = int(remd_sparse.sum())
    minor_gens = np.sort(seed_gen[labels == "minor"])
    first_minor = int(minor_gens[0]) if minor_gens.size else None
    hot_ns = lambda g: ledger[g]["hot_ns"]

    def gen_reaching(k):
        return int(minor_gens[k - 1]) if minor_gens.size >= k else None

    print(f"\n===== {NICE[name]} =====")
    print(f"  (Q1) cold-MD seeds initiated: {n}")
    print(f"  (Q3) basin of each seed by defining torsion (initiated == trapped, no s=1 crossing):")
    print(f"       MAJOR : {nmaj:3d} ({100*nmaj/n:.0f}%)")
    print(f"       MINOR : {nmin:3d} ({100*nmin/n:.0f}%)")
    print(f"       [caveat] seeds whose dominant K=30 microstate is REMD-sparse (<0.5%): {nsparse} "
          f"({100*nsparse/n:.0f}%) -- BROAD, clustering-sensitive; genuine kinetic traps ~16-22% (SCC def)")
    print(f"  (Q2) minor-state coverage: first minor seed at gen {first_minor} "
          f"(hot {hot_ns(first_minor):.0f} ns)" if first_minor is not None else "  (Q2) NO minor seed ever")
    if minor_gens.size:
        for k in (1, 3, 5):
            g = gen_reaching(k)
            if g is not None:
                print(f"       >= {k} minor seed(s) by gen {g:2d} (hot {hot_ns(g):.0f} ns)")
    # cumulative coverage table at milestone generations (by defining-torsion basin)
    miles = sorted(set([0, 1, 2, 5, 10, 20, len(ledger) - 1]))
    print(f"       gen | hot_ns | seeds | major minor  (REMD-sparse)")
    for g in miles:
        m = seed_gen <= g
        print(f"       {g:3d} | {hot_ns(g):6.0f} | {int(m.sum()):5d} | "
              f"{int((labels[m]=='major').sum()):5d} {int((labels[m]=='minor').sum()):5d} "
              f"{int(remd_sparse[m].sum()):13d}")


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
