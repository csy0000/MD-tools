import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob, pandas as pd
import mdtraj as md
from scipy.special import logsumexp
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
FWD='data/rgd/2026-06-29-reservoir-sw-s0p25/step_forward_ais'
# forward-AIS landings that seeded the reservoir
fdf=pd.read_csv(f'{FWD}/ais_trajectory_summary.csv'); logw=fdf['final_logw'].to_numpy()
land=md.load_dcd(f'{FWD}/ais_final_coordinates.dcd',top=top)
b=fz.assign(land)                       # major/minor per landing
# reservoir + REMD for reference
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
Xs=[featurize(md.load_dcd(s,top=top)[50:],q) for s in seeds]; Xall=np.concatenate(Xs)
res_gt=np.concatenate([fz.assign(md.load_dcd(s,top=top)[50:]) for s in seeds])
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
def wfrac(logw,mask):  # importance-weight fraction in-group via logsumexp
    return np.exp(logsumexp(logw[mask])-logsumexp(logw))
print("=== (a) overall major/minor landing ratio (forward AIS, 1000 landings) ===",flush=True)
cnt=np.bincount(b,minlength=2)
print(f"  by COUNT : major {cnt[0]} / minor {cnt[1]}  -> minor frac {cnt[1]/cnt.sum():.3f}",flush=True)
print(f"  by WEIGHT: minor weight frac {wfrac(logw,b==1):.3f}  (importance-reweighted / Jarzynski)",flush=True)
print(f"  reference: reservoir minor {res_gt.mean():.3f}  |  REMD minor {fz.assign(remd).mean():.3f}",flush=True)
print(f"  logw range [{logw.min():.0f},{logw.max():.0f}]  mean {logw.mean():.0f}",flush=True)
# (b) per-microstate landing count & weight
K=24
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(K,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
micro=km.predict(sc.transform(pca.transform(featurize(land,q))))
res_micro=km.predict(sc.transform(pca.transform(Xall)))
minorf=np.array([res_gt[res_micro==k].mean() for k in range(K)])
cntf=np.bincount(micro,minlength=K)/len(micro)
resf=np.bincount(res_micro,minlength=K)/len(res_micro)
wf=np.array([wfrac(logw,micro==k) for k in range(K)])
print("\n=== (b) per-microstate: forward-landing COUNT vs WEIGHT vs reservoir pop ===",flush=True)
print(f"{'state':>5} {'land%':>7} {'landW%':>7} {'res%':>7} {'minor?':>6}",flush=True)
for k in np.argsort(-cntf):
    print(f"{k:5d} {100*cntf[k]:7.2f} {100*wf[k]:7.2f} {100*resf[k]:7.2f} {'min' if minorf[k]>.5 else 'maj':>6}",flush=True)
