"""run_basin_cold_local.py — Stage 5: run K cold local MD walkers at s=1.0.

Reads resampled_cold_starts.npy from stage-04 output (equal-weight cold start
positions), runs K independent MD walkers at scale_factor=1.0, and writes
per-walker DCDs + walker_index.npy / frame_index.npy for TICA/MSM.

Usage:
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_basin_cold_local \\
        --ais-resample-dir data/.../04_ais_resampled \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/.../05_cold_local \\
        --duration-ns 2.0 --temperature-k 300.0 \\
        --platform OpenCL --traj-interval-ps 10.0 [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np



def main() -> None:
    parser = argparse.ArgumentParser(description="Run K cold local MD walkers at s=1.0.")
    parser.add_argument("--ais-resample-dir", required=True, type=Path,
                        help="Stage-04 resample dir containing resampled_cold_starts.npy.")
    parser.add_argument("--topology-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--scale-factor", type=float, default=1.0,
                        help="REST2 scale factor (1.0 = physical cold).")
    parser.add_argument("--duration-ns", type=float, default=2.0)
    parser.add_argument("--temperature-k", type=float, default=300.0)
    parser.add_argument("--timestep-fs", type=float, default=2.0)
    parser.add_argument("--friction-per-ps", type=float, default=1.0)
    parser.add_argument("--traj-interval-ps", type=float, default=10.0)
    parser.add_argument("--platform", default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-walkers", type=int, default=None,
                        help="Limit to first N walkers (for testing).")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    from escort_ais.common.paths import ensure_dir
    from escort_ais.methods.md_run import steps_from_time
    from escort_ais.methods.multi_walker_md import run_independent_walkers

    resample_dir = Path(args.ais_resample_dir)
    output_dir = ensure_dir(args.output_dir)

    cold_starts_path = resample_dir / "resampled_cold_starts.npy"
    if cold_starts_path.exists():
        cold_starts = np.load(cold_starts_path)
    elif args.dry_run:
        cold_starts = np.zeros((args.n_walkers or 10, 22, 3))
        print("  resampled_cold_starts.npy not found (dry_run -- using dummy positions).")
    else:
        raise FileNotFoundError(f"resampled_cold_starts.npy not found in {resample_dir}")
    if args.n_walkers is not None:
        cold_starts = cold_starts[: args.n_walkers]
    K = cold_starts.shape[0]

    duration_steps = steps_from_time(args.duration_ns * 1000.0, args.timestep_fs)
    traj_interval_steps = max(1, steps_from_time(args.traj_interval_ps, args.timestep_fs))

    print(f"Running {K} cold local walkers at s={args.scale_factor:.3f} ...")
    print(f"  duration: {args.duration_ns} ns  ({duration_steps} steps)")
    print(f"  traj_interval: {args.traj_interval_ps} ps ({traj_interval_steps} steps)")

    summary = run_independent_walkers(
        args.topology_dir,
        seed_positions_nm=cold_starts,
        scale_factor=args.scale_factor,
        duration_steps=duration_steps,
        temperature_k=args.temperature_k,
        timestep_fs=args.timestep_fs,
        friction_per_ps=args.friction_per_ps,
        traj_interval_steps=traj_interval_steps,
        platform=args.platform,
        seed=args.seed,
        output_dir=output_dir,
        dry_run=args.dry_run,
    )

    print(f"\nDone. {summary['n_walkers']} walkers, "
          f"{summary.get('total_frames', 0)} total frames.")
    print(f"  Output: {output_dir}")


if __name__ == "__main__":
    main()
