#!/usr/bin/env python3
"""make_rite_residence_fig.py — figure for the residence-gated LEQ result (from rite_residence_gated.json).

Per compound x basin: within-basin JS to REMD(.|B) vs the sub-well-residence threshold T, for
  keep MIXING seeds (residence <= T, simple average)  — reaches the floor,
  keep FROZEN seeds (residence >  T, simple average)  — climbs to the ln2 ceiling,
and the RITE-PC1 overlay on the mixing set (shows RITE adds ~nothing). Floor / ln2 reference lines.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.make_rite_residence_fig
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
BE = ROOT / "data/rgd/diagnostics/bais_eval"
OUT = ROOT / "results/rgd/report"
NAMES = ["rgd", "cilengitide", "rgd_redPheVal"]
LN2 = float(np.log(2))


def main():
    data = {n: json.loads((BE / n / "rite_residence_gated.json").read_text()) for n in NAMES}
    ncol = max(len(d["basins"]) for d in data.values())
    fig, axes = plt.subplots(len(NAMES), ncol, figsize=(4.4 * ncol, 3.6 * len(NAMES)), squeeze=False)
    for r, n in enumerate(NAMES):
        basins = data[n]["basins"]
        for c in range(ncol):
            ax = axes[r][c]
            if c >= len(basins):
                ax.axis("off"); continue
            b = basins[c]; T = [s["T"] for s in b["sweep"]]
            mix_u = [s["keep_le"]["js_unweighted"] if s["keep_le"] else np.nan for s in b["sweep"]]
            mix_r = [s["keep_le"]["js_rite_pc1"] if s["keep_le"] else np.nan for s in b["sweep"]]
            frz_u = [s["keep_gt"]["js_unweighted"] if s["keep_gt"] else np.nan for s in b["sweep"]]
            ax.plot(T, mix_u, "-o", color="C2", lw=2.2, label="keep mixing (res≤T), avg")
            ax.plot(T, mix_r, ":o", color="C0", lw=1.6, ms=4, label="keep mixing, RITE-PC1")
            ax.plot(T, frz_u, "--s", color="C3", lw=1.8, label="keep frozen (res>T), avg")
            ax.axhline(0.05, ls=":", c="green", lw=1, alpha=0.7)
            ax.axhline(LN2, ls="--", c="k", lw=1, alpha=0.5)
            rc = b["remd_control"]
            ax.set_title(f"{n} S{b['state']} (pop {b['p_remd']:.2f})\n"
                         f"RITE-on-REMD ctrl: JS={rc['js_rite_vs_self']:.3f} ESS={rc['ess']} (no-op)",
                         fontsize=8.5)
            ax.set_xlabel("residence threshold T (ns)"); ax.set_ylabel("JS to REMD(.|B)")
            ax.set_ylim(0, LN2 * 1.05)
            if r == 0 and c == 0:
                ax.legend(fontsize=7, loc="center right")
    fig.suptitle("Residence-gated within-basin LEQ: keeping internally-MIXING seeds (res≤T) reaches the floor "
                 "by simple averaging; RITE-PC1 adds nothing", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.98]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_rite_residence_gated.png", dpi=140); plt.close(fig)
    print(f"wrote {OUT / 'fig_rite_residence_gated.png'}", file=sys.stderr)


if __name__ == "__main__":
    main()
