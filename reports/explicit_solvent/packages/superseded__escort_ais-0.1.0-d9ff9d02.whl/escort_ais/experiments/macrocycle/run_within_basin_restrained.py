#!/usr/bin/env python3
"""run_within_basin_restrained.py — one within-basin restrained MD seed (physical s=1.0 + flat-bottom torsion wall).

Identical physical cold system to run_macrocycle_cold_md_seed.py, plus a flat-bottom restraint on the basin's
defining torsion that confines the run to one basin's dihedral window. Zero force inside the window, so the
interior distribution is the physical P_eq(x|B); the wall only stops escape to the neighbouring basin. Used to
build a within-basin equilibrium REFERENCE for testing whether the cold reservoir is locally equilibrated.

Writes <out-dir>/seed_<sid>/{trajectory.dcd, state.csv, final_structure.pdb}.

    python -m escort_ais.experiments.macrocycle.run_within_basin_restrained --name rgd --basin major \
        --seed-pdb seed.pdb --out-dir <dir> --sid 0 --prod-ps 10000 --k 500 --platform CUDA --device 0
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from openmm import unit
from openmm.app import PDBFile

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.build_macrocycle_cold_reservoir import build_cold_system, run_cold_seed  # noqa: E402
from escort_ais.methods.basin_restraint import flatbottom_torsion_force, basin_window  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True)
    ap.add_argument("--side", default="complement", choices=["in_window", "complement"],
                    help="which side of the defining-torsion rule to confine to (rgd major = complement)")
    ap.add_argument("--seed-pdb", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--sid", type=int, required=True)
    ap.add_argument("--prod-ps", type=float, default=10000.0)               # 10 ns default
    ap.add_argument("--save-ps", type=float, default=1.0)
    ap.add_argument("--k", type=float, default=500.0, help="flat-bottom force constant (kJ/mol/rad^2)")
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device", type=int, default=0)
    args = ap.parse_args()

    cfg = load_cfg(args.name)
    win = basin_window(cfg, args.side)
    xyz = np.array(PDBFile(args.seed_pdb).getPositions().value_in_unit(unit.nanometer))
    st, system = build_cold_system(cfg)
    system.addForce(flatbottom_torsion_force(win["quartet"], win["center_rad"], win["halfwidth_rad"], args.k))
    print(f"  restraint: {args.side} torsion #{win['qi']} atoms {win['quartet'].tolist()} "
          f"center={np.degrees(win['center_rad']):.0f} halfwidth={np.degrees(win['halfwidth_rad']):.0f} deg  "
          f"k={args.k}", flush=True)
    run_cold_seed(args.sid, xyz, st, system, Path(args.out_dir), args.prod_ps,
                  args.platform, args.device, save_ps=args.save_ps)


if __name__ == "__main__":
    main()
