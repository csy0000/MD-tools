import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
cold=np.concatenate([np.degrees(md.compute_dihedrals(md.load_dcd(s,top=top)[50:],q)) for s in seeds])
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
remdd=np.degrees(md.compute_dihedrals(remd,q))
nq=q.shape[0]; bins=np.linspace(-180,180,73)
def js(a,b):
    ha,_=np.histogram(a,bins,density=True); hb,_=np.histogram(b,bins,density=True)
    ha=ha/ha.sum()+1e-12; hb=hb/hb.sum()+1e-12; m=.5*(ha+hb)
    return .5*np.sum(ha*np.log(ha/m))+.5*np.sum(hb*np.log(hb/m))
jsd=np.array([js(cold[:,j],remdd[:,j]) for j in range(nq)])
tags={2:'dih2/tor2',6:'tor6',8:'tor8',12:'dih12',14:'dih14(sep)'}
fig,axes=plt.subplots(3,5,figsize=(15,8))
for j,ax in zip(np.argsort(-jsd),axes.flat):
    ax.hist(cold[:,j],bins,density=True,alpha=.55,color='#4477AA',label='cold-MD')
    ax.hist(remdd[:,j],bins,density=True,histtype='step',lw=1.8,color='#CC3311',label='REMD')
    ax.set_title(f"torsion {j} {tags.get(j,'')}\nJS div = {jsd[j]:.3f}",fontsize=9)
    ax.set_xlim(-180,180); ax.set_yticks([])
    if j==np.argsort(-jsd)[0]: ax.legend(fontsize=8)
fig.suptitle('Cold-MD vs REMD backbone-torsion distributions (sorted by divergence; JS high = cold != equilibrium)',fontsize=13,y=1.01)
fig.tight_layout()
p='results/rgd/report/fig_cold_vs_remd_torsions.png'; fig.savefig(p,dpi=140,bbox_inches='tight'); print('saved',p)
print("per-torsion JS divergence (cold vs REMD), sorted:")
for j in np.argsort(-jsd): print(f"  torsion {j:2d} {tags.get(j,''):>11}: {jsd[j]:.3f}")
