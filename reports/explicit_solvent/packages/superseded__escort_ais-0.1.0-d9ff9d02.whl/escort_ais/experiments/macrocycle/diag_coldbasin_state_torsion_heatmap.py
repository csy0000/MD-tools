import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
trs=[md.load_dcd(s,top=top)[50:] for s in seeds]
Xs=[featurize(t,q) for t in trs]; Xall=np.concatenate(Xs)
gt=np.concatenate([fz.assign(t) for t in trs])
DIH=np.concatenate([np.degrees(md.compute_dihedrals(t,q)) for t in trs])  # (N,15)
nq=DIH.shape[1]
K=24
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(K,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
full=np.concatenate([km.predict(sc.transform(pca.transform(X))).astype(int) for X in Xs])
pop=np.bincount(full,minlength=K).astype(float); pop/=pop.sum()
minorf=np.array([gt[full==k].mean() for k in range(K)])
def cmean(a): r=np.radians(a); return np.degrees(np.arctan2(np.sin(r).mean(),np.cos(r).mean()))
def cstd(a): r=np.radians(a); R=np.hypot(np.sin(r).mean(),np.cos(r).mean()); return np.degrees(np.sqrt(-2*np.log(max(R,1e-9))))
cen=np.array([[cmean(DIH[full==k,d]) for d in range(nq)] for k in range(K)])
spread=np.array([[cstd(DIH[full==k,d]) for d in range(nq)] for k in range(K)])
# spread of centroids across states per torsion (discriminative power)
disc=np.array([cstd(cen[:,d]) for d in range(nq)])
order=np.lexsort((-pop, minorf>0.5))   # major (minor=0) first, then by pop desc
fig,ax=plt.subplots(1,2,figsize=(13,8),gridspec_kw=dict(width_ratios=[1,7]))
# left: pop + minor
ax[0].barh(range(K),pop[order]*100,color=plt.cm.coolwarm(minorf[order]))
ax[0].set(yticks=range(K),xlabel='pop %'); ax[0].invert_yaxis()
ax[0].set_yticklabels([f"s{k} {'min' if minorf[k]>.5 else 'maj'}" for k in order],fontsize=7)
ax[0].axhline(np.sum(minorf[order]<.5)-0.5,color='k',lw=1)
# right: heatmap of mean angle
im=ax[1].imshow(cen[order],aspect='auto',cmap='twilight',vmin=-180,vmax=180)
ax[1].set(yticks=[],xticks=range(nq),xlabel='backbone torsion index')
tags={2:'dih2\ntor2 FAST',6:'tor6\nFAST',8:'tor8\nslow',12:'dih12',14:'dih14\nSLOW sep'}
ax[1].set_xticklabels([f"{d}\n{tags.get(d,'')}" for d in range(nq)],fontsize=7)
for d in range(nq):
    for i,k in enumerate(order):
        ax[1].text(d,i,f"{spread[k,d]:.0f}",ha='center',va='center',fontsize=4,color='white' if spread[k,d]<45 else 'black')
ax[1].axhline(np.sum(minorf[order]<.5)-0.5,color='lime',lw=2)
fig.colorbar(im,ax=ax[1],label='mean dihedral angle (deg)',shrink=.7)
ax[1].set_title('mean dihedral angle per microstate (color) + intra-state spread (number, deg)\n'
                'green line = major(top)/minor(bottom) split; discriminative torsions circled below')
# mark discriminative torsions
for d in range(nq):
    if disc[d]>50: ax[1].text(d,K-0.2,'★',ha='center',va='top',color='red',fontsize=12)
fig.suptitle('All 15 backbone torsions × 24 cold microstates  (★ = torsion that splits the microstates)',y=1.0,fontsize=13)
fig.tight_layout()
p='results/rgd/report/fig_state_torsion_heatmap.png'; fig.savefig(p,dpi=150,bbox_inches='tight'); print('saved',p)
print('discriminative (centroid spread>50deg) torsions:',[int(d) for d in range(nq) if disc[d]>50])
print('per-torsion centroid spread:',[f"{d}:{disc[d]:.0f}" for d in range(nq)])
