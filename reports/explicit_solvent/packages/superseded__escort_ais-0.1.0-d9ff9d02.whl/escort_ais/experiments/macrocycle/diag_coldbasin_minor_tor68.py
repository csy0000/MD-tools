import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from sklearn.decomposition import PCA; from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
trs=[md.load_dcd(s,top=top)[50:] for s in seeds]
Xs=[featurize(t,q) for t in trs]; Xall=np.concatenate(Xs)
gt=np.concatenate([fz.assign(t) for t in trs])
DIH=np.concatenate([np.degrees(md.compute_dihedrals(t,q)) for t in trs])  # (N,15)
def mdwell(d,D):
    out=d.copy(); cur=d[0]
    for i in range(1,len(d)):
        if d[i]!=cur and i+D<=len(d) and np.all(d[i:i+D]==d[i]): cur=d[i]
        out[i]=cur
    return out
K=24
pca=PCA(8,random_state=0).fit(Xall); sc=StandardScaler().fit(pca.transform(Xall))
km=KMeans(K,n_init=10,random_state=0).fit(sc.transform(pca.transform(Xall)))
dtr=[mdwell(km.predict(sc.transform(pca.transform(X))).astype(int),50) for X in Xs]
full=np.concatenate(dtr)
minorf=np.array([gt[full==k].mean() for k in range(K)])
minors=[k for k in range(K) if minorf[k]>0.5]
C=np.zeros((K,K),int)
for d in dtr:
    for a,b in zip(d[:-1],d[1:]):
        if a!=b: C[a,b]+=1
def cmean(a): r=np.radians(a); return np.degrees(np.arctan2(np.sin(r).mean(),np.cos(r).mean()))
cen={k:{d:cmean(DIH[full==k,d]) for d in [2,6,8,14]} for k in minors}
mask=np.isin(full,minors)
cmap=plt.cm.tab10; col={k:cmap(i%10) for i,k in enumerate(minors)}
fig,ax=plt.subplots(1,2,figsize=(13,5.5))
# panel A: overlap in (dih2, dih14)
sub=np.where(mask)[0]; sub=sub[::max(1,len(sub)//30000)]
for k in minors:
    m=full[sub]==k; ax[0].scatter(DIH[sub][m,2],DIH[sub][m,14],s=3,color=col[k],alpha=.25,lw=0)
for k in minors: ax[0].text(cen[k][2],cen[k][14],str(k),fontsize=9,weight='bold',ha='center',va='center')
ax[0].set(title='minor microstates in dih2 vs dih14\n(they OVERLAP here)',xlabel='dih2 (tor2)',ylabel='dih14',xlim=(-180,180),ylim=(-180,180))
# panel B: separate in (tor6, tor8) + crossing edges
for k in minors:
    m=full[sub]==k; ax[1].scatter(DIH[sub][m,6],DIH[sub][m,8],s=3,color=col[k],alpha=.25,lw=0)
for i in minors:
    for j in minors:
        if i<j and C[i,j]+C[j,i]>0:
            n=C[i,j]+C[j,i]
            ax[1].plot([cen[i][6],cen[j][6]],[cen[i][8],cen[j][8]],'-',color='k',lw=0.5+n*0.6,alpha=.7,zorder=2)
            ax[1].text((cen[i][6]+cen[j][6])/2,(cen[i][8]+cen[j][8])/2,str(n),fontsize=7,color='red',zorder=5)
for k in minors: ax[1].text(cen[k][6],cen[k][8],str(k),fontsize=9,weight='bold',ha='center',va='center',zorder=4)
ax[1].set(title='minor microstates in tor6 vs tor8\n(they SEPARATE here; edges=crossings)',
          xlabel='tor6  (FAST, ~0.18/ns)',ylabel='tor8  (SLOW, ~0.015/ns)',xlim=(-180,180),ylim=(-180,180))
fig.suptitle('Minor basin: co-located in dih2/dih14 but split by tor6 (fast) and tor8 (slow)',y=1.02)
fig.tight_layout()
p='results/rgd/report/fig_minor_tor6_tor8.png'; fig.savefig(p,dpi=140,bbox_inches='tight'); print('saved',p)
# report within-minor crossings decomposed tor6 vs tor8
d6=d8=0
for i in minors:
    for j in minors:
        if C[i,j]>0:
            a6=abs(((cen[i][6]-cen[j][6]+180)%360)-180); a8=abs(((cen[i][8]-cen[j][8]+180)%360)-180)
            (globals().__setitem__('d6',d6+C[i,j]) if a6>a8 else globals().__setitem__('d8',d8+C[i,j]))
            if a6>a8: d6+=C[i,j]
            else: d8+=C[i,j]
print(f"within-minor crossings mostly along tor6: {d6}, along tor8: {d8}")
