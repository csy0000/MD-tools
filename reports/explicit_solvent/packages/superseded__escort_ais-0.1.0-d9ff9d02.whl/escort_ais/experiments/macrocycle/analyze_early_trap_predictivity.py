#!/usr/bin/env python3
"""analyze_early_trap_predictivity.py — is the trapped-seed verdict decided EARLY? (Phase-A validation)

The adaptive-reservoir idea (docs/... adaptive trap-gated plan) is: after a SHORT cold-MD round (~5 ns), run
the REMD-free trap gate (KCC kinetic isolation  INTERSECT  forward-AIS weight ~ 0, i.e.
`artifact_quarantine.artifact_microstates`), STOP the trapped seeds, and extend only the survivors. That is
only safe if the short-round verdict matches what a much longer run would conclude. This script validates that
on EXISTING trajectories (no new MD), on two datasets:

  reservoir5  -- the 86 x 5 ns bAIS reservoir (data/.../bais_eval/<name>/cold_md); truncate to
                 tau in {0.2,0.5,1,2,5} ns, gate at each tau, compare to the tau=5 verdict (ground truth).
                 Rich trap set (~16-22%): tests how EARLY the verdict is decided.
  fps100      -- the 10 x 100 ns FPS runs (data/.../fps10_100ns_experiment/<name>/cold_md); truncate to
                 tau in {1,2,5,10,20,100} ns, compare to the tau=100 verdict. Clean seeds: tests that the
                 verdict is STABLE over a long horizon (survivors don't silently degrade).

Per-seed trapped verdict at tau: fit KMeans(100) microstates on the truncated pool, artifact set = KCC-
disconnected AND p_land < weight_frac; a seed is trapped if it spends > THETA of its (truncated) frames in
artifact microstates. Report, per shorter tau vs the ground-truth set: precision / recall / F1 / agreement
(fraction of seeds with the same boolean verdict), and the smallest tau at which the set is stable.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_early_trap_predictivity [name...]
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.common.artifact_quarantine import artifact_microstates  # noqa: E402
from sklearn.cluster import KMeans  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
FPS = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment"
OUT = ROOT / "results/rgd/report"
FPM = 1000                                  # frames per ns (cold MD 1 ps/frame)
BURN = 50
KMICRO, LAG, WEIGHT_FRAC, THETA = 100, 20, 1e-3, 0.5
FIT_CAP = 150000                            # subsample cap for the KMeans fit (speed; predict is full)
DATASETS = {
    "reservoir5": dict(taus=[0.2, 0.5, 1.0, 2.0, 5.0]),
    "fps100": dict(taus=[1.0, 2.0, 5.0, 10.0, 20.0, 100.0]),
}


def load_landings(name, q):
    fwd = BE / name / "gen0/fwd"
    cfg = load_cfg(name)
    land = md.load_dcd(str(fwd / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))  # dihedral scale-invariant
    logw = pd.read_csv(fwd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    return featurize(land, q), logw


def seed_feats(name, dataset, q):
    """Full featurized (post-burn) frames per seed, for the given dataset."""
    if dataset == "reservoir5":
        top = str(load_cfg(name).top_pdb)
        paths = sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))
        return [featurize(md.load_dcd(p, top=top)[BURN:], q) for p in paths], [Path(p).parent.name for p in paths]
    ds = sorted(d for d in glob.glob(str(FPS / name / "cold_md/seed_*"))
                if Path(d, "final_structure.pdb").exists())
    return ([featurize(md.load_dcd(str(Path(d) / "trajectory.dcd"),
                                   top=str(Path(d) / "final_structure.pdb"))[BURN:], q) for d in ds],
            [Path(d).name for d in ds])


def gate(seedX, land_feats, land_logw, rng):
    """Per-seed trapped verdict on a (possibly truncated) list of per-seed feature arrays."""
    Xall = np.concatenate(seedX)
    fitX = Xall[rng.choice(len(Xall), FIT_CAP, replace=False)] if len(Xall) > FIT_CAP else Xall
    km = KMeans(KMICRO, n_init=4, random_state=0).fit(fitX)
    dtrajs = [km.predict(x) for x in seedX]
    artifact, info = artifact_microstates(km, dtrajs, land_feats, land_logw, lag=LAG, weight_frac=WEIGHT_FRAC)
    art = np.fromiter(artifact, int) if artifact else np.empty(0, int)
    frac = np.array([float(np.isin(d, art).mean()) if art.size else 0.0 for d in dtrajs])
    return (frac > THETA), frac, dict(n_artifact=len(artifact), n_disconnected=len(info["disconnected"]),
                                      n_low_forward=len(info["low_forward"]))


def prf(pred, truth):
    pred = np.asarray(pred, bool); truth = np.asarray(truth, bool)
    tp = int((pred & truth).sum()); fp = int((pred & ~truth).sum()); fn = int((~pred & truth).sum())
    prec = tp / (tp + fp) if tp + fp else 1.0
    rec = tp / (tp + fn) if tp + fn else 1.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    agree = float((pred == truth).mean())
    return dict(precision=round(prec, 3), recall=round(rec, 3), f1=round(f1, 3),
                agreement=round(agree, 3), tp=tp, fp=fp, fn=fn)


def process(NAME):
    rng = np.random.default_rng(0)
    q, _, _ = load_quartets(load_cfg(NAME).topo, "backbone")
    land_feats, land_logw = load_landings(NAME, q)
    result = {"name": NAME, "kmicro": KMICRO, "lag": LAG, "weight_frac": WEIGHT_FRAC, "theta": THETA}
    print(f"\n===== {NAME} =====", file=sys.stderr)
    for dset, cfgd in DATASETS.items():
        seedX, sids = seed_feats(NAME, dset, q)
        nfull = min(len(x) for x in seedX)                          # all seeds same length here
        pairs, seen = [], set()                                     # (tau_label, n_frames), clamped + deduped
        for t in cfgd["taus"]:
            nf = min(int(t * FPM), nfull)
            if nf not in seen:
                seen.add(nf); pairs.append((t, nf))
        if nfull not in seen:                                       # ensure full length is the ground truth
            pairs.append((round(nfull / FPM, 2), nfull))
        taus = [t for t, _ in pairs]
        verdicts, fracs, meta = {}, {}, {}
        for t, nf in pairs:
            trapped, frac, m = gate([x[:nf] for x in seedX], land_feats, land_logw, rng)
            verdicts[t] = trapped; fracs[t] = frac; meta[t] = m
        gt_tau = taus[-1]; gt = verdicts[gt_tau]
        rows = []
        for t in taus:
            r = prf(verdicts[t], gt); r.update(tau_ns=t, n_trapped=int(verdicts[t].sum()), **meta[t])
            rows.append(r)
        gt_ntrap = int(gt.sum())
        # smallest tau whose verdict set exactly equals the ground-truth set
        stable = next((t for t in taus if np.array_equal(verdicts[t], gt)), gt_tau)
        result[dset] = dict(taus=taus, gt_tau=gt_tau, gt_n_trapped=gt_ntrap, n_seeds=len(seedX),
                            trapped_seeds_gt=[sids[i] for i in np.where(gt)[0]],
                            first_exact_tau=stable, per_tau=rows)
        print(f"  [{dset}] {len(seedX)} seeds | ground-truth trapped @ {gt_tau}ns = {gt_ntrap} "
              f"({[sids[i] for i in np.where(gt)[0]]}) | exact-match from tau >= {stable} ns", file=sys.stderr)
        for r in rows:
            print(f"     tau={r['tau_ns']:5.1f}ns  trapped={r['n_trapped']:2d}  "
                  f"recall={r['recall']:.2f} prec={r['precision']:.2f} agree={r['agreement']:.2f}  "
                  f"(artifact micro {r['n_artifact']}, disc {r['n_disconnected']}, low-fwd {r['n_low_forward']})",
                  file=sys.stderr)
    (FPS / NAME / "early_trap_predictivity.json").write_text(json.dumps(result, indent=2))
    return result


def make_figure(rows):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6))
    cols = {"rgd": "C0", "cilengitide": "C1", "rgd_redPheVal": "C3"}
    for ax, dset in zip(axes, ["reservoir5", "fps100"]):
        for r in rows:
            d = r.get(dset)
            if not d:
                continue
            taus = d["taus"]; c = cols.get(r["name"], "C4")
            agree = [row["agreement"] for row in d["per_tau"]]
            rec = [row["recall"] for row in d["per_tau"]]
            ax.plot(taus, agree, "-o", color=c, lw=2, label=f"{r['name']} agree (gt {d['gt_n_trapped']} trap)")
            ax.plot(taus, rec, "--s", color=c, lw=1.4, alpha=0.7)
        ax.axhline(1.0, ls=":", c="green", lw=1)
        ax.set_xscale("log"); ax.set_xlabel("truncation tau (ns)"); ax.set_ylabel("vs ground-truth verdict")
        ax.set_title(f"{dset}: agreement (solid) & recall (dashed) vs full-length trapped set", fontsize=10)
        ax.set_ylim(0, 1.03); ax.legend(fontsize=7)
    fig.suptitle("Is the trapped-seed verdict decided EARLY? (KCC ∩ forward-weight gate)", fontsize=11)
    fig.tight_layout(); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "fig_early_trap_predictivity.png", dpi=140); plt.close(fig)
    print(f"\nwrote {OUT / 'fig_early_trap_predictivity.png'}", file=sys.stderr)


def main():
    rows = [process(n) for n in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"])]
    make_figure(rows)


if __name__ == "__main__":
    main()
