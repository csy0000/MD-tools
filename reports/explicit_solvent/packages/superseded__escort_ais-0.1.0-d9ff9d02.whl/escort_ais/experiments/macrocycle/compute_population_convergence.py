#!/usr/bin/env python3
"""compute_population_convergence.py — POPULATION-based bAIS ddF convergence (REMD-consistent).

The REMD reference computes ddF the simple way: a single-torsion threshold (GeometricBasinModel) splits
frames into major/minor and ddF = -ln(p_minor/p_major). So the appropriate bAIS comparison is the matching
*population* estimate, NOT a per-microstate BAR combined by logsumexp (which also imports the contaminated
reverse reservoir). This computes, at every hot-length checkpoint, the two population estimates the analysis
calls for:

  (1) ddF_micro_pop     — microstate-population estimate: forward-AIS landing weight per microstate
                          p_land(S) (softmax of exp(final_logw) of landings in S), summed to the major/minor
                          basins (each microstate labelled by the majority basin of its cold frames):
                          p_minor = sum_{S in minor} p_land(S);  ddF = -ln(p_minor/p_major).
  (2) ddF_torsion_rew   — single-torsion reweighted-histogram estimate (the analog_reservoir_artifact
                          method): cold-reservoir frames weighted by W=p_land(S)/n_cold(S), histogrammed on
                          the state-DEFINING torsion, p_minor = weighted fraction inside the minor window;
                          ddF = -ln(p_minor/p_major). This is REMD's exact operation on the bAIS-reweighted
                          distribution.

Both are forward-side and use only data available at each checkpoint (landings gen 0..g; cold seeds
[:n_cold_seeds(g)]). Microstates are fixed (PCA(8)->KMeans(24) on the full cold reservoir, as in
make_analog_reservoir_reweight_figs.py) so only the data accumulated changes across checkpoints.

Writes data/rgd/diagnostics/bais_eval/<name>/population_convergence.json:
  [{gen, hot_ns, n_cold_seeds, ddF_micro_pop, ddF_torsion_rew, p_minor_micro, p_minor_torsion}]

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.compute_population_convergence
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
K = 24


def in_window(deg, lo, hi):
    return (deg >= lo) & (deg <= hi) if lo <= hi else (deg >= lo) | (deg <= hi)


def ddF(p_minor):
    p_minor = min(max(float(p_minor), 1e-9), 1 - 1e-9)
    return -float(np.log(p_minor / (1 - p_minor)))


def process(name):
    cfg = load_cfg(name)
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.basin_model_path)
    assert hasattr(model, "rules") and len(model.rules) == 1, "expects a 1-rule GeometricBasinModel"
    qi, lo, hi = model.rules[0]; qi = int(qi)

    ledger = json.load(open(BE / name / "generations.json"))["generations"]
    ngen = len(ledger)

    # forward landings per generation: features + logw (final_logw, higher == more weight)
    fwdX, fwdW = [], []
    for g in range(ngen):
        d = BE / name / (f"gen{g}/fwd")
        s = pd.read_csv(d / "ais_trajectory_summary.csv")
        t = md.load_dcd(str(d / "ais_final_coordinates.dcd"), top=top)
        n = min(len(s), t.n_frames)
        fwdX.append(featurize(t[:n], q)); fwdW.append(s["final_logw"].to_numpy()[:n])

    # cold reservoir per seed (creation-ordered): features, defining-torsion; sliced by n_cold_seeds(g)
    seed_dirs = sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))
    seedX, seedTor = [], []
    for sfile in seed_dirs:
        tr = md.load_dcd(sfile, top=top)[50:]                          # 50 ps burn
        seedX.append(featurize(tr, q))
        seedTor.append(np.degrees(md.compute_dihedrals(tr, q))[:, qi])

    # fixed microstates on the FULL cold reservoir (matches analog_reservoir_artifact clustering)
    Xcold_all = np.concatenate(seedX)
    pca = PCA(8, random_state=0).fit(Xcold_all)
    scal = StandardScaler().fit(pca.transform(Xcold_all))
    km = KMeans(K, n_init=10, random_state=0).fit(scal.transform(pca.transform(Xcold_all)))
    def micro(X):
        return km.predict(scal.transform(pca.transform(X)))
    # microstate -> basin label: majority side of the state-defining torsion among its cold frames
    # (this IS the GeometricBasinModel rule, so it matches model.assign exactly on the split coordinate)
    micro_cold_all = micro(Xcold_all)
    tor_cold_all = np.concatenate(seedTor)
    is_minor_frame = in_window(tor_cold_all, lo, hi)
    micro_is_minor = np.array([
        (is_minor_frame[micro_cold_all == S].mean() > 0.5) if (micro_cold_all == S).any() else False
        for S in range(K)])

    # per-seed microstate labels (for causal slicing)
    seed_micro = [micro(X) for X in seedX]

    rows = []
    for g in range(ngen):
        # p_land(S) from landings up to gen g
        Xf = np.concatenate(fwdX[:g + 1]); Wf = np.concatenate(fwdW[:g + 1])
        mf = micro(Xf)
        lp = np.full(K, -np.inf)
        for S in range(K):
            m = mf == S
            if m.any():
                lp[S] = logsumexp(Wf[m])
        lp -= logsumexp(lp); p_land = np.exp(lp)

        # (1) microstate-population ddF: sum p_land over minor-labelled microstates
        pmin_micro = float(p_land[micro_is_minor].sum())

        # (2) single-torsion reweighted-histogram ddF on cold seeds available at gen g
        nseed = int(ledger[g].get("n_cold_seeds", len(seed_dirs)))
        mc = np.concatenate(seed_micro[:nseed]); tc = np.concatenate(seedTor[:nseed])
        ncold = np.bincount(mc, minlength=K)
        Wcold = np.array([p_land[S] / ncold[S] if ncold[S] > 0 else 0.0 for S in mc])
        tot = Wcold.sum()
        pmin_tor = float(Wcold[in_window(tc, lo, hi)].sum() / tot) if tot > 0 else np.nan

        rows.append(dict(gen=g, hot_ns=float(ledger[g]["hot_ns"]), n_cold_seeds=nseed,
                         ddF_micro_pop=ddF(pmin_micro), ddF_torsion_rew=ddF(pmin_tor),
                         p_minor_micro=round(pmin_micro, 4), p_minor_torsion=round(pmin_tor, 4)))

    out = BE / name / "population_convergence.json"
    out.write_text(json.dumps(rows, indent=2))
    print(f"[{name}] tor#{qi} win=({lo:g},{hi:g}); final ddF micro-pop {rows[-1]['ddF_micro_pop']:.2f} / "
          f"torsion-rew {rows[-1]['ddF_torsion_rew']:.2f}  -> {out.name}", file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
