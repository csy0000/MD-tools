#!/usr/bin/env python3
"""make_defining_torsion_figs.py — reservoir reweighting drawn on the STATE-DEFINING torsion.

The major/minor state (for BOTH the REMD reference and the bAIS ddF) is a fixed threshold on ONE backbone
torsion (GeometricBasinModel rule). So the free energy is a functional of that single dihedral's marginal
across the threshold. The existing per-torsion figure (fig_<name>_cold_stateweighted_vs_remd.png) picks the
15 *highest-divergence* torsions, which need not include the state-defining one. This script draws the
marginal of THE defining torsion — cold (unweighted), cold (per-cluster STATE-reweighted, W=p_land/n_cold),
and REMD — with the minor-basin window shaded, and annotates p_minor and ddF = -ln(p_minor/p_major) for
each, so the population correction that drives the ddF is shown on its own coordinate.

Per-cluster weighting reproduced exactly from make_analog_reservoir_reweight_figs.py (PCA(8)->scaler->
KMeans(24) microstates; p_land(S) = softmax logsumexp of forward-AIS landing logw in S; W = p_land/n_cold).

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.make_defining_torsion_figs
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
OUT = ROOT / "results/rgd/report"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide (N-Me)", "rgd_redPheVal": "RGD reduced-PheVal amide"}
NMICRO = 24
BINS = np.linspace(-180, 180, 73)


def in_window(deg, lo, hi):
    """Boolean: dihedral (deg) inside the minor-basin window [lo,hi] (wrapping if lo>hi)."""
    return (deg >= lo) & (deg <= hi) if lo <= hi else (deg >= lo) | (deg <= hi)


def ddF(p_minor):
    p_minor = min(max(p_minor, 1e-9), 1 - 1e-9)
    return -np.log(p_minor / (1 - p_minor))


def process(name):
    cfg = load_cfg(name)
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.basin_model_path)
    assert hasattr(model, "rules") and len(model.rules) == 1, "expects a 1-rule GeometricBasinModel"
    qi, lo, hi = model.rules[0]
    qi = int(qi)

    # pooled forward-AIS landings + logw
    land, logw = [], []
    for csv in sorted((BE / name).glob("gen*/fwd/ais_trajectory_summary.csv")):
        dcd = csv.parent / "ais_final_coordinates.dcd"
        if not dcd.exists():
            continue
        d = pd.read_csv(csv); t = md.load_dcd(str(dcd), top=top)
        n = min(len(d), t.n_frames)
        land.append(featurize(t[:n], q)); logw.append(d["final_logw"].to_numpy()[:n])
    landX = np.concatenate(land); logw = np.concatenate(logw)

    # cold reservoir frames (after 50 ps burn): features + the defining torsion
    Xseed, TOR = [], []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        t = md.load_dcd(s, top=top)[50:]
        Xseed.append(featurize(t, q))
        TOR.append(np.degrees(md.compute_dihedrals(t, q))[:, qi])
    Xall = np.concatenate(Xseed); tor_cold = np.concatenate(TOR)

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    tor_remd = np.degrees(md.compute_dihedrals(remd, q))[:, qi]
    remdX = featurize(remd, q)

    # per-cluster state weights  W = p_land(S)/n_cold(S)  (identical to make_analog_reservoir_reweight_figs)
    pca = PCA(8, random_state=0).fit(Xall)
    scal = StandardScaler().fit(pca.transform(Xall))
    km = KMeans(NMICRO, n_init=10, random_state=0).fit(scal.transform(pca.transform(Xall)))
    micro_land = km.predict(scal.transform(pca.transform(landX)))
    micro_cold = km.predict(scal.transform(pca.transform(Xall)))
    lp = np.full(NMICRO, -np.inf)
    for S in range(NMICRO):
        m = micro_land == S
        if m.any():
            lp[S] = logsumexp(logw[m])
    lp -= logsumexp(lp); p_land = np.exp(lp)
    ncold = np.bincount(micro_cold, minlength=NMICRO)
    W = np.array([p_land[S] / ncold[S] if ncold[S] > 0 else 0.0 for S in micro_cold]); W /= W.sum()

    # p_minor on the DEFINING torsion for each distribution
    win_c = in_window(tor_cold, lo, hi); win_r = in_window(tor_remd, lo, hi)
    pmin_raw = float(win_c.mean())
    pmin_rew = float(W[win_c].sum())
    pmin_remd = float(win_r.mean())
    rows = [("REMD (reference)", pmin_remd, "#CC3311"),
            ("cold (unweighted)", pmin_raw, "#4477AA"),
            ("cold (state-reweighted)", pmin_rew, "#117733")]

    # figure: marginal of the defining torsion
    fig, ax = plt.subplots(figsize=(9, 5.2))
    ax.hist(tor_cold, BINS, density=True, alpha=0.40, color="#4477AA", label="cold (unweighted)")
    hw, _ = np.histogram(tor_cold, BINS, weights=W, density=True)
    ax.stairs(hw, BINS, color="#117733", lw=2.4, label="cold (state-reweighted)")
    ax.hist(tor_remd, BINS, density=True, histtype="step", lw=2.2, color="#CC3311", label="REMD")
    # shade the minor-basin window
    ymax = ax.get_ylim()[1]
    if lo <= hi:
        ax.axvspan(lo, hi, color="0.85", alpha=0.5, zorder=0)
    else:
        ax.axvspan(lo, 180, color="0.85", alpha=0.5, zorder=0)
        ax.axvspan(-180, hi, color="0.85", alpha=0.5, zorder=0)
    for x in (lo, hi):
        ax.axvline(x, color="0.4", ls="--", lw=1.0, zorder=1)
    txt = "state = minor iff torsion in shaded window\n" + "\n".join(
        f"{lab:26s} p_minor={p:5.3f}  ddF={ddF(p):+5.2f} kT" for lab, p, _c in rows)
    ax.text(0.015, 0.985, txt, transform=ax.transAxes, va="top", ha="left", fontsize=9,
            family="monospace", bbox=dict(boxstyle="round", fc="white", ec="0.7", alpha=0.9))
    ax.set(xlim=(-180, 180), xlabel=f"state-defining backbone torsion #{qi} (deg)  "
           f"[minor window = ({lo:g}, {hi:g})]", ylabel="density")
    ax.set_yticks([])
    ax.legend(loc="upper right", fontsize=9)
    ax.set_title(f"[{NICE[name]}] reservoir reweighting on the state-defining torsion\n"
                 f"cold p_minor {pmin_raw:.3f} (ddF {ddF(pmin_raw):+.2f}) → reweighted {pmin_rew:.3f} "
                 f"(ddF {ddF(pmin_rew):+.2f})  vs REMD {pmin_remd:.3f} (ddF {ddF(pmin_remd):+.2f})",
                 fontsize=11)
    fig.tight_layout()
    p = OUT / f"fig_{name}_defining_torsion_reweight.png"
    fig.savefig(p, dpi=140, bbox_inches="tight"); plt.close(fig)
    print(f"[{name}] tor#{qi} win=({lo:g},{hi:g})  p_minor raw {pmin_raw:.3f} / rew {pmin_rew:.3f} / "
          f"REMD {pmin_remd:.3f}  ddF {ddF(pmin_raw):+.2f} / {ddF(pmin_rew):+.2f} / {ddF(pmin_remd):+.2f}  "
          f"-> {p.name}", file=sys.stderr)


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
