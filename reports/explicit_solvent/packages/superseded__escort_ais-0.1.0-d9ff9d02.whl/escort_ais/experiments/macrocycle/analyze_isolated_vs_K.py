#!/usr/bin/env python3
"""analyze_isolated_vs_K.py — how many kinetically-ISOLATED clusters does the transition-merge give,
as a function of the KMeans microstate count K?

Pipeline (per compound, per K): KMeans(K) on the cold reservoir -> per-seed discrete trajectories ->
cold-MD transition count matrix (lag 20 ps) -> strongly-connected components (the transition-merge). Each
SCC is a kinetically-isolated cluster. Classify each SCC by REMD population: REAL (REMD >= 0.5%) vs TRAP
(cold-visited but REMD < 0.5%). Report how the counts scale with K.

The point: the raw KMeans count K is arbitrary, but if the transition-merge yields a ~stable number of REAL
isolated clusters (ideally ~2: major/minor) while only the TRAP count grows with K, that is the granularity-
robust state count. Uses the same SCC definition as artifact_quarantine.py / analyze_trapped_macrostates.py.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_isolated_vs_K
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide", "rgd_redPheVal": "rgd_redPheVal"}
LAG = 20
KS = [12, 24, 48, 100, 200]
ART = 0.005


def _count_matrix(dtrajs, lag, K):
    C = np.zeros((K, K))
    for d in dtrajs:
        if len(d) > lag:
            np.add.at(C, (d[:-lag], d[lag:]), 1.0)
    return C


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    seedX = [featurize(md.load_dcd(s, top=top)[50:], q)
             for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd")))]
    Xall = np.concatenate(seedX)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remdX = featurize(remd, q)

    # shared PCA/scaler (fit once on cold) so only K changes
    pca = PCA(8, random_state=0).fit(Xall)
    scal = StandardScaler().fit(pca.transform(Xall))
    Zseed = [scal.transform(pca.transform(x)) for x in seedX]
    Zall = np.concatenate(Zseed); Zremd = scal.transform(pca.transform(remdX))

    print(f"\n===== {NICE[name]}  (cold {len(Xall)} frames, REMD {len(remdX)}, lag {LAG} ps) =====")
    print(f"  {'K':>4} | {'#SCC':>5} {'#real(REMD>=0.5%)':>18} {'#trap(cold,REMD~0)':>19} "
          f"{'ergodic-frac':>12} {'trap cold-pop':>13} {'trap REMD-pop':>13}")
    for K in KS:
        km = KMeans(K, n_init=4, random_state=0).fit(Zall)
        dtrajs = [km.predict(z) for z in Zseed]
        C = _count_matrix(dtrajs, LAG, K)
        ncomp, comp = connected_components(csr_matrix(C > 0), directed=True, connection="strong")
        cold_pop = np.bincount(np.concatenate(dtrajs), minlength=K) / sum(len(d) for d in dtrajs)
        remd_pop = np.bincount(km.predict(Zremd), minlength=K) / len(remdX)
        # per-component populations
        comp_cold = np.array([cold_pop[comp == c].sum() for c in range(ncomp)])
        comp_remd = np.array([remd_pop[comp == c].sum() for c in range(ncomp)])
        comp_visited = np.array([cold_pop[comp == c].sum() > 0 for c in range(ncomp)])
        real = comp_visited & (comp_remd >= ART)
        trap = comp_visited & (comp_remd < ART)
        ergodic = int(np.argmax(comp_cold))
        print(f"  {K:>4} | {ncomp:>5} {int(real.sum()):>18} {int(trap.sum()):>19} "
              f"{comp_cold[ergodic]:>12.3f} {comp_cold[trap].sum():>13.3f} {comp_remd[trap].sum():>13.4f}")


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
