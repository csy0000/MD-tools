#!/usr/bin/env python3
"""build_macrocycle_basin_model.py — fit the fixed torsion-PCCA+ cold-basin model for a macrocycle.

Drives escort_ais.systems.cyclosporin_torsion_basins.build_basin_model (which had no CLI driver) from a
converged cold (s=1.0) reference trajectory, e.g. REMD replica_00. The molecule's torsion quartets are
read from / cached under its topology dir (SMILES resolved from config.json), so nothing is
cyclosporin-specific. n_basins should be chosen from the PCCA+ populations — use --scan to print the
populations for a range of n_basins before committing.

Usage:
  # scan to choose n_basins (does not save):
  python -m escort_ais.experiments.macrocycle.build_macrocycle_basin_model --name rgd \
      --cold-dcd data/rgd/2026-06-29-rest2-remd-8rep-s0p4-300ns/replica_00/trajectory.dcd \
      --burn-ns 50 --scan
  # build + save the chosen model:
  python -m escort_ais.experiments.macrocycle.build_macrocycle_basin_model --name rgd \
      --cold-dcd .../replica_00/trajectory.dcd --burn-ns 50 --n-basins 3
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.cyclosporin_torsion_basins import build_basin_model  # noqa: E402
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--cold-dcd", required=True, help="converged cold (s=1.0) reference trajectory")
    ap.add_argument("--torsion", default="backbone", choices=["backbone", "allatom"])
    ap.add_argument("--n-basins", type=int, default=3)
    ap.add_argument("--n-microstates", type=int, default=150)
    ap.add_argument("--pca-dim", type=int, default=8)
    ap.add_argument("--lag", type=int, default=20)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--burn-ns", type=float, default=0.0)
    ap.add_argument("--ns-per-frame", type=float, default=0.01, help="REMD traj cadence (10 ps/frame)")
    ap.add_argument("--seed", type=int, default=20260629)
    ap.add_argument("--scan", action="store_true", help="print populations for n_basins in 2..5; do not save")
    args = ap.parse_args()

    cfg = load_cfg(args.name, basin_model_set=args.torsion)
    burn_frames = int(round(args.burn_ns / args.ns_per_frame))
    cold_abs = Path(args.cold_dcd).resolve()
    cold_disp = cold_abs.relative_to(ROOT) if cold_abs.is_relative_to(ROOT) else cold_abs
    print(f"  molecule={args.name}  topo={cfg.topo.relative_to(ROOT)}  n_solute_atoms={cfg.n_solute_atoms}")
    print(f"  cold ref: {cold_disp}  burn={args.burn_ns} ns ({burn_frames} frames)")

    def build(nb):
        return build_basin_model(
            cold_dcd=Path(args.cold_dcd), top=cfg.top_pdb, topo_dir=cfg.topo,
            torsion=args.torsion, n_basins=nb, n_microstates=args.n_microstates,
            pca_dim=args.pca_dim, lag=args.lag, stride=args.stride,
            burn_frames=burn_frames, seed=args.seed, smiles=cfg.smiles)

    if args.scan:
        print("\n  n_basins scan (populations sorted desc; basin 0 = most populated):")
        for nb in (2, 3, 4, 5):
            try:
                m = build(nb)
                pop = np.round(m.basin_pop, 3).tolist()
                print(f"    n_basins={nb}: pop={pop}  min_frac={min(m.basin_pop):.3f}")
            except Exception as e:  # noqa: BLE001
                print(f"    n_basins={nb}: FAILED ({e})")
        print("\n  pick n_basins where the smallest basin is still adequately populated, then re-run without --scan.")
        return

    model = build(args.n_basins)
    cfg.basins.mkdir(parents=True, exist_ok=True)
    model.save(cfg.basin_model_path)
    pop = np.round(model.basin_pop, 4).tolist()
    ref = -np.log(model.basin_pop / model.basin_pop[0])
    print(f"\n  built {args.torsion} basin model: n_basins={model.n_basins}")
    print(f"  cold populations = {pop}")
    print(f"  reference ddF (kT) = {np.round(ref, 3).tolist()}")
    print(f"  saved -> {cfg.basin_model_path.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
