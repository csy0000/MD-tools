"""analyze_escort_reservoir_remd.py — W2 convergence comparison: Escort-RRE vs plain REMD.

Loads the physical-U₀ replica (replica_00) trajectory from a finished
Escort Reservoir REMD run and compares its convergence against the plain even
REMD baseline (replica_00 of ff19sb_gbn2_even_4rep_300K_remd_250ns).

Metrics
-------
PRIMARY  — self-convergence: W2(cumulative 0→t, own final-half reference) vs t.
           A faster/lower decay means the physical replica converges to its own
           equilibrium distribution faster.
SECONDARY — cross-run W2: the W2 between escort-RRE replica_00 (final half) and
            plain REMD replica_00 (final half).  Should be small if both reach
            the same physical distribution.
SANITY   — Ramachandran panel for escort-RRE replica_00: should show the
            C7eq + αR landscape, not the flattened reservoir distribution.

Usage
-----
  # Dry run (print paths and frame counts)
  conda run -n openmm python -m escort_ais.experiments.macrocycle.analyze_escort_reservoir_remd --dry-run

  # Full analysis
  conda run -n openmm python -m escort_ais.experiments.macrocycle.analyze_escort_reservoir_remd \\
      --escort-rre-dir data/alanine_dipeptide/md/2026-06-11-escort-reservoir-remd-4rep \\
      --baseline-dir data/alanine_dipeptide/md/ff19sb_gbn2_even_4rep_300K_remd_250ns \\
      --figure-path results/escort_reservoir_remd_w2.png

Outputs
-------
  data/alanine_dipeptide/analysis/2026-06-11-escort-reservoir-remd-w2/
    config.json
    self_convergence.csv   — columns: run, t_ns, w2_mean, w2_std
    cross_w2.json          — W2 between escort-RRE and baseline final halves
  results/escort_reservoir_remd_w2.png
    left:  Ramachandran scatter (escort-RRE replica_00 all frames)
    right: W2 self-convergence curves, both runs
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
PROJECT_ROOT = project_root()

from escort_ais.common.wasserstein import w2_torus, self_convergence_curve  # noqa: E402

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# ACE-ALA-NME atom indices (22-atom GBn2 system)
PHI_IDX = (4, 6, 8, 14)
PSI_IDX = (6, 8, 14, 16)

FRAME_PS = 10.0       # ps between saved frames (default traj_interval_ps)
REF_FRAC = 0.5        # fraction at which "final-half" reference starts

_DEFAULT_ESCORT_RRE_DIR = (
    PROJECT_ROOT / "data" / "alanine_dipeptide" / "md"
    / "2026-06-11-escort-reservoir-remd-4rep"
)
_DEFAULT_BASELINE_DIR = (
    PROJECT_ROOT / "data" / "alanine_dipeptide" / "md"
    / "ff19sb_gbn2_even_4rep_300K_remd_250ns"
)
_DEFAULT_PRMTOP = (
    PROJECT_ROOT / "data" / "topology" / "ff19sb_gbn2_even"
    / "system_scale_1p0.prmtop"
)
_DEFAULT_OUTPUT_DIR = (
    PROJECT_ROOT / "data" / "alanine_dipeptide" / "analysis"
    / "2026-06-11-escort-reservoir-remd-w2"
)
_DEFAULT_FIGURE = PROJECT_ROOT / "results" / "escort_reservoir_remd_w2.png"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_phi_psi_dcd(dcd_path: Path, prmtop_path: Path):
    """Return (phi_deg, psi_deg) arrays from a DCD trajectory via mdtraj."""
    import mdtraj as md

    traj = md.load_dcd(str(dcd_path), top=str(prmtop_path))
    phi_rad = md.compute_dihedrals(traj, [PHI_IDX])[:, 0]
    psi_rad = md.compute_dihedrals(traj, [PSI_IDX])[:, 0]
    return np.degrees(phi_rad), np.degrees(psi_rad)


def load_phi_psi_csv(csv_path: Path):
    """Return (phi_deg, psi_deg) from a torsion_timeseries.csv."""
    df = pd.read_csv(csv_path)
    return df["phi"].to_numpy(dtype=np.float64), df["psi"].to_numpy(dtype=np.float64)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--escort-rre-dir", default=str(_DEFAULT_ESCORT_RRE_DIR),
                   help="Escort-RRE run dir (contains replica_00/trajectory.dcd)")
    p.add_argument("--baseline-dir", default=str(_DEFAULT_BASELINE_DIR),
                   help="Plain even-REMD run dir")
    p.add_argument("--topology", default=str(_DEFAULT_PRMTOP),
                   help="Shared prmtop path (22-atom GBn2)")
    p.add_argument("--output-dir", default=str(_DEFAULT_OUTPUT_DIR))
    p.add_argument("--figure-path", default=str(_DEFAULT_FIGURE))
    p.add_argument("--frame-ps", type=float, default=FRAME_PS,
                   help="ps between saved frames (default 10 ps)")
    p.add_argument("--ref-start-frac", type=float, default=REF_FRAC,
                   help="Fraction of total frames where final-half reference starts (default 0.5)")
    p.add_argument("--n-subsample", type=int, default=2000)
    p.add_argument("--n-repeats", type=int, default=5)
    p.add_argument("--times-step-ns", type=float, default=5.0,
                   help="Time-grid step in ns for convergence curve (default 5 ns)")
    p.add_argument("--dry-run", action="store_true",
                   help="Print paths and frame counts; skip OT and plotting")
    args = p.parse_args(argv)

    escort_dir = Path(args.escort_rre_dir)
    baseline_dir = Path(args.baseline_dir)
    prmtop = Path(args.topology)
    output_dir = Path(args.output_dir)
    fig_path = Path(args.figure_path)

    # ── resolve paths ─────────────────────────────────────────────────────────
    escort_dcd = escort_dir / "replica_00" / "trajectory.dcd"
    baseline_dcd = baseline_dir / "replica_00" / "trajectory.dcd"
    baseline_csv = baseline_dir / "replica_00" / "torsion_timeseries.csv"

    print(f"Escort-RRE   : {escort_dir}")
    print(f"  replica_00 DCD   : {escort_dcd}  exists={escort_dcd.exists()}")
    print(f"Baseline     : {baseline_dir}")
    if baseline_csv.exists():
        print(f"  replica_00 CSV   : {baseline_csv}  exists=True")
    else:
        print(f"  replica_00 DCD   : {baseline_dcd}  exists={baseline_dcd.exists()}")
    print(f"Prmtop       : {prmtop}  exists={prmtop.exists()}")

    if not escort_dcd.exists():
        print(f"\nERROR: escort-RRE replica_00 DCD not found: {escort_dcd}")
        sys.exit(1)
    if not prmtop.exists():
        print(f"\nERROR: prmtop not found: {prmtop}")
        sys.exit(1)

    if args.dry_run:
        print("\nDRY RUN: paths resolved OK. Exiting.")
        return

    # Load phi/psi
    import mdtraj as md

    print("\nLoading escort-RRE replica_00 ...")
    phi_rre, psi_rre = load_phi_psi_dcd(escort_dcd, prmtop)
    n_rre = len(phi_rre)

    print("Loading baseline replica_00 ...")
    if baseline_csv.exists():
        phi_base, psi_base = load_phi_psi_csv(baseline_csv)
    elif baseline_dcd.exists():
        phi_base, psi_base = load_phi_psi_dcd(baseline_dcd, prmtop)
    else:
        print(f"ERROR: baseline replica_00 not found in {baseline_dir}")
        sys.exit(1)
    n_base = len(phi_base)

    duration_rre_ns = n_rre * args.frame_ps / 1000.0
    duration_base_ns = n_base * args.frame_ps / 1000.0
    ref_start_rre = int(n_rre * args.ref_start_frac)
    ref_start_base = int(n_base * args.ref_start_frac)

    print(f"\nEscort-RRE frames: {n_rre}  ({duration_rre_ns:.1f} ns)")
    print(f"Baseline frames:   {n_base}  ({duration_base_ns:.1f} ns)")
    print(f"Reference starts:  escort-RRE frame {ref_start_rre} ({ref_start_rre * args.frame_ps / 1000:.1f} ns)")
    print(f"                   baseline frame   {ref_start_base} ({ref_start_base * args.frame_ps / 1000:.1f} ns)")

    # ── W2 self-convergence ────────────────────────────────────────────────────
    print("\nComputing W2 self-convergence curves ...")

    times_step_frames = max(1, int(args.times_step_ns * 1000.0 / args.frame_ps))

    def _convergence_curve(phi, psi, ref_start):
        phi_ref = phi[ref_start:]
        psi_ref = psi[ref_start:]
        n = len(phi)
        t_frames = list(range(times_step_frames, n + 1, times_step_frames))
        if not t_frames or t_frames[-1] < n:
            t_frames.append(n)
        t_ns_list, w2_mean_list, w2_std_list = [], [], []
        for tf in t_frames:
            t_ns = tf * args.frame_ps / 1000.0
            w2_mean, w2_std = w2_torus(
                phi[:tf], psi[:tf], phi_ref, psi_ref,
                n_subsample=min(args.n_subsample, tf, len(phi_ref)),
                n_repeats=args.n_repeats,
            )
            t_ns_list.append(t_ns)
            w2_mean_list.append(w2_mean)
            w2_std_list.append(w2_std)
            print(f"  t={t_ns:.0f} ns  W2={w2_mean:.4f} ± {w2_std:.4f}")
        return np.array(t_ns_list), np.array(w2_mean_list), np.array(w2_std_list)

    print("  [Escort-RRE]")
    t_rre, w2_rre_mean, w2_rre_std = _convergence_curve(phi_rre, psi_rre, ref_start_rre)
    print("  [Baseline]")
    t_base, w2_base_mean, w2_base_std = _convergence_curve(phi_base, psi_base, ref_start_base)

    # ── Cross-run W2 ──────────────────────────────────────────────────────────
    print("\nComputing cross-run W2 (escort-RRE vs baseline, final halves) ...")
    cross_w2_mean, cross_w2_std = w2_torus(
        phi_rre[ref_start_rre:], psi_rre[ref_start_rre:],
        phi_base[ref_start_base:], psi_base[ref_start_base:],
        n_subsample=min(args.n_subsample, n_rre - ref_start_rre, n_base - ref_start_base),
        n_repeats=args.n_repeats,
    )
    print(f"  Cross W2 (escort-RRE vs baseline): {cross_w2_mean:.4f} ± {cross_w2_std:.4f}")

    # ── Save CSVs ─────────────────────────────────────────────────────────────
    output_dir.mkdir(parents=True, exist_ok=True)

    rows_rre = [{"run": "escort-rre", "t_ns": t, "w2_mean": m, "w2_std": s}
                for t, m, s in zip(t_rre, w2_rre_mean, w2_rre_std)]
    rows_base = [{"run": "baseline (even)", "t_ns": t, "w2_mean": m, "w2_std": s}
                 for t, m, s in zip(t_base, w2_base_mean, w2_base_std)]
    conv_df = pd.DataFrame(rows_rre + rows_base)
    conv_csv = output_dir / "self_convergence.csv"
    conv_df.to_csv(conv_csv, index=False)
    print(f"\nSaved: {conv_csv}")

    cross_data = {
        "escort_rre_dir": str(escort_dir),
        "baseline_dir": str(baseline_dir),
        "cross_w2_mean": float(cross_w2_mean),
        "cross_w2_std": float(cross_w2_std),
        "n_frames_rre_final_half": int(n_rre - ref_start_rre),
        "n_frames_base_final_half": int(n_base - ref_start_base),
    }
    cross_json = output_dir / "cross_w2.json"
    cross_json.write_text(json.dumps(cross_data, indent=2) + "\n", encoding="utf-8")
    print(f"Saved: {cross_json}")

    config = {
        "escort_rre_dir": str(escort_dir),
        "baseline_dir": str(baseline_dir),
        "prmtop": str(prmtop),
        "frame_ps": args.frame_ps,
        "ref_start_frac": args.ref_start_frac,
        "n_subsample": args.n_subsample,
        "n_repeats": args.n_repeats,
        "times_step_ns": args.times_step_ns,
    }
    (output_dir / "config.json").write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")

    # ── Figure ────────────────────────────────────────────────────────────────
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    fig.suptitle("Escort Reservoir REMD — alanine dipeptide (GBn2)", fontsize=13)

    # --- Left: Ramachandran for escort-RRE replica_00 ---
    ax0 = axes[0]
    ax0.scatter(phi_rre, psi_rre, s=2, alpha=0.15, color="steelblue", rasterized=True)
    ax0.set_xlabel("φ [°]", fontsize=11)
    ax0.set_ylabel("ψ [°]", fontsize=11)
    ax0.set_xlim(-180, 180)
    ax0.set_ylim(-180, 180)
    ax0.set_title(f"Escort-RRE replica_00 (U₀)\n{n_rre} frames / {duration_rre_ns:.0f} ns",
                  fontsize=10)
    ax0.axhline(0, color="gray", lw=0.5, ls="--")
    ax0.axvline(0, color="gray", lw=0.5, ls="--")

    # --- Right: W2 self-convergence comparison ---
    ax1 = axes[1]
    ax1.plot(t_rre, w2_rre_mean, color="steelblue", lw=2, label="Escort-RRE (replica_00)")
    ax1.fill_between(t_rre, w2_rre_mean - w2_rre_std, w2_rre_mean + w2_rre_std,
                     alpha=0.2, color="steelblue")
    ax1.plot(t_base, w2_base_mean, color="firebrick", lw=2, ls="--",
             label="Baseline even REMD (replica_00)")
    ax1.fill_between(t_base, w2_base_mean - w2_base_std, w2_base_mean + w2_base_std,
                     alpha=0.2, color="firebrick")
    ax1.set_xlabel("t [ns]", fontsize=11)
    ax1.set_ylabel("W2 (4D torus)", fontsize=11)
    ax1.set_title("Self-convergence W2\n(cumulative vs own final-half reference)", fontsize=10)
    ax1.legend(fontsize=9)
    ax1.set_xlim(left=0)
    ax1.set_ylim(bottom=0)

    plt.tight_layout()
    fig_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(str(fig_path), dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"\nFigure saved: {fig_path}")

    print("\n=== Done ===")
    print(f"Cross W2 (escort-RRE vs baseline, final halves): "
          f"{cross_w2_mean:.4f} ± {cross_w2_std:.4f}")
    print("Interpretation:")
    if cross_w2_mean < 0.05:
        print("  Cross-run W2 is small → escort-RRE and baseline converge to the same distribution ✓")
    else:
        print("  Cross-run W2 is non-trivial → check Ramachandran panels for bias")
    rre_final = w2_rre_mean[-1] if len(w2_rre_mean) else float("nan")
    base_final = w2_base_mean[-1] if len(w2_base_mean) else float("nan")
    print(f"  Final W2 at t_max: escort-RRE={rre_final:.4f}, baseline={base_final:.4f}")
    if rre_final < base_final:
        print("  Escort-RRE converges faster/lower than baseline ✓")
    else:
        print("  Baseline converges faster/lower — investigate exchange rate or ladder placement")


if __name__ == "__main__":
    main()
    sys.exit(0)
