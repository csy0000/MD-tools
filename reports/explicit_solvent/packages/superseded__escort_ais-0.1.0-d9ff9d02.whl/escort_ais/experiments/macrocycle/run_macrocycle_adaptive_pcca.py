#!/usr/bin/env python
"""Adaptive AIS+BAR with per-generation basin re-clustering (RGD macrocycle).

Basin method (step 5) is selectable: `tica-hot` (default) fits TICA on the flipping HOT ensemble
(dih#14 resolved, robust, lag-insensitive, re-fit as the hot ensemble grows); `pcca-cold` runs PCCA+ on
the cold reservoir (lag-sensitive; discovers fast x slow structure). A TICA/PCCA+ fit on the *cold*
reservoir alone fails to generalize (trapped segments) -- hence the hot-fit default.

Implements the 10-step protocol requested for cyclo-(RGDfV):

  [1] hot burn-in 10 ns
  [2] forward AIS from hot [10,60] ns, 1000 x 5 ps
  [3] seeds = 12 most torsion-distinct among the 100 LOWEST-work landings
  [4] 5 ns cold MD per seed
  [5] re-cluster low-transitioning basins (TICA-hot default, or PCCA+-cold via --basin-method)
  [6] assign the forward landings -> forward landing ratio
  [7] sort the cold reservoir by basin
  [8] reverse AIS allocated == forward landing ratio (per basin)
  [9] double the AIS switch (forward AND reverse) until every basin-pair BAR overlap > 0.2
      -- WITHOUT rerunning cold MD
  [10] each generation: +5 ns hot, +100 forward, add 2 cold seeds at the most-distinct NEW landings,
       re-run PCCA+, RE-ASSIGN all accumulated AIS (history included) to the new partition, and shoot an
       equal-ratio basin->hot reverse AIS.

Unlike run_macrocycle_adaptive_generations.py (frozen basin model), the partition here is rebuilt from the
cold reservoir every generation, so new low-transitioning states are discovered as the reservoir grows.
NB: PCCA+ can be jumpy for RGD's shallow minor state -- re-assigning ALL history each generation with the
current model keeps every generation's BAR internally consistent (basin 0 = most populated = reference).

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.run_macrocycle_adaptive_pcca \
        --remd-dir <REMD> --out-dir data/rgd/diagnostics/adaptive_pcca
"""
from __future__ import annotations
import argparse, json, shutil, sys
from pathlib import Path

import numpy as np
import mdtraj as md

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg                                          # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import (build_basin_model_from_segments,  # noqa: E402
                                                   build_tica_basin_model_from_traj,
                                                   featurize, load_quartets)
from escort_ais.methods.run_macrocycle_seedsource_swap import (run_leg, pool_cold_reservoir, largest_remainder,  # noqa: E402
                                            load_sw_hot, load_remd_ensemble, write_seed_dir)
from escort_ais.systems.build_macrocycle_cold_reservoir import build_cold_system, run_cold_seed, fps_indices  # noqa: E402
from escort_ais.methods.run_macrocycle_adaptive_generations import run_hot_md, ais_ns, bar_estimate       # noqa: E402

NS_PER_FRAME = 0.01     # hot MD + AIS-endpoint trajectories: 10 ps/frame


# --------------------------------------------------------------------------- seed selection (step 3)
def select_seeds_lowwork_fps(f_end, W_f, quartets, n_low, n_pick):
    """Step 3: the `n_pick` most torsion-distinct landings among the `n_low` LOWEST-work (highest-weight)
    forward endpoints. W_f = -logw, so lowest work == best weight; FPS starts from the single best."""
    order = np.argsort(W_f)                                   # ascending work == descending weight
    pool = order[: min(n_low, len(order))]
    X = featurize(f_end, np.asarray(quartets))
    loc = fps_indices(X[pool], min(n_pick, len(pool)), seed0=0)   # seed0=0 == lowest-work member of pool
    return pool[loc]


# --------------------------------------------------------------------------- coord-capturing AIS legs
def forward_leg(hot_win, k, cfg, out, switch, dev, rng, seed, args):
    """Forward AIS s_hot->1. Returns (W_f, forward-START coords (hot), forward-LANDING coords (cold))."""
    fpick = rng.choice(hot_win.n_frames, k, replace=k > hot_win.n_frames)
    frames = hot_win[fpick]
    write_seed_dir(out / "seed_hot", frames, cfg, args.timestep_fs)
    logw, sel = run_leg(out / "seed_hot", out / "fwd", k, args.s_hot, 1.0, switch, args.n_shards,
                        args.freq_ais, args.platform, seed, cfg, devices=dev)
    f_end = md.load_dcd(str(out / "fwd/ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    return -logw, frames[sel], f_end


def reverse_leg(model, cold_dir, k, land, cfg, out, switch, dev, rng, seed, args):
    """Reverse AIS 1->s_hot from the cold reservoir, allocated == forward landing ratio `land`.
    Returns (W_r, reverse-START coords (cold), reverse-LANDING coords (hot), reservoir populations)."""
    res_xyz, res_basin, top0 = pool_cold_reservoir(Path(cold_dir), cfg.top_pdb, model,
                                                   args.cold_burn_ps, max_ns=args.reverse_cold_max_ns)
    nb = model.n_basins
    reservoir_pop = np.bincount(res_basin, minlength=nb)
    land = np.asarray(land, float)
    usable = np.array([b for b in range(nb) if land[b] > 0 and reservoir_pop[b] > 0])
    alloc = largest_remainder(land[usable], k)
    rp, b_r0 = [], []
    for B, n in zip(usable, alloc):
        s0 = rng.choice(np.where(res_basin == B)[0], int(n), replace=True)
        rp.append(res_xyz[s0]); b_r0 += [int(B)] * int(n)
    starts = np.concatenate(rp)
    rseed = out / "rev/seed_cold"; rseed.mkdir(parents=True, exist_ok=True)
    md.Trajectory(starts, top0).save_dcd(str(rseed / "trajectory.dcd"))
    shutil.copy2(cfg.top_pdb, rseed / "start_structure.pdb")
    json.dump(dict(prmtop_path=str(cfg.prmtop), inpcrd_path=str(cfg.inpcrd), gb_model="GBn2",
                   gb_radii="mbondi3", n_solute_atoms=cfg.n_solute_atoms, timestep_fs=args.timestep_fs,
                   friction_per_ps=1.0, temperature_k=300.0, solvent="implicit"),
              open(rseed / "config.json", "w"), indent=2)
    print(f"    reverse reservoir: {res_basin.size} frames, basin pops {reservoir_pop.tolist()}, "
          f"alloc {[int(a) for a in alloc]}", flush=True)
    logw, sel = run_leg(rseed, out / "rev/step", len(b_r0), 1.0, args.s_hot, switch, args.n_shards,
                        args.freq_ais, args.platform, seed + 1, cfg, devices=dev)
    r_start = md.Trajectory(starts[sel], top0)
    r_end = md.load_dcd(str(out / "rev/step/ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    return -logw, r_start, r_end, reservoir_pop


def build_model(cold_dir, hot_win, cfg, args):
    """Step 5: determine the low-transitioning basins.

    tica-hot (default): fit TICA on the HOT ensemble (which flips major<->minor, so dih#14 is a resolved
        slow mode) -- robust and lag-insensitive; re-fit each generation as the hot ensemble grows.
    pcca-cold: PCCA+ on the cold-MD reservoir (each seed an independent MSM segment). More sensitive to
        the MSM lag; can discover fast x slow structure via auto n_basins."""
    if args.basin_method == "tica-hot":
        nb = args.n_basins if args.n_basins else 2
        m = build_tica_basin_model_from_traj([hot_win], cfg.topo, n_basins=nb, torsion="backbone",
                                             lag=args.tica_lag, seed=args.seed)
        print(f"  TICA-hot basins: {m.n_basins} (pop {np.round(m.basin_pop, 3).tolist()}) "
              f"from {hot_win.n_frames} hot frames, lag {args.tica_lag}", flush=True)
        return m
    seed_dcds = sorted(Path(cold_dir).glob("seed_*/trajectory.dcd"))
    m = build_basin_model_from_segments(
        seed_dcds, cfg.top_pdb, cfg.topo, torsion="backbone",
        n_basins=args.n_basins, max_basins=args.max_basins, n_microstates=args.n_microstates,
        pca_dim=args.pca_dim, lag=args.msm_lag, burn_frames=int(round(args.cold_burn_ps)), seed=args.seed)
    print(f"  PCCA+ basins: {m.n_basins} (pop {np.round(m.basin_pop, 3).tolist()}) "
          f"from {len(seed_dcds)} cold seeds, lag {args.msm_lag}", flush=True)
    return m


def reference_ddF(model, cold_remd):
    nb = model.n_basins
    p = np.bincount(model.assign(cold_remd), minlength=nb).astype(float); p /= p.sum()
    with np.errstate(divide="ignore"):
        ref = -np.log(p / p[0])
    return ref, p


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--remd-dir", required=True, help="REMD replica_00 cold reference")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--n-generations", type=int, default=8)
    ap.add_argument("--gen0-hot-ns", type=float, default=60.0)      # [2] forward from hot [burn, gen0-hot]
    ap.add_argument("--burn-ns", type=float, default=10.0)          # [1]
    ap.add_argument("--hot-step-ns", type=float, default=5.0)       # [10] +5 ns hot/gen
    ap.add_argument("--k0", type=int, default=1000)                 # [2]
    ap.add_argument("--gen-samples", type=int, default=100)         # [10] +100 forward/gen
    ap.add_argument("--n-low", type=int, default=100)               # [3] lowest-work pool
    ap.add_argument("--n-seeds", type=int, default=12)              # [3] cold seeds at gen 0
    ap.add_argument("--gen-seeds", type=int, default=2)             # [10] +2 cold seeds/gen
    ap.add_argument("--cold-ns", type=float, default=5.0)           # [4]
    # basin determination (step 5)
    ap.add_argument("--basin-method", choices=["tica-hot", "pcca-cold"], default="tica-hot",
                    help="tica-hot (default): TICA on the flipping hot ensemble -- robust, lag-insensitive, "
                         "re-fit as hot grows. pcca-cold: PCCA+ on the trapped cold reservoir -- lag-sensitive.")
    ap.add_argument("--tica-lag", type=int, default=50, help="TICA lag in hot-MD frames (10 ps/frame)")
    ap.add_argument("--n-basins", type=int, default=None, help="force basin count; None = 2 (tica) / auto (pcca)")
    ap.add_argument("--max-basins", type=int, default=4, help="cap for auto basin selection")
    ap.add_argument("--n-microstates", type=int, default=150)
    ap.add_argument("--pca-dim", type=int, default=8)
    ap.add_argument("--msm-lag", type=int, default=300,
                    help="MSM lag in cold-MD frames (1 ps/frame). MUST exceed fast-mode decorrelation "
                         "(~100 ps) so the slow dih#14 flip (~370 ps) is the dominant PCCA+ split; at "
                         "lag<=50 PCCA+ splits on a fast coordinate (~50/50), not major/minor. 200-400 "
                         "recovers the physical dih#14 partition on the RGD cold reservoir.")
    # AIS switching (steps 8-9)
    ap.add_argument("--switch-ps", type=float, default=5.0)
    ap.add_argument("--max-switch-ps", type=float, default=80.0)
    ap.add_argument("--overlap-threshold", type=float, default=0.2)
    ap.add_argument("--reverse-cold-max-ns", type=float, default=None)
    ap.add_argument("--s-hot", type=float, default=0.25)
    ap.add_argument("--freq-ais", type=int, default=10)
    ap.add_argument("--timestep-fs", type=float, default=2.0)
    ap.add_argument("--n-shards", type=int, default=4)
    ap.add_argument("--ais-devices", default=None)
    ap.add_argument("--cold-device", type=int, default=2)
    ap.add_argument("--platform", default="OpenCL")
    ap.add_argument("--n-bootstrap", type=int, default=2000)
    ap.add_argument("--remd-burn-ns", type=float, default=30.0)
    ap.add_argument("--cold-burn-ps", type=float, default=50.0)
    ap.add_argument("--seed", type=int, default=20260703)
    args = ap.parse_args()

    cfg = load_cfg(args.name)
    rng = np.random.default_rng(args.seed)
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    quartets, _om, _ring = load_quartets(cfg.topo, "backbone")
    cold_remd = load_remd_ensemble(Path(args.remd_dir), "replica_00", cfg.top_pdb,
                                   int(round(args.remd_burn_ns / NS_PER_FRAME)))
    st, system = build_cold_system(cfg)
    cold_dir = out / "cold_md"; cold_dir.mkdir(exist_ok=True)
    ledger, invest = [], 0.0

    # =================== GENERATION 0 ===================
    print("=== GENERATION 0 (PCCA+) ===", flush=True)
    hotdir = out / "hot_md"
    run_hot_md(cfg, hotdir, args.gen0_hot_ns, args.cold_device, args.seed, resume=False, s_hot=args.s_hot)
    invest += args.gen0_hot_ns
    hot = load_sw_hot(hotdir / "trajectory.dcd", cfg.top_pdb)
    lo = int(round(args.burn_ns / NS_PER_FRAME))
    hot_win = hot[lo:]
    print(f"  hot [{args.burn_ns:g},{args.gen0_hot_ns:g}] ns = {hot_win.n_frames} frames", flush=True)

    # [2] forward AIS, [3] seeds, [4] cold MD
    W_f, f_start, f_end = forward_leg(hot_win, args.k0, cfg, out / "gen0", args.switch_ps,
                                      args.ais_devices, rng, args.seed, args)
    invest += ais_ns(args.k0, args.switch_ps)
    seeds = select_seeds_lowwork_fps(f_end, W_f, quartets, args.n_low, args.n_seeds)
    print(f"  seeds: {len(seeds)} FPS among {min(args.n_low,len(W_f))} lowest-work landings", flush=True)
    for j, gi in enumerate(seeds):
        run_cold_seed(j, f_end.xyz[int(gi)], st, system, cold_dir, args.cold_ns * 1000.0,
                      args.platform, args.cold_device)
    invest += len(seeds) * args.cold_ns
    n_cold = len(seeds)
    seeded_X = featurize(f_end[seeds], quartets)

    model = build_model(cold_dir, hot_win, cfg, args)                 # [5]

    # [6-9] reverse allocated to forward landing + overlap-doubling gate (cold MD is NOT rerun)
    switch, n_doub = float(args.switch_ps), 0
    while True:
        if n_doub > 0:
            W_f, f_start, f_end = forward_leg(hot_win, args.k0, cfg, out / f"gen0_sw{switch:g}",
                                              switch, args.ais_devices, rng, args.seed, args)
            invest += ais_ns(args.k0, switch)
        ref, p = reference_ddF(model, cold_remd)
        b_f = model.assign(f_end); land = np.bincount(b_f, minlength=model.n_basins)
        W_r, r_start, r_end, respop = reverse_leg(model, cold_dir, args.k0, land, cfg,
                                                  out / f"gen0_sw{switch:g}", switch,
                                                  args.ais_devices, rng, args.seed, args)
        invest += ais_ns(args.k0, switch)
        a_f = model.assign(f_start); b_r = model.assign(r_start); a_r = model.assign(r_end)
        ddf, ci, half, ovl, ovl_all = bar_estimate(model, W_f, a_f, b_f, W_r, b_r, a_r, ref,
                                                    args.n_bootstrap, rng)
        print(f"  gen0 switch {switch:g} ps: BAR {ddf:.2f}±{half:.2f}  min-overlap {ovl:.2f}  "
              f"land {land.tolist()}", flush=True)
        if ovl >= args.overlap_threshold or switch * 2 > args.max_switch_ps:
            break
        switch *= 2.0; n_doub += 1

    # accumulate coords + works (history for step 10)
    Wf_all, fs_all, fe_all = W_f, f_start, f_end
    Wr_all, rs_all, re_all = W_r, r_start, r_end
    refv = float(ref[1]) if np.isfinite(ref[1]) else float("nan")
    ledger.append(dict(gen=0, hot_ns=args.gen0_hot_ns, switch_ps=switch, n_basins=int(model.n_basins),
                       basin_pop=model.basin_pop.tolist(), n_cold_seeds=n_cold, k_fwd=len(Wf_all),
                       k_rev=len(Wr_all), ddF_bar=ddf, ci=ci, ci_half=half, min_overlap=ovl,
                       reference=refv, cost_ns=round(invest, 3), cumulative_ns=round(invest, 3)))
    print(f"  GEN0: ddF {ddf:.2f}±{half:.2f} vs REMD {refv:.2f}; switch {switch:g}ps; {invest:.1f} ns",
          flush=True)

    # =================== GENERATIONS i>=1 ===================
    for gen in range(1, args.n_generations + 1):
        print(f"=== GENERATION {gen} (PCCA+) ===", flush=True)
        gdir = out / f"gen{gen}"
        run_hot_md(cfg, hotdir, args.hot_step_ns, args.cold_device, args.seed + gen, resume=True,
                   s_hot=args.s_hot)                                      # [10] +5 ns hot
        invest += args.hot_step_ns
        hot = load_sw_hot(hotdir / "trajectory.dcd", cfg.top_pdb); hot_win = hot[lo:]

        wf, fs, fe = forward_leg(hot_win, args.gen_samples, cfg, gdir, switch,               # [10] +100 fwd
                                 args.ais_devices, rng, args.seed + gen, args)
        invest += ais_ns(args.gen_samples, switch)
        fe_all = fe_all.join(fe); fs_all = fs_all.join(fs); Wf_all = np.concatenate([Wf_all, wf])

        # [10] add 2 cold seeds at the most torsion-distinct NEW landings (weight-filtered)
        Xland = featurize(fe_all, quartets)
        dmin = np.linalg.norm(Xland[:, None, :] - seeded_X[None, :, :], axis=2).min(1)
        elig = np.where(Wf_all <= np.median(Wf_all))[0]
        pick = elig[np.argsort(-dmin[elig])[:args.gen_seeds]]
        for gi in pick:
            run_cold_seed(n_cold, fe_all.xyz[int(gi)], st, system, cold_dir, args.cold_ns * 1000.0,
                          args.platform, args.cold_device)
            seeded_X = np.vstack([seeded_X, Xland[int(gi)]]); n_cold += 1; invest += args.cold_ns
        print(f"  +{len(pick)} cold seeds (reservoir now {n_cold})", flush=True)

        model = build_model(cold_dir, hot_win, cfg, args)                 # [10] re-fit on grown hot ensemble
        ref, p = reference_ddF(model, cold_remd)

        # [10] equal-ratio basin->hot reverse AIS, matched to the accumulated landing ratio (NEW model)
        b_f_all = model.assign(fe_all); land_acc = np.bincount(b_f_all, minlength=model.n_basins)
        wr, rs, re_, respop = reverse_leg(model, cold_dir, args.gen_samples, land_acc, gdir, switch,
                                          args.ais_devices, rng, args.seed + gen, args)
        invest += ais_ns(args.gen_samples, switch)
        re_all = re_all.join(re_); rs_all = rs_all.join(rs); Wr_all = np.concatenate([Wr_all, wr])

        # [10] re-assign ALL history (this + previous gens) under the new partition, then BAR
        a_f_all = model.assign(fs_all); b_f_all = model.assign(fe_all)
        b_r_all = model.assign(rs_all); a_r_all = model.assign(re_all)
        ddf, ci, half, ovl, ovl_all = bar_estimate(model, Wf_all, a_f_all, b_f_all, Wr_all, b_r_all,
                                                    a_r_all, ref, args.n_bootstrap, rng)
        refv = float(ref[1]) if np.isfinite(ref[1]) else float("nan")
        ledger.append(dict(gen=gen, hot_ns=args.gen0_hot_ns + gen * args.hot_step_ns, switch_ps=switch,
                           n_basins=int(model.n_basins), basin_pop=model.basin_pop.tolist(),
                           n_cold_seeds=n_cold, k_fwd=len(Wf_all), k_rev=len(Wr_all), ddF_bar=ddf,
                           ci=ci, ci_half=half, min_overlap=ovl, reference=refv,
                           cost_ns=round(invest - ledger[-1]["cumulative_ns"], 3),
                           cumulative_ns=round(invest, 3)))
        print(f"  gen{gen}: ddF {ddf:.2f}±{half:.2f}  ovl {ovl:.2f}  basins {model.n_basins}  "
              f"k=({len(Wf_all)},{len(Wr_all)})  cum {invest:.1f} ns", flush=True)

    json.dump(dict(name=args.name, n_generations=len(ledger), settled_switch_ps=switch,
                   total_investment_ns=round(invest, 3), generations=ledger),
              open(out / "generations.json", "w"), indent=2)
    print(f"\n=== ADAPTIVE-PCCA DONE: {len(ledger)} gens, final BAR {ledger[-1]['ddF_bar']:.2f}"
          f"±{ledger[-1]['ci_half']:.2f}; total {invest:.1f} ns ===", flush=True)


if __name__ == "__main__":
    main()
