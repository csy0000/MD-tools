"""run_escort_reservoir_md.py — Generate a Boltzmann reservoir at H_hot = U_{s=0.8} + u₁.

Runs a plain NVT MD at the escort Hamiltonian H_hot with REST2 scale s_mid and
escort potential lambda_u1=1.0 fixed (no switching).  The flattened landscape
makes the reservoir mix fast and cover all basins.

Also pre-computes and saves the reduced energy E_hot(x) for every saved frame into
reservoir_energies.npy so that the reservoir REMD driver can look them up without
re-evaluating them during production.

Outputs (in --output-dir):
  reservoir.dcd            — trajectory under H_hot
  reservoir_energies.npy   — reduced energy (kJ/mol) for each saved frame
  start_structure.pdb
  config.json
  summary.json
  run.log

Usage
-----
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_escort_reservoir_md \\
        --gmm-dir data/alanine_dipeptide/gmm_escort/2026-06-10-gmm-escort-prototype \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/alanine_dipeptide/md/2026-06-11-escort-reservoir-s0p8-softcap-d2g12-md \\
        --duration-ns 100 --platform OpenCL

Smoke test (1 ps):
    conda run -n openmm python -m escort_ais.experiments.macrocycle.run_escort_reservoir_md \\
        --gmm-dir data/alanine_dipeptide/gmm_escort/2026-06-10-gmm-escort-prototype \\
        --topology-dir data/topology/ff19sb_gbn2_even \\
        --output-dir data/alanine_dipeptide/md/test_reservoir_smoke \\
        --duration-ns 0.001 --platform CPU --traj-interval-ps 0.001
"""
from __future__ import annotations

import argparse
import json
import logging
import pickle
import sys
import time
from pathlib import Path

import numpy as np

BOLTZMANN_KJ_PER_MOL_K: float = 0.00831446261815324


def _parse_args(argv=None):
    p = argparse.ArgumentParser(description="Generate escort reservoir (H_hot MD)")
    p.add_argument("--gmm-dir", required=True, help="Dir containing gmm.pkl")
    p.add_argument("--topology-dir", required=True, help="build_topology output dir")
    p.add_argument("--output-dir", default=None,
                   help="Output dir (default: data/alanine_dipeptide/md/<auto>)")
    p.add_argument("--duration-ns", type=float, default=100.0, help="Production length [ns]")
    p.add_argument("--s-mid", type=float, default=0.8, help="REST2 scale for H_hot (default 0.8)")
    p.add_argument("--u1-variant", default="softcap", choices=["log","log1p","capped","softcap"])
    p.add_argument("--u1-target-depth-kt", type=float, default=2.0, help="Escort depth Δ [kT]")
    p.add_argument("--u1-cap-sharpness", type=float, default=12.0, help="Softcap sharpness γ")
    p.add_argument("--temperature-k", type=float, default=300.0)
    p.add_argument("--timestep-fs", type=float, default=2.0)
    p.add_argument("--friction-per-ps", type=float, default=1.0)
    p.add_argument("--traj-interval-ps", type=float, default=10.0,
                   help="Trajectory write interval [ps] (default 10 ps → 10 000 frames/100 ns)")
    p.add_argument("--checkpoint-interval-ps", type=float, default=100.0)
    p.add_argument("--equilibration-ps", type=float, default=1000.0,
                   help="NVT equilibration before production [ps] (default 1 ns)")
    p.add_argument("--minimize-steps", type=int, default=10_000)
    p.add_argument("--platform", default=None, help="OpenMM platform (CUDA/OpenCL/CPU)")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--dry-run", action="store_true",
                   help="Build system and report shapes; skip MD")
    return p.parse_args(argv)


def main(argv=None):
    args = _parse_args(argv)

    # ── output dir ──────────────────────────────────────────────────────────
    output_dir = Path(args.output_dir) if args.output_dir else (
        Path("data/alanine_dipeptide/md") /
        f"escort-reservoir-s{str(args.s_mid).replace('.','p')}-{args.u1_variant}"
        f"-d{str(args.u1_target_depth_kt).replace('.','p')}"
        f"g{str(args.u1_cap_sharpness).replace('.','p')}-md"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── logging ─────────────────────────────────────────────────────────────
    log_path = output_dir / "run.log"
    logger = logging.getLogger("reservoir_md")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(ch)

    logger.info("=== Escort Reservoir MD ===")
    logger.info("Output: %s", output_dir)

    # ── load GMM ────────────────────────────────────────────────────────────
    gmm_dir = Path(args.gmm_dir)
    gmm_data = pickle.loads((gmm_dir / "gmm.pkl").read_bytes())
    gmm = gmm_data["gmm"]
    logger.info("Loaded GMM n_components=%d from %s", gmm.n_components, gmm_dir)

    # ── load topology ───────────────────────────────────────────────────────
    topo_dir = Path(args.topology_dir)
    topo_cfg = json.loads((topo_dir / "config.json").read_text(encoding="utf-8"))
    n_solute_atoms = int(topo_cfg["n_solute_atoms"])

    for prmtop_name in ("system_scale_1p0.prmtop", "system.prmtop"):
        prmtop_path = topo_dir / prmtop_name
        if prmtop_path.exists():
            break
    else:
        raise FileNotFoundError(f"No prmtop found in {topo_dir}")
    for inpcrd_name in ("system_scale_1p0.inpcrd", "system.inpcrd"):
        inpcrd_path = topo_dir / inpcrd_name
        if inpcrd_path.exists():
            break
    else:
        raise FileNotFoundError(f"No inpcrd found in {topo_dir}")

    # ── imports that need openmm ─────────────────────────────────────────────
    from openmm import app, unit  # noqa: PLC0415
    from openmm.app import DCDReporter, StateDataReporter, CheckpointReporter  # noqa: PLC0415
    from escort_ais.systems.gmm_openmm import add_u1_to_system  # noqa: PLC0415
    from escort_ais.systems.openmm_system import Rest2ContextScaler, _clone_system  # noqa: PLC0415
    from escort_ais.methods.md_run import (  # noqa: PLC0415
        _build_simulation, _pick_platform, _write_pdb, steps_from_time,
    )

    # ── build system ────────────────────────────────────────────────────────
    prmtop = app.AmberPrmtopFile(str(prmtop_path))
    inpcrd = app.AmberInpcrdFile(str(inpcrd_path))

    base_system = prmtop.createSystem(
        nonbondedMethod=app.NoCutoff,
        constraints=app.HBonds,
        implicitSolvent=app.GBn2,
    )
    logger.info("Base GBn2 system: n_atoms=%d, n_solute=%d",
                base_system.getNumParticles(), n_solute_atoms)

    temperature_k = args.temperature_k
    beta0 = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * temperature_k)
    solute_indices = np.arange(n_solute_atoms, dtype=np.int64)

    sys_escort = _clone_system(base_system)
    scaler = Rest2ContextScaler(sys_escort, solute_indices)
    force_idx = add_u1_to_system(
        sys_escort, gmm, prmtop.topology, beta0, nbins=360,
        variant=args.u1_variant,
        target_depth_kt=args.u1_target_depth_kt,
        cap_sharpness=args.u1_cap_sharpness,
    )
    logger.info("Added u₁ force (variant=%s, d=%.1f, g=%.1f) at index %d",
                args.u1_variant, args.u1_target_depth_kt, args.u1_cap_sharpness, force_idx)

    if args.dry_run:
        logger.info("DRY RUN: system built OK. n_atoms=%d, n_forces=%d",
                    sys_escort.getNumParticles(), sys_escort.getNumForces())
        print("DRY RUN: OK")
        return

    # ── build simulation ─────────────────────────────────────────────────────
    platform_name = _pick_platform(args.platform)
    sim = _build_simulation(
        prmtop.topology, sys_escort, temperature_k,
        args.friction_per_ps, args.timestep_fs, platform_name,
    )
    scaler.apply(args.s_mid, sim.context)
    sim.context.setParameter("lambda_u1", 1.0)
    logger.info("Simulation on %s  s_mid=%.2f  lambda_u1=1.0", platform_name, args.s_mid)

    sim.context.setPositions(inpcrd.positions)
    t_start = time.time()

    # ── minimization ─────────────────────────────────────────────────────────
    sim.minimizeEnergy(maxIterations=args.minimize_steps)
    logger.info("Minimized (%.1f s)", time.time() - t_start)

    # ── equilibration ─────────────────────────────────────────────────────────
    equil_steps = steps_from_time(args.equilibration_ps, args.timestep_fs)
    sim.context.setVelocitiesToTemperature(temperature_k * unit.kelvin, args.seed)
    if equil_steps > 0:
        logger.info("Equilibrating %.0f ps (%d steps) ...", args.equilibration_ps, equil_steps)
        sim.step(equil_steps)
        logger.info("Equilibration done (%.1f s)", time.time() - t_start)

    equil_state = sim.context.getState(getPositions=True)
    _write_pdb(output_dir / "start_structure.pdb", prmtop.topology, equil_state.getPositions())

    # ── production ────────────────────────────────────────────────────────────
    production_steps = steps_from_time(args.duration_ns * 1000.0, args.timestep_fs)
    traj_steps = max(1, steps_from_time(args.traj_interval_ps, args.timestep_fs))
    chk_steps = max(1, steps_from_time(args.checkpoint_interval_ps, args.timestep_fs))

    res_dcd_path = output_dir / "reservoir.dcd"
    sim.reporters.append(DCDReporter(str(res_dcd_path), traj_steps))
    sim.reporters.append(
        StateDataReporter(
            str(output_dir / "state.csv"), traj_steps,
            step=True, time=True, potentialEnergy=True, kineticEnergy=True,
            totalEnergy=True, temperature=True, speed=True, progress=True,
            remainingTime=True, totalSteps=production_steps, separator=",",
        )
    )
    try:
        sim.reporters.append(CheckpointReporter(str(output_dir / "trajectory.chk"), chk_steps))
    except Exception:
        pass

    logger.info("Production: %d steps (%.0f ns), trajectory every %d steps",
                production_steps, args.duration_ns, traj_steps)
    sim.step(production_steps)
    wall_time_s = time.time() - t_start
    logger.info("Production done: %.1f s", wall_time_s)

    final_state = sim.context.getState(getPositions=True, getEnergy=True)
    sim.saveState(str(output_dir / "final_state.xml"))
    _write_pdb(output_dir / "final_structure.pdb", prmtop.topology, final_state.getPositions())

    # ── pre-compute reservoir energies ────────────────────────────────────────
    logger.info("Pre-computing H_hot energies for reservoir frames ...")
    import mdtraj as md  # noqa: PLC0415
    res_traj = md.load_dcd(str(res_dcd_path), top=str(prmtop_path))
    n_frames = res_traj.n_frames
    energies = np.zeros(n_frames, dtype=np.float64)
    for k, pos_nm in enumerate(res_traj.xyz):
        sim.reporters.clear()  # no reporters during scoring
        sim.context.setPositions(pos_nm * unit.nanometer)
        e_kj = sim.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(
            unit.kilojoule_per_mole
        )
        energies[k] = e_kj
        if (k + 1) % 500 == 0:
            logger.info("  scored %d/%d frames", k + 1, n_frames)
    np.save(str(output_dir / "reservoir_energies.npy"), energies)
    logger.info("Saved reservoir_energies.npy (%d frames)", n_frames)

    # ── write config + summary ────────────────────────────────────────────────
    config_dict = {
        "method": "escort_reservoir_md",
        "gmm_dir": str(gmm_dir),
        "topology_dir": str(topo_dir),
        "output_dir": str(output_dir),
        "s_mid": args.s_mid,
        "lambda_u1": 1.0,
        "u1_variant": args.u1_variant,
        "u1_target_depth_kt": args.u1_target_depth_kt,
        "u1_cap_sharpness": args.u1_cap_sharpness,
        "temperature_k": temperature_k,
        "duration_ns": args.duration_ns,
        "timestep_fs": args.timestep_fs,
        "traj_interval_ps": args.traj_interval_ps,
        "equilibration_ps": args.equilibration_ps,
        "minimize_steps": args.minimize_steps,
        "platform": platform_name,
        "seed": args.seed,
        "friction_per_ps": args.friction_per_ps,
        "production_steps": production_steps,
        "traj_interval_steps": traj_steps,
        "n_reservoir_frames": n_frames,
        "n_solute_atoms": n_solute_atoms,
        "prmtop_path": str(prmtop_path),
        "inpcrd_path": str(inpcrd_path),
    }
    (output_dir / "config.json").write_text(json.dumps(config_dict, indent=2) + "\n", encoding="utf-8")

    summary = {
        "output_dir": str(output_dir),
        "platform": platform_name,
        "duration_ns": args.duration_ns,
        "production_steps": production_steps,
        "n_reservoir_frames": n_frames,
        "reservoir_dcd": str(res_dcd_path),
        "reservoir_energies_npy": str(output_dir / "reservoir_energies.npy"),
        "final_potential_energy_kj_mol": final_state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole),
        "wall_time_s": wall_time_s,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    logger.info("Done. %d reservoir frames saved to %s", n_frames, res_dcd_path)
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == "__main__":
    main()
    sys.exit(0)
