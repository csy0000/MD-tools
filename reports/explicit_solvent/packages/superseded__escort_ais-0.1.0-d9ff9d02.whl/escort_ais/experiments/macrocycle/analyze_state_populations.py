#!/usr/bin/env python3
"""analyze_state_populations.py — compare bAIS vs REMD populations over the few most-populated, ISOLATED
metastable states (threshold-free alternative to the single-torsion major/minor ddF).

The single-torsion split is ill-defined for the derivatives (boundary in a populated region -> populations
swing ~1-2 kT with the threshold, 37-60% of cold seeds cross it; see analyze_threshold_sensitivity.py). So
instead of a 2-state ddF on one dihedral, define genuinely isolated metastable states from the transition-
rich HOT ensemble (TICA -> KMeans in TIC space; boundaries fall in kinetic barriers, not populated regions),
keep the top-N by REMD population, and compare the population VECTOR:

  p_REMD(state)  vs  p_bAIS(state) = forward-AIS Jarzynski population
                                   = sum_{landings in state} e^{logw} / sum e^{logw}

Reports per state: REMD pop, bAIS pop, raw (unweighted) cold-reservoir pop, and free energies
dG = -ln(p/p_max) relative to the most-populated REMD state; plus the total-variation distance
TV = 0.5*sum|p_REMD - p_bAIS| (0 = perfect) for bAIS and for the raw cold reservoir.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_state_populations
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.metrics import silhouette_score

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
HOT = {"rgd": ROOT / "data/rgd/2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701/trajectory.dcd",
       "cilengitide": ROOT / "data/cilengitide/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd",
       "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-06-sw-hot-s0p25-800ns/trajectory.dcd"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide", "rgd_redPheVal": "rgd_redPheVal"}
NSTATE = 5


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")

    # isolated metastable states from the transition-rich HOT ensemble (TICA -> KMeans in TIC space)
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NSTATE,
                                   lag=20, n_tic=4, burn_frames=1000, stride=2, seed=0)

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    p_remd = np.bincount(model.assign(remd), minlength=NSTATE).astype(float); p_remd /= p_remd.sum()

    # forward-AIS Jarzynski population per state
    lab, lw = [], []
    for csv in sorted((BE / name).glob("gen*/fwd/ais_trajectory_summary.csv")):
        dcd = csv.parent / "ais_final_coordinates.dcd"
        if not dcd.exists():
            continue
        d = pd.read_csv(csv); t = md.load_dcd(str(dcd), top=top); n = min(len(d), t.n_frames)
        lab.append(model.assign(t[:n])); lw.append(d["final_logw"].to_numpy()[:n])
    lab = np.concatenate(lab); lw = np.concatenate(lw)
    p_bais = np.array([np.exp(logsumexp(lw[lab == s])) if (lab == s).any() else 0.0 for s in range(NSTATE)])
    p_bais /= p_bais.sum()

    # raw (unweighted) cold-reservoir population per state
    cold_lab = []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        cold_lab.append(model.assign(md.load_dcd(s, top=top)[50:]))
    cold_lab = np.concatenate(cold_lab)
    p_cold = np.bincount(cold_lab, minlength=NSTATE).astype(float); p_cold /= p_cold.sum()

    # isolation: silhouette of the state assignment on REMD in TIC space
    Yremd = model.tica.transform(featurize(remd, q))[:, :model.n_tic]
    sil = float(silhouette_score(Yremd, model.assign(remd), sample_size=min(3000, len(remd)), random_state=0))

    # RELABEL states by COLD (REMD) population so S0 = most populated in the reference (S1 = 2nd, ...);
    # the TICABasinModel numbers by HOT-fit population, which hot<->cold rank inversions make confusing.
    perm = np.argsort(-p_remd)
    p_remd, p_bais, p_cold = p_remd[perm], p_bais[perm], p_cold[perm]
    ref = 0
    def dG(p):
        return -np.log(np.clip(p, 1e-9, None) / max(p[ref], 1e-9))
    tv = lambda p: 0.5 * np.abs(p_remd - p).sum()

    order = np.argsort(-p_remd)
    print(f"\n===== {NICE[name]}  ({NSTATE} isolated metastable states, TICA-on-hot; "
          f"REMD-frame silhouette {sil:+.2f}) =====")
    print(f"  state | p_REMD  p_bAIS  p_cold(raw) | dG_REMD  dG_bAIS  (kT, vs most-pop REMD state)")
    for s in order:
        print(f"   S{s}   | {p_remd[s]:6.3f} {p_bais[s]:6.3f} {p_cold[s]:11.3f} | "
              f"{dG(p_remd)[s]:+7.2f} {dG(p_bais)[s]:+7.2f}")
    print(f"  total-variation distance to REMD:  bAIS = {tv(p_bais):.3f}   raw cold = {tv(p_cold):.3f}   "
          f"(0 = perfect)")


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
