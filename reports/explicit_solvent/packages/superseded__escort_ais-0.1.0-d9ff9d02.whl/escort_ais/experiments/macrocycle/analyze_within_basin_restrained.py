#!/usr/bin/env python3
"""analyze_within_basin_restrained.py — is the cold reservoir locally equilibrated within the rgd MAJOR basin?

Builds a within-basin equilibrium REFERENCE from flat-bottom-restrained MD (confined to the major = complement
side of the dih#14 rule, [-180,-15] deg), then:
  (1) SELF-CONSISTENCY (validates the reference despite the 300 K frozen-sub-well caveat): do the restrained seeds
      agree? cross-seed pairwise JS + per-sub-basin split-Rhat; has pooled P converged vs time?
  (2) VALIDATE: JS(P_restrained, REMD(.|major))  — REMD only checks the reference.
  (3) LEQ VERDICT: JS(P_cold(.|major), P_restrained) + reweighting-ESS — does the cold reservoir match equilibrium?

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_within_basin_restrained
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
from sklearn.cluster import KMeans

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.methods.basin_restraint import basin_window, wrapped_deviation  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_rite_local_equilibrium import _js  # noqa: E402

RESTR = ROOT / "data/rgd/diagnostics/within_basin_restrained/rgd/major"
COLD = ROOT / "data/rgd/diagnostics/fps10_100ns_experiment/rgd/cold_md"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"}
OUT = ROOT / "results/rgd/report"
KSUB, BURN = 12, 1000                                    # 12 sub-basins; drop first 1 ns of each restrained run


def in_major(traj, quartet, center, hw):
    th = md.compute_dihedrals(traj, [quartet])[:, 0]
    return wrapped_deviation(th, center) <= hw


def _rhat_scalar(chains):
    """Split-Rhat for a set of equal-length scalar chains (list of 1-D arrays)."""
    L = min(len(c) for c in chains)
    if L < 8:
        return np.nan
    h = L // 2
    sub = np.array([c[s:s + h] for c in chains for s in (0, h)])      # 2m half-chains
    n = sub.shape[1]
    W = sub.var(axis=1, ddof=1).mean()
    B = n * sub.mean(axis=1).var(ddof=1)
    if W <= 0:
        return np.nan
    return float(np.sqrt(((n - 1) / n * W + B / n) / W))


def process(name="rgd"):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone")
    win = basin_window(cfg, "complement"); quart, c, hw = win["quartet"], win["center_rad"], win["halfwidth_rad"]
    top = str(cfg.top_pdb)

    # --- restrained reference (per-seed in-major features) ---
    restr_feats = []
    for d in sorted(glob.glob(str(RESTR / "seed_*"))):
        tr = md.load_dcd(str(Path(d) / "trajectory.dcd"), top=top)[BURN:]
        m = in_major(tr, quart, c, hw)
        if m.sum() > 100:
            restr_feats.append(featurize(tr, q)[m])
    if len(restr_feats) < 2:
        print("need >=2 restrained seeds", file=sys.stderr); return
    restr_all = np.concatenate(restr_feats)

    # --- cold reservoir in-major ---
    cold = []
    for d in sorted(glob.glob(str(COLD / "seed_*"))):
        pdb = Path(d) / "final_structure.pdb"
        if not pdb.exists():
            continue
        tr = md.load_dcd(str(Path(d) / "trajectory.dcd"), top=str(pdb))
        m = in_major(tr, quart, c, hw)
        if m.any():
            cold.append(featurize(tr, q)[m])
    cold_all = np.concatenate(cold)

    # --- REMD in-major (validation only) ---
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remd_f = featurize(remd, q)[in_major(remd, quart, c, hw)]

    # --- common KSUB grid on the union of supports ---
    km = KMeans(KSUB, n_init=6, random_state=0).fit(np.concatenate([restr_all, cold_all, remd_f]))
    H = lambda X: np.bincount(km.predict(X), minlength=KSUB).astype(float)
    P_restr, P_cold, P_remd = H(restr_all), H(cold_all), H(remd_f)

    # (1) self-consistency of the restrained reference
    per_seed = [H(f) for f in restr_feats]
    pair_js = [float(_js(per_seed[i], per_seed[j])) for i in range(len(per_seed)) for j in range(i + 1, len(per_seed))]
    labels = [km.predict(f) for f in restr_feats]
    rhats = [_rhat_scalar([(lab == j).astype(float) for lab in labels]) for j in range(KSUB)]
    rhats = [r for r in rhats if not np.isnan(r)]
    conv = []
    for fr in (0.25, 0.5, 0.75, 1.0):
        pooled = sum(H(f[:max(1, int(len(f) * fr))]) for f in restr_feats)
        conv.append(round(float(_js(pooled, P_restr)), 4))

    # (2) validate reference vs REMD; (3) LEQ verdict cold vs restrained
    js_restr_remd = round(float(_js(P_restr, P_remd)), 4)
    js_cold_restr = round(float(_js(P_cold, P_restr)), 4)
    js_cold_remd = round(float(_js(P_cold, P_remd)), 4)
    pr, pc = P_restr / P_restr.sum(), P_cold / P_cold.sum()
    w = pr[km.predict(cold_all)] / np.maximum(pc[km.predict(cold_all)], 1e-12)     # reweight cold -> restrained
    ess_frac = float((w.sum() ** 2) / (len(w) * np.sum(w ** 2)))

    res = dict(name=name, n_restr_seeds=len(restr_feats), n_restr_frames=int(len(restr_all)),
               n_cold_frames=int(len(cold_all)), n_remd_frames=int(len(remd_f)), ksub=KSUB,
               selfconsistency=dict(cross_seed_js_mean=round(float(np.mean(pair_js)), 4),
                                    cross_seed_js_max=round(float(np.max(pair_js)), 4),
                                    rhat_max=round(float(np.max(rhats)), 3) if rhats else None,
                                    rhat_mean=round(float(np.mean(rhats)), 3) if rhats else None,
                                    convergence_js=conv),
               js_restr_remd=js_restr_remd, js_cold_restr=js_cold_restr, js_cold_remd=js_cold_remd,
               cold_to_restr_ess_frac=round(ess_frac, 4),
               P_restr=(P_restr / P_restr.sum()).round(3).tolist(),
               P_cold=(P_cold / P_cold.sum()).round(3).tolist(),
               P_remd=(P_remd / P_remd.sum()).round(3).tolist())
    (RESTR.parent / "within_basin_restrained.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({k: res[k] for k in ("n_restr_seeds", "selfconsistency", "js_restr_remd",
                                          "js_cold_restr", "js_cold_remd", "cold_to_restr_ess_frac")}, indent=2),
          file=sys.stderr)
    make_figure(name, res)
    return res


def make_figure(name, res):
    from escort_ais.common.figutil import panel_labels
    # Convention: REMD (equilibrium) = GREY; cold reservoir = ORANGE (C1); restrained reference = BLUE (C0).
    pr = np.array(res["P_restr"]); pc = np.array(res["P_cold"]); pe = np.array(res["P_remd"])
    o = np.argsort(-pe); x = np.arange(len(pe))
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
    ax[0].bar(x, pe[o], color="0.6", alpha=0.55, label="REMD(·|major) [equilibrium]")
    ax[0].plot(x, pr[o], "-o", c="C0", ms=4, label="restrained ref P̂")
    ax[0].plot(x, pc[o], "-s", c="C1", ms=4, label="cold reservoir")
    ax[0].set_xlabel("sub-basin (sorted by REMD)"); ax[0].set_ylabel("within-major population")
    ax[0].set_title(f"{name}: within-major distributions"); ax[0].legend(fontsize=8)
    sc = res["selfconsistency"]
    ax[1].plot([0.25, 0.5, 0.75, 1.0], sc["convergence_js"], "-o", c="C0")
    ax[1].axhline(sc["cross_seed_js_mean"], ls="--", c="C2", label=f"cross-seed JS {sc['cross_seed_js_mean']}")
    ax[1].set_xlabel("restrained-run fraction used"); ax[1].set_ylabel("JS(pooled P̂, final P̂)")
    ax[1].set_title(f"reference self-consistency (R̂max={sc['rhat_max']})"); ax[1].legend(fontsize=8)
    labels = ["JS(ref,REMD)\n[reference ok?]", "JS(cold,ref)\n[LEQ verdict]", "JS(cold,REMD)"]
    vals = [res["js_restr_remd"], res["js_cold_restr"], res["js_cold_remd"]]
    ax[2].bar(range(3), vals, color=["C2", "C3", "0.6"])
    for i, v in enumerate(vals):
        ax[2].text(i, v, f"{v}", ha="center", va="bottom", fontsize=9)
    ax[2].axhline(0.05, ls=":", c="0.4"); ax[2].set_xticks(range(3)); ax[2].set_xticklabels(labels, fontsize=8)
    ax[2].set_ylabel("Jensen–Shannon divergence")
    ax[2].set_title(f"cold→ref reweight ESS = {res['cold_to_restr_ess_frac']}")
    fig.suptitle(f"{name}: within-basin (major) LEQ via flat-bottom restrained reference", fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.96]); OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"fig_{name}_within_basin_restrained.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_within_basin_restrained.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
