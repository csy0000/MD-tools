#!/usr/bin/env python3
"""run_macrocycle_adaptive_workflow.py -- the adaptive AIS+BAR overlap gate (workflow steps 1-3).

Reuses an existing hot ensemble + cold-MD reservoir and runs the single-walker AIS+BAR estimate
(forward AIS from the hot ensemble, reverse AIS from the cold reservoir) starting at --start-switch-ps,
DOUBLING the switch time (forward & reverse) until the BAR work-overlap reaches --overlap-threshold.
The cold MD is reused at every switch (no reservoir resampling), exactly as in the workflow figure.
Each switch is one call to run_macrocycle_seedsource_swap.py (--forward-source sw --reverse-source sw).

Usage:
  python -m escort_ais.experiments.macrocycle.run_macrocycle_adaptive_workflow --name rgd \
      --hot-ref data/rgd/2026-06-29-ref-singlewalker-hot-s0p25-300ns/trajectory.dcd \
      --hot-window-ns 30 300 --cold-dir data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md \
      --remd-dir data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns --k 1000 --ais-devices 1 \
      --out-dir data/rgd/diagnostics/adaptive_workflow
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from escort_ais.common.paths import project_root
ROOT = project_root()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--hot-ref", required=True)
    ap.add_argument("--hot-window-ns", type=float, nargs=2, default=[30.0, 300.0])
    ap.add_argument("--cold-dir", required=True)
    ap.add_argument("--remd-dir", required=True)
    ap.add_argument("--k", type=int, default=1000)
    ap.add_argument("--s-hot", type=float, default=0.25)
    ap.add_argument("--start-switch-ps", type=float, default=5.0)
    ap.add_argument("--max-switch-ps", type=float, default=80.0)
    ap.add_argument("--overlap-threshold", type=float, default=0.2)
    ap.add_argument("--burn-ns", type=float, default=30.0)
    ap.add_argument("--n-shards", type=int, default=4)
    ap.add_argument("--n-bootstrap", type=int, default=400)
    ap.add_argument("--platform", default="OpenCL")
    ap.add_argument("--ais-devices", default=None)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()

    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    steps, switch = [], float(args.start_switch_ps)
    while switch <= args.max_switch_ps + 1e-9:
        cell = out / f"switch_{switch:g}ps"
        cmd = [sys.executable, "-m", "escort_ais.methods.run_macrocycle_seedsource_swap",
               "--name", args.name, "--remd-dir", args.remd_dir, "--hot-ref", args.hot_ref,
               "--hot-window-ns", str(args.hot_window_ns[0]), str(args.hot_window_ns[1]),
               "--cold-dir", args.cold_dir, "--s-hot", str(args.s_hot), "--k", str(args.k),
               "--switch-ps", str(switch), "--burn-ns", str(args.burn_ns), "--platform", args.platform,
               "--n-shards", str(args.n_shards), "--n-bootstrap", str(args.n_bootstrap),
               "--forward-source", "sw", "--reverse-source", "sw", "--out-dir", str(cell)]
        if args.ais_devices is not None:
            cmd += ["--ais-devices", args.ais_devices]
        print(f"\n=== overlap gate: switch = {switch:g} ps ===", flush=True)
        subprocess.run(cmd, check=True)
        s = json.loads((cell / "validation_summary.json").read_text())
        ovl = min(s["overlap"]); ddf = s["ddF_bar"][1]; ref = s["reference_ddF"][1]; ais = s["ddF_ais"][1]
        steps.append(dict(switch_ps=switch, min_overlap=ovl, ddF_bar=ddf, ddF_ais=ais, reference=ref,
                          gate_passed=ovl >= args.overlap_threshold))
        print(f"  switch {switch:g} ps: overlap={ovl:.3f}  AIS={ais:.2f}  BAR={ddf:.2f}  ref={ref:.2f}  "
              f"{'PASS' if ovl >= args.overlap_threshold else 'below threshold -> double'}", flush=True)
        if ovl >= args.overlap_threshold:
            break
        switch *= 2.0

    final = steps[-1]
    summary = dict(overlap_threshold=args.overlap_threshold, steps=steps,
                   gate_switch_ps=final["switch_ps"], gate_passed=final["gate_passed"],
                   ddF_bar=final["ddF_bar"], reference=final["reference"])
    (out / "adaptive_summary.json").write_text(json.dumps(summary, indent=2))
    print("\n=== ADAPTIVE WORKFLOW RESULT ===")
    for st in steps:
        print(f"  {st['switch_ps']:>4g} ps  overlap {st['min_overlap']:.3f}  BAR {st['ddF_bar']:.2f}  "
              f"AIS {st['ddF_ais']:.2f}  (ref {st['reference']:.2f})")
    print(f"  -> gate reached at {final['switch_ps']:g} ps"
          f"{' (overlap>=%.2f)' % args.overlap_threshold if final['gate_passed'] else ' (max switch, gate NOT met)'}"
          f"; ddF_BAR = {final['ddF_bar']:.2f} kT vs reference {final['reference']:.2f} kT")


if __name__ == "__main__":
    main()
