#!/usr/bin/env python
"""Direct energetic probe of the reverse-work collapse (CPU single-point energies, no dynamics/AIS).

The reverse cold->hot switch work is, to leading order, dU = U(s=0.25) - U(s=1.0) evaluated at the
cold START configuration. Its SPREAD per basin is the structure-free proxy for the reverse-work spread.
We evaluate dU on (a) the forward-AIS landings (t=0, pre cold MD) and (b) cold-MD frames in windows
[0-1], [4-5], [9-10] ns, split by basin. If the minor dU is broad for the landings / early cold MD and
sharpens within ~1 ns, the 1ns->5ns W_r collapse is fast local strain dissipation, not slow backbone
relaxation (which src/escort_ais/experiments/macrocycle/diagnose_cold_relaxation.py already showed is absent).

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.diagnose_cold_energy
"""
from __future__ import annotations
import sys, warnings
from pathlib import Path

import numpy as np
import mdtraj as md
import parmed as pmd
from parmed.tools import changeRadii
import openmm as mm
from openmm import unit
from openmm.app import GBn2, NoCutoff, HBonds

warnings.filterwarnings("ignore")
from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import BasinModel, load_quartets
from escort_ais.systems.openmm_system import build_rest2_scaled_system

DATA = ROOT / "data/rgd/2026-06-29-reservoir-sw-s0p25"
NS = 1000
MINOR, MAJOR = 1, 0
KT = 2.494  # kJ/mol at 300 K


def make_context(cfg, s):
    st = pmd.load_file(str(cfg.prmtop), xyz=str(cfg.inpcrd))
    changeRadii(st, "mbondi3").execute()
    base = st.createSystem(implicitSolvent=GBn2, nonbondedMethod=NoCutoff,
                           constraints=HBonds, removeCMMotion=True)
    excl = np.load(cfg.omega)
    solute = np.arange(st.topology.getNumAtoms())
    system = build_rest2_scaled_system(base, solute, s, exclude_central_bonds=excl)
    ctx = mm.Context(system, mm.VerletIntegrator(1.0 * unit.femtosecond),
                     mm.Platform.getPlatformByName("CPU"))
    return ctx


def energies(ctx, xyz_nm):
    out = np.empty(len(xyz_nm))
    for i, x in enumerate(xyz_nm):
        ctx.setPositions(x * unit.nanometer)
        out[i] = ctx.getState(getEnergy=True).getPotentialEnergy().value_in_unit(
            unit.kilojoule_per_mole)
    return out


def dU_stats(label, traj, b, c_cold, c_hot, rng, nmax=250):
    for basin, tag in [(MINOR, "minor"), (MAJOR, "major")]:
        idx = np.where(b == basin)[0]
        if len(idx) == 0:
            print(f"  {label:>16} {tag}: (none)"); continue
        if len(idx) > nmax:
            idx = rng.choice(idx, nmax, replace=False)
        x = traj.xyz[idx]
        dU = energies(c_hot, x) - energies(c_cold, x)          # U(0.25) - U(1.0)
        print(f"  {label:>16} {tag}: n={len(idx):4d}  dU mean={dU.mean():8.1f}  std={dU.std():7.1f} kJ/mol "
              f"(std/kT={dU.std()/KT:6.1f})")


def main():
    cfg = load_cfg("rgd"); top = str(cfg.top_pdb); rng = np.random.default_rng(0)
    quartets, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.topo.parent / "basins_tica" / "basin_model_backbone.pkl")
    print("building s=1.0 and s=0.25 Hamiltonians (CPU) ...")
    c_cold, c_hot = make_context(cfg, 1.0), make_context(cfg, 0.25)

    # (a) forward-AIS landings = reverse starts at t=0 (pre cold MD)
    fwd = md.load_dcd(str(DATA / "step_forward_ais/ais_final_coordinates.dcd"), top=top)
    dU_stats("fwd-landing t=0", fwd, model.assign(fwd), c_cold, c_hot, rng)

    # (b) cold-MD windows
    seeds = sorted((DATA / "cold_md_10ns").glob("seed_*/trajectory.dcd"))
    for w in [(0, 1), (4, 5), (9, 10)]:
        xs, bs = [], []
        for s in seeds:
            tr = md.load_dcd(str(s), top=top)[w[0] * NS:w[1] * NS]
            xs.append(tr.xyz); bs.append(model.assign(tr))
        pool = md.Trajectory(np.concatenate(xs), md.load(top).topology)
        dU_stats(f"cold {w[0]}-{w[1]}ns", pool, np.concatenate(bs), c_cold, c_hot, rng)

    print(f"\n(kT = {KT} kJ/mol at 300 K; reverse work std ~ dU std for a near-instantaneous switch)")


if __name__ == "__main__":
    main()
