#!/usr/bin/env python3
"""analyze_macrocycle_reference_convergence.py — Phase-1 GATE: is the REMD cold reference converged?

Rebuilds the (pruned) cyclosporin Fig-10 logic for an arbitrary macrocycle: cumulative basin
populations on the cold replica (replica_00) vs REMD time, a quarter-block drift test (robust to the
anti-phase oscillation that fools a naive first/second-half test), and the Arg-Asp salt-bridge
distance distribution (the suspected slow order parameter for cyclo-RGDfV in implicit solvent).

Decision gate: proceed to the AIS diagnostics only if the basin populations are converged
(quarter-block spread small, no monotonic drift) and the salt bridge is well sampled (visits both
open and closed).

Usage:
  python -m escort_ais.experiments.macrocycle.analyze_macrocycle_reference_convergence --name rgd \
      --remd-dir data/rgd/2026-06-29-rest2-remd-8rep-s0p4-300ns --burn-ns 50
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.cyclosporin_torsion_basins import BasinModel  # noqa: E402
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402


def load_cold(remd_dir: Path, top_pdb: Path, burn_frames: int) -> md.Trajectory:
    d = remd_dir / "replica_00"
    parts = [str(d / "trajectory.dcd")] + [str(p) for p in sorted(d.glob("trajectory_ext*.dcd"))]
    return md.load(parts, top=str(top_pdb))[burn_frames:]


def salt_bridge_indices(smiles: str):
    """Arg side-chain N indices and Asp carboxylate O indices (RDKit==OpenMM identity map)."""
    from rdkit import Chem
    m = Chem.MolFromSmiles(smiles)
    # guanidinium nitrogens (protonated Arg): C bonded to 3 N
    arg_n = set()
    for at in m.GetAtoms():
        if at.GetSymbol() == "C":
            ns = [nb.GetIdx() for nb in at.GetNeighbors() if nb.GetSymbol() == "N"]
            if len(ns) == 3:
                arg_n.update(ns)
    asp_o = set()
    for match in m.GetSubstructMatches(Chem.MolFromSmarts("[CX3](=O)[O-]")):
        asp_o.update([match[1], match[2]])
    return sorted(arg_n), sorted(asp_o)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", default="rgd")
    ap.add_argument("--remd-dir", required=True)
    ap.add_argument("--burn-ns", type=float, default=50.0)
    ap.add_argument("--ns-per-frame", type=float, default=0.01)
    ap.add_argument("--basin-model", default=None, help="defaults to the molecule's backbone model")
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    cfg = load_cfg(args.name)
    model_path = Path(args.basin_model) if args.basin_model else cfg.basin_model_path
    out_dir = Path(args.out_dir) if args.out_dir else ROOT / "results" / args.name / "reference_convergence"
    out_dir.mkdir(parents=True, exist_ok=True)
    burn = int(round(args.burn_ns / args.ns_per_frame))

    model = BasinModel.load(model_path)
    nb = model.n_basins
    cold = load_cold(Path(args.remd_dir), cfg.top_pdb, burn)
    n = cold.n_frames
    t_ns = (np.arange(n) + burn) * args.ns_per_frame
    basin = model.assign(cold)

    # cumulative populations
    cum = np.zeros((n, nb))
    counts = np.zeros(nb)
    for i, b in enumerate(basin):
        counts[b] += 1
        cum[i] = counts / counts.sum()
    final = cum[-1]
    ref_ddF = -np.log(final / final[0])

    # quarter-block drift (robust to anti-phase oscillation)
    qsize = n // 4
    quarters = np.array([np.bincount(basin[i*qsize:(i+1)*qsize], minlength=nb) / max(1, qsize)
                         for i in range(4)])
    qspread = quarters.max(axis=0) - quarters.min(axis=0)   # per-basin range across quarters

    # salt bridge min-distance
    sb_dist = None
    try:
        arg_n, asp_o = salt_bridge_indices(cfg.smiles)
        if arg_n and asp_o:
            pairs = np.array([(a, o) for a in arg_n for o in asp_o])
            d = md.compute_distances(cold, pairs)            # nm, (n, n_pairs)
            sb_dist = d.min(axis=1) * 10.0                   # Angstrom, closest contact
    except Exception as e:  # noqa: BLE001
        print(f"  salt-bridge distance skipped: {e}")

    # ── report ──
    print(f"  molecule={args.name}  n_basins={nb}  cold frames={n} ({t_ns[0]:.0f}-{t_ns[-1]:.0f} ns)")
    print(f"  final cold populations = {np.round(final, 3).tolist()}")
    print(f"  reference ddF (kT)     = {np.round(ref_ddF, 3).tolist()}")
    print(f"  quarter-block pops:")
    for qi in range(4):
        print(f"    Q{qi+1}: {np.round(quarters[qi], 3).tolist()}")
    print(f"  per-basin quarter spread (max-min) = {np.round(qspread, 3).tolist()}")
    converged = bool(qspread.max() < 0.05)
    print(f"  CONVERGENCE GATE: max quarter spread = {qspread.max():.3f}  "
          f"-> {'CONVERGED (<0.05)' if converged else 'NOT converged (>=0.05)'}")
    if sb_dist is not None:
        print(f"  Arg-Asp salt bridge (Angstrom): min={sb_dist.min():.2f} median={np.median(sb_dist):.2f} "
              f"max={sb_dist.max():.2f}; frac closed (<4A) = {(sb_dist < 4.0).mean():.2f}")

    # ── plots ──
    ncol = 3 if sb_dist is not None else 2
    fig, ax = plt.subplots(1, ncol, figsize=(5 * ncol, 4))
    for b in range(nb):
        ax[0].plot(t_ns, cum[:, b], label=f"basin {b}")
    ax[0].set(xlabel="REMD time (ns)", ylabel="cumulative population",
              title=f"{args.name} cold (s=1.0) basin convergence")
    ax[0].legend(fontsize=8)
    ax[1].bar(np.arange(nb) - 0.3, final, width=0.2, label="final")
    for qi in range(4):
        ax[1].bar(np.arange(nb) - 0.1 + 0.2 * qi, quarters[qi], width=0.18, alpha=0.5)
    ax[1].set(xlabel="basin", ylabel="population", title="quarter-block populations")
    if sb_dist is not None:
        ax[2].hist(sb_dist, bins=40)
        ax[2].set(xlabel="Arg-Asp min distance (Å)", ylabel="count", title="salt-bridge sampling")
    fig.tight_layout()
    fig.savefig(out_dir / "fig_reference_convergence.png", dpi=130)
    np.savez(out_dir / "reference_convergence.npz", t_ns=t_ns, cum=cum, basin=basin,
             quarters=quarters, final=final, ref_ddF=ref_ddF,
             salt_bridge_dist=sb_dist if sb_dist is not None else np.array([]))
    print(f"  -> {out_dir.relative_to(ROOT)}/fig_reference_convergence.png")


if __name__ == "__main__":
    main()
