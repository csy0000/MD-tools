#!/usr/bin/env python3
"""make_reservoir_reweight_figs.py — per-torsion cold vs REMD vs STATE-reweighted histograms.

For each RGD cold reservoir (RMSD- and torsion-seeded), for the 15 highest-divergence backbone
torsions, three distributions:
  (blue)  cold reservoir, unweighted (each frame equal)
  (green) cold reservoir, PER-CONFIGURATION STATE-reweighted: cluster the cold frames into microstates
          (PCA(8)->KMeans(24)), give each microstate S the forward-AIS landing weight p_land(S)
          (softmax of the landing importance weights of forward landings assigned to S), and weight each
          cold frame by p_land(S)/n_cold(S).  Trapped artifact microstates (no landing support) -> ~0
          weight.  This is fix #3 of the artifact report.
  (red)   REMD cold rung (equilibrium reference).

State-reweighting suppresses the spurious cold-only peaks toward REMD; per-SEED reweighting does NOT
(it collapses to a few high-weight seeds and makes JS worse — see docs/RGD_cold_basin_problem).
Both reservoirs share the same forward-AIS landings.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.make_reservoir_reweight_figs
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets, BasinModel  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

OUT = ROOT / "results/rgd/report"
BINS = np.linspace(-180, 180, 73)
NMICRO = 24
FWD = ROOT / "data/rgd/2026-06-29-reservoir-sw-s0p25/step_forward_ais"   # shared forward-AIS landings
REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
BASIN = ROOT / "data/rgd/basins_tica/basin_model_backbone.pkl"
RESERVOIRS = {
    "rmsd": ROOT / "data/rgd/2026-06-29-reservoir-sw-s0p25",
    "torsion": ROOT / "data/rgd/2026-07-06-reservoir-torsion-s0p25",
}
TAGS = {2: "dih2", 6: "tor6", 8: "tor8", 12: "dih12", 14: "dih14(sep)"}
NICE = {"rmsd": "RMSD-seeded", "torsion": "torsion-seeded"}


def _js(h1, h2):
    a = h1 / h1.sum() + 1e-12
    b = h2 / h2.sum() + 1e-12
    m = 0.5 * (a + b)
    return 0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m))


def main():
    cfg = load_cfg("rgd")
    top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    fz = BasinModel.load(str(BASIN))

    logw = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].to_numpy()
    landX = featurize(md.load_dcd(str(FWD / "ais_final_coordinates.dcd"), top=top), q)
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 3000)
    remdd = np.degrees(md.compute_dihedrals(remd, q))
    remdX = featurize(remd, q)

    for tag, res in RESERVOIRS.items():
        seeds = sorted(glob.glob(str(res / "cold_md_10ns/seed_*/trajectory.dcd")))
        Xseed = [featurize(md.load_dcd(s, top=top)[50:], q) for s in seeds]
        Xall = np.concatenate(Xseed)
        DIH = np.concatenate([np.degrees(md.compute_dihedrals(md.load_dcd(s, top=top)[50:], q)) for s in seeds])

        # microstates on the cold frames; landings -> states; state landing-weight p_land(S)
        pca = PCA(8, random_state=0).fit(Xall)
        scal = StandardScaler().fit(pca.transform(Xall))
        km = KMeans(NMICRO, n_init=10, random_state=0).fit(scal.transform(pca.transform(Xall)))
        micro_land = km.predict(scal.transform(pca.transform(landX)))
        micro_cold = km.predict(scal.transform(pca.transform(Xall)))
        micro_remd = km.predict(scal.transform(pca.transform(remdX)))
        lp = np.full(NMICRO, -np.inf)
        for S in range(NMICRO):
            m = micro_land == S
            if m.any():
                lp[S] = logsumexp(logw[m])
        lp -= logsumexp(lp)
        p_land = np.exp(lp)
        ncold = np.bincount(micro_cold, minlength=NMICRO)
        W = np.array([p_land[S] / ncold[S] if ncold[S] > 0 else 0.0 for S in micro_cold])
        W /= W.sum()

        p_remd = np.bincount(micro_remd, minlength=NMICRO) / len(remd)
        suppressed = sum(p_land[S] for S in range(NMICRO) if p_remd[S] < 0.005)

        nq = q.shape[0]
        jsu = np.array([_js(np.histogram(DIH[:, j], BINS, density=True)[0],
                            np.histogram(remdd[:, j], BINS, density=True)[0]) for j in range(nq)])
        jsw = np.array([_js(np.histogram(DIH[:, j], BINS, weights=W)[0],
                            np.histogram(remdd[:, j], BINS, density=True)[0]) for j in range(nq)])

        fig, axes = plt.subplots(3, 5, figsize=(16, 8.5))
        for j, ax in zip(np.argsort(-jsu), axes.flat):
            ax.hist(DIH[:, j], BINS, density=True, alpha=0.45, color="#4477AA", label="cold (unweighted)")
            hw, _ = np.histogram(DIH[:, j], BINS, weights=W, density=True)
            ax.stairs(hw, BINS, color="#117733", lw=2.2, label="cold (STATE-reweighted)")
            ax.hist(remdd[:, j], BINS, density=True, histtype="step", lw=2.0, color="#CC3311", label="REMD")
            ax.set_title(f"tor {j} {TAGS.get(j,'')}  JS: {jsu[j]:.3f}→{jsw[j]:.3f}", fontsize=9)
            ax.set_xlim(-180, 180); ax.set_yticks([])
            if j == np.argsort(-jsu)[0]:
                ax.legend(fontsize=8)
        fig.suptitle(f"[{NICE[tag]}] cold reservoir: unweighted vs STATE-reweighted vs REMD  "
                     f"(mean JS {jsu.mean():.3f} → {jsw.mean():.3f}; artifact-state weight suppressed = {suppressed:.3f})",
                     fontsize=13, y=1.005)
        fig.tight_layout()
        p = OUT / f"fig_{tag}_cold_stateweighted_vs_remd.png"
        fig.savefig(p, dpi=140, bbox_inches="tight"); plt.close(fig)

        # per-microstate population vs REMD: before (unweighted) and after (state-reweighted)
        pu = ncold / ncold.sum()          # cold unweighted population per microstate
        pw = p_land                       # state-reweighted population (== forward-AIS landing weight)
        pr = p_remd                       # REMD population per microstate
        figs, axs = plt.subplots(figsize=(6.4, 6.4))
        axs.plot([1e-4, 1], [1e-4, 1], "k--", lw=0.8, zorder=1)
        for S in range(NMICRO):
            if pu[S] > 0 or pw[S] > 0:
                axs.annotate("", xy=(max(pw[S], 1e-4), max(pr[S], 1e-4)),
                             xytext=(max(pu[S], 1e-4), max(pr[S], 1e-4)),
                             arrowprops=dict(arrowstyle="->", color="0.65", lw=0.7), zorder=2)
        axs.scatter(pu + 1e-4, pr + 1e-4, s=48, c="#4477AA", edgecolor="k", lw=0.4,
                    label="cold unweighted (before)", zorder=3)
        axs.scatter(pw + 1e-4, pr + 1e-4, s=48, c="#117733", edgecolor="k", lw=0.4,
                    label="state-reweighted (after)", zorder=3)
        axs.set(xscale="log", yscale="log", xlim=(8e-4, .6), ylim=(8e-4, .6),
                xlabel="reservoir microstate population", ylabel="REMD microstate population",
                title=f"[{NICE[tag]}] microstate population vs REMD\nbefore (blue) $\\to$ after reweighting (green); on the diagonal = matches REMD")
        axs.legend(loc="upper left", fontsize=9)
        figs.tight_layout()
        ps = OUT / f"fig_{tag}_states_reweighted_vs_remd.png"
        figs.savefig(ps, dpi=140); plt.close(figs)

        print(f"[{tag}] meanJS {jsu.mean():.3f}->{jsw.mean():.3f}  artifact-wt-suppressed {suppressed:.3f}  -> {p.name}, {ps.name}",
              file=sys.stderr)


if __name__ == "__main__":
    main()
