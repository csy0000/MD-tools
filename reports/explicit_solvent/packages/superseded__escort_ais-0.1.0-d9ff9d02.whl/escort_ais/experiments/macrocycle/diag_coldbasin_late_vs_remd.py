import warnings; warnings.filterwarnings('ignore'); import numpy as np, glob
import mdtraj as md
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
from escort_ais.common.macrocycle_cfg import load as load_cfg
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets, BasinModel
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble
cfg=load_cfg('rgd'); top=str(cfg.top_pdb); q,_,_=load_quartets(cfg.topo,'backbone')
fz=BasinModel.load('data/rgd/basins_tica/basin_model_backbone.pkl')
seeds=sorted(glob.glob('data/rgd/2026-06-29-reservoir-sw-s0p25/cold_md_10ns/seed_*/trajectory.dcd'))
early=[]; late=[]; e_gt=[]; l_gt=[]
for s in seeds:
    t=md.load_dcd(s,top=top)
    te=t[50:5000]; tl=t[5000:10000]
    early.append(np.degrees(md.compute_dihedrals(te,q))); late.append(np.degrees(md.compute_dihedrals(tl,q)))
    e_gt.append(fz.assign(te)); l_gt.append(fz.assign(tl))
early=np.concatenate(early); late=np.concatenate(late)
egt=np.concatenate(e_gt); lgt=np.concatenate(l_gt)
remd=load_remd_ensemble(Path('data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns'),'replica_00',cfg.top_pdb,3000)
remdd=np.degrees(md.compute_dihedrals(remd,q)); rgt=fz.assign(remd)
nq=q.shape[0]; bins=np.linspace(-180,180,73)
def js(a,b):
    ha,_=np.histogram(a,bins,density=True); hb,_=np.histogram(b,bins,density=True)
    ha=ha/ha.sum()+1e-12; hb=hb/hb.sum()+1e-12; m=.5*(ha+hb); return .5*np.sum(ha*np.log(ha/m))+.5*np.sum(hb*np.log(hb/m))
jse=np.array([js(early[:,j],remdd[:,j]) for j in range(nq)])
jsl=np.array([js(late[:,j],remdd[:,j]) for j in range(nq)])
print(f"minor frac: cold-early {egt.mean():.3f}  cold-late {lgt.mean():.3f}  REMD {rgt.mean():.3f}",flush=True)
print(f"mean JS(vs REMD): early {jse.mean():.3f}  late {jsl.mean():.3f}  ({'IMPROVED' if jsl.mean()<jse.mean() else 'no improvement'})",flush=True)
tags={2:'dih2',6:'tor6',8:'tor8',12:'dih12',14:'dih14(sep)'}
fig,axes=plt.subplots(3,5,figsize=(15,8))
for j,ax in zip(np.argsort(-jsl),axes.flat):
    ax.hist(early[:,j],bins,density=True,alpha=.4,color='#88AACC',label='cold 0-5ns')
    ax.hist(late[:,j],bins,density=True,histtype='step',lw=1.6,color='#117733',label='cold 5-10ns')
    ax.hist(remdd[:,j],bins,density=True,histtype='step',lw=1.6,color='#CC3311',label='REMD')
    ax.set_title(f"tor {j} {tags.get(j,'')}\nJS: early {jse[j]:.3f} -> late {jsl[j]:.3f}",fontsize=8)
    ax.set_xlim(-180,180); ax.set_yticks([])
    if j==np.argsort(-jsl)[0]: ax.legend(fontsize=7)
fig.suptitle('Cold-MD later 5 ns vs earlier 5 ns vs REMD (does the reservoir relax toward equilibrium?)',fontsize=13,y=1.01)
fig.tight_layout()
p='results/rgd/report/fig_cold_late_vs_remd.png'; fig.savefig(p,dpi=140,bbox_inches='tight'); print('saved',p,flush=True)
print("\nper-torsion JS early->late (vs REMD):")
for j in np.argsort(-jsl): print(f"  tor {j:2d} {tags.get(j,''):>10}: {jse[j]:.3f} -> {jsl[j]:.3f}  {'better' if jsl[j]<jse[j] else 'worse '}")
