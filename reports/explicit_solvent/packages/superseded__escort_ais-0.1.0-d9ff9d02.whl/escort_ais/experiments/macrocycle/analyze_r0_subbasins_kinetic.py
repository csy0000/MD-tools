#!/usr/bin/env python3
"""analyze_r0_subbasins_kinetic.py — find the KINETIC sub-basins inside R0 (the major state) via TICA on hot MD.

R0's sub-states are barrier-separated but thermodynamically diffuse, so geometric density clustering (HDBSCAN in
torsion / PC space) cannot isolate them (this session's earlier probes). The continuous hot single-walker
(s=0.25, T_eff=1200 K, 500 ns, 10 ps/frame) DOES cross R0's internal barriers, so TICA on the hot trajectory
restricted to R0 recovers the slow within-R0 coordinates. Pipeline:
  (1) ITS diagnostic — within-R0 MSM implied timescales vs lag: is there a SLOW internal mode (i.e. real, separable
      sub-basins), or is R0 one fast-mixing basin?
  (2) TICA on hot-R0 -> slow coordinates; k-means micro-states -> reversible MSM -> PCCA+ -> sub-basins;
  (3) each sub-basin's defining torsions + its population in REMD-R0 (physical equilibrium) and hot-R0 (scaled).

COORDINATES come from hot (it has the transitions); POPULATIONS come from REMD (equilibrium). s=0.25 lowers
barriers, so hot timescales are a LOWER BOUND on the physical sub-basin separation.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_r0_subbasins_kinetic
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.msm_estimation import fit_tica, cluster_kmeans, fit_reversible_msm, pcca_basins  # noqa: E402
from escort_ais.systems.torsion_features import build_lagged_pairs  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_sw_hot, load_remd_ensemble  # noqa: E402

HOT = ROOT / "data/rgd/2026-06-29-ref-singlewalker-hot-s0p25-300ns/trajectory.dcd"
REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
OUT = ROOT / "results/rgd/report"
FPN = 100                    # 10 ps/frame -> 100 frames/ns
SEP = 14                     # major/minor separator dihedral


def in_major(D):
    return (D[:, SEP] >= -180) & (D[:, SEP] <= -15)


def cmean(a):
    r = np.radians(a)
    return float(np.degrees(np.arctan2(np.sin(r).mean(), np.cos(r).mean())))


def r0_segments(mask, min_len):
    """Contiguous runs of `mask` (each an uninterrupted stay in R0) with length >= min_len -> list of index arrays."""
    idx = np.where(mask)[0]
    if len(idx) == 0:
        return []
    brk = np.where(np.diff(idx) > 1)[0]
    starts = np.concatenate([[0], brk + 1]); ends = np.concatenate([brk + 1, [len(idx)]])
    return [idx[s:e] for s, e in zip(starts, ends) if e - s >= min_len]


def process(name="rgd", n_micro=60, n_sub=3, tica_lag=20, tica_dim=4):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone"); Q = np.asarray(q)

    # --- hot single-walker (continuous, crosses R0's internal barriers) ---
    hot = load_sw_hot(HOT, cfg.top_pdb)
    Xh = featurize(hot, q); Dh = np.degrees(md.compute_dihedrals(hot, Q))
    segs = r0_segments(in_major(Dh), min_len=2 * tica_lag + 2)
    rows = np.concatenate(segs)
    walker = np.concatenate([np.full(len(s), w) for w, s in enumerate(segs)])
    fid = np.concatenate([np.arange(len(s)) for s in segs])
    Xr0 = Xh[rows]; Dr0 = Dh[rows]
    seg_len = [len(s) for s in segs]
    print(f"hot R0: {len(rows)} frames in {len(segs)} segments "
          f"(median {int(np.median(seg_len))}, max {max(seg_len)} frames)", file=sys.stderr)

    # --- TICA on hot-R0 (slow within-R0 coordinates) ---
    t_idx, t_lag_idx = build_lagged_pairs(walker, fid, tica_lag)
    tica = fit_tica(Xr0, t_idx, t_lag_idx, n_dims=tica_dim, scaling="kinetic_map")
    Yr0 = tica.projection                                             # (n_r0, tica_dim) hot-R0 in TICA space

    # --- (1) ITS diagnostic: micro-states in TICA space, reversible MSM implied timescales vs lag ---
    micro = cluster_kmeans(Yr0, n_micro, seed=0)
    dtrajs = [micro[walker == w] for w in range(len(segs))]
    its_lags = [1, 2, 5, 10, 20, 40, 80, 160]
    its = {}
    for L in its_lags:
        try:
            ts = np.asarray(fit_reversible_msm(dtrajs, lag=L).model.timescales())
            its[L] = [round(float(t) / FPN, 3) for t in ts[:3]]       # t2,t3,t4 in ns
        except Exception as e:
            its[L] = [None, None, None]
            print(f"  ITS lag {L}: {e}", file=sys.stderr)

    # --- (2) sub-basins: MSM at tica_lag -> PCCA+ ---
    msm = pcca_basins(fit_reversible_msm(dtrajs, lag=tica_lag), n_basins=n_sub)
    active = np.asarray(msm.model.count_model.state_symbols, dtype=int)
    micro2basin = np.full(n_micro, -1, int); micro2basin[active] = msm.basin_of_microstate
    cent = np.array([Yr0[micro == m].mean(0) for m in range(n_micro)])   # micro centroids in TICA space
    for m in np.where(micro2basin < 0)[0]:                               # inactive micro -> nearest active basin
        micro2basin[m] = micro2basin[active[np.argmin(np.linalg.norm(cent[active] - cent[m], axis=1))]]
    basin_hot = micro2basin[micro]                                      # sub-basin of each hot-R0 frame

    # --- (3) populations: project REMD-R0 onto the SAME TICA, assign to nearest micro -> sub-basin ---
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    Xe = featurize(remd, q); De = np.degrees(md.compute_dihedrals(remd, Q))
    er0 = in_major(De)
    Ye = tica.model.transform(Xe[er0]); De0 = De[er0]
    micro_e = np.argmin(((Ye[:, None, :] - cent[None, :, :]) ** 2).sum(2), axis=1)
    basin_remd = micro2basin[micro_e]

    subs = []
    for b in range(n_sub):
        mh = basin_hot == b; me = basin_remd == b
        subs.append(dict(sub=b, hot_pop=round(float(mh.mean()), 3), remd_pop=round(float(me.mean()), 3),
                         dih2=round(cmean(Dr0[mh, 2])), dih4=round(cmean(Dr0[mh, 4])),
                         dih1=round(cmean(Dr0[mh, 1])), dih9=round(cmean(Dr0[mh, 9]))))
    subs.sort(key=lambda s: -s["remd_pop"])
    t2_plateau = max((v[0] for v in its.values() if v[0]), default=0.0)
    verdict = ("R0 has kinetically real sub-basins" if t2_plateau > 5 * (tica_lag / FPN)
               else "R0 is ~one fast-mixing basin (no slow internal mode)")
    res = dict(name=name, n_r0_frames=int(len(rows)), n_segments=len(segs),
               median_segment_ns=round(float(np.median(seg_len)) / FPN, 2),
               tica_lag_ns=tica_lag / FPN, tica_eigenvalues=[round(float(e), 3) for e in tica.eigenvalues],
               n_micro=n_micro, n_sub=n_sub, its_ns=its, slowest_t2_ns=round(t2_plateau, 3),
               subbasins=subs, verdict=verdict)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{name}_r0_subbasins_kinetic.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({k: res[k] for k in ("n_r0_frames", "n_segments", "tica_eigenvalues", "its_ns",
                                          "slowest_t2_ns", "subbasins", "verdict")}, indent=2), file=sys.stderr)
    make_figure(name, its, its_lags, Yr0, basin_hot, Ye, subs, n_sub, res)
    return res


def make_figure(name, its, its_lags, Yr0, basin_hot, Ye, subs, n_sub, res):
    cols = plt.cm.tab10(np.linspace(0, 1, max(n_sub, 3)))
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))
    # (A) ITS: t2/t3/t4 vs lag, with the t=lag resolution line
    lags_ns = np.array(its_lags) / FPN
    for k, c, lab in [(0, "C0", "t2 (slowest)"), (1, "C1", "t3"), (2, "C2", "t4")]:
        y = [its[L][k] for L in its_lags]
        ax[0].plot(lags_ns, y, "-o", c=c, label=lab)
    ax[0].plot(lags_ns, lags_ns, "k--", lw=1, alpha=0.6, label="t = lag (resolution limit)")
    ax[0].set_xscale("log"); ax[0].set_yscale("log")
    ax[0].set_xlabel("MSM lag (ns)"); ax[0].set_ylabel("implied timescale (ns)")
    ax[0].set_title(f"within-R0 implied timescales (hot s=0.25)\nplateau above the line = real internal barrier",
                    fontsize=10)
    ax[0].legend(fontsize=8)
    # (B) TICA IC1-IC2: hot-R0 coloured by sub-basin, REMD-R0 grey background
    ax[1].scatter(Ye[::5, 0], Ye[::5, 1], s=3, c="0.8", alpha=0.4, zorder=1, label="REMD-R0")
    for b in range(n_sub):
        m = basin_hot == b
        ax[1].scatter(Yr0[m, 0][::3], Yr0[m, 1][::3], s=4, color=cols[b], alpha=0.4, zorder=2)
    ax[1].set_xlabel("TICA IC1"); ax[1].set_ylabel("TICA IC2")
    ax[1].set_title("hot-R0 in TICA space, coloured by PCCA+ sub-basin\n(grey = REMD-R0 projected)", fontsize=10)
    ax[1].legend(fontsize=8)
    # (C) sub-basin populations REMD vs hot, x-labelled by defining torsions
    xb = np.arange(len(subs)); bw = 0.38
    ax[2].bar(xb - bw / 2, [s["remd_pop"] for s in subs], bw, color="0.6", label="REMD-R0 (physical)")
    ax[2].bar(xb + bw / 2, [s["hot_pop"] for s in subs], bw, color="C0", label="hot-R0 (s=0.25)")
    ax[2].set_xticks(xb)
    ax[2].set_xticklabels([f"sub{s['sub']}\nd2={s['dih2']:.0f} d4={s['dih4']:.0f}" for s in subs], fontsize=8)
    ax[2].set_ylabel("within-R0 population"); ax[2].legend(fontsize=8)
    ax[2].set_title(f"R0 sub-basin populations\n{res['verdict']}", fontsize=10)
    fig.suptitle(f"{name}: kinetic sub-basins of R0 (major) — TICA on hot MD, populations from REMD  "
                 f"[slowest t2 = {res['slowest_t2_ns']:.2f} ns]", fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / f"fig_{name}_r0_subbasins_kinetic.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_r0_subbasins_kinetic.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
