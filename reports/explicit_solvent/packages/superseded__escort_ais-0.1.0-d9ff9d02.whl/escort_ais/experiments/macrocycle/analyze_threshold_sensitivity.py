#!/usr/bin/env python3
"""analyze_threshold_sensitivity.py — is the single-torsion major/minor split a well-defined 2-state
partition, or does the boundary cut through a populated region?

A good state-defining coordinate has its dividing surface in a LOW-density valley (a free-energy barrier),
so (i) populations are insensitive to the exact threshold, and (ii) configs rarely sit on / cross the
boundary. This checks, per compound, on the state-defining backbone torsion:

  (1) BARRIER CLEARANCE: REMD density at each window edge / peak REMD density. ~0 = deep valley (good);
      order-1 = boundary sits on a populated shoulder (bad -> degenerate, threshold-sensitive).
  (2) THRESHOLD SENSITIVITY: ddF_REMD = -ln(p_minor/p_major) as the window is slid by delta in
      [-30..+30] deg. Flat = robust state; steep = ill-defined split.
  (3) BOUNDARY CROSSING: fraction of the cold-MD seeds whose 5 ns run has frames on BOTH sides of the
      threshold (straddles/crosses it) -- if large, "initiated == trapped in one basin" is false and the
      torsion is not a genuine slow coordinate.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_threshold_sensitivity
"""
from __future__ import annotations

import glob
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import mdtraj as md
import numpy as np

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import load_quartets, BasinModel  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
REMD = {"rgd": ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns",
        "cilengitide": ROOT / "data/cilengitide/2026-07-03-rest2-remd-6rep-s0p25-500ns",
        "rgd_redPheVal": ROOT / "data/rgd_redPheVal/2026-07-03-rest2-remd-6rep-s0p25-500ns"}
NICE = {"rgd": "cyclo-RGDfV", "cilengitide": "cilengitide", "rgd_redPheVal": "rgd_redPheVal"}


def wrap(a):
    return (a + 180) % 360 - 180


def in_window(deg, lo, hi):
    return (deg >= lo) & (deg <= hi) if lo <= hi else (deg >= lo) | (deg <= hi)


def ddF(pmin):
    pmin = min(max(float(pmin), 1e-9), 1 - 1e-9)
    return -float(np.log(pmin / (1 - pmin)))


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb)
    q, _, _ = load_quartets(cfg.topo, "backbone")
    model = BasinModel.load(cfg.basin_model_path)
    qi, lo, hi = model.rules[0]; qi = int(qi)

    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    remd_tor = np.degrees(md.compute_dihedrals(remd, q))[:, qi]

    # (1) barrier clearance: density at each edge / peak density (kde-free, fine histogram)
    edges = np.linspace(-180, 180, 181)
    dens, _ = np.histogram(remd_tor, edges, density=True)
    ctr = 0.5 * (edges[:-1] + edges[1:])
    peak = dens.max()
    def dens_at(x):
        return float(dens[np.argmin(np.abs(wrap(ctr - x)))])
    clear_lo = dens_at(lo) / peak
    clear_hi = dens_at(hi) / peak

    # (2) threshold sensitivity: slide the whole window by delta
    print(f"\n===== {NICE[name]}  (tor#{qi}, minor window ({lo:g},{hi:g})) =====")
    print(f"  (1) barrier clearance (REMD density at edge / peak): "
          f"lo={clear_lo:.2f}, hi={clear_hi:.2f}   (~0 deep valley = good; ~1 populated shoulder = bad)")
    print(f"  (2) ddF_REMD vs threshold shift delta:")
    base = None
    for d in (-30, -20, -10, 0, 10, 20, 30):
        pmin = float(in_window(remd_tor, wrap(lo + d), wrap(hi + d)).mean())
        val = ddF(pmin)
        if d == 0:
            base = val
        print(f"       delta={d:+3d} deg: p_minor={pmin:.3f}  ddF={val:+.2f}")
    # sensitivity slope near 0
    p_m10 = ddF(float(in_window(remd_tor, wrap(lo - 10), wrap(hi - 10)).mean()))
    p_p10 = ddF(float(in_window(remd_tor, wrap(lo + 10), wrap(hi + 10)).mean()))
    print(f"       -> ddF swing over +/-10 deg = {abs(p_p10 - p_m10):.2f} kT  (base {base:+.2f})")

    # (3) boundary crossing: fraction of cold seeds with frames on BOTH sides
    strad = 0; tot = 0; frac_minor = []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        tr = md.load_dcd(s, top=top)[50:]
        tor = np.degrees(md.compute_dihedrals(tr, q))[:, qi]
        fm = in_window(tor, lo, hi).mean()
        frac_minor.append(fm); tot += 1
        if 0.05 < fm < 0.95:      # meaningfully on both sides
            strad += 1
    frac_minor = np.array(frac_minor)
    print(f"  (3) cold seeds crossing the threshold (5-95% split): {strad}/{tot} "
          f"({100*strad/tot:.0f}%)   [pure-major<5%: {(frac_minor<0.05).sum()}, "
          f"pure-minor>95%: {(frac_minor>0.95).sum()}]")


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        process(name)


if __name__ == "__main__":
    main()
