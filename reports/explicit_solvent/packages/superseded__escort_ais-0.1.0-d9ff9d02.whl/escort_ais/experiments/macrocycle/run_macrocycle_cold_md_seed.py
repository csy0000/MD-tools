#!/usr/bin/env python3
"""run_macrocycle_cold_md_seed.py — one macrocycle cold-MD seed (s=1.0, GBn2/mbondi3) as a standalone process.

Molecule-generic (via macrocycle_cfg), device-pinned. Thin CLI around build_macrocycle_cold_reservoir's
build_cold_system(cfg) + run_cold_seed so N long cold-MD runs can be fanned across GPUs, each its own CUDA
context. Writes <out-dir>/seed_<sid>/{trajectory.dcd, state.csv, final_structure.pdb}.

    python -m escort_ais.experiments.macrocycle.run_macrocycle_cold_md_seed --name rgd \
        --seed-pdb seed.pdb --out-dir <dir> --sid 0 --prod-ps 100000 --platform CUDA --device 0
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from openmm import unit
from openmm.app import PDBFile

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.build_macrocycle_cold_reservoir import build_cold_system, run_cold_seed  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True)
    ap.add_argument("--seed-pdb", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--sid", type=int, required=True)
    ap.add_argument("--prod-ps", type=float, default=100000.0)   # 100 ns default
    ap.add_argument("--save-ps", type=float, default=1.0)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device", type=int, default=0)
    args = ap.parse_args()

    cfg = load_cfg(args.name)
    xyz = np.array(PDBFile(args.seed_pdb).getPositions().value_in_unit(unit.nanometer))
    st, system = build_cold_system(cfg)
    run_cold_seed(args.sid, xyz, st, system, Path(args.out_dir), args.prod_ps,
                  args.platform, args.device, save_ps=args.save_ps)


if __name__ == "__main__":
    main()
