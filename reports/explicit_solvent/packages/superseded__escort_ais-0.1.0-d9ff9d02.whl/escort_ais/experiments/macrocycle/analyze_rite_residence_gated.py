#!/usr/bin/env python3
"""analyze_rite_residence_gated.py — residence-gated RITE (PC1) + a RITE-on-REMD control.

Two experiments, both within each metastable basin B (TICA-on-hot, cold-ordered), backbone sin/cos features,
RITE on PC1 (1-D); JS scored on KSUB sub-wells (KMeans on REMD+cold in B). Reservoir = 86 x 5 ns cold seeds
(strided 5 ps/frame, as in analyze_rite_local_equilibrium).

EXP-1  residence-gated RITE. Per seed compute the longest continuous SUB-WELL residence (the frozen-vs-mixing
  axis: long residence = frozen/disjoint, short = internally mixing). Sweep a threshold T (ns) and keep either
  the FROZEN seeds (residence > T, as asked) or the MIXING seeds (residence < T). On the kept frames report the
  pooled within-B JS to REMD(.|B) for simple average (unweighted) AND RITE-PC1. Question: does gating by
  residence get closer to LEQ, and does RITE add anything over simple average on the gated set?

EXP-2  RITE-on-REMD control. Run RITE-PC1 on segments built from consecutive REMD-in-B frames, and check
  whether the RITE-reweighted REMD still matches the (unweighted) REMD distribution — vs the REMD self-floor
  (two random halves). If RITE-PC1 inflates JS on data that is ALREADY at equilibrium, PC1 is a poor RITE
  coordinate intrinsically; if it stays ~floor, PC1-RITE is benign and the cold failure is the data
  (disconnection), not the coordinate. Caveat: REMD replica_00 is demuxed, so its "segments" are not true
  dynamical transitions — this bounds how meaningful a positive result is.

    conda activate escort-ais && python -m escort_ais.experiments.macrocycle.analyze_rite_residence_gated [name...]
"""
from __future__ import annotations

import glob
import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np
import mdtraj as md
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_rite_local_equilibrium import HOT, REMD, NSTATE, STRIDE, rite_weights, _js  # noqa: E402
from escort_ais.analysis.analyze_js_vs_residence import _maxrun  # noqa: E402

BE = ROOT / "data/rgd/diagnostics/bais_eval"
KSUB, MINSEED, MINPOOL = 12, 100, 300
PS_PER_FRAME = STRIDE * 1.0                                          # strided cold: 5 ps/frame
T_LIST = [0.0, 1.0, 2.0, 3.0, 4.0]                                  # ns residence thresholds
RITE_CFG = dict(clusters=20, iters=100, sf=0.01, sfnn=0.05)   # iters must be divisible by iters//20 (rite_weight h5 buffer bug)


def _hist(km, X, w=None):
    return np.bincount(km.predict(X), minlength=km.n_clusters, weights=w).astype(float)


def _rite_pc1(Xc, from_idx, to_idx, tag):
    """RITE-PC1 per-frame weights over Xc given within-set lag-1 segments."""
    R = PCA(1, random_state=0).fit(Xc).transform(Xc)
    return rite_weights(R[from_idx], R[to_idx], from_idx, len(Xc), tag, cfg=RITE_CFG)


def process(name):
    cfg = load_cfg(name); top = str(cfg.top_pdb); q, _, _ = load_quartets(cfg.topo, "backbone")
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NSTATE, lag=20, n_tic=4,
                                   burn_frames=1000, stride=2, seed=0)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    p0 = np.bincount(model.assign(remd), minlength=NSTATE).astype(float); p0 /= p0.sum()
    perm = np.argsort(-p0); inv = np.empty(NSTATE, int); inv[perm] = np.arange(NSTATE); p_remd = p0[perm]
    rstate = inv[model.assign(remd)]; remdX = featurize(remd, q)
    seedX, seedst = [], []
    for s in sorted(glob.glob(str(BE / name / "cold_md/seed_*/trajectory.dcd"))):
        tr = md.load_dcd(s, top=top)[50::STRIDE]
        seedX.append(featurize(tr, q)); seedst.append(inv[model.assign(tr)])
    dom = np.array([np.bincount(st, minlength=NSTATE).argmax() for st in seedst])

    out = {"name": name, "ksub": KSUB, "rite": RITE_CFG, "t_list": T_LIST, "basins": []}
    for B in range(NSTATE):
        if p_remd[B] < 0.01:
            continue
        homed = np.where(dom == B)[0]
        Xr = remdX[rstate == B]
        if len(Xr) < MINPOOL or len(homed) < 2:
            continue
        # sub-wells (residence + JS scoring) on REMD + all homed cold-in-B frames
        allcold = np.concatenate([seedX[i][seedst[i] == B] for i in homed])
        km = KMeans(min(KSUB, len(Xr) // 25 + 2), n_init=6, random_state=0).fit(np.concatenate([Xr, allcold]))
        pr = _hist(km, Xr)
        # per-seed within-B frames + longest sub-well residence (ns)
        seeds = []
        for sid in homed:
            Xs = seedX[sid][seedst[sid] == B]
            if len(Xs) < MINSEED:
                continue
            res_ns = _maxrun(km.predict(Xs)) * PS_PER_FRAME / 1000.0
            seeds.append((sid, Xs, res_ns))
        res_all = np.array([r for _, _, r in seeds])
        rec = {"state": B, "p_remd": round(float(p_remd[B]), 3), "n_seeds": len(seeds),
               "res_min": round(float(res_all.min()), 2), "res_med": round(float(np.median(res_all)), 2),
               "res_max": round(float(res_all.max()), 2), "sweep": []}

        def pool_and_score(keep, tag):
            Xs_list = [s[1] for s in keep]
            if not Xs_list:
                return None
            fr, base = [], 0
            for Xs in Xs_list:
                if len(Xs) > 1:
                    fr.append(base + np.arange(len(Xs) - 1)); base += len(Xs)
            Xc = np.concatenate(Xs_list); from_idx = np.concatenate(fr); to_idx = from_idx + 1
            if len(Xc) < MINPOOL:
                return None
            ju = _js(_hist(km, Xc), pr)
            wf = _rite_pc1(Xc, from_idx, to_idx, tag)
            jr = _js(_hist(km, Xc, wf), pr)
            return dict(n_seeds=len(keep), n_frames=int(len(Xc)),
                        js_unweighted=round(ju, 4), js_rite_pc1=round(jr, 4))

        for T in T_LIST:
            frozen = [s for s in seeds if s[2] > T]                 # keep residence > T (as asked)
            mixing = [s for s in seeds if s[2] <= T] if T > 0 else []  # keep residence <= T (mixing)
            rec["sweep"].append(dict(
                T=T,
                keep_gt=pool_and_score(frozen, f"{name}_S{B}_gt{T}"),
                keep_le=pool_and_score(mixing, f"{name}_S{B}_le{T}") if T > 0 else None))
        out["basins"].append(rec)

        # EXP-2: RITE-PC1 on REMD itself (segments = consecutive REMD-in-B frames)
        nr = len(Xr); fr = np.arange(nr - 1); to = fr + 1
        wf_r = _rite_pc1(Xr, fr, to, f"{name}_S{B}_remd")
        idx = np.random.default_rng(0).permutation(nr); h = nr // 2
        floor = _js(_hist(km, Xr[idx[:h]]), _hist(km, Xr[idx[h:2 * h]]))
        js_remd_rite = _js(_hist(km, Xr, wf_r), pr)                  # RITE-reweighted REMD vs unweighted REMD
        rec["remd_control"] = dict(self_floor=round(floor, 4), js_rite_vs_self=round(js_remd_rite, 4),
                                   ess=round(float(wf_r.sum() ** 2 / (nr * (wf_r ** 2).sum())), 3))
        print(f"  [{name} S{B}] pop {p_remd[B]:.2f} | residence ns min/med/max "
              f"{res_all.min():.1f}/{np.median(res_all):.1f}/{res_all.max():.1f} | "
              f"REMD-control: RITE-PC1 vs self = {js_remd_rite:.4f} (floor {floor:.4f}, ESS {rec['remd_control']['ess']})",
              file=sys.stderr)
        for sw in rec["sweep"]:
            g, l = sw["keep_gt"], sw["keep_le"]
            gg = f"n={g['n_seeds']:2d} unw={g['js_unweighted']:.3f} rite={g['js_rite_pc1']:.3f}" if g else "—"
            ll = f"n={l['n_seeds']:2d} unw={l['js_unweighted']:.3f} rite={l['js_rite_pc1']:.3f}" if l else "—"
            print(f"     T={sw['T']:.1f}ns  keep res>T: {gg}   |  keep res<=T: {ll}", file=sys.stderr)

    (BE / name / "rite_residence_gated.json").write_text(json.dumps(out, indent=2))
    return out


def main():
    for name in (sys.argv[1:] or ["rgd", "cilengitide", "rgd_redPheVal"]):
        print(f"\n===== {name} =====", file=sys.stderr)
        process(name)


if __name__ == "__main__":
    main()
