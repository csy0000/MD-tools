#!/usr/bin/env python3
"""build_macrocycle_topology.py — parameterize an arbitrary macrocycle + compute the omega-exclude set.

General version of build_cyclosporin_topology.py: builds an OpenFF **Sage** ligand from an isomeric
SMILES (ETKDG conformer), verifies the RDKit<->OpenMM atom order is the identity map (the torsion
quartet + omega-exclude code relies on this), then detects the secondary-amide omega (peptide-bond)
central bonds and saves them so the REST2 hot ensemble can leave them unscaled. Tertiary amides
(proline / N-methyl) stay scaled.

Outputs -> data/<name>/topology/:
  system_scale_1p0.prmtop, .inpcrd, topology.pdb, config.json, omega_exclude_bonds.npy
Usage:
  python -m escort_ais.experiments.macrocycle.build_macrocycle_topology \
      --name rgd \
      --smiles "N1[C@@H](CCCNC(=[NH2+])N)C(=O)NCC(=O)N[C@@H](CC(=O)[O-])C(=O)N[C@H](Cc2ccccc2)C(=O)N[C@@H](C(C)C)C1=O" \
      [--forcefield sage] [--solvent gbn2] [--skip-build]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from rdkit import Chem

from escort_ais.common.paths import project_root
ROOT = project_root()

from escort_ais.systems.topology_prep import build_topology  # noqa: E402
from escort_ais.systems.peptide_torsions import amide_census, omega_exclude_bonds  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True, help="molecule short name -> data/<name>/topology")
    ap.add_argument("--smiles", required=True, help="isomeric SMILES (set protonation explicitly)")
    ap.add_argument("--forcefield", default="sage", choices=["sage", "gaff"])
    ap.add_argument("--solvent", default="gbn2")
    ap.add_argument("--skip-build", action="store_true",
                    help="reuse an existing topology in the output dir (only recompute omega bonds)")
    args = ap.parse_args()

    out = ROOT / "data" / args.name / "topology"

    cen = amide_census(Chem.MolFromSmiles(args.smiles))
    print(f"  amide census: {cen}")

    top_pdb = out / "topology.pdb"
    if args.skip_build and top_pdb.exists():
        print(f"  reusing existing topology in {out.relative_to(ROOT)}")
    else:
        print(f"  building topology ({args.forcefield} / {args.solvent}) -> {out.relative_to(ROOT)} ...")
        info = build_topology(output_dir=out, ligand_smiles=args.smiles,
                              forcefield=args.forcefield, solvent=args.solvent)
        print(f"  topology built: n_solute_atoms={int(info.get('n_solute_atoms', 0))}")

    # OpenFF molecule's RDKit atom order == OpenMM topology order (verified element-by-element),
    # so the OpenMM<->RDKit map is the identity. This is required by compute_quartets/omega_exclude.
    from openff.toolkit import Molecule  # noqa: E402  (deferred; heavy import)
    from openmm.app import PDBFile
    offmol = Molecule.from_smiles(args.smiles, allow_undefined_stereo=True)
    rdmol = offmol.to_rdkit()
    top_elems = [a.element.symbol for a in PDBFile(str(top_pdb)).topology.atoms()]
    rd_elems = [a.GetSymbol() for a in rdmol.GetAtoms()]
    assert rd_elems == top_elems, "OpenFF/OpenMM atom order mismatch -- identity map invalid"
    n_solute = len(top_elems)

    excl = omega_exclude_bonds(rdmol, np.arange(n_solute))   # (n_secondary, 2) OpenMM idx
    np.save(out / "omega_exclude_bonds.npy", excl)
    print(f"  omega_exclude_bonds (secondary amides, OpenMM indices), shape {excl.shape}:")
    print(excl)
    print(f"  Saved omega_exclude_bonds.npy -> {out.relative_to(ROOT)}  "
          f"({len(excl)} excluded; {cen['n_tertiary']} tertiary amides stay scaled)")


if __name__ == "__main__":
    main()
