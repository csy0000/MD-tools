#!/usr/bin/env python3
"""validate_rite_torch.py — does the torch port reproduce the reference rite_weight result?

Builds ONE real within-basin (from,to) transition-segment feature set (same pipeline as
analyze_rite_local_equilibrium.process), then runs BOTH the reference `rite_weight` and the torch port
`escort_ais.methods.rite_torch.RiteTorch` with the same inputs/seed/params, and compares the per-segment weights
(the `_avg_last` estimate) — correlation, total-variation, max abs diff — plus the downstream within-basin JS
to REMD(.|B) computed from each weighting. Not bit-identical (torch-vs-numpy argmin ties / float), but should
match to a few 1e-3 and give the same JS.

    conda activate escort-ais && python -m escort_ais.experiments.remd.validate_rite_torch [name] [basin]
"""
from __future__ import annotations

import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import glob
import numpy as np
import mdtraj as md
from scipy.stats import pearsonr, spearmanr
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import build_tica_basin_model, featurize, load_quartets  # noqa: E402
from escort_ais.methods.rite_torch import RiteTorch  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402
from escort_ais.analysis.analyze_rite_local_equilibrium import (  # noqa: E402
    HOT, REMD, NSTATE, KSUB, MINN, STRIDE, LAG, NPCA, TMP, rite_weights, _js)
from rite_weight import rite_weight  # noqa: E402  (reference; escort-ais only)

CLUSTERS, ITERS, SF, SFNN, SEED = 20, 100, 0.01, 0.05, 42


def build_basin(name, want_B):
    cfg = load_cfg(name); top = str(cfg.top_pdb); q, _, _ = load_quartets(cfg.topo, "backbone")
    model = build_tica_basin_model(HOT[name], cfg.top_pdb, cfg.topo, n_basins=NSTATE, lag=20, n_tic=4,
                                   burn_frames=1000, stride=2, seed=0)
    remd = load_remd_ensemble(REMD[name], "replica_00", cfg.top_pdb, 0)
    p0 = np.bincount(model.assign(remd), minlength=NSTATE).astype(float); p0 /= p0.sum()
    perm = np.argsort(-p0); inv = np.empty(NSTATE, int); inv[perm] = np.arange(NSTATE)
    rstate = inv[model.assign(remd)]; remdX = featurize(remd, q)
    seedX, seedst = [], []
    for s in sorted(glob.glob(str(ROOT / "data/rgd/diagnostics/bais_eval" / name / "cold_md/seed_*/trajectory.dcd"))):
        tr = md.load_dcd(s, top=top)[50::STRIDE]
        seedX.append(featurize(tr, q)); seedst.append(inv[model.assign(tr)])
    dom = np.array([np.bincount(st, minlength=NSTATE).argmax() for st in seedst])
    B = want_B
    homed = np.where(dom == B)[0]
    Xc_parts, from_idx, base = [], [], 0
    for sid in homed:
        Xs = seedX[sid][seedst[sid] == B]
        if len(Xs) <= LAG:
            continue
        Xc_parts.append(Xs); from_idx.append(base + np.arange(len(Xs) - LAG)); base += len(Xs)
    Xc = np.concatenate(Xc_parts); from_idx = np.concatenate(from_idx); to_idx = from_idx + LAG
    Rfeat = PCA(NPCA, random_state=0).fit(Xc).transform(Xc)
    Xr = remdX[rstate == B]
    return cfg, q, Xc, Rfeat, from_idx, to_idx, Xr


def js_from_weights(Xr, Xc, wf):
    """within-B sub-cluster JS to REMD from a per-FRAME weight vector wf."""
    km = KMeans(min(KSUB, len(Xr) // 25 + 2), n_init=6, random_state=0).fit(np.concatenate([Xr, Xc]))
    Kc = km.n_clusters
    pr = np.bincount(km.predict(Xr), minlength=Kc).astype(float)
    pc = np.bincount(km.predict(Xc), minlength=Kc, weights=wf).astype(float)
    return _js(pc, pr)


def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "rgd"
    B = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    cfg, q, Xc, Rfeat, from_idx, to_idx, Xr = build_basin(name, B)
    ff, tt = Rfeat[from_idx], Rfeat[to_idx]
    n_seg, n_fr = len(from_idx), len(Xc)
    print(f"[{name} S{B}] {n_fr} frames, {n_seg} segments, D={Rfeat.shape[1]}, "
          f"clusters={CLUSTERS} iters={ITERS} sf={SF} sfnn={SFNN}", file=sys.stderr)

    # reference (writes tf/tt npy + RW_val_avg_last.npy in TMP)
    cfgd = dict(clusters=CLUSTERS, iters=ITERS, sf=SF, sfnn=SFNN)
    wf_ref = rite_weights(ff, tt, from_idx, n_fr, "val", cfg=cfgd)
    wseg_ref = np.load(str(TMP / "RW_val_avg_last.npy"))

    # torch port (CPU here; identical code runs on GPU-RITE with device='cuda')
    rt = RiteTorch(ff, tt, device="cpu")
    wseg_torch = rt.iterate(np.ones(n_seg) / n_seg, CLUSTERS, ITERS, max(1, ITERS // 20),
                            smoothing_factor=SF, smoothing_factor_nn=SFNN, seed=SEED, save_last=10)
    wf_torch = np.zeros(n_fr); np.add.at(wf_torch, from_idx, wseg_torch)

    a, b = wseg_ref / wseg_ref.sum(), wseg_torch / wseg_torch.sum()
    tv = 0.5 * np.abs(a - b).sum()
    pear = pearsonr(a, b)[0]; spear = spearmanr(a, b)[0]
    js_ref = js_from_weights(Xr, Xc, wf_ref); js_torch = js_from_weights(Xr, Xc, wf_torch)
    js_unw = js_from_weights(Xr, Xc, np.ones(n_fr))
    print("\n=== per-segment weight agreement (reference vs torch) ===", file=sys.stderr)
    print(f"  Pearson r = {pear:.4f} | Spearman = {spear:.4f} | TV = {tv:.4f} | "
          f"max|Δ| = {np.abs(a-b).max():.2e}", file=sys.stderr)
    print("=== downstream within-basin JS to REMD(.|B) ===", file=sys.stderr)
    print(f"  unweighted = {js_unw:.4f} | reference = {js_ref:.4f} | torch = {js_torch:.4f} | "
          f"Δ(ref,torch) = {abs(js_ref-js_torch):.4f}", file=sys.stderr)
    ok = abs(js_ref - js_torch) < 0.01
    print(f"\nVERDICT: {'PASS' if ok else 'CHECK'} — JS matches within 0.01"
          if ok else f"\nVERDICT: CHECK — JS differs by {abs(js_ref-js_torch):.3f}", file=sys.stderr)
    # persist the feature set for the GPU-RITE cross-check
    np.save(TMP / "val_from.npy", ff); np.save(TMP / "val_to.npy", tt)
    print(f"(features saved to {TMP}/val_from.npy, val_to.npy for the GPU-RITE cross-check)", file=sys.stderr)


if __name__ == "__main__":
    main()
