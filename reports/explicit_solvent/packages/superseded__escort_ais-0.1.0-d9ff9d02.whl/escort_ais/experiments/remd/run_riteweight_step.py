#!/usr/bin/env python3
"""RITE-weight analysis of basin MD trajectories.

Runs in the `rite_weight` conda environment (separate from openmm env).
Called as a subprocess by run_crooks_basin_protocol.py.

Usage:
    /path/to/rite_weight/python -m escort_ais.experiments.remd.run_riteweight_step \
        --traj-list traj1.dcd traj2.dcd ... \
        --prmtop system.prmtop \
        --output-dir /path/to/riteweight_out \
        --phi-idx 4 6 8 14 \
        --psi-idx 6 8 14 16 \
        --clusters 100 \
        --iterations 300 \
        --lag-frames 1
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import h5py
import numpy as np


def torus_embed(phi_deg: np.ndarray, psi_deg: np.ndarray) -> np.ndarray:
    phi = np.radians(phi_deg)
    psi = np.radians(psi_deg)
    return np.column_stack([np.cos(phi), np.sin(phi), np.cos(psi), np.sin(psi)])


def load_phi_psi(dcd_path: str, prmtop_path: str, phi_idx, psi_idx) -> tuple[np.ndarray, np.ndarray]:
    import mdtraj as md
    traj = md.load_dcd(dcd_path, top=prmtop_path)
    phi = np.degrees(md.compute_dihedrals(traj, [list(phi_idx)]).ravel())
    psi = np.degrees(md.compute_dihedrals(traj, [list(psi_idx)]).ravel())
    return phi, psi


def main():
    parser = argparse.ArgumentParser()
    # Pre-computed arrays (preferred; avoids mdtraj dependency in this env)
    parser.add_argument("--phi-npy",        default=None)
    parser.add_argument("--psi-npy",        default=None)
    parser.add_argument("--boundaries-npy", default=None)
    # Fallback: load from DCD (requires mdtraj)
    parser.add_argument("--traj-list", nargs="+", default=None)
    parser.add_argument("--prmtop",    default=None)
    parser.add_argument("--phi-idx", nargs=4, type=int, default=[4, 6, 8, 14])
    parser.add_argument("--psi-idx", nargs=4, type=int, default=[6, 8, 14, 16])
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--clusters",   type=int, default=100)
    parser.add_argument("--iterations", type=int, default=300)
    parser.add_argument("--lag-frames", type=int, default=1)
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.phi_npy is not None:
        # Fast path: use pre-computed arrays (no mdtraj needed)
        phi_all        = np.load(args.phi_npy)
        psi_all        = np.load(args.psi_npy)
        traj_boundaries = np.load(args.boundaries_npy).tolist()
    else:
        # Fallback: load trajectories with mdtraj
        if args.traj_list is None or args.prmtop is None:
            parser.error("Either --phi-npy/--psi-npy/--boundaries-npy or --traj-list/--prmtop required.")
        phi_list, psi_list, traj_boundaries = [], [], [0]
        for dcd in args.traj_list:
            phi, psi = load_phi_psi(dcd, args.prmtop, args.phi_idx, args.psi_idx)
            phi_list.append(phi)
            psi_list.append(psi)
            traj_boundaries.append(traj_boundaries[-1] + len(phi))
        phi_all = np.concatenate(phi_list)
        psi_all = np.concatenate(psi_list)

    feats = torus_embed(phi_all, psi_all)   # (N_total, 4)

    # Build segment arrays with lag
    lag = args.lag_frames
    # Segments from within each trajectory only (no cross-trajectory lag pairs)
    from_rows, to_rows = [], []
    for i in range(len(traj_boundaries) - 1):
        start = traj_boundaries[i]
        end = traj_boundaries[i + 1]
        if end - start <= lag:
            continue
        from_rows.append(feats[start:end - lag])
        to_rows.append(feats[start + lag:end])

    trans_from = np.vstack(from_rows)   # (n_seg, 4)
    trans_to   = np.vstack(to_rows)     # (n_seg, 4)

    np.save(str(out_dir / "trans_from_Rfeat.npy"), trans_from)
    np.save(str(out_dir / "trans_to_Rfeat.npy"),   trans_to)
    np.save(str(out_dir / "phi_all.npy"), phi_all)
    np.save(str(out_dir / "psi_all.npy"), psi_all)
    np.save(str(out_dir / "traj_boundaries.npy"), np.array(traj_boundaries))

    # Run RITE-weight
    from rite_weight import rite_weight
    config = {
        "trans_from_Rfeat_path": str(out_dir / "trans_from_Rfeat.npy"),
        "trans_to_Rfeat_path":   str(out_dir / "trans_to_Rfeat.npy"),
    }
    model = rite_weight.rite_weight_model(config)
    n_seg = len(trans_from)
    initial_weights = np.ones(n_seg) / n_seg

    orig_dir = os.getcwd()
    os.chdir(str(out_dir))   # rite_weight writes Reweights.h5 to cwd
    model.rite_weight_iter(
        initial_weights,
        args.clusters,
        args.iterations,
        max(1, args.iterations // 10),
    )
    os.chdir(orig_dir)

    # Load final weights and save summary
    with h5py.File(str(out_dir / "Reweights.h5"), "r") as f:
        weights_all = f["weights_out"][:]          # (n_seg, n_saved)
    final_weights = weights_all[:, -1]
    np.save(str(out_dir / "final_weights.npy"), final_weights)

    # Map weights back to original full frames (including lag-shifted frames without pairs)
    # Segment i corresponds to frame i within each trajectory (lag-corrected)
    n_trajs = len(traj_boundaries) - 1
    frame_weights = np.zeros(len(phi_all))
    seg_idx = 0
    for i in range(n_trajs):
        start = traj_boundaries[i]
        end = traj_boundaries[i + 1]
        n = end - start - lag
        if n <= 0:
            continue
        frame_weights[start:start + n] += final_weights[seg_idx:seg_idx + n]
        seg_idx += n

    np.save(str(out_dir / "frame_weights.npy"), frame_weights)

    meta = {
        "n_trajs": n_trajs,
        "n_frames_total": int(len(phi_all)),
        "n_segments": int(n_seg),
        "lag_frames": lag,
        "clusters": args.clusters,
        "iterations": args.iterations,
    }
    (out_dir / "meta.json").write_text(json.dumps(meta, indent=2))
    print(f"RITE-weight done. n_seg={n_seg}, weights saved to {out_dir}")


if __name__ == "__main__":
    main()
