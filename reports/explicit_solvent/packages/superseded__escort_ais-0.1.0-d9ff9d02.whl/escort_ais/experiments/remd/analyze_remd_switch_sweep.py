#!/usr/bin/env python3
"""analyze_remd_switch_sweep.py — compare the REMD-seeded AIS+BAR validation across switch times.

Loads validation_summary.json for switch ∈ {5,10,20,40} ps and tabulates, per switch time:
  - per-basin ΔΔF (combined + hot-unified) vs the REMD cold reference, and per-basin |error|
  - per-basin BAR overlap
  - RMSE (combined + hot-unified)
  - forward/reverse work means and the DISSIPATION GAP  d = mean(W_f) - mean(-W_r)  (≈ 2·<W_diss>)
Then prints a recommendation: the smallest switch whose overlap clears the warn threshold (0.2) and
whose populated-basin (0,1,2) hot-unified RMSE is within ~0.1 kT — balancing cost (∝ switch length).

Output -> results/cyclosporin/remd_switch_sweep/{summary.csv, fig_switch_sweep.png}
Usage:  python -m escort_ais.experiments.remd.analyze_remd_switch_sweep
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
SWEEP = ROOT / "data/cyclosporin/2026-06-24-remd-switch-sweep"
OUT = ROOT / "results/cyclosporin/remd_switch_sweep"
OUT.mkdir(parents=True, exist_ok=True)
SWITCHES = [5, 10, 20, 40]
BETA = 1.0 / (0.00831446261815324 * 300.0)   # kJ/mol^-1 at 300 K (reduced-unit conversion for gap)
WARN = 0.2          # overlap warn threshold
POP_BASINS = [0, 1, 2]   # the populated basins (basin 3 is the rare ~2.4% state)


def load_one(sw):
    p = SWEEP / f"sw{sw:02d}ps/validation_summary.json"
    return json.loads(p.read_text()) if p.exists() else None


def main():
    rows, recs = [], {}
    ref = None
    for sw in SWITCHES:
        s = load_one(sw)
        if s is None:
            print(f"  switch {sw} ps: missing -> skip"); continue
        ref = np.array(s["reference_ddF"])
        hub = np.array(s["ddF_hotunified"])
        ais = np.array(s.get("ddF_ais", [np.nan] * len(ref)))   # forward-only AIS (Jarzynski) baseline
        ovl = np.array(s["overlap"]); nb = len(ref)
        gap = s["W_f_mean"] - (-s["W_r_mean"])
        rmse_all = lambda v: float(np.sqrt(np.nanmean((v - ref)[np.isfinite(v - ref)] ** 2)))
        pop_rmse_hub = float(np.sqrt(np.nanmean(np.abs(hub - ref)[POP_BASINS] ** 2)))
        recs[sw] = dict(min_overlap=float(np.nanmin(ovl)), pop_rmse_hub=pop_rmse_hub,
                        b3_err=float(np.abs(hub - ref)[3]) if nb > 3 else np.nan, gap_kJ=gap)
        rows.append(dict(
            switch_ps=sw, gap_kJ=round(gap, 2), gap_kT=round(gap * BETA, 2),
            rmse_ais=round(rmse_all(ais), 3), rmse_hub=round(s["rmse_hotunified"], 3),
            pop_rmse_hub=round(pop_rmse_hub, 3),
            **{f"ais_b{b}": round(ais[b], 3) for b in range(nb)},
            **{f"hub_b{b}": round(hub[b], 3) for b in range(nb)},
            **{f"ovl_b{b}": round(ovl[b], 3) for b in range(nb)},
            W_f=round(s["W_f_mean"], 1), W_r=round(s["W_r_mean"], 1)))
    if not rows:
        print("No sweep results yet."); return
    df = pd.DataFrame(rows).sort_values("switch_ps")
    df.to_csv(OUT / "summary.csv", index=False)
    print(f"reference ΔΔF (REMD cold) = {np.round(ref,3).tolist()}\n")
    print(df.to_string(index=False))

    # ── figure: overlap, dissipation gap, RMSE vs switch ──
    t = df["switch_ps"].to_numpy(); nb = len(ref)
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.4))
    cm = plt.cm.tab10
    for b in range(nb):
        ax[0].plot(t, df[f"ovl_b{b}"], "o-", color=cm(b), label=f"basin {b}")
    ax[0].axhspan(0, WARN, color="orange", alpha=0.12)
    ax[0].set_title("BAR overlap vs switch (warn < 0.2)"); ax[0].set_xlabel("switch (ps)")
    ax[0].set_ylabel("overlap"); ax[0].set_ylim(0, 1); ax[0].legend(fontsize=8); ax[0].grid(alpha=0.3)
    ax[1].plot(t, df["gap_kT"], "s-", color="#CC3311")
    ax[1].set_title("work dissipation gap  W_f−(−W_r)"); ax[1].set_xlabel("switch (ps)")
    ax[1].set_ylabel("gap (kT)"); ax[1].grid(alpha=0.3)
    ax[2].plot(t, df["rmse_ais"], "v--", color="#009988", alpha=0.8, label="AIS forward-only")
    ax[2].plot(t, df["rmse_hub"], "s-", color="#0077BB", label="hot-unified BAR")
    ax[2].plot(t, df["pop_rmse_hub"], "o:", color="#0077BB", alpha=0.5, label="hot-unified (populated)")
    ax[2].axhline(0.1, color="gray", ls=":", lw=1)
    ax[2].set_title("RMSE vs REMD reference (AIS vs hot-unified BAR)"); ax[2].set_xlabel("switch (ps)")
    ax[2].set_ylabel("RMSE (kT)"); ax[2].legend(fontsize=8); ax[2].grid(alpha=0.3)
    fig.suptitle("Cyclosporin AIS+BAR from REMD ensembles — switch-time sweep (k=1000, same seeds)",
                 fontsize=12)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(OUT / "fig_switch_sweep.png", dpi=150); plt.close(fig)

    # ── per-basin ΔΔF vs switch: AIS (forward-only) vs combined vs hot-unified vs REMD ref ──
    fig2, axes = plt.subplots(1, nb, figsize=(4.2 * nb, 4.0), sharex=True)
    for b in range(nb):
        a = axes[b]
        a.axhline(ref[b], color="k", ls="--", lw=1.5, label="REMD ref")
        a.plot(t, df[f"ais_b{b}"], "v--", color="#009988", label="AIS forward-only")
        a.plot(t, df[f"hub_b{b}"], "s-", color="#0077BB", label="hot-unified BAR")
        a.set_title(f"basin {b}  (ref {ref[b]:.2f} kT)"); a.set_xlabel("switch (ps)")
        a.grid(alpha=0.3)
        if b == 0:
            a.set_ylabel("ΔΔF (kT)"); a.legend(fontsize=8)
    fig2.suptitle("Per-state ΔΔF vs switch time — forward-only AIS vs BAR estimators (REMD-seeded)",
                  fontsize=12)
    fig2.tight_layout(rect=(0, 0, 1, 0.95))
    fig2.savefig(OUT / "fig_perbasin_ddF.png", dpi=150); plt.close(fig2)

    # ── recommendation ──
    print("\n=== recommendation ===")
    ok = [sw for sw in sorted(recs) if recs[sw]["min_overlap"] >= WARN and recs[sw]["pop_rmse_hub"] <= 0.1]
    if ok:
        print(f"  smallest switch clearing overlap≥{WARN} AND populated-RMSE≤0.1 kT: {ok[0]} ps")
    else:
        best = min(recs, key=lambda s: (recs[s]["pop_rmse_hub"], -recs[s]["min_overlap"]))
        print(f"  none clears both thresholds; best populated-RMSE at {best} ps "
              f"(min-overlap {recs[best]['min_overlap']:.2f}, pop-RMSE {recs[best]['pop_rmse_hub']:.3f} kT)")
    for sw in sorted(recs):
        r = recs[sw]
        print(f"   {sw:2d} ps: min-overlap {r['min_overlap']:.2f} | pop-RMSE {r['pop_rmse_hub']:.3f} | "
              f"basin3 |err| {r['b3_err']:.2f} kT | gap {r['gap_kJ']:.1f} kJ/mol")
    print(f"\nSaved -> {OUT.relative_to(ROOT)}/summary.csv + fig_switch_sweep.png")


if __name__ == "__main__":
    main()
