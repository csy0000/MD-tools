#!/usr/bin/env python3
"""analyze_ais_hdbscan_vs_remd.py — HDBSCAN the forward-AIS landings in backbone-torsion space vs REMD.

Pipeline the user asked for:
  (1) 1000 forward-AIS landings from the (T_discard=10 ns)+50 ns hot ensemble  — already produced as
      data/rgd/diagnostics/bais_eval/rgd/gen0/fwd/ (gen0, hot_ns=60, k_fwd=1000).
  (2) HDBSCAN on the backbone-torsion feature space (sin/cos of the 15 backbone dihedrals) to get cluster
      labels + centroids, and compare those clusters to REMD.

Two comparisons are reported:
  * DISCOVERY — HDBSCAN run INDEPENDENTLY on REMD and on the AIS landings: how many clusters each finds, and
    whether every REMD cluster centroid has a matching AIS cluster centroid (nearest-centroid, sin/cos Euclidean).
  * POPULATION — assign every AIS landing to its nearest REMD-HDBSCAN centroid; compare the AIS raw and
    AIS importance-weighted (exp(final_logw)) population of each REMD cluster to REMD's own population. This is
    the physically meaningful test (does forward AIS reproduce the REMD cluster populations?).

    conda activate escort-ais && python -m escort_ais.experiments.remd.analyze_ais_hdbscan_vs_remd
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mdtraj as md
import numpy as np
import pandas as pd
import hdbscan                                                # reference HDBSCAN: condensed tree + persistence
from scipy.special import logsumexp
from sklearn.cluster import HDBSCAN, OPTICS                    # sklearn HDBSCAN for the PC-space sweep; OPTICS check
from sklearn.decomposition import PCA

from escort_ais.common.paths import project_root
ROOT = project_root()
from escort_ais.common.macrocycle_cfg import load as load_cfg  # noqa: E402
from escort_ais.systems.cyclosporin_torsion_basins import featurize, load_quartets  # noqa: E402
from escort_ais.common.figutil import panel_labels  # noqa: E402
from escort_ais.methods.run_macrocycle_seedsource_swap import load_remd_ensemble  # noqa: E402

REMD = ROOT / "data/rgd/2026-06-29-rest2-remd-6rep-s0p25-500ns"
FWD = ROOT / "data/rgd/diagnostics/bais_eval/rgd/gen0/fwd"
OUT = ROOT / "results/rgd/report"


def cluster_centroids(X, labels, weights=None):
    """Per HDBSCAN cluster (drop noise=-1): the sin/cos-space centroid (for matching) + recovered dihedrals (deg),
    the count fraction, and the weight fraction. Centroid is the (optionally weight-)averaged sin/cos vector.
    X = [sin(dih0..14), cos(dih0..14)] (30-D)."""
    cents, dihs, pops, wfr = {}, {}, {}, {}
    W = np.ones(len(labels)) if weights is None else np.asarray(weights, float)
    totw = W.sum()
    for c in sorted(set(labels)):
        if c < 0:
            continue
        m = labels == c
        fc = np.average(X[m], axis=0, weights=W[m])
        cents[c] = fc
        dihs[c] = np.degrees(np.arctan2(fc[:15], fc[15:]))
        pops[c] = float(m.mean())
        wfr[c] = float(W[m].sum() / totw)
    return cents, dihs, pops, wfr


def _relabel(labels):
    """Renumber surviving clusters to contiguous 0..k-1 (noise stays -1)."""
    out = np.full(len(labels), -1, int)
    for new, c in enumerate(sorted(set(labels) - {-1})):
        out[labels == c] = new
    return out


def match_to_ref(query_feat, ref_cents):
    """Nearest reference centroid (Euclidean in sin/cos space) for each query feature vector -> ref cluster id."""
    ids = sorted(ref_cents)
    C = np.array([ref_cents[i] for i in ids])                       # (nref, 30)
    d = np.linalg.norm(query_feat[:, None, :] - C[None, :, :], axis=2)   # (nq, nref)
    j = d.argmin(1)
    return np.array([ids[k] for k in j]), d.min(1)


def process(name="rgd", remd_mcs=500, remd_ms=25, ais_mcs=10, ais_ms=5, ais_min_weight_frac=0.01,
            run_spaces=False):
    cfg = load_cfg(name); q, _, _ = load_quartets(cfg.topo, "backbone"); Q = np.asarray(q)

    # --- REMD reference (cold rung = equilibrium). Reference hdbscan: keeps the condensed-tree hierarchy +
    #     per-cluster persistence (stability), and prediction_data for approximate_predict below. Metric is
    #     Euclidean on sin/cos == the torsional chord distance sqrt(sum 2(1-cos dtheta)). ---
    remd = load_remd_ensemble(REMD, "replica_00", cfg.top_pdb, 0)
    Xr = featurize(remd, q); Dr = np.degrees(md.compute_dihedrals(remd, Q))
    mr = hdbscan.HDBSCAN(min_cluster_size=remd_mcs, min_samples=remd_ms, prediction_data=True).fit(Xr)
    lr = mr.labels_
    rc, rdih, rpop, _ = cluster_centroids(Xr, lr)
    r_noise = float((lr < 0).mean())
    r_persist = {int(c): round(float(mr.cluster_persistence_[c]), 3) for c in range(len(rc))}

    # --- forward-AIS landings (gen0: hot_ns=60 = 10 discard + 50, k_fwd=1000) ---
    land = md.load_dcd(str(FWD / "ais_final_coordinates.dcd"), top=str(cfg.top_pdb))
    Xl = featurize(land, q); Dl = np.degrees(md.compute_dihedrals(land, Q))
    logw = pd.read_csv(FWD / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    w = np.exp(logw - logw.max())
    # WEIGHT-AWARE AIS clustering: cluster at min_cluster_size=10, then keep only clusters carrying >= 1% of the
    # total AIS weight. NOTE: neither sklearn nor the hdbscan package accepts sample_weight, so the weight enters
    # via this post-hoc prune + weighted centroids (not into the density estimate itself).
    ll = hdbscan.HDBSCAN(min_cluster_size=ais_mcs, min_samples=ais_ms).fit_predict(Xl)
    totw = float(w.sum())
    pre_wfrac = {int(c): float(w[ll == c].sum() / totw) for c in sorted(set(ll) - {-1})}
    n_pre = len(pre_wfrac)
    for c in list(set(ll) - {-1}):
        if w[ll == c].sum() / totw < ais_min_weight_frac:
            ll[ll == c] = -1                                         # prune sub-1%-weight clusters to noise
    ll = _relabel(ll)
    lc, ldih, lpop, lwfrac = cluster_centroids(Xl, ll, weights=w)
    l_noise = float((ll < 0).mean())
    l_noise_wfrac = float(w[ll < 0].sum() / totw)

    # --- DISCOVERY: does each REMD cluster have a matching independent AIS cluster? ---
    ais_ids = sorted(lc)
    ais_cent = np.array([lc[i] for i in ais_ids]) if ais_ids else np.zeros((0, Xr.shape[1]))
    match, mdist = (match_to_ref(ais_cent, rc) if len(ais_cent) else (np.array([]), np.array([])))
    ais_to_remd = {int(ais_ids[k]): int(match[k]) for k in range(len(ais_ids))}
    remd_covered = sorted(set(int(m) for m in match))               # REMD clusters an AIS cluster maps to

    # --- SOFT ASSIGNMENT: route each AIS landing through the REMD condensed tree (approximate_predict). Landings
    #     that fall in no REMD cluster get -1 = "outside REMD's dense regions" (a diagnostic nearest-centroid hides). ---
    soft_lab, _soft_str = hdbscan.approximate_predict(mr, Xl)
    outside = soft_lab < 0
    soft = dict(outside_raw=round(float(outside.mean()), 3), outside_weight=round(float(w[outside].sum() / totw), 3),
                per_cluster={int(c): dict(raw=round(float((soft_lab == c).mean()), 3),
                                          weighted=round(float(w[soft_lab == c].sum() / totw), 3))
                             for c in sorted(rc)})

    # --- POPULATION: assign every AIS landing to nearest REMD centroid; raw + weighted pop per REMD cluster ---
    assign, _ = match_to_ref(Xl, rc)
    tot = logsumexp(logw)
    comp = {}
    for c in sorted(rc):
        m = assign == c
        comp[int(c)] = dict(
            remd_pop=round(rpop[c], 3),
            ais_raw=round(float(m.mean()), 3),
            ais_weighted=round(float(np.exp(logsumexp(logw[m]) - tot)) if m.any() else 0.0, 3),
            ais_ess=round(float((w[m].sum() ** 2) / np.sum(w[m] ** 2)) if m.any() else 0.0, 1),
            centroid_dih14=round(float(rdih[c][14]), 0), centroid_dih2=round(float(rdih[c][2]), 0))
    tv_raw = 0.5 * sum(abs(v["ais_raw"] - v["remd_pop"]) for v in comp.values())
    tv_wt = 0.5 * sum(abs(v["ais_weighted"] - v["remd_pop"]) for v in comp.values())

    res = dict(
        name=name, hot_ns=60.0, n_landings=int(len(Xl)),
        remd=dict(n_clusters=len(rc), noise_frac=round(r_noise, 3),
                  pops={int(k): round(v, 3) for k, v in rpop.items()},
                  persistence=r_persist,
                  min_cluster_size=remd_mcs, min_samples=remd_ms),
        ais=dict(n_clusters=len(lc), n_pre_prune=n_pre, n_kept=len(lc),
                 noise_frac=round(l_noise, 3), noise_weight_frac=round(l_noise_wfrac, 3),
                 raw_pops={int(k): round(v, 3) for k, v in lpop.items()},
                 weight_pops={int(k): round(v, 3) for k, v in lwfrac.items()},
                 min_cluster_size=ais_mcs, min_samples=ais_ms, min_weight_frac=ais_min_weight_frac),
        discovery=dict(ais_cluster_to_remd=ais_to_remd,
                       remd_clusters_covered_by_ais=remd_covered,
                       remd_clusters_missed_by_ais=sorted(int(x) for x in (set(rc) - set(remd_covered))),
                       match_dist={int(ais_ids[k]): round(float(mdist[k]), 3) for k in range(len(ais_ids))}),
        soft_assignment=soft,
        population=comp, tv_raw=round(tv_raw, 3), tv_weighted=round(tv_wt, 3))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{name}_ais_hdbscan_vs_remd.json").write_text(json.dumps(res, indent=2))
    print(json.dumps({k: res[k] for k in ("remd", "ais", "discovery", "soft_assignment",
                                          "tv_raw", "tv_weighted")}, indent=2), file=sys.stderr)

    pca = PCA(6, random_state=0).fit(Xr)
    make_figure(name, pca, Dr, Xr, lr, rdih, Dl, Xl, ll, ldih, assign, w, comp, res)
    hierarchy_figure(name, Xr, mr, r_persist, rpop)                # condensed-tree hierarchy + OPTICS check
    if run_spaces:
        compare_remd_spaces(name, Xr, Dr, pca)                     # slow PC-space sweep (answered; off by default)
    return res


def _cmean(a):
    r = np.radians(a)
    return float(np.degrees(np.arctan2(np.sin(r).mean(), np.cos(r).mean())))


def compare_remd_spaces(name, Xr, Dr, pca, mcs_list=(150, 70, 35)):
    """Does clustering REMD in PC-space 'find the clusters better' than the full 30-D torsion space?

    HDBSCAN in 30-D suffers the curse of dimensionality (uniform-ish densities -> high noise, R0 sub-wells lost).
    Compare torsion-30D vs PCA-3D / PCA-5D, each in RAW PC scores (PC1 variance-dominant) and WHITENED (unit
    variance per PC, so within-state axes get equal weight), across a granularity sweep. For each setting report
    n_clusters, noise, and how many clusters fall in the MAJOR (θ14 in [-180,-15]) with their dih#2 centroids —
    i.e. whether the dih#2≈+75 and dih#2≈-90 sub-states BOTH resolve."""
    Yr = pca.transform(Xr)
    std = Yr.std(0)
    spaces = {
        "torsion-30D": Xr,
        "PCA-3D raw": Yr[:, :3], "PCA-3D whit": Yr[:, :3] / std[:3],
        "PCA-5D raw": Yr[:, :5], "PCA-5D whit": Yr[:, :5] / std[:5],
    }
    major = (Dr[:, 14] >= -180) & (Dr[:, 14] <= -15)
    table = []
    for sp, feat in spaces.items():
        for mcs in mcs_list:
            lab = HDBSCAN(min_cluster_size=mcs, min_samples=15).fit_predict(feat)
            maj_ids = [c for c in set(lab) - {-1} if -180 <= _cmean(Dr[lab == c, 14]) <= -15]
            dih2 = sorted(round(_cmean(Dr[lab == c, 2])) for c in maj_ids)
            table.append(dict(space=sp, min_cluster_size=mcs, n_clusters=len(set(lab) - {-1}),
                              noise_frac=round(float((lab < 0).mean()), 3),
                              n_major_subclusters=len(maj_ids), major_dih2_centroids=dih2))
    (OUT / f"{name}_remd_hdbscan_spaces.json").write_text(json.dumps(table, indent=2))
    print("\nPC-space vs torsion-space HDBSCAN on REMD:", file=sys.stderr)
    print(f'{"space":>13} {"mcs":>4} {"nclust":>6} {"noise":>6} {"#major":>6}  major dih2 centroids', file=sys.stderr)
    for r in table:
        print(f'{r["space"]:>13} {r["min_cluster_size"]:>4} {r["n_clusters"]:>6} {r["noise_frac"]:>6.3f} '
              f'{r["n_major_subclusters"]:>6}  {r["major_dih2_centroids"]}', file=sys.stderr)

    # figure: REMD in PC1-PC2 coloured by HDBSCAN label for 3 representative settings (mcs=70)
    show = [("torsion-30D", Xr), ("PCA-5D raw", Yr[:, :5]), ("PCA-5D whit", Yr[:, :5] / std[:5])]
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))
    for axi, (sp, feat) in zip(ax, show):
        lab = HDBSCAN(min_cluster_size=70, min_samples=15).fit_predict(feat)
        axi.scatter(Yr[lab < 0, 0], Yr[lab < 0, 1], s=3, c="0.75", alpha=0.35, zorder=1)
        for c in sorted(set(lab) - {-1}):
            m = lab == c
            axi.scatter(Yr[m, 0][::5], Yr[m, 1][::5], s=6, alpha=0.5, color=plt.cm.tab20(c % 20), zorder=3)
        axi.set_xlabel("PC1"); axi.set_ylabel("PC2")
        axi.set_title(f"{sp} (mcs=70): {len(set(lab) - {-1})} clusters, noise {(lab < 0).mean():.0%}", fontsize=10)
    fig.suptitle(f"{name}: REMD HDBSCAN — does PC-space find clusters better than 30-D torsion space? "
                 f"(coloured by cluster, grey = noise)", fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / f"fig_{name}_remd_hdbscan_pcspace.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_remd_hdbscan_pcspace.png'}", file=sys.stderr)
    return table


def hierarchy_figure(name, Xr, mr, r_persist, rpop, optics_sub=8):
    """Two hierarchical density-based views the flat labels hide:
      (A) the hdbscan CONDENSED TREE of REMD (the density hierarchy; selected clusters highlighted, with per-cluster
          persistence = stability), and
      (B) an OPTICS REACHABILITY plot (sklearn, no install) on subsampled REMD as an independent hierarchical
          density-based cross-check — valleys = clusters, peaks = between-cluster boundaries."""
    fig, ax = plt.subplots(1, 2, figsize=(15, 5.4))
    # (A) per-cluster PERSISTENCE (stability) from the condensed-tree hierarchy. (hdbscan's own condensed_tree_.plot
    # icicle is incompatible with this matplotlib version — an Ellipse-patch bug — so we show the stability scores
    # the tree yields; cluster_persistence_ is indexed by the final cluster label, so it is exact.)
    ids = sorted(rpop)
    ax[0].bar(range(len(ids)), [r_persist[c] for c in ids], color=[plt.cm.tab20(c % 20) for c in ids])
    for i, c in enumerate(ids):
        ax[0].annotate(f"pop {rpop[c]:.2f}", (i, r_persist[c]), ha="center", va="bottom", fontsize=8)
    ax[0].set_xticks(range(len(ids))); ax[0].set_xticklabels([f"R{c}" for c in ids])
    ax[0].set_ylabel("cluster persistence (stability)")
    ax[0].set_title("REMD HDBSCAN cluster stability from the condensed-tree hierarchy\n"
                    "(higher = more persistent across density levels)", fontsize=10)

    # (B) OPTICS reachability (independent hierarchical density-based method)
    Xs = Xr[::optics_sub]
    opt = OPTICS(min_samples=25, xi=0.05, min_cluster_size=0.01, n_jobs=4).fit(Xs)
    order = opt.ordering_; reach = opt.reachability_[order]; olab = opt.labels_[order]
    n_opt = len(set(opt.labels_) - {-1}); noise_opt = float((opt.labels_ < 0).mean())
    xs = np.arange(len(order))
    finite = np.isfinite(reach)
    ax[1].plot(xs[finite], reach[finite], color="0.6", lw=0.6, zorder=1)
    for c in sorted(set(olab) - {-1}):
        m = olab == c
        ax[1].scatter(xs[m], np.where(np.isfinite(reach[m]), reach[m], np.nan), s=4,
                      color=plt.cm.tab10(c % 10), zorder=2)
    ax[1].set_xlabel("OPTICS ordering"); ax[1].set_ylabel("reachability distance")
    ax[1].set_title(f"OPTICS reachability on REMD (sub {len(Xs)}): {n_opt} clusters, "
                    f"noise {noise_opt:.0%}\nvalleys = density clusters", fontsize=10)
    fig.suptitle(f"{name}: hierarchical density-based views of REMD torsion space "
                 f"(HDBSCAN condensed tree vs OPTICS reachability)", fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(OUT / f"fig_{name}_remd_hierarchy.png", dpi=200); plt.close(fig)
    print(f"  OPTICS: {n_opt} clusters, noise {noise_opt:.3f} (min_samples=25, xi=0.05)", file=sys.stderr)
    print(f"  wrote {OUT / f'fig_{name}_remd_hierarchy.png'}", file=sys.stderr)


def make_figure(name, pca, Dr, Xr, lr, rdih, Dl, Xl, ll, ldih, assign, w, comp, res):
    Yr = pca.transform(Xr); Yl = pca.transform(Xl)
    fig, ax = plt.subplots(1, 3, figsize=(16.5, 5.0))

    # (A) REMD HDBSCAN clusters on PC1-PC2, centroids starred
    def _scatter_clusters(axi, Y, Dd, labels, dih_c, bg=None):
        if bg is not None:
            axi.scatter(bg[0][::40], bg[1][::40], s=3, c="0.85", alpha=0.5, zorder=1)
        noise = labels < 0
        axi.scatter(Y[noise, 0], Y[noise, 1], s=4, c="0.6", alpha=0.3, zorder=2)
        for c in sorted(set(labels)):
            if c < 0:
                continue
            m = labels == c
            axi.scatter(Y[m, 0], Y[m, 1], s=6, alpha=0.5, zorder=3,
                        color=plt.cm.tab20(c % 20))
        for c, dih in dih_c.items():
            fc = pca.transform([np.concatenate([np.sin(np.radians(dih)), np.cos(np.radians(dih))])])[0]
            axi.scatter(fc[0], fc[1], marker="*", s=240, color=plt.cm.tab20(c % 20),
                        edgecolor="k", lw=0.8, zorder=5)

    _scatter_clusters(ax[0], Yr, Dr, lr, rdih)
    ax[0].set_title(f"REMD HDBSCAN clusters (n={res['remd']['n_clusters']}, "
                    f"noise {res['remd']['noise_frac']:.0%})\n★ = cluster centroid")
    ax[0].set_xlabel("PC1"); ax[0].set_ylabel("PC2")

    # (B) AIS landings HDBSCAN clusters over REMD (grey), sized by AIS weight. Clusters are weight-pruned:
    # min_cluster_size=10 then only clusters carrying >= min_weight_frac of the total weight are kept; the label
    # by each ★ is that cluster's WEIGHT fraction (not count fraction).
    wpop = res["ais"]["weight_pops"]
    ax[1].scatter(Yr[::40, 0], Yr[::40, 1], s=3, c="0.85", alpha=0.5, zorder=1, label="REMD (equilibrium)")
    sz = 8 + 200 * np.sqrt(w / w.max())
    noise = ll < 0
    ax[1].scatter(Yl[noise, 0], Yl[noise, 1], s=sz[noise], c="0.6", alpha=0.4, zorder=2,
                  label=f"noise/pruned ({res['ais']['noise_weight_frac']:.0%} wt)")
    for c in sorted(ldih):
        m = ll == c
        ax[1].scatter(Yl[m, 0], Yl[m, 1], s=sz[m], color=plt.cm.tab20(c % 20), edgecolor="k", lw=0.2,
                      alpha=0.75, zorder=3)
        fc = pca.transform([np.concatenate([np.sin(np.radians(ldih[c])), np.cos(np.radians(ldih[c]))])])[0]
        ax[1].scatter(fc[0], fc[1], marker="*", s=240, color=plt.cm.tab20(c % 20), edgecolor="k", lw=0.8, zorder=5)
        ax[1].annotate(f"{wpop.get(c, 0):.0%} wt", (fc[0], fc[1]), fontsize=7, fontweight="bold",
                       xytext=(4, 4), textcoords="offset points", zorder=6)
    ais = res["ais"]
    ax[1].set_title(f"AIS HDBSCAN (min_clust=10, kept ≥{ais['min_weight_frac']:.0%} wt): "
                    f"{ais['n_pre_prune']}→{ais['n_kept']} clusters, {ais['noise_weight_frac']:.0%} wt noise\n"
                    f"★ label = cluster weight share;  REMD missed: {res['discovery']['remd_clusters_missed_by_ais']}",
                    fontsize=9.5)
    ax[1].set_xlabel("PC1"); ax[1].set_ylabel("PC2"); ax[1].legend(fontsize=8, loc="best")

    # (C) population per REMD cluster: REMD vs AIS-raw vs AIS-weighted (AIS assigned to nearest REMD centroid)
    ids = sorted(comp)
    xb = np.arange(len(ids)); bw = 0.27
    ax[2].bar(xb - bw, [comp[c]["remd_pop"] for c in ids], bw, color="0.6", label="REMD (equilibrium)")
    ax[2].bar(xb, [comp[c]["ais_weighted"] for c in ids], bw, color="C0", label="AIS weighted")
    ax[2].bar(xb + bw, [comp[c]["ais_raw"] for c in ids], bw, color="C1", label="AIS raw (unweighted)")
    ax[2].set_xticks(xb)
    ax[2].set_xticklabels([f"R{c}\nθ14={comp[c]['centroid_dih14']:.0f}" for c in ids], fontsize=7)
    ax[2].set_ylabel("population"); ax[2].legend(fontsize=8)
    ax[2].set_title(f"population per REMD cluster (AIS→nearest REMD centroid)\n"
                    f"TV(weighted)={res['tv_weighted']:.3f}  TV(raw)={res['tv_raw']:.3f}")

    fig.suptitle(f"{name}: HDBSCAN of 1000 forward-AIS landings (hot 60 ns) vs REMD, backbone-torsion space",
                 fontsize=12)
    panel_labels(fig)
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(OUT / f"fig_{name}_ais_hdbscan_vs_remd.png", dpi=300); plt.close(fig)
    print(f"  wrote {OUT / f'fig_{name}_ais_hdbscan_vs_remd.png'}", file=sys.stderr)


if __name__ == "__main__":
    process("rgd")
