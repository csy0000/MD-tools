#!/usr/bin/env python3
"""run_rite_torch.py — GPU-RITE service: run the torch RITE port on a (from,to) feature pair.

Designed to run under the isolated **GPU-RITE** conda env (torch+CUDA), decoupled from `escort-ais` via
`.npy` files exactly like the reference `rite_weight` (which also takes feature-array *paths*). The
`escort-ais` side writes the from/to segment feature `.npy`; this runner loads them, runs `RiteTorch` on GPU,
and writes the per-segment weights `.npy`; the `escort-ais` side reads them back to compute JS.

    /home/chen/software/miniforge3/envs/GPU-RITE/bin/python -m escort_ais.experiments.remd.run_rite_torch \
        --from tf.npy --to tt.npy --out w.npy --clusters 20 --iters 300 --sf 0.01 --sfnn 0.05 --device cuda
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np

from escort_ais.methods.rite_torch import RiteTorch  # standalone: torch/numpy/scipy/sklearn only  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="from_path", required=True)
    ap.add_argument("--to", dest="to_path", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--clusters", type=int, default=20)
    ap.add_argument("--iters", type=int, default=300)
    ap.add_argument("--sf", type=float, default=0.01)
    ap.add_argument("--sfnn", type=float, default=0.05)
    ap.add_argument("--lr", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--save-last", type=int, default=10)
    ap.add_argument("--knn-k", type=int, default=10)
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    import torch
    dev = args.device
    if dev == "cuda" and not torch.cuda.is_available():
        print("[run_rite_torch] CUDA not available — falling back to CPU", file=sys.stderr)
        dev = "cpu"
    ff = np.load(args.from_path); tt = np.load(args.to_path)
    n_seg = len(ff)
    t0 = time.time()
    rt = RiteTorch(ff, tt, knn_k=args.knn_k, device=dev)
    w = rt.iterate(np.ones(n_seg) / n_seg, args.clusters, args.iters, max(1, args.iters // 20),
                   learning_rate=args.lr, smoothing_factor=args.sf, smoothing_factor_nn=args.sfnn,
                   seed=args.seed, save_last=args.save_last)
    np.save(args.out, w)
    dt = time.time() - t0
    gpu = torch.cuda.get_device_name(0) if dev == "cuda" else "cpu"
    print(f"[run_rite_torch] device={dev} ({gpu}) | {n_seg} segments x {args.iters} iters | "
          f"{dt:.2f}s | wrote {args.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
