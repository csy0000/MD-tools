"""Generation-level bootstrap for every cBAR variant: resample GENERATIONS, not legs.

A generation is the natural quasi-independent unit of this protocol. It advances each walker,
draws its own seeds and runs its own legs, so resampling whole generations captures sources of
variation that leg-level resampling cannot see:

* **walker drift.** The confined walkers continue across generations. Resampling legs inside a
  frozen accumulated bank holds the walker trajectory fixed and therefore treats a drifting walker
  as if it were the only walker that could have occurred.
* **hot-pool growth.** Each generation draws from a different (growing, or saturated) hot prefix.
* **bank accumulation.** The forward bank is cumulative and never reweighted; its composition is a
  function of which generations happened.

Leg-level cluster resampling answers a narrower question -- "given these banks, how precise is the
solve" -- and will generally give a TIGHTER interval. Neither is wrong; they bound different
things, and this module exists so both can be reported.

WHAT THIS DOES NOT FIX. Generations are not independent: the walkers carry state across them, so
this is a bootstrap over correlated blocks and remains optimistic if the correlation time exceeds
one generation. With ~20 generations the resolution is coarse -- a 90% interval from 20 units is
itself uncertain. Both facts are recorded in the output rather than smoothed over.

The resampler is estimator-agnostic: pass a ``solve(generations) -> value`` callable. Every variant
(normal, traceback-stratified, wall-stratified) plugs in the same way, which is the point -- their
intervals are then comparable because the resampling unit is identical.
"""
from __future__ import annotations

import numpy as np

#: below this many generations a generation-level interval is not worth quoting
MIN_GENERATIONS = 8


def generation_bootstrap(generations, solve, n_boot: int = 500, seed: int = 20260810,
                         alpha: float = 0.05):
    """Resample generations with replacement and re-solve.

    :param generations: the generation labels available, e.g. ``[1, 2, ..., 20]``.
    :param solve: ``solve(list_of_generations) -> float or array``. Must pool exactly the legs of
        the generations it is given, INCLUDING duplicates -- a generation drawn twice contributes
        twice, which is what makes this a bootstrap rather than a subsample.
    :returns: dict with the point value, the [alpha/2, 1-alpha/2] interval, and the diagnostics a
        reader needs to decide whether to trust it.
    """
    gens = list(generations)
    rng = np.random.default_rng(seed)
    point = np.atleast_1d(np.asarray(solve(gens), float))

    reps, failed = [], 0
    for _ in range(n_boot):
        draw = [gens[i] for i in rng.integers(0, len(gens), size=len(gens))]
        try:
            v = np.atleast_1d(np.asarray(solve(draw), float))
        except Exception:
            failed += 1
            continue
        if np.isfinite(v).all():
            reps.append(v)
        else:
            failed += 1

    out = dict(point=point.tolist(), n_generations=len(gens), n_boot=n_boot,
               n_valid=len(reps), n_failed=failed,
               unit="generation (resampled with replacement)",
               enough_generations=bool(len(gens) >= MIN_GENERATIONS))
    if len(reps) < max(20, n_boot // 5):
        out.update(lo=None, hi=None,
                   note=(f"only {len(reps)}/{n_boot} replicates solved; no interval reported "
                         f"rather than one built from the subset that happened to converge"))
        return out
    A = np.vstack(reps)
    out.update(lo=np.percentile(A, 100 * alpha / 2, axis=0).tolist(),
               hi=np.percentile(A, 100 * (1 - alpha / 2), axis=0).tolist(),
               std=A.std(axis=0).tolist(),
               note=("generations are correlated blocks (walkers carry state across them), so this "
                     "is optimistic if the correlation time exceeds one generation"))
    if not out["enough_generations"]:
        out["note"] += (f"; only {len(gens)} generations -- below the {MIN_GENERATIONS} this module "
                        f"considers the minimum for a quotable interval")
    return out
