"""Attribute a conditional-BAR residual to the TERM that carries it, using REMD-MBAR per term.

A residual on ``f^C_n - f^C_m`` says only that something is wrong, because the estimand is a sum.
Both arms expose their intermediate terms and the REMD-MBAR reference can supply each one
independently, so the error can be attributed rather than merely observed.

TRACEBACK-STRATIFIED (`endpoint_restricted_delta`) -- two independently checkable pieces::

    f^C_n - f^C_m  =  [ (f^C_n - f^H_n) - (f^C_m - f^H_m) ]  +  ( f^H_n - f^H_m )
                      \\_________ matched, per-cell BAR _____/    \\__ hot counting __/

The matched term is a doubly-conditioned BAR between a cold cell and the SAME cell of the hot
state; the hot term is a population ratio in the hot ensemble obtained by counting. The identity is
asserted at runtime against the stored trace, so a future change to either convention fails loudly
here instead of silently re-attributing the error.

NORMAL cBAR (`conditional_bar_delta`) solves ``f^C_m - f_H`` against the WHOLE hot state, so it has
no hot-partition term at all; what is checkable is its cold population vector. That difference is
the point of running both: if the residual sits in the hot term, normal cBAR cannot be exposed to
it, and a disagreement between the arms localises the fault by construction.

THREE THINGS THIS GETS RIGHT ON PURPOSE, each of which would otherwise mislead:

* **Gauge-free comparison only.** Absolute ``f^C_m - f^H_m`` carries the AIS gauge (order -226 kT
  on the macrocycles) which no population-based reference can reproduce. Only DIFFERENCES between
  cells are compared; there the gauge cancels exactly. Comparing absolutes would measure the gauge.
* **The hot reference is the s = 0.25 rung, COUNTED.** The stored MBAR weights reweight onto the
  COLD state and cannot supply hot populations. Each rung of a converged ladder samples its own
  target, so counting that rung's own frames is the available estimator. Requesting a rung whose
  recorded scale is not 0.25 is refused rather than silently reweighted.
* **This is the comparison the freeze gate no longer makes.** Hot-ensemble convergence has been
  UNGUARDED since the population-ratio rule was retired (2026-08-04), and the AIS hot walker is an
  INDEPENDENT 500 ns chain rather than the REMD rung. A disagreement in the hot term is therefore a
  real statement about that walker, not a bookkeeping artefact.

Run: ``python -m escort_ais.analysis.cbar_term_decomposition --system ... --run-dir ...``
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root
from escort_ais.methods.nd_basin_tree import cells_from_spec
from escort_ais.methods.nd_flatbottom import interior_mask

ROOT = project_root()

#: the stratified identity must reproduce the trace's own f_rel to this tolerance (kT)
IDENTITY_TOL = 1e-6
#: bootstrap replicates for the reference confidence interval
N_BOOT_REF = 500
#: block lengths swept, as multiples of tau_int; the WIDEST resulting interval is reported.
#: A single multiple is not safe here. `origin` indexes a TEMPERATURE RUNG of the ladder, not a
#: continuous walker: after every exchange a different walker occupies the rung, so the cell
#: indicator decorrelates faster than the underlying physical process and tau_int is an
#: UNDERESTIMATE. Measured sensitivity (alanine, rgd_redPheVal): the interval widens ~18% from
#: 5*tau to 50*tau and then plateaus, so sweeping and taking the widest lands on the plateau
#: instead of on the optimistic first value.
BLOCK_TAU_MULTIPLES = (5, 25, 50)


def integrated_autocorr(x: np.ndarray, max_lag: int | None = None) -> float:
    """tau_int of a 0/1 indicator series by the initial-positive-sequence estimator.

    REMD frames are a correlated time series, so an i.i.d. bootstrap over frames would understate
    the reference uncertainty by roughly sqrt(2*tau) -- for a cell whose occupancy switches on a
    nanosecond timescale at 10-20 ps sampling that is an order of magnitude.
    """
    x = np.asarray(x, float)
    x = x - x.mean()
    n = len(x)
    if n < 8 or np.allclose(x, 0.0):
        return 1.0
    max_lag = min(n // 4, 2000) if max_lag is None else max_lag
    v = np.dot(x, x) / n
    if v <= 0:
        return 1.0
    tau = 0.5
    for k in range(1, max_lag):
        c = np.dot(x[:-k], x[k:]) / (n - k) / v
        if c <= 0.0:            # initial positive sequence: stop at the first non-positive lag
            break
        tau += c
    return float(max(tau, 0.5))


def reference_ci(reference: Path, assign, n_cells: int, hot_rung: int,
                 n_boot: int = N_BOOT_REF, seed: int = 20260809) -> dict:
    """[5%, 95%] CI on every reference term, by block bootstrap WITHIN each replica stream.

    Blocks are contiguous and resampled inside their own stream, so the ladder structure and the
    per-stream frame counts are preserved -- pooling streams would mix ensembles at different
    scales, and resampling whole streams (only 6 of them) would give a hopelessly coarse interval.

    The MBAR weights are held FIXED and re-summed over the resampled frames. That captures the
    sampling uncertainty of the populations given the reweighting, which dominates here, but NOT
    the uncertainty of the MBAR free energies themselves -- so these intervals are a lower bound on
    the total reference uncertainty, and are labelled as such.
    """
    z = np.load(reference)
    ang, w, origin = reference_angles(z), z["weights"].astype(float), z["origin"]
    lab = assign(ang)
    rng = np.random.default_rng(seed)

    streams = sorted(int(s) for s in np.unique(origin))
    idx_by_stream = {s: np.flatnonzero(origin == s) for s in streams}

    # block length from the slowest cell indicator in the cold stream
    cold = idx_by_stream[0]
    taus = [integrated_autocorr((lab[cold] == m).astype(float)) for m in range(n_cells)]
    tau = float(max(taus))

    def one(L):
        f_rel_b, hot_b = [], []
        for _ in range(n_boot):
            pick = {}
            for st, idx in idx_by_stream.items():
                nb = max(1, len(idx) // L)
                starts = rng.integers(0, max(1, len(idx) - L), size=nb)
                pick[st] = np.concatenate([idx[s:s + L] for s in starts])
            allf = np.concatenate([pick[s] for s in streams])
            wl, ll = w[allf], lab[allf]
            pc = np.array([wl[ll == m].sum() for m in range(n_cells)], float)
            hl = lab[pick[hot_rung]]
            ph = np.array([(hl == m).sum() for m in range(n_cells)], float)
            if (pc <= 0).any() or (ph <= 0).any():
                continue
            pc /= pc.sum(); ph /= ph.sum()
            f_rel_b.append(-np.log(pc[1:] / pc[0]))
            hot_b.append(-np.log(ph[1:] / ph[0]))
        if len(f_rel_b) < n_boot // 2:
            return None
        return np.array(f_rel_b), np.array(hot_b)

    sweep, best, best_L, best_w = [], None, None, -1.0
    for mult in BLOCK_TAU_MULTIPLES:
        L = int(max(2, round(mult * tau)))
        # need enough blocks per stream for the resampling to mean anything
        if min(len(i) for i in idx_by_stream.values()) // L < 10:
            sweep.append(dict(multiple=mult, block_len_frames=L, skipped="fewer than 10 blocks"))
            continue
        r = one(L)
        if r is None:
            sweep.append(dict(multiple=mult, block_len_frames=L, skipped="cells unoccupied"))
            continue
        F, H = r
        width = float(np.max(np.percentile(F, 95, axis=0) - np.percentile(F, 5, axis=0)))
        sweep.append(dict(multiple=mult, block_len_frames=L, f_rel_ci_width_kT=width))
        if width > best_w:
            best, best_L, best_w = r, L, width
    if best is None:
        raise SystemExit("no usable block length: the reference is too short or too sparse")
    F, H = best
    M = F - H
    q = lambda A: (np.percentile(A, 5, axis=0), np.percentile(A, 95, axis=0))
    lo_f, hi_f = q(F); lo_h, hi_h = q(H); lo_m, hi_m = q(M)
    return dict(tau_int_frames=tau, block_len_frames=best_L, n_boot=int(len(F)),
                block_sweep=sweep,
                f_rel_ci=[lo_f.tolist(), hi_f.tolist()],
                hot_term_ci=[lo_h.tolist(), hi_h.tolist()],
                matched_term_ci=[lo_m.tolist(), hi_m.tolist()],
                note=("block bootstrap within each temperature stream, widest of a block-length "
                      "sweep, MBAR weights held fixed. Still a LOWER BOUND on the total reference "
                      "uncertainty: it excludes the uncertainty of the MBAR free energies "
                      "themselves, and tau_int measured on a temperature stream understates the "
                      "correlation of the underlying physical process."))


def load_partition(path: Path):
    """(labels, assign) for either partition schema.

    ``nd_basin_tree`` writes {"n_cv","cells",...} and assigns with ``interior_mask``; the 2-D
    alanine ``barrier_partition`` writes {"basins","cuts"} and assigns with ``assign_basins``.
    They are not interchangeable, and reading one with the other's loader raises KeyError at best.
    """
    spec = json.loads(Path(path).read_text())
    if "cells" in spec:
        cells = cells_from_spec(spec)

        def assign(ang):
            lab = np.full(len(ang), -1, int)
            for i, c in enumerate(cells):
                lab[interior_mask(ang, c) & (lab < 0)] = i
            return lab
        return [c.label for c in cells], assign
    from escort_ais.methods.barrier_partition import assign_basins, partition_from_dict
    basins = partition_from_dict(spec)
    return [b.label for b in basins], (lambda ang: assign_basins(ang[:, 0], ang[:, 1], basins))


def reference_angles(z) -> np.ndarray:
    """Reference clouds store either an (n, n_cv) `angles` array or separate `phi`/`psi`."""
    if "angles" in z.files:
        return z["angles"].astype(float)
    if "phi" in z.files and "psi" in z.files:
        return np.column_stack([z["phi"], z["psi"]]).astype(float)
    raise SystemExit(f"reference has neither `angles` nor `phi`/`psi`: {z.files}")


def cell_populations(angles_rad, assign, n_cells, weights=None) -> np.ndarray:
    """Normalised population of each cell; weighted if ``weights`` is given, else by counting."""
    lab = assign(angles_rad)
    if (lab < 0).any():
        raise SystemExit(f"{int((lab < 0).sum())} reference frames fall outside an exhaustive "
                         f"partition")
    pi = np.array([float(weights[lab == i].sum()) if weights is not None else float((lab == i).sum())
                   for i in range(n_cells)])
    if (pi <= 0).any():
        raise SystemExit(f"a cell has no reference support: {pi.tolist()}")
    return pi / pi.sum()


def reference_terms(reference: Path, assign, n_cells: int, hot_rung: int | None = None,
                    with_ci: bool = True) -> dict:
    """Every term of the identity, from REMD-MBAR (cold) and the s=0.25 rung (hot).

    Returns gauge-free quantities relative to cell 0: ``f_rel``, ``hot_term`` and the implied
    ``matched_term = f_rel - hot_term``.
    """
    z = np.load(reference)
    ang, w, origin, scales = (reference_angles(z), z["weights"].astype(float),
                              z["origin"], z["scales"])
    rung = int(len(scales) - 1) if hot_rung is None else int(hot_rung)
    if abs(float(scales[rung]) - 0.25) > 1e-6:
        raise SystemExit(f"rung {rung} has s={float(scales[rung])}, not 0.25 -- refusing to call "
                         f"it the hot state")
    hot_sel = np.flatnonzero(origin == rung)
    if hot_sel.size == 0:
        raise SystemExit(f"no frames with origin == {rung}")

    pi_cold = cell_populations(ang, assign, n_cells, w / w.sum())   # all-replica MBAR, cold
    pi_hot = cell_populations(ang[hot_sel], assign, n_cells)        # s=0.25 rung, counted
    f_rel = -np.log(pi_cold[1:] / pi_cold[0])
    hot = -np.log(pi_hot[1:] / pi_hot[0])
    out = dict(pi_cold=pi_cold, pi_hot=pi_hot, f_rel=f_rel, hot_term=hot,
               matched_term=f_rel - hot, hot_rung=rung, n_hot_frames=int(hot_sel.size))
    if with_ci:
        out.update(reference_ci(reference, assign, n_cells, rung))
    return out


def load_stratified_trace(path: Path, labels: list[str]) -> list:
    """Normalise the two stored stratified schemas onto one shape.

    ``rgd_stratified_trace`` writes {"matched": {cell: ...}, "pi_hot": [...], "f_rel": {cell: ...}}.
    ``run_condbar_remdfree --also-stratified`` nests its solution per generation instead and names
    the same quantities differently: ``delta_CH`` for the matched term, ``fH`` for the hot term
    ALREADY as a free energy relative to cell 0, and ``f_rel`` as a LIST. Reading one as the other
    silently transposes a free energy into a population, so the two are converted explicitly here
    rather than duck-typed at the use site.
    """
    doc = json.loads(Path(path).read_text())
    if isinstance(doc, list):
        return doc
    out = []
    for g in doc["generations"]:
        st = g.get("stratified")
        if not st:
            continue
        fh = np.asarray(st["fH"], float)            # f^H_m - f^H_0, kT
        pi = np.exp(-fh)
        out.append(dict(generation=g["generation"],
                        matched={l: float(v) for l, v in zip(labels, st["delta_CH"])},
                        pi_hot=(pi / pi.sum()).tolist(),
                        f_rel={l: float(v) for l, v in zip(labels, st["f_rel"])}))
    if not out:
        raise SystemExit(f"{path}: no stratified block found")
    return out


def decompose_stratified(trace: list, labels: list[str], ref: dict) -> list[dict]:
    """Per generation: the matched and hot terms, and each one's error against the reference."""
    out, skipped = [], []
    for tr in trace:
        matched = np.array([tr["matched"][l] for l in labels], float)
        md = matched[1:] - matched[0]                          # gauge cancels in the difference
        ph = np.array(tr["pi_hot"], float)
        frel = np.array([np.nan if tr["f_rel"][l] is None else tr["f_rel"][l]
                         for l in labels[1:]], float)
        # A generation whose hot pool has not yet VISITED a cell has pi_hot = 0 there, so the hot
        # term is genuinely undefined -- an early-budget data condition, not a broken convention.
        # Skipped and counted, never silently dropped: a decomposition that quietly discards its
        # least converged generations would flatter every arm it scores.
        if (ph <= 0).any() or not np.isfinite(frel).all():
            skipped.append(dict(generation=tr["generation"], pi_hot=ph.tolist(),
                                reason=("empty hot cell" if (ph <= 0).any() else "f_rel undefined")))
            continue
        hot = -np.log(ph[1:] / ph[0])
        # the identity is the whole basis of the attribution -- verify, never assume
        if not np.allclose(md + hot, frel, atol=IDENTITY_TOL):
            raise SystemExit(
                f"generation {tr['generation']}: matched + hot = {(md + hot).tolist()} does not "
                f"reproduce the trace's f_rel = {frel.tolist()}. The stored sign or normaliser "
                f"convention has changed; the attribution below would be meaningless.")
        out.append(dict(generation=tr["generation"],
                        matched=md.tolist(), hot=hot.tolist(), f_rel=frel.tolist(),
                        pi_hot_ais=ph.tolist(),
                        matched_err=(md - ref["matched_term"]).tolist(),
                        hot_err=(hot - ref["hot_term"]).tolist(),
                        f_rel_err=(frel - ref["f_rel"]).tolist()))
    if skipped:
        print(f"  [skipped {len(skipped)} generation(s) with an unvisited hot cell: "
              f"{[s['generation'] for s in skipped]}]")
    return out


def decompose_normal(rows: list, labels: list[str], ref: dict) -> list[dict]:
    """Per generation: normal cBAR's cold populations and its f_rel error.

    Normal cBAR anchors on the WHOLE hot state, so it has no hot-partition term to check -- and
    therefore cannot inherit an error living in one. Runs do not all anchor `rel` on the same cell,
    so it is re-anchored to labels[0] here.
    """
    out = []
    for r in rows:
        p = np.array([r["populations"][l] for l in labels], float)
        rel = np.array([r["rel"][l] - r["rel"][labels[0]] for l in labels[1:]], float)
        out.append(dict(generation=r["gen"], pi_cold_ais=p.tolist(), f_rel=rel.tolist(),
                        f_rel_err=(rel - ref["f_rel"]).tolist(),
                        pi_ratio_to_ref=(p / ref["pi_cold"]).tolist()))
    return out


def _pops_from_boxes(boxes, labels):
    """Cold populations implied by the per-box delta values (report convention f_H - f_m)."""
    d = {b["box"]: b["delta"] for b in boxes}
    rel = np.array([-(d[l] - d[labels[0]]) for l in labels], float)   # f_m - f_0
    p = np.exp(-rel)
    return (p / p.sum()).tolist()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--system", required=True)
    ap.add_argument("--run-dir", type=Path, required=True,
                    help="normal cBAR run holding condbar_generations.json")
    ap.add_argument("--strat", type=Path, required=True, help="stratified trace JSON")
    ap.add_argument("--reference", type=Path, required=True, help="cold_reference.npz")
    ap.add_argument("--partition", type=Path, required=True)
    ap.add_argument("--hot-rung", type=int, default=None,
                    help="origin index of the s=0.25 rung (default: the last)")
    ap.add_argument("--out", type=Path, default=None)
    a = ap.parse_args(argv)

    labels, assign = load_partition(a.partition)
    ref = reference_terms(a.reference, assign, len(labels), a.hot_rung)
    strat = decompose_stratified(load_stratified_trace(a.strat, labels), labels, ref)
    ncand = a.run_dir / "condbar_generations.json"
    if ncand.exists():
        normal = decompose_normal(json.loads(ncand.read_text())["rows"], labels, ref)
    else:
        # the alanine driver writes both arms into remdfree_results.json instead
        doc = json.loads((a.run_dir / "remdfree_results.json").read_text())
        rows = [dict(gen=g["generation"],
                     populations={l: p for l, p in zip(
                         labels, _pops_from_boxes(g["boxes"], labels))},
                     rel={l: -(d - {b["box"]: b["delta"] for b in g["boxes"]}[labels[0]])
                          for l, d in ((b["box"], b["delta"]) for b in g["boxes"])})
                for g in doc["generations"]]
        normal = decompose_normal(rows, labels, ref)

    print(f"=== {a.system} ===  cells {labels}")
    print(f"  reference  pi_cold {np.round(ref['pi_cold'], 4).tolist()}   "
          f"pi_hot(s=0.25, {ref['n_hot_frames']} frames) {np.round(ref['pi_hot'], 4).tolist()}")
    def ci(key):
        lo, hi = ref[key + "_ci"]
        return "[" + ", ".join(f"{a:+.3f},{b:+.3f}" for a, b in zip(lo, hi)) + "]"
    print(f"    f_rel   {np.round(ref['f_rel'], 3).tolist()}   90% CI {ci('f_rel')}")
    print(f"    matched {np.round(ref['matched_term'], 3).tolist()}   90% CI {ci('matched_term')}")
    print(f"    hot     {np.round(ref['hot_term'], 3).tolist()}   90% CI {ci('hot_term')}")
    print(f"    (block bootstrap, tau_int {ref['tau_int_frames']:.1f} frames -> block "
          f"{ref['block_len_frames']} frames, {ref['n_boot']} replicates)\n")

    hdr = (f"{'gen':>4} | {'matched':>9} {'err':>8} | {'hot':>8} {'err':>8} | "
           f"{'f_rel':>8} {'err':>8} | {'pi_hot AIS':>11}")
    print(hdr); print("-" * len(hdr))
    for s in strat:
        if s["generation"] % 4 and s is not strat[-1]:
            continue
        print(f"{s['generation']:>4} | {s['matched'][0]:9.3f} {s['matched_err'][0]:+8.3f} | "
              f"{s['hot'][0]:8.3f} {s['hot_err'][0]:+8.3f} | "
              f"{s['f_rel'][0]:8.3f} {s['f_rel_err'][0]:+8.3f} | "
              f"{np.round(s['pi_hot_ais'], 4).tolist()}")

    print(f"\n  normal cBAR cold populations (no hot-partition term to check):")
    for r in (normal[len(normal)//4], normal[len(normal)//2], normal[-1]):
        print(f"    gen {r['generation']:>3}: AIS {np.round(r['pi_cold_ais'], 4).tolist()}"
              f"   ref {np.round(ref['pi_cold'], 4).tolist()}"
              f"   f_rel err {r['f_rel_err'][0]:+.3f} kT")

    last = strat[-1]
    print(f"\n  ATTRIBUTION at generation {last['generation']} (kT):")
    for j, lab in enumerate(labels[1:]):
        print(f"    {lab}:  total {last['f_rel_err'][j]:+.3f}  =  matched "
              f"{last['matched_err'][j]:+.3f}  +  hot {last['hot_err'][j]:+.3f}")

    if a.out:
        a.out.parent.mkdir(parents=True, exist_ok=True)
        a.out.write_text(json.dumps(dict(
            system=a.system, cells=labels,
            reference={k: (v.tolist() if isinstance(v, np.ndarray) else v)
                       for k, v in ref.items()},
            stratified=strat, normal=normal), indent=2) + "\n")
        print(f"\nwrote {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
