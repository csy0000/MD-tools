"""campaign_v1 report revision: nested convergence, independent references, cluster-aware errors.

No simulation is rerun. Every number here comes from stored AIS work, stored landing coordinates,
the stored reverse banks, and the stored REMD trajectories.

Three things this module fixes about the original report.

1. NESTED CONVERGENCE (report section 3). The campaign's ten "generations" are independent
   fixed-budget replicates. A running mean across them is not the convergence of a single
   calculation. Here we build genuinely nested prefixes within each generation -- every smaller
   subset is contained in every larger one -- in the deterministic stored order, and sweep N_F at
   fixed N_R and N_R at fixed N_F.

2. THE REPORTED QUANTITY (section 3). The primary result is the relative cold-substate free energy
   f_m - f_0 with C_0 = B_0 fixed, obtained as

       f_m - f_0 = Delta_m - Delta_0 = -(delta_m - delta_0),

   since delta_m = f_H - f_m = -Delta_m. B_0 is fixed by construction everywhere.

3. CLUSTER-AWARE UNCERTAINTY (section 5). Reverse legs that share an originating REMD frame are
   not independent: B1 draws 1100 legs from 173 unique seeds, one seed contributing up to 27 legs.
   Bootstrapping trajectories would therefore understate the error. We resample forward
   trajectories individually and reverse trajectories by SEED CLUSTER.

The estimator itself is untouched: conditional_bar_delta with M_m = log(N_F / N_R_m) over the whole
forward bank.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from escort_ais.analysis.condbar_v1_reconstruct import (CAMPAIGN, forward_generation, replay,
                                                        cluster_summary)
from escort_ais.common.paths import project_root
from escort_ais.methods.barrier_partition import assign_basins, partition_from_dict
from escort_ais.methods.conditional_bar import conditional_bar_delta, jarzynski_delta

ROOT = project_root()
REMD_DIR = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_mbondi3_6rep_300K_remd_100ns"
REF_BASIN = 0                      # C_0 = B_0, fixed everywhere, never re-chosen
N_BOXES = 3
NF_GRID = {"200": [25, 50, 100, 200], "800": [50, 100, 200, 400, 800]}
NR_GRID = [10, 20, 50, 100]


def partition():
    return partition_from_dict(json.loads((CAMPAIGN / "basin_tree.json").read_text()))


# ── the estimand ─────────────────────────────────────────────────────────────────────────────
def relative_free_energies(deltas: np.ndarray) -> np.ndarray:
    """f_m - f_0 from delta_m = f_H - f_m.  f_m - f_0 = -(delta_m - delta_0)."""
    d = np.asarray(deltas, float)
    return -(d - d[REF_BASIN])


def solve_deltas(Wf, lab, reverse, n_forward=None):
    """delta_m = f_H - f_m for every box, from a forward bank and per-box reverse works."""
    n_f = int(len(Wf) if n_forward is None else n_forward)
    out = np.full(N_BOXES, np.nan)
    for m in range(N_BOXES):
        wr = reverse[m]
        if len(wr) == 0 or not np.any(lab == m):
            continue
        out[m] = -conditional_bar_delta(Wf, lab == m, wr, n_forward=n_f)
    return out


def solve_landing(Wf, lab):
    return np.array([-jarzynski_delta(Wf, lab == m, n_forward=len(Wf)) for m in range(N_BOXES)])


# ── section 3.1: nested convergence ──────────────────────────────────────────────────────────
def nested_convergence(tag: str, arm: str = "equal") -> dict:
    """Sweep N_F at max N_R, and N_R at max N_F, using nested prefixes in stored order."""
    part = partition()
    rep, _ = replay(CAMPAIGN / f"campaign_results_nf{tag}.json")
    out = {"tag": tag, "arm": arm, "reference_basin": f"B{REF_BASIN}",
           "vs_NF": [], "vs_NR": []}
    per_gen = {}
    for g in range(1, 11):
        Wf, phi, psi = forward_generation(int(tag), g)
        per_gen[g] = (Wf, assign_basins(phi, psi, part),
                      {m: rep[(arm, g, m)][0] for m in range(N_BOXES)})

    nr_max = min(len(per_gen[1][2][m]) for m in range(N_BOXES))
    for nf in NF_GRID[tag]:
        vals, land = [], []
        for g, (Wf, lab, rv) in per_gen.items():
            if nf > len(Wf):
                continue
            sub, sl = Wf[:nf], lab[:nf]
            if not all(np.any(sl == m) for m in range(N_BOXES)):
                continue                                  # a box with no forward hit is undefined
            vals.append(relative_free_energies(solve_deltas(sub, sl, rv)))
            land.append(relative_free_energies(solve_landing(sub, sl)))
        if vals:
            v, l = np.array(vals), np.array(land)
            out["vs_NF"].append(dict(N_F=int(nf), N_R=int(nr_max), n_generations=len(vals),
                                     condbar_mean=np.nanmean(v, 0).tolist(),
                                     condbar_sd=np.nanstd(v, 0, ddof=1).tolist(),
                                     landing_mean=np.nanmean(l, 0).tolist(),
                                     landing_sd=np.nanstd(l, 0, ddof=1).tolist()))
    for nr in NR_GRID:
        vals = []
        for g, (Wf, lab, rv) in per_gen.items():
            sub = {m: rv[m][:nr] for m in range(N_BOXES)}
            if any(len(sub[m]) == 0 for m in range(N_BOXES)):
                continue
            vals.append(relative_free_energies(solve_deltas(Wf, lab, sub)))
        if vals:
            v = np.array(vals)
            out["vs_NR"].append(dict(N_R=int(nr), N_F=int(tag), n_generations=len(vals),
                                     condbar_mean=np.nanmean(v, 0).tolist(),
                                     condbar_sd=np.nanstd(v, 0, ddof=1).tolist()))
    return out


# ── section 4.1: independent cold-MD reference ───────────────────────────────────────────────
def _iat(x: np.ndarray, n_max: int = 2000) -> float:
    x = np.asarray(x, float) - np.mean(x)
    n, var = len(x), np.dot(x, x) / len(x)
    if var <= 0:
        return 1.0
    tau = 1.0
    for k in range(1, min(n_max, n - 1)):
        c = np.dot(x[:-k], x[k:]) / (n * var)
        if c <= 0:
            break
        tau += 2.0 * c
    return float(tau)


def cold_md_reference(n_boot: int = 2000, seed: int = 7) -> dict:
    """pi_m and f_m - f_0 from the PHYSICAL s=1 replica slot alone, block-bootstrapped.

    Frames are strongly autocorrelated, so a naive per-frame bootstrap would badly understate the
    error. Block length is set from the integrated autocorrelation time of the basin indicators.
    """
    import mdtraj as md

    part = partition()
    top = REMD_DIR / "start_structure_minimized.pdb"
    t = md.load_dcd(str(REMD_DIR / "replica_00/trajectory.dcd"), top=str(top))
    phi, psi = md.compute_phi(t)[1][:, 0], md.compute_psi(t)[1][:, 0]
    lab = assign_basins(phi, psi, part)
    ind = np.stack([(lab == m).astype(float) for m in range(N_BOXES)])
    taus = [_iat(ind[m]) for m in range(N_BOXES)]
    block = int(max(50, np.ceil(5 * max(taus))))          # >= 5 tau, conservative
    n = len(lab)
    nblocks = n // block
    rng = np.random.default_rng(seed)
    starts = np.arange(nblocks) * block
    boot = []
    for _ in range(n_boot):
        pick = rng.choice(starts, size=nblocks, replace=True)
        idx = np.concatenate([np.arange(s, s + block) for s in pick])
        l = lab[idx]
        pi = np.array([(l == m).mean() for m in range(N_BOXES)])
        if np.all(pi > 0):
            boot.append(-np.log(pi / pi[REF_BASIN]))
    boot = np.array(boot)
    pi = np.array([(lab == m).mean() for m in range(N_BOXES)])
    return dict(source="REMD replica_00 (physical s=1 slot) only", n_frames=int(n),
                tau_int=taus, block_length=int(block), n_blocks=int(nblocks),
                n_bootstrap=int(len(boot)), pi=pi.tolist(),
                f_m_minus_f0=(-np.log(pi / pi[REF_BASIN])).tolist(),
                ci_low=np.percentile(boot, 2.5, axis=0).tolist(),
                ci_high=np.percentile(boot, 97.5, axis=0).tolist(),
                sd=boot.std(0, ddof=1).tolist())


# ── section 5.1: seed-cluster-aware bootstrap ────────────────────────────────────────────────
def cluster_bootstrap(tag: str, arm: str = "equal", n_boot: int = 500, seed: int = 11) -> dict:
    """Resample forward trajectories individually and reverse legs BY SEED CLUSTER.

    Pooling all generations gives the largest reverse bank per box; clusters are unique seed
    frames. Resampling trajectories instead would treat 27 legs from one B1 seed as 27 independent
    observations.
    """
    part = partition()
    rep, _ = replay(CAMPAIGN / f"campaign_results_nf{tag}.json")
    Wf, lab = [], []
    for g in range(1, 11):
        w, phi, psi = forward_generation(int(tag), g)
        Wf.append(w); lab.append(assign_basins(phi, psi, part))
    Wf, lab = np.concatenate(Wf), np.concatenate(lab)
    rw, rs = {}, {}
    for m in range(N_BOXES):
        rw[m] = np.concatenate([rep[(arm, g, m)][0] for g in range(1, 11)])
        rs[m] = np.concatenate([rep[(arm, g, m)][1] for g in range(1, 11)])

    clusters = {m: {s: np.flatnonzero(rs[m] == s) for s in np.unique(rs[m])} for m in range(N_BOXES)}
    rng = np.random.default_rng(seed)
    boot = []
    for _ in range(n_boot):
        fi = rng.integers(0, len(Wf), len(Wf))
        sub_r = {}
        for m in range(N_BOXES):
            keys = list(clusters[m])
            pick = rng.choice(len(keys), size=len(keys), replace=True)
            sub_r[m] = np.concatenate([rw[m][clusters[m][keys[k]]] for k in pick])
        d = solve_deltas(Wf[fi], lab[fi], sub_r)
        if np.all(np.isfinite(d)):
            boot.append(np.concatenate([relative_free_energies(d),
                                        np.exp(d - np.max(d)) / np.sum(np.exp(d - np.max(d)))]))
    boot = np.array(boot)
    point = solve_deltas(Wf, lab, rw)
    pi_hat = np.exp(point - point.max()); pi_hat /= pi_hat.sum()
    cs = cluster_summary()
    return dict(tag=tag, arm=arm, n_bootstrap=int(len(boot)), n_forward_total=int(len(Wf)),
                f_m_minus_f0=relative_free_energies(point).tolist(),
                f_ci_low=np.percentile(boot[:, :N_BOXES], 2.5, 0).tolist(),
                f_ci_high=np.percentile(boot[:, :N_BOXES], 97.5, 0).tolist(),
                f_sd=boot[:, :N_BOXES].std(0, ddof=1).tolist(),
                pi=pi_hat.tolist(),
                pi_ci_low=np.percentile(boot[:, N_BOXES:], 2.5, 0).tolist(),
                pi_ci_high=np.percentile(boot[:, N_BOXES:], 97.5, 0).tolist(),
                reverse_clusters={f"B{m}": int(len(clusters[m])) for m in range(N_BOXES)},
                reverse_legs={f"B{m}": int(len(rw[m])) for m in range(N_BOXES)},
                bank_cluster_summary=cs)


def main() -> int:
    out = dict(reference_basin=f"B{REF_BASIN}",
               cold_md=cold_md_reference(),
               nested={tag: nested_convergence(tag) for tag in ("200", "800")},
               cluster_bootstrap={tag: cluster_bootstrap(tag) for tag in ("200", "800")})
    dest = CAMPAIGN / "revision_analysis.json"
    dest.write_text(json.dumps(out, indent=2) + "\n")
    print(f"wrote {dest}")
    cm = out["cold_md"]
    print(f"\ncold-MD reference (block {cm['block_length']}, tau {np.round(cm['tau_int'], 1)}):")
    for m in range(N_BOXES):
        print(f"  B{m}: f_m-f_0 = {cm['f_m_minus_f0'][m]:+.4f} "
              f"[{cm['ci_low'][m]:+.4f}, {cm['ci_high'][m]:+.4f}]")
    for tag in ("200", "800"):
        cb = out["cluster_bootstrap"][tag]
        print(f"\ncluster bootstrap N_F={tag} ({cb['n_bootstrap']} reps, "
              f"clusters {cb['reverse_clusters']}):")
        for m in range(N_BOXES):
            print(f"  B{m}: f_m-f_0 = {cb['f_m_minus_f0'][m]:+.4f} "
                  f"[{cb['f_ci_low'][m]:+.4f}, {cb['f_ci_high'][m]:+.4f}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
