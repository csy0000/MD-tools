"""hz_slice_range_study.py — WHICH slices to use, not how many (report §4, supplementary).

The L-sweep in :mod:`hz_slice_study` answers the question as posed ("is L = 20 enough?") and
gets a non-monotonic answer: on the log-PMF metric L = 1 (0.53 kT) beats L = 20 (1.65 kT) beats
L = 40 (2.60 kT).  That is not noise and it is not a bug in the combiner — ESS-weighting the
slices instead of averaging them changes nothing material (L = 40: 2.78 vs 2.60 kT).

The cause is measurable per slice.  An HS slice at scale ``s`` is reweighted to cold by
``exp[-(u_C - u_s)]``, i.e. a **single-step Zwanzig reweight across the remaining tempering
gap**.  For alanine that gap is enormous at the hot end (the whole REST2 work is ≈ 48 kT), so:

    slice s     0.25    0.33    0.43    0.53    0.65    0.78    0.93
    ESS/256      6.4    11.7    10.6    23.4    57.4    85.0    96.9
    RMSE (kT)   4.97    3.03    1.94    1.87    1.21    1.08    0.76

Hot slices are individually unbiased but individually *useless*, and averaging them into the
estimate injects log-space noise.  So the actionable knob is the **s-range**, not the count:
this module sweeps ``s_min`` and reports where the two families of metric — log-PMF error
(barrier heights) and linear population error (basin weights) — actually optimise.

Recording all 20 slices costs ~2 % wall clock, so the recommendation is to keep recording them
(they are nearly free, and they are what makes the s-range study possible at all) and to let the
*estimator* select.
"""
from __future__ import annotations

import numpy as np

from escort_ais.analysis.hz_reconstruction import hz_histogram, hz_log_weights, weighted_ess
from escort_ais.analysis.hz_slice_study import (PHI_BINS, population_mae, pmf_rmse,
                                                support_coverage, trajectory_bootstrap)

__all__ = ["per_slice_diagnostics", "s_range_sweep", "recommend_s_min"]


def per_slice_diagnostics(hz, bins=PHI_BINS, ref=None, column: str = "phi") -> dict:
    """ESS and standalone reconstruction error of every recorded slice."""
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    rows = []
    for sid, g in hz.groupby(slice_col):
        lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                            g["u_cold_reduced"])
        p = hz_histogram(g[column], lw, bins)
        rows.append(dict(observation_id=int(sid), s=float(g["s"].iloc[0]),
                         sqrt_s=float(g["sqrt_s"].iloc[0]),
                         n_samples=int(len(g)), ess=weighted_ess(lw),
                         ess_fraction=weighted_ess(lw) / max(len(g), 1),
                         pmf_rmse_kT=(pmf_rmse(p, ref) if ref is not None else float("nan"))))
    rows.sort(key=lambda r: r["s"])
    return dict(slices=rows)


def _combined(hz, s_min, bins, column, combine="ess_weighted"):
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    sub = hz if s_min is None else hz[hz["s"] >= s_min]
    dens, ess = [], []
    for _sid, g in sub.groupby(slice_col):
        lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                            g["u_cold_reduced"])
        dens.append(hz_histogram(g[column], lw, bins))
        ess.append(weighted_ess(lw))
    if not dens:
        return None, 0.0, 0
    D, e = np.vstack(dens), np.asarray(ess, float)
    p = ((D * e[:, None]).sum(0) / e.sum()) if (combine == "ess_weighted" and e.sum() > 0) \
        else D.mean(0)
    return p / p.sum(), float(e.sum()), len(dens)


def s_range_sweep(hz, ref, s_mins=(None, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95),
                  bins=PHI_BINS, column: str = "phi", n_boot: int = 200) -> dict:
    """Metrics as a function of the cold-side cut ``s >= s_min``."""
    traj_col = "trajectory_id" if "trajectory_id" in hz.columns else "trajectory_index"
    centres = 0.5 * (np.asarray(bins)[:-1] + np.asarray(bins)[1:])
    ref_pop = float(np.asarray(ref)[centres > 0].sum()) if ref is not None else float("nan")

    rows = {}
    for s_min in s_mins:
        p, ess, n_sl = _combined(hz, s_min, bins, column)
        if p is None:
            continue
        sub = hz if s_min is None else hz[hz["s"] >= s_min]

        def _rmse(rows_idx, _sub=sub):
            g = _sub.iloc[rows_idx]
            lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                                g["u_cold_reduced"])
            return pmf_rmse(hz_histogram(g[column], lw, bins), ref)

        bm, bs = ((float("nan"), float("nan")) if ref is None else
                  trajectory_bootstrap(sub[traj_col].to_numpy(), _rmse, n_boot=n_boot))
        rows[("all" if s_min is None else f"{s_min:g}")] = dict(
            s_min=s_min, n_slices_used=n_sl, total_ess=ess,
            pmf_rmse_kT=(pmf_rmse(p, ref) if ref is not None else float("nan")),
            pmf_rmse_boot_std=float(bs) if np.isfinite(bs) else float("nan"),
            population_mae=(population_mae(p, ref) if ref is not None else float("nan")),
            support_coverage=(support_coverage(p, ref) if ref is not None else float("nan")),
            basin_population_phi_gt_0=float(p[centres > 0].sum()),
            basin_population_reference=ref_pop,
            basin_population_error=float(p[centres > 0].sum() - ref_pop),
            density=p.tolist())
    return dict(name="s_range_sweep", rows=rows, reference_population=ref_pop)


def recommend_s_min(sweep: dict) -> dict:
    """Pick ``s_min`` on the log-PMF metric, and report what it costs on the linear metrics."""
    rows = {k: v for k, v in sweep["rows"].items() if np.isfinite(v["pmf_rmse_kT"])}
    if not rows:
        return dict(decision="undetermined")
    best_pmf = min(rows.items(), key=lambda kv: kv[1]["pmf_rmse_kT"])
    best_pop = min(rows.items(), key=lambda kv: abs(kv[1]["basin_population_error"]))
    best_mae = min(rows.items(), key=lambda kv: kv[1]["population_mae"])
    allrow = rows.get("all")
    return dict(
        recommended_s_min=best_pmf[1]["s_min"],
        pmf_rmse_at_recommendation=best_pmf[1]["pmf_rmse_kT"],
        pmf_rmse_using_all_slices=(allrow["pmf_rmse_kT"] if allrow else float("nan")),
        improvement_factor=((allrow["pmf_rmse_kT"] / best_pmf[1]["pmf_rmse_kT"])
                            if allrow and best_pmf[1]["pmf_rmse_kT"] > 0 else float("nan")),
        best_for_basin_population=best_pop[0],
        best_for_population_mae=best_mae[0],
        note=("log-PMF error and linear population error optimise at different cuts: the "
              "population metrics keep improving as more (hotter) slices are added, while the "
              "log-PMF error degrades. Choose per deliverable."),
        rows_summary={k: dict(pmf_rmse_kT=v["pmf_rmse_kT"],
                              population_mae=v["population_mae"],
                              basin_population_error=v["basin_population_error"],
                              n_slices_used=v["n_slices_used"]) for k, v in rows.items()})
