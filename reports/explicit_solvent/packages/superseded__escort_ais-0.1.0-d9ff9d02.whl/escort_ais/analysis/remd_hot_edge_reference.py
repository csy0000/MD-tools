"""Reusable REMD reference metric for hot-edge free energies Δ_{H→m} = f_m - f_H.

REMD is the ground truth for the free energy between the hot state H1 (s=0.25) and each cold umbrella C_m. The
reference factorizes into a window-INDEPENDENT offset and a window-DEPENDENT reweighting:

    Δ_{H→m}^{REMD} = dF_{C0-H} + ( -ln⟨e^{-U_m}⟩_{C0} ),

where dF_{C0-H} = f_{C0} - f_H is a stored scalar (MBAR over the REST2 ladder, s=1 ↔ s=0.25) and the second term is
computed on demand from the stored s=1 (C0) replica angles for WHATEVER umbrella windows an estimator used. This
lets any current or future estimator (AIS endpoint, co-switch, MTS, ...) be scored against the same REMD reference
for its own windows:

    from escort_ais.analysis.remd_hot_edge_reference import score
    result = score(f_m_estimate, windows)   # RMSE + per-window residuals vs REMD

The reference is produced by ``scripts/remd_hot_edge_fe.py`` and stored at
``results/alanine_dipeptide/remd_hot_edge_reference/reference.json``.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Sequence

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root, results_root
from escort_ais.methods.coverage_windows import bias_u

REF_PATH = "alanine_dipeptide/remd_hot_edge_reference/reference.json"


@lru_cache(maxsize=1)
def load_reference(path: str | None = None) -> dict:
    """Load the canonical REMD hot-edge reference (dF_{C0-H}, its error, and the s=1 replica angles)."""
    p = Path(path) if path else (results_root() / REF_PATH)
    if not p.exists():
        raise FileNotFoundError(f"REMD hot-edge reference not found at {p}; run scripts/remd_hot_edge_fe.py first.")
    ref = json.loads(p.read_text())
    ref["_ang0"] = np.asarray(ref["cold_replica_angles_rad"], float)   # (N,d) s=1 (C0) angles for reweight
    return ref


def _windows_list(windows) -> list[dict]:
    """Accept a list of {mu,kappa} dicts or a (mu, kappa) pair of arrays."""
    if isinstance(windows, (list, tuple)) and len(windows) == 2 and not isinstance(windows[0], dict):
        mu, kappa = np.asarray(windows[0], float), np.asarray(windows[1], float)
        return [{"mu": mu[m], "kappa": kappa[m]} for m in range(len(mu))]
    return list(windows)


def f_m_minus_c0(windows, ref: dict | None = None) -> np.ndarray:
    """Window-dependent reweight f_m - f_{C0} = -ln⟨e^{-U_m}⟩_{C0} over the stored s=1 REMD replica."""
    ref = ref or load_reference()
    ang0 = ref["_ang0"]
    return np.array([-(logsumexp(-bias_u(ang0, w)) - np.log(len(ang0))) for w in _windows_list(windows)])


def hot_edge_reference(windows, ref: dict | None = None) -> np.ndarray:
    """REMD reference Δ_{H→m} = dF_{C0-H} + (f_m - f_{C0}) for the given umbrella windows (gauge f_H=0)."""
    ref = ref or load_reference()
    return f_m_minus_c0(windows, ref) + float(ref["dF_C0_minus_H"])


def score(f_m, windows, gauge: str = "hot", ref: dict | None = None) -> dict:
    """Score an estimator's per-window free energies against the REMD reference.

    f_m    : estimator free energies. gauge='hot' ⇒ f_m already = Δ_{H→m} (f_H=0, e.g. solve_joint output);
             gauge='free' ⇒ f_m known only up to an additive constant, which is fit out before scoring (so only
             the RELATIVE per-window structure is compared, matching the reconstruction-relevant quantity).
    windows: the umbrella windows the estimator used (list of {mu,kappa} or (mu,kappa) arrays).
    Returns RMSE, MAE, max |residual|, per-window residuals, and the REMD reference values.
    """
    ref = ref or load_reference()
    f_m = np.asarray(f_m, float)
    dH_ref = hot_edge_reference(windows, ref)
    if gauge == "free":
        resid = (f_m - f_m.mean()) - (dH_ref - dH_ref.mean())
    elif gauge == "hot":
        resid = f_m - dH_ref
    else:
        raise ValueError("gauge must be 'hot' or 'free'")
    return dict(rmse=float(np.sqrt(np.mean(resid ** 2))), mae=float(np.mean(np.abs(resid))),
                max_abs=float(np.max(np.abs(resid))), residuals=resid.tolist(),
                dH_remd=dH_ref.tolist(), dF_C0_minus_H=float(ref["dF_C0_minus_H"]),
                dF_C0_minus_H_err=float(ref["dF_C0_minus_H_err"]))
