"""Revision figures for campaign_v1: nested convergence of f_m - f_0 against two references.

Adds the REMD reference uncertainty (section 4.2) and renders the primary convergence figure
(section 3.2). No simulation is rerun.

REMD uncertainty. The reported interval re-solves MBAR for every bootstrap replicate, using the
recomputed ``u_kn`` in ``cold_reference_ukn.npz``. ``remd_reference()`` below implements a cheaper
fixed-weight variant that is only a LOWER BOUND (it omits MBAR-solution uncertainty); it is
retained as a fallback and ``main()`` prefers a stored full reference when one exists.
"""
from __future__ import annotations

import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from escort_ais.analysis.condbar_v1_revision import (CAMPAIGN, REF_BASIN, N_BOXES, partition,
                                                     cold_md_reference)
from escort_ais.methods.barrier_partition import assign_basins


def remd_reference(n_boot: int = 2000, block: int = 100, seed: int = 3) -> dict:
    """All-replica MBAR cold reference with a block-bootstrap LOWER BOUND on its uncertainty."""
    ref = np.load(CAMPAIGN / "cold_reference.npz")
    w, origin = ref["weights"], ref["origin"]
    part = partition()
    lab = assign_basins(ref["phi"], ref["psi"], part)
    pi = np.array([w[lab == m].sum() for m in range(N_BOXES)])
    f = -np.log(pi / pi[REF_BASIN])

    rng = np.random.default_rng(seed)
    boot = []
    reps = np.unique(origin)
    idx_by_rep = {r: np.flatnonzero(origin == r) for r in reps}
    for _ in range(n_boot):
        take = []
        for r in reps:
            ii = idx_by_rep[r]
            nb = len(ii) // block
            starts = np.arange(nb) * block
            pick = rng.choice(starts, size=nb, replace=True)
            take.append(np.concatenate([ii[s:s + block] for s in pick]))
        take = np.concatenate(take)
        ww, ll = w[take], lab[take]
        p = np.array([ww[ll == m].sum() for m in range(N_BOXES)])
        if np.all(p > 0):
            boot.append(-np.log(p / p[REF_BASIN]))
    boot = np.array(boot)
    return dict(source="all six REST2-REMD replicas, MBAR-reweighted to s=1",
                pi=pi.tolist(), f_m_minus_f0=f.tolist(), block_length=int(block),
                n_bootstrap=int(len(boot)),
                ci_low=np.percentile(boot, 2.5, 0).tolist(),
                ci_high=np.percentile(boot, 97.5, 0).tolist(),
                sd=boot.std(0, ddof=1).tolist(),
                uncertainty_note="LOWER BOUND: block bootstrap over frames with the stored MBAR "
                                 "weights held fixed; does not include MBAR-solution uncertainty")


def figure(rev: dict, cold: dict, remd: dict):
    fig, ax = plt.subplots(2, 2, figsize=(10.5, 7.0))
    cols = {"200": "#4363d8", "800": "#e6194b"}
    for row, box in enumerate((1, 2)):
        a = ax[row, 0]
        for tag in ("200", "800"):
            d = rev["nested"][tag]["vs_NF"]
            x = [r["N_F"] for r in d]
            y = [r["condbar_mean"][box] for r in d]
            e = [r["condbar_sd"][box] / np.sqrt(r["n_generations"]) for r in d]
            a.errorbar(x, y, yerr=e, fmt="o-", ms=4, capsize=2.5, color=cols[tag],
                       label=f"conditional BAR ($N_F^{{max}}$={tag})")
            yl = [r["landing_mean"][box] for r in d]
            el = [r["landing_sd"][box] / np.sqrt(r["n_generations"]) for r in d]
            a.errorbar(x, yl, yerr=el, fmt="s--", ms=3, capsize=2, alpha=.5, color=cols[tag],
                       label=f"landing only ($N_F^{{max}}$={tag})")
        a.set_xscale("log"); a.set_xlabel(r"$N_F$ (nested prefix)")
        a.set_title(f"$f_{box}-f_0$ vs $N_F$   (at max available $N_{{R,m}}$)", fontsize=9)

        b = ax[row, 1]
        for tag in ("200", "800"):
            d = rev["nested"][tag]["vs_NR"]
            x = [r["N_R"] for r in d]
            y = [r["condbar_mean"][box] for r in d]
            e = [r["condbar_sd"][box] / np.sqrt(r["n_generations"]) for r in d]
            b.errorbar(x, y, yerr=e, fmt="o-", ms=4, capsize=2.5, color=cols[tag],
                       label=f"conditional BAR ($N_F$={tag})")
        b.set_xscale("log"); b.set_xlabel(r"$N_{R,m}$ (nested prefix)")
        b.set_title(f"$f_{box}-f_0$ vs $N_{{R,m}}$   (at max $N_F$)", fontsize=9)

        for a_ in (a, b):
            a_.axhspan(cold["ci_low"][box], cold["ci_high"][box], color="#3cb44b", alpha=.20,
                       label="cold-MD reference (95%)")
            a_.axhline(cold["f_m_minus_f0"][box], color="#3cb44b", lw=1.3)
            _full = str(remd.get("uncertainty_note", "")).startswith("full")
            a_.axhspan(remd["ci_low"][box], remd["ci_high"][box], color="k", alpha=.13,
                       label="REMD reference (95%)" if _full
                             else "REMD reference (95%, lower bound)")
            a_.axhline(remd["f_m_minus_f0"][box], color="k", lw=1.3, ls="--")
            a_.set_ylabel(rf"$f_{box}-f_0$ ($k_BT$)")
    ax[0, 0].legend(fontsize=6, ncol=2)
    fig.suptitle(r"Nested convergence of relative cold-substate free energies $f_m-f_0$ "
                 r"($C_0=B_0$ fixed)", fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(CAMPAIGN / "figures/fig4_convergence_relative.pdf", dpi=200, bbox_inches="tight")
    fig.savefig(CAMPAIGN / "figures/fig4_convergence_relative.png", dpi=150, bbox_inches="tight")


def main() -> int:
    rev = json.loads((CAMPAIGN / "revision_analysis.json").read_text())
    cold = rev["cold_md"]
    # Prefer a stored FULL reference (MBAR re-solved per replicate). Only fall back to the
    # fixed-weight lower bound if no full one has been computed.
    stored = rev.get("remd", {})
    if str(stored.get("uncertainty_note", "")).startswith("full"):
        remd = stored
        print("using stored REMD reference with MBAR re-solved per replicate")
    else:
        remd = remd_reference()
        rev["remd"] = remd
    rev["reference_comparison"] = [
        dict(box=f"B{m}", cold_md=cold["f_m_minus_f0"][m], cold_md_sd=cold["sd"][m],
             remd=remd["f_m_minus_f0"][m], remd_sd=remd["sd"][m],
             difference=cold["f_m_minus_f0"][m] - remd["f_m_minus_f0"][m])
        for m in (1, 2)]
    (CAMPAIGN / "revision_analysis.json").write_text(json.dumps(rev, indent=2) + "\n")
    (CAMPAIGN / "figures").mkdir(parents=True, exist_ok=True)
    figure(rev, cold, remd)
    print("reference comparison (f_m - f_0, kT):")
    for r in rev["reference_comparison"]:
        print(f"  {r['box']}: cold-MD {r['cold_md']:+.4f} +/- {r['cold_md_sd']:.4f}   "
              f"REMD {r['remd']:+.4f} +/- {r['remd_sd']:.4f}   diff {r['difference']:+.4f}")
    print(f"\nwrote {CAMPAIGN / 'figures/fig4_convergence_relative.pdf'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
