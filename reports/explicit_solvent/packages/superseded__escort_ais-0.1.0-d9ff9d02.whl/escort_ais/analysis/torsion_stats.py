"""torsion_stats.py — small canonical statistics helpers for torsion/population analysis.

Provides ONE canonical implementation of helpers that were copy-pasted (with diverged
signatures) across many analysis scripts. New scripts should import from here; existing
scripts are intentionally left un-repointed to avoid changing validated outputs.
"""
from __future__ import annotations

import numpy as np


def jensen_shannon(p, q, eps: float = 1e-12) -> float:
    """Jensen-Shannon divergence between two non-negative vectors (populations or histogram bins).

    Both are normalized to sum 1 (after adding `eps` for numerical safety). Symmetric, in [0, ln 2].
    For raw samples, histogram first (e.g. np.histogram(..., density=True)) then pass the bin vectors.
    """
    a = np.asarray(p, float) + eps; a = a / a.sum()
    b = np.asarray(q, float) + eps; b = b / b.sum()
    m = 0.5 * (a + b)
    return float(0.5 * np.sum(a * np.log(a / m)) + 0.5 * np.sum(b * np.log(b / m)))


def circular_mean(angles_deg) -> float:
    """Circular mean of angles given in DEGREES, returned in degrees in (-180, 180]."""
    r = np.radians(np.asarray(angles_deg, float))
    return float(np.degrees(np.arctan2(np.sin(r).mean(), np.cos(r).mean())))


def circular_std(angles_deg) -> float:
    """Circular standard deviation of angles in DEGREES (Mardia), returned in degrees."""
    r = np.radians(np.asarray(angles_deg, float))
    R = np.hypot(np.sin(r).mean(), np.cos(r).mean())
    return float(np.degrees(np.sqrt(-2.0 * np.log(max(R, 1e-9)))))
