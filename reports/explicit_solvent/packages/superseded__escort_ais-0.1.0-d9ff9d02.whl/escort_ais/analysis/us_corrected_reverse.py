#!/usr/bin/env python3
"""us_corrected_reverse.py — DEPRECATED / UNSUPPORTED (not BAUS theory).

⚠️  Uses the retired density-corrected reverse work W_1=ln(q̃_m/p), which is NOT a valid Crooks/BAR/MSK reverse
    work for a forward protocol ending in C_m (BAUS_theory.pdf Appendix A). Kept only for reproducibility; on NO
    default path. The corrected reverse work is -U_m(x_0) (methods/baus_estimator.hot_edge_works).

density-corrected reverse-leg BAR for a BAIS-US (`--method us`) run.

Post-processing (no re-run): recompute each window's ΔF-to-H1 via forward JE, reverse JE, and two-sided
BAR, using the NAIVE (−b_m) vs the density-CORRECTED (ln q̃_m/p_C0) reverse first step
(`bais_us.density_corrected_first_step`; theory: BAIS-US_theory §"The reverse leg"). The C0→H1 annealing
work is FIXED (recovered per shot from the reverse `ais_trajectory_summary.csv`); only the debias first
step changes. p_C0 is the INDEPENDENT forward-JE cold density (hot→cold landings reweighted by e^{−W_f}),
q̃_m the confined-walker density (the accumulated `reverse/umb_XX/seed_gGGGG` seeds).

Validated on alanine (big-PREP `us_gen_label`, 2200 landings): corrected two-sided BAR π(α_L)=0.024
(bandwidth-robust) vs cold-MD 0.0285, from naive BAR 0.013; rescues drift-poisoned reverse windows.

Run:  python -m escort_ais.analysis.us_corrected_reverse --run-dir data/alanine_dipeptide/bais_standalone/us_gen_label
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logsumexp

import warnings

from escort_ais.common.paths import project_root
from escort_ais.methods.bais_us import density_corrected_first_step, flatbottom_bias_D, torsion_D
from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works

warnings.warn("us_corrected_reverse is DEPRECATED/UNSUPPORTED (ln q̃_m/p is not a valid BAR reverse work); "
              "the matched reverse work is -U_m(x_0) (baus_estimator). See BAUS_theory.pdf App. A.",
              DeprecationWarning)


def _softmax_pi(dG: np.ndarray) -> np.ndarray:
    dG = np.where(np.isfinite(dG), dG, np.nanmax(dG) + 50.0)
    p = np.exp(-(dG - np.nanmin(dG)))
    return p / p.sum()


def analyze(run_dir: str | Path, *, bins: int = 48, sigma: float = 1.6, phi_pos: bool = True) -> dict:
    """Recompute forward-JE / reverse-JE / BAR ΔF-to-H1 (naive vs density-corrected reverse) for a us run.

    Returns a dict with per-window ΔF arrays and the φ>0 populations for each estimator."""
    import mdtraj as md  # local: heavy, only needed to reload confined/seed frames

    D = Path(run_dir)
    r = json.load(open(D / "us_gen_results.json"))
    cen = np.array(r["centres_deg"])
    pos = cen[:, 0] > 0.0
    z = np.load(D / "works.npz")
    Wf = z["Wf"]
    land_ang = z["land_ang"]                     # rad, (Nf, d)
    land_deg = np.degrees(land_ang)
    Nf = len(Wf)
    phi_ref, hw, kk = z["phi_ref"], z["hw"], z["k"]
    nb = len(phi_ref)
    cold_w = np.exp(-(Wf - Wf.max()))            # forward-JE cold weights

    top_pdb = glob.glob(str(D / "reverse/umb_00/seed_g*/start_structure.pdb"))[0]
    refpdb = md.load(top_pdb)
    quart = np.array([md.compute_phi(refpdb)[0][0], md.compute_psi(refpdb)[0][0]], int)

    fJE = np.full(nb, np.nan)
    rJE_n = np.full(nb, np.nan); rJE_c = np.full(nb, np.nan)
    bar_n = np.full(nb, np.nan); bar_c = np.full(nb, np.nan)
    n_rev = np.zeros(nb, int)

    for m in range(nb):
        pr = np.asarray(phi_ref[m], float)
        u_land = flatbottom_bias_D(torsion_D(land_ang, pr), hw[m], kk[m])   # (Nf,) forward bias at landings
        fJE[m] = -(logsumexp(-(Wf + u_land)) - np.log(Nf))                  # forward JE ΔF-to-H1

        conf = []                                                          # confined-walker samples (rad)
        for p in sorted(glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*/trajectory.dcd")):
            t = md.load_dcd(p, top=os.path.dirname(p) + "/start_structure.pdb")
            conf.append(md.compute_dihedrals(t, quart))
        if not conf:
            continue
        conf = np.concatenate(conf)

        Wann, start_ang = [], []                                           # C0→H1 anneal work + start config/shot
        for sdir in sorted(glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*")):
            g = os.path.basename(sdir).replace("seed_g", "")
            summ = f"{D}/reverse/umb_{m:02d}/g{g}/ais_trajectory_summary.csv"
            if not os.path.exists(summ):
                continue
            s = pd.read_csv(summ)
            wa = -s["final_logw"].to_numpy()
            ifx = s["initial_frame_index"].to_numpy().astype(int)
            sang = md.compute_dihedrals(md.load_dcd(sdir + "/trajectory.dcd",
                                                    top=sdir + "/start_structure.pdb"), quart)
            for j, fi in enumerate(ifx):
                fi = min(max(int(fi), 0), len(sang) - 1)
                Wann.append(wa[j]); start_ang.append(sang[fi])
        if not Wann:
            continue
        Wann = np.asarray(Wann); start_ang = np.asarray(start_ang)
        n_rev[m] = len(Wann)

        ub = flatbottom_bias_D(torsion_D(start_ang, pr), hw[m], kk[m])      # naive −b_m debias per shot
        w1 = density_corrected_first_step(start_ang, conf, land_ang, cold_w, bins=bins, sigma=sigma)
        Wr_n = Wann - ub                                                   # naive reverse work
        Wr_c = Wann + w1                                                   # density-corrected reverse work

        rJE_n[m] = +(logsumexp(-Wr_n) - np.log(len(Wr_n)))
        rJE_c[m] = +(logsumexp(-Wr_c) - np.log(len(Wr_c)))
        bar_n[m] = solve_bar_with_infinite_works(Wf + u_land, Wr_n, n_f_total=Nf, n_r_total=len(Wr_n))[0]
        bar_c[m] = solve_bar_with_infinite_works(Wf + u_land, Wr_c, n_f_total=Nf, n_r_total=len(Wr_c))[0]

    ests = {"forward_JE": fJE, "reverse_JE_naive": rJE_n, "reverse_JE_corrected": rJE_c,
            "BAR_naive": bar_n, "BAR_corrected": bar_c}
    phi_pos_pop = {k: float(_softmax_pi(v)[pos].sum()) for k, v in ests.items()}
    return dict(centres_deg=cen.tolist(), phi_pos=pos.tolist(), n_rev=n_rev.tolist(),
                dF_kT={k: v.tolist() for k, v in ests.items()}, phi_pos_pop=phi_pos_pop,
                phi_pos_c0_pmf=float(r.get("phi_pos_c0", float("nan"))), bins=bins, sigma=sigma)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", required=True, help="a --method us run dir (has works.npz + reverse/)")
    ap.add_argument("--bins", type=int, default=48)
    ap.add_argument("--sigma", type=float, default=1.6)
    ap.add_argument("--reference", type=float, default=None, help="reference cold φ>0 population, e.g. 0.0285")
    ap.add_argument("--out", default=None, help="write result JSON here (default: <run-dir>/corrected_reverse.json)")
    args = ap.parse_args()

    res = analyze(args.run_dir, bins=args.bins, sigma=args.sigma)
    cen = np.array(res["centres_deg"]); pos = np.array(res["phi_pos"]); dF = res["dF_kT"]
    print(f"{'umb(phi,psi)':>13} {'nrev':>5}  " + "  ".join(f"{k:>18}" for k in dF))
    for m in range(len(cen)):
        row = "  ".join(f"{dF[k][m]:18.2f}" for k in dF)
        print(f"({cen[m,0]:+5.0f},{cen[m,1]:+5.0f}) {res['n_rev'][m]:5d}  {row}{'  <phi>0' if pos[m] else ''}")
    print("\nphi>0 population:")
    for k, v in res["phi_pos_pop"].items():
        print(f"  {k:22s}: {v:.4f}")
    print(f"  {'C0-PMF (WHAM+BAR)':22s}: {res['phi_pos_c0_pmf']:.4f}")
    if args.reference is not None:
        print(f"  {'reference':22s}: {args.reference:.4f}")

    out = Path(args.out) if args.out else Path(args.run_dir) / "corrected_reverse.json"
    json.dump(res, open(out, "w"), indent=2)
    try:
        rel = out.relative_to(project_root())
    except ValueError:
        rel = out
    print(f"\nwrote {rel}")
    return res


if __name__ == "__main__":
    main()
