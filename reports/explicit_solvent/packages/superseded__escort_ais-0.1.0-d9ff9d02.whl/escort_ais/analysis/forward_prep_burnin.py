"""Forensic controls for forward-AIS burn-in: is apparent drift source-time or execution-order?

Section 7 of the 36-hour brief. Before any burn-in selector can be trusted, two things must be ruled
out, because both would masquerade as hot-source nonstationarity:

* **Control A, fixed-start replay.** Repeated fresh AIS from the SAME configurations, with
  generation labels spanning "early" and "late". AIS shots launched from fixed configurations with
  correctly seeded fresh streams are INDEPENDENT nonequilibrium trajectories, so a generation label
  alone must not move the work or landing distribution. If it does, the cause is inside the
  execution path -- Context/integrator reuse, seeding after Context creation, output mixing, state
  leakage -- and is classified ``AIS_ORDER_STATE_LEAK``, not physics. There is no Markov-chain
  burn-in to discover for independent trajectories.
* **Control B, chronological vs permuted execution.** Same starts, same seed mapping, submitted in
  chronological order and in a fixed permuted order. Execution order may change wall time; it must
  not change the joint distribution.

Every shot appends one row carrying its own provenance (§6): the exact hot frame it started from,
its chronological block, the seeds, the work, and an explicit ``record_role`` /
``accepted_for_production``. Production membership is never inferred from array position -- these
controls are ``diagnostic`` and are excluded from every production estimator by construction.

Reduced-work convention (CLAUDE.md): the AIS summary stores ``final_logw = -W/kT`` with ``final_W``
in kJ/mol, so the reduced work is ``W = -final_logw`` and cold weights are ``exp(final_logw)``.
Reading ``final_W`` directly would be off by kT.
"""
from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

from escort_ais.common.paths import project_root

ROOT = project_root()
S_HOT, S_COLD = 0.25, 1.0


@dataclass(frozen=True)
class ShotBatch:
    """One AIS launch: fixed starts, one seed, one label. The unit of the controls."""
    batch_id: str
    system: str
    record_role: str          # diagnostic | confirmation | production | failed
    generation_label: str     # the LABEL under test in Control A, not a real generation
    block_id: int             # chronological hot block the starts came from
    frame_indices: tuple[int, ...]
    ais_seed: int
    exec_order_index: int     # position in the submission sequence (Control B)
    device: str


def hot_blocks(n_frames: int, n_blocks: int) -> list[tuple[int, int]]:
    """Contiguous, NON-overlapping chronological blocks. Never wraps (§2 rule 9)."""
    edges = np.linspace(0, n_frames, n_blocks + 1).astype(int)
    return [(int(edges[i]), int(edges[i + 1])) for i in range(n_blocks)]


def pick_frames(lo: int, hi: int, k: int, rng: np.random.Generator) -> np.ndarray:
    """k distinct frame indices drawn uniformly inside one block, returned SORTED.

    Distinct because two shots from one frame share a configuration and are not independent
    starts; sorted so the recorded provenance is reproducible from (block, seed, k) alone.
    """
    if hi - lo < k:
        raise ValueError(f"block [{lo},{hi}) has {hi - lo} frames, need {k}")
    return np.sort(rng.choice(np.arange(lo, hi), size=k, replace=False))


#: A seed dir is not just coordinates: ``ais_linear.load_ais_inputs`` resolves the SYSTEM from a
#: config.json in the same directory and raises if it carries neither 'openmm_dir' nor
#: 'prmtop_path'. Reuse an existing seed config rather than hand-writing one, so the topology, GB
#: radii and solute count cannot drift from the runs this campaign is compared against.
SEED_CONFIG_TEMPLATE = "data/alanine_dipeptide/condbar_remdfree_v3/prep_g00_hotseed/config.json"


def write_seed_dir(walker: Path, frames: Sequence[int], out: Path,
                   config_template: Optional[Path] = None) -> Path:
    """Materialise the chosen hot frames as an AIS input dir (the driver reads a dir, not indices).

    Writes the frame provenance alongside, which the driver ignores but the campaign needs: the
    mapping from shot index to originating hot frame is what makes a record traceable to one exact
    frame and block rather than to an array position.
    """
    import mdtraj as md

    out.mkdir(parents=True, exist_ok=True)
    tmpl = Path(config_template) if config_template else ROOT / SEED_CONFIG_TEMPLATE
    cfg = json.loads(tmpl.read_text())
    for key in ("openmm_dir", "prmtop_path"):
        if key in cfg:
            break
    else:
        raise KeyError(f"{tmpl} carries neither 'openmm_dir' nor 'prmtop_path'; "
                       "the AIS loader cannot resolve the system from it")
    (out / "config.json").write_text(json.dumps(cfg, indent=2) + "\n")

    t = md.load_dcd(str(walker / "trajectory.dcd"), top=str(walker / "start_structure.pdb"))
    sub = t[list(frames)]
    sub[0].save_pdb(str(out / "start_structure.pdb"))
    sub.save_dcd(str(out / "trajectory.dcd"))
    (out / "frame_provenance.json").write_text(json.dumps(dict(
        walker=str(walker), config_template=str(tmpl),
        frame_indices=[int(f) for f in frames],
        n_frames_source=int(t.n_frames)), indent=2) + "\n")
    return out


def run_batch(batch: ShotBatch, seed_dir: Path, out_dir: Path, *, t_ais: int,
              n_obs: int, s_min: float, timeout_s: int = 7200,
              cv_definition: Optional[str] = None,
              omega_exclude_npy: Optional[Path] = None) -> dict:
    """Launch one forward AIS batch through the repository's own driver (§2 rule 7).

    k_ais equals the number of starts, so each start is used exactly once per batch and the pairing
    between a shot and its hot frame stays one-to-one.

    ``cv_definition`` and ``omega_exclude_npy`` are NOT optional for a macrocycle, only for a
    dipeptide. Without ``--cv-definition`` the writer falls back to ``mdtraj.compute_phi/psi``,
    which finds NOTHING on a cyclic sage/openff topology and silently stores all-NaN CV columns --
    the defect that made 183 000 rows of an earlier RGD cloud unusable and unreconstructable.
    Without ``--omega-exclude-npy`` the REST2 scaling hits the secondary-amide omegas that the REMD
    ladder leaves unscaled, which is a different ensemble and retired an entire earlier campaign.
    """
    cmd = [sys.executable, "-u", "-m",
           "escort_ais.experiments.alanine.run_alanine_ais_linear_scaling",
           "--solvent", "implicit", "--input-scaled-dir", str(seed_dir),
           "--k-ais", str(len(batch.frame_indices)), "--t-ais", str(int(t_ais)),
           "--freq-ais", "1", "--s-hot", str(S_HOT), "--s-cold", str(S_COLD),
           "--scaling-mode", "square", "--mode", "discovery",
           "--hz-n-observations", str(int(n_obs)), "--hz-s-min", str(float(s_min)),
           "--neq-integrator", "--leg", "forward", "--workers-per-gpu", "1",
           "--device-indices", str(batch.device), "--output-dir", str(out_dir),
           "--seed", str(int(batch.ais_seed))]
    if cv_definition:
        cmd += ["--cv-definition", str(cv_definition)]
    if omega_exclude_npy:
        cmd += ["--omega-exclude-npy", str(omega_exclude_npy)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s)
    return dict(returncode=r.returncode, stdout_tail=r.stdout[-2000:], stderr_tail=r.stderr[-2000:],
                command=" ".join(cmd))


def read_batch_works(out_dir: Path) -> "object":
    """Reduced works + landing CVs for one batch, as W = -final_logw (never final_W)."""
    import pandas as pd

    cand = list(out_dir.rglob("ais_trajectory_summary.csv")) + \
        list(out_dir.rglob("trajectory_summary.parquet"))
    if not cand:
        raise FileNotFoundError(f"no AIS summary under {out_dir}")
    p = cand[0]
    df = pd.read_csv(p) if p.suffix == ".csv" else pd.read_parquet(p)
    if "final_logw" not in df.columns:
        raise KeyError(f"{p} has no final_logw; columns={list(df.columns)}")
    df = df.copy()
    df["W_reduced"] = -df["final_logw"].to_numpy(float)
    return df


def batch_rows(batch: ShotBatch, df, *, git_commit: str, walker_hash: str) -> list[dict]:
    """One append-only record per shot, with provenance explicit rather than positional (§6)."""
    rows = []
    for i, (_, r) in enumerate(df.iterrows()):
        frame = int(batch.frame_indices[i]) if i < len(batch.frame_indices) else -1
        rows.append(dict(
            batch_id=batch.batch_id, system=batch.system,
            record_role=batch.record_role, accepted_for_production=False,
            exclusion_reason="forensic control (Section 7); never enters production",
            generation_label=batch.generation_label, block_id=batch.block_id,
            hot_frame_index=frame, exec_order_index=batch.exec_order_index,
            ais_seed=batch.ais_seed, device=batch.device,
            shot_index=i, W_reduced=float(r["W_reduced"]),
            final_logw=float(r["final_logw"]),
            git_commit=git_commit, walker_hash=walker_hash))
    return rows


def order_invariance(rows_a: Sequence[dict], rows_b: Sequence[dict]) -> dict:
    """Paired comparison of two batches that must be physically identical.

    Compares the WORK DISTRIBUTIONS, not shot-by-shot values: identical starts with different
    velocity seeds give different trajectories by construction, so equality per shot is not the
    invariant. Reports the free-energy difference as well, since that is the quantity the campaign
    ultimately gates on and a distributional wobble that leaves it unmoved is not a leak.
    """
    from scipy.special import logsumexp

    wa = np.asarray([r["W_reduced"] for r in rows_a], float)
    wb = np.asarray([r["W_reduced"] for r in rows_b], float)

    def jarzynski(w):
        return float(-(logsumexp(-w) - np.log(w.size)))

    def ess(w):
        lw = -w - np.max(-w)
        p = np.exp(lw)
        return float(p.sum() ** 2 / np.sum(p ** 2))

    da, db = jarzynski(wa), jarzynski(wb)
    # paired bootstrap over shots for the difference
    rng = np.random.default_rng(0)
    n = min(wa.size, wb.size)
    boots = []
    for _ in range(2000):
        ia = rng.integers(0, wa.size, wa.size)
        ib = rng.integers(0, wb.size, wb.size)
        boots.append(jarzynski(wa[ia]) - jarzynski(wb[ib]))
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return dict(n_a=int(wa.size), n_b=int(wb.size),
                mean_W_a=float(wa.mean()), mean_W_b=float(wb.mean()),
                std_W_a=float(wa.std()), std_W_b=float(wb.std()),
                ess_a=ess(wa), ess_b=ess(wb),
                dF_a=da, dF_b=db, dF_diff=da - db,
                dF_diff_ci95=[float(lo), float(hi)],
                consistent_at_95=bool(lo <= 0.0 <= hi),
                n_matched=int(n))
