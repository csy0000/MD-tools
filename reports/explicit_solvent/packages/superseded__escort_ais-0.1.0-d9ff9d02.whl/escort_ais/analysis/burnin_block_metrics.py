"""Section 9.3: work-aware per-block statistics, the input every cutoff policy is scored on.

One row per (system, seed set, block, cell) plus one per (system, seed set, block) global row. The
cutoff scan reads this table and never re-touches trajectories, so every policy in Section 8 is
compared on numerically identical raw records -- which is the point of computing it once.

THINGS THAT ARE EASY TO GET WRONG HERE, all of them silent:

* **Landing CVs must come from the HS cloud at s = 1, not from ``final_phi``/``final_psi``.** The
  chunked writer fills those with ``mdtraj.compute_phi/psi``, which finds NOTHING on a cyclic
  sage/openff macrocycle: for RGD they are 0/100 finite while the declared CV columns
  ``cv0_t0``... are 2000/2000 finite. Reading the legacy columns yields an all-NaN assignment that
  looks like "no landings in any cell" rather than an error.
* **``hz_observations`` stores DEGREES; ``PeriodicInterval``/``interior_mask`` work in RADIANS.**
  Mixing them produces a plausible assignment that sums to 1 with zero unassigned frames -- it has
  already cost one wrong pi_m (0.71/0.13/0.16 against a true 0.97/0.007/0.027).
* **``ell`` must be computed with log-sum-exp.** ``mean(exp(-W))`` at W ~ -46 kT (ALA) or ~ +175 kT
  (RGD) overflows or underflows to 0/inf and silently reports a cell as unsupported.
* **Two partition schemas.** ``nd_basin_tree`` writes ``cells`` and assigns with ``interior_mask``;
  the 2-D alanine ``barrier_partition`` writes ``basins`` and assigns with ``assign_basins``. They
  are not interchangeable.

Both `W_reduced` conventions are cross-checked against the frozen shot table rather than trusted:
the campaign's authoritative work is ``W = -final_logw`` (CLAUDE.md), and a mismatch aborts.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root

ROOT = project_root()


def _ess(logw: np.ndarray) -> float:
    """Kish ESS from LOG weights, normalised in log space (never exponentiate raw work)."""
    if logw.size == 0:
        return 0.0
    ln = logw - logsumexp(logw)
    return float(np.exp(-logsumexp(2.0 * ln)))


def landing_frame(batch_dir: Path, system: str):
    """(trajectory_id, W_reduced, angles_rad[n, n_cv]) for one batch, from the s=1 HS slice."""
    import pandas as pd

    hz = pd.read_parquet(batch_dir / "merged" / "hz_observations.parquet")
    ts = pd.read_parquet(batch_dir / "merged" / "trajectory_summary.parquet")
    last = hz[np.isclose(hz["s"].to_numpy(float), float(hz["s"].max()))]
    if len(last) != len(ts):
        raise SystemExit(f"{batch_dir}: {len(last)} landings at s=1 but {len(ts)} summary rows")

    if system == "cyclo_rgdfv":
        cols = sorted([c for c in last.columns if c.startswith("cv")],
                      key=lambda c: int(c.split("_")[0][2:]))
        if not cols:
            raise SystemExit(f"{batch_dir}: no declared cv* columns in the HS cloud")
    else:
        cols = ["phi", "psi"]
    ang_deg = last[cols].to_numpy(float)
    if not np.isfinite(ang_deg).all():
        raise SystemExit(f"{batch_dir}: {int((~np.isfinite(ang_deg)).sum())} non-finite landing "
                         f"CVs in {cols} -- refusing to assign cells to NaN")

    m = last.merge(ts[["trajectory_id", "final_logw"]], on="trajectory_id", how="left")
    W = -m["final_logw"].to_numpy(float)          # CLAUDE.md: W = -final_logw, reduced
    if not np.isfinite(W).all():
        raise SystemExit(f"{batch_dir}: non-finite reduced work")
    return m["trajectory_id"].to_numpy(int), W, np.radians(ang_deg)   # DEGREES -> RADIANS


def cell_labels(angles_rad: np.ndarray, partition: Path):
    """Assign each landing to a cell; returns (labels, cell_names). -1 means unassigned."""
    spec = json.loads(partition.read_text())
    if "cells" in spec:
        from escort_ais.methods.nd_basin_tree import cells_from_spec
        from escort_ais.methods.nd_flatbottom import interior_mask
        cells = cells_from_spec(spec)
        lab = np.full(len(angles_rad), -1, int)
        for i, c in enumerate(cells):
            lab[interior_mask(angles_rad, c) & (lab < 0)] = i
        return lab, [c.label for c in cells]
    from escort_ais.methods.barrier_partition import assign_basins, partition_from_dict
    basins = partition_from_dict(spec)
    lab = assign_basins(angles_rad[:, 0], angles_rad[:, 1], basins)
    return lab, [b.label for b in basins]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--campaign", type=Path,
                    default=ROOT / "campaigns/20260808T074306Z__forward-prep-burnin")
    a = ap.parse_args(argv)

    import pandas as pd

    lock = json.loads((a.campaign / "selection_lock.json").read_text())
    rows, glob_rows, land_rows = [], [], []

    for sysname, S in lock["systems"].items():
        stage = a.campaign / S["stage"]
        partition = ROOT / S["cold_cells"]["partition_file"]
        shots = pd.read_parquet(ROOT / S["diagnostic_ais"]["shots_parquet"])
        n_blocks = S["block_definition"]["n_blocks"]
        seedsets = sorted(shots["generation_label"].unique())

        for ss_i, ss in enumerate(seedsets):
            for b in range(n_blocks):
                bd = stage / f"b{b:02d}_s{ss_i}"
                if not bd.exists():
                    continue
                tid, W, ang = landing_frame(bd, sysname)
                lab, names = cell_labels(ang, partition)

                # cross-check the frozen shot table: same batch, same works, no silent reordering
                sh = shots[(shots["block_id"] == b) & (shots["generation_label"] == ss)]
                if len(sh) != len(W) or not np.allclose(
                        np.sort(sh["W_reduced"].to_numpy(float)), np.sort(W), atol=1e-6):
                    raise SystemExit(f"{bd}: works disagree with the frozen shot table -- the "
                                     f"landing join is not the batch the lock hashed")

                logw = -W                       # cold weight w = exp(-W), W reduced
                tot = logsumexp(logw)
                glob_rows.append(dict(
                    system=sysname, seed_set=ss, block_id=b, n_shots=len(W),
                    ess=_ess(logw), ess_frac=_ess(logw) / len(W),
                    log_total_weight=float(tot),
                    W_mean=float(W.mean()), W_median=float(np.median(W)),
                    W_iqr=float(np.subtract(*np.percentile(W, [75, 25]))),
                    # rare LOW works dominate exp(-W); the lower tail is the informative one
                    W_p01=float(np.percentile(W, 1)), W_p05=float(np.percentile(W, 5)),
                    W_p10=float(np.percentile(W, 10)),
                    n_unassigned=int((lab < 0).sum()),
                    top1_weight_share=float(np.exp(logw.max() - tot)),
                ))

                # Per-shot landing cache (Section 7): one row per shot with its block, seed set,
                # reduced work, assigned cell and landing CVs. Criterion 6 compares weighted
                # landing DISTRIBUTIONS between slabs, which per-block aggregates cannot express,
                # and every policy in Section 8 must read these identical rows.
                for i in range(len(W)):
                    r = dict(system=sysname, seed_set=ss, block_id=b,
                             trajectory_id=int(tid[i]), W_reduced=float(W[i]),
                             logw=float(logw[i]), cell_index=int(lab[i]),
                             cell=(names[lab[i]] if lab[i] >= 0 else None))
                    for d in range(ang.shape[1]):
                        r[f"cv{d}_rad"] = float(ang[i, d])
                    land_rows.append(r)

                for m, name in enumerate(names):
                    sel = lab == m
                    n_m = int(sel.sum())
                    # ell[b,m] = log mean(exp(-W) I(landing in m)), log-sum-exp, over ALL shots in
                    # the block: the landing probability is part of the estimand, so the normaliser
                    # is the whole bank, never the landing count.
                    ell = (logsumexp(logw[sel]) - np.log(len(W))) if n_m else -np.inf
                    rows.append(dict(
                        system=sysname, seed_set=ss, block_id=b, cell=name, cell_index=m,
                        n_landings=n_m, landing_frac=n_m / len(W),
                        ell=float(ell),
                        weight_share=float(np.exp(logsumexp(logw[sel]) - tot)) if n_m else 0.0,
                        ess_cell=_ess(logw[sel]) if n_m else 0.0,
                        W_median_cell=float(np.median(W[sel])) if n_m else np.nan,
                        W_p05_cell=float(np.percentile(W[sel], 5)) if n_m else np.nan,
                    ))

    if not rows:
        raise SystemExit("no batches read")
    cells_df, glob_df = pd.DataFrame(rows), pd.DataFrame(glob_rows)
    cells_df.to_parquet(a.campaign / "block_metrics.parquet", index=False)
    glob_df.to_parquet(a.campaign / "block_metrics_global.parquet", index=False)
    # written per system: the two systems have different CV counts, so one table would be ragged
    land_df = pd.DataFrame(land_rows)
    for sysname, g in land_df.groupby("system"):
        g.dropna(axis=1, how="all").to_parquet(
            a.campaign / f"landings_{sysname}.parquet", index=False)
        print(f"wrote landings_{sysname}.parquet ({len(g)} shots, "
              f"{sum(c.endswith('_rad') for c in g.dropna(axis=1, how='all').columns)} CVs)")

    print(f"wrote block_metrics.parquet ({len(cells_df)} rows) and "
          f"block_metrics_global.parquet ({len(glob_df)} rows)\n")
    for sysname in glob_df["system"].unique():
        g = glob_df[glob_df["system"] == sysname]
        c = cells_df[cells_df["system"] == sysname]
        print(f"=== {sysname} ===")
        print(f"  blocks {g['block_id'].nunique()} x seed sets {g['seed_set'].nunique()}, "
              f"{int(g['n_shots'].sum())} shots, unassigned landings {int(g['n_unassigned'].sum())}")
        print(f"  ESS/N per block: min {g['ess_frac'].min():.3f} max {g['ess_frac'].max():.3f}")
        print(f"  max single-shot weight share in a block: {g['top1_weight_share'].max():.3f}")
        piv = c.pivot_table(index="block_id", columns="cell", values="landing_frac",
                            aggfunc="mean")
        print("  mean landing fraction by block x cell:")
        print(piv.round(4).to_string().replace("\n", "\n    "))
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
