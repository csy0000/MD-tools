"""Is a REMD reference reliable? Four probes that are NOT "run more REMD".

Running the ladder longer tests one thing: statistical precision. It cannot tell you whether the
ladder is connected, whether a replica is stuck, whether the cold ensemble has stopped drifting, or
whether your error bars are calibrated -- and a broken ladder gets *more confidently wrong* with
more sampling, because the block bootstrap sees a smooth, self-consistent series either way. These
four probes each fail differently, and all four read data that is already on disk.

**1. LADDER CONNECTIVITY (exchange acceptance per neighbouring pair).** The ladder is a chain: its
throughput is the weakest link, not the mean. A single pair at 2% acceptance disconnects the cold
end from the hot end no matter how good the other six are. Reads ``exchange_attempts.csv``.

**2. ROUND TRIPS / TUNNELLING (the decisive one).** Replay the accepted swaps to get which rung each
replica occupies over time, then count end-to-end traversals. A *round trip* -- rung 0 to the top
rung and back -- is one delivery of a genuinely re-randomised configuration to the cold state. If
replicas do not traverse, the cold rung is a handful of short independent runs wearing a trench
coat, however long the wall time. This is the failure that most looks like success from inside.

**3. TIME-HALVES.** First half vs second half of the cold rung, reported as ``d ln pi``, i.e. in kT,
because that is the unit the result is quoted in. Probes drift, which mixing diagnostics cannot see:
a perfectly mixing ladder still drifts if it started far from equilibrium.

**4. PER-REPLICA SPREAD (K independent chains, for free).** Each replica is one CONTINUOUS
configuration trajectory that changes temperature; two replicas never share a configuration. So the
K replicas' own visits to the cold rung give K quasi-independent estimates of every cell population,
and their scatter is an EMPIRICAL error bar that assumes no ``tau`` and no block length. Comparing
it against the block bootstrap calibrates the error model -- exactly the check the project already
demands of the hot ensemble ("reference-free convergence needs K independent walkers"), applied to
the reference itself.

WHAT NONE OF THESE CAN DO. They cannot find a basin the ladder never visited at any rung. Coverage
is invisible from inside a single method; only an independent method or an external reference can
speak to it. Probe 4 comes closest -- a region reached by one replica and no other is a warning --
but absence everywhere stays undetectable.
"""
from __future__ import annotations

import numpy as np

#: acceptance below this on any neighbouring pair is a ladder bottleneck worth reporting
ACCEPTANCE_FLOOR = 0.10
#: fewer round trips than this per replica and the cold rung is not being refreshed
ROUND_TRIPS_MIN = 10


def rung_occupancy(exchange_csv, n_replicas: int):
    """Replay accepted swaps -> ``occ[round, replica] = rung``, plus the per-pair acceptance.

    ``exchange_attempts.csv`` records ``(step, phase, i, j, accepted)`` with ``i``/``j`` the RUNG
    indices proposed for exchange. Swapping rungs between the two replicas currently holding them is
    the same permutation as swapping their configurations, which is what the stored per-replica
    trajectories represent.
    """
    import pandas as pd
    df = pd.read_csv(exchange_csv)
    acc = df.groupby(["i", "j"]).accepted.agg(["mean", "size"]).sort_index()
    steps = np.sort(df.step.unique())
    arr = df[df.accepted == 1].sort_values("step")[["step", "i", "j"]].to_numpy()

    rung = np.arange(n_replicas)          # rung[replica]
    where = np.arange(n_replicas)         # where[rung] = replica
    occ = np.zeros((len(steps), n_replicas), dtype=np.int8)
    k = 0
    for t, s in enumerate(steps):
        while k < len(arr) and arr[k, 0] == s:
            i, j = int(arr[k, 1]), int(arr[k, 2])
            a, b = where[i], where[j]
            where[i], where[j] = b, a
            rung[a], rung[b] = j, i
            k += 1
        occ[t] = rung
    return occ, acc


def round_trips(occ):
    """End-to-end traversals and round trips per replica.

    A traversal is a change between "at the cold end" and "at the hot end" with nothing in between
    counted; two traversals make one round trip. Intermediate rungs are ignored on purpose -- a
    replica that oscillates in the middle without reaching either end delivers nothing.
    """
    n = occ.shape[1]
    out = []
    for r in range(n):
        x = occ[:, r]
        hit = x[(x == 0) | (x == n - 1)]
        flips = int((np.diff(hit) != 0).sum()) if len(hit) else 0
        out.append(dict(replica=r, traversals=flips, round_trips=flips // 2))
    return out


def cold_owner(occ, n_frames: int, stride: int):
    """Which replica held the cold rung at each stored cold frame."""
    idx = np.arange(0, occ.shape[0], stride)[:n_frames]
    return np.array([int(np.where(occ[t] == 0)[0][0]) for t in idx])


def per_replica_populations(labels, owner, n_cells: int):
    """K quasi-independent population estimates, one per replica chain."""
    m = min(len(labels), len(owner))
    labels, owner = np.asarray(labels)[:m], np.asarray(owner)[:m]
    n_rep = int(owner.max()) + 1
    cnt = np.array([[((owner == r) & (labels == k)).sum() for k in range(n_cells)]
                    for r in range(n_rep)], float)
    tot = cnt.sum(1)
    pi = np.divide(cnt, tot[:, None], out=np.full_like(cnt, np.nan), where=tot[:, None] > 0)
    return pi, tot


def time_halves(labels, n_cells: int):
    """First half vs second half of the cold rung, in populations and in kT."""
    labels = np.asarray(labels)
    h = len(labels) // 2
    p1 = np.array([(labels[:h] == m).mean() for m in range(n_cells)])
    p2 = np.array([(labels[h:] == m).mean() for m in range(n_cells)])
    with np.errstate(divide="ignore", invalid="ignore"):
        dln = np.log(p2 / p1)
    return p1, p2, dln, float(0.5 * np.abs(p1 - p2).sum())
