"""Per-generation convergence of wall-cBAR's three terms, converted to HARD-CELL free energies.

wall-cBAR natively estimates quantities between SOFT-WALLED states: BAR gives ``C_m(k_cold) -
H_m(k_hot)`` and MBAR gives ``H_m(k_hot) - H_n(k_hot)``. The reported science is about HARD cells,
so each term needs a Zwanzig correction from the walled ensemble to the indicator::

    f^X_m(hard) - f^X_m(wall) = -ln( pi^X_m / <e^-U_m>_X )

applied at the COLD end with ``k_cold`` and at the HOT end with ``k_hot``::

    (C_m - H_m)_hard = (C_m - H_m)_wall + corr_cold_m - corr_hot_m
    (H_m - H_n)_hard = (H_m - H_n)_wall + corr_hot_m  - corr_hot_n

THE HOT CORRECTION IS NOT SMALL AND THE COLD ONE IS. At the production stiffness the cold ensemble
essentially never enters the wall region, so ``corr_cold`` is ~1e-5 kT on alanine. The hot wall is
SOFT by design -- that is what buys the overlap -- so a large part of the walled hot ensemble sits
outside the hard cell and ``corr_hot`` reaches ~0.45 kT on the rare cell. Reporting the raw BAR and
MBAR numbers as if they were hard-cell quantities therefore misstates both per-cell terms.

THE HOT CORRECTIONS CANCEL IN THE TOTAL, and that is a useful check rather than a reason to skip
them: the total picks up only ``corr_cold_m - corr_cold_n``. So a bug in the hot correction shows up
in the components while leaving the headline number untouched -- exactly the kind of error that
survives review.

Once converted, the correct reference is the HARD-partition one, i.e. the ``stratified`` block of
``remd_component_reference`` -- not the ``wall`` block, which is stated between walled states.
"""
from __future__ import annotations

import argparse
import glob
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root

ROOT = project_root()


def zwanzig_corrections(reference: Path, partition: Path, k_hot: float, k_cold: float,
                        hot_rung: int = 5):
    """``(corr_cold, corr_hot)``: walled -> hard, per cell, from the REMD endpoint ensembles."""
    from escort_ais.analysis.cbar_term_decomposition import load_partition, reference_angles
    from escort_ais.analysis.remd_component_reference import _cells
    from escort_ais.methods.nd_flatbottom import nd_bias_kT

    labels, assign = load_partition(partition)
    nd = _cells(partition)
    z = np.load(reference)
    ang, origin = reference_angles(z), z["origin"]
    cold, hot = ang[origin == 0], ang[origin == hot_rung]
    lc, lh = assign(cold), assign(hot)

    cc, ch = [], []
    for m in range(len(nd)):
        lz_c = logsumexp(-nd_bias_kT(cold, nd[m], k_cold)) - np.log(len(cold))
        lz_h = logsumexp(-nd_bias_kT(hot, nd[m], k_hot)) - np.log(len(hot))
        cc.append(float(-(np.log((lc == m).mean()) - lz_c)))
        ch.append(float(-(np.log((lh == m).mean()) - lz_h)))
    return labels, np.array(cc), np.array(ch)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", type=Path,
                    default=ROOT / "data/alanine_dipeptide/wall_cbar_v8_protocol")
    ap.add_argument("--reference", type=Path,
                    default=ROOT / "reports/alanine/remd_ground_truth/cold_reference.npz")
    ap.add_argument("--partition", type=Path,
                    default=ROOT / "reports/alanine/conditional_bar/campaign_v8/basin_tree.json")
    ap.add_argument("--component-reference", type=Path,
                    default=ROOT / "reports/alanine/20260809_remd-component-reference/"
                                   "alanine_v8.json")
    ap.add_argument("--k-hot", type=float, required=True)
    ap.add_argument("--k-cold", type=float, default=100.0)
    ap.add_argument("--bootstrap", type=int, default=0,
                    help="NES-leg bootstrap replicates. Legs are resampled by SEED FRAME, "
                         "namespaced by generation (that index restarts each generation), because "
                         "legs sharing an originating configuration are not independent. The "
                         "MBAR hot term is held FIXED across replicates -- it is a property of the "
                         "window ensembles, not of the legs, so leg resampling cannot speak to it; "
                         "the interval is therefore on the NES terms and on the total THROUGH "
                         "them, and is a LOWER bound on the total uncertainty.")
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args(argv)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import pandas as pd
    from escort_ais.methods.endpoint_bar import solve_bar_with_infinite_works

    labels, cc, ch = zwanzig_corrections(a.reference, a.partition, a.k_hot, a.k_cold)
    print(f"Zwanzig walled -> hard corrections (kT):")
    for m, l in enumerate(labels):
        print(f"   {l}: cold (k={a.k_cold:g}) {cc[m]:+.5f}    hot (k={a.k_hot:.3f}) {ch[m]:+.5f}")

    ref = json.loads(a.component_reference.read_text())["stratified"]   # HARD partition reference
    rows = json.loads((a.run / "wall_legs.json").read_text())
    gens = sorted({r["generation"] for r in rows})
    fh = {r["generation"]: np.array(r["f_hot_mbar"], float) for r in rows}

    def legs(g, lab, kind):
        """(W, cluster) pooled over generations 1..g; cluster = (generation, seed frame)."""
        W, C = [], []
        for gg in range(1, g + 1):
            for f in glob.glob(f"{a.run}/g{gg:02d}_{lab}_{kind}/ais_trajectory_summary.csv"):
                df = pd.read_csv(f)
                W.append(-df["final_logw"].to_numpy(float))
                sid = (df["initial_frame_index"].to_numpy(int) if "initial_frame_index" in df
                       else np.arange(len(df)))
                C.append(gg * 1000000 + sid)
        return np.concatenate(W), np.concatenate(C)

    rng = np.random.default_rng(20260810)

    def draw(C):
        uc, inv = np.unique(C, return_inverse=True)
        by = [np.flatnonzero(inv == k) for k in range(len(uc))]
        return np.concatenate([by[k] for k in rng.integers(0, len(uc), size=len(uc))])

    matched, hot_t, total = {l: [] for l in labels}, [], []
    ci_m, ci_tot = {l: [] for l in labels}, []
    for g in gens:
        d, banks = {}, {}
        for m, lab in enumerate(labels):
            Wf, Cf = legs(g, lab, "fwd")
            Wr, Cr = legs(g, lab, "rev")
            banks[m] = (Wf, Cf, Wr, Cr)
            v = solve_bar_with_infinite_works(Wf, Wr, len(Wf), len(Wr))[0]
            d[m] = v + cc[m] - ch[m]                       # walled -> hard, both ends
            matched[lab].append(d[m])
        h = fh[g][1] + ch[1] - ch[0]                        # walled -> hard, hot side
        hot_t.append(h)
        total.append(d[1] - d[0] + h)

        if a.bootstrap:
            reps = {m: [] for m in range(len(labels))}
            tot_reps = []
            for _ in range(a.bootstrap):
                vals = {}
                for m in range(len(labels)):
                    Wf, Cf, Wr, Cr = banks[m]
                    fi, ri = draw(Cf), draw(Cr)
                    try:
                        b, ok = solve_bar_with_infinite_works(Wf[fi], Wr[ri], len(fi), len(ri))
                    except Exception:
                        ok = False
                    if not ok or not np.isfinite(b):
                        vals = None
                        break
                    vals[m] = b + cc[m] - ch[m]
                if vals is None:
                    continue
                for m in vals:
                    reps[m].append(vals[m])
                tot_reps.append(vals[1] - vals[0] + h)      # hot term FIXED, as documented
            for m, lab in enumerate(labels):
                r = np.array(reps[m], float)
                ci_m[lab].append([float(np.percentile(r, 5)), float(np.percentile(r, 95))]
                                 if len(r) >= max(20, a.bootstrap // 3) else [None, None])
            r = np.array(tot_reps, float)
            ci_tot.append([float(np.percentile(r, 5)), float(np.percentile(r, 95))]
                          if len(r) >= max(20, a.bootstrap // 3) else [None, None])

    fig, ax = plt.subplots(1, 3, figsize=(14.5, 4.3))
    panels = [(f"$f^C_{{{labels[0]}}}-f^H_{{{labels[0]}}}$", matched[labels[0]], ref["matched"][0]),
              (f"$f^C_{{{labels[1]}}}-f^H_{{{labels[1]}}}$", matched[labels[1]], ref["matched"][1]),
              (f"$f^H_{{{labels[1]}}}-f^H_{{{labels[0]}}}$", hot_t, ref["hot"][1])]
    for i, (title, series, rv) in enumerate(panels):
        if a.bootstrap and i < 2 and ci_m[labels[i]] and ci_m[labels[i]][0][0] is not None:
            lo = [c[0] for c in ci_m[labels[i]]]; hi = [c[1] for c in ci_m[labels[i]]]
            ax[i].fill_between(gens, lo, hi, color="#1f77b4", alpha=0.18, lw=0,
                               label="90% CI (leg bootstrap)")
        ax[i].plot(gens, series, "o-", color="#1f77b4", lw=1.8, ms=4, label="wall-cBAR")
        ax[i].axhline(rv, color="#111111", ls="--", lw=1.3, label="REMD (hard cells)")
        ax[i].set_title(title + f"\nREMD {rv:+.3f} kT", fontsize=10)
        ax[i].set_xlabel("generation"); ax[i].grid(alpha=0.3)
        if i == 0:
            ax[i].set_ylabel("free energy / $k_BT$"); ax[i].legend(fontsize=8)
    fig.suptitle("wall-cBAR per-term convergence, converted to HARD-CELL free energies "
                 "(Zwanzig applied at both ends)", fontsize=11)
    fig.tight_layout()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(a.out, dpi=170)

    # second figure: the total, which the hot corrections cancel out of
    f2, x2 = plt.subplots(figsize=(6.4, 4.3))
    if a.bootstrap and ci_tot and ci_tot[0][0] is not None:
        x2.fill_between(gens, [c[0] for c in ci_tot], [c[1] for c in ci_tot],
                        color="#2ca02c", alpha=0.18, lw=0, label="90% CI (leg bootstrap)")
    x2.plot(gens, total, "o-", color="#2ca02c", lw=1.8, ms=4, label="wall-cBAR (hard cells)")
    x2.axhline(ref["f_rel"][1], color="#111111", ls="--", lw=1.3, label="REMD (hard cells)")
    x2.set_xlabel("generation"); x2.set_ylabel("$f_{B1}-f_{B0}$ / $k_BT$")
    x2.set_title("total; the HOT corrections cancel here, only the cold ones survive", fontsize=10)
    x2.grid(alpha=0.3); x2.legend(fontsize=8); f2.tight_layout()
    f2.savefig(a.out.with_name(a.out.stem + "_total.png"), dpi=170)

    (a.out.with_suffix(".json")).write_text(json.dumps(dict(
        generations=gens, corr_cold=cc.tolist(), corr_hot=ch.tolist(),
        matched_hard={l: matched[l] for l in labels}, hot_hard=hot_t, total_hard=total,
        matched_ci={l: ci_m[l] for l in labels}, total_ci=ci_tot, n_boot=a.bootstrap,
        ci_note=("legs resampled by seed frame, namespaced by generation; the MBAR hot term is "
                 "held fixed, so this is a LOWER bound on the total uncertainty"),
        reference_hard=dict(matched=ref["matched"], hot=ref["hot"], f_rel=ref["f_rel"])),
        indent=2) + "\n")
    print(f"\n{'gen':>4}{'C0-H0':>10}{'err':>8}{'C1-H1':>10}{'err':>8}"
          f"{'H1-H0':>10}{'err':>8}{'total':>9}{'err':>8}")
    for i, g in enumerate(gens):
        print(f"{g:>4}{matched[labels[0]][i]:>10.3f}{matched[labels[0]][i]-ref['matched'][0]:>+8.3f}"
              f"{matched[labels[1]][i]:>10.3f}{matched[labels[1]][i]-ref['matched'][1]:>+8.3f}"
              f"{hot_t[i]:>10.3f}{hot_t[i]-ref['hot'][1]:>+8.3f}"
              f"{total[i]:>9.3f}{total[i]-ref['f_rel'][1]:>+8.3f}")
    print(f"\nwrote {a.out} and {a.out.with_name(a.out.stem + '_total.png')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
