"""hz_slice_study.py — how many HS slices, and how long a switch? (report §4, §5, §6)

Two questions, deliberately answered with different experimental designs.

**§4 — is L = 20 enough?**  Observations along one AIS trajectory are *correlated*, so more
slices do not buy proportionally more information.  The comparison is therefore run **paired**:
one discovery set at L = 40 is generated, and the smaller grids are obtained by taking every
2nd / 4th / 8th slice (L = 20 / 10 / 5) and the final landing alone (L = 1).  Because pausing the
NEQ integrator is exact to 0 ULP, a stride-2 subset of a 40-slice run *is* the 20-slice run for
the same seeds — so every difference between L values is attributable to the slices used and not
to trajectory noise.  Wall-clock overhead cannot be measured that way and is timed separately.

**§5 — how much of the remaining error is bias?**  Switch duration is swept at fixed
``Freq_AIS = 1`` (more switching intervals, same schedule *definition*), and the error against
the converged REMD reference is decomposed as ``MSE = bias² + variance`` using independent
trajectory batches: the variance is the across-batch variance of the per-batch estimates, and
the bias is the deviation of the batch-mean from the REMD reference.  A component that does not
shrink with more trajectories is bias, and more sampling will not remove it.

All uncertainty is **trajectory-level bootstrap** — whole trajectories are resampled, never
individual frames, because frames within a trajectory are not independent.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

from escort_ais.analysis.hz_reconstruction import (
    hz_histogram,
    hz_log_weights,
    weighted_ess,
)

PHI_BINS = np.linspace(-180.0, 180.0, 37)
ALPHA_L = ("phi>0", lambda phi, psi: np.asarray(phi) > 0)


# ─────────────────────────────── metrics ─────────────────────────────────────
def pmf_rmse(p: np.ndarray, ref: np.ndarray) -> float:
    """RMSE in kT of −ln p over bins populated in BOTH, after removing the free constant."""
    p, ref = np.asarray(p, float), np.asarray(ref, float)
    m = (p > 0) & (ref > 0)
    if m.sum() < 3:
        return float("nan")
    a, b = -np.log(p[m]), -np.log(ref[m])
    return float(np.sqrt(np.mean(((a - a.mean()) - (b - b.mean())) ** 2)))


def population_mae(p: np.ndarray, ref: np.ndarray) -> float:
    """Mean absolute error of the binned populations (not of the log-densities)."""
    return float(np.mean(np.abs(np.asarray(p, float) - np.asarray(ref, float))))


def support_coverage(p: np.ndarray, ref: np.ndarray, floor: float = 1e-4) -> float:
    """Fraction of the reference's probability mass that the estimate actually reaches."""
    p, ref = np.asarray(p, float), np.asarray(ref, float)
    return float(ref[(p > floor * p.max()) & (ref > 0)].sum() / max(ref.sum(), 1e-300))


def trajectory_bootstrap(traj_ids, per_row_fn, n_boot: int = 200, seed: int = 0):
    """Resample whole TRAJECTORIES (never frames) and re-evaluate ``per_row_fn(mask)``.

    ``per_row_fn`` receives a boolean/int index array selecting rows and returns a scalar or a
    1-D array.  Returns (mean, std) over bootstrap replicates.
    """
    traj_ids = np.asarray(traj_ids)
    uniq = np.unique(traj_ids)
    rng = np.random.default_rng(seed)
    idx_by_traj = {t: np.flatnonzero(traj_ids == t) for t in uniq}
    out = []
    for _ in range(int(n_boot)):
        pick = rng.choice(uniq, size=uniq.size, replace=True)
        rows = np.concatenate([idx_by_traj[t] for t in pick])
        try:
            out.append(per_row_fn(rows))
        except Exception:
            continue
    if not out:
        return float("nan"), float("nan")
    arr = np.asarray(out, float)
    return arr.mean(axis=0), arr.std(axis=0, ddof=1)


# ───────────────────── slice-subset reconstruction (§4) ──────────────────────
def subset_slice_ids(all_ids: Sequence[int], n_keep: int) -> list[int]:
    """``n_keep`` slice ids evenly spaced in the recorded (already √s-even) grid.

    ``n_keep = 1`` means the final landing only — the endpoint-Jarzynski special case.
    """
    ids = sorted(int(i) for i in all_ids)
    if n_keep <= 1:
        return [ids[-1]]
    if n_keep >= len(ids):
        return ids
    stride = len(ids) / float(n_keep)
    sel = sorted({ids[min(len(ids) - 1, int(round(j * stride)))] for j in range(n_keep)})
    if ids[-1] not in sel:                       # the cold landing is always informative
        sel[-1] = ids[-1]
    return sel


def reconstruct_from_slices(hz, slice_ids: Sequence[int], bins=PHI_BINS,
                            column: str = "phi") -> dict:
    """Per-slice-normalised HS reconstruction restricted to ``slice_ids``."""
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    sub = hz[hz[slice_col].isin(list(slice_ids))]
    per_slice, ess = [], {}
    for sid, g in sub.groupby(slice_col):
        lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                            g["u_cold_reduced"])
        per_slice.append(hz_histogram(g[column], lw, bins))
        ess[int(sid)] = weighted_ess(lw)
    if not per_slice:
        return dict(density=np.zeros(len(bins) - 1), total_ess=0.0, per_slice_ess={})
    p = np.vstack(per_slice).mean(axis=0)
    tot = p.sum()
    return dict(density=(p / tot if tot > 0 else p), total_ess=float(sum(ess.values())),
                per_slice_ess=ess, n_slices=len(per_slice))


def basin_population(hz, slice_ids, phi_gt_zero: bool = True) -> float:
    """Work-weighted P(φ>0) reconstructed from the chosen slices (the rare α_L basin)."""
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    sub = hz[hz[slice_col].isin(list(slice_ids))]
    vals = []
    for _, g in sub.groupby(slice_col):
        lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                            g["u_cold_reduced"])
        lw = lw - lw.max()
        w = np.exp(lw)
        sel = (g["phi"].to_numpy() > 0) if phi_gt_zero else (g["phi"].to_numpy() <= 0)
        vals.append(float(w[sel].sum() / max(w.sum(), 1e-300)))
    return float(np.mean(vals)) if vals else float("nan")


def clustering_stability(hz, slice_ids, model: str = "product_vm", n_components: int = 5,
                         n_repeats: int = 3, seed: int = 1000) -> dict:
    """How stable is the vM mixture fitted on the HS-weighted cloud, for this slice subset?

    Stability is measured by refitting with different EM seeds and comparing the recovered
    component centres (mean torus chord distance after greedy matching) and the mixture weights.
    A slice grid that is too sparse shows up as unstable centres.
    """
    from escort_ais.methods.torus_mixture import (_match_centres, chord_distance,
                                                  fit_torus_mixture)

    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    sub = hz[hz[slice_col].isin(list(slice_ids))]
    lw = hz_log_weights(sub["cumulative_reduced_work"], sub["u_current_reduced"],
                        sub["u_cold_reduced"])
    lw = np.asarray(lw) - np.max(lw)
    w = np.exp(lw)
    phi = np.radians(sub["phi"].to_numpy())
    psi = np.radians(sub["psi"].to_numpy())
    traj = sub[("trajectory_id" if "trajectory_id" in sub.columns else "trajectory_index")].to_numpy()

    fits = []
    for r in range(n_repeats):
        try:
            fits.append(fit_torus_mixture(phi, psi, weights=w, n_components=n_components,
                                          model=model, n_init=4, group=traj, seed=seed + 977 * r))
        except Exception as exc:
            return dict(model=model, ok=False, error=f"{type(exc).__name__}: {exc}")
    centres = [np.asarray(f.mu, float) for f in fits]          # (K, 2) [mu_phi, mu_psi] rad
    dists = []
    for a in range(1, len(centres)):
        j = _match_centres(centres[0], centres[a])
        dists.append(float(np.mean(chord_distance(centres[a][j], centres[0]))))
    weights = np.vstack([np.sort(f.weights)[::-1] for f in fits])
    return dict(model=model, ok=True, n_components=n_components,
                mean_centre_shift=float(np.mean(dists)) if dists else 0.0,
                max_centre_shift=float(np.max(dists)) if dists else 0.0,
                weight_spread=float(np.max(weights.std(axis=0))),
                log_likelihood=float(np.mean([f.log_likelihood for f in fits])),
                n_eff=float(np.mean([f.n_eff for f in fits])))


# ────────────────────────────── §4 driver ────────────────────────────────────
def slice_count_study(hz, ref_density: Optional[np.ndarray], L_values=(1, 5, 10, 20, 40),
                      bins=PHI_BINS, n_boot: int = 200, do_clustering: bool = True) -> dict:
    """Paired L-sweep on one recorded discovery set (see the module docstring)."""
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    traj_col = "trajectory_id" if "trajectory_id" in hz.columns else "trajectory_index"
    all_ids = sorted(int(i) for i in hz[slice_col].unique())

    rows = {}
    for L in L_values:
        ids = subset_slice_ids(all_ids, L)
        rec = reconstruct_from_slices(hz, ids, bins)
        sub = hz[hz[slice_col].isin(ids)]

        def _rmse_from_rows(row_idx, _ids=ids, _sub=sub):
            g = _sub.iloc[row_idx]
            lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                                g["u_cold_reduced"])
            return pmf_rmse(hz_histogram(g["phi"], lw, bins), ref_density)

        boot_mean, boot_std = ((float("nan"), float("nan")) if ref_density is None else
                               trajectory_bootstrap(sub[traj_col].to_numpy(), _rmse_from_rows,
                                                    n_boot=n_boot))
        row = dict(
            L=int(L), n_slices_used=len(ids), slice_ids=ids,
            pmf_rmse_kT=(pmf_rmse(rec["density"], ref_density) if ref_density is not None
                         else float("nan")),
            pmf_rmse_boot_mean=float(boot_mean) if np.isfinite(boot_mean) else float("nan"),
            pmf_rmse_boot_std=float(boot_std) if np.isfinite(boot_std) else float("nan"),
            population_mae=(population_mae(rec["density"], ref_density)
                            if ref_density is not None else float("nan")),
            support_coverage=(support_coverage(rec["density"], ref_density)
                              if ref_density is not None else float("nan")),
            weighted_ess_total=rec["total_ess"],
            weighted_ess_per_slice_mean=(float(np.mean(list(rec["per_slice_ess"].values())))
                                         if rec["per_slice_ess"] else float("nan")),
            basin_population_phi_gt_0=basin_population(hz, ids),
            n_rows=int(len(sub)),
            bytes_parquet_estimate=int(len(sub) * 15 * 8),   # 15 numeric columns, float64
            density=rec["density"].tolist(),
        )
        if do_clustering:
            row["clustering_product_vm"] = clustering_stability(hz, ids, "product_vm")
            row["clustering_sine_vm"] = clustering_stability(hz, ids, "sine_vm")
        rows[str(L)] = row
    return dict(name="slice_count_study", L_values=list(L_values), rows=rows,
                bins=bins.tolist(), design="paired subsets of one L=40 discovery set")


def plateau_decision(study: dict, tol_frac: float = 0.10) -> dict:
    """Is L=20 at the accuracy plateau? (adopt 20 only if it is — report §4)"""
    rows = study["rows"]
    have = {int(k): v["pmf_rmse_kT"] for k, v in rows.items() if np.isfinite(v["pmf_rmse_kT"])}
    if not have or 20 not in have:
        return dict(decision="undetermined", reason="no finite RMSE at L=20")
    best = min(have.values())
    r20 = have[20]
    at_plateau = (r20 - best) <= tol_frac * max(abs(best), 1e-12)
    larger = {L: r for L, r in have.items() if L > 20}
    improves = {L: (r20 - r) / max(r20, 1e-12) for L, r in larger.items()}
    return dict(decision=("adopt L=20" if at_plateau else "L=20 is NOT at the plateau"),
                rmse_by_L=have, best_rmse=best, rmse_at_20=r20,
                relative_excess_at_20=float((r20 - best) / max(abs(best), 1e-12)),
                relative_improvement_beyond_20=improves, tolerance=tol_frac)


# ────────────────────────────── §5 driver ────────────────────────────────────
def bias_variance_decomposition(batch_estimates: Sequence[float], reference: float) -> dict:
    """MSE = bias² + variance from INDEPENDENT trajectory batches.

    ``variance`` is the across-batch variance of the per-batch estimates (what more trajectories
    reduces); ``bias`` is the deviation of the batch mean from the converged reference (what more
    trajectories does NOT reduce).
    """
    e = np.asarray([x for x in batch_estimates if np.isfinite(x)], float)
    if e.size < 2:
        return dict(n_batches=int(e.size), bias=float("nan"), variance=float("nan"),
                    mse=float("nan"))
    mean = float(e.mean())
    var = float(e.var(ddof=1))
    bias = float(mean - reference)
    return dict(n_batches=int(e.size), batch_mean=mean, reference=float(reference),
                bias=bias, bias_squared=bias ** 2, variance=var, mse=bias ** 2 + var,
                bias_fraction_of_mse=float(bias ** 2 / (bias ** 2 + var))
                if (bias ** 2 + var) > 0 else float("nan"),
                per_batch=e.tolist())
