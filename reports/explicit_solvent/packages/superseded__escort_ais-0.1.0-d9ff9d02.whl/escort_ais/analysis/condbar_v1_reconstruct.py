"""Reconstruct the campaign_v1 forward banks and reverse seed clusters from saved data.

No simulation is rerun. Everything here re-reads stored AIS output:
  * forward legs   -> data/.../condbar_campaign/gen_forward/nf{NF}_seed{S}/shard*/
  * reverse banks  -> data/.../condbar_campaign/reverse_banks/B{m}/bank.npz

The campaign shuffled each bank in place with ``np.random.default_rng(1234 + m).shuffle(W)`` and
then consumed contiguous slices via per-arm cursors. ``W`` was shuffled but ``seed_frames`` was
not, so the work -> seed mapping has to be recovered by replaying the SAME permutation on an index
array: ``Generator.shuffle`` is Fisher-Yates driven purely by the stream and length, so shuffling
``arange(n)`` with the same seed yields the permutation actually applied. :func:`verify` checks
that byte-for-byte against the works saved by the campaign, and against the recorded allocations.

Why this matters: multiple reverse legs share an originating REMD frame, so trajectory-level
standard errors overstate the independent information. B1's bank draws 1100 legs from 173 unique
frames.
"""
from __future__ import annotations

import glob
import json
from pathlib import Path

import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root

ROOT = project_root()
CAMPAIGN = ROOT / "reports/legacy/alanine/20260729_campaign_v1"
DATA = ROOT / "data/alanine_dipeptide/condbar_campaign"
BANKS = DATA / "reverse_banks"
GEN_FWD = DATA / "gen_forward"
SHUFFLE_SEED_BASE = 1234
GEN_SEED = lambda g: 90000 + 137 * g          # noqa: E731  (mirrors run_condbar_campaign)
N_BOXES = 3


# ── forward ──────────────────────────────────────────────────────────────────────────────────
def forward_generation(n_forward: int, gen: int):
    """Reduced work and landing torsions for one generation, in the campaign's own order.

    ``_ais_leg`` sharded across devices and concatenated the per-shard results in shard index
    order, so re-reading shard0, shard1, ... reproduces the original ordering exactly.
    """
    import mdtraj as md

    d = GEN_FWD / f"nf{n_forward}_seed{GEN_SEED(gen)}"
    shards = sorted(glob.glob(str(d / "shard*")))
    dirs = shards if shards else [str(d)]
    W, phi, psi = [], [], []
    for sd in dirs:
        sd = Path(sd)
        W.append(-pd.read_csv(sd / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float))
        seed_pdb = _seed_pdb_for(sd)
        t = md.load_dcd(str(sd / "ais_final_coordinates.dcd"), top=str(seed_pdb))
        phi.append(md.compute_phi(t)[1][:, 0])
        psi.append(md.compute_psi(t)[1][:, 0])
    return np.concatenate(W), np.concatenate(phi), np.concatenate(psi)


def _seed_pdb_for(shard_dir: Path) -> Path:
    """The hot seed topology the leg was run against."""
    cand = ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns/start_structure.pdb"
    if cand.exists():
        return cand
    raise FileNotFoundError("hot seed start_structure.pdb not found")


# ── reverse: permutation recovery and cluster labels ─────────────────────────────────────────
def bank_permutation(n: int, box: int) -> np.ndarray:
    """The permutation ``np.random.default_rng(1234+m).shuffle`` applied to a length-n array."""
    idx = np.arange(n)
    np.random.default_rng(SHUFFLE_SEED_BASE + box).shuffle(idx)
    return idx


def shuffled_bank(box: int):
    """(work, seed_frame) in the campaign's consumption order."""
    z = np.load(BANKS / f"B{box}" / "bank.npz")
    W0, S0 = np.asarray(z["W"], float), np.asarray(z["seed_frames"], int)
    perm = bank_permutation(len(W0), box)
    # Cross-check the permutation against an actual in-place shuffle of a copy.
    chk = W0.copy()
    np.random.default_rng(SHUFFLE_SEED_BASE + box).shuffle(chk)
    if not np.array_equal(chk, W0[perm]):
        raise RuntimeError(f"B{box}: index-array shuffle does not reproduce the in-place shuffle; "
                           f"the seed->work mapping cannot be trusted")
    return W0[perm], S0[perm]


def allocations(results_path: Path) -> dict:
    """Per-generation reverse allocation actually used, read back from the results JSON."""
    r = json.loads(Path(results_path).read_text())
    out = {}
    for row in r["generations"][1:]:
        g = int(row["generation"])
        out[g] = {arm: list(map(int, row["arms"][arm]["n_reverse"]))
                  for arm in ("equal", "ratio") if arm in row.get("arms", {})}
    return out


def replay(results_path: Path):
    """Replay the cursors and return, per (arm, generation, box), the works and seed frames."""
    alloc = allocations(results_path)
    banks = {m: shuffled_bank(m) for m in range(N_BOXES)}
    cursor = {arm: np.zeros(N_BOXES, int) for arm in ("equal", "ratio")}
    out = {}
    for g in sorted(alloc):
        for arm in ("equal", "ratio"):
            if arm not in alloc[g]:
                continue
            for m in range(N_BOXES):
                take = alloc[g][arm][m]
                c0 = cursor[arm][m]
                W, S = banks[m]
                out[(arm, g, m)] = (W[c0:c0 + take].copy(), S[c0:c0 + take].copy())
                cursor[arm][m] = c0 + take
    return out, {arm: cursor[arm].tolist() for arm in cursor}


# ── verification ─────────────────────────────────────────────────────────────────────────────
def verify(tag: str = "200") -> dict:
    """Check the reconstruction reproduces the campaign's saved arrays exactly."""
    res = CAMPAIGN / f"campaign_results_nf{tag}.json"
    works_npz = CAMPAIGN / f"campaign_results_nf{tag}.works.npz"
    rep, cursors = replay(res)
    report = dict(tag=tag, reverse_checked=0, reverse_exact=0, forward_checked=0,
                  forward_exact=0, max_forward_absdiff=0.0, notes=[])

    if works_npz.exists():
        z = np.load(works_npz)
        for (arm, g, m), (W, _S) in rep.items():
            key = f"reverse_g{g}_{arm}_b{m}__work"
            if key not in z.files:
                continue
            report["reverse_checked"] += 1
            if np.array_equal(z[key], W):
                report["reverse_exact"] += 1
            else:
                report["notes"].append(f"MISMATCH {key}")
        for g in range(1, 11):
            key = f"forward_g{g}_-_b-1__work"
            if key not in z.files:
                continue
            Wf, _, _ = forward_generation(int(tag), g)
            report["forward_checked"] += 1
            d = float(np.max(np.abs(np.sort(z[key]) - np.sort(Wf)))) if len(Wf) == len(z[key]) \
                else float("inf")
            report["max_forward_absdiff"] = max(report["max_forward_absdiff"], d)
            if d < 1e-9:
                report["forward_exact"] += 1
    else:
        report["notes"].append(f"{works_npz.name} absent; reverse works not byte-checkable for "
                               f"this budget (forward legs are still reconstructable from disk)")
    report["cursors"] = cursors
    return report


def cluster_summary() -> dict:
    out = {}
    for m in range(N_BOXES):
        z = np.load(BANKS / f"B{m}" / "bank.npz")
        S = np.asarray(z["seed_frames"], int)
        _, counts = np.unique(S, return_counts=True)
        out[f"B{m}"] = dict(n_legs=int(len(S)), n_unique_seeds=int(len(counts)),
                            reuse_factor=float(len(S) / len(counts)),
                            seed_ess=float(z["ess_seed"]),
                            max_legs_per_seed=int(counts.max()))
    return out


if __name__ == "__main__":
    print(json.dumps(dict(clusters=cluster_summary(),
                          verify_nf200=verify("200"),
                          verify_nf800=verify("800")), indent=2))
