from __future__ import annotations

from typing import Iterable, Tuple

import numpy as np
from openmm.app import Topology


def dihedral_deg(coords: np.ndarray, atom_indices: Iterable[int]) -> float:
    """Compute a dihedral angle in degrees from Cartesian coordinates in any distance unit."""
    i, j, k, l = tuple(atom_indices)
    p0 = coords[i]
    p1 = coords[j]
    p2 = coords[k]
    p3 = coords[l]

    b0 = p0 - p1
    b1 = p2 - p1
    b2 = p3 - p2

    b1_norm = np.linalg.norm(b1)
    if b1_norm == 0.0:
        return float("nan")
    b1_hat = b1 / b1_norm

    v = b0 - np.dot(b0, b1_hat) * b1_hat
    w = b2 - np.dot(b2, b1_hat) * b1_hat

    x = np.dot(v, w)
    y = np.dot(np.cross(b1_hat, v), w)
    return float(np.degrees(np.arctan2(y, x)))


def find_phi_psi_indices(topology: Topology) -> Tuple[Tuple[int, int, int, int], Tuple[int, int, int, int]]:
    """Return atom indices for phi and psi in ACE-ALA-NME.

    phi = C(ACE)-N(ALA)-CA(ALA)-C(ALA)
    psi = N(ALA)-CA(ALA)-C(ALA)-N(NME)
    """

    atom_lookup = {}
    for atom in topology.atoms():
        key = (atom.residue.name.strip(), atom.name.strip())
        atom_lookup[key] = atom.index

    try:
        phi = (
            atom_lookup[("ACE", "C")],
            atom_lookup[("ALA", "N")],
            atom_lookup[("ALA", "CA")],
            atom_lookup[("ALA", "C")],
        )
        psi = (
            atom_lookup[("ALA", "N")],
            atom_lookup[("ALA", "CA")],
            atom_lookup[("ALA", "C")],
            atom_lookup[("NME", "N")],
        )
    except KeyError as exc:
        raise KeyError(
            "Failed to identify ACE/ALA/NME phi/psi atoms in topology. "
            "Check residue and atom naming in generated AMBER topology."
        ) from exc

    return phi, psi


def find_omega_indices(
    topology,
) -> tuple[tuple[int, int, int, int], tuple[int, int, int, int]]:
    """Return atom indices for the two ω peptide dihedrals in ACE-ALA-NME.

    omega_1 (ACE→ALA): CH3(ACE)-C(ACE)-N(ALA)-CA(ALA)
    omega_2 (ALA→NME): CA(ALA)-C(ALA)-N(NME)-C(NME)
    """
    atom_lookup: dict[tuple[str, str], int] = {}
    for atom in topology.atoms():
        key = (atom.residue.name.strip(), atom.name.strip())
        atom_lookup[key] = atom.index

    try:
        omega_1 = (
            atom_lookup[("ACE", "CH3")],
            atom_lookup[("ACE", "C")],
            atom_lookup[("ALA", "N")],
            atom_lookup[("ALA", "CA")],
        )
        omega_2 = (
            atom_lookup[("ALA", "CA")],
            atom_lookup[("ALA", "C")],
            atom_lookup[("NME", "N")],
            atom_lookup[("NME", "C")],
        )
    except KeyError as exc:
        raise KeyError(
            "Failed to identify ACE/ALA/NME omega atoms in topology. "
            "Check residue and atom naming in generated AMBER topology."
        ) from exc

    return omega_1, omega_2


def force_statistics(forces: np.ndarray) -> tuple[float, float]:
    """Return global norm and max per-atom norm for a force array shaped (N, 3)."""
    if forces.size == 0:
        return 0.0, 0.0
    per_atom = np.linalg.norm(forces, axis=1)
    return float(np.linalg.norm(forces)), float(np.max(per_atom))
