"""All-replica MBAR cold reference on arbitrary declared CVs.

The single-replica cold reference uses only the ``s=1`` slot and throws away ``(K-1)/K`` of the
REST2-REMD sampling.  Here every frame from every replica slot enters one MBAR solve over the K
REST2 states, and the per-frame weights at ``s=1`` define the cold probability ``p(x)``.  The rare
substates gain the most: they are visited far more often at ``s<1``, so pooling raises their
effective sample size without touching the estimand.

The reduced potential is ``u_l(x) = U_{s_l}(x) / (k_B T_base)`` with a single ``T_base`` thermostat
for every replica -- REST2 scales the *Hamiltonian*, not the temperature.

This is the N-CV generalisation of ``experiments.alanine.run_condbar_cold_reference``, which is
hard-wired to alanine's ``(phi, psi)`` and to ``mdtraj.compute_phi/psi``.  Those functions find
nothing on a cyclic sage/openff topology, so a macrocycle must read its CVs from the declared
quartets in ``systems/<slug>/cv_definition.json``.

CRITICAL: the base system must be built through ``systems.openmm_system.build_implicit_system``,
the same ``gb_radii='mbondi3'`` parmed branch as the AIS legs.  ``AmberPrmtopFile.createSystem``
differs by ~16.6 kJ/mol at bit-identical radii, which would put ``p(x)`` on a different Hamiltonian
than the works it is compared against.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Sequence

import numpy as np

KB_KJ = 0.0083144621

__all__ = ["load_all_replicas", "reduced_potentials", "mbar_cold_weights", "weighted_pmf_1d",
           "weighted_pmf_2d", "arc_segments", "arc_midpoint"]


def arc_segments(arc, active: bool = True):
    """Degree spans covering a periodic arc, split at +-180 when it wraps.

    A cell whose arc runs from +124 to -11 deg covers 225 deg THROUGH the branch cut, not the
    -135 deg a naive ``hi - lo`` gives. Drawing it as one rectangle produces a negative width,
    which matplotlib renders as nothing -- so a wrapping cell silently vanishes from the plot.
    """
    if not active:
        return [(-180.0, 180.0)]
    lo, hi = np.degrees(arc.lo), np.degrees(arc.hi)
    return [(lo, hi)] if lo <= hi else [(lo, 180.0), (-180.0, hi)]


def arc_midpoint(arc, active: bool = True) -> float:
    """Circular midpoint of an arc in degrees, wrapped back into [-180, 180)."""
    if not active:
        return 0.0
    lo, hi = np.degrees(arc.lo), np.degrees(arc.hi)
    width = (hi - lo) % 360.0
    return ((lo + 0.5 * width + 180.0) % 360.0) - 180.0


def load_all_replicas(remd_dir: Path, cv, burn_in: int = 0, stride: int = 1,
                      top_name: str = "start_structure_minimized.pdb", verbose: bool = True):
    """Pooled coordinates, CVs (RADIANS) and per-frame origin replica over every REMD slot.

    ``cv`` is a loaded ``CVDefinition``; its ``quartets`` drive ``mdtraj.compute_dihedrals``, so
    the CVs are the declared ones rather than whatever mdtraj can guess from the topology.
    """
    import mdtraj as md

    remd_dir = Path(remd_dir)
    top = remd_dir / top_name
    xyz, angles, origin = [], [], []
    slots = sorted(p for p in remd_dir.glob("replica_*") if p.is_dir())
    if not slots:
        raise FileNotFoundError(f"no replica_* directories under {remd_dir}")
    for k, slot in enumerate(slots):
        t = md.load_dcd(str(slot / "trajectory.dcd"), top=str(top))[burn_in:][::stride]
        xyz.append(t.xyz)
        angles.append(md.compute_dihedrals(t, np.asarray(cv.quartets, int)))
        origin.append(np.full(t.n_frames, k, int))
        if verbose:
            print(f"[cold-ref] {slot.name}: {t.n_frames} frames", flush=True)
    ang = np.concatenate(angles)
    if not np.isfinite(ang).all():
        raise ValueError(f"{int((~np.isfinite(ang)).sum())} non-finite CV values -- the declared "
                         "quartets do not match this topology")
    return np.concatenate(xyz), ang, np.concatenate(origin), len(slots)


def reduced_potentials(xyz: np.ndarray, scale_factors: Sequence[float], prmtop_path,
                       inpcrd_path=None, n_solute: Optional[int] = None,
                       exclude_central_bonds=None, temperature_k: float = 300.0,
                       platform_name: str = "CUDA", device_index: Optional[str] = None,
                       verbose: bool = True) -> np.ndarray:
    """``u_kn[l, n] = U_{s_l}(x_n) / kT`` -- one Context per REST2 state, reused across frames.

    ``exclude_central_bonds`` must carry the SAME omega-selective exclusion list the REMD ladder
    used, or the reference lives on a different Hamiltonian than the ensemble it describes.
    """
    from openmm import Context, LangevinMiddleIntegrator, Platform, unit

    from escort_ais.systems.openmm_system import build_implicit_system, build_rest2_scaled_system

    kt_kj = KB_KJ * float(temperature_k)
    base = build_implicit_system(prmtop_path, inpcrd_path=inpcrd_path)
    n_solute = int(n_solute if n_solute is not None else base.getNumParticles())
    solute = np.arange(n_solute)
    platform = Platform.getPlatformByName(platform_name)
    props = {"Precision": "mixed"} if platform_name in ("CUDA", "OpenCL") else {}
    if device_index is not None and platform_name in ("CUDA", "OpenCL"):
        props["DeviceIndex"] = str(device_index)

    u_kn = np.empty((len(scale_factors), len(xyz)), float)
    for l, s in enumerate(scale_factors):
        system = build_rest2_scaled_system(base, solute, float(s),
                                           exclude_central_bonds=exclude_central_bonds)
        integ = LangevinMiddleIntegrator(temperature_k, 1.0, 0.002)
        ctx = Context(system, integ, platform, props) if props else Context(system, integ, platform)
        for n in range(len(xyz)):
            ctx.setPositions(xyz[n])
            u_kn[l, n] = (ctx.getState(getEnergy=True).getPotentialEnergy()
                          .value_in_unit(unit.kilojoule_per_mole) / kt_kj)
        if verbose:
            print(f"[cold-ref] state s={s:.4f}: <u> = {u_kn[l].mean():+.3f} kT", flush=True)
        del ctx, integ
    return u_kn


def mbar_cold_weights(u_kn: np.ndarray, origin: np.ndarray, n_slots: int, cold_state: int = 0):
    """Normalised per-frame weights in the cold state, its Kish ESS, and the MBAR free energies."""
    from pymbar import MBAR

    n_k = np.array([(origin == k).sum() for k in range(n_slots)], int)
    mbar = MBAR(u_kn, n_k, solver_protocol="robust")
    w = np.asarray(mbar.weights()[:, cold_state], float)
    w = w / w.sum()
    return w, float(1.0 / np.sum(w ** 2)), mbar.compute_free_energy_differences()["Delta_f"], n_k


def weighted_pmf_1d(theta: np.ndarray, w: np.ndarray, nbin: int = 72, kt: float = 1.0):
    """Periodic 1-D PMF in kT from weighted samples: ``F = -kT ln p``, zeroed at its minimum.

    ``theta`` in RADIANS.  Empty bins come back as ``inf`` rather than being silently dropped, so
    a caller plotting the curve sees the gap instead of a spurious interpolation across it.
    """
    edges = np.linspace(-np.pi, np.pi, int(nbin) + 1)
    p, _ = np.histogram(np.asarray(theta, float), bins=edges, weights=np.asarray(w, float))
    p = p / p.sum()
    with np.errstate(divide="ignore"):
        f = -kt * np.log(p)
    f -= np.nanmin(f[np.isfinite(f)])
    centres = 0.5 * (edges[:-1] + edges[1:])
    return centres, f, p


def weighted_pmf_2d(x, y, w, nbin: int = 64, kt: float = 1.0):
    """Periodic 2-D PMF in kT, zeroed at its minimum; empty bins are NaN, not zero.

    Returns ``(F, edges_deg)`` with ``F`` indexed ``[x_bin, y_bin]``.
    """
    edges = np.linspace(-np.pi, np.pi, int(nbin) + 1)
    h, _, _ = np.histogram2d(np.asarray(x, float), np.asarray(y, float),
                             bins=[edges, edges], weights=np.asarray(w, float))
    p = h / h.sum()
    with np.errstate(divide="ignore"):
        f = -kt * np.log(p)
    f[~np.isfinite(f)] = np.nan
    return f - np.nanmin(f), np.degrees(edges)
