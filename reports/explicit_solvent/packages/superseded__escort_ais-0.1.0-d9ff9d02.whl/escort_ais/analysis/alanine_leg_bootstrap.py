"""Cluster-bootstrap confidence intervals for the alanine cBAR arms, from the retained leg banks.

The alanine driver keeps its per-leg output in ``--work-dir`` (default
``data/alanine_dipeptide/condbar_remdfree``), which is a DIFFERENT directory from ``--out``. It is
cleared once at start-up to drop a stale tree, never at the end, and every generation writes to its
own ``g<NN>_H<m>_fwd`` / ``g<NN>_b<m>_rev`` path -- so a completed run leaves the whole bank on
disk. Searching only the output tree finds four JSON files and looks like proof that nothing was
retained; it is not.

LAYOUT, which differs from the macrocycle driver's::

    g<NN>_fwd/        forward legs drawn PROPORTIONALLY from the hot ensemble -- the NORMAL arm
    g<NN>_H<m>_fwd/   forward legs launched from hot cell m -- the STRATIFIED arm only
    g<NN>_H<m>_seed/  the hot frames the stratified legs started from
    g<NN>_b<m>_rev/   reverse legs from the confined walker of cold cell m
    g<NN>_b<m>_seed/  the interior frames they started from

THE TWO ARMS DO NOT SHARE A FORWARD BANK. ``--also-stratified`` launches a SEPARATE equal-per-cell
allocation alongside the proportional one, so the normal arm must read ``g<NN>_fwd`` and the
stratified arm ``g<NN>_H<m>_fwd``. Feeding the stratified directories to the normal solver returns
roughly the matched term instead of the total -- a plausible-looking number about 3 kT too small.
Both reconstructions are checked against the driver's own stored per-generation values before any
interval is reported.

RESAMPLING UNIT IS THE SEED FRAME, namespaced by generation. Legs sharing an originating
configuration are not independent, and ``initial_frame_index`` restarts every generation -- pooling
across generations would merge unrelated seeds under one cluster id.

THE HOT TERM IS HELD FIXED. Per the campaign convention, the stratified arm's hot populations are a
property of the hot ensemble, not of the leg banks; bootstrapping legs cannot speak to them. The
interval is on the matched term and on the total through it.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np

from escort_ais.common.paths import project_root

ROOT = project_root()


def _legs(d: Path):
    """(W_reduced, seed_id) for one leg directory, or None."""
    import pandas as pd
    f = d / "ais_trajectory_summary.csv"
    if not f.exists():
        return None
    df = pd.read_csv(f)
    if "final_logw" not in df.columns:
        return None
    return (-df["final_logw"].to_numpy(float),
            df["initial_frame_index"].to_numpy(int) if "initial_frame_index" in df
            else np.arange(len(df)))


def _landing_labels(d: Path, top_pdb: Path, assign) -> np.ndarray:
    import mdtraj as md
    from escort_ais.systems.cv_definition import load_cv_definition
    cv = load_cv_definition("alanine_dipeptide")
    t = md.load_dcd(str(d / "ais_final_coordinates.dcd"), top=str(top_pdb))
    return assign(cv.compute(t))


def bootstrap_delta(fW, fL, rW, n_f, n_r, fC, rC, rng, n_boot, solve):
    """Cluster-resample forward and reverse banks and re-solve; returns [n_boot, ...] array."""
    def draw(C):
        uc, inv = np.unique(C, return_inverse=True)
        by = [np.flatnonzero(inv == k) for k in range(len(uc))]
        pick = rng.integers(0, len(uc), size=len(uc))
        return np.concatenate([by[k] for k in pick])
    out = []
    for _ in range(n_boot):
        fi = draw(fC)
        ri = {m: draw(rC[m]) for m in rW}
        try:
            out.append(solve(fW[fi], fL[fi], {m: rW[m][ri[m]] for m in rW}, len(fi)))
        except Exception:
            continue
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--work-dir", type=Path,
                    default=ROOT / "data/alanine_dipeptide/condbar_remdfree")
    ap.add_argument("--results", type=Path,
                    default=ROOT / "data/alanine_dipeptide/condbar_v8_series/remdfree_results.json")
    ap.add_argument("--partition", type=Path,
                    default=ROOT / "reports/alanine/conditional_bar/campaign_v8/basin_tree.json")
    ap.add_argument("--top", type=Path,
                    default=ROOT / "data/alanine_dipeptide/2026-07-18-ref-singlewalker-cold-s1p0-"
                                   "mbondi3-1000ns/start_structure.pdb")
    ap.add_argument("--bootstrap", type=int, default=200)
    ap.add_argument("--every", type=int, default=1, help="analyse every Nth generation")
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args(argv)

    from escort_ais.analysis.cbar_term_decomposition import load_partition
    from escort_ais.methods.conditional_bar import (combine_substates, endpoint_restricted_delta,
                                                    solve_substates)
    labels, assign = load_partition(a.partition)
    n = len(labels)
    doc = json.loads(a.results.read_text())
    fH = {g["generation"]: np.asarray(g["stratified"]["fH"], float) for g in doc["generations"]
          if g.get("stratified")}

    gens = sorted({int(re.match(r"g(\d+)_", p.name).group(1))
                   for p in a.work_dir.glob("g*_b0_rev")})
    gens = [g for g in gens if g % a.every == 0]
    rng = np.random.default_rng(20260810)

    fW, fL, fC = [], [], []                       # pooled forward bank (normal arm)
    sW, sL, sC = {m: [] for m in range(n)}, {m: [] for m in range(n)}, {m: [] for m in range(n)}
    rW, rC = {m: [] for m in range(n)}, {m: [] for m in range(n)}
    rows = []
    for g in gens:
        ok = True
        nd = a.work_dir / f"g{g:02d}_fwd"                 # proportional bank -> NORMAL arm
        ln = _legs(nd)
        if ln is None:
            ok = False
        else:
            Wn, sn = ln
            fW.append(Wn); fL.append(_landing_labels(nd, a.top, assign))
            fC.append(g * 1000000 + sn)
        for m in range(n):
            fd = a.work_dir / f"g{g:02d}_H{m}_fwd"        # equal allocation -> STRATIFIED arm
            rd = a.work_dir / f"g{g:02d}_b{m}_rev"
            lf, lr = _legs(fd), _legs(rd)
            if lf is None or lr is None:
                ok = False
                break
            W, sid = lf
            lab = _landing_labels(fd, a.top, assign)
            sW[m].append(W); sL[m].append(lab == m); sC[m].append(g * 1000000 + sid)
            rW[m].append(lr[0]); rC[m].append(g * 1000000 + lr[1])
        if not ok:
            print(f"  generation {g} incomplete -- skipped", flush=True)
            continue

        FW, FL, FC = np.concatenate(fW), np.concatenate(fL), np.concatenate(fC)
        RW = {m: np.concatenate(rW[m]) for m in range(n)}
        RC = {m: np.concatenate(rC[m]) for m in range(n)}

        def solve_normal(w, l, rv, nf):
            r = solve_substates(w, l, rv, substate_labels=labels, n_forward=nf)
            c = combine_substates(r, reference=0)
            return [c["relative_free_energies"].get(x, np.nan) for x in labels]
        point_n = solve_normal(FW, FL, RW, len(FW))
        reps_n = bootstrap_delta(FW, FL, RW, len(FW), None, FC, RC, rng, a.bootstrap, solve_normal)

        # stratified: matched per-cell BAR + the FIXED hot term
        SWm = {m: np.concatenate(sW[m]) for m in range(n)}
        SLm = {m: np.concatenate(sL[m]) for m in range(n)}
        SCm = {m: np.concatenate(sC[m]) for m in range(n)}
        RLm = {m: np.concatenate([np.ones(len(x), bool) for x in rW[m]]) for m in range(n)}

        def matched(idx=None):
            d = np.empty(n)
            for m in range(n):
                fi = idx[0][m] if idx else slice(None)
                ri = idx[1][m] if idx else slice(None)
                d[m] = endpoint_restricted_delta(SWm[m][fi], SLm[m][fi], RW[m][ri], RLm[m][ri],
                                                 len(SWm[m][fi]), len(RW[m][ri]))
            return d
        hot = fH.get(g)
        point_s = (matched() - matched()[0] + hot).tolist() if hot is not None else None

        reps_s = []
        if hot is not None:
            for _ in range(a.bootstrap):
                def dr(C):
                    uc, inv = np.unique(C, return_inverse=True)
                    by = [np.flatnonzero(inv == k) for k in range(len(uc))]
                    return np.concatenate([by[k] for k in rng.integers(0, len(uc), size=len(uc))])
                try:
                    d = matched(([dr(SCm[m]) for m in range(n)], [dr(RC[m]) for m in range(n)]))
                    reps_s.append((d - d[0] + hot).tolist())
                except Exception:
                    continue

        def ci(reps, j):
            A = np.array(reps, float)
            if A.size == 0 or A.shape[0] < max(20, a.bootstrap // 3):
                return None
            col = A[:, j][np.isfinite(A[:, j])]
            return [float(np.percentile(col, 5)), float(np.percentile(col, 95))] if col.size else None

        # reproduce the driver's own numbers before trusting the interval
        stored = [x for x in doc["generations"] if x["generation"] == g]
        chk = {}
        if stored:
            b = {y["box"]: y["delta"] for y in stored[0]["boxes"]}
            chk["normal_stored"] = float(-(b[labels[1]] - b[labels[0]]))
            chk["normal_delta"] = float(point_n[1] - chk["normal_stored"])
            if stored[0].get("stratified"):
                chk["strat_stored"] = float(stored[0]["stratified"]["f_rel"][1])
                if point_s is not None:
                    chk["strat_delta"] = float(point_s[1] - chk["strat_stored"])

        rows.append(dict(generation=g, check=chk,
                         normal={labels[j]: float(point_n[j]) for j in range(n)},
                         normal_ci={labels[j]: ci(reps_n, j) for j in range(n)},
                         strat=(None if point_s is None else
                                {labels[j]: float(point_s[j]) for j in range(n)}),
                         strat_ci=({labels[j]: ci(reps_s, j) for j in range(n)}
                                   if reps_s else None),
                         n_forward=int(len(FW)),
                         n_reverse={labels[m]: int(len(RW[m])) for m in range(n)}))
        r = rows[-1]
        nc = r["normal_ci"][labels[1]]; sc = (r["strat_ci"] or {}).get(labels[1])
        dn = chk.get("normal_delta"); ds = chk.get("strat_delta")
        print(f"  gen {g:>3}: normal {r['normal'][labels[1]]:+.3f} "
              f"[{nc[0]:+.3f},{nc[1]:+.3f}] (vs stored {dn:+.4f})"
              + (f"   strat {r['strat'][labels[1]]:+.3f} [{sc[0]:+.3f},{sc[1]:+.3f}]"
                 f" (vs stored {ds:+.4f})" if sc and ds is not None else ""), flush=True)

    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps(rows, indent=2) + "\n")
    print(f"\nwrote {a.out} ({len(rows)} generations)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
