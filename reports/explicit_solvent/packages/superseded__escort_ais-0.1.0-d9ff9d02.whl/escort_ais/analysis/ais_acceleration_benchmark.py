"""ais_acceleration_benchmark.py — the nine timing/accuracy comparisons of report §11.

Every benchmark writes a machine-readable record to
``reports/alanine/ais_performance/benchmark_data/<name>.json`` (plus the per-worker Parquet the runs
themselves produce).  No plotting and no figure styling happens here: the point is the raw data.

The nine comparisons
--------------------
1. ``manual``          — the legacy per-switch driver (``run_linear_scaling_ais``, neq_integrator=False)
2. ``neq_oneshot``     — the same driver with the on-device NEQ integrator
3. ``chunked_hz``      — chunked NEQ + 20 Hummer-Szabo observations (discovery mode)
4. ``cold_context``    — persistent cold context vs. switch-to-cold-and-restore (§3)
5. ``workers``         — 1 / 2 / 4 / 8 workers per GPU (§7)
6.  (same record)      — the 4-worker point is the production configuration
7. ``batched``         — batched copies in one System (§8; feasibility, see the module docstring there)
8. ``freq_ais``        — Freq_AIS = 1 vs 10, matched two ways (§9)
9.  (same record)

Efficiency conventions (§9)
---------------------------
* primary throughput  : completed AIS trajectories per GPU-hour
* primary efficiency  : ``E = 1 / (MSE(Δf̂) × GPU-hours)`` where MSE is the bootstrap mean-squared
  error of the Jarzynski free-energy estimate.  Bootstrap resampling captures the *variance*; a
  protocol-length bias common to all replicates is NOT captured, so ``mean_dF`` is reported
  alongside so any bias between settings is visible.
* ``ess_je_per_gpu_hour`` and ``hz_pmf_rmse_per_gpu_hour`` are reported as secondary metrics.

The HS (multi-time-slice) PMF estimator used for the error metric is the per-slice reweighting

    p̂(φ) ∝ Σ_l Σ_i 1[φ_il ∈ bin] · exp(−W_il − (u_C(x_il) − u_l(x_il)))

Each slice l is on its own an unbiased self-normalised estimator of the COLD ensemble: a sample
drawn at slice l carries AIS weight ``e^{−W_il}`` for the ensemble ∝ ``e^{−u_l}``, and the extra
factor ``e^{−(u_C − u_l)}`` moves it to ``e^{−u_C}``.  Both energies are recorded fields, so the
estimator costs nothing extra.  Slices are combined with equal weight after per-slice
normalisation (a mixture of L unbiased estimators).
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import asdict
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

from escort_ais.common.paths import project_root

DEFAULT_SEED_DIR = "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"
DEFAULT_COLD_REF = "data/alanine_dipeptide/2026-07-18-ref-singlewalker-cold-s1p0-mbondi3-1000ns"
S_HOT, S_COLD = 0.25, 1.0
PHI_BINS = np.linspace(-180.0, 180.0, 37)          # 10° bins


def out_root() -> Path:
    d = project_root() / "reports/alanine/ais_performance/benchmark_data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _write(name: str, payload: dict) -> Path:
    p = out_root() / f"{name}.json"
    p.write_text(json.dumps(payload, indent=2, default=str))
    print(f"[bench] wrote {p}")
    return p


# ─────────────────────────────── estimators ──────────────────────────────────
def jarzynski(reduced_work: np.ndarray) -> float:
    """Δf = −ln⟨e^{−W}⟩ in kT, from reduced forward works."""
    from scipy.special import logsumexp
    w = np.asarray(reduced_work, float)
    return float(-(logsumexp(-w) - np.log(w.size)))


def ess_fraction(reduced_work: np.ndarray) -> float:
    w = np.asarray(reduced_work, float)
    lw = -w - np.max(-w)
    p = np.exp(lw)
    return float(p.sum() ** 2 / np.sum(p ** 2) / w.size)


def bootstrap_mse(reduced_work: np.ndarray, n_boot: int = 400, seed: int = 0) -> dict:
    rng = np.random.default_rng(seed)
    w = np.asarray(reduced_work, float)
    est = np.array([jarzynski(rng.choice(w, w.size, replace=True)) for _ in range(n_boot)])
    point = jarzynski(w)
    return dict(mean_dF=point, boot_mean=float(est.mean()), boot_std=float(est.std(ddof=1)),
                boot_mse=float(np.mean((est - point) ** 2)), n=int(w.size))


def hz_pmf(hz: "object", bins: np.ndarray = PHI_BINS) -> np.ndarray:
    """Multi-time-slice phi population from a discovery-mode ``hz_observations`` table.

    Thin wrapper over the shared, unit-tested estimator in
    ``escort_ais.analysis.hz_reconstruction`` (verified against an exactly solvable 1-D system in
    ``tests/test_hz_reconstruction.py``) so the benchmark and the production analysis cannot
    drift apart.
    """
    from escort_ais.analysis.hz_reconstruction import hz_reconstruct_dataframe
    return hz_reconstruct_dataframe(hz, bins, column="phi", combine="per_slice_mean")["density"]


def reference_phi_pmf(cold_ref_dir: Optional[Path] = None,
                      bins: np.ndarray = PHI_BINS) -> Optional[np.ndarray]:
    """φ populations from the 1 µs cold (s=1) reference MD, or None if it is unavailable."""
    import mdtraj as md
    d = Path(cold_ref_dir or project_root() / DEFAULT_COLD_REF)
    traj, top = d / "trajectory.dcd", d / "start_structure.pdb"
    if not traj.exists() or not top.exists():
        return None
    t = md.load(str(traj), top=str(top))
    from escort_ais.analysis.analysis import find_phi_psi_indices
    phi_idx, _ = find_phi_psi_indices(md.Topology.to_openmm(t.topology))
    ang = np.degrees(md.compute_dihedrals(t, [list(map(int, phi_idx))])[:, 0])
    h, _ = np.histogram(ang, bins=bins)
    return h / h.sum()


def pmf_rmse(p: np.ndarray, ref: Optional[np.ndarray]) -> float:
    """RMSE in kT of −ln p over bins where BOTH are populated."""
    if ref is None:
        return float("nan")
    m = (p > 0) & (ref > 0)
    if m.sum() < 3:
        return float("nan")
    a, b = -np.log(p[m]), -np.log(ref[m])
    return float(np.sqrt(np.mean(((a - a.mean()) - (b - b.mean())) ** 2)))


def landing_coverage(phi_deg: np.ndarray, reduced_work: Optional[np.ndarray] = None) -> dict:
    """How much of the Ramachandran plane the cold landings reach (+ the rare φ>0 weight)."""
    phi = np.asarray(phi_deg, float)
    occ = np.histogram(phi, bins=PHI_BINS)[0]
    d = dict(n=int(phi.size), n_bins_occupied=int((occ > 0).sum()),
             frac_phi_positive=float(np.mean(phi > 0)))
    if reduced_work is not None:
        lw = -np.asarray(reduced_work, float)
        lw -= lw.max()
        w = np.exp(lw)
        d["weighted_frac_phi_positive"] = float(w[phi > 0].sum() / w.sum())
    return d


# ───────────────────────────── benchmark drivers ─────────────────────────────
def _seed_dir(p: Optional[Path]) -> Path:
    return Path(p or project_root() / DEFAULT_SEED_DIR)


def bench_legacy(work_dir: Path, k_ais: int, t_ais: int, freq_ais: int, platform: str,
                 neq: bool, seed_dir: Optional[Path] = None, seed: int = 20260728,
                 device_index: Optional[str] = None, stride: int = 97) -> dict:
    """Comparisons 1 and 2: the existing single-process driver, manual vs on-device NEQ work."""
    import pandas as pd

    from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
    out = Path(work_dir)
    shutil.rmtree(out, ignore_errors=True)
    cfg = LinearAISConfig(
        solvent="implicit", k_ais=k_ais, t_ais=t_ais, freq_ais=freq_ais, s_hot=S_HOT, s_cold=S_COLD,
        platform=platform, seed=seed, start_frame_stride=stride, input_scaled_dir=_seed_dir(seed_dir),
        output_dir=out, overwrite=True, save_traj_every_switch=False, scaling_mode="square",
        neq_integrator=neq, device_index=device_index)
    t0 = time.perf_counter()
    run_linear_scaling_ais(cfg)
    wall = time.perf_counter() - t0
    df = pd.read_csv(out / "ais_trajectory_summary.csv")
    w = -df["final_logw"].to_numpy()                      # reduced forward work
    rec = dict(name="manual" if not neq else "neq_oneshot", wall_clock_s=wall, k_ais=k_ais,
               t_ais=t_ais, freq_ais=freq_ais, platform=platform, neq_integrator=neq,
               s_per_trajectory=wall / k_ais, trajectories_per_gpu_hour=k_ais / (wall / 3600.0),
               work_mean=float(w.mean()), work_std=float(w.std(ddof=1)),
               ess_fraction=ess_fraction(w), **bootstrap_mse(w),
               coverage=landing_coverage(df["final_phi"].to_numpy(), w))
    rec["efficiency_E"] = 1.0 / max(rec["boot_mse"], 1e-12) / (wall / 3600.0)
    rec["ess_je_per_gpu_hour"] = rec["ess_fraction"] * k_ais / (wall / 3600.0)
    return rec


def bench_chunked(work_dir: Path, k_ais: int, t_ais: int, freq_ais: int, platform: str,
                  mode: str, workers_per_gpu: int, device_indices: Sequence[str],
                  seed_dir: Optional[Path] = None, seed: int = 20260728,
                  hz_n_observations: int = 20, full_coordinate_interval_ps: Optional[float] = None,
                  stride: int = 97, ref_pmf: Optional[np.ndarray] = None) -> dict:
    """Comparisons 3, 5, 6, 8, 9: the chunked-NEQ launcher in either mode."""
    import pandas as pd

    from escort_ais.methods.chunked_neq_ais import ChunkedNEQConfig
    from escort_ais.methods.chunked_neq_launcher import LaunchSpec, launch
    out = Path(work_dir)
    shutil.rmtree(out, ignore_errors=True)
    cfg = ChunkedNEQConfig(s_hot=S_HOT, s_cold=S_COLD, scaling_mode="square", t_ais=t_ais,
                           freq_ais=freq_ais, mode=mode, hz_n_observations=hz_n_observations,
                           full_coordinate_interval_ps=full_coordinate_interval_ps,
                           platform=platform)
    m = launch(LaunchSpec(cfg=cfg, input_scaled_dir=_seed_dir(seed_dir), run_dir=out,
                          n_trajectories=k_ais, workers_per_gpu=workers_per_gpu,
                          device_indices=tuple(device_indices), base_seed=seed,
                          start_frame_stride=stride))
    s = pd.read_parquet(out / "merged" / "trajectory_summary.parquet")
    w = s["final_W_reduced"].to_numpy()
    rec = dict(name=f"chunked_{mode}_w{workers_per_gpu}", mode=mode,
               workers_per_gpu=workers_per_gpu, n_gpus=len(device_indices),
               k_ais=k_ais, t_ais=t_ais, freq_ais=freq_ais, m_ais=cfg.m_ais, platform=platform,
               wall_clock_s=m["wall_clock_s"],
               trajectories_per_gpu_hour=m["trajectories_per_gpu_hour"],
               s_per_trajectory=m["wall_clock_s"] / max(k_ais, 1),
               work_mean=float(w.mean()), work_std=float(w.std(ddof=1)),
               ess_fraction=ess_fraction(w), **bootstrap_mse(w),
               coverage=landing_coverage(s["final_phi"].to_numpy(), w),
               stage_timings=m["stage_timings"], per_worker=m["per_worker"])
    gpu_h = m["wall_clock_s"] / 3600.0 * len(device_indices)
    rec["efficiency_E"] = 1.0 / max(rec["boot_mse"], 1e-12) / gpu_h
    rec["ess_je_per_gpu_hour"] = rec["ess_fraction"] * k_ais / gpu_h
    hz_path = out / "merged" / "hz_observations.parquet"
    if hz_path.exists():
        hz = pd.read_parquet(hz_path)
        p = hz_pmf(hz)
        rec["hz_pmf"] = p.tolist()
        rec["hz_pmf_rmse_kT"] = pmf_rmse(p, ref_pmf)
        rec["hz_pmf_rmse_per_gpu_hour"] = rec["hz_pmf_rmse_kT"] / gpu_h if gpu_h else float("nan")
        rec["n_hz_rows"] = int(len(hz))
    return rec


def bench_cold_context(platform: str, n_probe: int = 200, t_ais: int = 500,
                       seed_dir: Optional[Path] = None, device_index: Optional[str] = None) -> dict:
    """Comparison 4 (§3): persistent cold context vs. switch-to-cold-and-restore.

    Times the three components separately (position transfer, cold energy evaluation, total per
    observation) and asserts the two routes give the same ``u_C``.
    """
    import openmm
    from openmm import unit

    from escort_ais.methods.ais_linear import LinearAISConfig, load_ais_inputs
    from escort_ais.methods.chunked_neq_ais import ChunkedNEQConfig, ChunkedNEQRunner
    import mdtraj as md

    lin = LinearAISConfig(solvent="implicit", k_ais=1, t_ais=t_ais, freq_ais=1, s_hot=S_HOT,
                          s_cold=S_COLD, platform=platform, scaling_mode="square")
    inputs = load_ais_inputs(lin, _seed_dir(seed_dir))
    cfg = ChunkedNEQConfig(s_hot=S_HOT, s_cold=S_COLD, t_ais=t_ais, freq_ais=1, mode="discovery",
                           platform=platform, device_index=device_index)
    runner = ChunkedNEQRunner(cfg, inputs.base_system, inputs.topology, inputs.solute_indices,
                              phi_indices=inputs.phi_indices, psi_indices=inputs.psi_indices)
    frame = md.load_frame(str(inputs.source_traj_path), 0, top=str(inputs.source_topology_path))
    runner.context.setPositions(np.asarray(frame.xyz[0], float) * unit.nanometer)
    runner.context.setVelocitiesToTemperature(cfg.temperature_k * unit.kelvin, 1)

    xs, u_persist, u_switch = [], [], []
    t_pos = t_eval = t_switch_route = 0.0
    for i in range(n_probe):
        runner.integrator.step(2)
        x = runner.context.getState(getPositions=True).getPositions(asNumpy=True) \
            .value_in_unit(unit.nanometer)
        xs.append(x)

        t0 = time.perf_counter()
        runner.cold_context.setPositions(x * unit.nanometer)
        t1 = time.perf_counter()
        e = runner.cold_context.getState(getEnergy=True).getPotentialEnergy() \
            .value_in_unit(unit.kilojoule_per_mole)
        t2 = time.perf_counter()
        t_pos += t1 - t0
        t_eval += t2 - t1
        u_persist.append(float(e))

        # the route we are replacing: rescale the SWITCHING context to cold, read, restore
        t3 = time.perf_counter()
        saved = {n: runner.context.getParameter(n) for n in runner.scaler._params}
        runner.scaler.apply(S_COLD, runner.context)
        e2 = runner.context.getState(getEnergy=True).getPotentialEnergy() \
            .value_in_unit(unit.kilojoule_per_mole)
        for n, v in saved.items():
            runner.context.setParameter(n, v)
        t4 = time.perf_counter()
        t_switch_route += t4 - t3
        u_switch.append(float(e2))

    a, b = np.array(u_persist), np.array(u_switch)
    rec = dict(name="cold_context", platform=platform, n_probe=n_probe,
               persistent_position_transfer_ms=1e3 * t_pos / n_probe,
               persistent_energy_eval_ms=1e3 * t_eval / n_probe,
               persistent_total_ms=1e3 * (t_pos + t_eval) / n_probe,
               switch_restore_total_ms=1e3 * t_switch_route / n_probe,
               speedup=float(t_switch_route / max(t_pos + t_eval, 1e-12)),
               max_abs_energy_difference_kj=float(np.abs(a - b).max()),
               energies_agree=bool(np.allclose(a, b, atol=1e-4, rtol=1e-9)))
    runner.close()
    return rec


def bench_freq_ais(work_dir: Path, k_ais: int, platform: str, device_indices: Sequence[str],
                   workers_per_gpu: int = 4, seed_dir: Optional[Path] = None,
                   m_ais_matched: int = 2500, t_ais_matched: int = 2500,
                   ref_pmf: Optional[np.ndarray] = None, seed: int = 20260728) -> dict:
    """Comparisons 8/9 (§9): Freq_AIS = 1 vs 10, matched two ways.

    * fixed switching-interval count  M_ais : Freq 1 → T = M,      Freq 10 → T = 10 M
    * fixed total MD step count       T_ais : Freq 1 → M = T,      Freq 10 → M = T/10

    Freq_AIS = 1 is NOT rejected for dissipating more: the question is whether its lower cost buys
    more precision per GPU-hour, which is what ``efficiency_E`` measures.
    """
    runs = {}
    for label, t_ais, freq in (("matched_M_freq1", m_ais_matched, 1),
                               ("matched_M_freq10", 10 * m_ais_matched, 10),
                               ("matched_T_freq1", t_ais_matched, 1),
                               ("matched_T_freq10", t_ais_matched, 10)):
        runs[label] = bench_chunked(Path(work_dir) / label, k_ais, t_ais, freq, platform,
                                    "discovery", workers_per_gpu, device_indices,
                                    seed_dir=seed_dir, seed=seed, ref_pmf=ref_pmf)
        runs[label]["name"] = f"freq_ais_{label}"
        print(f"[bench] {label}: {runs[label]['trajectories_per_gpu_hour']:.0f} traj/GPU-h, "
              f"E={runs[label]['efficiency_E']:.3g}")
    return dict(name="freq_ais", runs=runs)


# ─────────────────────────────────── CLI ─────────────────────────────────────
def main(argv=None) -> None:
    import argparse

    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--which", nargs="+", default=["all"],
                    choices=["all", "legacy", "chunked", "cold_context", "workers", "multigpu",
                             "freq_ais"])
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device-indices", default="0")
    ap.add_argument("--k-ais", type=int, default=64)
    ap.add_argument("--k-ais-workers", type=int, default=256)
    ap.add_argument("--t-ais", type=int, default=2500)
    ap.add_argument("--freq-ais", type=int, default=1)
    ap.add_argument("--seed-dir", type=Path, default=None)
    ap.add_argument("--scratch", type=Path,
                    default=Path("/tmp/ais_accel_bench"))
    ap.add_argument("--seed", type=int, default=20260728)
    ap.add_argument("--workers-per-gpu", type=int, default=1,
                    help="workers per GPU for the freq_ais and multi-GPU points "
                         "(1 is optimal for alanine -- see the report)")
    args = ap.parse_args(argv)

    which = set(args.which)
    if "all" in which:
        which = {"legacy", "chunked", "cold_context", "workers", "multigpu", "freq_ais"}
    devs = tuple(args.device_indices.split(","))
    scratch = Path(args.scratch)
    scratch.mkdir(parents=True, exist_ok=True)
    ref = reference_phi_pmf()
    if ref is None:
        print("[bench] WARNING: cold reference MD not found; HS PMF errors will be NaN")
    else:
        _write("reference_phi_pmf", dict(bins=PHI_BINS.tolist(), p=ref.tolist()))

    if "cold_context" in which:
        _write("cold_context", bench_cold_context(args.platform, device_index=devs[0]))

    if "legacy" in which:
        for neq in (False, True):
            rec = bench_legacy(scratch / ("manual" if not neq else "neq_oneshot"), args.k_ais,
                               args.t_ais, args.freq_ais, args.platform, neq,
                               seed_dir=args.seed_dir, seed=args.seed, device_index=devs[0])
            _write(rec["name"], rec)
            print(f"[bench] {rec['name']}: {rec['s_per_trajectory']:.3f} s/traj, "
                  f"{rec['trajectories_per_gpu_hour']:.0f} traj/GPU-h")

    if "chunked" in which:
        for mode, tag in (("production", "chunked_production"), ("discovery", "chunked_hz")):
            rec = bench_chunked(scratch / tag, args.k_ais, args.t_ais, args.freq_ais, args.platform,
                                mode, 1, devs[:1], seed_dir=args.seed_dir, seed=args.seed,
                                full_coordinate_interval_ps=(5.0 if mode == "discovery" else None),
                                ref_pmf=ref)
            rec["name"] = tag
            _write(tag, rec)
            print(f"[bench] {tag}: {rec['s_per_trajectory']:.3f} s/traj, "
                  f"{rec['trajectories_per_gpu_hour']:.0f} traj/GPU-h")

    if "multigpu" in which:
        rec = bench_chunked(scratch / "multigpu", args.k_ais_workers, args.t_ais, args.freq_ais,
                            args.platform, "production", args.workers_per_gpu, devs,
                            seed_dir=args.seed_dir, seed=args.seed, ref_pmf=ref)
        rec["name"] = "multigpu"
        _write("multigpu", rec)
        print(f"[bench] {len(devs)} GPUs x {args.workers_per_gpu} worker: "
              f"{rec['trajectories_per_gpu_hour']:.0f} traj/GPU-h, "
              f"{rec['k_ais'] / (rec['wall_clock_s'] / 3600):.0f} traj/h total")

    if "workers" in which:
        out = {}
        for w in (1, 2, 4, 8):
            rec = bench_chunked(scratch / f"workers_{w}", args.k_ais_workers, args.t_ais,
                                args.freq_ais, args.platform, "production", w, devs[:1],
                                seed_dir=args.seed_dir, seed=args.seed, ref_pmf=ref)
            out[str(w)] = rec
            print(f"[bench] workers/gpu={w}: {rec['trajectories_per_gpu_hour']:.0f} traj/GPU-h "
                  f"({rec['wall_clock_s']:.1f} s)")
        _write("workers_per_gpu", dict(name="workers_per_gpu", runs=out,
                                       k_ais=args.k_ais_workers, t_ais=args.t_ais))
        if len(devs) > 1:                        # multi-GPU point, same workers-per-GPU
            rec = bench_chunked(scratch / "workers_multigpu", args.k_ais_workers, args.t_ais,
                                args.freq_ais, args.platform, "production",
                                args.workers_per_gpu, devs,
                                seed_dir=args.seed_dir, seed=args.seed, ref_pmf=ref)
            _write("workers_multigpu", rec)

    if "freq_ais" in which:
        _write("freq_ais", bench_freq_ais(scratch / "freq", args.k_ais, args.platform, devs[:1],
                                          workers_per_gpu=args.workers_per_gpu,
                                          seed_dir=args.seed_dir, ref_pmf=ref, seed=args.seed))


if __name__ == "__main__":
    main()
