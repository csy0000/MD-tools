"""mps_benchmark.py — OPTIONAL CUDA MPS throughput benchmark (report §12).

Background.  Without MPS, kernels from different processes sharing one GPU are *time-sliced* by
the driver, and for a 22-atom launch-latency-bound system that costs more than it buys: the
measured aggregate throughput on one RTX A5000 falls from 1.39 traj/s (1 process) to 0.57 traj/s
(2 or 4 processes).  CUDA MPS lets kernels from several processes run concurrently instead, which
is the mechanism that could change that verdict.

This module does **not** enable MPS.  Starting ``nvidia-cuda-mps-control`` is a machine-wide
change affecting every user of the GPU, so it is the operator's decision:

    export CUDA_VISIBLE_DEVICES=0
    nvidia-cuda-mps-control -d          # operator runs this, not this script
    python -m escort_ais.analysis.mps_benchmark --confirm-mps-active --device 0
    echo quit | nvidia-cuda-mps-control # operator stops it afterwards

``--confirm-mps-active`` is required: the script refuses to report "MPS numbers" it cannot
attribute to MPS.  It probes for a running control daemon and records what it found, so the
result is never silently mislabelled.

The default of one worker per GPU changes only if MPS shows a **reproducible aggregate speed-up**
over the recorded non-MPS baseline (``benchmark_data/gpu_sharing_probe.json``).
"""
from __future__ import annotations

import json
import multiprocessing as mp
import subprocess
import time
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

SEED_DIR = "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns"
S_HOT, S_COLD = 0.25, 1.0


# ─────────────────────────────── MPS detection ───────────────────────────────
def detect_mps() -> dict:
    """Best-effort evidence that an MPS control daemon is running. Never starts one."""
    out = dict(control_daemon_process=False, pipe_dir=None, nvidia_smi_mode=None)
    try:
        ps = subprocess.run(["pgrep", "-f", "nvidia-cuda-mps-control"], capture_output=True,
                            text=True, timeout=10)
        out["control_daemon_process"] = ps.returncode == 0 and bool(ps.stdout.strip())
    except Exception:
        pass
    for d in ("/tmp/nvidia-mps", Path.home() / "nvidia-mps"):
        if Path(d).exists():
            out["pipe_dir"] = str(d)
            break
    try:
        smi = subprocess.run(["nvidia-smi", "--query-gpu=compute_mode", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=15)
        if smi.returncode == 0:
            out["nvidia_smi_mode"] = smi.stdout.strip().splitlines()
    except Exception:
        pass
    out["looks_active"] = bool(out["control_daemon_process"] or out["pipe_dir"])
    return out


# ─────────────────────────────── the workload ────────────────────────────────
def _worker(q, device: str, n_traj: int, t_ais: int, seed: int):
    """One process: build a context and run ``n_traj`` full AIS legs; report seconds/trajectory."""
    try:
        import numpy as _np
        from pathlib import Path as _P

        import mdtraj as md
        from openmm import unit

        from escort_ais.common.paths import project_root
        from escort_ais.methods.ais_linear import LinearAISConfig, load_ais_inputs
        from escort_ais.methods.chunked_neq_ais import ChunkedNEQConfig, ChunkedNEQRunner

        lin = LinearAISConfig(solvent="implicit", k_ais=1, t_ais=t_ais, freq_ais=1,
                              s_hot=S_HOT, s_cold=S_COLD, platform="CUDA", scaling_mode="square")
        inputs = load_ais_inputs(lin, project_root() / SEED_DIR)
        cfg = ChunkedNEQConfig(s_hot=S_HOT, s_cold=S_COLD, t_ais=t_ais, freq_ais=1,
                               mode="production", platform="CUDA", device_index=device)
        runner = ChunkedNEQRunner(cfg, inputs.base_system, inputs.topology, inputs.solute_indices,
                                  phi_indices=inputs.phi_indices, psi_indices=inputs.psi_indices,
                                  worker_id=0, base_seed=seed)
        frame = md.load_frame(str(inputs.source_traj_path), 0,
                              top=str(inputs.source_topology_path))
        xyz0 = _np.asarray(frame.xyz[0], float)

        runner.run_trajectory(xyz0, trajectory_index=0)          # warm-up, not timed
        t0 = time.perf_counter()
        for i in range(1, n_traj + 1):
            runner.run_trajectory(xyz0, trajectory_index=i)
        dt = time.perf_counter() - t0
        runner.close()
        q.put(("ok", dt / n_traj))
    except BaseException as exc:                                  # noqa: BLE001
        import traceback
        q.put(("error", f"{type(exc).__name__}: {exc}\n{traceback.format_exc()[-1500:]}"))


def benchmark_workers(device: str = "0", worker_counts: Sequence[int] = (1, 2, 4),
                      n_traj: int = 8, t_ais: int = 2500, seed: int = 20260728) -> dict:
    """Aggregate throughput for N concurrent worker processes on ONE device."""
    ctx = mp.get_context("spawn")
    rows = {}
    for n in worker_counts:
        q = ctx.Queue()
        procs = [ctx.Process(target=_worker, args=(q, device, n_traj, t_ais, seed + 100 * w))
                 for w in range(n)]
        t0 = time.perf_counter()
        for p in procs:
            p.start()
        results = [q.get() for _ in procs]
        for p in procs:
            p.join()
        wall = time.perf_counter() - t0
        errs = [r[1] for r in results if r[0] == "error"]
        per = [r[1] for r in results if r[0] == "ok"]
        rows[str(n)] = dict(
            n_workers=n, errors=errs,
            s_per_trajectory_each=per,
            s_per_trajectory_mean=float(np.mean(per)) if per else float("nan"),
            aggregate_traj_per_s=(float(n / np.mean(per)) if per else float("nan")),
            wall_clock_s=wall, n_traj_per_worker=n_traj)
        print(f"[mps] {n} worker(s): {rows[str(n)]['s_per_trajectory_mean']*1e3:.0f} ms/traj each"
              f" -> aggregate {rows[str(n)]['aggregate_traj_per_s']:.3f} traj/s")
    return rows


def compare_with_baseline(rows: dict, baseline_path: Optional[Path] = None) -> dict:
    """Compare against the recorded NON-MPS probe and state whether the default should change."""
    from escort_ais.common.paths import project_root
    p = Path(baseline_path or project_root()
             / "reports/alanine/ais_performance/benchmark_data/gpu_sharing_probe.json")
    if not p.exists():
        return dict(available=False, note=f"no non-MPS baseline at {p}")
    base = {str(r["n_processes"]): r for r in json.loads(p.read_text())["rows"]}
    cmp = {}
    for n, r in rows.items():
        b = base.get(n)
        if not b or not np.isfinite(r["aggregate_traj_per_s"]):
            continue
        cmp[n] = dict(mps_aggregate=r["aggregate_traj_per_s"],
                      non_mps_aggregate=b["aggregate_traj_per_s_excl_startup"],
                      speedup=r["aggregate_traj_per_s"] / b["aggregate_traj_per_s_excl_startup"])
    best = max((v["speedup"] for v in cmp.values()), default=float("nan"))
    one = cmp.get("1", {}).get("mps_aggregate", float("nan"))
    beats_single = {n: (v["mps_aggregate"] / one if np.isfinite(one) and one > 0 else float("nan"))
                    for n, v in cmp.items()}
    change = any(np.isfinite(v) and v > 1.15 for k, v in beats_single.items() if k != "1")
    return dict(available=True, per_worker_count=cmp, best_speedup_vs_non_mps=best,
                multiworker_vs_single_worker_under_mps=beats_single,
                recommendation=("switch the default to >1 worker per GPU (MPS gives a "
                                ">15 % aggregate gain)" if change else
                                "KEEP one worker per GPU: MPS does not give a reproducible "
                                "aggregate speed-up over a single worker"))


def main(argv=None) -> None:
    import argparse

    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--confirm-mps-active", action="store_true",
                    help="REQUIRED. Assert that you started nvidia-cuda-mps-control yourself.")
    ap.add_argument("--device", default="0")
    ap.add_argument("--workers", type=int, nargs="+", default=[1, 2, 4])
    ap.add_argument("--n-traj", type=int, default=8)
    ap.add_argument("--t-ais", type=int, default=2500)
    ap.add_argument("--seed", type=int, default=20260728)
    args = ap.parse_args(argv)

    probe = detect_mps()
    print(f"[mps] detection: {probe}")
    if not args.confirm_mps_active:
        raise SystemExit(
            "Refusing to run: pass --confirm-mps-active only after YOU have started the MPS "
            "control daemon (`nvidia-cuda-mps-control -d`). This script never enables MPS, and "
            "will not label numbers as MPS results without that confirmation.")
    if not probe["looks_active"]:
        print("[mps] WARNING: --confirm-mps-active was given but no MPS control daemon was "
              "detected. The results below are recorded as UNVERIFIED.")

    rows = benchmark_workers(args.device, args.workers, args.n_traj, args.t_ais, args.seed)
    payload = dict(name="mps_benchmark", device=args.device, t_ais=args.t_ais,
                   n_traj_per_worker=args.n_traj, mps_detection=probe,
                   mps_confirmed_by_operator=bool(args.confirm_mps_active),
                   mps_verified_by_probe=bool(probe["looks_active"]), rows=rows)
    payload["comparison"] = compare_with_baseline(rows)
    print(f"[mps] {payload['comparison'].get('recommendation')}")

    from escort_ais.common.paths import project_root
    out = project_root() / "reports/alanine/ais_performance/benchmark_data/mps_benchmark.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, default=str))
    print(f"[mps] wrote {out}")


if __name__ == "__main__":
    main()
