"""Section 8: cutoff policies compared on identical raw rows AT MATCHED COUNTS, against the reference.

This is the first step in the campaign that is allowed to look at a reference answer, and only
because every selection is already frozen: ``selection_lock.json`` is hashed and ``decision.json``
is written. Running this earlier would have let the reference leak into a threshold.

MATCHED COUNTS ARE THE WHOLE POINT. A later cutoff keeps fewer blocks, so comparing it to
``LEGACY_ALL`` at its natural size confounds "discarding early records helped" with "the estimate
used less data". Every policy here is subsampled to the SAME number of shots -- the size of the
smallest suffix -- and the subsampling is repeated so the reported spread is the policy's, not one
lucky draw's.

``REFERENCE_ORACLE_CUTOFF`` is computed and reported as overfitting evidence ONLY. It is the cutoff
that minimises reference error in hindsight and can never be selected or promoted; its value is the
gap between it and what the blind gate achieved, which is a measure of how much hindsight would
have been worth.

The reference is the all-replica MBAR reconstruction evaluated INSIDE THE FROZEN CELLS, never the
partition MBAR would have chosen for itself -- scoring against different cells would confound
estimator error with a partition difference. The stored ``pi`` in the reference file is ignored for
exactly this reason: for alanine it has three entries and campaign_v8 has two basins.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root
from escort_ais.analysis.burnin_block_metrics import cell_labels

ROOT = project_root()

REFERENCES = {
    "alanine": ROOT / "reports/alanine/remd_ground_truth/cold_reference.npz",
    "cyclo_rgdfv": ROOT / "reports/rgd/remd_ground_truth/cold_reference.npz",
}


def reference_pi(system: str, partition: Path) -> np.ndarray:
    """MBAR-weighted mass of each FROZEN cell, from the raw reference cloud."""
    z = np.load(REFERENCES[system])
    w = z["weights"].astype(float)
    w = w / w.sum()
    if system == "alanine":
        ang = np.column_stack([z["phi"], z["psi"]]).astype(float)
    else:
        ang = z["angles"].astype(float)
    # both references store RADIANS; assert rather than assume -- a degrees cloud would assign
    # every frame to whichever cell happens to span the origin and look entirely plausible
    if np.nanmax(np.abs(ang)) > 2 * np.pi:
        raise SystemExit(f"{REFERENCES[system]}: angles exceed 2*pi, so they are not radians "
                         f"(max |angle| = {np.nanmax(np.abs(ang)):.1f}); refusing to assign cells")
    lab, names = cell_labels(ang, partition)
    if (lab < 0).any():
        raise SystemExit(f"{system}: {int((lab < 0).sum())} reference frames fall outside an "
                         f"exhaustive partition")
    pi = np.array([w[lab == m].sum() for m in range(len(names))])
    return pi, names


def rel_f(logw, ci, n_cells, ref):
    n = float(len(logw))
    ell = np.array([logsumexp(logw[ci == m]) - np.log(n) if (ci == m).any() else -np.inf
                    for m in range(n_cells)])
    return -(ell - ell[ref])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--campaign", type=Path,
                    default=ROOT / "campaigns/20260808T074306Z__forward-prep-burnin")
    ap.add_argument("--n-resample", type=int, default=200)
    ap.add_argument("--seed", type=int, default=20260809)
    a = ap.parse_args(argv)

    import pandas as pd

    lock = json.loads((a.campaign / "selection_lock.json").read_text())
    decision = json.loads((a.campaign / "decision.json").read_text())
    rows, summary = [], {}

    for sysname, S in lock["systems"].items():
        land = pd.read_parquet(a.campaign / f"landings_{sysname}.parquet")
        land = land[land["cell_index"] >= 0].reset_index(drop=True)
        partition = ROOT / S["cold_cells"]["partition_file"]
        n_blocks = S["block_definition"]["n_blocks"]

        pi_ref, names = reference_pi(sysname, partition)
        ref = int(np.argmax(pi_ref))                  # C_0 = highest-population cell, fixed
        f_ref = -np.log(pi_ref / pi_ref[ref])

        logw = land["logw"].to_numpy(float)
        ci = land["cell_index"].to_numpy(int)
        blocks = land["block_id"].to_numpy(int)

        # policies: LEGACY_ALL (c=0) and the fixed-cutoff sweep. Every candidate must retain at
        # least the 6 blocks the lock requires, so c runs 0..n_blocks-6.
        cutoffs = list(range(0, n_blocks - lock["eligibility"]["min_diagnostic_blocks_in_candidate"] + 1))
        n_match = int(min((blocks >= c).sum() for c in cutoffs))
        rng = np.random.default_rng(a.seed)

        for c in cutoffs:
            idx = np.flatnonzero(blocks >= c)
            draws = np.array([rel_f(logw[p], ci[p], len(names), ref) for p in
                              (rng.choice(idx, size=n_match, replace=False)
                               for _ in range(a.n_resample))])
            for m in range(len(names)):
                if m == ref:
                    continue
                col = draws[:, m]
                col = col[np.isfinite(col)]
                rows.append(dict(
                    system=sysname,
                    policy=("LEGACY_ALL" if c == 0 else f"FIXED_CUTOFF_{c}"),
                    cutoff=c, cell=names[m], n_matched_shots=n_match,
                    n_available_shots=int(len(idx)),
                    f_rel_mean=float(col.mean()) if col.size else np.nan,
                    f_rel_lo=float(np.percentile(col, 2.5)) if col.size else np.nan,
                    f_rel_hi=float(np.percentile(col, 97.5)) if col.size else np.nan,
                    f_reference=float(f_ref[m]),
                    residual=float(col.mean() - f_ref[m]) if col.size else np.nan,
                    reference_pi=float(pi_ref[m])))

        df = pd.DataFrame([r for r in rows if r["system"] == sysname])
        worst = df.groupby("cutoff")["residual"].apply(lambda s: s.abs().max())
        oracle = int(worst.idxmin())
        blind = decision["systems"][sysname]["source_burn_cutoff"]
        summary[sysname] = dict(
            reference=str(REFERENCES[sysname].relative_to(ROOT)),
            reference_pi=pi_ref.tolist(), reference_cell=names[ref],
            f_reference_kT={names[m]: float(f_ref[m]) for m in range(len(names)) if m != ref},
            n_matched_shots=n_match,
            worst_abs_residual_by_cutoff={int(k): float(v) for k, v in worst.items()},
            reference_oracle_cutoff=oracle,
            oracle_worst_abs_residual_kT=float(worst.min()),
            legacy_all_worst_abs_residual_kT=float(worst.loc[0]),
            blind_gate_cutoff=blind,
            gate_status=decision["systems"][sysname]["status"],
            oracle_note=("REFERENCE_ORACLE_CUTOFF is hindsight overfitting evidence and can never "
                         "be selected or promoted. The blind gate returned no cutoff for this "
                         "system, so the comparison below measures what hindsight would have "
                         "bought, not what the gate gave up."))

    out = pd.DataFrame(rows)
    out.to_parquet(a.campaign / "matched_results.parquet", index=False)
    (a.campaign / "matched_summary.json").write_text(json.dumps(summary, indent=2) + "\n")

    print(f"wrote matched_results.parquet ({len(out)} rows) and matched_summary.json\n")
    for sysname, s in summary.items():
        print(f"=== {sysname} ===  gate: {s['gate_status']}  (blind cutoff: {s['blind_gate_cutoff']})")
        print(f"  reference pi = {np.round(s['reference_pi'], 4).tolist()}  (cell {s['reference_cell']} = C_0)")
        print(f"  reference f_m - f_0 = " +
              ", ".join(f"{k} {v:+.3f}" for k, v in s["f_reference_kT"].items()) + " kT")
        print(f"  matched at {s['n_matched_shots']} shots per policy")
        print("  worst |residual| by cutoff (kT):")
        for k, v in sorted(s["worst_abs_residual_by_cutoff"].items()):
            tag = "  <- LEGACY_ALL" if k == 0 else ("  <- ORACLE" if k == s["reference_oracle_cutoff"] else "")
            print(f"    cutoff {k}: {v:6.3f}{tag}")
        print(f"  hindsight would have bought "
              f"{s['legacy_all_worst_abs_residual_kT'] - s['oracle_worst_abs_residual_kT']:+.3f} kT "
              f"over LEGACY_ALL\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
