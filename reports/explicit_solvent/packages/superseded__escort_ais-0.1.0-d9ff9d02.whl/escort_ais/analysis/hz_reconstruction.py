"""hz_reconstruction.py — Hummer–Szabo multiple-time-slice reconstruction of the COLD ensemble.

NAMING.  The correct abbreviation is **HS** (Hummer–**S**zabo) and all prose in this repository
uses it.  The ``hz_`` prefix on module names, identifiers, parquet columns, on-disk artifacts
(``hz_observations.parquet``) and the ``--hz-n-observations`` CLI flag is a legacy misspelling that
is deliberately NOT renamed: those names are a wire format shared with ~100 committed run
directories, and renaming the code without the data would silently break every existing run.
Read ``hz_`` as "Hummer–Szabo" wherever it appears.

The identity this module implements (report §3).  For an AIS path driven from ``u_0`` to ``u_C``
through intermediates ``u_k``, the partial-path Jarzynski relation is exact for *every* slice:

    E[ f(x_k) e^{-W_{0:k}} ]  =  (Z_k / Z_0) · E_{π_k}[ f ],        π_k ∝ e^{-u_k}

so ``e^{-W_{0:k}}`` reweights the slice-k configurations to the *equilibrium at slice k* — not to
the cold target.  Multiplying by the tempering-energy difference completes the journey:

    w̃_ik^C  =  exp[-W_{i,0:k}] · exp[-(u_C(x_ik) - u_k(x_ik))]                            (HS)

    E[ f(x_k) w̃^C ]  =  (Z_k/Z_0)(Z_C/Z_k) E_{π_C}[f]  =  (Z_C/Z_0) · E_{π_C}[ f ]

Each slice is therefore an independent, unbiased (self-normalised: consistent) estimator of the
cold ensemble, and slices may be combined.  Alignment matters and is checked in the tests:

* ``x_ik`` is the configuration reached at switching index ``k``;
* ``W_{i,0:k}`` is the work accumulated up to that same index;
* ``u_k(x_ik)`` is the *intermediate* Hamiltonian at that index (recorded as
  ``u_current_reduced``), not the cold one;
* ``u_C(x_ik)`` is the physical cold Hamiltonian (``u_cold_reduced``);
* no umbrella/restraint energy appears anywhere in a forward physical AIS HS weight.

The common wrong alternative — giving every frame of a trajectory the *final* Jarzynski weight
``e^{-W_{0:M}}`` — is provided as :func:`final_jarzynski_log_weights` **only** so tests can show
it is biased.  It is not an estimator; do not use it.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Optional, Sequence

import numpy as np
import pandas as pd

__all__ = [
    "hz_log_weights",
    "final_jarzynski_log_weights",
    "self_normalised_expectation",
    "hz_histogram",
    "hz_reconstruct_dataframe",
    "DEFAULT_S_MIN",
    "weighted_ess",
    "hs_sample_cloud",
    # ── multi-CV time-slice layer ───────────────────────────────────────────
    "KT_KJ_300K",
    "TimeSliceCloud",
    "cloud_from_hz_frame",
    "periodic_histogram_1d",
    "periodic_histogram_2d",
    "per_slice_pmf",
    "combine_slices",
    "final_landing_pmf",
    "trajectory_bootstrap",
    "compare_to_reference",
    "reference_pmf_from_trajectory",
    "wrap_angles",
]

KT_KJ_300K = 2.4943387854      # k_B T at 300 K in kJ/mol (R = 8.31446261815324e-3)


# ─────────────────────────────── the weights ─────────────────────────────────
def hz_log_weights(cumulative_reduced_work, u_current_reduced, u_cold_reduced) -> np.ndarray:
    """log w̃^C = −W_{0:k} − (u_C(x_k) − u_k(x_k)), all arguments in kT (reduced)."""
    w = np.asarray(cumulative_reduced_work, float)
    u_cur = np.asarray(u_current_reduced, float)
    u_cold = np.asarray(u_cold_reduced, float)
    if not (w.shape == u_cur.shape == u_cold.shape):
        raise ValueError(f"shape mismatch: W{w.shape} u_current{u_cur.shape} u_cold{u_cold.shape}")
    return -w - (u_cold - u_cur)


def final_jarzynski_log_weights(final_reduced_work, n_slices: int) -> np.ndarray:
    """WRONG-BY-CONSTRUCTION comparison estimator: the final work pinned on every frame.

    Present only so the test suite can demonstrate that it does **not** reproduce the cold
    ensemble at intermediate slices.  It ignores both the partial-path structure of the work and
    the tempering-energy correction.
    """
    wf = np.asarray(final_reduced_work, float)
    return np.repeat(-wf[:, None], int(n_slices), axis=1).ravel()


# ─────────────────────────────── reductions ──────────────────────────────────
def _normalised(logw: np.ndarray) -> np.ndarray:
    lw = np.asarray(logw, float)
    lw = lw - np.max(lw)
    w = np.exp(lw)
    tot = w.sum()
    return w / tot if tot > 0 else np.full_like(w, 1.0 / max(w.size, 1))


def self_normalised_expectation(values, logw) -> float:
    """⟨f⟩ under the self-normalised weights."""
    w = _normalised(logw)
    return float(np.sum(w * np.asarray(values, float)))


def weighted_ess(logw) -> float:
    """Kish effective sample size of a weight set (absolute, not a fraction)."""
    w = _normalised(logw)
    return float(1.0 / np.sum(w ** 2)) if w.size else 0.0


def hs_sample_cloud(hz, cv_cols, s_min: float = 0.7):
    """``(angles_rad, weights, shot_id)`` for a basin tree, from a multi-slice HS cloud.

    ``barrier_partition.hz_density`` does the same job but returns a 2-D (phi, psi) GRID, which a
    10-CV macrocycle cannot use and which has already summed away the per-shot weights that the
    cell-mass standard error needs. Each slice above ``s_min`` is reweighted to cold and normalised
    ON ITS OWN, then slices are combined weighted by their Kish ESS, so an ESS-starved slice near
    the hot end cannot dominate.

    The originating SHOT of every row is returned because rule 4's standard error must be clustered
    on it: one shot contributes one row per slice (~20), so a row-level error understates the
    uncertainty by that factor and admits a cell resting on a single trajectory.
    ``trajectory_id`` restarts at 0 each generation, so it is namespaced by generation here --
    without that, 20 generations of 100 shots collapse onto 100 ids.
    """
    cols = list(cv_cols)
    sc = "observation_id" if "observation_id" in hz.columns else "observation_index"
    sub = hz[hz["s"] >= float(s_min)]
    if sub.empty:
        raise ValueError(f"no HS rows above s_min={s_min}")
    gen = sub["generation"] if "generation" in sub.columns else pd.Series(0, index=sub.index)
    shot = gen.astype(str) + ":" + sub["trajectory_id"].astype(str)
    A, W, S = [], [], []
    for _, g in sub.groupby(sc):
        lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                            g["u_cold_reduced"])
        w = np.exp(lw - lw.max()); w = w / w.sum()
        A.append(np.radians(g[cols].to_numpy(float)))
        W.append(w * weighted_ess(lw))                 # ESS-weighted slice combination
        S.append(shot.loc[g.index].to_numpy())
    A = np.concatenate(A); W = np.concatenate(W); S = np.concatenate(S)
    return A, W / W.sum(), S


def hz_histogram(values, logw, bins) -> np.ndarray:
    """Self-normalised weighted histogram (a density estimate of the cold ensemble)."""
    w = _normalised(logw)
    h, _ = np.histogram(np.asarray(values, float), bins=bins, weights=w)
    tot = h.sum()
    return h / tot if tot > 0 else h


#: Below this REST2 scale an HS slice is, in effect, a single-step Zwanzig reweight across a
#: large tempering gap.  Measured on alanine (s_hot = 0.25, 5 ps switch, 256 trajectories):
#: per-slice ESS falls from 97/256 at s = 0.93 to 6.4/256 at s = 0.25, and including those hot
#: slices raises the log-PMF RMSE from 0.50 kT (cold-side slices only) to 2.78 kT (all 40).
#: Recording them is nearly free; *using* them is not.  See the report, §4.
DEFAULT_S_MIN = 0.7


def hz_reconstruct_dataframe(hz, bins, column: str = "phi",
                             combine: str = "ess_weighted",
                             s_min: Optional[float] = DEFAULT_S_MIN) -> dict:
    """Reconstruct a 1-D cold distribution from a discovery-mode ``hz_observations`` table.

    ``s_min`` drops slices whose REST2 scale is below the threshold *before* combining.  This is
    the single most important option: every slice is individually unbiased, but a slice at
    ``s = 0.25`` carries an importance weight spanning ~48 kT and its self-normalised density is
    dominated by a handful of configurations, which shows up as log-space noise in the combined
    PMF.  Pass ``s_min=None`` to use every recorded slice.

    ``combine``:

    * ``"ess_weighted"`` (default) — average the per-slice densities weighted by each slice's
      Kish ESS, so better-conditioned (colder) slices count for more.
    * ``"per_slice_mean"`` — plain average of the per-slice densities.
    * ``"pooled"`` — one global normalisation over all (trajectory, slice) rows.  Lower variance
      when slices are comparably informative, but one slice can swamp the estimate.

    Returns the density plus per-slice ESS diagnostics.
    """
    import pandas as pd

    if not isinstance(hz, pd.DataFrame):
        hz = pd.DataFrame(hz)
    need = {"cumulative_reduced_work", "u_current_reduced", "u_cold_reduced", column}
    missing = need - set(hz.columns)
    if missing:
        raise KeyError(f"hz table is missing required columns: {sorted(missing)}")
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"

    n_all = int(hz[slice_col].nunique())
    if s_min is not None and "s" in hz.columns:
        hz = hz[hz["s"] >= float(s_min)]
        if hz.empty:
            raise ValueError(f"s_min={s_min} removed every slice")

    bins = np.asarray(bins, float)
    per_slice, ess = [], {}
    for sid, g in hz.groupby(slice_col):
        lw = hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                            g["u_cold_reduced"])
        per_slice.append(hz_histogram(g[column], lw, bins))
        ess[int(sid)] = weighted_ess(lw)

    stack = np.vstack(per_slice) if per_slice else np.zeros((1, len(bins) - 1))
    if combine == "pooled":
        lw = hz_log_weights(hz["cumulative_reduced_work"], hz["u_current_reduced"],
                            hz["u_cold_reduced"])
        p = hz_histogram(hz[column], lw, bins)
    elif combine == "per_slice_mean":
        p = stack.mean(axis=0)
    elif combine == "ess_weighted":
        e = np.asarray([ess[int(sid)] for sid in sorted(ess)], float)
        p = ((stack * e[:, None]).sum(axis=0) / e.sum()) if e.sum() > 0 else stack.mean(axis=0)
    else:
        raise ValueError(f"unknown combine={combine!r}")
    tot = p.sum()
    p = p / tot if tot > 0 else p

    return dict(density=p, bins=bins, per_slice_density=stack,
                per_slice_ess=ess, n_slices=len(per_slice), n_slices_recorded=n_all,
                s_min=s_min, combine=combine,
                total_ess=float(sum(ess.values())))


# ═════════════════════════════════════════════════════════════════════════════
# Multi-CV time-slice layer
#
# Moved here from the former ``alanine_timeslice_reweighting`` module, which computed the same HS
# identity from the legacy per-interval CSV and was hard-wired to exactly two CVs called phi/psi
# (``ForwardSlices.phi``/``.psi``, ``periodic_histogram2d(phi, psi)``, and a reference builder that
# called ``mdtraj.compute_phi/psi`` -- the very call that finds nothing on a cyclic macrocycle).
# The prefix was therefore accurate, not merely untidy.
#
# WHAT "GENERAL" MEANS HERE. It does NOT mean an N-dimensional histogram: a 10-CV macrocycle would
# need 72^10 bins, and the estimator would be all zeros. The cloud carries every declared CV, and
# the PMF helpers take an EXPLICIT CV selection -- one CV for a marginal, two for a Ramachandran-
# style map. Everything else (slice combination, bootstrap, reference comparison) is
# dimension-agnostic. Per-cell masses for many CVs come from the basin-tree partition, not from a
# histogram.
# ═════════════════════════════════════════════════════════════════════════════
def wrap_angles(a):
    """Wrap to (-pi, pi]. Torsions only -- this layer has no non-periodic CV support."""
    return (np.asarray(a, float) + np.pi) % (2 * np.pi) - np.pi


@dataclass
class TimeSliceCloud:
    """HS-reweighted intermediate slices over an arbitrary number of periodic CVs.

    ``cvs`` is ``(N, n_cv)`` in RADIANS, column order matching ``cv_names`` -- which is the order
    declared in ``systems/<slug>/cv_definition.json``. Selecting a CV by NAME rather than by
    position is deliberate: a reordered definition then fails to resolve instead of silently
    plotting a different coordinate.
    """

    trajectory: np.ndarray        # (N,) trajectory id, unique across merged sources
    observation: np.ndarray       # (N,) slice index k
    s: np.ndarray                 # (N,) REST2 scale of the intermediate the frame was drawn under
    cvs: np.ndarray               # (N, n_cv) radians
    cv_names: tuple
    log_w_cold: np.ndarray        # (N,) log w~^C_ik, unnormalised, reduced
    # endpoint landings -- the final-Jarzynski baseline the slice construction must beat
    final_trajectory: np.ndarray = None
    final_cvs: np.ndarray = None
    final_logw: np.ndarray = None
    meta: dict = None

    def __len__(self) -> int:
        return int(len(self.log_w_cold))

    def index(self, name: str) -> int:
        if name not in self.cv_names:
            raise KeyError(f"CV {name!r} not in this cloud; have {list(self.cv_names)}")
        return list(self.cv_names).index(name)

    def cv(self, name: str) -> np.ndarray:
        return self.cvs[:, self.index(name)]

    def final_cv(self, name: str) -> np.ndarray:
        if self.final_cvs is None:
            raise ValueError("this cloud carries no endpoint landings")
        return self.final_cvs[:, self.index(name)]

    def take(self, idx, final_idx=None) -> "TimeSliceCloud":
        """Row subset, keeping the CV axis intact (used by the bootstrap)."""
        return replace(
            self, trajectory=self.trajectory[idx], observation=self.observation[idx],
            s=self.s[idx], cvs=self.cvs[idx], log_w_cold=self.log_w_cold[idx],
            final_trajectory=(None if self.final_trajectory is None or final_idx is None
                              else self.final_trajectory[final_idx]),
            final_cvs=(None if self.final_cvs is None or final_idx is None
                       else self.final_cvs[final_idx]),
            final_logw=(None if self.final_logw is None or final_idx is None
                        else self.final_logw[final_idx]))


def cloud_from_hz_frame(hz, cv_names: Optional[Sequence[str]] = None,
                        s_min: Optional[float] = DEFAULT_S_MIN,
                        summary=None) -> TimeSliceCloud:
    """Build a cloud from an ``hz_observations`` table (the chunked writer's parquet).

    ``cv_names`` selects and orders the CV columns; when omitted, every ``cv<i>_<name>`` column is
    used in index order, falling back to ``phi``/``psi`` for the dipeptide schema. Pass the names
    from the system's ``cv_definition`` to be explicit.

    ``summary`` is an optional ``trajectory_summary`` frame supplying the endpoint landings.
    """
    import pandas as pd  # noqa: PLC0415

    if not isinstance(hz, pd.DataFrame):
        hz = pd.DataFrame(hz)
    need = {"cumulative_reduced_work", "u_current_reduced", "u_cold_reduced"}
    missing = need - set(hz.columns)
    if missing:
        raise KeyError(f"hz table is missing required columns: {sorted(missing)}")

    if cv_names is None:
        cols = sorted([c for c in hz.columns if c.startswith("cv") and "_" in c],
                      key=lambda c: int(c.split("_", 1)[0][2:]))
        if not cols:
            cols = [c for c in ("phi", "psi") if c in hz.columns]
        if not cols:
            raise KeyError("no CV columns found; pass cv_names explicitly")
    else:
        cols = list(cv_names)
        missing = [c for c in cols if c not in hz.columns]
        if missing:
            raise KeyError(f"CV columns absent from the hz table: {missing}")

    if s_min is not None and "s" in hz.columns:
        hz = hz[hz["s"] >= float(s_min)]
        if hz.empty:
            raise ValueError(f"s_min={s_min} removed every slice")

    # hz_observations stores CVs in DEGREES; everything downstream of here is radians. Mixing the
    # two produced a plausible-looking assignment that summed to 1 with zero unassigned frames.
    cvs = wrap_angles(np.radians(hz[cols].to_numpy(float)))
    lw = hz_log_weights(hz["cumulative_reduced_work"], hz["u_current_reduced"],
                        hz["u_cold_reduced"])
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    traj_col = "trajectory_id" if "trajectory_id" in hz.columns else "trajectory_index"

    f_traj = f_cvs = f_lw = None
    if summary is not None:
        if not isinstance(summary, pd.DataFrame):
            summary = pd.DataFrame(summary)
        fcols = [c for c in cols if c in summary.columns]
        if len(fcols) == len(cols):
            f_cvs = wrap_angles(np.radians(summary[fcols].to_numpy(float)))
            f_traj = summary[traj_col].to_numpy(int) if traj_col in summary else \
                np.arange(len(summary))
            wcol = "final_reduced_work" if "final_reduced_work" in summary else "reduced_work"
            f_lw = -summary[wcol].to_numpy(float) if wcol in summary else None

    return TimeSliceCloud(
        trajectory=hz[traj_col].to_numpy(int), observation=hz[slice_col].to_numpy(int),
        s=(hz["s"].to_numpy(float) if "s" in hz.columns else np.full(len(hz), np.nan)),
        cvs=cvs, cv_names=tuple(cols), log_w_cold=np.asarray(lw, float),
        final_trajectory=f_traj, final_cvs=f_cvs, final_logw=f_lw,
        meta={"n_rows": int(len(hz)), "s_min": s_min, "cv_names": list(cols)})


# ────────────────────────────── periodic PMFs ─────────────────────────────────
def _normalised_linear_weights(log_weights, n):
    if log_weights is None:
        return np.ones(n) / max(n, 1)
    lw = np.asarray(log_weights, float)
    return np.exp(lw - (lw.max() if lw.size else 0.0)) / \
        max(np.exp(lw - (lw.max() if lw.size else 0.0)).sum(), 1e-300)


def periodic_histogram_1d(x, log_weights=None, n_bins: int = 72) -> dict:
    """Weighted 1-D histogram over the FULL period [-pi, pi)."""
    edges = np.linspace(-np.pi, np.pi, n_bins + 1)
    a = wrap_angles(x)
    w = _normalised_linear_weights(log_weights, len(a))
    P, _ = np.histogram(a, bins=edges, weights=w)
    tot = P.sum()
    P = P / tot if tot > 0 else P
    return dict(P=P, edges=edges, ess=float(weighted_ess(log_weights))
                if log_weights is not None else float(len(a)))


def periodic_histogram_2d(x, y, log_weights=None, n_bins: int = 72) -> dict:
    """Weighted 2-D histogram on the FULL period [-pi, pi)^2.

    The grid spans exactly one period and the edges are identified, so there is no Euclidean
    artefact at +/-pi. Weights arrive in log space and are normalised by log-sum-exp, so nothing
    overflows.
    """
    edges = np.linspace(-np.pi, np.pi, n_bins + 1)
    p, q = wrap_angles(x), wrap_angles(y)
    w = _normalised_linear_weights(log_weights, len(p))
    P, _, _ = np.histogram2d(p, q, bins=[edges, edges], weights=w)
    tot = P.sum()
    P = P / tot if tot > 0 else P
    return dict(P=P, edges=edges, ess=float(weighted_ess(log_weights))
                if log_weights is not None else float(len(p)))


def _pmf(cloud: TimeSliceCloud, cv_sel, log_w, n_bins: int, final: bool = False) -> dict:
    get = cloud.final_cv if final else cloud.cv
    if isinstance(cv_sel, str):
        return periodic_histogram_1d(get(cv_sel), log_w, n_bins)
    names = tuple(cv_sel)
    if len(names) == 1:
        return periodic_histogram_1d(get(names[0]), log_w, n_bins)
    if len(names) == 2:
        return periodic_histogram_2d(get(names[0]), get(names[1]), log_w, n_bins)
    raise ValueError(
        f"cv_sel selects {len(names)} CVs. A histogram PMF is supported for 1 or 2 only -- "
        f"{n_bins}^{len(names)} bins would be essentially all zeros. For many CVs use the "
        f"basin-tree partition (methods.nd_basin_tree) and report per-cell masses.")


def per_slice_pmf(cloud: TimeSliceCloud, cv_sel, n_bins: int = 72) -> dict:
    """One self-normalised cold PMF per slice index k, over the selected CV(s)."""
    out = {}
    for k in np.unique(cloud.observation):
        sel = cloud.observation == k
        sub = cloud.take(sel)
        out[int(k)] = _pmf(sub, cv_sel, sub.log_w_cold, n_bins)
        out[int(k)]["n"] = int(sel.sum())
        out[int(k)]["s"] = float(np.nanmedian(cloud.s[sel]))
    return out


def combine_slices(cloud: TimeSliceCloud, cv_sel, n_bins: int = 72,
                   mode: str = "slice_ess") -> dict:
    """Combine the per-slice cold PMFs.

    Each slice is already carried exactly to the cold state by the HS identity, so no
    self-consistent unfolding is needed -- the combination is a weighted average.

    * ``slice_ess`` (default): weight slice k by its own Kish ESS. Robust to one slice being
      dominated by a single trajectory.
    * ``pooled``: one global self-normalised estimate over all (i, k). Lower variance when the
      weights are well behaved, but a single huge weight can take over.
    """
    per = per_slice_pmf(cloud, cv_sel, n_bins)
    if not per:
        raise ValueError("cloud contains no slices")
    stack = np.array([v["P"] for v in per.values()])
    if mode == "pooled":
        P = _pmf(cloud, cv_sel, cloud.log_w_cold, n_bins)["P"]
    elif mode == "slice_ess":
        w = np.array([max(v["ess"], 0.0) for v in per.values()], float)
        w = w / w.sum() if w.sum() > 0 else np.ones(len(w)) / len(w)
        P = np.tensordot(w, stack, axes=(0, 0))
    else:
        raise ValueError(f"unknown mode {mode!r}; expected 'slice_ess' or 'pooled'")
    return dict(P=P, per_slice=per, mode=mode, n_slices=len(per),
                ess_per_slice={k: v["ess"] for k, v in per.items()})


def final_landing_pmf(cloud: TimeSliceCloud, cv_sel, n_bins: int = 72) -> dict:
    """Endpoint Jarzynski PMF -- the baseline the time-slice construction must beat."""
    if cloud.final_cvs is None:
        raise ValueError("this cloud carries no endpoint landings")
    return _pmf(cloud, cv_sel, cloud.final_logw, n_bins, final=True)


def trajectory_bootstrap(cloud: TimeSliceCloud, cv_sel, n_bins: int = 72, n_boot: int = 200,
                         mode: str = "slice_ess", seed: int = 70000) -> dict:
    """Resample COMPLETE trajectories (all their slices together) with replacement.

    Slices of one trajectory are not independent -- they are points on a single driven path -- so
    resampling rows would understate the uncertainty.
    """
    rng = np.random.default_rng(seed)
    trajs = np.unique(cloud.trajectory)
    by_t = {int(t): np.where(cloud.trajectory == t)[0] for t in trajs}
    has_final = cloud.final_cvs is not None and cloud.final_trajectory is not None
    by_ft = ({int(t): np.where(cloud.final_trajectory == t)[0] for t in trajs}
             if has_final else {})
    Ps, Pf = [], []
    for _ in range(n_boot):
        pick = rng.choice(trajs, size=len(trajs), replace=True)
        idx = np.concatenate([by_t[int(t)] for t in pick])
        fidx = (np.concatenate([by_ft[int(t)] for t in pick if by_ft.get(int(t), np.empty(0)).size])
                if has_final else None)
        sub = cloud.take(idx, fidx)
        Ps.append(combine_slices(sub, cv_sel, n_bins, mode)["P"])
        if has_final and fidx is not None and fidx.size:
            Pf.append(final_landing_pmf(sub, cv_sel, n_bins)["P"])
    Ps = np.asarray(Ps)
    out = dict(P_timeslice=Ps, sd_timeslice=Ps.std(axis=0, ddof=1),
               n_boot=int(n_boot), n_trajectories=int(len(trajs)))
    if Pf:
        Pf = np.asarray(Pf)
        out.update(P_final=Pf, sd_final=Pf.std(axis=0, ddof=1))
    return out


# ─────────────────────────── comparison to a reference ────────────────────────
def compare_to_reference(P: np.ndarray, P_ref: np.ndarray, p_min: float = 1e-4) -> dict:
    """PMF RMSE over bins above ``p_min`` in the reference, JS divergence, population MAE.

    The PMF residuals are mean-centred first: a PMF is defined only up to an additive constant,
    so an uncentred RMSE would report the arbitrary offset as error.
    """
    P = np.asarray(P, float)
    R = np.asarray(P_ref, float)
    if P.shape != R.shape:
        raise ValueError(f"shape mismatch: estimate {P.shape} vs reference {R.shape}")
    mask = R >= p_min
    with np.errstate(divide="ignore", invalid="ignore"):
        Fp = -np.log(np.where(P > 0, P, np.nan))
        Fr = -np.log(np.where(R > 0, R, np.nan))
    d = (Fp - Fr)[mask]
    d = d[np.isfinite(d)]
    d = d - d.mean() if d.size else d
    m = 0.5 * (P + R)
    with np.errstate(divide="ignore", invalid="ignore"):
        js = 0.5 * np.nansum(np.where(P > 0, P * np.log(P / m), 0.0)) \
           + 0.5 * np.nansum(np.where(R > 0, R * np.log(R / m), 0.0))
    return dict(pmf_rmse=float(np.sqrt(np.mean(d ** 2))) if d.size else float("nan"),
                pmf_max_abs=float(np.max(np.abs(d))) if d.size else float("nan"),
                n_bins_compared=int(d.size), js_divergence=float(js),
                population_mae=float(np.mean(np.abs(P - R))),
                covered_reference_mass=float(R[P > 0].sum()), p_min=p_min)


def reference_pmf_from_trajectory(traj, cv_definition, cv_sel, n_bins: int = 72,
                                  burn_in: int = 0, stride: int = 1) -> dict:
    """Unweighted cold reference PMF from an equilibrium trajectory, over the DECLARED CVs.

    Takes a ``CVDefinition`` rather than calling ``mdtraj.compute_phi/psi``: that call returns
    nothing on a cyclic sage/openff macrocycle, which is how an all-NaN CV cloud was once written.
    """
    from escort_ais.systems.cv_definition import assert_finite  # noqa: PLC0415

    ang = cv_definition.compute(traj)[burn_in::stride]      # (n_frames, n_cv), radians
    assert_finite(ang, cv_definition, where="reference trajectory")
    cloud = TimeSliceCloud(
        trajectory=np.zeros(len(ang), int), observation=np.zeros(len(ang), int),
        s=np.ones(len(ang)), cvs=wrap_angles(ang),
        cv_names=tuple(cv_definition.names), log_w_cold=np.zeros(len(ang)),
        meta={"n_frames": int(len(ang)), "burn_in": burn_in, "stride": stride})
    out = _pmf(cloud, cv_sel, None, n_bins)
    out["n_frames"] = int(len(ang))
    return out
