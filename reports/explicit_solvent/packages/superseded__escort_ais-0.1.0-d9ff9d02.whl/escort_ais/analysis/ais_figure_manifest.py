"""ais_figure_manifest.py — machine-readable index of the accelerated-AIS benchmark data (§15).

No figures are produced anywhere in this workflow.  This module writes
``reports/alanine/ais_performance/figure_data_manifest.json``, which states, for each figure a
reader might want, exactly which JSON file holds the numbers, which keys to read, and what the
axes should be.  A plotting pass (Codex or otherwise) needs nothing beyond this manifest and the
files it points at.
"""
from __future__ import annotations

import json
from pathlib import Path

__all__ = ["FIGURES", "build_manifest", "main"]

FIGURES = [
    dict(
        id="fig_workers_per_gpu",
        title="Throughput vs workers per GPU (no MPS)",
        source="benchmark_data/workers_per_gpu.json",
        x=dict(key="runs.<w>.workers_per_gpu", label="workers per GPU"),
        y=dict(key="runs.<w>.trajectories_per_gpu_hour", label="trajectories per GPU-hour"),
        annotate="runs.<w>.wall_clock_s",
        note="1 worker is optimal; 2/4/8 lose ~2.4x aggregate throughput without CUDA MPS.",
    ),
    dict(
        id="fig_gpu_sharing_probe",
        title="Per-process slowdown when N processes share one GPU",
        source="benchmark_data/gpu_sharing_probe.json",
        x=dict(key="rows[].n_processes", label="concurrent processes on one GPU"),
        y=dict(key="rows[].aggregate_traj_per_s_excl_startup", label="aggregate trajectories/s"),
        secondary=dict(key="rows[].ms_per_trajectory", label="ms per trajectory (each)"),
        note="Pure-OpenMM probe, no I/O, idle GPU.",
    ),
    dict(
        id="fig_hz_per_slice_ess",
        title="Per-slice ESS and standalone PMF error vs REST2 scale",
        source="benchmark_data/hz_slice_range_study.json",
        x=dict(key="per_slice.slices[].s", label="REST2 scale s"),
        y=dict(key="per_slice.slices[].ess", label="Kish ESS (of 256 trajectories)"),
        secondary=dict(key="per_slice.slices[].pmf_rmse_kT", label="slice PMF RMSE (kT)"),
        note="The core §4 result: hot slices are individually unbiased but ESS-starved.",
    ),
    dict(
        id="fig_hz_s_range_sweep",
        title="Reconstruction error vs cold-side cut s_min",
        source="benchmark_data/hz_slice_range_study.json",
        x=dict(key="sweep.rows.<s_min>.s_min", label="s_min (None = all slices)"),
        y=dict(key="sweep.rows.<s_min>.pmf_rmse_kT", label="HS PMF RMSE (kT)"),
        errorbar="sweep.rows.<s_min>.pmf_rmse_boot_std",
        secondary=dict(key="sweep.rows.<s_min>.population_mae", label="population MAE"),
        note="log-PMF error minimises at s_min≈0.8; linear population error prefers all slices.",
    ),
    dict(
        id="fig_hz_slice_count",
        title="Paired L-sweep (L slices out of one L=40 run)",
        source="benchmark_data/hz_slice_count_study.json",
        x=dict(key="rows.<L>.L", label="number of HS slices L"),
        y=dict(key="rows.<L>.pmf_rmse_kT", label="HS PMF RMSE (kT)"),
        errorbar="rows.<L>.pmf_rmse_boot_std",
        secondary=dict(key="rows.<L>.population_mae", label="population MAE"),
        note="Non-monotonic: see fig_hz_s_range_sweep for the explanation.",
    ),
    dict(
        id="fig_hz_overhead",
        title="Wall-clock and file-size cost of L observations",
        source="benchmark_data/hz_slice_count_study.json",
        x=dict(key="overhead.<L>.k_ais", label="number of HS slices L"),
        y=dict(key="overhead.<L>.s_per_trajectory", label="seconds per trajectory"),
        secondary=dict(key="overhead.<L>.hz_bytes_per_trajectory", label="bytes per trajectory"),
    ),
    dict(
        id="fig_duration_bias_variance",
        title="MSE = bias^2 + variance vs switch duration",
        source="benchmark_data/switch_duration_study.json",
        x=dict(key="rows.<ps>.switch_duration_ps", label="switch duration (ps)"),
        y=dict(key="rows.<ps>.population_decomposition.bias_squared", label="bias^2"),
        stack=dict(key="rows.<ps>.population_decomposition.variance", label="variance"),
        secondary=dict(key="rows.<ps>.hz_pmf_rmse_mean", label="HS PMF RMSE (kT)"),
        note="Independent trajectory batches; bias measured against the converged REMD PMF.",
    ),
    dict(
        id="fig_duration_efficiency",
        title="Precision per GPU-hour vs switch duration",
        source="benchmark_data/switch_duration_study.json",
        x=dict(key="rows.<ps>.switch_duration_ps", label="switch duration (ps)"),
        y=dict(key="length_recommendation.efficiency_by_duration.<ps>",
               label="1 / (Var(dF) x GPU-hour)"),
        secondary=dict(key="rows.<ps>.je_ess_fraction_mean", label="Jarzynski ESS fraction"),
    ),
    dict(
        id="fig_freq_ais",
        title="Freq_AIS 1 vs 10, matched two ways",
        source="benchmark_data/freq_ais.json",
        x=dict(key="runs.<label>", label="matched comparison"),
        y=dict(key="runs.<label>.efficiency_E", label="1 / (MSE(dF) x GPU-hour)"),
        secondary=dict(key="runs.<label>.ess_fraction", label="ESS fraction"),
    ),
    dict(
        id="fig_stage_timing",
        title="Where the wall clock goes (production vs discovery)",
        source="benchmark_data/final_benchmark.json",
        x=dict(key="<leg>.stage_fractions.percent", label="stage"),
        y=dict(key="<leg>.stage_fractions.percent.<stage>", label="% of worker time"),
        note="legs: discovery, production.",
    ),
    dict(
        id="fig_final_throughput",
        title="Final benchmark: accelerated vs legacy driver",
        source="benchmark_data/final_benchmark.json",
        x=dict(key="<leg>", label="workflow"),
        y=dict(key="<leg>.launch.trajectories_per_gpu_hour",
               label="trajectories per GPU-hour"),
        reference=dict(key="legacy.trajectories_per_gpu_hour", label="legacy per-switch driver"),
    ),
    dict(
        id="fig_vm_clustering_1ps",
        title="vM clustering of the 1 ps cold-weighted cloud + disjoint flat cores",
        source="benchmark_data/vm_clustering_1ps.json",
        rendered="vm_clustering_1ps.png",
        x=dict(key="<model>_K<K>.mu_deg[][0]", label="phi (deg)"),
        y=dict(key="<model>_K<K>.mu_deg[][1]", label="psi (deg)"),
        size=dict(key="<model>_K<K>.weights[]", label="mixture weight"),
        model_selection=dict(bic="<model>_K<K>.bic", max_overlap="<model>_K<K>.max_overlap",
                             min_pair_sep="<model>_K<K>.min_pair_sep"),
        note="K=5 adopted: BIC keeps falling to K=7-8 but centre separation collapses.",
    ),
    dict(
        id="fig_disjoint_cores",
        title="Non-overlapping flat-bottom cores and their importance-sampled ensembles",
        source="benchmark_data/disjoint_flatbottom_design_1ps.json",
        x=dict(key="windows[].phi_ref_deg[0]", label="phi (deg)"),
        y=dict(key="windows[].phi_ref_deg[1]", label="psi (deg)"),
        radius=dict(key="windows[].hw_lin", label="flat-core radius h (sqrt(D) units)"),
        verification=dict(min_slack="verification.min_pair_slack",
                          max_cover="verification.max_windows_covering_a_point",
                          torus_fraction="verification.torus_fraction_inside_some_core"),
        secondary=dict(key="ensembles.<m>.pool_ess", label="importance-sampling ESS"),
    ),
    dict(
        id="fig_switch_1ps_vs_5ps",
        title="1 ps vs 5 ps switching at matched GPU cost",
        source="benchmark_data/switch_1ps_vs_5ps.json",
        x=dict(key="rows.<run>.switch_duration_ps", label="switch duration (ps)"),
        y=dict(key="rows.<run>.ess_per_gpu_hour", label="Jarzynski ESS per GPU-hour"),
        secondary=dict(key="rows.<run>.hz_pmf_rmse_kT", label="HS PMF RMSE (kT)"),
        note="Opposite rankings: 1 ps wins on dF ESS/GPU-h, 5 ps wins on PMF per GPU-h.",
    ),
    dict(
        id="fig_barrier_partition",
        title="Barrier-aligned rectangular partition (per mode)",
        source="barrier_partition_alanine-3state.json",
        rendered="barrier_partition_<mode>.png",
        arrays="barrier_partition_<mode>_arrays.npz",
        x=dict(key="basins[].phi_interval.lower_deg", label="phi (deg)"),
        y=dict(key="basins[].psi_interval.lower_deg", label="psi (deg)"),
        rectangle=dict(width="basins[].phi_interval.width", height="basins[].psi_interval.width"),
        cuts=dict(key="cuts[].value_deg", parent="cuts[].parent_region",
                  barrier="cuts[].barrier_height_kT", stability="cuts[].bootstrap_sd_deg"),
        note=("modes: alanine-2state, alanine-3state, recursive-barrier-K2..K5. A conditional "
              "cut must be drawn only across its parent region (cuts[].parent_extent). "
              "cuts[].bootstrap_sd_deg is the LOOSER of the two boundaries of a pair cut; the "
              "individual ones are boundary1_sd_deg / boundary2_sd_deg in bootstrap.cuts[]."),
    ),
    dict(
        id="fig_basin_tree",
        title="Basin tree: recursive splitting with a free-energy stopping criterion",
        source="basin_tree.json",
        rendered="basin_tree_partition.png",
        arrays="basin_tree_arrays.npz",
        x=dict(key="basins[].phi_interval.lower_deg", label="phi (deg)"),
        y=dict(key="basins[].psi_interval.lower_deg", label="psi (deg)"),
        tree=dict(key="tree.<node_id>", split="tree.<node_id>.split.barrier_height_kT",
                  stop="tree.<node_id>.stop_reason", leaf="tree.<node_id>.is_leaf"),
        stability=dict(key="bootstrap.n_cuts_histogram",
                       label="number of cuts found per bootstrap replicate"),
        note=("stop_barrier_kT is the recursion threshold; barrier_cap_kT is null (no capping). "
              "Every wall is a recorded valley, so tree.<node>.split carries its provenance."),
    ),
    dict(
        id="fig_wall_stiffness_scan",
        title="Proposal leakage and overlap vs wall stiffness k",
        source="benchmark_data/wall_stiffness_scan.json",
        x=dict(key="rows[].k", label="k (kT/rad^2)"),
        y=dict(key="rows[].worst_leak", label="worst-basin proposal leakage"),
        secondary=dict(key="rows[].max_overlap", label="max pairwise proposal overlap"),
        note="Basis for the fixed k = 100 decision (report 11f.12); log-log axes.",
    ),
    dict(
        id="fig_barrier_ladder",
        title="Barrier ladder and the K produced by each stopping threshold",
        source="benchmark_data/barrier_ladder.json",
        x=dict(key="ladder[].n_basins", label="K after the split"),
        y=dict(key="ladder[].barrier_height_kT", label="barrier of that split (kT)"),
        secondary=dict(key="k_vs_threshold[].n_basins", label="K at a given stop_barrier_kT"),
        note=("ladder_is_monotone is FALSE for alanine: step 7 (1.66 kT) exceeds steps 4-6, so a "
              "threshold cannot be converted to K by walking the ladder -- read k_vs_threshold."),
    ),
    dict(
        id="fig_partition_comparison",
        title="Partition comparison: masses, barriers, stability, overlap",
        source="barrier_partition_comparison.json",
        x=dict(key="<mode>", label="partition"),
        y=dict(key="<mode>.masses[]", label="basin cold mass"),
        secondary=dict(key="<mode>.cuts[].bootstrap_sd_deg", label="cut bootstrap SD (deg)"),
        tertiary=dict(key="<mode>.max_overlap", label="max proposal overlap"),
    ),
    dict(
        id="fig_vm_vs_rectangular",
        title="von Mises components (diagnostic) vs the rectangular partition",
        source="benchmark_data/vm_vs_rectangular_diagnostic.json",
        x=dict(key="mu_deg[][0]", label="phi (deg)"),
        y=dict(key="mu_deg[][1]", label="psi (deg)"),
        overlay=dict(key="responsibility_boundaries_phi[].phi_deg",
                     label="mixture responsibility crossings in phi"),
        note="4 of 5 vM modes fall inside B0; none inside B2. Mixtures are diagnostics only.",
    ),
    dict(
        id="fig_cold_context_cost",
        title="Persistent cold context vs switch-and-restore, per observation",
        source="benchmark_data/cold_context.json",
        x=dict(key="<route>", label="route"),
        y=dict(key="persistent_total_ms|switch_restore_total_ms", label="ms per observation"),
        note="Correctness device, not a speed-up: ~19 % slower for alanine.",
    ),
]


def build_manifest(root: Path) -> dict:
    root = Path(root)
    figs = []
    for f in FIGURES:
        p = root / f["source"]
        figs.append(dict(**f, available=p.exists(),
                         bytes=(p.stat().st_size if p.exists() else 0)))
    return dict(
        generated_for="reports/alanine/ais_performance",
        note=("No figures are produced by this workflow (report §15). Each entry names the JSON "
              "file, the keys to read and the intended axes. '<x>' in a key is a dict key to "
              "iterate over; '[]' is a list to iterate over."),
        raw_data_dir="benchmark_data/",
        figures=figs,
        missing=[f["id"] for f in figs if not f["available"]])


def main(argv=None) -> None:
    from escort_ais.common.paths import project_root
    root = project_root() / "reports/alanine/ais_performance"
    root.mkdir(parents=True, exist_ok=True)
    man = build_manifest(root)
    p = root / "figure_data_manifest.json"
    p.write_text(json.dumps(man, indent=2))
    print(f"wrote {p}  ({len(man['figures'])} figures, missing: {man['missing']})")


if __name__ == "__main__":
    main()
