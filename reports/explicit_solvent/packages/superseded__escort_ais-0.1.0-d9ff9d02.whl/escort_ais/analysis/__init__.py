"""escort_ais.analysis.analysis subpackage."""
