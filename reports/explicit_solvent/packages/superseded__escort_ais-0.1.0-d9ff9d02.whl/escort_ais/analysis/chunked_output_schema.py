"""chunked_output_schema.py — THE stable data contract for accelerated-AIS output (report §13).

One schema, validated in one place, so no downstream module has to guess — and in particular so
nothing has to infer a proposal id from a directory name.

Discovery (``merged/hz_observations.parquet``), one row per (trajectory, observation):

    trajectory_id, observation_id, s, sqrt_s, lambda, cumulative_reduced_work,
    u_current_reduced, u_cold_reduced, phi, psi, final_coordinate_reference

Production / any leg (``merged/trajectory_summary.parquet``), one row per trajectory:

    trajectory_id, leg, reduced_work, final_phi, final_psi, final_coordinate_reference

and, for reverse legs seeded from umbrella proposals, additionally:

    proposal_id, source_window_id, reverse_work, starting_phi, starting_psi,
    starting_coordinate_reference

``phi``/``psi`` are DEGREES in the files (the analysis helpers convert to radians), energies and
works are REDUCED (kT), and the work-direction convention is unchanged: forward = hot→cold with
``W = −ln w``.

:func:`to_time_slice_cloud` bridges the Parquet output into the ``TimeSliceCloud`` structure in
:mod:`escort_ais.analysis.hz_reconstruction`, so accelerated runs feed the time-slice PMF, slice
combination and bootstrap machinery directly. It carries an arbitrary number of declared CVs, not
just the dipeptide's (phi, psi).
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Sequence

import numpy as np

__all__ = [
    "DISCOVERY_COLUMNS",
    "TRAJECTORY_COLUMNS",
    "REVERSE_COLUMNS",
    "SchemaError",
    "validate_discovery",
    "validate_trajectory_summary",
    "load_discovery",
    "load_trajectory_summary",
    "to_time_slice_cloud",
    "reverse_work_table",
    "describe_run",
]

DISCOVERY_COLUMNS = ("trajectory_id", "observation_id", "s", "sqrt_s", "lambda",
                     "cumulative_reduced_work", "u_current_reduced", "u_cold_reduced",
                     "phi", "psi", "final_coordinate_reference")

TRAJECTORY_COLUMNS = ("trajectory_id", "leg", "reduced_work", "final_phi", "final_psi",
                      "final_coordinate_reference")

REVERSE_COLUMNS = ("proposal_id", "source_window_id", "reverse_work",
                   "starting_phi", "starting_psi", "starting_coordinate_reference")


class SchemaError(ValueError):
    """The output does not satisfy the documented contract."""


def _require(df, columns, what: str):
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise SchemaError(f"{what} is missing required column(s) {missing}; "
                          f"present: {sorted(df.columns)}")


def validate_discovery(df) -> dict:
    """Structural + physical validation of an ``hz_observations`` table."""
    _require(df, DISCOVERY_COLUMNS, "discovery hz_observations")
    if len(df) == 0:
        raise SchemaError("discovery table is empty")
    s = df["s"].to_numpy(float)
    if not np.all((s > 0) & (s <= 1.0 + 1e-12)):
        raise SchemaError("REST2 scale s outside (0, 1]")
    if not np.allclose(df["sqrt_s"].to_numpy(float), np.sqrt(s), atol=1e-9):
        raise SchemaError("sqrt_s is not sqrt(s)")
    lam = df["lambda"].to_numpy(float)
    if not np.all((lam >= -1e-12) & (lam <= 1 + 1e-12)):
        raise SchemaError("lambda outside [0, 1]")
    for c in ("cumulative_reduced_work", "u_current_reduced", "u_cold_reduced", "phi", "psi"):
        if not np.all(np.isfinite(df[c].to_numpy(float))):
            raise SchemaError(f"non-finite values in {c}")
    for c in ("phi", "psi"):
        v = df[c].to_numpy(float)
        if np.nanmax(np.abs(v)) > 180.0 + 1e-6:
            raise SchemaError(f"{c} is not in degrees within [-180, 180]")
    n_per = df.groupby("trajectory_id")["observation_id"].nunique()
    return dict(n_rows=int(len(df)), n_trajectories=int(df["trajectory_id"].nunique()),
                observations_per_trajectory=dict(min=int(n_per.min()), max=int(n_per.max())),
                s_range=(float(s.min()), float(s.max())))


def validate_trajectory_summary(df, leg: Optional[str] = None) -> dict:
    """Structural validation of a ``trajectory_summary`` table; reverse legs need more."""
    _require(df, TRAJECTORY_COLUMNS, "trajectory_summary")
    if len(df) == 0:
        raise SchemaError("trajectory summary is empty")
    if df["trajectory_id"].duplicated().any():
        dup = df.loc[df["trajectory_id"].duplicated(), "trajectory_id"].unique()[:10]
        raise SchemaError(f"duplicate trajectory_id values: {list(dup)}")
    if not np.all(np.isfinite(df["reduced_work"].to_numpy(float))):
        raise SchemaError("non-finite reduced_work")
    legs = set(df["leg"].dropna().unique())
    if leg is not None and legs != {leg}:
        raise SchemaError(f"expected leg={leg!r}, found {sorted(legs)}")
    out = dict(n_trajectories=int(len(df)), legs=sorted(legs),
               work_mean=float(df["reduced_work"].mean()),
               work_std=float(df["reduced_work"].std(ddof=1)) if len(df) > 1 else float("nan"))
    if legs == {"reverse"}:
        _require(df, REVERSE_COLUMNS, "reverse trajectory_summary")
        if df["proposal_id"].isna().all():
            raise SchemaError("reverse leg has no proposal_id — downstream code must not have "
                              "to infer it from directory names (report §13)")
        out["proposals"] = sorted(str(x) for x in df["proposal_id"].dropna().unique())
        out["source_windows"] = sorted(str(x) for x in df["source_window_id"].dropna().unique())
    return out


# ─────────────────────────────── loading ─────────────────────────────────────
def _merged(run_dir: Path, name: str) -> Path:
    run_dir = Path(run_dir)
    p = run_dir / "merged" / name
    return p if p.exists() else run_dir / name


def load_discovery(run_dir: Path):
    import pandas as pd
    p = _merged(run_dir, "hz_observations.parquet")
    if not p.exists():
        raise FileNotFoundError(f"no hz_observations.parquet under {run_dir} "
                                "(was this run in production mode?)")
    df = pd.read_parquet(p)
    validate_discovery(df)
    return df


def load_trajectory_summary(run_dir: Path):
    import pandas as pd
    p = _merged(run_dir, "trajectory_summary.parquet")
    if not p.exists():
        raise FileNotFoundError(f"no trajectory_summary.parquet under {run_dir}")
    df = pd.read_parquet(p)
    validate_trajectory_summary(df)
    return df


def reverse_work_table(run_dir: Path):
    """Reverse-leg works with their proposal provenance attached (report §13)."""
    df = load_trajectory_summary(run_dir)
    rev = df[df["leg"] == "reverse"]
    if rev.empty:
        raise SchemaError(f"{run_dir} contains no reverse-leg trajectories")
    validate_trajectory_summary(rev, leg="reverse")
    return rev[list(TRAJECTORY_COLUMNS) + list(REVERSE_COLUMNS)]


def to_time_slice_cloud(run_dirs: Sequence[Path], cv_names: Optional[Sequence[str]] = None,
                        kt_kj: float = 0.00831446261815324 * 300.0):
    """Bridge accelerated discovery output into a
    :class:`~escort_ais.analysis.hz_reconstruction.TimeSliceCloud`.

    The cold log-weight is the same HS quantity the legacy CSV path built
    (``-W_{0:k} - (u_C - u_k)``), so per-slice PMFs, slice combination, final-landing PMFs and the
    trajectory bootstrap all work unchanged on accelerated runs.

    ``cv_names`` selects and orders the CV columns; when omitted, the ``cv<i>_<name>`` columns are
    used in index order, falling back to ``phi``/``psi`` for the dipeptide schema. Trajectory ids
    are offset per run directory so several runs can be merged without collision.
    """
    from escort_ais.analysis.hz_reconstruction import (TimeSliceCloud, hz_log_weights,
                                                       wrap_angles)

    traj, interval, s_old, cvs, lw = [], [], [], [], []
    f_traj, f_cvs, f_lw = [], [], []
    metas = []
    offset = 0
    names: Optional[list] = None
    for d in run_dirs:
        d = Path(d)
        hz = load_discovery(d)
        summ = load_trajectory_summary(d)
        metas.append(dict(dir=str(d), n_observations=int(len(hz)),
                          n_trajectories=int(len(summ))))

        if names is None:
            if cv_names is not None:
                names = list(cv_names)
            else:
                names = sorted([c for c in hz.columns if c.startswith("cv") and "_" in c],
                               key=lambda c: int(c.split("_", 1)[0][2:]))
                if not names:
                    names = [c for c in ("phi", "psi") if c in hz.columns]
            if not names:
                raise SchemaError(f"{d}: no CV columns found; pass cv_names explicitly")
        missing = [c for c in names if c not in hz.columns]
        if missing:
            raise SchemaError(f"{d}: CV columns absent from hz_observations: {missing}")

        traj.append(hz["trajectory_id"].to_numpy(int) + offset)
        interval.append(hz[("ais_interval_index" if "ais_interval_index" in hz.columns
                            else "observation_id")].to_numpy(int))
        s_old.append(hz["s"].to_numpy(float))
        cvs.append(wrap_angles(np.radians(hz[names].to_numpy(float))))
        lw.append(np.asarray(hz_log_weights(hz["cumulative_reduced_work"],
                                            hz["u_current_reduced"], hz["u_cold_reduced"]), float))

        # Endpoint landings use the summary's final_* columns for the dipeptide schema; a generic
        # CV set reuses the same names when the writer recorded them.
        fcols = [("final_" + c if "final_" + c in summ.columns else c) for c in names]
        if all(c in summ.columns for c in fcols):
            f_traj.append(summ["trajectory_id"].to_numpy(int) + offset)
            f_cvs.append(wrap_angles(np.radians(summ[fcols].to_numpy(float))))
            f_lw.append(-summ["reduced_work"].to_numpy(float))       # log w = -W (reduced)
        offset += int(summ["trajectory_id"].max()) + 1

    has_final = len(f_traj) == len(list(run_dirs)) and bool(f_traj)
    return TimeSliceCloud(
        trajectory=np.concatenate(traj), observation=np.concatenate(interval),
        s=np.concatenate(s_old), cvs=np.concatenate(cvs), cv_names=tuple(names),
        log_w_cold=np.concatenate(lw),
        final_trajectory=np.concatenate(f_traj) if has_final else None,
        final_cvs=np.concatenate(f_cvs) if has_final else None,
        final_logw=np.concatenate(f_lw) if has_final else None,
        meta=dict(runs=metas, kt_kj=kt_kj, source="chunked_neq_ais", cv_names=list(names)))


def describe_run(run_dir: Path) -> dict:
    """One-call summary used by the tests and by the final report."""
    import json as _json
    run_dir = Path(run_dir)
    out = dict(run_dir=str(run_dir))
    try:
        out["trajectory_summary"] = validate_trajectory_summary(load_trajectory_summary(run_dir))
    except Exception as exc:
        out["trajectory_summary"] = dict(error=str(exc))
    try:
        out["discovery"] = validate_discovery(load_discovery(run_dir))
    except FileNotFoundError:
        out["discovery"] = dict(absent="production run: no HS observations by design")
    except Exception as exc:
        out["discovery"] = dict(error=str(exc))
    for f in ("run_manifest.json", "launch_metrics.json"):
        p = run_dir / f
        if p.exists():
            out[f.replace(".json", "")] = _json.loads(p.read_text())
    return out
