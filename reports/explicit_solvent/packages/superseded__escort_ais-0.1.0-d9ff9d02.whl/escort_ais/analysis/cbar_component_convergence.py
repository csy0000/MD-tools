"""Convergence of EACH TERM of the conditional-BAR identity, against cost, with REMD alongside.

The total-free-energy figure shows a residual; this shows which term is producing it and whether
that term is converging, drifting, or merely noisy. Three rows::

    matched   (f^C_n - f^H_n) - (f^C_m - f^H_m)     per-cell doubly-conditioned BAR
    hot        f^H_n - f^H_m                        population ratio in the hot ensemble
    total      f^C_n - f^C_m  =  matched + hot      what the campaign reports

REMD IS PLOTTED FOR EVERY TERM, not just the total, because the ladder can supply each one
independently and at a directly comparable cost:

* total -- running counting on the s = 1 rung;
* hot   -- running counting on the s = 0.25 rung, the SAME quantity the AIS hot pool estimates;
* matched -- their difference, term by term.

That makes the hot row a like-for-like race between two independent estimates of one quantity: the
AIS hot walker (an independent 500 ns chain) and the REMD s=0.25 rung. Since the freeze gate stopped
guarding hot-ensemble convergence in 2026-08-04, this row is the only routine check on it.

COST AXIS. Both methods are charged as in the total figure: AIS pays PREP plus per-generation
walkers and legs, REMD pays every replica. REMD's own curve is charged its full ladder because all
six replicas must run for the s=1 rung to be an equilibrium sample -- charging only the rung being
counted would make it look six times cheaper than it is.

Reference lines are the all-replica MBAR values for the total and the s=0.25 rung for the hot term;
the matched reference is their difference. All comparisons are gauge-free (differences between
cells only), since the absolute matched term carries the AIS gauge.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from escort_ais.analysis.cbar_term_decomposition import (load_partition, reference_angles)
from escort_ais.common.paths import project_root

ROOT = project_root()


def running_component(angles, assign, n_cells, n_points=60):
    """Running -ln(pi_m/pi_0) from counting a single rung, at log-spaced prefixes."""
    lab = assign(angles)
    n = len(lab)
    idx = np.unique(np.geomspace(max(n // 500, 200), n, n_points).astype(int))
    out = np.full((len(idx), n_cells - 1), np.nan)
    for j, k in enumerate(idx):
        pi = np.array([(lab[:k] == i).sum() for i in range(n_cells)], float)
        if (pi > 0).all():
            out[j] = -np.log(pi[1:] / pi[0])
    return idx, out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--decomposition", type=Path, required=True)
    ap.add_argument("--reference", type=Path, required=True)
    ap.add_argument("--partition", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True, help="directory; written beside the total")
    ap.add_argument("--t-gen", type=float, default=5.0)
    ap.add_argument("--n-box", type=int, default=3)
    ap.add_argument("--n-fwd", type=int, default=100)
    ap.add_argument("--n-rev", type=int, default=300)
    ap.add_argument("--t-ais", type=float, default=0.005)
    ap.add_argument("--prep-series-ns", type=float, default=0.0)
    ap.add_argument("--n-replicas", type=int, default=6)
    ap.add_argument("--xscale", choices=("linear", "log"), default="linear",
                    help="cost axis scale. Linear puts both methods on a common absolute footing, "
                         "which is what makes REMD's 6-replica ladder visibly more expensive; log "
                         "spreads the early AIS generations out but compresses that difference.")
    ap.add_argument("--frame-ps", type=float, default=None,
                    help="spacing of the STORED reference frames. Older reference files (alanine "
                         "campaign_v1) record `stride` and `burn_in` but no `frame_ps`, and the "
                         "stored spacing is the raw spacing TIMES the stride. Required for those; "
                         "guessing it would silently rescale the entire cost axis.")
    a = ap.parse_args(argv)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    doc = json.loads(a.decomposition.read_text())
    labels, assign = load_partition(a.partition)
    ref = doc["reference"]
    cells = labels[1:]
    n_cells = len(labels)

    per_gen_ser = a.t_gen * (1 + a.n_box) + (a.n_fwd + a.n_rev) * a.t_ais
    g = np.array([r["generation"] for r in doc["stratified"]], float)
    x_ais = a.prep_series_ns + g * per_gen_ser
    matched = np.array([r["matched"] for r in doc["stratified"]], float)
    hot = np.array([r["hot"] for r in doc["stratified"]], float)
    total = np.array([r["f_rel"] for r in doc["stratified"]], float)

    gn = np.array([r["generation"] for r in doc["normal"]], float)
    x_nrm = a.prep_series_ns + gn * per_gen_ser
    tot_nrm = np.array([r["f_rel"] for r in doc["normal"]], float)

    # --- REMD, term by term, from its own rungs -------------------------------------------
    z = np.load(a.reference)
    ang, origin = reference_angles(z), z["origin"]
    if a.frame_ps is not None:
        frame_ps = a.frame_ps
    elif "frame_ps" in z.files:
        frame_ps = float(z["frame_ps"])
    else:
        raise SystemExit(f"{a.reference} has no `frame_ps` (keys: {z.files}); pass --frame-ps "
                         f"with the spacing of the STORED frames, i.e. raw spacing x stride")
    rung = int(ref["hot_rung"])
    i_cold, e_cold = running_component(ang[origin == 0], assign, n_cells)
    i_hot, e_hot = running_component(ang[origin == rung], assign, n_cells)
    # every replica must run for either rung to be an equilibrium sample
    x_cold = i_cold * frame_ps / 1000.0 * a.n_replicas
    x_hot = i_hot * frame_ps / 1000.0 * a.n_replicas
    k = min(len(i_cold), len(i_hot))
    x_mat, e_mat = x_cold[:k], e_cold[:k] - e_hot[:k]

    rows = [("matched  $(f^C_n-f^H_n)-(f^C_m-f^H_m)$", matched, None,
             (x_mat, e_mat), np.array(ref["matched_term"], float)),
            ("hot  $f^H_n-f^H_m$", hot, None,
             (x_hot, e_hot), np.array(ref["hot_term"], float)),
            ("total  $f^C_n-f^C_m$", total, (x_nrm, tot_nrm),
             (x_cold, e_cold), np.array(ref["f_rel"], float))]

    fig, axes = plt.subplots(3, len(cells), figsize=(5.6 * len(cells) + 1.0, 10.4),
                             sharex=True, squeeze=False)
    for r, (title, ais, nrm, (xr, er), refv) in enumerate(rows):
        for c, lab in enumerate(cells):
            ax = axes[r][c]
            ax.plot(xr, er[:, c], color="#c0392b", lw=1.7, label="REST2-REMD counting")
            if nrm is not None:
                ax.plot(nrm[0], nrm[1][:, c], color="#1f77b4", lw=1.8, label="conditional BAR")
            ax.plot(x_ais, ais[:, c], color="#2ca02c", lw=1.8, label="traceback-stratified")
            ax.axhline(refv[c], color="#111111", lw=1.3, ls="--",
                       label="all-replica MBAR" if r == 2 else "REMD rung / MBAR")
            ax.set_ylabel(f"{title}\n/ $k_BT$" if c == 0 else "")
            if r == 0:
                ax.set_title(f"{lab} vs {labels[0]}", fontsize=10)
            if r == 2:
                ax.set_xlabel("series time / ns  (total simulated)")
            if r == 0 and c == 0:
                ax.legend(fontsize=7.5, loc="best")
            ax.set_xscale(a.xscale)
    fig.suptitle("Per-term convergence. The hot row is two independent estimates of the SAME "
                 "quantity:\nthe AIS hot walker and the REMD $s{=}0.25$ rung.", fontsize=10.5)
    fig.tight_layout()
    a.out.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(a.out / f"component_convergence.{ext}", dpi=170)

    summary = dict(
        cells=cells, reference=dict(matched=ref["matched_term"], hot=ref["hot_term"],
                                    total=ref["f_rel"]),
        final=dict(generation=int(g[-1]), series_ns=float(x_ais[-1]),
                   matched=matched[-1].tolist(), hot=hot[-1].tolist(), total=total[-1].tolist(),
                   matched_err=(matched[-1] - np.array(ref["matched_term"])).tolist(),
                   hot_err=(hot[-1] - np.array(ref["hot_term"])).tolist(),
                   total_err=(total[-1] - np.array(ref["f_rel"])).tolist()),
        remd_final=dict(series_ns=float(x_cold[-1]), total=e_cold[-1].tolist(),
                        hot=e_hot[-1].tolist()))
    (a.out / "component_convergence.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"wrote {a.out}/component_convergence.{{png,pdf,json}}")
    for j, lab in enumerate(cells):
        f = summary["final"]
        print(f"  {lab}: matched {f['matched'][j]:+.3f} ({f['matched_err'][j]:+.3f})   "
              f"hot {f['hot'][j]:+.3f} ({f['hot_err'][j]:+.3f})   "
              f"total {f['total'][j]:+.3f} ({f['total_err'][j]:+.3f})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
