"""Supply EVERY component of each cBAR variant's identity from REMD alone, and score them apart.

A residual on the reported free energy is a sum, so it says only that something is off. REMD holds
both endpoint ensembles and the MBAR free-energy matrix, so each intermediate term can be computed
independently and the error attributed to the term that carries it. On alanine this localised the
whole wall-cBAR residual to the NES legs and cleared the hot term to 0.002 kT -- a conclusion the
total alone cannot support.

THE THREE VARIANTS DIFFER IN WHAT "THE HOT SIDE" MEANS, and the reference must match::

  normal cBAR       Delta_m = f^C_m - f^H            hot side is the WHOLE hot state, unpartitioned
  traceback-strat   (f^C_m - f^H_m) + (f^H_m - f^H_n)   hot side is the HARD hot partition
  wall-stratified   (C_m - H_m) + (H_m - H_n)           hot side is the SOFT-WALLED window H_m

Scoring one variant against another's reference is the mistake this module exists to prevent: the
hard-partition f^H_m and the soft-walled f^H_m differ by the wall turn-on free energy, which on
alanine is 2.5 kT on the rare cell -- far larger than any residual being chased.

REFERENCE FORMULAS, all from the same REMD cloud and the same gauge::

    f^C_m(hard)  - f^H       = (f_C - f_H) - ln pi^C_m
    f^C_m(hard)  - f^H_m(hard) = (f_C - f_H) - ln( pi^C_m / pi^H_m )
    f^H_m(hard)  - f^H_n(hard) = -ln( pi^H_m / pi^H_n )
    f^C_m(wall)  - f^H_m(wall) = (f_C - f_H) - ln <e^-U_m(k_cold)>_cold + ln <e^-U_m(k_hot)>_hot
    f^H_m(wall)  - f^H_n(wall) = -ln( <e^-U_m(k_hot)>_hot / <e^-U_n(k_hot)>_hot )

WHAT THE GAUGE DOES AND DOES NOT AFFECT. ``f_C - f_H`` is taken from the MBAR matrix and enters
every ``C_m - H_m`` row EQUALLY, so it cancels in any difference between cells. It does not cancel
in the absolute per-component numbers, which therefore carry its error -- on alanine the MBAR
matrix gives -48.117 against the project's established -48.183, a 0.066 kT offset that is reported
rather than silently absorbed.

The cold reference is the all-replica MBAR reconstruction; the hot reference is the s = 0.25 rung
COUNTED, since the stored weights reweight onto the cold state and cannot supply hot populations.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from escort_ais.analysis.cbar_term_decomposition import (load_partition, reference_angles)
from escort_ais.common.paths import project_root

ROOT = project_root()

#: established alanine value, used ONLY to fix the sign convention of the MBAR f_kl matrix
_FCH_HINT = -48.183


def _f_cold_minus_hot(f_kl, cold_rung: int, hot_rung: int, hint: float = _FCH_HINT) -> float:
    """``f_C - f_H`` from the MBAR matrix, with the sign convention pinned by a known value.

    ``f_kl`` conventions differ between writers and a sign error here flips every per-component
    number while leaving the cell-to-cell differences untouched -- i.e. it would look fine in the
    only place most readers check.
    """
    cand = [f_kl[cold_rung, hot_rung], f_kl[hot_rung, cold_rung],
            -f_kl[cold_rung, hot_rung], -f_kl[hot_rung, cold_rung]]
    return float(min(cand, key=lambda v: abs(v - hint)))


def remd_components(reference: Path, partition: Path, k_hot: float | None = None,
                    k_cold: float = 100.0, hot_rung: int | None = None,
                    fch_hint: float = _FCH_HINT) -> dict:
    """Every component of all three identities, from one REMD cloud."""
    from escort_ais.methods.nd_flatbottom import nd_bias_kT
    from escort_ais.methods.wall_stratified import as_nd_cells

    labels, assign = load_partition(partition)
    n = len(labels)
    z = np.load(reference)
    ang, w, origin, scales = (reference_angles(z), z["weights"].astype(float),
                              z["origin"], z["scales"])
    rung = int(len(scales) - 1) if hot_rung is None else int(hot_rung)
    if abs(float(scales[rung]) - 0.25) > 1e-6:
        raise SystemExit(f"rung {rung} has s={float(scales[rung])}, not 0.25")
    fch = _f_cold_minus_hot(z["f_kl"], 0, rung, fch_hint)

    cold, hot = ang[origin == 0], ang[origin == rung]
    lab_c, lab_h = assign(cold), assign(hot)
    pi_cold_mbar = np.array([w[assign(ang) == m].sum() for m in range(n)]); pi_cold_mbar /= pi_cold_mbar.sum()
    pi_c = np.array([(lab_c == m).mean() for m in range(n)])
    pi_h = np.array([(lab_h == m).mean() for m in range(n)])

    out = dict(labels=labels, f_cold_minus_hot=fch, f_cold_minus_hot_hint=fch_hint,
               pi_cold_mbar=pi_cold_mbar.tolist(), pi_cold_counted=pi_c.tolist(),
               pi_hot_counted=pi_h.tolist(), hot_rung=rung,
               normal=dict(  # Delta_m = f^C_m - f^H, hot side unpartitioned
                   delta=[float(fch - np.log(pi_cold_mbar[m])) for m in range(n)],
                   f_rel=[float(-np.log(pi_cold_mbar[m] / pi_cold_mbar[0])) for m in range(n)]),
               stratified=dict(  # hard hot partition
                   matched=[float(fch - np.log(pi_c[m] / pi_h[m])) for m in range(n)],
                   hot=[float(-np.log(pi_h[m] / pi_h[0])) for m in range(n)],
                   f_rel=[float(-np.log(pi_c[m] / pi_c[0])) for m in range(n)]))

    if k_hot is not None:
        nd = _cells(partition)
        lz_c = [logsumexp(-nd_bias_kT(cold, c, k_cold)) - np.log(len(cold)) for c in nd]
        lz_h = [logsumexp(-nd_bias_kT(hot, c, k_hot)) - np.log(len(hot)) for c in nd]
        out["wall"] = dict(
            k_hot=float(k_hot), k_cold=float(k_cold),
            matched=[float(fch - lz_c[m] + lz_h[m]) for m in range(n)],
            hot=[float(-(lz_h[m] - lz_h[0])) for m in range(n)],
            f_rel=[float(-(lz_c[m] - lz_c[0])) for m in range(n)],
            f_rel_hard_minus_walled=float(
                -np.log(pi_cold_mbar[1] / pi_cold_mbar[0]) - (-(lz_c[1] - lz_c[0]))))
    return out


def _cells(partition: Path):
    """Cells in whichever schema the partition uses, adapted to the nd interface."""
    from escort_ais.methods.wall_stratified import as_nd_cells
    spec = json.loads(Path(partition).read_text())
    if "cells" in spec:
        from escort_ais.methods.nd_basin_tree import cells_from_spec
        return as_nd_cells(cells_from_spec(spec))
    from escort_ais.methods.barrier_partition import partition_from_dict
    return as_nd_cells(partition_from_dict(spec))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--reference", type=Path, required=True)
    ap.add_argument("--partition", type=Path, required=True)
    ap.add_argument("--k-hot", type=float, default=None,
                    help="soft hot-wall stiffness; enables the wall-stratified reference")
    ap.add_argument("--k-cold", type=float, default=100.0)
    ap.add_argument("--hot-rung", type=int, default=None)
    ap.add_argument("--fch-hint", type=float, default=_FCH_HINT)
    ap.add_argument("--out", type=Path, default=None)
    a = ap.parse_args(argv)

    r = remd_components(a.reference, a.partition, a.k_hot, a.k_cold, a.hot_rung, a.fch_hint)
    L = r["labels"]
    print(f"f_C - f_H (MBAR matrix) = {r['f_cold_minus_hot']:+.4f} kT "
          f"(sign pinned by hint {r['f_cold_minus_hot_hint']:+.3f})")
    print(f"pi_cold (MBAR)  {np.round(r['pi_cold_mbar'], 4).tolist()}")
    print(f"pi_hot  (s=0.25 rung, counted) {np.round(r['pi_hot_counted'], 4).tolist()}\n")

    print("NORMAL cBAR      Delta_m = f^C_m - f^H   (hot side = whole hot state)")
    for m, l in enumerate(L):
        print(f"   {l}: {r['normal']['delta'][m]:+9.4f}")
    print(f"   f_rel {L[1]}-{L[0]} = {r['normal']['f_rel'][1]:+.4f}\n")

    print("STRATIFIED cBAR  (f^C_m - f^H_m) + (f^H_m - f^H_n)   (HARD hot partition)")
    for m, l in enumerate(L):
        print(f"   {l}: matched {r['stratified']['matched'][m]:+9.4f}   "
              f"hot {r['stratified']['hot'][m]:+8.4f}")
    print(f"   f_rel {L[1]}-{L[0]} = {r['stratified']['f_rel'][1]:+.4f}\n")

    if "wall" in r:
        w = r["wall"]
        print(f"WALL cBAR        (C_m - H_m) + (H_m - H_n)   (SOFT walls, "
              f"k_hot={w['k_hot']:.3f} k_cold={w['k_cold']:g})")
        for m, l in enumerate(L):
            print(f"   {l}: matched {w['matched'][m]:+9.4f}   hot {w['hot'][m]:+8.4f}")
        print(f"   f_rel {L[1]}-{L[0]} = {w['f_rel'][1]:+.4f}  (WALLED target)")
        print(f"   hard - walled = {w['f_rel_hard_minus_walled']:+.4f} kT  "
              f"-- score wall-cBAR against the WALLED value, not the hard one")

    if a.out:
        a.out.parent.mkdir(parents=True, exist_ok=True)
        a.out.write_text(json.dumps(r, indent=2) + "\n")
        print(f"\nwrote {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
