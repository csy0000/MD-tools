#!/usr/bin/env python3
"""coverage_c0_mbar.py — joint MSK(hot-edge BAR) ⊕ equilibrium-MBAR reconstruction of the cold ensemble C0 for a
COVERAGE-window BAUS (`--method coverage`) run.

Realizes the corrected BAUS estimator (theory: docs/theory/BAUS_theory.pdf). Per-window free energies f_m=-ln Z_m
are solved from ONE joint objective (methods/baus_estimator.solve_joint):

  • equilibrium MBAR over the harmonic von Mises umbrellas: overlapping umbrellas constrain relative cold-window
    free energies (u_C cancels; each equilibrium config enters ONCE, cross-evaluated under every U_n).
  • matched hot-edge BAR/MSK for every umbrella: forward W_{H→m}=W_{H→C}+U_m(x_land) over ALL forward landings,
    reverse W_{m→H}=-U_m(x_0)+W_{C→H} from EQUILIBRIUM umbrella draws x_0, with the directional count correction
    c_{Hm}=ln(N^AIS_{H→m}/N^AIS_{m→H}). The hot edges anchor disconnected overlap components and isolated windows.

The continuous cold ensemble is reconstructed with explicit MBAR weights a_i^C ∝ 1/Σ_m N_m exp[f_m-U_m(x_i)]
(baus_estimator.reconstruct_weights); any region population is π_A=Σ_i a_i^C·1[x_i∈A] — no state definition.

This REPLACES the retired density-corrected reverse (ln q̃_m/p): that KDE ratio is NOT a valid BAR reverse work
and is not used here (see BAUS_theory.pdf Appendix A; bais_us.density_corrected_first_step is deprecated).

Post-processing only (no re-run): reuses `coverage_windows.npz` (mu, kappa, Wf, land_ang, label) +
`reverse/umb_XX/{seed_g*/trajectory.dcd, g*/ais_trajectory_summary.csv}` from a finished coverage run.

Run:  python -m escort_ais.analysis.coverage_c0_mbar \
          --run-dir data/alanine_dipeptide/bais_standalone/coverage --reference 0.0285
"""
from __future__ import annotations

import argparse
import glob
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
from escort_ais.methods import baus_estimator as be
from escort_ais.methods.coverage_windows import bias_u


def _load_run(run_dir):
    """Load the coverage-run arrays + per-window (confined samples, anneal works, reverse-start configs)."""
    import mdtraj as md
    D = Path(run_dir)
    z = np.load(D / "coverage_windows.npz")
    mu, kappa, Wf, land_ang, lab_land = z["mu"], z["kappa"], z["Wf"], z["land_ang"], z["label"]
    nb = len(mu)
    top_pdb = glob.glob(str(D / "reverse/umb_00/seed_g*/start_structure.pdb"))[0]
    quart = np.array([md.compute_phi(md.load(top_pdb))[0][0], md.compute_psi(md.load(top_pdb))[0][0]], int)
    conf, Wann, start = [], [], []
    for m in range(nb):
        cm = []
        for p in sorted(glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*/trajectory.dcd")):
            cm.append(md.compute_dihedrals(md.load_dcd(p, top=os.path.dirname(p) + "/start_structure.pdb"), quart))
        conf.append(np.concatenate(cm) if cm else np.zeros((0, mu.shape[1])))
        wa, sa = [], []
        for sdir in sorted(glob.glob(f"{D}/reverse/umb_{m:02d}/seed_g*")):
            g = os.path.basename(sdir).replace("seed_g", "")
            summ = f"{D}/reverse/umb_{m:02d}/g{g}/ais_trajectory_summary.csv"
            if not os.path.exists(summ):
                continue
            s = pd.read_csv(summ)
            sang = md.compute_dihedrals(md.load_dcd(sdir + "/trajectory.dcd", top=sdir + "/start_structure.pdb"), quart)
            for j, fi in zip(-s["final_logw"].to_numpy(), s["initial_frame_index"].to_numpy().astype(int)):
                wa.append(j); sa.append(sang[min(max(int(fi), 0), len(sang) - 1)])
        Wann.append(np.asarray(wa)); start.append(np.asarray(sa) if sa else np.zeros((0, mu.shape[1])))
    return dict(mu=mu, kappa=kappa, Wf=Wf, land_ang=land_ang, lab_land=lab_land, nb=nb,
                conf=conf, Wann=Wann, start=start)


def _win(mu, kappa, m):
    return {"mu": np.asarray(mu[m], float), "kappa": np.asarray(kappa[m], float)}


def _write_reconstruction_tables(pooled, weights, sample_window, nodes_out, map_nodes_out, bins=48):
    """Write raw weighted configurations and the explicit binned table used by the C0 map."""
    angles = np.degrees(np.asarray(pooled, float))
    if angles.ndim != 2 or angles.shape[1] < 2:
        raise ValueError("the C0 map requires at least phi and psi angles")
    table = pd.DataFrame({
        "phi_deg": angles[:, 0],
        "psi_deg": angles[:, 1],
        "reconstruct_weight": np.asarray(weights, float),
        "source_window": np.asarray(sample_window, int),
    })
    for path in (Path(nodes_out), Path(map_nodes_out)):
        path.parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(nodes_out, index=False)

    edges = np.linspace(-180.0, 180.0, int(bins) + 1)
    mass, phi_edges, psi_edges = np.histogram2d(
        table["phi_deg"], table["psi_deg"], bins=(edges, edges),
        weights=table["reconstruct_weight"],
    )
    count, _, _ = np.histogram2d(table["phi_deg"], table["psi_deg"], bins=(edges, edges))
    phi_grid, psi_grid = np.meshgrid(
        (phi_edges[:-1] + phi_edges[1:]) / 2,
        (psi_edges[:-1] + psi_edges[1:]) / 2,
        indexing="ij",
    )
    keep = mass > 0
    pd.DataFrame({
        "phi_deg": phi_grid[keep],
        "psi_deg": psi_grid[keep],
        "reconstruct_population": mass[keep],
        "sample_count": count[keep].astype(int),
    }).to_csv(map_nodes_out, index=False)


def _information_graph(centres_deg, hot_information, overlap_edges):
    """Build the transparent graph artifact consumed by data-driven figure renderers."""
    centres = np.asarray(centres_deg, float)
    nodes = [{"id": "H1", "label": "H_1", "type": "hot", "centre_deg": None}]
    nodes += [
        {"id": f"C{m}", "label": f"C_{m}", "type": "umbrella", "centre_deg": centre.tolist()}
        for m, centre in enumerate(centres)
    ]
    edges = [
        {"source": "H1", "target": f"C{m}", "type": "hot_ais_msk", "information": float(info)}
        for m, info in enumerate(hot_information) if np.isfinite(info) and info > 0
    ]
    edges += [
        {"source": f"C{m}", "target": f"C{n}", "type": "mbar_overlap", "information": float(info)}
        for m, n, info in overlap_edges if np.isfinite(info) and info > 0
    ]
    laplacian_edges = []
    for edge in edges:
        i = 0 if edge["source"] == "H1" else int(edge["source"][1:]) + 1
        j = int(edge["target"][1:]) + 1
        laplacian_edges.append((i, j, edge["information"]))
    laplacian = be.information_laplacian(laplacian_edges, len(nodes))
    return {
        "nodes": nodes,
        "edges": edges,
        "laplacian": laplacian.tolist(),
        "laplacian_eigenvalues": np.linalg.eigvalsh(laplacian).tolist(),
        "information_definition": "I_ij = -d2 ell_ij / d Delta_ij^2",
    }


def reconstruct(run_dir, estimator="joint", nodes_out=None, map_nodes_out=None,
                graph_out=None, map_bins=48):
    """C0 reconstruction (baus_estimator). Returns dict(f, pi_reweight, phi_pos, edge_info, ...).

    estimator ∈ {"joint", "bar-only"}: "joint" solves ℓ_eq+Σℓ_Hm^BAR (equilibrium MBAR overlap + hot edges);
    "bar-only" uses ONLY the H↔m bidirectional BAR edges (no inter-umbrella overlap) — the simpler, fully
    decoupled estimator / cross-check."""
    R = _load_run(run_dir)
    mu, kappa, Wf, land_ang, nb = R["mu"], R["kappa"], R["Wf"], R["land_ang"], R["nb"]
    conf, Wann, start = R["conf"], R["Wann"], R["start"]
    Nf = len(Wf)
    windows = [_win(mu, kappa, m) for m in range(nb)]
    cen = np.degrees(mu)

    # pooled EQUILIBRIUM umbrella configs (each enters MBAR once, cross-evaluated under every U_n)
    N = np.array([len(c) for c in conf], int)
    pooled = np.concatenate([c for c in conf if len(c)]) if N.sum() else np.zeros((0, mu.shape[1]))
    sample_window = np.concatenate([np.full(len(c), m, int) for m, c in enumerate(conf)]) if N.sum() \
        else np.zeros(0, int)
    U = be.bias_matrix(pooled, windows) if len(pooled) else np.zeros((nb, 0))

    # matched hot edges: soft +U_m forward over ALL landings; naive -U_m reverse from equilibrium draws
    edges = []
    for m in range(nb):
        if len(Wann[m]) == 0 or len(start[m]) == 0:
            continue
        Um_land = bias_u(land_ang, windows[m])                 # U_m at every forward landing
        Um_start = bias_u(start[m], windows[m])                # U_m at each reverse-AIS start (equilibrium draw)
        Wfwd, Wrev = be.hot_edge_works(Wf, Um_land, Wann[m], Um_start)
        edges.append(be.HotEdge(window=m, Wfwd=Wfwd, Wrev=Wrev, n_fwd=Nf, n_rev=len(Wann[m])))

    have_eq = len(pooled) > 0
    if estimator == "bar-only":
        bar = be.bar_only_free_energies(edges, n_windows=nb)
        f = bar.f
        edge_delta = bar.f.tolist(); edge_info = bar.edge_information.tolist()
        converged = bool(np.all(bar.converged)); extra = dict(edge_overlap=bar.edge_overlap.tolist())
    else:
        res = be.solve_joint(edges, U if have_eq else None,
                             sample_window if have_eq else None,
                             N if have_eq else None, n_windows=nb)
        f = res.f
        edge_delta = res.edge_delta_bar.tolist(); edge_info = res.edge_information.tolist()
        converged = bool(res.converged); extra = dict(diagnostics=res.diagnostics)

    # continuous-C0 reconstruction weights over the pooled equilibrium configs + region populations
    phi_pos = np.nan
    a_i = None
    if have_eq:
        a_i = be.reconstruct_weights(U, f, N)
        phi_pos = be.region_population(a_i, pooled[:, 0] > 0.0)

    overlap_edges = be.equilibrium_information_edges(U, f, N) if have_eq and estimator == "joint" else []
    graph = _information_graph(cen, edge_info, overlap_edges)
    requested_exports = any(path is not None for path in (nodes_out, map_nodes_out, graph_out))
    if requested_exports and not have_eq:
        raise ValueError("cannot export a C0 reconstruction without equilibrium umbrella configurations")
    if nodes_out is not None or map_nodes_out is not None:
        if nodes_out is None or map_nodes_out is None:
            raise ValueError("nodes_out and map_nodes_out must be supplied together")
        _write_reconstruction_tables(pooled, a_i, sample_window, nodes_out, map_nodes_out, bins=map_bins)
    if graph_out is not None:
        graph_path = Path(graph_out)
        graph_path.parent.mkdir(parents=True, exist_ok=True)
        graph_path.write_text(json.dumps(graph, indent=2) + "\n")

    # per-window reweighted mass (diagnostic): Σ a_i over configs sampled from m (does NOT define a state)
    pi_reweight = np.array([float(a_i[sample_window == m].sum()) if have_eq else np.nan for m in range(nb)])

    return dict(estimator=estimator, centres_deg=cen.tolist(), f=f.tolist(), converged=converged,
                edge_delta_bar=edge_delta, edge_information=edge_info,
                pi_reweight=pi_reweight.tolist(), phi_pos=float(phi_pos), N=N.tolist(),
                n_windows=int(nb), n_edges=int(len(edges)), **extra)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--estimator", choices=["joint", "bar-only"], default="joint",
                    help="joint = equilibrium MBAR + hot edges; bar-only = H↔m BAR edges only (no overlap)")
    ap.add_argument("--reference", type=float, default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--nodes-out", default=None, help="raw per-configuration reconstruction CSV")
    ap.add_argument("--map-nodes-out", default=None, help="processed binned-node CSV used by Figure 3")
    ap.add_argument("--graph-out", default=None, help="information-graph JSON")
    ap.add_argument("--map-bins", type=int, default=48, help="bins per torsion for the processed map-node table")
    args = ap.parse_args()

    out = Path(args.out) if args.out else Path(args.run_dir) / "coverage_c0_mbar.json"
    nodes_out = Path(args.nodes_out) if args.nodes_out else out.with_name(out.stem + "_nodes.csv")
    map_nodes_out = Path(args.map_nodes_out) if args.map_nodes_out else out.with_name(out.stem + "_map_nodes.csv")
    graph_out = Path(args.graph_out) if args.graph_out else out.with_name(out.stem + "_graph.json")
    r = reconstruct(args.run_dir, estimator=args.estimator, nodes_out=nodes_out,
                    map_nodes_out=map_nodes_out, graph_out=graph_out, map_bins=args.map_bins)
    r["artifacts"] = {
        "raw_nodes_csv": str(nodes_out),
        "map_nodes_csv": str(map_nodes_out),
        "information_graph_json": str(graph_out),
    }
    cen = np.array(r["centres_deg"]); f = np.array(r["f"]); info = np.array(r["edge_information"])
    print(f"estimator={r['estimator']}  windows={r['n_windows']}  hot edges={r['n_edges']}  "
          f"converged={r['converged']}")
    print("\nper-window f_m (=-ln Z_m, gauge f_H=0), hot-edge information I_Hm:")
    for m in np.argsort(f):
        print(f"  ({cen[m,0]:+5.0f},{cen[m,1]:+5.0f})  f={f[m]:+7.3f}  I_Hm={info[m]:8.2f}"
              f"{'  [uninformative hot edge]' if info[m] < 1e-6 else ''}")
    print(f"\nφ>0 population (continuous C0 reconstruction): {r['phi_pos']:.4f}")
    if args.reference is not None:
        print(f"reference                                    : {args.reference:.4f}")
    print("\nNOTE: joint estimator validation in progress — do not treat a single population match as correctness "
          "(BAUS_theory.pdf §Validation). Use parent-unit bootstrap for uncertainty.")

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(r, indent=2) + "\n")
    try:
        rel = out.relative_to(project_root())
    except ValueError:
        rel = out
    print(f"\nwrote {rel}")
    return r


if __name__ == "__main__":
    main()
