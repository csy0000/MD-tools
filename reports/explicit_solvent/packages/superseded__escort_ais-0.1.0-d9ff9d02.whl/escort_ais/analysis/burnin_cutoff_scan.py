"""Section 9.4: the Sequential Suffix Gate (`SSG_V1`) and the fixed-cutoff sensitivity sweep.

Reads ``selection_lock.json`` and applies the seven criteria EXACTLY as frozen there. No threshold
is read from anywhere else and none is passed on the command line -- if a threshold could be
supplied at run time, the lock would not be binding, and rule 12 is the one rule in this campaign
that cannot be repaired after the fact.

The estimand is the relative substate free energy
``f_m - f_0 = -(ell_m - ell_0)``, with ``ell_m = log mean(exp(-W) I(landing in m))`` over the WHOLE
block set (CLAUDE.md: the forward normaliser uses the size of the whole bank, since the landing
probability is part of the estimand). ``C_0`` is the highest-population cell, fixed once from all
diagnostic data and never re-chosen -- re-picking it per candidate would let the reference basin
move under the estimator and make the reported differences incomparable across cutoffs.

ONLINE EMULATION IS REAL. At decision block ``t`` a candidate cutoff ``c`` may use blocks ``c..t``
and nothing later. The scan never peeks past ``t``, so a cutoff that looks good only with hindsight
cannot be selected -- that is precisely what ``REFERENCE_ORACLE_CUTOFF`` is for, computed elsewhere
and never promotable.

Bootstrap grouping is BY BLOCK, not by shot. Shots within a block share a hot source window and are
not independent; resampling shots would understate the uncertainty by roughly the within-block
correlation and admit a cutoff resting on one favourable block.
"""
from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

from escort_ais.common.paths import project_root

ROOT = project_root()


def _ess(logw):
    if logw.size == 0:
        return 0.0
    ln = logw - logsumexp(logw)
    return float(np.exp(-logsumexp(2.0 * ln)))


def rel_free_energies(logw, cell_idx, blocks, keep_blocks, cells, ref):
    """f_m - f_ref over the shots whose block is in keep_blocks. NaN where a cell has no landing."""
    sel = np.isin(blocks, keep_blocks)
    if not sel.any():
        return np.full(len(cells), np.nan)
    lw, ci = logw[sel], cell_idx[sel]
    n = float(sel.sum())
    ell = np.array([logsumexp(lw[ci == m]) - np.log(n) if (ci == m).any() else -np.inf
                    for m in range(len(cells))])
    return -(ell - ell[ref])


def block_bootstrap(logw, cell_idx, blocks, keep, cells, ref, n_boot, rng):
    """Resample BLOCKS with replacement; returns [n_boot, n_cells] of f_m - f_ref."""
    keep = np.asarray(keep)
    out = np.full((n_boot, len(cells)), np.nan)
    idx_by_block = {b: np.flatnonzero(blocks == b) for b in keep}
    for i in range(n_boot):
        pick = rng.choice(keep, size=len(keep), replace=True)
        rows = np.concatenate([idx_by_block[b] for b in pick])
        lw, ci = logw[rows], cell_idx[rows]
        n = float(len(rows))
        ell = np.array([logsumexp(lw[ci == m]) - np.log(n) if (ci == m).any() else -np.inf
                        for m in range(len(cells))])
        out[i] = -(ell - ell[ref])
    return out


def weighted_mmd(x1, w1, x2, w2, gamma):
    """Weighted Gaussian-kernel MMD^2 between two weighted point sets on the torus.

    Coordinates enter as (sin, cos) pairs so that the periodic wrap is handled by the embedding
    rather than by an ad-hoc angular difference; the kernel is then an ordinary Gaussian.
    """
    def k(a, wa, b, wb):
        d = ((a[:, None, :] - b[None, :, :]) ** 2).sum(-1)
        return float((np.outer(wa, wb) * np.exp(-gamma * d)).sum())
    w1 = w1 / w1.sum()
    w2 = w2 / w2.sum()
    return k(x1, w1, x1, w1) + k(x2, w2, x2, w2) - 2.0 * k(x1, w1, x2, w2)


def slabs(keep, n_slabs, min_per):
    """Split a contiguous block list into n_slabs consecutive slabs of at least min_per blocks."""
    keep = list(keep)
    if len(keep) < n_slabs * min_per:
        return None
    q, r = divmod(len(keep), n_slabs)
    sizes, out, i = [q + (1 if j < r else 0) for j in range(n_slabs)], [], 0
    for s in sizes:
        out.append(keep[i:i + s])
        i += s
    return out if all(len(x) >= min_per for x in out) else None


def evaluate(cand, land, cells, ref, crit, elig, rng, n_boot):
    """All seven criteria for one candidate cutoff at one decision time. Returns a dict row."""
    logw = land["logw"].to_numpy(float)
    ci = land["cell_index"].to_numpy(int)
    blocks = land["block_id"].to_numpy(int)
    seeds = land["seed_set"].to_numpy(object)
    keep = cand["keep_blocks"]
    m_idx = [m for m in range(len(cells)) if m != ref]

    row = dict(cutoff=cand["cutoff"], decision_block=cand["decision_block"],
               n_blocks=len(keep), keep_blocks=",".join(map(str, keep)))

    point = rel_free_energies(logw, ci, blocks, keep, cells, ref)
    for m in m_idx:
        row[f"f_{cells[m]}"] = float(point[m])

    sel = np.isin(blocks, keep)
    lw_all = logw[sel]
    row["ess_overall"] = _ess(lw_all)
    ess_cell = {m: _ess(logw[sel & (ci == m)]) for m in range(len(cells))}
    row["ess_min_cell"] = float(min(ess_cell.values()))
    # 5. importance support
    row["c5_support"] = bool(row["ess_overall"] >= crit["5_importance_support"]["overall_forward_ess_min"]
                             and row["ess_min_cell"] >= crit["5_importance_support"]["per_required_basin_ess_min"])

    # 1. estimator precision -- block-grouped bootstrap half-width
    boot = block_bootstrap(logw, ci, blocks, keep, cells, ref, n_boot, rng)
    hw = {}
    for m in m_idx:
        col = boot[:, m][np.isfinite(boot[:, m])]
        hw[m] = float((np.percentile(col, 97.5) - np.percentile(col, 2.5)) / 2.0) if col.size else np.inf
    row["c1_halfwidth_max"] = float(max(hw.values()))
    row["c1_precision"] = bool(row["c1_halfwidth_max"] <= crit["1_estimator_precision"]["threshold_kT"])
    se = {m: float(np.nanstd(boot[:, m])) for m in m_idx}

    # 2. temporal agreement across three consecutive slabs
    sl = slabs(keep, elig["n_slabs"], elig["min_blocks_per_slab"])
    row["c2_slabs"] = "|".join(",".join(map(str, s)) for s in sl) if sl else ""
    if sl is None:
        row["c2_temporal"], row["c2_max_gap"] = False, np.inf
    else:
        vals = [rel_free_energies(logw, ci, blocks, s, cells, ref) for s in sl]
        gaps = []
        for m in m_idx:
            tol = max(0.20, 2.0 * se[m])
            for i, j in combinations(range(len(sl)), 2):
                g = abs(vals[i][m] - vals[j][m])
                gaps.append(g if np.isfinite(g) else np.inf)
                if not np.isfinite(g) or g > tol:
                    row.setdefault("_c2_fail", True)
        row["c2_max_gap"] = float(max(gaps)) if gaps else np.inf
        row["c2_temporal"] = not row.pop("_c2_fail", False)

    # 3. no material residual drift -- per-block estimates regressed on block index
    per_block = np.array([rel_free_energies(logw, ci, blocks, [b], cells, ref) for b in keep])
    drift_ok, max_drift = True, 0.0
    for m in m_idx:
        y = per_block[:, m]
        good = np.isfinite(y)
        if good.sum() < 3:
            drift_ok = False
            continue
        x = np.arange(len(keep))[good]
        slope = np.polyfit(x, y[good], 1)[0]
        # block bootstrap on the slope, so the CI respects the block grouping
        bs = []
        for _ in range(200):
            pick = rng.choice(np.flatnonzero(good), size=int(good.sum()), replace=True)
            if len(np.unique(x[np.searchsorted(np.flatnonzero(good), pick)])) < 2:
                continue
            bs.append(np.polyfit(np.arange(len(keep))[pick], y[pick], 1)[0])
        lo, hi = (np.percentile(bs, [2.5, 97.5]) if len(bs) > 20 else (-np.inf, np.inf))
        end_to_end = abs(slope) * (len(keep) - 1)
        max_drift = max(max_drift, float(end_to_end))
        if not (lo <= 0.0 <= hi) or end_to_end >= 0.20:
            drift_ok = False
    row["c3_end_to_end_drift"] = max_drift
    row["c3_no_drift"] = bool(drift_ok)

    # 4. block influence -- leave-one-block-out range, and no block over 25% of a basin's weight
    loo = []
    for b in keep:
        v = rel_free_energies(logw, ci, blocks, [x for x in keep if x != b], cells, ref)
        loo.append([v[m] for m in m_idx])
    loo = np.array(loo, float)
    rng_loo = float(np.nanmax(np.nanmax(loo, 0) - np.nanmin(loo, 0))) if loo.size else np.inf
    shares = []
    for m in range(len(cells)):
        tot = logsumexp(logw[sel & (ci == m)]) if (sel & (ci == m)).any() else -np.inf
        for b in keep:
            bm = (blocks == b) & (ci == m)
            if bm.any() and np.isfinite(tot):
                shares.append(float(np.exp(logsumexp(logw[bm]) - tot)))
    row["c4_loo_range"] = rng_loo
    row["c4_max_block_share"] = float(max(shares)) if shares else 1.0
    row["c4_influence"] = bool(rng_loo <= crit["4_block_influence"]["leave_one_block_out_range_kT"]
                               and row["c4_max_block_share"] <= crit["4_block_influence"]["max_single_block_weight_share"])

    # 7. replicate consistency -- seed sets at matched counts
    uss = sorted(set(seeds))
    if len(uss) < 2:
        row["c7_replicate"], row["c7_max_gap"] = False, np.inf
    else:
        per_seed = []
        for s in uss:
            mask = sel & (seeds == s)
            n = float(mask.sum())
            ell = np.array([logsumexp(logw[mask & (ci == m)]) - np.log(n)
                            if (mask & (ci == m)).any() else -np.inf for m in range(len(cells))])
            per_seed.append(-(ell - ell[ref]))
        g = [abs(per_seed[0][m] - per_seed[1][m]) for m in m_idx]
        row["c7_max_gap"] = float(np.nanmax(g)) if g else np.inf
        row["c7_replicate"] = bool(all(
            np.isfinite(gg) and gg <= max(0.20, 2.0 * se[m]) for gg, m in zip(g, m_idx)))

    # 6. landing-distribution stability across slabs, bootstrap-calibrated
    if sl is None:
        row["c6_stability"], row["c6_p"] = False, 0.0
    else:
        cvcols = [c for c in land.columns if c.endswith("_rad")]
        def feats(bl):
            mm = np.isin(blocks, bl)
            ang = land.loc[mm, cvcols].to_numpy(float)
            return np.hstack([np.sin(ang), np.cos(ang)]), np.exp(logw[mm] - logw[mm].max())
        gamma = 1.0 / (2 * len(cvcols))
        obs = max(weighted_mmd(*feats(sl[i]), *feats(sl[j]), gamma)
                  for i, j in combinations(range(len(sl)), 2))
        # null: reshuffle BLOCKS among slabs of the same sizes (within-suffix block resampling)
        null = []
        for _ in range(200):
            perm = rng.permutation(keep)
            k, parts = 0, []
            for s in sl:
                parts.append(perm[k:k + len(s)]); k += len(s)
            null.append(max(weighted_mmd(*feats(parts[i]), *feats(parts[j]), gamma)
                            for i, j in combinations(range(len(parts)), 2)))
        p = float((np.sum(np.asarray(null) >= obs) + 1) / (len(null) + 1))
        row["c6_mmd"], row["c6_p"] = float(obs), p
        row["c6_stability"] = bool(p > crit["6_landing_distribution_stability"]["level"])

    row["passes_all"] = bool(row["c1_precision"] and row["c2_temporal"] and row["c3_no_drift"]
                             and row["c4_influence"] and row["c5_support"]
                             and row["c6_stability"] and row["c7_replicate"])
    return row


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--campaign", type=Path,
                    default=ROOT / "campaigns/20260808T074306Z__forward-prep-burnin")
    ap.add_argument("--n-boot", type=int, default=500)
    ap.add_argument("--seed", type=int, default=20260809)
    ap.add_argument("--reuse-scan", action="store_true",
                    help="recompute the decision from an existing cutoff_scan.parquet instead of "
                         "re-evaluating every candidate. Thresholds still come from the lock; this "
                         "only avoids repeating the expensive MMD null.")
    a = ap.parse_args(argv)

    import pandas as pd

    lock = json.loads((a.campaign / "selection_lock.json").read_text())
    crit, elig = lock["ssg_v1_criteria"], lock["eligibility"]
    all_rows, decisions = [], {}

    for sysname, S in lock["systems"].items():
        land = pd.read_parquet(a.campaign / f"landings_{sysname}.parquet")
        land = land[land["cell_index"] >= 0].reset_index(drop=True)
        cells = (land.sort_values("cell_index")["cell"].dropna().unique().tolist())
        n_blocks = S["block_definition"]["n_blocks"]
        # C_0 fixed ONCE from all diagnostic data, never re-chosen per candidate
        ref = int(land["cell_index"].value_counts().idxmax())
        rng = np.random.default_rng(a.seed)

        min_blocks = elig["min_diagnostic_blocks_in_candidate"]
        if a.reuse_scan and (a.campaign / "cutoff_scan.parquet").exists():
            prev = pd.read_parquet(a.campaign / "cutoff_scan.parquet")
            df = prev[prev["system"] == sysname].reset_index(drop=True)
        else:
            rows = []
            for t in range(min_blocks - 1, n_blocks):
                for c in range(0, t - min_blocks + 2):
                    rows.append(evaluate(dict(cutoff=c, decision_block=t,
                                              keep_blocks=list(range(c, t + 1))),
                                         land, cells, ref, crit, elig, rng, a.n_boot))
            df = pd.DataFrame(rows)
            df.insert(0, "system", sysname)
        all_rows.append(df)

        # SSG_V1 selection: earliest passing candidate per decision time, then persistence
        sel_by_t = {}
        for t, g in df.groupby("decision_block"):
            ok = g[g["passes_all"]].sort_values("cutoff")
            sel_by_t[int(t)] = int(ok.iloc[0]["cutoff"]) if len(ok) else None

        chosen, streak, gate_block = None, 0, None
        for t in sorted(sel_by_t):
            c = sel_by_t[t]
            if c is None:
                chosen, streak = None, 0
                continue
            if chosen is not None and abs(c - chosen) <= elig["persistence_tolerance_blocks"]:
                streak += 1
            else:
                chosen, streak = c, 1
            if streak >= elig["persistence_decisions"]:
                gate_block = t
                break

        # Section 9.4 distinguishes the failure modes and they are NOT interchangeable.
        # HOT_NOT_CONVERGED means the criteria could be evaluated and no cutoff held up -- a
        # statement about the hot source. When criterion 5 fails everywhere the criteria were
        # never meaningfully testable: the estimator has no support, which is a statement about
        # the AIS weights (or about a cell nothing ever reaches). Reporting the latter as
        # "hot not converged" would blame the trajectory for an importance-sampling failure.
        prod = (gate_block + 1) if gate_block is not None else None
        if gate_block is not None:
            status = "SSG_V1_SELECTED"
            if prod >= n_blocks:
                status, prod = "TRAJECTORY_EXHAUSTED", None
        elif not df["c5_support"].any():
            widest = df.loc[df["n_blocks"].idxmax()]
            status = ("REGION_UNSAMPLED" if widest["ess_min_cell"] == 0.0
                      else "AIS_WEIGHT_COLLAPSE")
        else:
            status = "HOT_NOT_CONVERGED"
        decisions[sysname] = dict(
            status=status, reference_cell=cells[ref], n_cells=len(cells),
            source_burn_cutoff=chosen if gate_block is not None else None,
            gate_decision_block=gate_block, production_start=prod,
            per_decision_earliest_pass=sel_by_t,
            n_candidates=int(len(df)), n_passing=int(df["passes_all"].sum()),
            support_diagnostics=dict(
                ess_overall_min=float(df["ess_overall"].min()),
                ess_overall_max=float(df["ess_overall"].max()),
                ess_overall_threshold=crit["5_importance_support"]["overall_forward_ess_min"],
                ess_min_cell_min=float(df["ess_min_cell"].min()),
                ess_min_cell_max=float(df["ess_min_cell"].max()),
                ess_per_basin_threshold=crit["5_importance_support"]["per_required_basin_ess_min"],
                halfwidth_min_kT=float(df["c1_halfwidth_max"].min()),
                max_block_weight_share=float(df["c4_max_block_share"].max()),
                binding_constraint=("per-basin ESS" if df["ess_overall"].min() >=
                                    crit["5_importance_support"]["overall_forward_ess_min"]
                                    else "overall ESS")),
            caveat_criterion_3=(
                "the drift regression fits PER-BLOCK estimates; for a rare cell one block holds "
                "only a handful of landings, so those points are individually noise-dominated and "
                "the test has little power. Reported, not loosened."),
            criterion_pass_rate={k: float(df[k].mean()) for k in
                                 ["c1_precision", "c2_temporal", "c3_no_drift", "c4_influence",
                                  "c5_support", "c6_stability", "c7_replicate"]},
            note=("production_start is the first UNTOUCHED block after the gate decision; every "
                  "record used for selection or confirmation stays quarantined regardless of "
                  "which side of the cutoff it falls on"))

    scan = pd.concat(all_rows, ignore_index=True)
    scan.to_parquet(a.campaign / "cutoff_scan.parquet", index=False)
    scan.to_csv(a.campaign / "gate_trace.csv", index=False)
    (a.campaign / "decision.json").write_text(json.dumps(
        dict(schema="ssg_v1_decision/v1",
             selection_lock_sha256_16=(a.campaign / "selection_lock.sha256").read_text().strip(),
             n_boot=a.n_boot, seed=a.seed, systems=decisions), indent=2) + "\n")

    print(f"wrote cutoff_scan.parquet / gate_trace.csv ({len(scan)} candidate evaluations) "
          f"and decision.json\n")
    for sysname, d in decisions.items():
        print(f"=== {sysname} : {d['status']} ===")
        print(f"  reference cell {d['reference_cell']}, {d['n_cells']} cells; "
              f"{d['n_passing']}/{d['n_candidates']} candidates pass all seven")
        print(f"  source_burn_cutoff={d['source_burn_cutoff']}  "
              f"gate_decision_block={d['gate_decision_block']}  "
              f"production_start={d['production_start']}")
        print("  per-criterion pass rate over all candidates:")
        for k, v in d["criterion_pass_rate"].items():
            print(f"    {k:<16} {v:6.1%}")
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
