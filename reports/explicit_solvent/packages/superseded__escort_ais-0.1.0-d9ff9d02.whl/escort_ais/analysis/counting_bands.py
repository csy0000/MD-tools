"""Confidence bands on the running populations of a COUNTING trajectory.

A counting reference -- a cold MD walker, or the ``s=1`` slot of a replica-exchange ladder --
estimates ``pi_m`` by counting frames in each cell. Its frames are a correlated time series, so an
i.i.d. frame bootstrap understates the band by roughly ``sqrt(2 tau)``. This module block-bootstraps
instead, and makes the one judgement call that matters explicit rather than burying it in a default.

THE BLOCK LENGTH IS ``tau_multiple x tau_int``, AND ``tau_multiple`` DEPENDS ON WHAT THE SERIES IS:

* **Continuous walker** (a free cold MD trajectory): ``tau_multiple = 8``. ``tau`` is measured on
  the physical process and the ordinary choice applies.
* **Temperature stream** (the ``s=1`` rung of a REMD ladder): ``tau_multiple = 50``. The rung is not
  one walker -- exchanges swap different replicas in and out of it, so the cell indicator
  decorrelates faster than the underlying conformational process and ``tau`` measured on the stream
  is an UNDERESTIMATE. 50 compensates.

Getting this backwards is not a cosmetic error in either direction. Using 50 on the alanine 1 us
cold walker gave a 38 ns block, leaving fewer than 10 blocks for every prefix below 380 ns -- i.e.
no band over most of the curve. Using 8 on a REMD rung would report a band narrower than the
reference's real uncertainty, which is the direction that makes an estimator look biased when it is
merely being compared against an over-confident reference.

Prefixes holding fewer than 10 blocks get ``nan`` rather than a band built from too few blocks to
resample.
"""
from __future__ import annotations

import numpy as np

#: continuous walker -- tau is measured on the physical process
TAU_MULTIPLE_WALKER = 8
#: REMD rung -- exchanges make tau an underestimate; see module docstring
TAU_MULTIPLE_TEMPERATURE_STREAM = 50

#: below this many blocks a prefix gets nan instead of a band
MIN_BLOCKS = 10


def counting_band(labels, n_basin, idx, n_boot, rng, block=None,
                  tau_multiple=TAU_MULTIPLE_WALKER, min_blocks=MIN_BLOCKS):
    """``[5%, 95%]`` band on the running ``pi_m / pi_0`` of a counting trajectory.

    THE BLOCK LENGTH IS PER CELL. The plotted quantity is the ratio ``pi_m / pi_0``, so the block
    only has to decorrelate the two indicators that enter it: ``block_m = tau_multiple *
    max(tau_m, tau_0)``. Taking one global block from the slowest cell in the partition is
    conservative for every other cell, and on an 11-cell system it is fatal -- cyclosporin's C4 has
    ``tau = 212`` frames against C9's 3.5, so a global block of 212*50 leaves 4 blocks in 1000 ns and
    NO cell gets a band, including the nine that could easily support one.

    Cells whose own block still leaves fewer than ``min_blocks`` are returned as ``nan`` and named in
    ``info["starved"]`` -- the caller is expected to say so rather than draw nothing silently.

    :param labels: per-frame cell index, in time order. Must be exhaustive (no ``-1``).
    :param idx: prefix lengths at which to evaluate, in frames.
    :param block: fixed block length in frames, overriding the per-cell derivation (reproduction).
    :param tau_multiple: see the module docstring -- 8 for a continuous walker, 50 for a REMD rung.
    :returns: ``(lo, hi, info)``; ``info`` carries ``tau``, ``blocks``, ``n_blocks`` and ``starved``.
    """
    from escort_ais.analysis.cbar_term_decomposition import integrated_autocorr
    labels = np.asarray(labels)
    tau = np.array([integrated_autocorr((labels == m).astype(float)) for m in range(n_basin)])
    if block is None:
        blocks = np.maximum(2, np.round(tau_multiple * np.maximum(tau, tau[0]))).astype(int)
    else:
        blocks = np.full(n_basin, int(block))

    lo = np.full((len(idx), n_basin), np.nan)
    hi = np.full((len(idx), n_basin), np.nan)
    for m in range(n_basin):
        blk = int(blocks[m])
        for j, k in enumerate(idx):
            seg = labels[:k]
            nb = max(1, len(seg) // blk)
            if nb < min_blocks:
                continue
            reps = np.empty(n_boot)
            for b in range(n_boot):
                st = rng.integers(0, max(1, len(seg) - blk), size=nb)
                samp = np.concatenate([seg[t:t + blk] for t in st])
                n_m = (samp == m).sum(); n_0 = (samp == 0).sum()
                reps[b] = n_m / n_0 if n_0 > 0 else np.nan
            lo[j, m] = np.nanpercentile(reps, 5)
            hi[j, m] = np.nanpercentile(reps, 95)

    n_full = np.maximum(1, len(labels) // blocks)
    info = dict(tau=tau.tolist(), blocks=blocks.tolist(), n_blocks=n_full.tolist(),
                min_blocks=int(min_blocks), tau_multiple=int(tau_multiple),
                starved=[m for m in range(n_basin) if n_full[m] < min_blocks])
    return lo, hi, info
