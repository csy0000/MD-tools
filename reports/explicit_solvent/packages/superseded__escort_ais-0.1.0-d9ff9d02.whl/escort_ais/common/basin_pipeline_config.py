"""basin_pipeline_config.py — Config dataclasses and dir-schema helpers for the basin pipeline.

Staged REST2-AIS + TICA/MSM + CFT/TRAM basin free-energy pipeline.
All dataclasses are pure-Python; no OpenMM or GPU imports.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Float → path-safe string encoding  (e.g. 2.0 → "d2p0", 0.4 → "d0p4")
# ---------------------------------------------------------------------------

def float_to_tag(value: float, prefix: str = "d") -> str:
    """Encode a float as a path-safe string with 'p' for the decimal point.

    Examples
    --------
    >>> float_to_tag(2.0)
    'd2p0'
    >>> float_to_tag(0.4, prefix='s')
    's0p4'
    >>> float_to_tag(12.5)
    'd12p5'
    """
    # Format with up to 4 decimal places, strip trailing zeros after decimal
    s = f"{value:.4f}".rstrip("0").rstrip(".")
    return prefix + s.replace(".", "p")


# ---------------------------------------------------------------------------
# Stage sub-directory names (relative to a pipeline run root)
# ---------------------------------------------------------------------------

STAGE_DIRS = {
    "seeds":        "01_seeds",
    "hot":          "01_hot",
    "hot_resample": "02_hot_resampled",
    "fwd_ais":      "03_fwd_ais",
    "ais_resample": "04_ais_resampled",
    "cold_local":   "05_cold_local",
    "msm":          "06_msm",
    "rev_ais":      "07_rev_ais",
    "analysis":     "08_analysis",
}


def stage_dir(pipeline_root: Path, stage_key: str) -> Path:
    """Return the absolute path for a pipeline stage sub-directory."""
    return pipeline_root / STAGE_DIRS[stage_key]


# ---------------------------------------------------------------------------
# Conformer seeding (stage 1a)
# ---------------------------------------------------------------------------

@dataclass
class ConformerSeedConfig:
    """Config for GPU ETKDG+MMFF conformer pool generation + MaxMin diversity picking."""

    smiles: str = "CC(=O)N[C@@H](C)C(=O)NC"
    n_pool: int = 10_000
    n_pick: int = 1_000
    seed: int = 42
    max_mmff_iters: int = 200
    # Path to the tleap reference PDB for atom-order mapping
    leap_pdb: Optional[str] = None
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Hot walker MD (stage 1b)
# ---------------------------------------------------------------------------

@dataclass
class HotWalkerConfig:
    """Config for N independent short MD sims at s_hot seeded from diverse conformers."""

    topology_dir: str = ""
    seed_positions_npy: str = ""       # (K, n_atoms, 3) nm, Amber order
    scale_factor: float = 0.4          # s_hot
    duration_steps: int = 5_000        # per walker (10 ps at 2 fs)
    traj_interval_steps: int = 500     # save every 1 ps
    temperature_k: float = 300.0
    friction_per_ps: float = 1.0
    timestep_fs: float = 2.0
    platform: str = "OpenCL"
    seed: int = 42
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Resampling (stages 2 + 4)
# ---------------------------------------------------------------------------

@dataclass
class ResampleConfig:
    """Config for a single weighted-resample stage."""

    method: str = "systematic"         # "systematic" | "stratified"
    n_out: int = 1_000
    seed: int = 42
    log_weights_npy: str = ""          # input log-weights (length K)
    source_positions_npy: str = ""     # optional: source coords to resample
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Forward AIS (stage 3)
# ---------------------------------------------------------------------------

@dataclass
class ForwardAISConfig:
    """Config for the forward nonequilibrium switching s_hot→s_cold."""

    topology_dir: str = ""
    source_positions_npy: str = ""     # (K, n_atoms, 3) nm — equal-weight starts
    s_hot: float = 0.4
    s_cold: float = 1.0
    n_windows: int = 20
    switching_time_ps: float = 5.0
    timestep_fs: float = 2.0
    temperature_k: float = 300.0
    platform: str = "OpenCL"
    seed: int = 42
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Cold local MD (stage 5)
# ---------------------------------------------------------------------------

@dataclass
class ColdLocalConfig:
    """Config for cold local MD runs seeded from resampled AIS endpoints."""

    topology_dir: str = ""
    seed_positions_npy: str = ""       # (K, n_atoms, 3) nm, equal-weight cold starts
    scale_factor: float = 1.0          # s_cold
    duration_steps: int = 50_000       # per walker (100 ps at 2 fs)
    traj_interval_steps: int = 500
    temperature_k: float = 300.0
    friction_per_ps: float = 1.0
    timestep_fs: float = 2.0
    platform: str = "OpenCL"
    seed: int = 42
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# MSM / TICA (stage 6)
# ---------------------------------------------------------------------------

@dataclass
class MSMConfig:
    """Config for TICA + k-means + reversible MSM + PCCA+ (deeptime)."""

    cold_local_dir: str = ""           # stage 5 output dir (has phi_psi.npy + walker_index.npy)
    fwd_ais_dir: str = ""              # stage 3 output dir (ais_final_coordinates.dcd + summary csv)
    topology_dir: str = ""
    tica_lag: int = 5                  # lag in frames for TICA
    tica_dims: int = 2
    n_clusters: int = 50
    msm_lag: int = 5                   # lag in frames for MSM
    n_basins: int = 4                  # PCCA+ macrostates
    seed: int = 42
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Reverse AIS (stage 7)
# ---------------------------------------------------------------------------

@dataclass
class ReverseAISConfig:
    """Config for reverse nonequilibrium switching s_cold→s_hot."""

    topology_dir: str = ""
    cold_endpoint_positions_npy: str = ""  # (K, n_atoms, 3) nm cold starts (resampled AIS endpoints)
    s_cold: float = 1.0
    s_hot: float = 0.4
    n_windows: int = 20
    switching_time_ps: float = 5.0
    timestep_fs: float = 2.0
    temperature_k: float = 300.0
    platform: str = "OpenCL"
    seed: int = 42
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Analysis (stage 8)
# ---------------------------------------------------------------------------

@dataclass
class BasinAnalysisConfig:
    """Config for the post-analysis estimator comparison."""

    fwd_ais_dir: str = ""
    msm_dir: str = ""
    rev_ais_dir: str = ""              # optional; triggers BAR/CFT if provided
    temperature_k: float = 300.0
    n_boot: int = 200
    seed: int = 42
    output_dir: Optional[str] = None


# ---------------------------------------------------------------------------
# Top-level pipeline config
# ---------------------------------------------------------------------------

@dataclass
class BasinPipelineConfig:
    """Umbrella config tying all stages together under one pipeline root dir."""

    pipeline_root: str = ""            # data/alanine_dipeptide/basin_pipeline/<date>-<name>/
    topology_dir: str = ""
    seeds: ConformerSeedConfig = field(default_factory=ConformerSeedConfig)
    hot: HotWalkerConfig = field(default_factory=HotWalkerConfig)
    hot_resample: ResampleConfig = field(default_factory=ResampleConfig)
    fwd_ais: ForwardAISConfig = field(default_factory=ForwardAISConfig)
    ais_resample: ResampleConfig = field(default_factory=ResampleConfig)
    cold_local: ColdLocalConfig = field(default_factory=ColdLocalConfig)
    msm: MSMConfig = field(default_factory=MSMConfig)
    rev_ais: ReverseAISConfig = field(default_factory=ReverseAISConfig)
    analysis: BasinAnalysisConfig = field(default_factory=BasinAnalysisConfig)
