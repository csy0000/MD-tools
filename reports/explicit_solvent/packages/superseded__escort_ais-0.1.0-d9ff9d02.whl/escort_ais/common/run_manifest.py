"""Versioned run-manifest for reproducible run provenance.

A manifest records how a single run was produced: identity, system/method, config hash, git state,
command, seeds, timing, checksums, outputs, and retention/lifecycle. It is JSON-serializable and
written atomically. See ``docs/protocols/report_and_run_provenance.md`` for the lifecycle.

Typical use::

    from escort_ais.common.run_manifest import RunManifest, config_hash, make_run_id, write_manifest
    cfg = {"n": 10, "seed": 0}
    h = config_hash(cfg)
    rid = make_run_id("toy", "kcc_split", h)
    m = RunManifest.new(run_id=rid, system="toy", method="kcc_split", config_hash=h,
                        command="python -m escort_ais.experiments.toy.demo_kcc_split_toy",
                        seeds=[0], retention="exploratory")
    d = write_manifest(run_dir(rid), m)            # status stays "planned"
    update_status(d, "running")
    update_status(d, "completed", output_paths=["fig.png"])
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA_VERSION = 1
MANIFEST_NAME = "manifest.json"

STATUS_VALUES = {"planned", "running", "completed", "failed", "invalid", "superseded", "archived"}
RETENTION_VALUES = {"temporary", "exploratory", "production", "reference", "archive", "deletion_candidate"}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def config_hash(config: dict[str, Any]) -> str:
    """Deterministic 12-char hex hash of a config dict (order-independent, JSON-canonical)."""
    payload = json.dumps(config, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]


def make_run_id(system_slug: str, method_slug: str, cfg_hash: str, *, when: datetime | None = None) -> str:
    """Immutable run ID ``YYYYMMDDTHHMMSS__<system>__<method>__<hash8>``."""
    ts = (when or datetime.now(timezone.utc)).strftime("%Y%m%dT%H%M%S")
    return f"{ts}__{system_slug}__{method_slug}__{cfg_hash[:8]}"


def git_state(repo: Path | None = None) -> tuple[str | None, bool]:
    """Return (commit_sha, dirty). Tolerates a missing/absent git repo (returns (None, False))."""
    cwd = str(repo) if repo else None
    try:
        sha = subprocess.run(["git", "rev-parse", "HEAD"], cwd=cwd, capture_output=True,
                             text=True, check=True).stdout.strip()
        porcelain = subprocess.run(["git", "status", "--porcelain"], cwd=cwd, capture_output=True,
                                   text=True, check=True).stdout
        return sha or None, bool(porcelain.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None, False


@dataclass
class RunManifest:
    run_id: str
    system: str
    method: str
    config_hash: str
    command: str
    status: str = "planned"
    schema_version: int = SCHEMA_VERSION
    git_commit: str | None = None
    git_dirty: bool = False
    seeds: list[int] = field(default_factory=list)
    backend: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    input_checksums: dict[str, str] = field(default_factory=dict)
    output_paths: list[str] = field(default_factory=list)
    retention: str = "exploratory"
    replaced_by: str | None = None
    failure_reason: str | None = None

    def __post_init__(self) -> None:
        if self.status not in STATUS_VALUES:
            raise ValueError(f"invalid status {self.status!r}; allowed {sorted(STATUS_VALUES)}")
        if self.retention not in RETENTION_VALUES:
            raise ValueError(f"invalid retention {self.retention!r}; allowed {sorted(RETENTION_VALUES)}")

    @classmethod
    def new(cls, *, run_id: str, system: str, method: str, config_hash: str, command: str,
            seeds: list[int] | None = None, backend: str | None = None,
            retention: str = "exploratory", repo: Path | None = None,
            input_checksums: dict[str, str] | None = None) -> "RunManifest":
        """Construct a fresh 'planned' manifest, recording current git state."""
        sha, dirty = git_state(repo)
        return cls(run_id=run_id, system=system, method=method, config_hash=config_hash,
                   command=command, seeds=list(seeds or []), backend=backend, retention=retention,
                   git_commit=sha, git_dirty=dirty, input_checksums=dict(input_checksums or {}))

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=True)

    @classmethod
    def from_json(cls, text: str) -> "RunManifest":
        return cls(**json.loads(text))


def write_manifest(directory: Path, manifest: RunManifest, *, overwrite: bool = False) -> Path:
    """Write ``manifest.json`` into ``directory`` atomically. Refuse to overwrite unless ``overwrite``."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / MANIFEST_NAME
    if target.exists() and not overwrite:
        raise FileExistsError(f"{target} exists (use overwrite=True or update_status)")
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(manifest.to_json(), encoding="utf-8")
    os.replace(tmp, target)  # atomic within the same filesystem
    return target


def read_manifest(directory: Path) -> RunManifest:
    return RunManifest.from_json((Path(directory) / MANIFEST_NAME).read_text(encoding="utf-8"))


def update_status(directory: Path, new_status: str, **fields: Any) -> RunManifest:
    """Load the manifest, apply a status transition (+ optional fields), rewrite atomically.

    Stamps ``started_at`` on -> running and ``completed_at`` on -> completed/failed if unset.
    """
    if new_status not in STATUS_VALUES:
        raise ValueError(f"invalid status {new_status!r}; allowed {sorted(STATUS_VALUES)}")
    m = read_manifest(directory)
    m.status = new_status
    for k, v in fields.items():
        if not hasattr(m, k):
            raise AttributeError(f"RunManifest has no field {k!r}")
        setattr(m, k, v)
    if new_status == "running" and not m.started_at:
        m.started_at = _utcnow()
    if new_status in ("completed", "failed") and not m.completed_at:
        m.completed_at = _utcnow()
    m.__post_init__()  # re-validate enums after field updates
    write_manifest(directory, m, overwrite=True)
    return m
