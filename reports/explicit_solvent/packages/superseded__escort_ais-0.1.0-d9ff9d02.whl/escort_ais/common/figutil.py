"""figutil.py — small shared helpers for consistent, referenceable figures (panel letters, etc.)."""
from __future__ import annotations

import string


def panel_labels(fig, size: int = 13, x: float = -0.04, y: float = 1.04, weight: str = "bold"):
    """Label each *visible* subplot of `fig` with A, B, C, ... (row-major) in its top-left corner.

    Only axes with their frame turned on (`ax.axison`, i.e. not `ax.axis('off')`) are labelled, so grid
    figures that hide unused cells get contiguous letters. Call once, just before `fig.savefig`."""
    axes = [a for a in fig.axes if getattr(a, "axison", True)]
    for a, lab in zip(axes, string.ascii_uppercase):
        a.text(x, y, lab, transform=a.transAxes, fontsize=size, fontweight=weight, va="bottom", ha="right")


def zoom_trace_figure(out_path, traces, transform, pair, ylabel, ref, ref_se,
                      xlim, title="", xlabel="total simulated MD (ns), PREP included",
                      dpi: int = 185, ylim=None):
    """Write a SINGLE-panel figure of cumulative traces restricted to *xlim*.

    The wide convergence panels are dominated by the long REMD arms, so the first tens of ns --
    where the AIS-based estimators do all their work and where the REMD arms are still nowhere near
    their reference -- occupy a few percent of the axis. This redraws exactly the same traces over a
    chosen budget window.

    *transform* maps a free energy in kT to whatever the y-axis shows (identity, or the sigmoid to a
    population); *pair* maps and re-sorts an interval, which matters because that sigmoid is
    monotone decreasing. y limits are taken from the data actually inside *xlim*, not from the wide
    figure's limits, or the zoom would inherit a window chosen for a different range.

    Parameters
    ----------
    traces : list of ``(x, y_kT, plot_kwargs)``
    """
    import matplotlib.pyplot as plt
    import numpy as np

    lo, hi = float(xlim[0]), float(xlim[1])
    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    ax.axhspan(*pair(ref - 2 * ref_se, ref + 2 * ref_se), color="#4a4a4a", alpha=0.14, lw=0,
               label="REMD reference ($\\pm2$ s.e.)")
    ax.axhline(transform(ref), color="#4a4a4a", lw=0.9, ls="--")

    inside = []
    for x, y, kw in traces:
        x = np.asarray(x, float)
        keep = np.flatnonzero((x >= lo) & (x <= hi))
        if keep.size == 0:
            continue
        # Extend by one sample on each side so a sparsely sampled arm still enters and leaves the
        # axes as a line.  A trace evaluated every 10th generation can have a SINGLE point inside a
        # narrow window -- window-strat-cBAR has exactly one below 100 ns, because its MBAR +
        # Zwanzig hot term is strided -- and would otherwise render as an unconnected dot.  The
        # segment drawn to the neighbour outside the window is the same straight-line interpolation
        # the wide figure already shows between evaluated points; the markers keep the actual
        # evaluations visible, so nothing is implied that the data does not contain.
        i0, i1 = max(0, keep[0] - 1), min(len(x) - 1, keep[-1] + 1)
        sl = slice(i0, i1 + 1)
        ty = transform(np.asarray(y, float)[sl])
        ax.plot(x[sl], ty, **kw)
        inside.append(transform(np.asarray(y, float)[keep]))   # y limits from the window itself

    if ylim is not None:
        # A TRUE zoom: the y window is inherited from the full-range panel, so this figure is that
        # panel with a narrower x and nothing else changed.  Autoscaling instead re-stretches the
        # vertical axis, which makes the same curves look like different data laid side by side.
        ax.set_ylim(*ylim)
    elif inside:
        flat = np.concatenate(inside)
        edges = np.concatenate([flat, np.asarray(pair(ref - 2 * ref_se, ref + 2 * ref_se))])
        span = float(edges.max() - edges.min())
        ax.set_ylim(float(edges.min()) - 0.06 * span, float(edges.max()) + 0.06 * span)
    ax.set_xlim(lo, hi)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if title:
        ax.set_title(title, fontsize=9.5, loc="left")
    # Compact, upper left, two columns: nine entries at the default spacing occupied most of the
    # plotting area on a narrow zoom window.  Two columns keep it short rather than tall, and the
    # tightened pads matter more than the font size for the footprint.
    ax.legend(fontsize=6.0, loc="upper left", frameon=True, facecolor="white", edgecolor="none",
              framealpha=0.9, ncol=2, handlelength=1.1, handletextpad=0.4, columnspacing=0.8,
              labelspacing=0.28, borderpad=0.35, borderaxespad=0.4)
    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi, bbox_inches="tight")
    print(f"wrote {out_path}")
    return fig
