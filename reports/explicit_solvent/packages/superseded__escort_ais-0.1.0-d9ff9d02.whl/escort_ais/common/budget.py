"""budget.py — total force-evaluation accounting for matched-budget method comparison.

Every overdamped-Langevin step is one force evaluation. A method's total budget is the sum over its components
(hot MD, forward AIS, reverse AIS, umbrella sampling, cold kinetics). We also track the maximum *sequential*
trajectory length (embarrassingly-parallel wall-clock depth) separately from aggregate work.
"""
from __future__ import annotations


class Budget:
    """Accumulate force evaluations by component + the longest single sequential trajectory."""

    def __init__(self):
        self.components = {}
        self.max_sequential = 0

    def add(self, component, force_evals, sequential_len=None):
        self.components[component] = self.components.get(component, 0) + int(force_evals)
        if sequential_len is not None:
            self.max_sequential = max(self.max_sequential, int(sequential_len))
        return self

    # ── force-eval counts of the primitives (all in Langevin steps) ──
    @staticmethod
    def langevin(n_walkers, n_steps, burn=0):
        return int(n_walkers) * (int(n_steps) + int(burn))

    @staticmethod
    def ais(n_shots, m_windows, freq):
        """One AIS shot = m_windows λ-steps × freq MD steps of propagation."""
        return int(n_shots) * int(m_windows) * int(freq)

    def total(self):
        return int(sum(self.components.values()))

    def table(self):
        return dict(self.components, total=self.total(), max_sequential=int(self.max_sequential))
