#!/usr/bin/env python3
"""top100w_cfg.py — experiment-path selector for the top100w pipeline.

The top100w pipeline (select seeds -> cold MD -> RITE -> reverse AIS -> estimators)
is run for two forward seed sources, chosen by the TOP100W_EXP env var:

  diverse20_100ps  (default) : forward AIS seeded from the REMD hot replica_03
  remdfree_hot5ns            : forward AIS seeded from a STANDALONE 5 ns hot MD
                               (no REMD) -> realizes the REMD-free cost variant

Shared across both: the 22-atom topology PDB (geometry-only, for loading DCDs) and
the GOLD reverse (REMD replica_00 2 ps backward), which is the ground-truth cold
ensemble both variants are validated against.
"""
from __future__ import annotations

import os
from pathlib import Path

from escort_ais.common.paths import project_root
ROOT = project_root()
EXP = os.environ.get("TOP100W_EXP", "diverse20_100ps")

# REMD root (reference + gold reverse; also hot replica for the default variant)
REMD_DIR = ROOT / "data/alanine_dipeptide/md/ff19sb_gbn2_even_4rep_300K_remd_250ns"

_EXP = {
    "diverse20_100ps": dict(
        FWD=ROOT / "data/alanine_dipeptide/2026-06-17-top100w-2ps/step_forward_ais",
        RUNS=ROOT / "data/runs/top100w_diverse20_100ps",
        REVRUN=ROOT / "data/alanine_dipeptide/2026-06-17-top100w-revais",
        RESULTS=ROOT / "results/top100w_diverse20_100ps",
        HOT_SRC=REMD_DIR / "replica_03/trajectory.dcd",
        HOT_BURN=500,        # 500 frames @ 10 ps = 5 ns REMD burn-in
    ),
    "remdfree_hot5ns": dict(
        FWD=ROOT / "data/alanine_dipeptide/2026-06-18-top100w-hotmd5ns/step_forward_ais",
        RUNS=ROOT / "data/runs/top100w_remdfree_hot5ns",
        REVRUN=ROOT / "data/alanine_dipeptide/2026-06-18-top100w-hotmd5ns-revais",
        RESULTS=ROOT / "results/top100w_remdfree_hot5ns",
        HOT_SRC=ROOT / "data/alanine_dipeptide/2026-06-15-crooks-tram/step1_hot_md/trajectory.dcd",
        HOT_BURN=500,        # 500 frames @ 1 ps = 500 ps hot-MD burn-in
    ),
    # Fully REMD-free "faster than REMD" experiment: forward AIS seeded from the
    # first 6 ns of a STANDALONE 250 ns s=0.4 single-walker hot MD (10 ps/frame),
    # fresh kinetic basins built from the cold MD, reverse drawn uniformly with the
    # forward-landing ratio (no RITE).
    "remdfree_s04": dict(
        FWD=ROOT / "data/alanine_dipeptide/2026-06-18-remdfree-s04/step_forward_ais",
        RUNS=ROOT / "data/runs/remdfree_s04",
        REVRUN=ROOT / "data/alanine_dipeptide/2026-06-18-remdfree-s04-revais",
        RESULTS=ROOT / "results/remdfree_s04",
        HOT_SRC=ROOT / "data/alanine_dipeptide/md/etkdg_v3_seed_20260526_n20000_gbn2_cuda_250ns_scale_0p4/trajectory.dcd",
        HOT_BURN=100,        # 100 frames @ 10 ps = 1 ns hot-MD burn-in
    ),
}
if EXP not in _EXP:
    raise SystemExit(f"TOP100W_EXP={EXP!r} not in {list(_EXP)}")

_c = _EXP[EXP]
FWD: Path = _c["FWD"]
RUNS: Path = _c["RUNS"]
REVRUN: Path = _c["REVRUN"]
RESULTS: Path = _c["RESULTS"]
HOT_SRC: Path = _c["HOT_SRC"]
HOT_BURN: int = _c["HOT_BURN"]

# sweep mode: REMDFREE_I=i (1..20) redirects the remdfree_s04 paths to per-i dirs and
# (in the forward runner) sets the hot-MD seed window to [1, 1+5i] ns.
if EXP == "remdfree_s04" and os.environ.get("REMDFREE_I"):
    _I = int(os.environ["REMDFREE_I"])
    _SW = ROOT / "data/alanine_dipeptide/2026-06-18-remdfree-s04-sweep"
    FWD = _SW / f"i{_I:02d}/step_forward_ais"
    REVRUN = _SW / f"i{_I:02d}-revais"
    RUNS = ROOT / "data/runs/remdfree_s04_sweep" / f"i{_I:02d}"
    RESULTS = ROOT / "results/remdfree_s04_sweep" / f"i{_I:02d}"

# shared (geometry-only topology + gold REMD reverse)
TOP_PDB = ROOT / "data/alanine_dipeptide/2026-06-17-top100w-2ps/seed_hot/start_structure.pdb"
GOLD_REV = ROOT / "data/alanine_dipeptide/2026-06-17-top100w-2ps/step_backward_ais"
