#!/usr/bin/env python3
"""macrocycle_cfg.py — centralized per-molecule paths + derived constants for the macrocycle AIS/BAR pipeline.

The cyclosporin run scripts hardcoded `data/cyclosporin/...` paths and `n_solute_atoms=196`. This module
resolves those per molecule name (default layout `data/<name>/...`) and reads the solute count + SMILES
from the topology `config.json` written by build_macrocycle_topology.py, so nothing molecule-specific is
duplicated in the drivers.

Usage:
    from escort_ais.common.macrocycle_cfg import load
    cfg = load("rgd")
    cfg.prmtop, cfg.omega, cfg.basin_model_path, cfg.n_solute_atoms, cfg.smiles
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from escort_ais.common.paths import project_root
ROOT = project_root()


@dataclass
class MoleculeConfig:
    name: str
    topo: Path
    basins: Path
    basin_model_set: str = "backbone"
    remd: Path | None = None

    @property
    def top_pdb(self) -> Path:
        return self.topo / "topology.pdb"

    @property
    def prmtop(self) -> Path:
        return self.topo / "system_scale_1p0.prmtop"

    @property
    def inpcrd(self) -> Path:
        return self.topo / "system_scale_1p0.inpcrd"

    @property
    def omega(self) -> Path:
        return self.topo / "omega_exclude_bonds.npy"

    @property
    def basin_model_path(self) -> Path:
        return self.basins / f"basin_model_{self.basin_model_set}.pkl"

    def _config(self) -> dict:
        return json.loads((self.topo / "config.json").read_text())

    @property
    def n_solute_atoms(self) -> int:
        return int(self._config()["n_solute_atoms"])

    @property
    def smiles(self) -> str | None:
        return self._config().get("ligand_source")


def load(name: str = "rgd", topo_dir: str | Path | None = None,
         basins_dir: str | Path | None = None, remd_dir: str | Path | None = None,
         basin_model_set: str = "backbone") -> MoleculeConfig:
    return MoleculeConfig(
        name=name,
        topo=Path(topo_dir) if topo_dir else ROOT / "data" / name / "topology",
        basins=Path(basins_dir) if basins_dir else ROOT / "data" / name / "basins",
        remd=Path(remd_dir) if remd_dir else None,
        basin_model_set=basin_model_set,
    )
