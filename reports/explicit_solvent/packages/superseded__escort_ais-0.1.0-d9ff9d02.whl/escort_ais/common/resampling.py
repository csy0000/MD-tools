"""resampling.py — Systematic and stratified resampling for importance-sampling stages.

All functions are pure numpy — no OpenMM, no deeptime. Designed to implement
the resampling stages (hot→forward-AIS starts; AIS endpoints→cold starts) of
the basin free-energy pipeline.

Statistical contract
--------------------
After resampling, the returned parent indices produce an **equal-weight** empirical
sample from the target distribution. Do NOT carry the old log-weights forward.
"""
from __future__ import annotations

import numpy as np
from scipy.special import logsumexp


# ---------------------------------------------------------------------------
# ESS
# ---------------------------------------------------------------------------

def effective_sample_size(log_weights: np.ndarray) -> float:
    """ESS = (Σ w_i)² / Σ w_i² in log space (logsumexp-stable).

    Parameters
    ----------
    log_weights : (K,) unnormalized log-weights

    Returns
    -------
    float  ESS ∈ (0, K]
    """
    lw = np.asarray(log_weights, dtype=np.float64)
    log_sum_w = logsumexp(lw)
    log_sum_w2 = logsumexp(2.0 * lw)
    return float(np.exp(2.0 * log_sum_w - log_sum_w2))


def normalized_weights(log_weights: np.ndarray) -> np.ndarray:
    """Return normalized weights summing to 1 (logsumexp-stable)."""
    lw = np.asarray(log_weights, dtype=np.float64)
    log_z = logsumexp(lw)
    return np.exp(lw - log_z)


# ---------------------------------------------------------------------------
# Systematic resampling
# ---------------------------------------------------------------------------

def systematic_resample(
    log_weights: np.ndarray,
    n_out: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Systematic resampling — single random draw, lowest variance.

    Parameters
    ----------
    log_weights : (K,) unnormalized log-weights (any scale; logsumexp-normalized internally)
    n_out : number of output (equal-weight) samples to draw
    rng : seeded numpy Generator

    Returns
    -------
    parent_indices : (n_out,) int64 — indices into the original K particles;
        equal-weight after resampling (do NOT reuse old weights).
    """
    w = normalized_weights(log_weights)
    K = len(w)
    cumsum = np.cumsum(w)
    cumsum[-1] = 1.0  # guard float rounding

    # Systematic: one uniform draw u ~ U[0, 1/n_out), then n_out evenly-spaced positions
    u0 = rng.uniform(0.0, 1.0 / n_out)
    positions = u0 + np.arange(n_out) / n_out

    indices = np.searchsorted(cumsum, positions).astype(np.int64)
    indices = np.clip(indices, 0, K - 1)
    return indices


# ---------------------------------------------------------------------------
# Stratified resampling
# ---------------------------------------------------------------------------

def stratified_resample(
    log_weights: np.ndarray,
    n_out: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Stratified resampling — independent uniform draw per stratum.

    Slightly higher variance than systematic but identically unbiased.

    Parameters
    ----------
    log_weights : (K,) unnormalized log-weights
    n_out : number of output samples
    rng : seeded numpy Generator

    Returns
    -------
    parent_indices : (n_out,) int64
    """
    w = normalized_weights(log_weights)
    K = len(w)
    cumsum = np.cumsum(w)
    cumsum[-1] = 1.0

    # One independent uniform per stratum [k/n_out, (k+1)/n_out)
    strata_starts = np.arange(n_out) / n_out
    u = rng.uniform(size=n_out) / n_out
    positions = strata_starts + u

    indices = np.searchsorted(cumsum, positions).astype(np.int64)
    indices = np.clip(indices, 0, K - 1)
    return indices


# ---------------------------------------------------------------------------
# Convenience: resample a coordinate array
# ---------------------------------------------------------------------------

def resample_positions(
    positions: np.ndarray,
    log_weights: np.ndarray,
    n_out: int,
    rng: np.random.Generator,
    method: str = "systematic",
) -> tuple[np.ndarray, np.ndarray]:
    """Resample position array according to log-weights.

    Parameters
    ----------
    positions : (K, ...) array of particle states
    log_weights : (K,) unnormalized log-weights
    n_out : output sample count
    rng : seeded Generator
    method : "systematic" | "stratified"

    Returns
    -------
    resampled_positions : (n_out, ...) equal-weight positions
    parent_indices : (n_out,) int64
    """
    if method == "systematic":
        idx = systematic_resample(log_weights, n_out, rng)
    elif method == "stratified":
        idx = stratified_resample(log_weights, n_out, rng)
    else:
        raise ValueError(f"Unknown method {method!r}; use 'systematic' or 'stratified'.")
    return positions[idx], idx
