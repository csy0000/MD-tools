"""wasserstein.py — W2 distance on the (phi, psi) torus.

Two methods are provided:

4D torus embedding (default, ``w2_torus``)
    Embeds (phi,psi) as (cos_phi, sin_phi, cos_psi, sin_psi) ∈ R⁴ so that
    the Euclidean (chordal) distance is naturally periodic.  Exact W2 is
    solved via POT ot.emd2; large point clouds are handled by repeated random
    subsampling.  Units: dimensionless (chordal, ~radian-scale).

2D histogram (``w2_histogram_2d``)
    Bins (phi, psi) into an N×N histogram over [-180,180]² and solves exact
    OT with a periodic squared-angle cost (minimum-image convention).
    Deterministic — no subsampling noise.  Units: degrees.

All angle inputs are in **degrees**.

Public API
----------
torus_embed(phi_deg, psi_deg)                   -> (N, 4) float64
w2_torus(phi_a, psi_a, phi_b, psi_b, ...)       -> (mean: float, std: float)
self_convergence_curve(phi, psi, ...)            -> (times_ns, w2_mean, w2_std)
cross_convergence_curve(phi, psi, phi_ref, psi_ref, ...) -> (times_ns, w2_mean, w2_std)
w2_histogram_2d(phi_a, psi_a, phi_b, psi_b, ...) -> float   [degrees]
self_convergence_curve_2d(phi, psi, ...)         -> (times_ns, w2, zeros)
"""

from __future__ import annotations

import numpy as np
from typing import Tuple


# ---------------------------------------------------------------------------
# Core helpers
# ---------------------------------------------------------------------------

def torus_embed(phi_deg: np.ndarray, psi_deg: np.ndarray) -> np.ndarray:
    """Map (phi, psi) in degrees to a (N, 4) embedding on the flat torus.

    Each row is  [cos(phi), sin(phi), cos(psi), sin(psi)].
    Row norm is always sqrt(2), so the embedding is isometric (up to a constant
    factor) and periodicity is handled naturally by Euclidean distance.

    Parameters
    ----------
    phi_deg, psi_deg : array_like, shape (N,)
        Dihedral angles in degrees.

    Returns
    -------
    X : np.ndarray, shape (N, 4)
    """
    phi = np.asarray(phi_deg, dtype=np.float64)
    psi = np.asarray(psi_deg, dtype=np.float64)
    phi_r = np.deg2rad(phi)
    psi_r = np.deg2rad(psi)
    return np.column_stack([np.cos(phi_r), np.sin(phi_r),
                            np.cos(psi_r), np.sin(psi_r)])


def _w2_exact(X: np.ndarray, Y: np.ndarray) -> float:
    """Exact W2 between two equal-weight point clouds via POT's exact OT solver.

    Builds the squared-Euclidean cost matrix M, solves the linear-program
    transport problem, and returns sqrt of the optimal transport cost.

    Parameters
    ----------
    X, Y : np.ndarray, shape (n, d)
        Point clouds (will be treated as empirical distributions with uniform
        weights 1/n).

    Returns
    -------
    w2 : float
        W2 distance in embedding units.
    """
    import ot  # lazy import — ot is only needed here

    n = len(X)
    m = len(Y)
    a = np.ones(n, dtype=np.float64) / n
    b = np.ones(m, dtype=np.float64) / m

    # Squared Euclidean cost matrix
    # Use broadcasting; for n=2000, d=4 this is 2000*2000*4 doubles ~ 128 MB — acceptable
    diff = X[:, None, :] - Y[None, :, :]   # (n, m, d)
    M = (diff * diff).sum(axis=-1)          # (n, m)

    ot_cost = ot.emd2(a, b, M, numItermax=200_000)
    return float(np.sqrt(max(0.0, ot_cost)))


# ---------------------------------------------------------------------------
# Public W2 function
# ---------------------------------------------------------------------------

def w2_torus(
    phi_a: np.ndarray,
    psi_a: np.ndarray,
    phi_b: np.ndarray,
    psi_b: np.ndarray,
    n_subsample: int = 2000,
    n_repeats: int = 5,
    seed: int = 0,
) -> Tuple[float, float]:
    """W2 distance between two (phi, psi) ensembles on the torus.

    Large ensembles are handled by repeated random subsampling; each replicate
    draws n_subsample frames independently from each side and the reported
    value is the mean (and std) over n_repeats replicates.

    Parameters
    ----------
    phi_a, psi_a : array_like, shape (N,)
        First ensemble in degrees.
    phi_b, psi_b : array_like, shape (M,)
        Second ensemble in degrees.
    n_subsample : int
        Number of frames to draw per side per replicate.  If N < n_subsample
        all frames are used (same for M).
    n_repeats : int
        Number of independent subsamples to average over.
    seed : int
        Base seed for reproducibility; replicate r uses seed + r.

    Returns
    -------
    mean : float
        Mean W2 over replicates.
    std : float
        Std of W2 over replicates (0.0 when n_repeats == 1).
    """
    phi_a = np.asarray(phi_a, dtype=np.float64)
    psi_a = np.asarray(psi_a, dtype=np.float64)
    phi_b = np.asarray(phi_b, dtype=np.float64)
    psi_b = np.asarray(psi_b, dtype=np.float64)

    Xa = torus_embed(phi_a, psi_a)
    Xb = torus_embed(phi_b, psi_b)

    na, nb = len(Xa), len(Xb)
    na_use = min(na, n_subsample)
    nb_use = min(nb, n_subsample)

    vals = []
    for r in range(n_repeats):
        rng = np.random.default_rng(seed + r)
        idx_a = rng.choice(na, size=na_use, replace=False) if na > na_use else np.arange(na)
        idx_b = rng.choice(nb, size=nb_use, replace=False) if nb > nb_use else np.arange(nb)
        vals.append(_w2_exact(Xa[idx_a], Xb[idx_b]))

    vals = np.array(vals)
    return float(vals.mean()), float(vals.std())


# ---------------------------------------------------------------------------
# Self-convergence curve
# ---------------------------------------------------------------------------

def self_convergence_curve(
    phi: np.ndarray,
    psi: np.ndarray,
    times_ns: np.ndarray,
    frame_ps: float = 10.0,
    ref_start_ns: float = 125.0,
    n_subsample: int = 2000,
    n_repeats: int = 5,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute W2(cumulative[0, t], own-final-half) for a range of times.

    For each time t in ``times_ns``, the query ensemble is the cumulative
    trajectory from frame 0 through frame int(t * 1000 / frame_ps) (inclusive).
    The reference ensemble is frames from ``ref_start_ns`` onward.

    Parameters
    ----------
    phi, psi : np.ndarray, shape (T,)
        Full dihedral time series in degrees.
    times_ns : np.ndarray
        Grid of query times in ns.
    frame_ps : float
        Spacing between saved frames in ps (default 10 ps → 25,000 frames at 250 ns).
    ref_start_ns : float
        Start of the reference (final-half) window in ns.
    n_subsample, n_repeats, seed
        Passed to w2_torus.

    Returns
    -------
    times_ns : np.ndarray
        Same as input times_ns (for convenience).
    w2_mean : np.ndarray, shape (len(times_ns),)
    w2_std  : np.ndarray, shape (len(times_ns),)
    """
    phi = np.asarray(phi, dtype=np.float64)
    psi = np.asarray(psi, dtype=np.float64)
    times_ns = np.asarray(times_ns, dtype=np.float64)

    ref_start_frame = int(ref_start_ns * 1000.0 / frame_ps)
    phi_ref = phi[ref_start_frame:]
    psi_ref = psi[ref_start_frame:]

    w2_mean = np.zeros(len(times_ns))
    w2_std  = np.zeros(len(times_ns))

    for i, t in enumerate(times_ns):
        end_frame = int(t * 1000.0 / frame_ps)
        end_frame = max(end_frame, 1)
        phi_q = phi[:end_frame]
        psi_q = psi[:end_frame]
        mu, sig = w2_torus(
            phi_q, psi_q, phi_ref, psi_ref,
            n_subsample=n_subsample,
            n_repeats=n_repeats,
            seed=seed,
        )
        w2_mean[i] = mu
        w2_std[i]  = sig

    return times_ns, w2_mean, w2_std


# ---------------------------------------------------------------------------
# 2D histogram W2 (periodic, degrees)
# ---------------------------------------------------------------------------

def w2_histogram_2d(
    phi_a: np.ndarray,
    psi_a: np.ndarray,
    phi_b: np.ndarray,
    psi_b: np.ndarray,
    n_bins: int = 36,
) -> float:
    """W2 between two (phi, psi) ensembles via 2D histogram OT.

    Bins both ensembles into an n_bins × n_bins grid over [-180, 180]² and
    solves exact OT with a periodic squared-angle cost (minimum-image
    convention on the torus).  Deterministic — no subsampling noise.

    Parameters
    ----------
    phi_a, psi_a : array_like, shape (N,)
        First ensemble in degrees.
    phi_b, psi_b : array_like, shape (M,)
        Second ensemble in degrees.
    n_bins : int
        Number of bins per axis (default 36 → 10° bins).
        Cost matrix size is n_bins⁴ floats; 36⁴ ≈ 1.3M (fast, ~10 MB).

    Returns
    -------
    w2 : float
        W2 distance in **degrees** (sqrt of optimal squared-angle transport cost).
    """
    import ot  # lazy import

    edges   = np.linspace(-180.0, 180.0, n_bins + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])

    ha, _, _ = np.histogram2d(np.asarray(phi_a), np.asarray(psi_a),
                               bins=[edges, edges], density=False)
    hb, _, _ = np.histogram2d(np.asarray(phi_b), np.asarray(psi_b),
                               bins=[edges, edges], density=False)

    a = ha.flatten().astype(np.float64)
    b = hb.flatten().astype(np.float64)
    a /= a.sum()
    b /= b.sum()

    # Build periodic squared-angle cost matrix between all bin-center pairs
    phi_c, psi_c = np.meshgrid(centers, centers, indexing="ij")
    coords = np.column_stack([phi_c.ravel(), psi_c.ravel()])  # (n_bins², 2)

    diff = coords[:, None, :] - coords[None, :, :]            # (n², n², 2)
    diff = diff - 360.0 * np.round(diff / 360.0)              # min-image wrap
    M    = (diff * diff).sum(axis=-1)                          # squared deg²

    ot_cost = ot.emd2(a, b, M, numItermax=500_000)
    return float(np.sqrt(max(0.0, ot_cost)))


def cross_convergence_curve(
    phi: np.ndarray,
    psi: np.ndarray,
    phi_ref: np.ndarray,
    psi_ref: np.ndarray,
    times_ns: np.ndarray,
    frame_ps: float = 10.0,
    n_subsample: int = 2000,
    n_repeats: int = 5,
    seed: int = 0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """W2(cumulative[0, t] of (phi,psi), fixed external reference) over time.

    Unlike self_convergence_curve, the reference ensemble is supplied by the
    caller and is not sliced from the query trajectory.  Intended use: compare
    the physical replica of one sampler against the *other* sampler's converged
    distribution (the other setup's final-half).

    Parameters
    ----------
    phi, psi : np.ndarray, shape (T,)
        Query trajectory in degrees.
    phi_ref, psi_ref : np.ndarray, shape (M,)
        Fixed reference ensemble in degrees (e.g. final-half of the other setup).
    times_ns : np.ndarray
        Grid of query times in ns.
    frame_ps : float
        Spacing between saved frames in ps.
    n_subsample, n_repeats, seed
        Passed to w2_torus.

    Returns
    -------
    times_ns : np.ndarray
    w2_mean  : np.ndarray, shape (len(times_ns),)
    w2_std   : np.ndarray, shape (len(times_ns),)
    """
    phi      = np.asarray(phi,     dtype=np.float64)
    psi      = np.asarray(psi,     dtype=np.float64)
    phi_ref  = np.asarray(phi_ref, dtype=np.float64)
    psi_ref  = np.asarray(psi_ref, dtype=np.float64)
    times_ns = np.asarray(times_ns, dtype=np.float64)

    w2_mean = np.zeros(len(times_ns))
    w2_std  = np.zeros(len(times_ns))

    for i, t in enumerate(times_ns):
        end_frame = int(t * 1000.0 / frame_ps)
        end_frame = max(end_frame, 1)
        mu, sig = w2_torus(
            phi[:end_frame], psi[:end_frame],
            phi_ref, psi_ref,
            n_subsample=n_subsample,
            n_repeats=n_repeats,
            seed=seed,
        )
        w2_mean[i] = mu
        w2_std[i]  = sig

    return times_ns, w2_mean, w2_std


def self_convergence_curve_2d(
    phi: np.ndarray,
    psi: np.ndarray,
    times_ns: np.ndarray,
    frame_ps: float = 10.0,
    ref_start_ns: float = 125.0,
    n_bins: int = 36,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute 2D-histogram W2(cumulative[0,t], own-final-half) over time.

    Same interface as self_convergence_curve but uses w2_histogram_2d.
    Returns zeros for w2_std since the method is deterministic.

    Returns
    -------
    times_ns : np.ndarray
    w2       : np.ndarray   (degrees)
    w2_std   : np.ndarray   (all zeros — deterministic method)
    """
    phi      = np.asarray(phi,      dtype=np.float64)
    psi      = np.asarray(psi,      dtype=np.float64)
    times_ns = np.asarray(times_ns, dtype=np.float64)

    ref_start_frame = int(ref_start_ns * 1000.0 / frame_ps)
    phi_ref = phi[ref_start_frame:]
    psi_ref = psi[ref_start_frame:]

    w2_vals = np.zeros(len(times_ns))

    for i, t in enumerate(times_ns):
        end_frame = max(int(t * 1000.0 / frame_ps), 1)
        w2_vals[i] = w2_histogram_2d(
            phi[:end_frame], psi[:end_frame],
            phi_ref, psi_ref,
            n_bins=n_bins,
        )

    return times_ns, w2_vals, np.zeros_like(w2_vals)
