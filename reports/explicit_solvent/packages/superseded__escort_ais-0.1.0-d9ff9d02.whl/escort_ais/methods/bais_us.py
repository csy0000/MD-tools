#!/usr/bin/env python3
"""bais_us.py — BAIS-US: a FLAT-BOTTOM torsion-CV umbrella PMF-reconstruction tool on the BAIS graph.

BAIS-US is **not** an independent population estimator and uses **no reference state and no TI** (route-2 is
removed). Its job is to **reconstruct the microstate-level PMF** from overlapping umbrella windows, with **BAR
supplying the inter-basin free energies**. For each committed (GMM-by-BIC) basin B_i we add a FLAT-BOTTOM
restraint on the native periodic torsion CV

    D_i(x) = Σ_k 2[1 − cos(φ_k(x) − φ_ref,k)]  = ‖feat(x) − centre_i‖²    (BAIS-US_theory §4.1, eq. cv)

built as an OpenMM ``CustomTorsionForce`` summed inside a ``CustomCVForce``, biased by the flat-bottom wall

    U_i(x) = ½ · k_i · max(0, √D_i(x) − hw_i)²    (ZERO inside √D ≤ hw_i, harmonic wall beyond).

This is the molecular multi-torsion analogue of the toy `flatbottom_bias` / `spring_from_committor`
(`scripts/bais_we_us_converged_toy.py`), reusing the same flat-bottom form as
`basin_restraint.flatbottom_torsion_force` but on the √Dcv reach. The flat interior half-width is the GMM core
hw_i = w_i and the wall reaches U = E*=5 kT near the committor midpoint d_ij/2, so (LINEAR √Dcv metric):

    d_ij = √( torsion_D(mean_i, mean_j) )     (nearest-neighbour LINEAR separation, feature-chord units)
    w_i  = √( trace Σ_i ) = hw_i               (LINEAR core width from the GMM covariance)
    k_i  = clip( 2 · E* / max(d_ij/2, ε)², k_min=5, k_max=50 )   (E*=5 kT; MEDIAN-to-median reach, see
                                              spring_from_gmm_overlap — NOT the old wall-to-wall d_ij/2 − w_i).

Reconstruction: overlap-connected clusters of windows (union-find on window-sample overlap) → WHAM (self-
consistent, no pymbar) removes the KNOWN flat-bottom bias and gives the RELATIVE microstate PMF within each
cluster; **BAR sets each cluster's absolute level** across the high barrier (the SOFT flat-bottom BAR π when
`soft_bar_inputs` is supplied, else the endpoint π^BAR). The microstate PMF is `F(node) = [WHAM shape within
cluster] + [BAR offset between clusters]`; populations follow by binning.

The flat interior is unbiased ⇒ the confined cold pool IS the within-basin Boltzmann (WHAM only removes the
wall). vM-BIC over-splits are collapsed BEFORE the walls by `merge_oversplit_windows` (median E*/k_max trigger +
barrier veto); the k_max=50 clamp then guards any residual near-coincident pair.

This module is estimator code only — the BAUS driver (`run_bais_standalone.py --method us`, reservoir-free)
supplies the confident basin graph (centres + covariances + soft-BAR / reverse-from-window works) and one seed
config per window, and calls `run_bais_us`.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

E_STAR_DEFAULT = 5.0      # kT — wall energy reached AT the committor midpoint d_ij/2 (toy spring_from_committor)
K_MAX_DEFAULT = 50.0      # kT/Dcv-unit — spring clamp (mirrors reference.json k_merged_basins params)
K_MIN_DEFAULT = 5.0       # kT/Dcv-unit — spring FLOOR: when the median separation d_ij/2 is large the wall would
#                           be softer than this; clamp up so a well-separated window is never under-confined.
REACH_EPS_DEFAULT = 0.09  # rad-like floor on d_ij/2 (linear √Dcv units, ~5°)
OVERLAP_THRESH_DEFAULT = 0.05   # min histogram overlap (over microstate nodes) to connect two windows
# Back-compat alias (older callers may pass E_reach); the flat-bottom wall now reaches E*=5 kT, not 0.5 kT.
E_REACH_DEFAULT = E_STAR_DEFAULT


# ── the native periodic torsion CV (pure geometry) ──────────────────────────────────────────────
def basin_reference_angles(centre_feat, d):
    """φ_ref,k (rad) from a basin/node centre feature row (cos_0..cos_{d-1}, sin_0..sin_{d-1}): atan2(sin_k, cos_k)."""
    cf = np.asarray(centre_feat, float)
    return np.arctan2(cf[d:2 * d], cf[:d])


def torsion_D(angles, phi_ref):
    """CV value D = Σ_k 2[1 − cos(φ_k − φ_ref,k)] (periodic, ≥0, 0 at the centre). angles (...,d) rad.

    Note D(x) = ‖feat(x) − feat(centre)‖² in (cos,sin) feature space (since 2(1−cosΔ)=‖Δ(cos,sin)‖²)."""
    return np.sum(2.0 * (1.0 - np.cos(np.asarray(angles, float) - np.asarray(phi_ref, float))), axis=-1)


# ── flat-bottom committor spring from the GMM covariance overlap (toy spring_from_committor) ─────
def spring_from_gmm_overlap(means_feat, covs, d, *, E_star=E_STAR_DEFAULT, eps=REACH_EPS_DEFAULT,
                            k_max=K_MAX_DEFAULT, k_min=K_MIN_DEFAULT):
    """Per-window FLAT-BOTTOM wall spring k_i (kT per Dcv-unit) + flat half-width hw_i, molecular multi-torsion
    generalisation of the toy `spring_from_committor` (E*=5 kT, clamp k∈[k_min=5, k_max=50]).

    LINEAR √Dcv metric (the umbrella confines the SQUARED CV D = Σ 2(1−cosΔφ); its LINEAR reach is √D). The
    flat interior is the GMM core hw_i = w_i and the harmonic wall rises BEYOND hw_i to reach U = E* near the
    committor midpoint d_ij/2 between the window and its nearest neighbour:
        d_ij  = √( torsion_D(mean_i, mean_j) )    nearest-neighbour LINEAR separation (feature-chord units),
        w_i   = √( trace Σ_i )                     LINEAR core width from the (cos,sin) GMM covariance = hw_i,
        reach = max( d_ij/2 , ε ) ,                k_i = clip( 2·E* / reach² , k_min , k_max ) .
    MEDIAN-TO-MEDIAN reach: the spring is set from the raw centre(median)-to-committor-midpoint distance d_ij/2,
    NOT the old wall-to-wall d_ij/2 − w_i. Subtracting the flat half-width made wide-but-separated windows look
    adjacent (reach→0 ⇒ k→k_max), which on alanine collapsed every window into one and erased α_L (see
    merge_oversplit_windows); median-to-median is barrier-safe. The k_min floor keeps a well-separated window
    (large d_ij/2 ⇒ soft wall) from being under-confined. UNITS: k in kT/(√Dcv)² (rad-like), NOT kT/deg²; the
    k_max=50 / k_min=5 clamps are in these native units. Returns (k (nb,), d_ij (nb,), nearest_j (nb,), w (nb,))
    — d_ij and w in LINEAR √Dcv units; hw_i = w_i."""
    C = np.asarray(means_feat, float)
    nb = len(C)
    ang = np.array([basin_reference_angles(C[i], d) for i in range(nb)])   # (nb, d) rad
    covs = np.asarray(covs, float)
    # LINEAR width w_i = √(trace Σ_i); for a d-torsion angular spread this is the RMS feature-chord displacement.
    w = np.array([float(np.sqrt(max(np.trace(np.atleast_2d(covs[i])), 1e-12))) for i in range(nb)])
    k = np.zeros(nb); d_ij = np.zeros(nb); jnn = np.zeros(nb, int)
    for i in range(nb):
        if nb >= 2:
            dd = np.array([np.sqrt(max(torsion_D(ang[i], ang[j]), 0.0)) if j != i else np.inf for j in range(nb)])
            j = int(np.argmin(dd)); d_ij[i] = float(dd[j]); jnn[i] = j
        else:
            d_ij[i] = float(np.pi); jnn[i] = i                              # single window: nominal separation
        reach = max(d_ij[i] / 2.0, eps)                                     # MEDIAN-to-median (was d_ij/2 − w_i)
        k[i] = float(np.clip(2.0 * float(E_star) / reach ** 2, float(k_min), float(k_max)))   # floor k_min, clamp k_max
    return k, d_ij, jnn, w


# ── window design from the confident basin graph ────────────────────────────────────────────────
def design_windows(centres_feat, covs, d, *, E_star=E_STAR_DEFAULT, eps=REACH_EPS_DEFAULT,
                   k_max=K_MAX_DEFAULT):
    """One FLAT-BOTTOM window per basin from the centres + GMM covariances. Emits
    {basin, phi_ref, k_kT (kT/√Dcv²), hw_lin (flat half-width = w_i, √Dcv units)}. The umbrella is unbiased
    (flat) inside √D ≤ hw_i and a harmonic wall beyond, reaching E*=5 kT at the committor midpoint d_ij/2."""
    C = np.asarray(centres_feat, float)
    nb = len(C)
    ang = np.array([basin_reference_angles(C[i], d) for i in range(nb)])
    k, d_ij, jnn, w = spring_from_gmm_overlap(C, covs, d, E_star=E_star, eps=eps, k_max=k_max)
    windows = []
    for i in range(nb):
        windows.append(dict(basin=i, phi_ref=ang[i].tolist(), k_kT=float(k[i]), hw_lin=float(w[i]),
                            d_ij_lin=float(d_ij[i]), nearest_j=int(jnn[i]), w_lin=float(w[i])))
    return windows


# ── post-vM-BIC basin-stability merge (molecular analogue of the toy merge_oversplit_components) ──
def merge_oversplit_windows(means_feat, covs, d, land_ang, land_w, *, E_star=E_STAR_DEFAULT,
                            k_max=K_MAX_DEFAULT, eps=REACH_EPS_DEFAULT, comp_w=None,
                            barrier_kT_thresh=1.0, kde_h=0.5):
    """Collapse vM-BIC OVER-SPLIT windows before walls are placed — the molecular, d-torsion generalisation of the
    toy `merge_oversplit_components`. For every pair of window centres (i,j) at LINEAR √Dcv separation
    D=√torsion_D(mean_i,mean_j), the MEDIAN-to-median committor spring k=2·E*/max(D/2,ε)² (NOT wall-to-wall). MERGE
    the pair iff BOTH:
      • **k ≥ k_max trigger** — the two centres are so close (relative to E*) that a shared wall would pin at the
        k_max clamp (they cannot be separately confined at barrier E*); AND
      • **barrier < barrier_kT_thresh veto** — the weighted-landing DENSITY MINIMUM along the torus geodesic
        between the two centres is a PMF barrier < barrier_kT_thresh kT. The AIS landings tile cold space, so their
        weighted torus-KDE density minimum ≈ the cold-PMF barrier; a genuine barrier (≥1 kT) VETOES the merge.
    This keeps the α_L / α_R / real-barrier windows split while collapsing spurious same-basin over-splits (e.g. the
    alanine β/PPII/C5 upper ridge). Components merge by union-find; a merged window = weight-combined feature centre
    + law-of-total-variance covariance (trace = within + between spread ⇒ correct √Dcv width). Returns
    (means_out (m,2d), covs_out (m,2d,2d), groups (list of member-index lists), log)."""
    C = np.asarray(means_feat, float); nb = len(C)
    covs = np.asarray(covs, float)
    if nb <= 1:
        return C, covs, [[0]] if nb else [], dict(n_in=int(nb), n_out=int(nb), pairs=[])
    ang = np.array([basin_reference_angles(C[i], d) for i in range(nb)])          # (nb, d) rad
    la = np.atleast_2d(np.asarray(land_ang, float)); lw = np.asarray(land_w, float).ravel()
    cw = np.ones(nb) if comp_w is None else np.asarray(comp_w, float).ravel()

    def dens(p):                                                                 # torus KDE at angle-point p
        Dl = np.sum(2.0 * (1.0 - np.cos(la - p[None, :])), axis=1)               # √Dcv² to every landing
        return float(np.sum(lw * np.exp(-Dl / (2.0 * kde_h ** 2))) + 1e-12)

    parent = list(range(nb))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a

    pairs = []
    for i in range(nb):
        for j in range(i + 1, nb):
            D = float(np.sqrt(max(torsion_D(ang[i], ang[j]), 0.0)))
            reach = max(D / 2.0, eps)                                            # median-to-median
            k_pair = 2.0 * float(E_star) / reach ** 2
            high_k = bool(k_pair >= k_max)
            # geodesic barrier: shortest-wrap interpolation between the two angle centres
            dphi = np.arctan2(np.sin(ang[j] - ang[i]), np.cos(ang[j] - ang[i]))
            ts = np.linspace(0.08, 0.92, 24)
            rho_min = min(dens(ang[i] + t * dphi) for t in ts)
            rho_ends = min(dens(ang[i]), dens(ang[j]))
            barrier = max(0.0, float(-np.log(max(rho_min, 1e-12) / max(rho_ends, 1e-12))))
            do_merge = bool(high_k and barrier < barrier_kT_thresh)
            pairs.append(dict(i=i, j=j, D_lin=D, reach_lin=reach, k_pair=float(k_pair), high_k=high_k,
                              barrier_kT=barrier, merged=do_merge))
            if do_merge:
                ri, rj = find(i), find(j)
                if ri != rj:
                    parent[ri] = rj

    gmap = {}
    for i in range(nb):
        gmap.setdefault(find(i), []).append(i)
    groups = list(gmap.values())
    if len(groups) == nb:
        return C, covs, groups, dict(n_in=int(nb), n_out=int(nb), pairs=pairs)

    means_out, covs_out = [], []
    for mem in groups:
        wm = cw[mem].astype(float); sw = wm.sum() if wm.sum() > 0 else float(len(mem))
        wm = wm / sw if wm.sum() > 0 else np.ones(len(mem)) / len(mem)
        c_bar = (C[mem] * wm[:, None]).sum(0)
        cov_bar = np.zeros((C.shape[1], C.shape[1]))
        for m, wmi in zip(mem, wm):                                             # law of total variance in feature space
            diff = (C[m] - c_bar)[:, None]
            cov_bar += wmi * (np.atleast_2d(covs[m]) + diff @ diff.T)
        means_out.append(c_bar); covs_out.append(cov_bar)
    return np.array(means_out), np.array(covs_out), groups, dict(n_in=int(nb), n_out=int(len(groups)), pairs=pairs)


# ── flat-bottom bias (pure geometry) ─────────────────────────────────────────────────────────────
def flatbottom_bias_D(Dcv, hw, k):
    """FLAT-BOTTOM umbrella energy on the SQUARED CV Dcv = Σ 2(1−cosΔφ). ZERO (unbiased) inside the flat
    interior √Dcv ≤ hw; harmonic wall U = ½·k·(√Dcv − hw)² beyond. Molecular multi-torsion analogue of the toy
    `flatbottom_bias` (which uses the 1-D linear |θ−c|); here the linear reach is dev = √Dcv. hw, k in √Dcv units."""
    dev = np.sqrt(np.clip(np.asarray(Dcv, float), 0.0, None))
    return 0.5 * float(k) * np.clip(dev - float(hw), 0.0, None) ** 2


def _build_flatbottom_force_cvforce(quartets, phi_ref, hw, k_kj, group=31):
    """OpenMM ``CustomCVForce`` build of the FLAT-BOTTOM umbrella U = ½·k·max(0, √Dcv − hw)² [kJ/mol],
    Dcv = Σ 2(1−cos(θ−φ_ref)). A CustomTorsionForce computes Dcv and a CustomCVForce wraps it. CORRECT but heavy:
    the CustomCVForce keeps an inner Context and does an EXTRA force-evaluation pass every step, which dominates
    per-step cost on tiny (launch-bound) systems. The 1e-9 floor under the sqrt keeps the wall gradient finite as
    Dcv→0 (inside the flat region max(0,·) makes the term and its gradient exactly 0)."""
    from openmm import CustomCVForce, CustomTorsionForce
    cv = CustomTorsionForce("2*(1 - cos(theta - phiref))")
    cv.addPerTorsionParameter("phiref")
    for (a, b, c, dd), pr in zip(np.asarray(quartets, int), np.asarray(phi_ref, float)):
        cv.addTorsion(int(a), int(b), int(c), int(dd), [float(pr)])
    bias = CustomCVForce("0.5*kwall*dwall^2; dwall=max(0, dev-hw); dev=sqrt(Dcv+1e-9)")
    bias.addCollectiveVariable("Dcv", cv)
    bias.addGlobalParameter("kwall", float(k_kj))
    bias.addGlobalParameter("hw", float(hw))
    bias.setForceGroup(int(group))
    return bias


def _build_flatbottom_force_compound(quartets, phi_ref, hw, k_kj, group=31):
    """Native ``CustomCompoundBondForce`` build of the SAME wall U = ½·k·max(0, √Dcv − hw)²,
    Dcv = Σ_t 2(1−cos(dihedral_t − φ_ref,t)) — analytically identical energy/forces to the CVForce version, but a
    SINGLE native bonded force with NO inner Context and NO extra per-step pass, so it avoids the CV-wrapper
    overhead that dominates tiny-system MD. All torsion atoms go into ONE compound bond; each ``dihedral(pI,pJ,..)``
    in the energy expression indexes that bond's local particle list (1-based p1..pN)."""
    from openmm import CustomCompoundBondForce
    q = np.asarray(quartets, int)
    pr = np.asarray(phi_ref, float)
    d = len(q)
    particles = sorted({int(a) for quad in q for a in quad})            # union of all torsion atoms (global idx)
    loc = {a: i + 1 for i, a in enumerate(particles)}                    # global atom -> 1-based bond-local index
    terms = [f"2*(1-cos(dihedral(p{loc[int(quad[0])]},p{loc[int(quad[1])]},"
             f"p{loc[int(quad[2])]},p{loc[int(quad[3])]})-phiref{t}))" for t, quad in enumerate(q)]
    energy = f"0.5*kwall*dwall^2; dwall=max(0, dev-hw); dev=sqrt(Dcv+1e-9); Dcv={'+'.join(terms)}"
    force = CustomCompoundBondForce(len(particles), energy)
    for t in range(d):
        force.addPerBondParameter(f"phiref{t}")
    force.addGlobalParameter("kwall", float(k_kj))
    force.addGlobalParameter("hw", float(hw))
    force.addBond([int(a) for a in particles], [float(x) for x in pr])
    force.setForceGroup(int(group))
    return force


def _build_flatbottom_force(quartets, phi_ref, hw, k_kj, group=31, impl="cvforce"):
    """Build the flat-bottom √Dcv umbrella wall. `impl`: 'cvforce' (default; CustomCVForce, validated) or
    'compound' (CustomCompoundBondForce, energy-identical, faster — no CV inner-context overhead). Own force group
    so the driver/sanity check reads the bias energy in isolation; the flat interior ⇒ the confined pool IS the
    within-basin Boltzmann (a KNOWN bias WHAM removes)."""
    if impl == "compound":
        return _build_flatbottom_force_compound(quartets, phi_ref, hw, k_kj, group)
    return _build_flatbottom_force_cvforce(quartets, phi_ref, hw, k_kj, group)


# ── energy sanity (flat-bottom: 0 inside the core, rises beyond hw), end-to-end through the force ──
def energy_sanity_check(quartets, window, centre_xyz_nm, prmtop_topology, base_system, kT_kj,
                        platform="CPU", device=None, impl="cvforce"):
    """Assert the built FLAT-BOTTOM bias is ≈0 at the basin centre (inside √D ≤ hw) and rises for a
    torsion-displaced config that leaves the flat interior. Evaluates the bias force group in isolation on a real
    OpenMM context. Returns dict(E_centre_kT, E_displaced_kT, D_centre, D_displaced, ok)."""
    import copy

    from openmm import LangevinMiddleIntegrator, Platform, app, unit
    k_kj = window["k_kT"] * kT_kj
    hw = float(window["hw_lin"])
    bias = _build_flatbottom_force(quartets, window["phi_ref"], hw, k_kj, group=31, impl=impl)
    system = copy.deepcopy(base_system)
    system.addForce(bias)
    integ = LangevinMiddleIntegrator(300 * unit.kelvin, 1.0 / unit.picosecond, 1.0 * unit.femtoseconds)
    plat = Platform.getPlatformByName(platform)
    props = {}
    if platform == "CUDA" and device is not None:
        props = {"DeviceIndex": str(device)}
    elif platform == "OpenCL" and device is not None:
        props = {"OpenCLDeviceIndex": str(device)}
    sim = app.Simulation(prmtop_topology, system, integ, plat, props) if props else \
        app.Simulation(prmtop_topology, system, integ, plat)
    xyz = np.asarray(centre_xyz_nm, float)
    sim.context.setPositions(xyz * unit.nanometer)
    e_ctr = sim.context.getState(getEnergy=True, groups={31}).getPotentialEnergy().value_in_unit(
        unit.kilojoule_per_mole) / kT_kj
    # Dcv = Σ 2(1−cos(θ_t−φ_ref)) computed DIRECTLY from the config's dihedrals — impl-independent (the
    # CustomCVForce getCollectiveVariableValues API does not exist on CustomCompoundBondForce).
    import mdtraj as md
    _mtop = md.Topology.from_openmm(prmtop_topology)

    def _dcv(_xyz):
        _tr = md.Trajectory(np.asarray(_xyz, float)[None], _mtop)
        _ang = md.compute_dihedrals(_tr, np.asarray(quartets, int))[0]
        return float(torsion_D(_ang, np.asarray(window["phi_ref"], float)))

    D_ctr = _dcv(xyz)
    # displace: push every defining-torsion atom a little so the torsions rotate and D climbs above 0
    disp = xyz.copy()
    q = np.unique(np.asarray(quartets, int))
    rng = np.random.default_rng(0)
    disp[q] += 0.08 * rng.standard_normal(disp[q].shape)                   # ~0.8 Å kick on the CV atoms
    sim.context.setPositions(disp * unit.nanometer)
    e_dis = sim.context.getState(getEnergy=True, groups={31}).getPotentialEnergy().value_in_unit(
        unit.kilojoule_per_mole) / kT_kj
    D_dis = _dcv(disp)
    # flat-bottom U = ½·k·max(0, √D − hw)²: verify the built force implements it at BOTH points (the seed sits
    # inside the flat interior ⇒ E_centre ≈ 0), and that leaving the interior raises the bias.
    k = float(window["k_kT"])
    pred_ctr = float(flatbottom_bias_D(D_ctr, hw, k))
    pred_dis = float(flatbottom_bias_D(D_dis, hw, k))
    fb_ok = (abs(e_ctr - pred_ctr) < 1e-2 * max(1.0, abs(pred_ctr)) + 1e-3 and
             abs(e_dis - pred_dis) < 1e-2 * max(1.0, abs(pred_dis)) + 1e-3)
    rises = (e_dis >= e_ctr - 1e-9) if (D_dis >= D_ctr) else True
    ok = bool(fb_ok and rises)
    return dict(E_centre_kT=float(e_ctr), E_displaced_kT=float(e_dis),
                D_centre=D_ctr, D_displaced=D_dis, ok=ok)


# ── restrained MD in one flat-bottom window ──────────────────────────────────────────────────────
def run_window(quartets, window, seed_xyz_nm, prmtop_topology, base_system, kT_kj, n_ps, save_ps,
               platform="CPU", device=None, dt_fs=2.0, temp=300.0, seed=0, minimize=True, impl="cvforce"):
    """Flat-bottom-umbrella-restrained MD in one basin. Returns (angles (F,d) rad, U_base_kT (F,), traj) — the
    base (bias-off) reduced potential, the defining-torsion angles per saved frame, and the confined-frame
    mdtraj.Trajectory (the within-basin cold ensemble that the reservoir-free reverse-AIS seeds from). REAL
    biased Langevin; the KNOWN flat-bottom bias is removed later by WHAM. The unbiased flat interior ⇒ the
    confined pool is the within-basin Boltzmann."""
    import copy

    import mdtraj as md
    from openmm import LangevinMiddleIntegrator, Platform, app, unit
    k_kj = window["k_kT"] * kT_kj
    bias = _build_flatbottom_force(quartets, window["phi_ref"], float(window["hw_lin"]), k_kj, group=31, impl=impl)
    system = copy.deepcopy(base_system)
    system.addForce(bias)
    integ = LangevinMiddleIntegrator(temp * unit.kelvin, 1.0 / unit.picosecond, dt_fs * unit.femtoseconds)
    plat = Platform.getPlatformByName(platform)
    props = {}
    if platform == "CUDA":
        props = {"Precision": "mixed"}
        if device is not None:
            props["DeviceIndex"] = str(device)
    elif platform == "OpenCL":
        props = {"Precision": "mixed"}
        if device is not None:
            props["OpenCLDeviceIndex"] = str(device)
    sim = app.Simulation(prmtop_topology, system, integ, plat, props) if props else \
        app.Simulation(prmtop_topology, system, integ, plat)
    sim.context.setPositions(np.asarray(seed_xyz_nm, float) * unit.nanometer)
    if minimize:
        sim.minimizeEnergy(maxIterations=200)
    sim.context.setVelocitiesToTemperature(temp * unit.kelvin, int(seed))
    stride = max(1, int(round(save_ps * 1000 / dt_fs)))
    n_save = max(1, int(round(n_ps / save_ps)))
    quartets = np.asarray(quartets, int)
    xyz_frames, ubase = [], []
    all_groups = set(range(32)) - {31}                                    # every force group EXCEPT the bias
    for _ in range(n_save):
        sim.step(stride)
        st = sim.context.getState(getEnergy=True, getPositions=True, groups=all_groups)
        ubase.append(st.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole) / kT_kj)
        xyz_frames.append(st.getPositions(asNumpy=True).value_in_unit(unit.nanometer))
    top = md.Topology.from_openmm(prmtop_topology)
    traj = md.Trajectory(np.asarray(xyz_frames, float), top)
    angles = md.compute_dihedrals(traj, quartets)                         # (F, d) rad
    return np.asarray(angles, float), np.asarray(ubase, float), traj


# ── continuous flat-bottom umbrella walkers (generational BAUS) ───────────────────────────────────
class UmbrellaWalkers:
    """Persistent CONTINUOUS flat-bottom walkers — one per umbrella — for the generational BAUS loop. Each walker
    is a biased-Langevin trajectory under its umbrella's flat-bottom wall, advanced T_gen per generation; its frames
    ACCUMULATE into that umbrella's within-basin cold ensemble (the reverse-AIS seed pool). One walker per umbrella,
    NO split/merge/anchor (contrast the WE reservoir). New umbrellas can be added mid-run (adaptive growth). Reuses
    `_build_flatbottom_force` (impl='compound') + the same LangevinMiddle setup as `run_window`."""

    def __init__(self, make_system, quartets, kT_kj, platform="CUDA", device=0, dt_fs=2.0, temp=300.0,
                 impl="compound"):
        import mdtraj as md
        self.prmtop, self.base = make_system()
        self.topo = self.prmtop.topology
        self.mdtop = md.Topology.from_openmm(self.topo)
        self.quartets = np.asarray(quartets, int)
        self.kT_kj = kT_kj; self.platform = platform; self.device = device
        self.dt_fs = dt_fs; self.temp = temp; self.impl = impl
        self.walkers = []                                         # dict(sim, phi_ref, hw, k_kT, xyz=[frames])

    def add(self, window, seed_xyz_nm, seed=0, minimize=True):
        """Spin up a new persistent walker for `window` (needs phi_ref, hw_lin, k_kT), seeded from seed_xyz_nm."""
        import copy
        from openmm import LangevinMiddleIntegrator, Platform, app, unit
        k_kj = float(window["k_kT"]) * self.kT_kj
        bias = _build_flatbottom_force(self.quartets, window["phi_ref"], float(window["hw_lin"]), k_kj,
                                       group=31, impl=self.impl)
        system = copy.deepcopy(self.base); system.addForce(bias)
        integ = LangevinMiddleIntegrator(self.temp * unit.kelvin, 1.0 / unit.picosecond,
                                         self.dt_fs * unit.femtoseconds)
        plat = Platform.getPlatformByName(self.platform)
        props = {"Precision": "mixed"}
        if self.device is not None:
            props["DeviceIndex" if self.platform == "CUDA" else "OpenCLDeviceIndex"] = str(self.device)
        sim = app.Simulation(self.topo, system, integ, plat, props)
        sim.context.setPositions(np.asarray(seed_xyz_nm, float) * unit.nanometer)
        if minimize:
            sim.minimizeEnergy(maxIterations=200)
        sim.context.setVelocitiesToTemperature(self.temp * unit.kelvin, int(seed))
        self.walkers.append(dict(sim=sim, phi_ref=np.asarray(window["phi_ref"], float),
                                 hw=float(window["hw_lin"]), k_kT=float(window["k_kT"]), xyz=[]))
        return len(self.walkers) - 1

    def advance(self, t_ps, save_ps):
        """Step EVERY walker by t_ps, appending a frame every save_ps to its accumulating confined ensemble."""
        from openmm import unit
        stride = max(1, int(round(save_ps * 1000 / self.dt_fs)))
        n_save = max(1, int(round(t_ps / save_ps)))
        for w in self.walkers:
            sim = w["sim"]
            for _ in range(n_save):
                sim.step(stride)
                st = sim.context.getState(getPositions=True)
                w["xyz"].append(st.getPositions(asNumpy=True).value_in_unit(unit.nanometer))

    def samples(self, i):
        """mdtraj.Trajectory of umbrella i's accumulated confined frames (the reverse-AIS seed pool)."""
        import mdtraj as md
        w = self.walkers[i]
        return md.Trajectory(np.asarray(w["xyz"], float), self.mdtop) if w["xyz"] else None

    def n_frames(self, i):
        return len(self.walkers[i]["xyz"])

    def __len__(self):
        return len(self.walkers)


# ── overlap clusters + node-WHAM (self-consistent, no pymbar) + BAR bridge ───────────────────────
def _assign_nodes(angles, node_angles):
    """Assign each sample (F,d rad) to its nearest microstate node (M,d rad) in the torsion-D CV metric."""
    A = np.asarray(angles, float); N = np.asarray(node_angles, float)
    if A.ndim == 1:
        A = A[None, :]
    # D[f,m] = Σ_k 2(1 − cos(A[f,k] − N[m,k]))
    D = (2.0 * (1.0 - np.cos(A[:, None, :] - N[None, :, :]))).sum(-1)      # (F, M)
    return np.argmin(D, axis=1).astype(int)


def _connected_clusters(overlap, thresh):
    """Union-find on the window-overlap matrix: windows i,j join if overlap[i,j] > thresh. Returns
    (cluster_of[n], n_clusters) with contiguous cluster ids."""
    n = overlap.shape[0]
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a

    for i in range(n):
        for j in range(i + 1, n):
            if overlap[i, j] > thresh:
                ra, rb = find(i), find(j)
                if ra != rb:
                    parent[ra] = rb
    roots, cluster_of = {}, np.zeros(n, int)
    for i in range(n):
        r = find(i)
        if r not in roots:
            roots[r] = len(roots)
        cluster_of[i] = roots[r]
    return cluster_of, len(roots)


def _wham_nodes(counts, node_bias_kT, n_iter=40000, tol=1e-11):
    """Self-consistent (Ferrenberg–Swendsen) WHAM over discrete microstate NODES, mirroring the toy `wham_1d`
    but with arbitrary node bias evaluated at each node centre. Reduced units (β=1).

        log P(m) = log n_tot(m) − logsumexp_i[ log N_i + f_i − u_i(m) ]
        f_i      = − logsumexp_m[ log P(m) − u_i(m) ]              (pinned f_0 = 0)

    counts (W, M): per-window sample counts over nodes. node_bias_kT (W, M): u_i(node m) in kT (≥0). Returns
    (logP (M,), f (W,), n_iter_used). Nodes never sampled by any window get logP = −inf."""
    from scipy.special import logsumexp
    counts = np.asarray(counts, float)
    W, M = counts.shape
    logbias = -np.asarray(node_bias_kT, float)                            # (W, M)
    N = counts.sum(1)
    ntot = counts.sum(0)
    occ = ntot > 0
    logN = np.log(np.maximum(N, 1e-300))
    logntot = np.full(M, -np.inf)
    logntot[occ] = np.log(ntot[occ])
    f = np.zeros(W)
    logP = np.full(M, -np.inf)
    n_used = n_iter
    for it in range(n_iter):
        A = logN[:, None] + f[:, None] + logbias                          # (W, M)
        denom = logsumexp(A, axis=0)                                      # (M,)
        logP = np.where(occ, logntot - denom, -np.inf)
        s = logsumexp(logP[occ]) if occ.any() else 0.0
        logP[occ] -= s                                                     # normalise Σ_occ P = 1
        B = logP[None, :] + logbias                                       # (W, M)
        fnew = -logsumexp(np.where(np.isneginf(B), -np.inf, B), axis=1)   # (W,)
        fnew = fnew - fnew[0]
        if np.max(np.abs(fnew - f)) < tol:
            f = fnew; n_used = it + 1; break
        f = fnew
    return logP, f, n_used


def reconstruct_mbar(windows, angles_list, ubase_list, node_angles, node_basin, pi_bar,
                     *, overlap_thresh=OVERLAP_THRESH_DEFAULT):
    """Reconstruct the MICROSTATE-level PMF from the flat-bottom windows + BAR bridge (plan rule c). NOT an
    independent population estimator.

    1. Assign each window's samples to their nearest microstate NODE → per-window node histograms.
    2. overlap[i,j] = Σ_m min(hist_i, hist_j) (row-normalised) → union-find overlap-connected CLUSTERS of windows.
    3. Per cluster: WHAM (self-consistent; pymbar per-sample MBAR if available, else `_wham_nodes`) removes the
       KNOWN flat-bottom bias → the RELATIVE node PMF within the cluster.
    4. **BAR bridge**: each cluster's absolute level = Σ π^BAR over its basins; scale the cluster's node-P to that
       mass. Node → cluster via node_basin → window → cluster_of.
    5. F(node) = −ln P(node) (WHAM shape within a cluster + BAR offset between clusters). Populations π^US[b] =
       Σ_{node∈basin b} P(node).

    Returns dict with pmf_micro, pi_us (per basin), k_kT, overlap clusters, reconstruct_method, diagnostics."""
    nb = len(windows)
    N_k = np.array([len(a) for a in angles_list], int)
    if nb == 0 or int(N_k.sum()) == 0:
        return dict(pi_us=None, pmf_micro=None, reconstruct_method="empty", n_clusters=0,
                    cluster_of=[], overlap_matrix=[])
    node_angles = np.asarray(node_angles, float)
    node_basin = np.asarray(node_basin, int)
    M = len(node_angles)
    pi_bar = np.asarray(pi_bar, float) if pi_bar is not None else np.full(nb, 1.0 / nb)
    d = node_angles.shape[1]

    # 1. per-window node histograms + empirical reach diagnostics
    counts = np.zeros((nb, M))
    reach_emp = np.full(nb, np.nan)
    for i, ang in enumerate(angles_list):
        if len(ang) == 0:
            continue
        lab = _assign_nodes(ang, node_angles)
        for m in lab:
            counts[i, m] += 1.0
        Di = torsion_D(ang, np.asarray(windows[i]["phi_ref"], float))     # in-window CV (squared)
        reach_emp[i] = float(np.sqrt(max(np.quantile(Di, 0.95), 0.0)))    # LINEAR 95th-pct reach

    # 2. overlap-connected clusters
    hn = counts / np.clip(counts.sum(1, keepdims=True), 1e-12, None)
    overlap = np.array([[float(np.minimum(hn[i], hn[j]).sum()) for j in range(nb)] for i in range(nb)])
    cluster_of, n_clusters = _connected_clusters(overlap, overlap_thresh)

    # 3+4. WHAM per cluster (removes the KNOWN flat-bottom bias) → relative P; BAR sets the cluster level
    node_bias = np.array([flatbottom_bias_D(torsion_D(node_angles, np.asarray(windows[i]["phi_ref"], float)),
                                            windows[i]["hw_lin"], windows[i]["k_kT"]) for i in range(nb)])  # (nb,M)
    node_cluster = cluster_of[np.clip(node_basin, 0, nb - 1)]             # node → basin → cluster
    cluster_bar_mass = np.array([float(pi_bar[[i for i in range(nb) if cluster_of[i] == c]].sum())
                                 for c in range(n_clusters)])
    if cluster_bar_mass.sum() > 0:
        cluster_bar_mass = cluster_bar_mass / cluster_bar_mass.sum()

    method = "wham_nodes+bar_bridge"
    P_micro = np.zeros(M)
    wham_iters = []
    for c in range(n_clusters):
        wins_c = [i for i in range(nb) if cluster_of[i] == c]
        logP, _f, it = _wham_nodes(counts[wins_c], node_bias[np.ix_(wins_c, np.arange(M))])
        wham_iters.append(int(it))
        Pc = np.where(np.isneginf(logP), 0.0, np.exp(logP))
        sel = node_cluster == c                                           # nodes owned by this cluster
        mass = Pc[sel].sum()
        if mass > 0:
            P_micro[sel] = Pc[sel] / mass * cluster_bar_mass[c]           # WHAM shape within, BAR offset between
    s = P_micro.sum()
    P_micro = P_micro / s if s > 0 else P_micro
    with np.errstate(divide="ignore"):
        F_micro = -np.log(np.where(P_micro > 0, P_micro, np.nan))
    if np.isfinite(F_micro).any():
        F_micro = F_micro - np.nanmin(F_micro)

    # 5. per-basin populations from the reconstructed microstate PMF
    pi_us = np.array([float(P_micro[node_basin == b].sum()) for b in range(nb)])
    ss = pi_us.sum(); pi_us = pi_us / ss if ss > 0 else pi_us

    return dict(
        pi_us=pi_us.tolist(), pmf_micro=F_micro.tolist(), P_micro=P_micro.tolist(),
        reconstruct_method=method, bar_bridge=True,
        n_clusters=int(n_clusters), cluster_of=[int(x) for x in cluster_of],
        overlap_matrix=overlap.tolist(), overlap_thresh=float(overlap_thresh),
        cluster_bar_mass=[float(x) for x in cluster_bar_mass], wham_iters=wham_iters,
        k_kT=[float(w["k_kT"]) for w in windows],
        reach_emp_lin=[None if not np.isfinite(x) else float(x) for x in reach_emp],
        reach_target_lin=[float(w["d_ij_lin"] / 2.0) for w in windows],
        penalty_neighbour_kT=[float(0.5 * w["k_kT"] * max(w["d_ij_lin"] - w["hw_lin"], 0.0) ** 2)
                              for w in windows],
        d_ij_lin=[float(w["d_ij_lin"]) for w in windows], w_lin=[float(w["w_lin"]) for w in windows],
        node_basin=[int(x) for x in node_basin],
    )


# ══════════════════════════════════════════════════════════════════════════════════════════════════
#  UNSUPPORTED EXPLORATORY ALTERNATIVE — NOT BAUS theory, NOT on any default path.
#  The density-corrected reverse work W_1 = ln(q̃_m/p) is NOT a valid Crooks/BAR/MSK reverse work for a
#  forward protocol ending in C_m (BAUS_theory.pdf App. A). The CORRECT matched reverse is the physical
#  endpoint work -U_m(x_0) with x_0 ~ q_m equilibrium (methods/baus_estimator.hot_edge_works). These two
#  functions are retained ONLY for reproducibility of the deprecated analysis scripts + tests and emit a
#  DeprecationWarning. Do NOT use them in the central estimator.
# ══════════════════════════════════════════════════════════════════════════════════════════════════
def torus_kde(angles, weights=None, *, bins=48, sigma=1.6):
    """Smooth PERIODIC density on the d-torus: a Gaussian-blurred d-histogram with wrap-around edges.
    `angles` (N,d) rad in (−π,π]; returns (H, edges) with H an nd grid normalised to sum 1. Practical
    only for LOW d (d≲3): the grid is bins**d. For many-torsion systems estimate the density in a reduced
    (TICA/slow) subspace instead of the full torus."""
    from scipy.ndimage import gaussian_filter
    A = np.asarray(angles, float)
    if A.ndim == 1:
        A = A[:, None]
    d = A.shape[1]
    H, edges = np.histogramdd(A, bins=[bins] * d, range=[(-np.pi, np.pi)] * d, weights=weights)
    H = gaussian_filter(H, sigma, mode="wrap") + 1e-12
    return H / H.sum(), edges


def _torus_grid_index(ang, bins):
    a = np.asarray(ang, float).ravel()
    return tuple(np.clip(((a + np.pi) / (2.0 * np.pi) * bins).astype(int), 0, bins - 1))


def density_corrected_first_step(start_angles, confined_angles, cold_angles, cold_weights,
                                 *, bins=48, sigma=1.6):
    r"""DEPRECATED / UNSUPPORTED — NOT BAUS theory. The reverse first-step work

        W_1(x) = ln[ q̃_m(x) / p_{C0}(x) ]      (reduced units, β=1)

    is NOT a valid Crooks/BAR/MSK reverse work when paired with a forward protocol ending in C_m: ln(q̃_m/p)
    and the physical endpoint work −U_m do NOT represent the same thermodynamic edge and do NOT give the same
    populations. The unit-average ⟨p/q̃_m⟩_{q̃_m}=1 is a normalization identity (support + normalization), NOT a
    statistical-independence or matched-endpoint proof; a marginal (TICA) KDE ratio is not a full-space density
    correction; and an under-relaxed walker cannot be redefined as a new equilibrium state and retrospectively
    repaired (that is a sampling failure — fix it with longer equilibration / more walkers / better windows /
    replica exchange). See BAUS_theory.pdf Appendix A.

    The CORRECT matched reverse work is −U_m(x_0) with x_0 ~ q_m equilibrium, computed by
    ``methods.baus_estimator.hot_edge_works`` and used on the default ``--method coverage`` path via
    ``soft_bar.basin_free_energies_soft``. This function is retained ONLY for reproducibility of the deprecated
    analysis scripts + tests; it emits a DeprecationWarning and must not be used in the central estimator."""
    import warnings
    warnings.warn(
        "density_corrected_first_step (ln q̃_m/p) is DEPRECATED/UNSUPPORTED and not BAUS theory; use the matched "
        "reverse work -U_m(x_0) via baus_estimator.hot_edge_works (see BAUS_theory.pdf App. A).",
        DeprecationWarning, stacklevel=2)
    p_c0, _ = torus_kde(cold_angles, cold_weights, bins=bins, sigma=sigma)
    q_m, _ = torus_kde(confined_angles, None, bins=bins, sigma=sigma)
    start = np.asarray(start_angles, float)
    if start.ndim == 1:
        start = start[:, None]
    return np.array([np.log(q_m[_torus_grid_index(x, bins)] / p_c0[_torus_grid_index(x, bins)])
                     for x in start])


# ── driver ───────────────────────────────────────────────────────────────────────────────────────
def run_bais_us(cfg, make_system, centres_feat, covs, pi_bar, quartets, seed_xyz_per_basin,
                kT_kj, out, *, dF_ais=None, platform="CPU", device=None, n_ps=20.0, save_ps=1.0,
                E_star=E_STAR_DEFAULT, k_max=K_MAX_DEFAULT, reach_eps=REACH_EPS_DEFAULT,
                overlap_thresh=OVERLAP_THRESH_DEFAULT, micro_centres=None, micro2basin=None, smoke=False,
                soft_bar_inputs=None, prep_budget=None, reverse_ais_fn=None, fwd_soft=None, impl="cvforce"):
    """Driver-facing BAIS-US pass — PMF reconstruction (NOT an independent population estimator).

    One FLAT-BOTTOM window per committed basin (flat interior = GMM core hw_i = w_i, wall reaching E*=5 kT at the
    committor midpoint, k clamped to k_max=50); flat-bottom energy sanity; REAL biased-Langevin sampling per
    window; overlap-connected clusters → WHAM (relative node PMF within a cluster) with BAR setting the
    inter-cluster offsets → the microstate-level PMF + π^US. No reference state, no TI, no route-2.
    `bar_bridge=True`.

    make_system : callable -> (prmtop_like, base_system) fresh (so the bias is added to a private copy).
    centres_feat: (nb, 2d) committed basin centres in (cos,sin). covs: (nb, 2d, 2d) GMM covariances (for k, w).
    pi_bar      : (nb,) endpoint-BAR populations — the fallback BAR bridge (used when soft_bar_inputs is None).
    soft_bar_inputs : optional dict(Wf, land_ang_rad, Wr, rev_start) → the SOFT flat-bottom BAR π used for the
                  bridge (toy soft-BAR). prep_budget : optional dict recorded under results['budget']['prep']
                  (the --we hot-only PREP up to the W2 landing-gate freeze G_conv). dF_ais is provenance only."""
    d = np.asarray(quartets, int).shape[0]
    windows = design_windows(centres_feat, covs, d, E_star=E_star, eps=reach_eps, k_max=k_max)
    prmtop, base_system = make_system()
    topo = prmtop.topology

    # 1) flat-bottom energy sanity on every window (0 inside the flat core / rises beyond hw), through OpenMM
    sanity = []
    for i, w in enumerate(windows):
        seed = seed_xyz_per_basin[i] if i < len(seed_xyz_per_basin) else None
        if seed is None:
            sanity.append(dict(basin=i, ok=None, note="no seed config"))
            continue
        s = energy_sanity_check(quartets, w, seed, topo, base_system, kT_kj, platform="CPU", device=None, impl=impl)
        s["basin"] = i
        sanity.append(s)
        print(f"    [bais-us] basin {i}: flat-bottom sanity E_ctr={s['E_centre_kT']:.3e} kT (D={s['D_centre']:.3f}) "
              f"-> E_disp={s['E_displaced_kT']:.3f} kT (D={s['D_displaced']:.3f})  "
              f"k={w['k_kT']:.2f} kT/√Dcv², hw={w['hw_lin']:.3f}  {'OK' if s['ok'] else 'FAIL'}", file=sys.stderr)
    if not all(s.get("ok") for s in sanity if s.get("ok") is not None):
        raise AssertionError(f"BAIS-US flat-bottom energy sanity failed: {sanity}")

    # 2) REAL biased-Langevin sampling per flat-bottom window
    angles_list, ubase_list, kept, conf_trajs = [], [], [], []
    for i, w in enumerate(windows):
        seed = seed_xyz_per_basin[i] if i < len(seed_xyz_per_basin) else None
        if seed is None:
            angles_list.append(np.zeros((0, d))); ubase_list.append(np.zeros(0)); conf_trajs.append(None); continue
        ang, ub, traj = run_window(quartets, w, seed, topo, base_system, kT_kj, n_ps=n_ps, save_ps=save_ps,
                                   platform=platform, device=device, seed=7000 + 100 * i, impl=impl)
        angles_list.append(ang); ubase_list.append(ub); conf_trajs.append(traj); kept.append(i)
        print(f"    [bais-us] basin {i}: sampled {len(ang)} frames "
              f"(⟨D⟩={float(np.mean(torsion_D(ang, np.asarray(w['phi_ref'], float)))):.3f})", file=sys.stderr)

    # 3) node graph: microstate centres (frozen graph) → node angles + node→basin map
    if micro_centres is not None and micro2basin is not None and len(micro_centres):
        mc = np.asarray(micro_centres, float)
        node_angles = np.array([basin_reference_angles(mc[m], d) for m in range(len(mc))])
        node_basin = np.asarray(micro2basin, int)
    else:                                                                 # fallback: each basin is its own node
        node_angles = np.array([np.asarray(w["phi_ref"], float) for w in windows])
        node_basin = np.arange(len(windows), dtype=int)

    # 3a) RESERVOIR-FREE reverse pool (BAUS): when no reservoir soft_bar_inputs is supplied but the caller
    #     injected a reverse-AIS callable + the forward-landing works, launch count-matched reverse AIS
    #     (cold s=1 → hot s=s_hot) FROM EACH WINDOW'S OWN CONFINED SAMPLES (the flat-bottom interior ≈ within-basin
    #     Boltzmann), and assemble soft_bar_inputs here. This is the decoupling from the WE reservoir: the reverse
    #     works come from the umbrellas themselves, not a separate weighted-ensemble pool.
    rev_windows_diag = None
    if soft_bar_inputs is None and reverse_ais_fn is not None and fwd_soft is not None:
        Wf_soft = np.asarray(fwd_soft["Wf"], float)
        land_ang_soft = np.asarray(fwd_soft["land_ang_rad"], float)
        land_basin_soft = np.asarray(fwd_soft["land_basin"], int)              # forward landing → window index
        Wr_parts, rev_start_parts, rev_log = [], [], []
        for i in kept:
            traj_i = conf_trajs[i]
            n_fwd_i = int(np.sum(land_basin_soft == i))
            k_i = max(8, min(n_fwd_i, int(fwd_soft.get("n_rev_cap", 64))))     # count-matched, capped, floor 8
            if traj_i is None or len(traj_i) == 0:
                rev_log.append(dict(window=i, k=0, note="no confined frames")); continue
            Wr_i = reverse_ais_fn(traj_i, i, k_i)                              # cold→hot reduced works (k_i,)
            if Wr_i is None or len(Wr_i) == 0:
                rev_log.append(dict(window=i, k=0, note="reverse-AIS returned empty")); continue
            Wr_parts.append(np.asarray(Wr_i, float)); rev_start_parts.append(np.full(len(Wr_i), i, int))
            rev_log.append(dict(window=i, k=int(len(Wr_i)), meanWr=float(np.mean(Wr_i))))
            print(f"    [bais-us] reverse-from-window {i}: {len(Wr_i)} shots, mean W_r={np.mean(Wr_i):.2f} kT",
                  file=sys.stderr)
        if Wr_parts:
            soft_bar_inputs = dict(Wf=Wf_soft, land_ang_rad=land_ang_soft,
                                   Wr=np.concatenate(Wr_parts), rev_start=np.concatenate(rev_start_parts))
        rev_windows_diag = rev_log

    # 3b) SOFT flat-bottom BAR (toy soft-BAR): if the caller supplies forward works + landing angles + reverse
    #     works/starts, recompute the inter-basin π via the FINITE flat-bottom perturbation (no hard veto) and use
    #     IT for the BAR bridge. Falls back to the supplied endpoint π^BAR when inputs are missing.
    pi_soft = None; soft_diag = None
    if soft_bar_inputs is not None:
        from escort_ais.methods.soft_bar import basin_free_energies_soft
        sb = basin_free_energies_soft(soft_bar_inputs["Wf"], soft_bar_inputs["land_ang_rad"],
                                      soft_bar_inputs["Wr"], soft_bar_inputs["rev_start"], windows)
        pi_soft = np.asarray(sb["pi"], float); soft_diag = sb["diagnostics"]
        print(f"    [bais-us] soft flat-bottom BAR π = {np.round(np.nan_to_num(pi_soft), 3).tolist()} "
              f"(vs endpoint π^BAR = {np.round(np.nan_to_num(np.asarray(pi_bar, float)), 3).tolist()})",
              file=sys.stderr)
    pi_bridge = pi_soft if (pi_soft is not None and np.isfinite(pi_soft).any()) else pi_bar

    # 3c) AUS (forward-only Jarzynski) — a FREE comparison estimator (no new sim): per-window softmax of the
    #     forward landing works, π_aus[i] ∝ Σ_{land∈i} e^{−W_f}. Higher-variance / one-sided; NOT production.
    pi_aus = None
    if fwd_soft is not None:
        lb = np.asarray(fwd_soft["land_basin"], int); Wf_a = np.asarray(fwd_soft["Wf"], float)
        wl = np.exp(-(Wf_a - Wf_a.max()))
        pa = np.array([float(wl[lb == i].sum()) for i in range(len(windows))], float)
        pi_aus = (pa / pa.sum()).tolist() if pa.sum() > 0 else None

    # 4) WHAM (per overlap cluster) + BAR bridge → microstate PMF + π^US
    rec = reconstruct_mbar(windows, angles_list, ubase_list, node_angles, node_basin, pi_bridge,
                           overlap_thresh=overlap_thresh)

    pi_bar_l = np.asarray(pi_bar, float).tolist() if pi_bar is not None else [np.nan] * len(windows)
    residual = ("BAIS-US is a PMF-RECONSTRUCTION tool, not an independent population estimator: the inter-basin "
                "(cross-barrier) offsets are BAR's, only the intra-cluster shape is WHAM's over the overlapping "
                "FLAT-BOTTOM windows (bar_bridge=True). The umbrella is U=½·k·max(0, √Dcv − hw)² with "
                "D=Σ2(1−cosΔφ) (ZERO inside the GMM core √Dcv ≤ hw=w_i, harmonic wall beyond reaching E*=5 kT near "
                "the committor midpoint d_ij/2), k=clip(2·E*/max(d_ij/2,ε)², k_min=5, k_max=50) — MEDIAN-to-median "
                "reach from the GMM covariance overlap. The BAR bridge uses the SOFT flat-bottom BAR π when "
                "soft_bar_inputs are supplied (a finite forward-only +U_bias^B perturbation, no hard endpoint "
                "veto), else the endpoint π^BAR. NOTE (flagged): in BAUS the soft-BAR reverse works are the "
                "reverse-AIS launched from each window's OWN confined samples, which equal the within-basin "
                "Boltzmann only under the flat-interior≈within-basin-Boltzmann approximation (the legacy "
                "--us-from-run path instead draws them from a WE reservoir). WHAM evaluates the known bias at "
                "microstate-NODE centres (binned WHAM), so the "
                "intra-cluster PMF resolution is the microstate graph, not a full (φ,ψ) grid.")
    us_cold_ps = float(len(kept) * n_ps)                         # confined-window MD only (PREP cold-spend = 0)
    results = dict(
        n_basins=len(windows), windows=windows, sanity=sanity,
        route="pmf-reconstruction (flat-bottom US + soft-BAR bridge + WHAM)", bar_bridge=True,
        umbrella_type="flat-bottom", flatbottom_impl=impl,
        pi_us=rec.get("pi_us"), pi_bar=pi_bar_l,
        pi_soft_bar=(None if pi_soft is None else np.nan_to_num(pi_soft).tolist()),
        pi_aus=pi_aus, reverse_pool=("windows" if rev_windows_diag is not None else "reservoir"),
        reverse_windows_diag=rev_windows_diag,
        soft_bar_diagnostics=soft_diag, pmf_micro=rec.get("pmf_micro"),
        reconstruct_method=rec.get("reconstruct_method"), k_kT=rec.get("k_kT"),
        hw_lin=[float(w["hw_lin"]) for w in windows],
        overlap_clusters=dict(n_clusters=rec.get("n_clusters"), cluster_of=rec.get("cluster_of"),
                              overlap_matrix=rec.get("overlap_matrix"), overlap_thresh=rec.get("overlap_thresh"),
                              cluster_bar_mass=rec.get("cluster_bar_mass"), wham_iters=rec.get("wham_iters")),
        E_star=float(E_star), k_max=float(k_max),
        # PREP / budget bookkeeping (port 3): the --we hot phase (up to the W2 landing-gate freeze G_conv) is the
        # hot-only PREP; the confined US cold windows run ONLY AFTER, so the US phase's PREP cold-spend is 0.
        budget=dict(prep=(None if prep_budget is None else dict(prep_budget)),
                    us_cold_ps=us_cold_ps, prep_cold_ps=0.0,
                    G_conv=(None if prep_budget is None else prep_budget.get("G_conv"))),
        overlap_diag=dict(d_ij_lin=rec.get("d_ij_lin"), w_lin=rec.get("w_lin"),
                          reach_emp_lin=rec.get("reach_emp_lin"), reach_target_lin=rec.get("reach_target_lin"),
                          penalty_neighbour_kT=rec.get("penalty_neighbour_kT")),
        node_basin=rec.get("node_basin"), dF_ais=(None if dF_ais is None else np.asarray(dF_ais, float).tolist()),
        residual_approximation=residual)
    Path(out).mkdir(parents=True, exist_ok=True)
    (Path(out) / "bais_us_results.json").write_text(json.dumps(results, indent=1))
    print(f"[bais-us] wrote {Path(out) / 'bais_us_results.json'}  (method={results['reconstruct_method']}, "
          f"bar_bridge=True, {rec.get('n_clusters')} overlap cluster(s))", file=sys.stderr)
    print(f"[bais-us] pi_US = {np.round(np.asarray(rec.get('pi_us', []), float), 3).tolist()}  vs  "
          f"pi_BAR = {np.round(np.asarray(pi_bar_l, float), 3).tolist()}", file=sys.stderr)
    print(f"[bais-us] overlap: reach_emp={[None if x is None else round(x,2) for x in rec.get('reach_emp_lin', [])]} "
          f"vs target(d_ij/2)={[round(x,2) for x in rec.get('reach_target_lin', [])]}; "
          f"penalty@nbr(kT)={[round(x,2) for x in rec.get('penalty_neighbour_kT', [])]}", file=sys.stderr)
    return results
