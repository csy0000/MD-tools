"""Continuing MD walkers for the REMD-free conditional-BAR campaign.

One long-lived OpenMM ``Context`` per stream (the hot REST2 ensemble and one per cold box), stepped
forward in fixed chunks once per generation. Keeping the context alive is what makes the walker a
genuine continuation: restarting through ``md_run.run_single_md`` each generation would re-run
``minimizeEnergy`` (where ``maxIterations=0`` means *minimise to convergence*, not skip) and quench
the structure every chunk.

Engine invariants honoured here (CLAUDE.md):
  * the integrator is seeded BEFORE its ``Context`` is created -- ``setRandomNumberSeed`` afterwards
    is silently ignored by OpenMM;
  * ``Precision = mixed`` is set explicitly on CUDA/OpenCL, since the platform default is single and
    silently changes energies;
  * the base system is built through the parmed ``changeRadii`` route selected by
    ``gb_radii='mbondi3'``, the same branch the AIS legs use. ``AmberPrmtopFile.createSystem``
    differs by 16.6 kJ/mol at identical radii.

The cold box walkers carry a rectangular flat-bottom restraint ``U_m``. Their stationary
distribution is therefore the SOFT ensemble ``p(x) e^{-U_m(x)}``, not ``pi_m``. Frames inside the
box have ``U_m == 0`` and are unbiased ``pi_m`` samples; wall-region frames are not, and
:func:`interior_mask` is what separates them. Reverse AIS legs must be seeded from the interior
frames only.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

from escort_ais.common.paths import project_root

ROOT = project_root()
PRMTOP = ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.prmtop"
INPCRD = ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.inpcrd"
GB_RADII = "mbondi3"
N_SOLUTE = 22
T_BASE_K = 300.0
KB_KJ = 0.0083144621
KT_KJ = KB_KJ * T_BASE_K
TIMESTEP_FS = 2.0
FRICTION_PER_PS = 1.0


def build_base_system():
    """Base (unscaled) system on the SAME builder branch as the AIS legs."""
    from escort_ais.systems.openmm_system import build_implicit_system  # noqa: PLC0415

    return build_implicit_system(PRMTOP, gb_radii=GB_RADII, inpcrd_path=INPCRD)


def load_topology():
    from openmm import app
    return app.AmberPrmtopFile(str(PRMTOP)).topology


def torsion_quartets(topology):
    from escort_ais.analysis.analysis import find_phi_psi_indices
    return find_phi_psi_indices(topology)


def interior_mask(phi_rad, psi_rad, basin) -> np.ndarray:
    """True where the flat-bottom bias is exactly zero, i.e. genuine ``pi_m`` samples."""
    from escort_ais.methods.rectangular_flatbottom import rect_bias_kT
    return np.asarray(rect_bias_kT(np.asarray(phi_rad), np.asarray(psi_rad), basin), float) <= 0.0


@dataclass
class Walker:
    """A continuing MD walker: one context, stepped in chunks, accumulating frames."""
    name: str
    simulation: object
    n_atoms: int
    frames: list = field(default_factory=list)      # list of (n_atoms, 3) float32, nm
    n_steps_run: int = 0

    def advance(self, duration_ps: float, save_interval_ps: float = 1.0) -> np.ndarray:
        """Step the walker and return the coordinates collected during THIS chunk (nm).

        If a preload source is attached (``preload_source`` / ``preload_per_gen`` /
        ``preload_cursor``), the chunk is READ from that trajectory instead of integrated. This is
        a compute shortcut only: the caller receives exactly the number of frames the protocol
        would have produced, at the same spacing, so the ensemble seen by the estimator is
        unchanged. Appending a whole foreign trajectory instead would silently hand the estimator a
        much larger hot ensemble -- a different experiment, not a cheaper one.
        """
        from openmm import unit

        src = getattr(self, "preload_source", None)
        if src is not None:
            n = int(getattr(self, "preload_per_gen", 0)) or max(
                1, int(round(duration_ps / save_interval_ps)))
            i = int(getattr(self, "preload_cursor", 0))
            if i + n > len(src):
                raise RuntimeError(
                    "preload source exhausted: %d frames requested from cursor %d of %d. "
                    "Use a longer pre-run walker or fewer generations." % (n, i, len(src)))
            chunk = src[i:i + n]
            self.preload_cursor = i + n
            self.frames.append(chunk)
            self.n_steps_run += int(round(duration_ps * 1000.0 / TIMESTEP_FS))
            return chunk

        n_save = max(1, int(round(save_interval_ps * 1000.0 / TIMESTEP_FS)))
        n_chunks = max(1, int(round(duration_ps / save_interval_ps)))
        out = np.empty((n_chunks, self.n_atoms, 3), np.float32)
        for i in range(n_chunks):
            self.simulation.step(n_save)
            st = self.simulation.context.getState(getPositions=True)
            out[i] = st.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
            if not np.isfinite(out[i]).all():
                raise RuntimeError(f"walker {self.name!r} produced NaN coordinates after "
                                   f"{self.n_steps_run + (i + 1) * n_save} steps")
        self.n_steps_run += n_chunks * n_save
        self.frames.append(out)
        return out

    def all_frames(self) -> np.ndarray:
        return np.concatenate(self.frames) if self.frames else np.zeros((0, self.n_atoms, 3))

    def torsions(self, coords: Optional[np.ndarray] = None):
        """(phi, psi) in RADIANS for the given coordinates (default: all accumulated frames)."""
        import mdtraj as md
        xyz = self.all_frames() if coords is None else np.asarray(coords)
        if len(xyz) == 0:
            return np.zeros(0), np.zeros(0)
        traj = md.Trajectory(xyz, self._mdtop)
        return md.compute_phi(traj)[1][:, 0], md.compute_psi(traj)[1][:, 0]

    _mdtop: object = None


def _make_simulation(system, positions_nm, seed: int, platform_name: str, device: Optional[str],
                     minimize_steps: int = 500, equilibrate_ps: float = 2.0):
    """Create the context and relax the seed.

    Minimisation/equilibration happen ONCE, here, at walker creation. AIS landing endpoints are
    nonequilibrium structures and integrate straight to NaN without it. This is NOT in tension
    with keeping the context alive across generations: the continuation never re-minimises, which
    is exactly what restarting through ``md_run.run_single_md`` each generation would do.
    """
    from openmm import LangevinMiddleIntegrator, Platform, app, unit

    integrator = LangevinMiddleIntegrator(T_BASE_K * unit.kelvin,
                                          FRICTION_PER_PS / unit.picosecond,
                                          TIMESTEP_FS * unit.femtosecond)
    # MUST precede Context creation; setRandomNumberSeed afterwards is silently ignored.
    integrator.setRandomNumberSeed(int(seed))
    platform = Platform.getPlatformByName(platform_name)
    props = {}
    if platform_name in ("CUDA", "OpenCL"):
        props["Precision"] = "mixed"                 # platform default is single -- never rely on it
        if device is not None:
            props["DeviceIndex" if platform_name == "CUDA" else "OpenCLDeviceIndex"] = str(device)
    top = load_topology()
    sim = app.Simulation(top, system, integrator, platform, props)
    sim.context.setPositions(np.asarray(positions_nm) * unit.nanometer)
    if minimize_steps > 0:
        sim.minimizeEnergy(maxIterations=int(minimize_steps))
    sim.context.setVelocitiesToTemperature(T_BASE_K * unit.kelvin, int(seed))
    n_eq = int(round(equilibrate_ps * 1000.0 / TIMESTEP_FS))
    if n_eq > 0:
        sim.step(n_eq)
    st = sim.context.getState(getPositions=True)
    if not np.isfinite(st.getPositions(asNumpy=True).value_in_unit(unit.nanometer)).all():
        raise RuntimeError("walker seed integrated to NaN during equilibration; the seed "
                           "structure is unusable")
    return sim


def make_hot_walker(positions_nm, s_hot: float, seed: int, platform_name: str = "CUDA",
                    device: Optional[str] = None) -> Walker:
    """Hot REST2 walker at solute scale ``s_hot``."""
    import mdtraj as md

    from escort_ais.systems.openmm_system import build_rest2_scaled_system

    base = build_base_system()
    system = build_rest2_scaled_system(base, np.arange(N_SOLUTE), float(s_hot))
    sim = _make_simulation(system, positions_nm, seed, platform_name, device)
    w = Walker(name=f"hot_s{s_hot:g}", simulation=sim, n_atoms=system.getNumParticles())
    w._mdtop = md.Topology.from_openmm(load_topology())
    return w


def make_box_walker(positions_nm, basin, seed: int, platform_name: str = "CUDA",
                    device: Optional[str] = None) -> Walker:
    """Cold walker confined by the rectangular flat-bottom restraint of ``basin``.

    The restraint exists only to generate the confined ensemble. It is NOT part of any AIS work:
    the reverse legs are run on a restraint-free system seeded from this walker's interior frames.
    """
    import mdtraj as md

    from escort_ais.methods.rectangular_flatbottom import build_rectangular_flatbottom_cvforce

    system = build_base_system()
    top = load_topology()
    phi_q, psi_q = torsion_quartets(top)
    force = build_rectangular_flatbottom_cvforce(phi_q, psi_q, basin, KT_KJ)
    system.addForce(force)
    sim = _make_simulation(system, positions_nm, seed, platform_name, device)
    w = Walker(name=basin.label, simulation=sim, n_atoms=system.getNumParticles())
    w._mdtop = md.Topology.from_openmm(top)
    return w


def write_seed_dir(seed_dir: Path, xyz_nm: np.ndarray, seed_config: dict, top_pdb: Path) -> Path:
    """Write the {config.json, start_structure.pdb, trajectory.dcd} an AIS leg needs."""
    import json
    import shutil

    import mdtraj as md

    seed_dir.mkdir(parents=True, exist_ok=True)
    (seed_dir / "config.json").write_text(json.dumps(seed_config))
    shutil.copy(top_pdb, seed_dir / "start_structure.pdb")
    ref = md.load(str(top_pdb))
    md.Trajectory(np.asarray(xyz_nm), ref.topology).save_dcd(str(seed_dir / "trajectory.dcd"))
    return seed_dir


def integrated_act(x: np.ndarray, n_max: int = 500) -> float:
    """Integrated autocorrelation time of a scalar series, initial-positive-sequence truncation.

    Must be applied WITHIN a single walker: computing it across a concatenation of independent
    walkers fakes decorrelation.
    """
    x = np.asarray(x, float).ravel()
    n = len(x)
    if n < 8:
        return float("nan")
    x = x - x.mean()
    var = np.dot(x, x) / n
    if var <= 0:
        return float("nan")
    tau = 1.0
    for k in range(1, min(n_max, n - 1)):
        c = np.dot(x[:-k], x[k:]) / (n * var)
        if c <= 0:
            break
        tau += 2.0 * c
    return float(tau)
