"""chunked_neq_ais.py — on-device NEQ AIS with sparse Hummer-Szabo observations.

Three execution modes, deliberately separated (see the acceleration report,
``reports/alanine/ais_performance/ais_acceleration_report.md``):

* **validation** — small trajectory counts with every diagnostic enabled: manual-vs-NEQ work
  comparison, determinism checks, force-contamination checks.  Records what discovery records.

* **production** — the whole hot->cold protocol runs in ONE on-device call; a single
  readback of the cumulative protocol work per trajectory; coordinates only at the end.
  Nothing is read back per switch and nothing is accumulated Python-side.
* **discovery** — the same continuous trajectory is *paused* at a small number of
  square-spaced observation points (default 20), where compact scalars are recorded for
  Hummer-Szabo reconstruction.  Full atomic coordinates are saved on an INDEPENDENT
  physical-time schedule (default every 5 ps), not at every observation.

Three measured facts underpin the design (``tests/test_chunked_neq_ais.py``):

1. **Chunking is exact.** Pausing ``AlchemicalNonequilibriumLangevinIntegrator`` mid-protocol
   and resuming reproduces the one-shot trajectory *bit for bit* — work and final positions
   agree to 0 ULP for even and uneven chunkings, on Reference and CUDA.  Observation points
   are therefore free of numerical cost; only the readback costs time.
2. **Contexts are reusable.** One switching Context + integrator serves every trajectory in a
   worker; ``integrator.reset()`` restores the protocol index, lambda and cumulative work but
   NOT the random stream, so consecutive trajectories are independent while the whole
   per-worker sequence stays reproducible for a fixed seed.
3. **The cold context is a correctness device, not a speed-up.** ``u_C`` is evaluated in a
   persistent context pinned at ``s = s_cold`` with a bare VerletIntegrator so the switching
   context is provably never rescaled mid-protocol.  Measured, it is ~19 % SLOWER per
   observation than rescale-and-restore (it pays a host->device position upload); it is kept
   for the guarantee, and in production mode it is not instantiated at all (§9).

Work conventions are unchanged: forward = hot->cold, reverse = cold->hot, reduced
``W = -log w``, and the protocol work is exactly what the integrator accumulates.  No
umbrella/restraint force is ever added here — the flat-bottom windows generate the cold
proposal ensemble elsewhere and must not contaminate the physical AIS work.
"""
from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Literal, Optional, Sequence

import numpy as np

# Hoisted: this used to be imported inside the per-observation CV helpers, so the import
# machinery ran once per CV per slice.
from escort_ais.analysis.analysis import dihedral_deg as _dihedral_deg

__all__ = [
    "ChunkedNEQConfig",
    "EngineSafetyError",
    "assert_no_umbrella_force",
    "assert_cv_probe_is_inert",
    "build_cv_probe_force",
    "CV_PROBE_FORCE_GROUP",
    "assert_context_platform",
    "assert_cold_context_is_physical",
    "assert_neq_integrator",
    "runtime_banner",
    "hz_observation_indices",
    "coordinate_frame_indices",
    "sqrt_spaced_scales",
    "Timer",
    "ChunkedNEQRunner",
    "worker_seed",
]

BOLTZMANN_KJ_PER_MOL_K = 0.00831446261815324


# ─────────────────────────────────────────────────────────────────────────────
# configuration
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class ChunkedNEQConfig:
    """Everything that defines one worker's AIS leg.

    The defaults ARE the frozen production configuration (report §1): square-spaced REST2,
    ``Freq_AIS = 1``, on-device NEQ work, no intermediate output.  ``mode`` only changes what is
    *recorded*; it never changes the physical protocol.
    """
    # ── physical path (frozen: square-spaced REST2, see report §1) ──────────
    s_hot: float = 0.25
    s_cold: float = 1.0
    scaling_mode: str = "square"
    t_ais: int = 500                      # total MD steps == switching intervals x freq;
                                          # 500 x 2 fs = 1 ps is the adopted switch length
    freq_ais: int = 1                     # MD steps per perturbation interval
    temperature_k: float = 300.0
    timestep_fs: float = 2.0
    friction_per_ps: float = 1.0

    # ── mode and observation schedules (independent of each other) ──────────
    mode: Literal["validation", "discovery", "production"] = "production"
    # ``None``/``"auto"`` mean "take the frozen preset for this mode" (§1); an explicit value
    # that contradicts the mode is an error, not a silent override.
    hz_n_observations: Optional[int] = None     # square-spaced HS observation states
    # Restrict the HS observation window to ``s in [hz_s_min, s_cold]``.  ``None`` (default)
    # spreads the observations over the whole switch, which is what every run before 2026-08-04
    # did.  Only slices near the cold end carry usable HS weight, so on the standard
    # ``s_hot=0.25`` schedule roughly two thirds of the observations are discarded by the
    # ``s >= s_min`` filter in the reconstruction; setting this places all ``hz_n_observations``
    # inside the window that is actually used instead of relying on the caller having requested
    # 61 to obtain 20.  The accumulated work is tracked continuously on the device, so declining
    # to observe below ``hz_s_min`` costs no information.
    hz_s_min: Optional[float] = None
    full_coordinate_interval_ps: Optional[float] | str = "auto"   # None disables sparse frames
    save_final_coordinates: bool = True
    save_initial_coordinates: bool = False

    # ── engine ──────────────────────────────────────────────────────────────
    platform: str = "CUDA"
    device_index: Optional[str] = None
    precision: str = "mixed"
    require_platform: bool = True         # fail loudly if `platform` is unavailable (§8)
    require_precision: bool = True        # fail loudly if the context is not at `precision` (§8)
    require_gpu_switching: bool = True    # fail loudly if the REST2 global-parameter scaler is absent

    # ── provenance carried through to every row (§13) ───────────────────────
    leg: Literal["forward", "reverse"] = "forward"
    proposal_id: Optional[str] = None     # reverse legs: which proposal ensemble started them
    source_window_id: Optional[str] = None

    # ── output ──────────────────────────────────────────────────────────────
    out_dir: Optional[Path] = None
    flush_every: int = 64                 # trajectories buffered before a write

    # ── frozen presets (report §1) ──────────────────────────────────────────
    PRODUCTION_DEFAULTS = dict(scaling_mode="square", freq_ais=1, hz_n_observations=0,
                               full_coordinate_interval_ps=None, save_final_coordinates=True)
    DISCOVERY_DEFAULTS = dict(scaling_mode="square", freq_ais=1, hz_n_observations=20,
                              full_coordinate_interval_ps=5.0, save_final_coordinates=True)

    def __post_init__(self):
        if self.mode not in ("validation", "discovery", "production"):
            raise ValueError(f"unknown mode {self.mode!r}")
        # resolve the frozen presets (§1) for anything the caller left unset
        preset = (self.PRODUCTION_DEFAULTS if self.mode == "production"
                  else self.DISCOVERY_DEFAULTS)
        if self.hz_n_observations is None:
            self.hz_n_observations = preset["hz_n_observations"]
        if self.full_coordinate_interval_ps == "auto":
            self.full_coordinate_interval_ps = preset["full_coordinate_interval_ps"]
        # §2: reject incompatible combinations rather than silently honouring them.
        if self.mode == "production":
            if self.hz_n_observations:
                raise ValueError("production mode records no Hummer-Szabo observations; "
                                 "got hz_n_observations=%d (use --mode discovery)"
                                 % self.hz_n_observations)
            if self.full_coordinate_interval_ps:
                raise ValueError("production mode writes no intermediate coordinates; got "
                                 f"full_coordinate_interval_ps={self.full_coordinate_interval_ps}")
            if not self.save_final_coordinates:
                raise ValueError("production mode must keep the final landing coordinates "
                                 "(they are the umbrella seeds)")
        if self.mode == "discovery" and self.hz_n_observations < 2:
            raise ValueError("discovery mode needs >= 2 HS observations; "
                             f"got {self.hz_n_observations}")
        if self.hz_s_min is not None:
            if not self.s_hot <= self.hz_s_min < self.s_cold:
                raise ValueError("hz_s_min must lie in [s_hot, s_cold); got "
                                 f"{self.hz_s_min} for s_hot={self.s_hot}, s_cold={self.s_cold}")
            if not self.hz_n_observations:
                raise ValueError("hz_s_min restricts the HS observation window but no HS "
                                 "observations were requested")
        if self.t_ais % self.freq_ais:
            raise ValueError(f"t_ais={self.t_ais} not divisible by freq_ais={self.freq_ais}")

    @property
    def m_ais(self) -> int:
        return self.t_ais // self.freq_ais

    @property
    def collects_hz(self) -> bool:
        return self.mode in ("discovery", "validation") and self.hz_n_observations > 1

    @property
    def switch_duration_ps(self) -> float:
        return self.t_ais * self.timestep_fs / 1000.0

    @property
    def needs_cold_context(self) -> bool:
        """§9: the cold-energy context exists only where u_C(x_ik) is actually recorded."""
        return self.collects_hz


# ─────────────────────────────────────────────────────────────────────────────
# schedules
# ─────────────────────────────────────────────────────────────────────────────
def sqrt_spaced_scales(s_hot: float, s_cold: float, n: int) -> np.ndarray:
    """``s_l = [sqrt(s_H) + l/(n-1) (sqrt(s_C) - sqrt(s_H))]^2``, l = 0..n-1."""
    if n < 2:
        raise ValueError("n must be >= 2")
    r = np.linspace(np.sqrt(float(s_hot)), np.sqrt(float(s_cold)), int(n))
    return r ** 2


def hz_observation_indices(s_hot: float, s_cold: float, m_ais: int,
                           n_obs: int = 20, scaling_mode: str = "square",
                           s_min: Optional[float] = None) -> np.ndarray:
    """Switching indices at which to pause for a Hummer-Szabo observation.

    The observation targets are defined **independently of the switching interval count**:
    ``L = n_obs`` states uniformly spaced in ``sqrt(s)``.  Each target is mapped to the
    nearest actual switching index; duplicates are removed and the endpoints (initial hot
    state 0 and final cold state ``m_ais``) are always present.  This is what stops the
    observation count from tracking ``Freq_AIS = 1``.

    ``s_min`` restricts the targets to ``s in [s_min, s_cold]``, so that all ``n_obs`` of them
    fall inside the window the reconstruction actually keeps.  The hot endpoint 0 is then NOT
    forced into the schedule -- it lies outside the requested window and would be discarded by
    the same ``s >= s_min`` filter downstream.  Nothing is lost by not observing there: the
    accumulated work ``W_{i,0:k}`` is integrated continuously on the device, and an observation
    only reads out the state that is already being tracked.

    Returns a sorted array of unique indices in ``[0, m_ais]``.
    """
    m_ais = int(m_ais)
    if m_ais < 1:
        raise ValueError("m_ais must be >= 1")
    if n_obs < 2:
        return np.array([0, m_ais], dtype=int)

    # actual switching grid, in the same sqrt(s) coordinate
    if scaling_mode == "square":
        r_grid = np.linspace(np.sqrt(s_hot), np.sqrt(s_cold), m_ais + 1)
    elif scaling_mode == "linear":
        r_grid = np.sqrt(np.linspace(s_hot, s_cold, m_ais + 1))
    else:
        raise ValueError(f"unknown scaling_mode {scaling_mode!r}")

    if s_min is None:
        cand = np.arange(m_ais + 1)
    else:
        # Restrict the CANDIDATE indices, not just the targets.  Snapping a target to the
        # nearest grid point can round it below the requested window -- at m_ais=2500 the
        # s_min=0.7 target lands on s=0.69990 -- and the reconstruction's ``s >= s_min``
        # filter would then silently discard that slice, returning n_obs-1 of them.
        cand = np.flatnonzero(r_grid >= np.sqrt(float(s_min)) - 1e-12)
        if cand.size == 0:
            raise ValueError("no switching index has s >= s_min=%.4f" % s_min)
    lo = r_grid[cand[0]] if s_min is not None else np.sqrt(s_hot)
    targets = np.linspace(lo, np.sqrt(s_cold), int(n_obs))
    idx = cand[np.abs(r_grid[cand][None, :] - targets[:, None]).argmin(axis=1)]
    forced = [m_ais] if s_min is not None else [0, m_ais]
    idx = np.unique(np.concatenate([idx, forced]))
    return idx.astype(int)


def coordinate_frame_indices(m_ais: int, freq_ais: int, timestep_fs: float,
                             interval_ps: Optional[float]) -> np.ndarray:
    """Switching indices at which to store FULL coordinates, on a physical-time schedule.

    Deliberately unrelated to the HS schedule: HS records compact scalars often, coordinates
    are heavy and are stored rarely.  ``interval_ps=None`` disables sparse frames entirely.
    """
    if interval_ps is None or interval_ps <= 0:
        return np.array([], dtype=int)
    ps_per_interval = freq_ais * timestep_fs / 1000.0
    stride = max(1, int(round(float(interval_ps) / ps_per_interval)))
    return np.arange(0, int(m_ais) + 1, stride, dtype=int)


def worker_seed(base_seed: int, worker: int, trajectory: int) -> int:
    """Deterministic, collision-free: ``base + 10^6 * w + i`` (report §7)."""
    return int(base_seed) + 1_000_000 * int(worker) + int(trajectory)


# ─────────────────────────────────────────────────────────────────────────────
# runtime safety checks (report §8) -- every one of these FAILS LOUDLY
# ─────────────────────────────────────────────────────────────────────────────
class EngineSafetyError(RuntimeError):
    """A silent-degradation guard tripped. Never caught internally; never downgraded."""


UMBRELLA_PARAMETER_NAMES = frozenset({"kwall", "hw", "umbrella_lambda"})

# Force group reserved for the inert CV probe.  Nothing else in this package sets a force
# group, so every physical force lives in group 0 and the probe cannot collide with one.
CV_PROBE_FORCE_GROUP = 30


def build_cv_probe_force(quartets, names, openmm):
    """A ZERO-ENERGY ``CustomCVForce`` that reports torsional CVs straight off the device.

    Each CV is a ``CustomTorsionForce("theta")`` wrapped in a ``CustomCVForce`` whose own energy
    expression is the literal ``"0"``.  The wrapper therefore contributes **no energy and no
    force** -- verified bit-identically, and re-checked at runtime by
    :func:`assert_cv_probe_is_inert` -- while ``getCollectiveVariableValues(context)`` still
    evaluates the inner torsions.  This replaces a full ``getPositions`` device->host transfer
    plus a NumPy dihedral per CV with one scalar readback for all CVs at once.

    Returns ``None`` when there is nothing to probe, so callers can treat the probe as optional.
    """
    quartets = [q for q in (quartets or [])]
    if not quartets:
        return None
    if len(names) != len(quartets):
        raise ValueError(f"{len(names)} CV names for {len(quartets)} quartets")
    cv = openmm.CustomCVForce("0")
    for slot, (name, quartet) in enumerate(zip(names, quartets)):
        idx = [int(i) for i in np.asarray(quartet, int).ravel()]
        if len(idx) != 4:
            raise ValueError(f"CV {name!r}: expected a 4-atom quartet, got {idx}")
        tor = openmm.CustomTorsionForce("theta")
        tor.addTorsion(*idx, [])
        # CustomCVForce requires unique, expression-safe CV names; the parquet column keeps the
        # human-readable one. Order is positional and matches ``names``.
        cv.addCollectiveVariable(f"cv{slot}", tor)
    cv.setForceGroup(CV_PROBE_FORCE_GROUP)
    return cv


def assert_cv_probe_is_inert(context) -> None:
    """§8: the CV probe must contribute exactly zero potential energy.

    A probe that carried energy would enter the protocol work silently -- the same failure mode
    :func:`assert_no_umbrella_force` guards against, but self-inflicted.  Checked against the
    real context on the real platform, not assumed from the energy expression.
    """
    from openmm import unit as _u

    e = (context.getState(getEnergy=True, groups={CV_PROBE_FORCE_GROUP})
         .getPotentialEnergy().value_in_unit(_u.kilojoule_per_mole))
    if e != 0.0:
        raise EngineSafetyError(
            f"CV probe force group {CV_PROBE_FORCE_GROUP} contributes {e!r} kJ/mol, not 0. "
            "It would enter the protocol work. Refusing to run.")


def assert_no_umbrella_force(system) -> None:
    """§8/§10: an umbrella/flat-bottom force must never live in a system carrying AIS work.

    The restraints exist only to generate proposal ensembles; if one reached the switching
    system its energy would enter the protocol work silently and bias every estimator built on
    it.  Checked structurally (global-parameter names + the flat-bottom energy expression), not
    by trusting the caller.
    """
    import openmm

    found = []
    for fi in range(system.getNumForces()):
        f = system.getForce(fi)
        if hasattr(f, "getNumGlobalParameters"):
            for gp in range(f.getNumGlobalParameters()):
                name = f.getGlobalParameterName(gp)
                if name in UMBRELLA_PARAMETER_NAMES:
                    found.append(f"{type(f).__name__}.{name}")
        expr = getattr(f, "getEnergyFunction", None)
        if expr is not None and isinstance(f, (openmm.CustomCVForce, openmm.CustomCompoundBondForce,
                                               openmm.CustomTorsionForce)):
            try:
                if "dwall" in f.getEnergyFunction():
                    found.append(f"{type(f).__name__}(flat-bottom wall)")
            except Exception:
                pass
    if found:
        raise EngineSafetyError(
            "umbrella/restraint force present in the physical AIS switching system: "
            + ", ".join(found)
            + " -- the restraint would enter the protocol work. Restraints belong to "
              "proposal-generation MD only (see report §10).")


def _resolve_platform(openmm, cfg):
    available = {openmm.Platform.getPlatform(i).getName()
                 for i in range(openmm.Platform.getNumPlatforms())}
    if cfg.platform not in available:
        if cfg.require_platform:
            raise EngineSafetyError(
                f"platform {cfg.platform!r} was requested but is not available "
                f"(available: {sorted(available)}). Refusing to silently fall back.")
        raise RuntimeError(f"platform {cfg.platform!r} unavailable")
    return openmm.Platform.getPlatformByName(cfg.platform)


def assert_context_platform(context, cfg) -> None:
    """§8: fail if the context is not on the requested platform/precision.

    The precision check is the one that matters in practice: the CUDA default is *single*, and a
    single-precision context silently changes the accumulated work while running ~25 % faster.
    """
    got = context.getPlatform().getName()
    if got != cfg.platform and cfg.require_platform:
        raise EngineSafetyError(f"requested platform {cfg.platform!r} but the context runs on "
                                f"{got!r}")
    if cfg.platform in ("CUDA", "OpenCL") and cfg.require_precision:
        try:
            prec = context.getPlatform().getPropertyValue(context, "Precision")
        except Exception:                                  # property absent -> nothing to check
            return
        if prec != cfg.precision:
            raise EngineSafetyError(
                f"requested {cfg.precision!r} precision but the context reports {prec!r}; "
                "single precision silently changes the accumulated protocol work.")


def assert_cold_context_is_physical(switch_context, cold_context, scaler, cfg,
                                    tol_kj: float = 1e-4) -> None:
    """§8: the cold context must be the SAME Hamiltonian at ``s = s_cold``, not a second build.

    Verified numerically: put the switching context's coordinates into the cold context, scale
    the switching context to ``s_cold`` momentarily, and require the two energies to agree.  The
    switching context is restored to its exact prior global-parameter state afterwards.
    """
    import openmm
    unit = openmm.unit
    st = switch_context.getState(getPositions=True)
    xyz = st.getPositions(asNumpy=True)
    cold_context.setPositions(xyz)
    e_cold = cold_context.getState(getEnergy=True).getPotentialEnergy() \
        .value_in_unit(unit.kilojoule_per_mole)
    saved = {n: switch_context.getParameter(n) for n in scaler._params}
    try:
        scaler.apply(float(cfg.s_cold), switch_context)
        e_ref = switch_context.getState(getEnergy=True).getPotentialEnergy() \
            .value_in_unit(unit.kilojoule_per_mole)
    finally:
        for n, v in saved.items():
            switch_context.setParameter(n, v)
    if abs(e_cold - e_ref) > tol_kj * max(1.0, abs(e_ref)):
        raise EngineSafetyError(
            f"cold-energy context disagrees with the physical cold Hamiltonian: "
            f"{e_cold:.6f} vs {e_ref:.6f} kJ/mol (|Δ| = {abs(e_cold - e_ref):.3e}). "
            "u_C would be evaluated under the wrong Hamiltonian.")


def assert_neq_integrator(integrator) -> None:
    """§8: the on-device NEQ path must actually be an alchemical NEQ integrator with a set seed."""
    name = type(integrator).__name__
    if "Nonequilibrium" not in name:
        raise EngineSafetyError(
            f"NEQ work accumulation was requested but the integrator is {name!r} -- the run "
            "would silently fall back to the manual per-switch path.")
    if int(integrator.getRandomNumberSeed()) == 0:
        raise EngineSafetyError(
            "the NEQ integrator random seed is 0 (unset). OpenMM ignores setRandomNumberSeed "
            "after Context creation, so the accumulated work would not be reproducible.")


def runtime_banner(cfg, context=None, integrator=None, extra: Optional[dict] = None) -> dict:
    """§8: the environment record printed and saved at the start of every run."""
    import openmm

    d = {
        "openmm_version": openmm.version.version,
        "requested_platform": cfg.platform,
        "requested_precision": cfg.precision,
        "device_index": cfg.device_index,
        "mode": cfg.mode,
        "leg": cfg.leg,
        "scaling_mode": cfg.scaling_mode,
        "s_hot": cfg.s_hot, "s_cold": cfg.s_cold,
        "freq_ais": cfg.freq_ais,
        "t_ais_steps": cfg.t_ais,
        "m_ais_switching_intervals": cfg.m_ais,
        "timestep_fs": cfg.timestep_fs,
        "switch_duration_ps": cfg.switch_duration_ps,
        "temperature_k": cfg.temperature_k,
        "friction_per_ps": cfg.friction_per_ps,
        "hz_n_observations": cfg.hz_n_observations if cfg.collects_hz else 0,
        "full_coordinate_interval_ps": cfg.full_coordinate_interval_ps,
        "cold_context_instantiated": bool(cfg.needs_cold_context),
    }
    if context is not None:
        d["actual_platform"] = context.getPlatform().getName()
        try:
            d["actual_precision"] = context.getPlatform().getPropertyValue(context, "Precision")
        except Exception:
            d["actual_precision"] = "n/a"
    if integrator is not None:
        d["integrator"] = type(integrator).__name__
        d["integrator_random_seed"] = int(integrator.getRandomNumberSeed())
        d["neq_integrator"] = "Nonequilibrium" in type(integrator).__name__
    if extra:
        d.update(extra)
    return d


# ─────────────────────────────────────────────────────────────────────────────
# profiling
# ─────────────────────────────────────────────────────────────────────────────
class Timer:
    """Accumulating wall-clock timer keyed by stage name (report §11)."""

    def __init__(self):
        self.total: dict[str, float] = {}
        self.count: dict[str, int] = {}

    @contextmanager
    def __call__(self, key: str):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            dt = time.perf_counter() - t0
            self.total[key] = self.total.get(key, 0.0) + dt
            self.count[key] = self.count.get(key, 0) + 1

    def as_dict(self) -> dict:
        return {k: dict(seconds=self.total[k], calls=self.count[k],
                        ms_per_call=1e3 * self.total[k] / max(self.count[k], 1))
                for k in sorted(self.total)}


# ─────────────────────────────────────────────────────────────────────────────
# the runner
# ─────────────────────────────────────────────────────────────────────────────
class ChunkedNEQRunner:
    """One persistent switching context + one persistent cold-energy context, reused for
    every trajectory this worker runs.

    Lifetime rules (these are what make it fast):
      * the switching Context and NEQ integrator are built ONCE;
      * ``integrator.reset()`` between trajectories -- never between observation blocks;
      * the cold context is pinned at ``s = s_cold`` and never rescaled;
      * the switching context is never rescaled to cold and back.
    """

    def __init__(self, cfg: ChunkedNEQConfig, base_system, topology,
                 solute_indices: np.ndarray, phi_indices=None, psi_indices=None,
                 omega_exclude_bonds=None, worker_id: int = 0, base_seed: int = 20260728,
                 cv_definition=None):
        import openmm
        from openmmtools.integrators import AlchemicalNonequilibriumLangevinIntegrator
        from escort_ais.methods.ais_linear import alchemical_functions_for
        from escort_ais.systems.openmm_system import build_rest2_lambda_system, Rest2LambdaScaler

        self.cfg = cfg
        self.worker_id = int(worker_id)
        self.base_seed = int(base_seed)
        self.timer = Timer()
        self.topology = topology
        self.phi_indices = phi_indices
        self.psi_indices = psi_indices
        # Generic CVs (systems/<slug>/cv_definition.json). phi_indices/psi_indices are the 2-CV
        # legacy path and are kept for the dipeptide schema; for a macrocycle they are None and
        # mdtraj finds nothing, which is how 183 000 all-NaN rows were written for RGD.
        self.cv = cv_definition
        self.cv_cols = list(cv_definition.column_names()) if cv_definition is not None else []
        self._openmm = openmm
        self.kT = BOLTZMANN_KJ_PER_MOL_K * cfg.temperature_k

        with self.timer("context_initialization"):
            self.system = build_rest2_lambda_system(
                base_system, np.asarray(solute_indices, int),
                exclude_central_bonds=omega_exclude_bonds)
            self.scaler = Rest2LambdaScaler(self.system)
            afuncs = {k: v for k, v in
                      alchemical_functions_for(cfg.s_hot, cfg.s_cold, cfg.scaling_mode).items()
                      if k in set(self.scaler._params)}
            if not afuncs and cfg.require_gpu_switching:
                raise RuntimeError(
                    "REST2 global-parameter (GPU-side) switching is unavailable for this system, "
                    "so the run would silently fall back to the per-window reload scaler. Refusing "
                    "in production; pass require_gpu_switching=False to override.")
            if not afuncs:
                raise RuntimeError("no REST2 global parameters present; GPU switching unavailable")
            self.alchemical_functions = afuncs
            assert_no_umbrella_force(self.system)          # §8/§10: never bias the physical work

            # Inert on-device CV probe. Added BEFORE the Context exists, since a System cannot
            # gain a force afterwards. Prefers the declared cv_definition; falls back to the
            # legacy (phi, psi) pair so the dipeptide schema is unchanged.
            if self.cv is not None:
                probe_q, probe_names = list(self.cv.quartets), list(self.cv_cols)
            elif phi_indices is not None and psi_indices is not None:
                probe_q, probe_names = [phi_indices, psi_indices], ["phi", "psi"]
            else:
                probe_q, probe_names = [], []
            self.cv_probe = build_cv_probe_force(probe_q, probe_names, openmm)
            self.cv_probe_names = probe_names
            if self.cv_probe is not None:
                self.system.addForce(self.cv_probe)

            splitting = "H " + " ".join(["V R O R V"] * max(int(cfg.freq_ais), 1))
            self.integrator = AlchemicalNonequilibriumLangevinIntegrator(
                alchemical_functions=afuncs, nsteps_neq=cfg.m_ais, splitting=splitting,
                temperature=cfg.temperature_k * openmm.unit.kelvin,
                collision_rate=cfg.friction_per_ps / openmm.unit.picosecond,
                timestep=cfg.timestep_fs * openmm.unit.femtosecond)
            # seed BEFORE Context creation -- setting it afterwards has no effect
            self.integrator.setRandomNumberSeed(worker_seed(base_seed, worker_id, 0))

            plat = _resolve_platform(openmm, cfg)
            props = {}
            if cfg.platform in ("CUDA", "OpenCL"):
                props["Precision"] = cfg.precision
                if cfg.device_index is not None:
                    props["DeviceIndex" if cfg.platform == "CUDA" else "OpenCLDeviceIndex"] = \
                        str(cfg.device_index)
            self.context = (openmm.Context(self.system, self.integrator, plat, props)
                            if props else openmm.Context(self.system, self.integrator, plat))
            assert_context_platform(self.context, cfg)    # §8: no silent CPU/single-precision run

            # ── persistent COLD-energy context (report §3, §9) ──────────────
            # Same system, so u_C is exactly the switching Hamiltonian at s = s_cold -- there is
            # no second Hamiltonian to drift.  A bare VerletIntegrator: this context never
            # integrates, it only reports energy.  It is built ONLY when u_C is actually
            # recorded (§9): production mode never instantiates it.
            self.cold_context = None
            self.cold_integrator = None
            if cfg.needs_cold_context:
                self.cold_integrator = openmm.VerletIntegrator(
                    cfg.timestep_fs * openmm.unit.femtosecond)
                self.cold_context = (openmm.Context(self.system, self.cold_integrator, plat, props)
                                     if props else
                                     openmm.Context(self.system, self.cold_integrator, plat))
                self.scaler.apply(float(cfg.s_cold), self.cold_context)  # pinned, once, forever
                # the u_C-Hamiltonian equality check needs real coordinates, so it runs lazily
                # at the first observation (see _cold_energy).
                self._cold_context_verified = False

        # the inert-probe check also needs real coordinates -> lazy, see _probe_cvs_deg
        self._cv_probe_verified = False

        self.hz_idx = hz_observation_indices(cfg.s_hot, cfg.s_cold, cfg.m_ais,
                                             cfg.hz_n_observations, cfg.scaling_mode,
                                             s_min=cfg.hz_s_min)
        self.coord_idx = set(int(i) for i in coordinate_frame_indices(
            cfg.m_ais, cfg.freq_ais, cfg.timestep_fs, cfg.full_coordinate_interval_ps))
        self.scales = (sqrt_spaced_scales(cfg.s_hot, cfg.s_cold, cfg.m_ais + 1)
                       if cfg.scaling_mode == "square"
                       else np.linspace(cfg.s_hot, cfg.s_cold, cfg.m_ais + 1))

        assert_neq_integrator(self.integrator)             # §8, after the seed is set
        self.banner = runtime_banner(cfg, self.context, self.integrator, extra=dict(
            worker_id=self.worker_id, base_seed=self.base_seed,
            first_trajectory_seed=worker_seed(base_seed, worker_id, 0),
            n_hz_indices=int(len(self.hz_idx)) if cfg.collects_hz else 0,
            n_coordinate_frames=int(len(self.coord_idx)),
            rest2_global_parameters=sorted(afuncs),
        ))

        # output buffers (report §5) -- nothing is written per switch
        self.hz_rows: list[dict] = []
        self.summary_rows: list[dict] = []
        self.sparse_coords: list[np.ndarray] = []
        self.sparse_meta: list[dict] = []
        self._traj_counter = 0
        self._completed: set[int] = set()                  # for resume (§7)

    # ── stable downstream schema (report §13) ───────────────────────────────
    def _final_coord_ref(self, i_traj: int) -> str:
        """Where the final landing of trajectory ``i_traj`` will be found after the flush.

        Downstream code must never have to infer this from directory names, so the pointer is
        written into every row: ``worker_XX/sparse_coordinates.npz`` indexed by
        ``(trajectory_index, ais_interval_index == m_ais)``.
        """
        return f"worker_{self.worker_id:02d}/sparse_coordinates.npz#traj={i_traj},interval={self.cfg.m_ais}"

    def _summary_row(self, i_traj, vseed, w_reduced, phi, psi, n_obs,
                     start_phi=float("nan"), start_psi=float("nan")) -> dict:
        cfg = self.cfg
        return dict(
            # ── stable downstream schema ────────────────────────────────────
            trajectory_id=i_traj, leg=cfg.leg,
            proposal_id=cfg.proposal_id, source_window_id=cfg.source_window_id,
            reduced_work=w_reduced, reverse_work=(w_reduced if cfg.leg == "reverse" else None),
            final_phi=phi, final_psi=psi,
            starting_phi=start_phi, starting_psi=start_psi,
            starting_coordinate_reference=(
                f"worker_{self.worker_id:02d}/sparse_coordinates.npz#traj={i_traj},interval=0"
                if (cfg.save_initial_coordinates or 0 in self.coord_idx) else None),
            final_coordinate_reference=self._final_coord_ref(i_traj),
            # ── provenance / legacy aliases ─────────────────────────────────
            worker=self.worker_id, trajectory_index=i_traj, velocity_seed=vseed,
            final_W_kj=w_reduced * self.kT, final_W_reduced=w_reduced, final_logw=-w_reduced,
            n_hz_observations=n_obs, mode=cfg.mode,
            m_ais=cfg.m_ais, freq_ais=cfg.freq_ais, switch_duration_ps=cfg.switch_duration_ps)

    # ── observation ─────────────────────────────────────────────────────────
    def _probe_cvs_deg(self) -> Optional[dict]:
        """{name: degrees} read straight off the device, or ``None`` when no probe exists.

        One scalar readback for ALL CVs, versus a full ``getPositions`` transfer plus one NumPy
        dihedral per CV.  The first call also proves the probe is energetically inert (§8).
        """
        if self.cv_probe is None:
            return None
        with self.timer("cv_probe_readback"):
            vals = self.cv_probe.getCollectiveVariableValues(self.context)
        if not self._cv_probe_verified:
            assert_cv_probe_is_inert(self.context)
            self._cv_probe_verified = True
            self.banner["cv_probe_verified_inert"] = True
        return {n: float(np.degrees(v)) for n, v in zip(self.cv_probe_names, vals)}

    def _torsions(self, xyz: np.ndarray, probed: Optional[dict] = None) -> tuple[float, float]:
        if probed is not None and "phi" in probed and "psi" in probed:
            return probed["phi"], probed["psi"]
        phi = _dihedral_deg(xyz, self.phi_indices) if self.phi_indices is not None else float("nan")
        psi = _dihedral_deg(xyz, self.psi_indices) if self.psi_indices is not None else float("nan")
        return float(phi), float(psi)

    def _cvs(self, xyz: np.ndarray, probed: Optional[dict] = None) -> dict:
        """{column: degrees} for every declared CV, or {} when no definition was supplied."""
        if self.cv is None:
            return {}
        if probed is not None:
            return {c: probed[c] for c in self.cv_cols if c in probed}
        return {c: float(_dihedral_deg(np.asarray(xyz, float), q))
                for c, q in zip(self.cv_cols, self.cv.quartets)}

    def _cold_energy(self, xyz, box) -> float:
        """u_C(x) in kJ/mol from the PERSISTENT cold context. The switching context is
        untouched -- no scale change, no restore.

        On the FIRST call this also verifies (§8) that the cold context really is the physical
        cold Hamiltonian, by momentarily scaling the switching context to ``s_cold`` at the same
        coordinates and comparing.  The switching context's global parameters are restored
        exactly; the check runs once per worker.
        """
        unit = self._openmm.unit
        with self.timer("cold_context_position_assignment"):
            if box is not None:
                self.cold_context.setPeriodicBoxVectors(*box)
            self.cold_context.setPositions(xyz * unit.nanometer)
        with self.timer("cold_energy_evaluation"):
            e = self.cold_context.getState(getEnergy=True).getPotentialEnergy()
        e_kj = float(e.value_in_unit(unit.kilojoule_per_mole))
        if not self._cold_context_verified:
            assert_cold_context_is_physical(self.context, self.cold_context, self.scaler,
                                            self.cfg)
            self._cold_context_verified = True
            self.banner["cold_context_verified_against_physical_cold"] = True
        return e_kj

    # ── one trajectory ──────────────────────────────────────────────────────
    def run_trajectory(self, xyz0: np.ndarray, box=None, trajectory_index: Optional[int] = None,
                       velocity_seed: Optional[int] = None) -> dict:
        """Propagate one AIS leg. In production mode this is a single on-device call."""
        openmm = self._openmm
        unit = openmm.unit
        cfg = self.cfg
        i_traj = self._traj_counter if trajectory_index is None else int(trajectory_index)
        self._traj_counter += 1
        vseed = worker_seed(self.base_seed, self.worker_id, i_traj) if velocity_seed is None \
            else int(velocity_seed)

        with self.timer("position_assignment"):
            if box is not None:
                self.context.setPeriodicBoxVectors(*box)
            self.context.setPositions(np.asarray(xyz0, float) * unit.nanometer)
        with self.timer("velocity_initialization"):
            self.context.setVelocitiesToTemperature(cfg.temperature_k * unit.kelvin, vseed)
        # starting (phi, psi): needed by reverse legs so a proposal draw is traceable (§13)
        phi0, psi0 = (self._torsions(np.asarray(xyz0, float))
                      if self.phi_indices is not None else (float("nan"), float("nan")))
        # resets protocol index, lambda and cumulative work -- NOT the random stream
        self.integrator.reset()

        if cfg.save_initial_coordinates or (0 in self.coord_idx):
            x = self.context.getState(getPositions=True).getPositions(asNumpy=True) \
                .value_in_unit(unit.nanometer)
            self.sparse_coords.append(np.asarray(x, np.float32))
            self.sparse_meta.append(dict(trajectory_index=i_traj, ais_interval_index=0))

        if not cfg.collects_hz:
            # ── PRODUCTION: one on-device call, one work readback ───────────
            with self.timer("on_device_switching_md"):
                self.integrator.step(cfg.m_ais)
            with self.timer("final_state_retrieval"):
                w_reduced = float(self.integrator.get_protocol_work(dimensionless=True))
                need_x = cfg.save_final_coordinates or self.phi_indices is not None
                st = self.context.getState(getPositions=need_x)
                xf = (st.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
                      if need_x else None)
            phi, psi = self._torsions(xf) if xf is not None else (float("nan"), float("nan"))
            if cfg.save_final_coordinates and xf is not None:
                self.sparse_coords.append(np.asarray(xf, np.float32))
                self.sparse_meta.append(dict(trajectory_index=i_traj,
                                             ais_interval_index=cfg.m_ais))
            rec = self._summary_row(i_traj, vseed, w_reduced, phi, psi, 0,
                                    start_phi=phi0, start_psi=psi0)
            self.summary_rows.append(rec)
            self._completed.add(i_traj)
            return rec

        # ── DISCOVERY: pause at the HS observations AND, independently, at the
        # physical-time coordinate frames.  The two schedules are unrelated; the
        # trajectory is simply paused at the union of their indices. ───────────
        hz_set = set(int(k) for k in self.hz_idx)
        stops = sorted(hz_set | {int(k) for k in self.coord_idx})
        prev = 0
        n_obs = 0
        for k in stops:
            if k > prev:
                with self.timer("on_device_switching_md"):
                    self.integrator.step(k - prev)     # continuous; NO reset, NO rebuild
                prev = k
            is_hz = k in hz_set
            with self.timer("hz_position_readback"):
                # u_current comes from the SAME State as the positions, so it is free (§4):
                # one device->host transfer, not two.
                st = self.context.getState(getPositions=True, getEnergy=is_hz)
                xk = st.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
                u_cur = (float(st.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole))
                         if is_hz else float("nan"))
            if is_hz:
                with self.timer("hz_work_readback"):
                    w_reduced = float(self.integrator.get_protocol_work(dimensionless=True))
                u_cold = self._cold_energy(xk, box)
                probed = self._probe_cvs_deg()
                with self.timer("torsion_calculation"):
                    phi, psi = self._torsions(xk, probed)
                s_k = float(self.scales[k])
                with self.timer("hz_record_buffering"):
                    self.hz_rows.append(dict(
                        # ── stable downstream schema (report §13) ───────────
                        trajectory_id=i_traj, observation_id=n_obs,
                        s=s_k, sqrt_s=float(np.sqrt(s_k)), **{"lambda": float(k / cfg.m_ais)},
                        cumulative_reduced_work=w_reduced,
                        u_current_reduced=u_cur / self.kT, u_cold_reduced=u_cold / self.kT,
                        phi=phi, psi=psi, **self._cvs(xk, probed),
                        final_coordinate_reference=self._final_coord_ref(i_traj),
                        # ── provenance / legacy aliases ─────────────────────
                        worker=self.worker_id, trajectory_index=i_traj, observation_index=n_obs,
                        ais_interval_index=k, lam=float(k / cfg.m_ais),
                        cumulative_work_kj=w_reduced * self.kT,
                        u_cold_kj=u_cold, u_current_kj=u_cur,
                        leg=cfg.leg, proposal_id=cfg.proposal_id,
                        source_window_id=cfg.source_window_id))
                n_obs += 1
            if k in self.coord_idx and k != 0:
                self.sparse_coords.append(np.asarray(xk, np.float32))
                self.sparse_meta.append(dict(trajectory_index=i_traj, ais_interval_index=k))

        if prev < cfg.m_ais:                            # safety: finish the protocol
            with self.timer("on_device_switching_md"):
                self.integrator.step(cfg.m_ais - prev)

        with self.timer("final_state_retrieval"):
            w_reduced = float(self.integrator.get_protocol_work(dimensionless=True))
            xf = self.context.getState(getPositions=True).getPositions(asNumpy=True) \
                .value_in_unit(unit.nanometer)
        phi, psi = self._torsions(xf)
        if cfg.save_final_coordinates:
            self.sparse_coords.append(np.asarray(xf, np.float32))
            self.sparse_meta.append(dict(trajectory_index=i_traj, ais_interval_index=cfg.m_ais))
        rec = self._summary_row(i_traj, vseed, w_reduced, phi, psi, n_obs,
                                start_phi=phi0, start_psi=psi0)
        self.summary_rows.append(rec)
        self._completed.add(i_traj)
        return rec

    # ── buffered output (report §5) ─────────────────────────────────────────
    def flush(self, out_dir: Optional[Path] = None) -> dict:
        """Write the buffers in one block. One directory per worker; no shared files."""
        import pandas as pd
        out = Path(out_dir or self.cfg.out_dir or ".") / f"worker_{self.worker_id:02d}"
        out.mkdir(parents=True, exist_ok=True)
        written = {}
        with self.timer("output_flush"):
            if self.summary_rows:
                p = out / "trajectory_summary.parquet"
                df = pd.DataFrame(self.summary_rows)
                if p.exists():
                    df = pd.concat([pd.read_parquet(p), df], ignore_index=True)
                df.to_parquet(p, index=False)
                written["trajectory_summary"] = len(df)
            if self.hz_rows:
                p = out / "hz_observations.parquet"
                df = pd.DataFrame(self.hz_rows)
                if p.exists():
                    df = pd.concat([pd.read_parquet(p), df], ignore_index=True)
                df.to_parquet(p, index=False)
                written["hz_observations"] = len(df)
            if self.sparse_coords:
                p = out / "sparse_coordinates.npz"
                arr = np.stack(self.sparse_coords).astype(np.float32)
                meta = pd.DataFrame(self.sparse_meta)
                if p.exists():
                    old = np.load(p)
                    arr = np.concatenate([old["xyz"], arr])
                    meta = pd.concat([pd.DataFrame(dict(
                        trajectory_index=old["trajectory_index"],
                        ais_interval_index=old["ais_interval_index"])), meta], ignore_index=True)
                np.savez_compressed(
                    p, xyz=arr,
                    trajectory_index=meta["trajectory_index"].to_numpy(int),
                    ais_interval_index=meta["ais_interval_index"].to_numpy(int))
                written["sparse_coordinates"] = int(arr.shape[0])
        self.hz_rows.clear()
        self.summary_rows.clear()
        self.sparse_coords.clear()
        self.sparse_meta.clear()
        return written

    def maybe_flush(self, out_dir: Optional[Path] = None) -> Optional[dict]:
        if len(self.summary_rows) >= self.cfg.flush_every:
            return self.flush(out_dir)
        return None

    # ── resume (report §7) ──────────────────────────────────────────────────
    def already_done(self, out_dir: Optional[Path] = None) -> set[int]:
        """Global trajectory ids this worker has ALREADY written and flushed.

        Read from the worker's own parquet, so a resumed run skips exactly the trajectories that
        are durably on disk -- buffered-but-unflushed work is redone, which is correct: it was
        never persisted.  Trajectory ids are global, so the skip set is meaningful regardless of
        how the launcher partitioned the work.
        """
        import pandas as pd
        out = Path(out_dir or self.cfg.out_dir or ".") / f"worker_{self.worker_id:02d}"
        p = out / "trajectory_summary.parquet"
        if not p.exists():
            return set()
        try:
            df = pd.read_parquet(p, columns=["trajectory_index"])
        except Exception:
            return set()
        return {int(i) for i in df["trajectory_index"].to_numpy()}

    def profile(self) -> dict:
        d = self.timer.as_dict()
        d["_config"] = {k: (str(v) if isinstance(v, Path) else v)
                        for k, v in asdict(self.cfg).items()}
        d["_schedule"] = dict(m_ais=self.cfg.m_ais,
                              n_hz_observations=int(len(self.hz_idx)) if self.cfg.collects_hz else 0,
                              hz_indices=([int(i) for i in self.hz_idx]
                                          if self.cfg.collects_hz else []),
                              n_coordinate_frames=int(len(self.coord_idx)),
                              switch_duration_ps=self.cfg.switch_duration_ps)
        d["_banner"] = self.banner
        return d

    def close(self):
        for a in ("context", "cold_context", "integrator", "cold_integrator"):
            if getattr(self, a, None) is not None:
                setattr(self, a, None)


# ─────────────────────────────────────────────────────────────────────────────
# deterministic merge (report §5)
# ─────────────────────────────────────────────────────────────────────────────
def merge_workers(run_dir: Path, out_subdir: str = "merged") -> dict:
    """Concatenate every ``worker_XX`` directory in a fixed (sorted) order.

    Deterministic: workers are merged by ascending worker id and rows sorted by
    (worker, trajectory_index, observation_index), so the merged output does not depend on
    completion order.
    """
    import pandas as pd
    run_dir = Path(run_dir)
    out = run_dir / out_subdir
    out.mkdir(parents=True, exist_ok=True)
    workers = sorted(p for p in run_dir.glob("worker_*") if p.is_dir())
    res = {}

    for name, keys in (("trajectory_summary", ["worker", "trajectory_index"]),
                       ("hz_observations", ["worker", "trajectory_index", "observation_index"])):
        parts = [pd.read_parquet(w / f"{name}.parquet") for w in workers
                 if (w / f"{name}.parquet").exists()]
        if parts:
            df = pd.concat(parts, ignore_index=True).sort_values(keys).reset_index(drop=True)
            df.to_parquet(out / f"{name}.parquet", index=False)
            res[name] = len(df)

    xyz, tr, iv, wk = [], [], [], []
    for w in workers:
        p = w / "sparse_coordinates.npz"
        if p.exists():
            z = np.load(p)
            xyz.append(z["xyz"])
            tr.append(z["trajectory_index"])
            iv.append(z["ais_interval_index"])
            wk.append(np.full(len(z["trajectory_index"]), int(w.name.split("_")[1])))
    if xyz:
        np.savez_compressed(out / "sparse_coordinates.npz",
                            xyz=np.concatenate(xyz), trajectory_index=np.concatenate(tr),
                            ais_interval_index=np.concatenate(iv), worker=np.concatenate(wk))
        res["sparse_coordinates"] = int(sum(x.shape[0] for x in xyz))
    res["n_workers"] = len(workers)
    return res
