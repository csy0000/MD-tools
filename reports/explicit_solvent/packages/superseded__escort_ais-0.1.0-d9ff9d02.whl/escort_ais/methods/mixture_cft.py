"""mixture_cft.py — the 1-hot + M-cold-proposal ("1H + M C_m") mixture-CFT estimator.

Theory: ``docs/theory/alanine_cold_mixture_cft_theory.pdf``.
Protocol/provenance: ``docs/protocols/alanine_mixture_cft_validation.md``.

WHAT THIS IS
------------
Reverse (cold -> hot) AIS trajectories are started from *restrained* cold proposal
ensembles ``pi_m ∝ exp(-u_C - U_m)`` but their recorded work contains ONLY the physical
cold->hot schedule.  The restraint therefore biases the *starting density*, not the work,
and is removed by importance weighting against the stratified proposal mixture
``q = Σ_m α_m π_m`` (α_m = N_m/N_R).  The physical-to-proposal ratio

    ρ(x) ∝ 1 / Σ_m N_m exp(f_m - U_m(x)),        f_m = -log Z_m                 (reduced)

involves the unknown cold potential ``u_C`` NOWHERE — only the analytic restraint values
``U_n(x_i)`` for EVERY proposal n (the "proposal bias matrix"), which is why that full
matrix, not just the source column, must be supplied.

The estimator has two levels:

* **Level A** — the weighted Crooks/Bennett *estimating equation* (NOT a likelihood):

      G(Δ) = (1/N_F) Σ_i σ(Δ - M* - W^F_i) - e^{-M*} Σ_j ω_j σ(M* - Δ - W^R_j) = 0

  which is consistent for ANY fixed Bennett constant M* (M* only affects variance); the
  ``e^{-M*}`` factor is what makes that true when M* != log(N_F/N_R), i.e. when the reverse
  count has been degraded to an effective one.  With M = 1 and uniform ω it reduces exactly
  to ``reverse_ais_bar.bar_free_energy``.

* **Level B** — the coupled composite objective ``ℓ_eq(f) + γ[weighted Shirts terms]``.
  ``ℓ_eq`` is the exact UWHAM/MBAR profile empirical likelihood for the offsets; the second
  bracket is a *pseudo*-likelihood.  Labelled as such throughout: the plain inverse Hessian
  is NOT a valid standard error, and the primary uncertainty is the (two-level) bootstrap.

GAUGE
-----
``ω_i`` is invariant under ``f_m -> f_m + c``: normalized reverse weights determine only the
M-1 differences.  Absolute offsets, and in particular ``f_m - f_C``, come from the
*equilibrium* MBAR block (option ``offsets="mbar"``), never from the reverse weights alone.

This module does not modify, wrap or replace ``endpoint_bar``, ``bais``, ``bais_us``,
``baus_estimator``, ``asymptotic_bar`` or ``reverse_ais_bar.cft_free_energy``.

All works, offsets and restraint energies are REDUCED (k_B T).  Forward = hot->cold,
reverse = cold->hot, ``w = exp(-W)``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Literal, Optional, Sequence

import numpy as np
from scipy.optimize import brentq, minimize
from scipy.special import expit, logsumexp

__all__ = [
    "MixtureCFTResult",
    "mixture_log_denominator",
    "mixture_log_weights",
    "normalized_mixture_weights",
    "solve_offsets_mbar",
    "uwham_objective",
    "levelA_residual",
    "solve_delta_levelA",
    "solve_joint_levelB",
    "fit_mixture_cft",
    "crooks_residuals",
    "reweighted_pmf_2d",
    "zwanzig_offsets",
]


# ─────────────────────────────────────────────────────────────────────────────
# small helpers
# ─────────────────────────────────────────────────────────────────────────────
def _log_sigmoid(z: np.ndarray) -> np.ndarray:
    """log σ(z) = -log(1+e^{-z}), stable for both signs."""
    return -np.logaddexp(0.0, -np.asarray(z, float))


def _as_counts(proposal_sample_counts, m_index: np.ndarray, n_proposals: int) -> np.ndarray:
    if proposal_sample_counts is None:
        return np.bincount(m_index, minlength=n_proposals).astype(float)
    n = np.asarray(proposal_sample_counts, float)
    if n.shape != (n_proposals,):
        raise ValueError(f"proposal_sample_counts must have shape ({n_proposals},), got {n.shape}")
    return n


def _centre(f: np.ndarray, gauge: str) -> np.ndarray:
    f = np.asarray(f, float)
    if gauge == "sum_zero":
        return f - f.mean()
    if gauge == "first_zero":
        return f - f[0]
    raise ValueError(f"unknown gauge {gauge!r} (expected 'sum_zero' or 'first_zero')")


# ─────────────────────────────────────────────────────────────────────────────
# mixture weights
# ─────────────────────────────────────────────────────────────────────────────
def mixture_log_denominator(bias_matrix: np.ndarray, counts: np.ndarray, f: np.ndarray) -> np.ndarray:
    """log Σ_m N_m exp(f_m - U_m(x_i))  — the MBAR / balance-heuristic denominator.

    bias_matrix : (N_R, M) reduced restraint energies U_n(x_i) for EVERY proposal n.
    counts      : (M,)     N_m, the number of reverse trajectories started from proposal m.
    f           : (M,)     reduced proposal offsets f_m = -log Z_m (any gauge).
    """
    B = np.asarray(bias_matrix, float)
    n = np.asarray(counts, float)
    f = np.asarray(f, float)
    if B.ndim != 2:
        raise ValueError("bias_matrix must be 2-D (N_R, M)")
    if n.shape[0] != B.shape[1] or f.shape[0] != B.shape[1]:
        raise ValueError("counts/f length must equal bias_matrix.shape[1]")
    with np.errstate(divide="ignore"):
        log_n = np.where(n > 0, np.log(np.where(n > 0, n, 1.0)), -np.inf)
    return logsumexp(log_n[None, :] + f[None, :] - B, axis=1)


def mixture_log_weights(bias_matrix: np.ndarray, counts: np.ndarray, f: np.ndarray) -> np.ndarray:
    """Unnormalized log ρ(x_i) = -log Σ_m N_m exp(f_m - U_m(x_i)) (gauge-dependent by a constant)."""
    return -mixture_log_denominator(bias_matrix, counts, f)


def normalized_mixture_weights(bias_matrix: np.ndarray, counts: np.ndarray, f: np.ndarray) -> np.ndarray:
    """ω_i = ρ_i / Σ_j ρ_j — invariant under f -> f + c (Prop. 1 of the theory note)."""
    lw = mixture_log_weights(bias_matrix, counts, f)
    return np.exp(lw - logsumexp(lw))


def effective_sample_size(weights: np.ndarray) -> float:
    w = np.asarray(weights, float)
    s = w.sum()
    if s <= 0:
        return 0.0
    w = w / s
    return float(1.0 / np.sum(w * w))


# ─────────────────────────────────────────────────────────────────────────────
# equilibrium block: UWHAM / MBAR over the pooled proposal samples
# ─────────────────────────────────────────────────────────────────────────────
def uwham_objective(f: np.ndarray, bias_matrix: np.ndarray, counts: np.ndarray) -> tuple[float, np.ndarray]:
    """UWHAM/MBAR profile log-likelihood ℓ_eq(f) = Σ_n N_n f_n - Σ_i log Σ_m N_m e^{f_m-U_m(x_i)}
    and its analytic gradient ∂ℓ/∂f_n = N_n - Σ_i s_in.  Concave on the gauge-fixed subspace.

    (The common e^{-u_C(x_i)} factor is f-independent and has been dropped — it only shifts
    ℓ_eq by a constant.)
    """
    B = np.asarray(bias_matrix, float)
    n = np.asarray(counts, float)
    f = np.asarray(f, float)
    logD = mixture_log_denominator(B, n, f)
    val = float(np.dot(n, f) - logD.sum())
    with np.errstate(divide="ignore"):
        log_n = np.where(n > 0, np.log(np.where(n > 0, n, 1.0)), -np.inf)
    S = np.exp(log_n[None, :] + f[None, :] - B - logD[:, None])   # (N_R, M) responsibilities
    grad = n - S.sum(axis=0)
    return val, grad


def _uwham_hessian(f: np.ndarray, bias_matrix: np.ndarray, counts: np.ndarray) -> np.ndarray:
    """Hessian of -ℓ_eq (positive semi-definite; rank M-1 because of the gauge)."""
    B = np.asarray(bias_matrix, float)
    n = np.asarray(counts, float)
    logD = mixture_log_denominator(B, n, f)
    with np.errstate(divide="ignore"):
        log_n = np.where(n > 0, np.log(np.where(n > 0, n, 1.0)), -np.inf)
    S = np.exp(log_n[None, :] + f[None, :] - B - logD[:, None])   # (N_R, M)
    H = -S.T @ S
    H[np.diag_indices_from(H)] += S.sum(axis=0)
    return H                                                       # = Σ_i (diag(s_i) - s_i s_i^T)


def solve_offsets_mbar(
    bias_matrix: np.ndarray,
    counts: np.ndarray,
    f_init: Optional[np.ndarray] = None,
    gauge: str = "sum_zero",
    tol: float = 1e-10,
    max_self_consistent: int = 500,
    newton: bool = True,
) -> dict:
    """Solve the MBAR self-consistency f_n = -log Σ_i e^{-U_n(x_i)}/Σ_m N_m e^{f_m-U_m(x_i)}.

    Returns dict(f, f_C, converged, n_iter, grad_norm, hessian, eigvals, log_likelihood).
    ``f_C`` is the unbiased cold state (U ≡ 0) placed on the SAME gauge as ``f``; it is a
    zero-sample state, so it never enters the denominator.
    """
    B = np.asarray(bias_matrix, float)
    n = np.asarray(counts, float)
    M = B.shape[1]
    f = _centre(np.zeros(M) if f_init is None else np.asarray(f_init, float), gauge)

    converged = False
    it = 0
    for it in range(1, max_self_consistent + 1):
        logD = mixture_log_denominator(B, n, f)
        f_new = -logsumexp(-B - logD[:, None], axis=0)
        f_new = _centre(f_new, gauge)
        delta = float(np.max(np.abs(f_new - f)))
        f = f_new
        if delta < tol:
            converged = True
            break

    if newton:                                # polish on the concave objective (gauge-projected)
        def _neg(x):
            v, g = uwham_objective(_centre(x, gauge), B, n)
            return -v, -g
        res = minimize(_neg, f, jac=True, method="L-BFGS-B",
                       options=dict(maxiter=500, ftol=1e-16, gtol=1e-12))
        f = _centre(res.x, gauge)
        converged = converged or bool(res.success)

    logD = mixture_log_denominator(B, n, f)
    f_C = float(-logsumexp(-logD))            # U_C ≡ 0, zero-sample state, same gauge
    val, grad = uwham_objective(f, B, n)
    grad = grad - grad.mean()                 # project out the gauge direction
    H = _uwham_hessian(f, B, n)
    # gauge-fixed spectrum: project onto 1^perp
    P = np.eye(M) - np.ones((M, M)) / M
    eig = np.linalg.eigvalsh(P @ H @ P)
    return dict(f=f, f_C=f_C, converged=bool(converged), n_iter=it,
                grad_norm=float(np.max(np.abs(grad))), hessian=H,
                eigvals=eig, log_likelihood=val)


def zwanzig_offsets(bias_matrix_cold: np.ndarray, weights: Optional[np.ndarray] = None,
                    gauge: str = "sum_zero") -> dict:
    """ORACLE offsets from exact cold samples: f_m - f_C = -log <e^{-U_m}>_C.

    bias_matrix_cold : (N_C, M) restraint energies U_m evaluated on EXACT cold samples.
    weights          : optional (N_C,) nonnegative sample weights (e.g. for a reweighted
                       cold ensemble); defaults to uniform.
    Returns dict(f_minus_fC, f (gauge-centred), z (= Z_m/Z_C)).
    """
    B = np.asarray(bias_matrix_cold, float)
    if weights is None:
        lw = np.full(B.shape[0], -np.log(B.shape[0]))
    else:
        w = np.asarray(weights, float)
        if np.any(w < 0):
            raise ValueError("weights must be nonnegative")
        lw = np.log(np.where(w > 0, w, np.finfo(float).tiny))
        lw = lw - logsumexp(lw)
    log_z = logsumexp(lw[:, None] - B, axis=0)          # log <e^{-U_m}>_C
    f_minus_fC = -log_z
    return dict(f_minus_fC=f_minus_fC, f=_centre(f_minus_fC, gauge), z=np.exp(log_z))


# ─────────────────────────────────────────────────────────────────────────────
# Level A: weighted Crooks/Bennett estimating equation
# ─────────────────────────────────────────────────────────────────────────────
def levelA_residual(delta: float, forward_work: np.ndarray, reverse_work: np.ndarray,
                    omega: np.ndarray, m_star: float) -> float:
    """G(Δ) = mean_F σ(Δ - M* - W^F) - e^{-M*} Σ_j ω_j σ(M* - Δ - W^R).  Strictly increasing in Δ."""
    wf = np.asarray(forward_work, float)
    wr = np.asarray(reverse_work, float)
    om = np.asarray(omega, float)
    lhs = float(np.mean(expit(delta - m_star - wf)))
    rhs = float(np.exp(-m_star) * np.sum(om * expit(m_star - delta - wr)))
    return lhs - rhs


def _bennett_constant(m_star, n_forward: int, omega: np.ndarray) -> float:
    """M* selection.  'ess' (default) uses the DEGRADED reverse count — variance-optimal to
    leading order once the reverse ensemble has been importance-weighted.  Consistency does
    not depend on this choice (Prop. 2 of the theory note)."""
    if isinstance(m_star, (int, float, np.floating)) and not isinstance(m_star, bool):
        return float(m_star)
    if m_star == "nominal":
        return float(np.log(n_forward / max(len(omega), 1)))
    if m_star == "ess":
        ess = max(effective_sample_size(omega), 1e-12)
        return float(np.log(n_forward / ess))
    raise ValueError(f"unknown m_star {m_star!r} (expected float, 'ess' or 'nominal')")


def solve_delta_levelA(forward_work: np.ndarray, reverse_work: np.ndarray, omega: np.ndarray,
                       m_star, delta_init: float = 0.0,
                       tol: float = 1e-10) -> dict:
    """Solve G(Δ)=0 by bracketed Brent on the monotone residual.  Returns dict(delta_f, ...)."""
    wf = np.asarray(forward_work, float)
    wr = np.asarray(reverse_work, float)
    om = np.asarray(omega, float)
    om = om / om.sum()
    ms = _bennett_constant(m_star, len(wf), om)

    def g(d):
        return levelA_residual(d, wf, wr, om, ms)

    lo = hi = float(delta_init)
    scale = 1.0 + float(np.std(wf) + np.std(wr))
    for _ in range(80):
        if g(lo) < 0.0 < g(hi) or g(lo) > 0.0 > g(hi):
            break
        lo -= scale
        hi += scale
        scale *= 1.6
    else:
        return dict(delta_f=float("nan"), converged=False, m_star=ms, residual=float("nan"))
    try:
        root = brentq(g, lo, hi, xtol=tol, maxiter=500)
    except ValueError:
        return dict(delta_f=float("nan"), converged=False, m_star=ms, residual=float("nan"))
    return dict(delta_f=float(root), converged=True, m_star=ms, residual=float(g(root)))


def _delta_se_delta_method(delta: float, forward_work, reverse_work, omega, m_star) -> float:
    """Delta-method / sandwich SE for Δ at FIXED offsets.  Conditional on f: it ignores the
    offset uncertainty and the parent-frame correlation, so it is reported only as a cheap
    cross-check next to the bootstrap SE (see the theory note, §5.4)."""
    wf = np.asarray(forward_work, float)
    wr = np.asarray(reverse_work, float)
    om = np.asarray(omega, float)
    om = om / om.sum()
    a = expit(delta - m_star - wf)
    c = np.exp(-m_star) * expit(m_star - delta - wr)
    var_f = float(np.var(a, ddof=1) / len(a)) if len(a) > 1 else np.inf
    t = float(np.sum(om * c))
    var_r = float(np.sum(om ** 2 * (c - t) ** 2))            # self-normalized IS variance
    dg = float(np.mean(a * (1 - a)) + np.exp(-m_star) * np.sum(om * expit(m_star - delta - wr)
                                                              * (1 - expit(m_star - delta - wr))))
    if dg <= 0:
        return float("nan")
    return float(np.sqrt(max(var_f + var_r, 0.0)) / dg)


# ─────────────────────────────────────────────────────────────────────────────
# Level B: coupled composite objective
# ─────────────────────────────────────────────────────────────────────────────
def _levelB_value_grad(theta: np.ndarray, B: np.ndarray, counts: np.ndarray,
                       wf: np.ndarray, wr: np.ndarray, gamma: float, m_star: float):
    """L(ζ, Δ) and its analytic gradient.  ζ ∈ R^{M-1} is the gauge-free parameterization
    f = (ζ, 0) re-centred (gauge G2 of the theory note); θ = (ζ, Δ)."""
    M = B.shape[1]
    zeta, delta = theta[: M - 1], theta[M - 1]
    f_raw = np.concatenate([zeta, [0.0]])
    f = f_raw - f_raw.mean()

    logD = mixture_log_denominator(B, counts, f)
    with np.errstate(divide="ignore"):
        log_n = np.where(counts > 0, np.log(np.where(counts > 0, counts, 1.0)), -np.inf)
    S = np.exp(log_n[None, :] + f[None, :] - B - logD[:, None])          # (N_R, M)

    ell_eq = float(np.dot(counts, f) - logD.sum())
    g_eq = counts - S.sum(axis=0)                                        # ∂ℓ_eq/∂f

    lw = -logD
    lw = lw - logsumexp(lw)
    om = np.exp(lw)                                                      # ω_j
    e_ms = float(np.exp(-m_star))
    ls_r = _log_sigmoid(wr + delta - m_star)                             # log σ(W^R+Δ-M*)
    ls_f = _log_sigmoid(wf - delta + m_star)
    ne_term = float(np.mean(ls_f) + e_ms * np.sum(om * ls_r))
    value = ell_eq + gamma * ne_term

    # ∂/∂Δ
    dL_ddelta = gamma * (-np.mean(expit(delta - m_star - wf))
                         + e_ms * np.sum(om * expit(m_star - delta - wr)))
    # ∂ω_j/∂f_n = ω_j (s̄_n - s_jn)
    s_bar = om @ S                                                       # (M,)
    dom_df = om[:, None] * (s_bar[None, :] - S)                          # (N_R, M)
    g_ne = gamma * e_ms * (ls_r @ dom_df)                                # (M,)
    g_f = g_eq + g_ne

    # chain rule through f = (ζ,0) - mean
    #   ∂f_k/∂ζ_a = δ_{ka} - 1/M
    g_zeta = g_f[: M - 1] - g_f.sum() / M
    return value, np.concatenate([g_zeta, [dL_ddelta]])


def solve_joint_levelB(bias_matrix: np.ndarray, counts: np.ndarray,
                       forward_work: np.ndarray, reverse_work: np.ndarray,
                       f_init: np.ndarray, delta_init: float,
                       m_star, gamma: Optional[float] = None,
                       gauge: str = "sum_zero", method: str = "L-BFGS-B") -> dict:
    """Maximize the Level-B composite objective jointly in (f, Δ).  Second optimizer /
    initialization-sensitivity check for the decoupled solve."""
    B = np.asarray(bias_matrix, float)
    n = np.asarray(counts, float)
    wf = np.asarray(forward_work, float)
    wr = np.asarray(reverse_work, float)
    M = B.shape[1]
    gamma = float(len(wf)) if gamma is None else float(gamma)

    om0 = normalized_mixture_weights(B, n, f_init)
    ms = _bennett_constant(m_star, len(wf), om0)

    f0 = _centre(np.asarray(f_init, float), "sum_zero")
    theta0 = np.concatenate([f0[: M - 1] - f0[M - 1], [float(delta_init)]])

    def _neg(t):
        v, g = _levelB_value_grad(t, B, n, wf, wr, gamma, ms)
        return -v, -g

    res = minimize(_neg, theta0, jac=True, method=method,
                   options=dict(maxiter=2000, ftol=1e-15, gtol=1e-10)
                   if method == "L-BFGS-B" else dict(maxiter=5000))
    zeta, delta = res.x[: M - 1], float(res.x[M - 1])
    f_raw = np.concatenate([zeta, [0.0]])
    f = _centre(f_raw, gauge)
    _, grad = _levelB_value_grad(res.x, B, n, wf, wr, gamma, ms)
    return dict(f=f, delta_f=delta, converged=bool(res.success),
                gradient_norm=float(np.max(np.abs(grad))), m_star=ms,
                objective=float(-res.fun), n_iter=int(res.nit), message=str(res.message))


# ─────────────────────────────────────────────────────────────────────────────
# diagnostics
# ─────────────────────────────────────────────────────────────────────────────
def crooks_residuals(forward_work: np.ndarray, reverse_work: np.ndarray, omega: np.ndarray,
                     delta_f: float, n_bins: int = 24, min_count: float = 5.0) -> dict:
    """r_b = log P_F(W_b) - log P_R^C(-W_b) - (W_b - Δf) on a common work grid.

    A systematic slope indicates residual reconstruction bias (usually missing support);
    a constant offset indicates a Δf error.  Bins with too little mass on either side are
    dropped (returned in ``dropped``).
    """
    wf = np.asarray(forward_work, float)
    wr = np.asarray(reverse_work, float)
    om = np.asarray(omega, float)
    om = om / om.sum()
    lo = min(wf.min(), -wr.max())
    hi = max(wf.max(), -wr.min())
    if not np.isfinite(lo) or not np.isfinite(hi) or lo >= hi:
        return dict(centers=np.array([]), residual=np.array([]), dropped=n_bins, slope=float("nan"))
    edges = np.linspace(lo, hi, n_bins + 1)
    centers = 0.5 * (edges[:-1] + edges[1:])
    width = edges[1] - edges[0]

    hf, _ = np.histogram(wf, bins=edges)
    pf = hf / (len(wf) * width)
    hr, _ = np.histogram(-wr, bins=edges, weights=om)          # reflected reverse, weighted
    pr = hr / width
    # effective counts for the weighted side
    hr_eff, _ = np.histogram(-wr, bins=edges, weights=om ** 2)
    n_eff_bin = np.where(hr_eff > 0, hr ** 2 / np.where(hr_eff > 0, hr_eff, 1.0), 0.0)

    ok = (hf >= min_count) & (n_eff_bin >= min_count) & (pf > 0) & (pr > 0)
    r = np.full(n_bins, np.nan)
    r[ok] = np.log(pf[ok]) - np.log(pr[ok]) - (centers[ok] - delta_f)
    slope = float("nan")
    if ok.sum() >= 3:
        slope = float(np.polyfit(centers[ok], r[ok], 1)[0])
    return dict(centers=centers, residual=r, ok=ok, dropped=int((~ok).sum()), slope=slope,
                edges=edges, p_forward=pf, p_reverse_reconstructed=pr)


def support_diagnostic(bias_matrix: np.ndarray, counts: np.ndarray, f: np.ndarray,
                       probe_bias: Optional[np.ndarray], probe_weights: Optional[np.ndarray],
                       quantile: float = 0.999, min_bias_kT: float = 10.0) -> dict:
    """Detect cold mass that no proposal covers (extrapolation detector).

    ``probe_bias`` (n_probe, M) holds U_n evaluated at independently-known *important* cold
    configurations (in practice the forward AIS landings), with ``probe_weights`` their
    Jarzynski weights.

    The importance ratio is ρ ∝ 1/Σ_m N_m e^{f_m-U_m}: a configuration that NO proposal covers
    has a tiny mixture density and hence a HUGE log ρ.  A probe is therefore "uncovered" when
    its log ρ exceeds the ``quantile`` quantile of the log ρ actually realized by the reverse
    pool — i.e. it sits outside the support the proposals demonstrably reached, so any weight
    assigned to it would be extrapolation.

    Also reported: ``min_bias_mass``, the probe mass with min_m U_m(x) > ``min_bias_kT``, which
    is the direct form of the Phase-4 design requirement "∀x with important π_C(x), min_m U_m(x)
    is small".
    """
    if probe_bias is None or probe_weights is None:
        return dict(available=False, uncovered_mass=float("nan"), threshold=float("nan"),
                    min_bias_mass=float("nan"))
    B = np.asarray(bias_matrix, float)
    Bp = np.asarray(probe_bias, float)
    n = np.asarray(counts, float)
    log_rho_pool = -mixture_log_denominator(B, n, f)
    log_rho_probe = -mixture_log_denominator(Bp, n, f)
    thr = float(np.quantile(log_rho_pool, quantile))
    w = np.asarray(probe_weights, float)
    w = w / w.sum()
    unc = float(w[log_rho_probe > thr].sum())
    min_bias = Bp.min(axis=1)
    return dict(available=True, uncovered_mass=unc, threshold=thr,
                log_rho_probe=log_rho_probe, log_rho_pool_quantile=quantile,
                min_bias_mass=float(w[min_bias > min_bias_kT].sum()),
                min_bias_kT=min_bias_kT)


def proposal_separability(reverse_work: np.ndarray, source_index: np.ndarray,
                          n_proposals: int) -> dict:
    """Pairwise two-sample KS statistics of the proposal-conditioned reverse works.
    Small values warn that two proposals' reverse data cannot distinguish their weights
    (they remain determined by the equilibrium block)."""
    from scipy.stats import ks_2samp
    wr = np.asarray(reverse_work, float)
    src = np.asarray(source_index, int)
    ks = np.full((n_proposals, n_proposals), np.nan)
    for a in range(n_proposals):
        xa = wr[src == a]
        for b in range(a + 1, n_proposals):
            xb = wr[src == b]
            if len(xa) >= 5 and len(xb) >= 5:
                ks[a, b] = ks[b, a] = float(ks_2samp(xa, xb).statistic)
    with np.errstate(invalid="ignore"):
        worst = float(np.nanmin(ks)) if np.isfinite(ks).any() else float("nan")
    return dict(ks=ks, min_ks=worst)


# ─────────────────────────────────────────────────────────────────────────────
# PMF reconstruction (Phase 7)
# ─────────────────────────────────────────────────────────────────────────────
def reweighted_pmf_2d(phi: np.ndarray, psi: np.ndarray, weights: np.ndarray,
                      n_bins: int = 72) -> dict:
    """Periodic (φ,ψ) histogram on [-π,π)² from mixture weights.  Returns P, F=-logP, edges.

    Genuinely periodic: the grid spans exactly one full period in each angle and the two
    edges are identified, so there is no Euclidean artefact at ±π.  Angles are wrapped into
    [-π,π) before binning.
    """
    def _wrap(a):
        return (np.asarray(a, float) + np.pi) % (2 * np.pi) - np.pi

    edges = np.linspace(-np.pi, np.pi, n_bins + 1)
    w = np.asarray(weights, float)
    H, _, _ = np.histogram2d(_wrap(phi), _wrap(psi), bins=[edges, edges], weights=w)
    tot = H.sum()
    P = H / tot if tot > 0 else H
    with np.errstate(divide="ignore"):
        F = -np.log(P)
    return dict(P=P, F=F, phi_edges=edges, psi_edges=edges, total_weight=float(tot))


# ─────────────────────────────────────────────────────────────────────────────
# result container
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class MixtureCFTResult:
    delta_f: float
    delta_f_se: float
    proposal_offsets: np.ndarray
    proposal_offset_covariance: np.ndarray
    normalized_reverse_weights: np.ndarray
    reverse_ess: float
    max_weight_fraction: float
    objective: float
    gradient_norm: float
    converged: bool
    crooks_residuals: dict
    bootstrap_results: dict
    # extras
    proposal_offsets_minus_fC: np.ndarray = field(default_factory=lambda: np.array([]))
    delta_f_se_sandwich: float = float("nan")
    delta_f_joint: float = float("nan")
    proposal_offsets_joint: np.ndarray = field(default_factory=lambda: np.array([]))
    m_star: float = float("nan")
    delta_f_init_je: float = float("nan")
    diagnostics: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)

    def summary(self) -> str:
        w = ("; ".join(self.warnings)) if self.warnings else "none"
        return (f"Δf_HC = {self.delta_f:+.4f} ± {self.delta_f_se:.4f} kT "
                f"(sandwich ±{self.delta_f_se_sandwich:.4f}); "
                f"ESS={self.reverse_ess:.1f} ({100*self.reverse_ess/max(len(self.normalized_reverse_weights),1):.1f}%), "
                f"max ω={self.max_weight_fraction:.3f}, converged={self.converged}; warnings: {w}")


# ─────────────────────────────────────────────────────────────────────────────
# the driver
# ─────────────────────────────────────────────────────────────────────────────
def fit_mixture_cft(
    forward_work: np.ndarray,
    reverse_work: np.ndarray,
    reverse_start_coordinates_or_cvs: Optional[np.ndarray] = None,
    source_proposal_index: Optional[np.ndarray] = None,
    proposal_bias_matrix: Optional[np.ndarray] = None,
    proposal_sample_counts: Optional[np.ndarray] = None,
    initial_delta_f: Optional[float] = None,
    initial_proposal_offsets: Optional[np.ndarray] = None,
    *,
    offsets: Literal["mbar", "fixed", "joint"] = "mbar",
    fixed_offsets: Optional[np.ndarray] = None,
    gauge: Literal["sum_zero", "first_zero"] = "sum_zero",
    m_star="ess",
    gamma: Optional[float] = None,
    n_bootstrap: int = 200,
    bootstrap_parent: Optional[np.ndarray] = None,
    crooks_bins: int = 24,
    probe_bias: Optional[np.ndarray] = None,
    probe_weights: Optional[np.ndarray] = None,
    ess_floor: float = 0.05,
    max_weight_ceiling: float = 0.10,
    uncovered_mass_ceiling: float = 0.01,
    identifiability_floor: float = 1e-6,
    run_joint: bool = True,
    rng: Optional[np.random.Generator] = None,
) -> MixtureCFTResult:
    """Fit the 1-hot + M-cold-proposal mixture-CFT estimator.

    Parameters
    ----------
    forward_work : (N_F,) REDUCED forward (hot->cold) works W^F.
    reverse_work : (N_R,) REDUCED reverse (cold->hot) works W^R.  These must NOT contain any
        restraint term: U_m biases the starting density, not the work.
    reverse_start_coordinates_or_cvs : (N_R, d) optional; carried through for the PMF stage
        and stored in ``diagnostics``.  Not used by the solver itself (the solver needs only
        the bias matrix).
    source_proposal_index : (N_R,) which proposal each reverse trajectory started from.
    proposal_bias_matrix : (N_R, M) U_n(x_i) for EVERY proposal n — required for the balance
        heuristic.  Passing only the source column is not supported and will silently give a
        different (higher-variance, single-source) estimator, so it is rejected by shape.
    proposal_sample_counts : (M,) N_m.  Defaults to bincount(source_proposal_index).
    initial_delta_f, initial_proposal_offsets : JE-based initialization (see ``je_initialization``).
    offsets : "mbar" (equilibrium block, the only option that identifies f_m - f_C),
        "fixed" (use ``fixed_offsets``, e.g. the exact Zwanzig oracle), or "joint" (Level B).
    m_star : Bennett constant; "ess" (default), "nominal", or a float.
    bootstrap_parent : (N_R,) parent identifier for the two-level bootstrap (e.g. the cold
        frame a reverse shot was launched from).  Resampling is done over parents WITHIN each
        source stratum, then over shots within parents.

    Returns
    -------
    MixtureCFTResult
    """
    rng = np.random.default_rng() if rng is None else rng
    wf = np.asarray(forward_work, float).ravel()
    wr = np.asarray(reverse_work, float).ravel()
    if wf.size == 0 or wr.size == 0:
        raise ValueError("forward_work and reverse_work must be non-empty")
    if proposal_bias_matrix is None:
        raise ValueError("proposal_bias_matrix (N_R, M) is required — the balance-heuristic "
                         "denominator needs U_n(x_i) for every proposal n")
    B = np.asarray(proposal_bias_matrix, float)
    if B.ndim != 2 or B.shape[0] != wr.size:
        raise ValueError(f"proposal_bias_matrix must have shape ({wr.size}, M), got {B.shape}")
    M = B.shape[1]
    src = (np.zeros(wr.size, int) if source_proposal_index is None
           else np.asarray(source_proposal_index, int).ravel())
    counts = _as_counts(proposal_sample_counts, src, M)
    if counts.sum() <= 0:
        raise ValueError("proposal_sample_counts sum to zero")

    warnings_: list[str] = []

    # ── initialization ────────────────────────────────────────────────────
    delta_je = float(-logsumexp(-wf) + np.log(len(wf)))          # -log mean exp(-W^F)
    f0 = (_centre(np.asarray(initial_proposal_offsets, float), gauge)
          if initial_proposal_offsets is not None else np.zeros(M))
    d0 = float(initial_delta_f) if initial_delta_f is not None else delta_je

    # ── offsets ───────────────────────────────────────────────────────────
    mbar = solve_offsets_mbar(B, counts, f_init=f0, gauge=gauge)
    if offsets == "fixed":
        if fixed_offsets is None:
            raise ValueError('offsets="fixed" requires fixed_offsets')
        f_hat = _centre(np.asarray(fixed_offsets, float), gauge)
        f_minus_fC = np.asarray(fixed_offsets, float)            # caller's own reference
        eq_converged, eq_grad = True, 0.0
    else:
        f_hat = mbar["f"]
        f_minus_fC = mbar["f"] - mbar["f_C"]
        eq_converged, eq_grad = mbar["converged"], mbar["grad_norm"]
        if not eq_converged:
            warnings_.append("equilibrium (MBAR) block did not converge")

    omega = normalized_mixture_weights(B, counts, f_hat)
    ess = effective_sample_size(omega)
    max_w = float(omega.max())

    # ── Level A solve ─────────────────────────────────────────────────────
    lvlA = solve_delta_levelA(wf, wr, omega, m_star, delta_init=d0)
    delta_hat = lvlA["delta_f"]
    ms = lvlA["m_star"]
    if not lvlA["converged"]:
        warnings_.append("Level-A root find failed to bracket/converge")

    # ── Level B (second optimizer + init sensitivity) ─────────────────────
    joint = {}
    if run_joint and offsets != "fixed" and M > 1:
        joint = solve_joint_levelB(B, counts, wf, wr, f_hat, delta_hat, ms, gamma=gamma, gauge=gauge)
        if joint["converged"] and np.isfinite(joint["delta_f"]):
            if abs(joint["delta_f"] - delta_hat) > 1e-3 + 0.0:
                pass  # magnitude judged against the bootstrap width below
        else:
            warnings_.append("Level-B joint optimizer did not converge")
    if offsets == "joint" and joint:
        f_hat = joint["f"]
        delta_hat = joint["delta_f"]
        omega = normalized_mixture_weights(B, counts, f_hat)
        ess = effective_sample_size(omega)
        max_w = float(omega.max())

    # ── uncertainty: two-level bootstrap (primary) ────────────────────────
    boot = _bootstrap(wf, wr, B, counts, src, bootstrap_parent, n_bootstrap, m_star,
                      offsets, f_hat if offsets == "fixed" else None, gauge, delta_hat, rng)
    se = float(np.nanstd(boot["delta_f"], ddof=1)) if np.isfinite(boot["delta_f"]).sum() > 2 else float("nan")
    cov = (np.cov(boot["offsets"][np.isfinite(boot["offsets"]).all(axis=1)].T)
           if boot["offsets"].size and np.isfinite(boot["offsets"]).all(axis=1).sum() > 2
           else np.full((M, M), np.nan))
    se_sand = _delta_se_delta_method(delta_hat, wf, wr, omega, ms)

    # ── diagnostics ───────────────────────────────────────────────────────
    cr = crooks_residuals(wf, wr, omega, delta_hat, n_bins=crooks_bins)
    sup = support_diagnostic(B, counts, f_hat, probe_bias, probe_weights)
    sep = proposal_separability(wr, src, M) if M > 1 else dict(ks=np.zeros((1, 1)), min_ks=float("nan"))
    eig = mbar["eigvals"]
    lam_min = float(np.min(eig[1:])) if eig.size > 1 else float("nan")   # drop the gauge zero-mode

    if ess / len(omega) < ess_floor:
        warnings_.append(f"reverse ESS fraction {ess/len(omega):.3f} < {ess_floor}")
    if max_w > max_weight_ceiling:
        warnings_.append(f"max normalized weight {max_w:.3f} > {max_weight_ceiling}")
    if sup["available"] and sup["uncovered_mass"] > uncovered_mass_ceiling:
        warnings_.append(f"uncovered important cold mass {sup['uncovered_mass']:.3f} "
                         f"> {uncovered_mass_ceiling} — missing proposal support")
    if M > 1 and np.isfinite(lam_min) and lam_min < identifiability_floor * len(wr):
        warnings_.append(f"proposal offsets near-unidentifiable (λ_min={lam_min:.3e}); "
                         "duplicated/degenerate proposals are the benign cause")
    if joint and np.isfinite(joint.get("delta_f", np.nan)) and np.isfinite(se):
        if abs(joint["delta_f"] - lvlA["delta_f"]) > max(2 * se, 1e-6):
            warnings_.append(f"solver disagreement: Level-A {lvlA['delta_f']:.4f} vs "
                             f"Level-B {joint['delta_f']:.4f} (> 2 bootstrap SE)")

    diagnostics = dict(
        m_star=ms, ess_fraction=float(ess / len(omega)),
        uwham_log_likelihood=mbar["log_likelihood"], uwham_grad_norm=eq_grad,
        uwham_eigvals=eig, identifiability_lambda_min=lam_min,
        support=sup, separability=sep, counts=counts, source_index=src,
        n_forward=int(wf.size), n_reverse=int(wr.size), n_proposals=int(M),
        offsets_mode=offsets, gauge=gauge,
        reverse_cvs=(None if reverse_start_coordinates_or_cvs is None
                     else np.asarray(reverse_start_coordinates_or_cvs)),
        levelA=lvlA, levelB=joint,
        f_C_mbar=mbar["f_C"],
    )

    return MixtureCFTResult(
        delta_f=float(delta_hat),
        delta_f_se=se,
        proposal_offsets=f_hat,
        proposal_offset_covariance=cov,
        normalized_reverse_weights=omega,
        reverse_ess=float(ess),
        max_weight_fraction=max_w,
        objective=float(mbar["log_likelihood"]),
        gradient_norm=float(joint["gradient_norm"]) if joint else float(eq_grad),
        converged=bool(lvlA["converged"] and eq_converged),
        crooks_residuals=cr,
        bootstrap_results=boot,
        proposal_offsets_minus_fC=np.asarray(f_minus_fC, float),
        delta_f_se_sandwich=se_sand,
        delta_f_joint=float(joint.get("delta_f", np.nan)) if joint else float("nan"),
        proposal_offsets_joint=np.asarray(joint.get("f", []), float) if joint else np.array([]),
        m_star=float(ms),
        delta_f_init_je=delta_je,
        diagnostics=diagnostics,
        warnings=warnings_,
    )


def _bootstrap(wf, wr, B, counts, src, parent, n_boot, m_star, offsets, fixed_f, gauge,
               delta_init, rng) -> dict:
    """Two-level bootstrap: resample parents within each source stratum, then shots within
    parents; forward works resampled independently.  Falls back to a plain stratified
    bootstrap when no parent labels are given."""
    M = B.shape[1]
    if n_boot <= 0:
        return dict(delta_f=np.array([]), offsets=np.zeros((0, M)), n=0)
    strata = {m: np.where(src == m)[0] for m in range(M)}
    par = None if parent is None else np.asarray(parent)
    d_out = np.full(n_boot, np.nan)
    f_out = np.full((n_boot, M), np.nan)

    for b in range(n_boot):
        idx_parts = []
        for m, idx in strata.items():
            if idx.size == 0:
                continue
            if par is None:
                idx_parts.append(rng.choice(idx, size=idx.size, replace=True))
            else:
                pids = np.unique(par[idx])
                drawn = rng.choice(pids, size=pids.size, replace=True)
                by_p = {p: idx[par[idx] == p] for p in pids}
                sel = []
                for p in drawn:
                    pool = by_p[p]
                    sel.append(rng.choice(pool, size=pool.size, replace=True))
                if sel:
                    take = np.concatenate(sel)
                    # keep the stratum size fixed so the design (N_m) is preserved
                    if take.size >= idx.size:
                        take = take[: idx.size]
                    else:
                        take = np.concatenate([take, rng.choice(idx, size=idx.size - take.size,
                                                               replace=True)])
                    idx_parts.append(take)
        if not idx_parts:
            continue
        ridx = np.concatenate(idx_parts)
        fidx = rng.integers(0, len(wf), size=len(wf))
        Bb, wrb = B[ridx], wr[ridx]
        try:
            if offsets == "fixed":
                fb = fixed_f
            else:
                fb = solve_offsets_mbar(Bb, counts, f_init=None, gauge=gauge,
                                        max_self_consistent=200, newton=False)["f"]
            omb = normalized_mixture_weights(Bb, counts, fb)
            r = solve_delta_levelA(wf[fidx], wrb, omb, m_star, delta_init=delta_init)
            if r["converged"]:
                d_out[b] = r["delta_f"]
                f_out[b] = fb
        except (ValueError, FloatingPointError, np.linalg.LinAlgError):
            continue

    finite = np.isfinite(d_out)
    ci = (np.nanpercentile(d_out, [2.5, 97.5]) if finite.sum() > 2 else np.array([np.nan, np.nan]))
    return dict(delta_f=d_out, offsets=f_out, n=int(finite.sum()),
                ci95=ci, failure_rate=float(1.0 - finite.mean()))


# ─────────────────────────────────────────────────────────────────────────────
# JE initialization (theory note §6)
# ─────────────────────────────────────────────────────────────────────────────
def je_initialization(forward_work: np.ndarray, responsibilities: Optional[np.ndarray] = None,
                      alpha: Optional[np.ndarray] = None, gauge: str = "sum_zero") -> dict:
    """JE-weighted component masses p_m^(0) and Δf^(0)_JE.  Initializer + reference
    diagnostic ONLY — Δf_JE is a one-sided exponential average and is biased low."""
    wf = np.asarray(forward_work, float).ravel()
    lw = -wf - logsumexp(-wf)
    delta0 = float(-logsumexp(-wf) + np.log(len(wf)))
    out = dict(delta_f_je=delta0, weights=np.exp(lw))
    if responsibilities is not None:
        R = np.asarray(responsibilities, float)
        p0 = np.exp(logsumexp(lw[:, None], b=np.clip(R, 1e-300, None), axis=0))
        p0 = p0 / p0.sum()
        out["component_mass"] = p0
        if alpha is not None:
            a = np.asarray(alpha, float)
            f0 = np.log(np.clip(p0, 1e-300, None)) - np.log(np.clip(a, 1e-300, None))
            out["offsets"] = _centre(f0, gauge)
    return out
