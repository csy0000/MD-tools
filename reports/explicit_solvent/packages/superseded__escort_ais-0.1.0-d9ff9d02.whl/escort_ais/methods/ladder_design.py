"""ladder_design.py — AIS-derived REMD ladder optimization.

Derives an efficient REMD scale-factor ladder from the torsion information
embedded in an AIS switching run (s=0.4 → 1.0).  Three analyses:

1. Basin identification  (assign_basins / basin_populations)
   Assign each (φ,ψ) frame to a GMM component.

2. Basin connectivity vs s  (connectivity_count)
   Count connected density regions in the 2D Ramachandran histogram;
   drops from ≥2 to 1 when the basins merge.

3. Optimal ladder placement  (thermodynamic_length / equal_length_ladder)
   Place REMD rungs at equal cumulative thermodynamic length, concentrating
   replicas where the landscape changes fastest.

All functions are pure numpy/scipy and importable without OpenMM.

Public API
----------
assign_basins(phi_deg, psi_deg, gmm)          -> np.ndarray  shape (N,) int
basin_populations(phi_deg, psi_deg, gmm)      -> dict[int, float]
connectivity_count(phi_deg, psi_deg, ...)     -> int
thermodynamic_length(work_timeseries, ...)    -> (g_k, L_cumulative)
equal_length_ladder(s_nodes, L_cumulative, n_replicas) -> np.ndarray
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Basin identification (GMM-based)
# ---------------------------------------------------------------------------

def assign_basins(
    phi_deg: np.ndarray,
    psi_deg: np.ndarray,
    gmm,
) -> np.ndarray:
    """Assign each (phi, psi) frame to the most-probable GMM component.

    Features are built as  [cos(phi), cos(psi), sin(phi), sin(psi)]
    to match the ordering used by  gmm_escort.extract_torsion_features.

    Parameters
    ----------
    phi_deg, psi_deg : array_like, shape (N,)
        Dihedral angles in degrees.
    gmm : sklearn.mixture.GaussianMixture
        Fitted GMM (4D cos/sin features).

    Returns
    -------
    labels : np.ndarray of int, shape (N,)
        Component index 0 .. n_components-1 for each frame.
    """
    phi = np.asarray(phi_deg, dtype=np.float64)
    psi = np.asarray(psi_deg, dtype=np.float64)
    phi_r = np.deg2rad(phi)
    psi_r = np.deg2rad(psi)
    # Feature order matches gmm_escort.extract_torsion_features with d=2:
    # angles_deg = (N,2) [phi, psi]  →  [cos_phi, cos_psi, sin_phi, sin_psi]
    features = np.column_stack([
        np.cos(phi_r), np.cos(psi_r),
        np.sin(phi_r), np.sin(psi_r),
    ])
    return gmm.predict(features)


def basin_populations(
    phi_deg: np.ndarray,
    psi_deg: np.ndarray,
    gmm,
) -> Dict[int, float]:
    """Return fractional population of each GMM component.

    Parameters
    ----------
    phi_deg, psi_deg : array_like, shape (N,)
    gmm : sklearn.mixture.GaussianMixture

    Returns
    -------
    dict mapping component index (int) to population fraction (float).
    Fractions sum to 1.0 (up to floating-point rounding).
    """
    labels = assign_basins(phi_deg, psi_deg, gmm)
    n = max(len(labels), 1)
    return {int(comp): float(np.sum(labels == comp)) / n
            for comp in range(gmm.n_components)}


def gmm_means_deg(gmm) -> Tuple[np.ndarray, np.ndarray]:
    """Convert GMM component means from 4D embedding to (phi, psi) degrees.

    The 4D mean is ordered  [cos_phi, cos_psi, sin_phi, sin_psi].

    Returns
    -------
    phi_mean_deg : np.ndarray, shape (n_components,)
    psi_mean_deg : np.ndarray, shape (n_components,)
    """
    means = np.asarray(gmm.means_)  # (n_components, 4)
    cos_phi = means[:, 0]
    cos_psi = means[:, 1]
    sin_phi = means[:, 2]
    sin_psi = means[:, 3]
    phi_deg = np.degrees(np.arctan2(sin_phi, cos_phi))
    psi_deg = np.degrees(np.arctan2(sin_psi, cos_psi))
    return phi_deg, psi_deg


# ---------------------------------------------------------------------------
# Connectivity metric
# ---------------------------------------------------------------------------

def connectivity_count(
    phi_deg: np.ndarray,
    psi_deg: np.ndarray,
    n_bins: int = 18,
    density_threshold: float = 0.05,
) -> int:
    """Count connected density regions in the Ramachandran (phi, psi) histogram.

    Bins the ensemble into an n_bins × n_bins grid over [-180, 180]².
    Cells with density < density_threshold × peak are treated as empty.
    The remaining cells are labeled with 4-connectivity (scipy.ndimage.label).

    Periodicity (phi/psi wrap at ±180°) is handled by a union-find merge:
    after standard labeling, cells on opposite sides of each periodic boundary
    (row 0 ↔ row n_bins−1 for φ; col 0 ↔ col n_bins−1 for ψ) that are both
    non-zero are merged into one cluster. The count drops from ≥2 to 1 when
    the basins merge across s.

    Parameters
    ----------
    phi_deg, psi_deg : array_like, shape (N,)
        Dihedral angles in degrees (wrapped to [-180, 180) internally).
    n_bins : int
        Bins per axis (default 18 → 20° bins; robust for ≥500 samples/node).
    density_threshold : float
        Cells with density < this fraction of the peak are treated as empty
        (default 0.05).

    Returns
    -------
    n_components : int
        Number of connected basins.  0 if histogram is empty.
    """
    from scipy.ndimage import label as ndlabel

    phi = np.asarray(phi_deg, dtype=np.float64)
    psi = np.asarray(psi_deg, dtype=np.float64)

    # Wrap to [-180, 180) so all samples fall inside the histogram range
    phi = ((phi + 180.0) % 360.0) - 180.0
    psi = ((psi + 180.0) % 360.0) - 180.0

    edges = np.linspace(-180.0, 180.0, n_bins + 1)
    h, _, _ = np.histogram2d(phi, psi, bins=[edges, edges])

    peak = h.max()
    if peak == 0:
        return 0

    mask = (h >= density_threshold * peak).astype(np.int32)

    # Standard 4-connected labeling
    labeled, n_labels = ndlabel(mask)
    if n_labels <= 1:
        return n_labels

    # ---------------------------------------------------------------------------
    # Union-find: merge labels that connect across the periodic torus boundary.
    # Phi periodicity: row 0 (phi≈-180°) ↔ row n_bins-1 (phi≈+180°), same col.
    # Psi periodicity: col 0 ↔ col n_bins-1, same row.
    # A tiling approach fails when the two sides are isolated (no non-zero cells
    # between them), because the tiled array labels them in separate components.
    # The union-find directly merges the boundary labels instead.
    # ---------------------------------------------------------------------------

    parent = list(range(n_labels + 1))   # label 0 = background

    def _find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]   # path compression
            x = parent[x]
        return x

    def _union(x, y):
        rx, ry = _find(x), _find(y)
        if rx != ry:
            parent[ry] = rx

    # Phi boundary
    for j in range(n_bins):
        a, b = int(labeled[0, j]), int(labeled[n_bins - 1, j])
        if a != 0 and b != 0:
            _union(a, b)

    # Psi boundary
    for i in range(n_bins):
        a, b = int(labeled[i, 0]), int(labeled[i, n_bins - 1])
        if a != 0 and b != 0:
            _union(a, b)

    # Count distinct non-zero roots
    roots: set = set()
    for i in range(n_bins):
        for j in range(n_bins):
            lbl = int(labeled[i, j])
            if lbl != 0:
                roots.add(_find(lbl))

    return int(len(roots))


# ---------------------------------------------------------------------------
# Thermodynamic length and equal-length ladder
# ---------------------------------------------------------------------------

def thermodynamic_length(
    work_timeseries: np.ndarray,
    s_nodes: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute per-window thermodynamic length and cumulative length along s.

    The per-window work increment ΔW_k = W_k − W_{k-1} has variance
    Var[ΔW_k].  The thermodynamic length element is g_k = sqrt(Var[ΔW_k]).
    The cumulative length L_k = Σ_{j<k} g_j is monotone and maps the AIS
    schedule to a natural geometry; equal-length placement minimises the
    replica round-trip time.

    Parameters
    ----------
    work_timeseries : np.ndarray, shape (n_samples, n_windows)
        Cumulative reduced work at each window end, as saved by
        run_alanine_ais_s04_baseline.py in work_timeseries.npy.
        NaN rows (failed samples) are dropped.
    s_nodes : np.ndarray, shape (n_windows + 1,)
        Scale factor at each schedule node (lambda_schedule.npy).
        s_nodes[0] is the source scale (e.g. 0.4); s_nodes[-1] = 1.0.

    Returns
    -------
    g_k : np.ndarray, shape (n_windows,)
        Thermodynamic-length element per window.
    L_cumulative : np.ndarray, shape (n_windows + 1,)
        Cumulative length at each node.  L_cumulative[0] = 0,
        L_cumulative[k] corresponds to s_nodes[k].
    """
    wts = np.asarray(work_timeseries, dtype=np.float64)

    # Drop rows with any NaN (failed AIS samples)
    valid = ~np.any(np.isnan(wts), axis=1)
    wts = wts[valid]
    if wts.shape[0] < 2:
        raise ValueError(
            f"At least 2 valid samples needed; got {wts.shape[0]} after NaN removal."
        )

    # Per-window increments: shape (n_samples, n_windows)
    w_padded = np.concatenate([np.zeros((len(wts), 1)), wts], axis=1)
    delta_w = np.diff(w_padded, axis=1)

    # Sample variance of each window's increment
    var_k = np.var(delta_w, axis=0, ddof=1)          # shape (n_windows,)
    g_k = np.sqrt(np.maximum(var_k, 0.0))

    L_cumulative = np.concatenate([[0.0], np.cumsum(g_k)])

    return g_k, L_cumulative


def equal_length_ladder(
    s_nodes: np.ndarray,
    L_cumulative: np.ndarray,
    n_replicas: int,
) -> np.ndarray:
    """Place REMD rungs at equal cumulative thermodynamic length.

    Rungs are placed at equal intervals of L_cumulative by linearly
    interpolating the L(s) curve.  The physical replica (s=1.0) is always
    index 0; the hottest replica (s=s_nodes[0]) is always index n_replicas−1.

    Parameters
    ----------
    s_nodes : np.ndarray, shape (n_nodes,)
        Scale factors at AIS schedule nodes, **ascending** (s_min → 1.0),
        as returned by np.linspace(source_scale, 1.0, n_windows+1).
    L_cumulative : np.ndarray, shape (n_nodes,)
        Cumulative thermodynamic length from thermodynamic_length().
        L_cumulative[0] = 0 ↔ s_nodes[0]; L_cumulative[-1] ↔ s_nodes[-1].
    n_replicas : int
        Desired number of replicas (rungs).  Must be ≥ 2.

    Returns
    -------
    scale_factors : np.ndarray, shape (n_replicas,)
        Optimal scale factors in **descending** order: s[0]=1.0, s[-1]=s_min.
        All values in (0, 1].
    """
    s_nodes = np.asarray(s_nodes, dtype=np.float64)
    L = np.asarray(L_cumulative, dtype=np.float64)

    if n_replicas < 2:
        raise ValueError("n_replicas must be >= 2")
    if len(s_nodes) != len(L):
        raise ValueError(
            f"s_nodes ({len(s_nodes)}) and L_cumulative ({len(L)}) must have same length."
        )

    L_total = float(L[-1])

    # Equal-spacing targets in L
    L_targets = np.linspace(0.0, L_total, n_replicas)   # ascending

    # Invert L(s): interpolate s at each L target.
    # Both s_nodes and L are ascending → standard np.interp applies.
    scale_factors = np.interp(L_targets, L, s_nodes)    # ascending: s_min → 1.0

    # Enforce exact endpoints
    scale_factors[0] = float(s_nodes[0])
    scale_factors[-1] = 1.0

    # Clip to valid range
    scale_factors = np.clip(scale_factors, 1e-6, 1.0)

    # Return descending (physical replica first, hot replica last)
    return scale_factors[::-1].copy()
