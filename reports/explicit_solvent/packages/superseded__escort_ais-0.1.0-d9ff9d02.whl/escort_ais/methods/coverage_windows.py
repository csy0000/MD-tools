#!/usr/bin/env python3
"""coverage_windows.py — anisotropic HARMONIC umbrella windows by landing coverage (no flat-bottom).

The window-construction alternative to the vM/flat-bottom design (`bais_us.py`). Works entirely on the AIS
landings + their trusted cold weights (no MD). Pipeline (`build_windows`):

  1. place_windows  — fit a BIC-selected product-von-Mises mixture to landing geometry, then retain components
                      carrying at least 1% of the cold weight. Every component is diagonal in torsion space.
  2. merge_windows  — merge only redundant pairs, until all pairwise overlap is below `merge_ov` (0.4).
  3. update_windows — the umbrella-UPDATE rule (also used per generation): if unassigned weight > 2%, propose a
                      window on the densest unassigned region; ACCEPT iff [A] ≥`min_core` landings have
                      membership exp(−u)>0.9 (coherent core) AND [B] BAR overlap < `update_ov` (0.4, Option 2)
                      with every existing window. Adds only genuine, distinct new basins (e.g. a late α_L);
                      never re-splits a covered dense basin.

BAR overlap is computed from the weights alone: reweight the landings by each window's harmonic,
q_i(n) ∝ w_n·exp(−u_i(x_n)), and take the Bhattacharyya coefficient Σ_n √(q_i q_j) ∈ [0,1] (the overlap
integral ∫√(p_i p_j) that governs BAR conditioning). Membership P*(x)=max_m exp(−u_m(x)); a landing is
UNASSIGNED when P*<`memb` (≈2.1σ at 0.10). Angles are in RADIANS on the torus (wrap-safe); the vM harmonic
`U=Σ_t κ_t(1−cos(θ_t−μ_t))` maps to a native OpenMM ``CustomTorsionForce`` (`build_harmonic_force`), and that
same function is `bias_u`, so the walker restraint and the reweighting bias are byte-for-byte identical."""
from __future__ import annotations

import numpy as np

from escort_ais.systems.vonmises_mixture import fit_vmm_bic, invert_A, vmm_predict

KMAX_COMP_DEFAULT = 12                      # max #components tried by the vM-mixture BIC fit (placement)
KMIN_DEFAULT = 3.0                         # min per-torsion κ (broadest window, angular σ≈1/√κ ~33°) — RULE 3
KMAX_DEFAULT = 30.0                        # max per-torsion κ (tightest, σ≈11°); also the merge trigger for E* — RULE 3
E_STAR_DEFAULT = 3.0                       # target inter-window wall (kT): other centers ≥ E* above ours in C_m — RULE 1
OVERLAP_MAX_DEFAULT = 0.6                  # RULE 2: pairwise BAR overlap must be < this (tighten the separating
                                           # torsion until met; merge the pair if unreachable at KMAX)
SHARE_DEFAULT = 2                          # a landing may seed/belong to at most this many windows
MEMB_DEFAULT = 0.10                        # unassigned if max_m exp(−u_m) < this (≈2.1σ)
MERGE_OV_DEFAULT = 0.40                    # merge only redundant pairs; useful neighbouring tiles may overlap
UPDATE_OV_DEFAULT = 0.60                   # [B] distinctness gate: a new window's BAR overlap must be < this (= RULE 2)
MIN_WEIGHT_DEFAULT = 0.01                  # [A]: a new window must capture > this fraction of the total cold weight
MIN_CORE_DEFAULT = 3                       # minimal captured-landing count for a well-defined vM fit (not gate [A])
U_TRIGGER_DEFAULT = 0.01                   # keep proposing while unassigned weight > this; real stop is gate [A]
                                           # (no candidate holds > MIN_WEIGHT). Leftover scattered <1% weight is fine.


def _wrap(a):
    return (a + np.pi) % (2.0 * np.pi) - np.pi


def _fit(ang, w, mask, kmin=KMIN_DEFAULT, kmax=KMAX_DEFAULT):
    """Fit a DIAGONAL von Mises window to the masked landings: per-torsion circular mean μ_t and concentration
    κ_t (from the mean resultant length via A⁻¹). The umbrella is the vM log-density U=Σ_t κ_t(1−cos(θ_t−μ_t))."""
    ang = np.asarray(ang, float); w = np.asarray(w, float); D = ang.shape[1]
    wc = w * mask; s = max(wc.sum(), 1e-12)
    mu = np.zeros(D); kappa = np.zeros(D)
    for t in range(D):
        C = (wc * np.cos(ang[:, t])).sum() / s; S = (wc * np.sin(ang[:, t])).sum() / s
        mu[t] = np.arctan2(S, C)
        kappa[t] = float(np.clip(invert_A(min(np.hypot(C, S), 0.999)), kmin, kmax))
    return dict(mu=mu, kappa=kappa)


def bias_u(ang, win):
    """Harmonic bias u(x) = Σ_t κ_t (1 − cos(θ_t − μ_t)) — the von Mises umbrella potential (reduced units),
    IDENTICAL to the OpenMM CustomTorsionForce restraint the walker runs. Periodic and wrap-safe."""
    d = _wrap(np.asarray(ang, float) - win["mu"])
    return (np.asarray(win["kappa"], float)[None, :] * (1.0 - np.cos(d))).sum(1)


def bar_overlap(wi, wj, ang, w):
    """BAR overlap (Bhattacharyya) of two windows' biased landing ensembles, from the weights alone."""
    qi = w * np.exp(-bias_u(ang, wi)); qi = qi / qi.sum()
    qj = w * np.exp(-bias_u(ang, wj)); qj = qj / qj.sum()
    return float(np.sqrt(qi * qj).sum())


def overlap_matrix(wins, ang, w):
    n = len(wins)
    return np.array([[bar_overlap(wins[i], wins[j], ang, w) if i != j else 1.0 for j in range(n)] for i in range(n)])


def label(ang, wins, memb=MEMB_DEFAULT):
    """Lowest-work label L(x)=argmin_m u_m(x); UNASSIGNED where max_m exp(−u_m) < memb. Returns (labels, unassigned)."""
    if not wins:
        return np.zeros(len(ang), int), np.ones(len(ang), bool)
    U = np.stack([bias_u(ang, x) for x in wins], axis=1)
    return U.argmin(1), (np.exp(-U).max(1) < memb)


# ── E*-calibrated κ: centers + aggregate free energies, no per-landing weights ──────────────────────
def window_free_energies(wins, ang, w, memb=MEMB_DEFAULT):
    """Aggregate window ensemble free energies f_k = −ln(Σ_{i∈k} w_i / Σ w) from the hard-label partition. Robust
    (summed weights over many landings, and only DIFFERENCES f_n−f_m are used downstream, so offsets cancel)."""
    lab, un = label(ang, wins, memb)
    wtot = max(float(np.sum(w)), 1e-300)
    f = np.empty(len(wins))
    for k in range(len(wins)):
        f[k] = -np.log(max(float(w[(lab == k) & ~un].sum()), 1e-300) / wtot)
    return f


def estar_kappa(m, centers, f, *, E_star=E_STAR_DEFAULT, kmin=KMIN_DEFAULT, kmax=KMAX_DEFAULT):
    """Center-to-center free-energy LP for window m's anisotropic κ (μ fixed):
        min Σ_t κ_t   s.t.   Σ_t κ_t[1−cos(c_{n,t}−c_{m,t})] ≥ E* − (f_n − f_m)  ∀ n≠m,   kmin ≤ κ_t ≤ kmax.
    Every OTHER center then sits ≥ E* above center m in the biased ensemble C_m. Constraints with RHS ≤ 0
    (a much-higher neighbour) are inactive → no wall toward it. Returns (kappa (D,), feasible, offender):
    ``feasible=False`` (κ>kmax needed to separate a too-close, comparable/deeper neighbour) is the MERGE signal,
    ``offender`` = the window index driving the tightest infeasible demand (else −1)."""
    from scipy.optimize import linprog
    centers = np.asarray(centers, float); D = centers.shape[1]; mu_m = centers[m]
    A_ub, b_ub, worst = [], [], (-1, np.inf)
    for n in range(len(centers)):
        if n == m:
            continue
        coef = 1.0 - np.cos(_wrap(centers[n] - mu_m))          # (D,), ≥ 0
        rhs = E_star - (f[n] - f[m])
        if rhs <= 0:
            continue
        A_ub.append(-coef); b_ub.append(-rhs)
        reach = kmax * float(coef.sum())                        # best achievable wall toward n at κ=kmax
        if reach < rhs - 1e-9 and reach - rhs < worst[1]:       # infeasible toward n; track the tightest
            worst = (n, reach - rhs)
    if not A_ub:                                                # isolated window → broadest umbrella
        return np.full(D, float(kmin)), True, -1
    res = linprog(np.ones(D), A_ub=np.array(A_ub), b_ub=np.array(b_ub),
                  bounds=[(float(kmin), float(kmax))] * D, method="highs")
    if res.success:
        return np.clip(np.asarray(res.x, float), kmin, kmax), True, -1
    return np.full(D, float(kmax)), False, worst[0]             # saturate + flag the offending neighbour


CONFINE_SLACK_DEFAULT = 2.0                 # σ_confine = √slack · σ_core (slack=2 → 1.4σ): cover the connected core
                                           # + its tails, but exclude a disconnected sub-basin many σ away
CONFINE_TRIM_NSIG = 2.5                     # iteratively drop cap members beyond this many σ of the window centre


def _cluster_spread_kappa(mu, members, ang, w, kmin, kmax, slack=CONFINE_SLACK_DEFAULT, nsig=CONFINE_TRIM_NSIG,
                          iters=3):
    """Confinement floor from the window's CONNECTED CORE (the current-label members, NOT a stored cap — caps go
    stale as landings accumulate). A product-vM mixture component can lump a disconnected sub-basin (broad κ spanning
    a barrier); we iteratively trim members beyond `nsig`·σ of the window centre so the spread reflects only the dense
    connected blob. κ = κ_core/slack (σ_confine ≈ 1.4·σ_core) → covers the core + tails but does NOT reach across a
    barrier into a disconnected sub-basin (which sits many σ away → left unassigned rather than lumped)."""
    members = np.asarray(members, bool)
    D = np.asarray(mu).shape[0]
    if int(members.sum()) < 2:
        return np.full(D, float(kmin))
    mu = np.asarray(mu, float); mem = members.copy(); ang = np.asarray(ang, float)
    for _ in range(iters):
        k = _fit(ang, w, mem, kmin=1e-3, kmax=1e6)["kappa"]            # raw spread of current members
        sig = 1.0 / np.sqrt(np.maximum(k, 1e-9))
        keep = mem & np.all(np.abs(np.angle(np.exp(1j * (ang - mu)))) <= nsig * sig, axis=1)
        if int(keep.sum()) < 2 or np.array_equal(keep, mem):
            break
        mem = keep
    return np.clip(_fit(ang, w, mem, kmin=kmin, kmax=kmax)["kappa"] / float(slack), kmin, kmax)


def calibrate_kappa(wins, ang, w, *, E_star=E_STAR_DEFAULT, kmin=KMIN_DEFAULT, kmax=KMAX_DEFAULT, memb=MEMB_DEFAULT):
    """Set every window's κ = max(E* center-to-center wall, connected-core confinement spread) (centres μ unchanged).
    The E* term walls off close/deeper neighbours; the confinement FLOOR confines the umbrella to its own compact
    connected cluster so a floppy (no-neighbour) direction cannot reach across an unknown barrier and lump a
    disconnected sub-basin. Members are the CURRENT hard-label assignment (recomputed each iteration; caps are not
    used — they go stale across generations). Iterates label→f→κ. Returns (wins, merge_pairs): merge_pairs are
    (m, offender) whose LP is infeasible within kmax (⇒ collapse them)."""
    wins = [dict(x) for x in wins]
    wtot = max(float(np.sum(w)), 1e-300)
    if len(wins) == 0:
        return wins, []
    centers = np.array([x["mu"] for x in wins], float)
    pairs = set()
    for _ in range(4):
        lab, un = label(ang, wins, memb)
        f = np.array([-np.log(max(float(w[(lab == k) & ~un].sum()), 1e-300) / wtot) for k in range(len(wins))])
        changed = False
        for m in range(len(wins)):
            spread = _cluster_spread_kappa(wins[m]["mu"], (lab == m) & ~un, ang, w, kmin, kmax)
            if len(wins) == 1:
                k, ok, off = spread, True, -1                          # single window: just confine to its cluster
            else:
                k, ok, off = estar_kappa(m, centers, f, E_star=E_star, kmin=kmin, kmax=kmax)
                k = np.maximum(k, spread)                              # confinement floor (never looser than cluster)
            if not np.allclose(k, wins[m]["kappa"]):
                changed = True
            wins[m]["kappa"] = k
            if not ok and off >= 0:
                pairs.add(frozenset((m, off)))
        if not changed:
            break
    return wins, [tuple(sorted(p)) for p in pairs]


def calibrate_kappa_overlap(wins, ang, w, *, E_star=E_STAR_DEFAULT, kmin=KMIN_DEFAULT, kmax=KMAX_DEFAULT,
                            ov_max=OVERLAP_MAX_DEFAULT, memb=MEMB_DEFAULT, merge=True):
    """The 3-rule torsional-umbrella κ design (centres μ unchanged):
      RULE 1  E* wall = E_star kT   — via `calibrate_kappa`: κ = max(E* center-to-center wall, confinement floor).
              U_m(c_n) ≥ E* − (f_n − f_m) walls every neighbour ≥ E* above ours in C_m, MORE strongly toward a
              LOWER-free-energy neighbour, so a high-FE window cannot leak down the gradient into a low-FE basin.
      RULE 2  pairwise BAR overlap < ov_max, or merge — after the E* calibration, while the worst pairwise
              Bhattacharyya overlap ≥ ov_max, TIGHTEN both windows along their separating torsion (raise κ on the
              axis with the largest 1−cos(Δμ); this only RAISES κ, so the E* wall is preserved). If a pair cannot
              clear ov_max at κ=kmax: merge it (``merge=True``, at build time) or leave it (``merge=False``,
              per-generation add-only — no removal of a seeded umbrella).
      RULE 3  kmin ≤ κ_t ≤ kmax — enforced throughout by `calibrate_kappa` and the tighten step.
    Returns (wins, merge_pairs). ``merge_pairs`` are the (i,j) that were merged (merge=True) or flagged unseparable
    (merge=False)."""
    wins = [dict(x) for x in wins]
    merged_flag = []
    for _ in range(200):
        wins, mpairs = calibrate_kappa(wins, ang, w, E_star=E_star, kmin=kmin, kmax=kmax, memb=memb)
        if mpairs and merge:                                       # E*-infeasible (too-close) pair → collapse, redo
            i, j = mpairs[0]; merged_flag.append((i, j))
            wins = _merge_pair(wins, i, j, ang, w, kmin, kmax); continue
        recalibrate = False; frozen = set()                       # pairs that can't clear ov_max (per-gen: skip)
        for _ in range(4000):                                      # RULE 2 overlap loop (κ only rises here)
            if len(wins) < 2:
                break
            BC = overlap_matrix(wins, ang, w); np.fill_diagonal(BC, 0.0)
            for (a, b) in frozen:                                  # ignore already-flagged unseparable pairs
                if a < len(wins) and b < len(wins):
                    BC[a, b] = BC[b, a] = 0.0
            i, j = np.unravel_index(int(np.argmax(BC)), BC.shape)
            if BC[i, j] < ov_max:
                break
            d = np.abs(_wrap(wins[i]["mu"] - wins[j]["mu"]))       # per-torsion centre separation
            progressed = False
            for t in np.argsort(-d):                               # tighten the separating torsion first
                for m in (i, j):
                    if wins[m]["kappa"][t] < kmax - 1e-9:
                        wins[m]["kappa"][t] = min(wins[m]["kappa"][t] * 1.12, kmax); progressed = True
                if progressed:
                    break
            if not progressed:                                     # cannot clear ov_max at κ=kmax
                merged_flag.append((int(i), int(j)))
                if merge:
                    wins = _merge_pair(wins, i, j, ang, w, kmin, kmax); recalibrate = True
                    break                                          # re-run E* calibration on the merged set
                frozen.add((int(i), int(j)))                       # per-gen: flag but keep (add-only)
        if not recalibrate:
            break
    return wins, merged_flag


def _vmm_windows(ang, w, *, kmax_comp, min_weight, seed=0):
    """Cluster the landings with a product von-Mises mixture (BIC-selected K, argmin to resolve rare states such as
    α_L), hard-assign by responsibility, and keep the components whose captured COLD weight exceeds `min_weight`
    (gate [A]). Each window is `{mu (from EM), kappa (EM spread, provisional), cap}`; the final κ is set later by
    `calibrate_kappa` (E* walls ∨ cluster-confinement floor). No capture radius.

    PLACEMENT IS GEOMETRY-DRIVEN (unweighted EM), by design. The cold weights ``w = e^{-W}`` are heavy-tailed under a
    dissipative switch (ESS ≪ N): weighting the EM by them lets a handful of low-work landings dominate, so BIC
    under-splits and a populous-but-low-weight basin (e.g. C7eq/β with hundreds of landings) is lumped into a
    neighbour and missed. Placement is a COVERAGE problem over where the landings physically are; the cold weights
    enter ONLY through gate [A] (drop clusters with <`min_weight` cold weight) and, downstream, the free energies
    f_m. This cleanly separates coverage (geometry) from thermodynamics (weights)."""
    ang = np.asarray(ang, float); w = np.asarray(w, float); wtot = max(float(w.sum()), 1e-300)
    if len(ang) < 2:
        return []
    kmax = int(min(kmax_comp, len(ang)))
    res = fit_vmm_bic(ang, kmax=kmax, sample_weight=None, kmin=1, seed=seed, select="argmin")  # UNWEIGHTED (geometry)
    mu, kappa, wts = res["mu"], res["kappa"], res["weights"]
    lab = vmm_predict(ang, mu, kappa, wts)
    wins = []
    for k in range(len(mu)):
        cap = lab == k
        if float(w[cap].sum()) / wtot > min_weight and int(cap.sum()) >= MIN_CORE_DEFAULT:   # gate [A] (COLD weight)
            wins.append({"mu": np.asarray(mu[k], float), "kappa": np.asarray(kappa[k], float), "cap": cap})
    return wins


def place_windows(ang, w, *, kmax_comp=KMAX_COMP_DEFAULT, min_weight=MIN_WEIGHT_DEFAULT, seed=0, **_legacy):
    """Placement = von-Mises-mixture clustering of the weighted landings (no capture radius). See `_vmm_windows`."""
    return _vmm_windows(ang, w, kmax_comp=kmax_comp, min_weight=min_weight, seed=seed)


def merge_windows(wins, ang, w, *, merge_ov=MERGE_OV_DEFAULT):
    """Merge the highest-BAR-overlap pair until every pairwise overlap < merge_ov."""
    wins = [dict(x) for x in wins]
    while len(wins) > 1:
        BC = overlap_matrix(wins, ang, w); np.fill_diagonal(BC, 0.0)
        i, j = np.unravel_index(np.argmax(BC), BC.shape)
        if BC[i, j] < merge_ov:
            break
        cu = wins[i]["cap"] | wins[j]["cap"]
        wins = [wins[k] for k in range(len(wins)) if k not in (i, j)] + [{**_fit(ang, w, cu), "cap": cu}]
    return wins


def update_windows(wins, ang, w, *, memb=MEMB_DEFAULT, update_ov=UPDATE_OV_DEFAULT, min_weight=MIN_WEIGHT_DEFAULT,
                   u_trigger=U_TRIGGER_DEFAULT, kmax_comp=KMAX_COMP_DEFAULT, seed=0, max_add=25, **_legacy):
    """Umbrella-update rule (also per generation). Returns (windows, added, unassigned_weight). If the unassigned
    weight exceeds `u_trigger`, cluster the UNASSIGNED landings with a vM mixture (no capture radius) and add each
    new component that passes [A] its captured landings hold > `min_weight` of the TOTAL cold weight AND [B] BAR
    overlap < `update_ov` with every existing window (distinctness — a genuinely new basin). Existing windows are
    untouched (μ fixed); κ is set by `calibrate_kappa` afterwards."""
    ang = np.asarray(ang, float); w = np.asarray(w, float); wtot = max(float(w.sum()), 1e-300)
    wins = [dict(x) for x in wins]; added = []
    _, un = label(ang, wins, memb)
    if w[un].sum() / wtot <= u_trigger or int(un.sum()) < MIN_CORE_DEFAULT:
        return wins, added, float(w[un].sum() / wtot)
    idx_un = np.where(un)[0]                                                # cluster only the unassigned landings
    cands = _vmm_windows(ang[un], w[un], kmax_comp=kmax_comp, min_weight=0.0, seed=seed)
    for c in cands:
        cap = np.zeros(len(ang), bool); cap[idx_un[c["cap"]]] = True
        if float(w[cap].sum()) / wtot < min_weight:                        # [A] captured cold-weight floor (of TOTAL)
            continue
        cand = {"mu": c["mu"], "kappa": c["kappa"], "cap": cap}
        if wins and max(bar_overlap(cand, x, ang, w) for x in wins) >= update_ov:   # [B] distinct new basin
            continue
        wins.append(cand); added.append(cand)
        if len(added) >= max_add:
            break
    _, un = label(ang, wins, memb)
    return wins, added, float(w[un].sum() / wtot)


def _merge_pair(wins, i, j, ang, w, kmin, kmax):
    """Collapse windows i,j into one refit on the union of their caps (μ via vM; κ recalibrated by the caller)."""
    cu = wins[i]["cap"] | wins[j]["cap"]
    keep = [wins[k] for k in range(len(wins)) if k not in (i, j)]
    return keep + [{**_fit(ang, w, cu, kmin=kmin, kmax=kmax), "cap": cu}]


def build_windows(ang, w, *, update_ov=UPDATE_OV_DEFAULT, memb=MEMB_DEFAULT, min_weight=MIN_WEIGHT_DEFAULT,
                  kmax_comp=KMAX_COMP_DEFAULT, E_star=E_STAR_DEFAULT, kmin=KMIN_DEFAULT, kmax=KMAX_DEFAULT,
                  ov_max=OVERLAP_MAX_DEFAULT, seed=0, **kw):
    """Full torsional-umbrella pipeline: geometry-driven (unweighted-argmin) vM-mixture placement (centres μ; gate
    [A]) → distinctness update ([A]∧[B]) → the 3-rule κ design (`calibrate_kappa_overlap`): RULE 1 E* wall,
    RULE 2 pairwise BAR overlap < ov_max or merge, RULE 3 kmin ≤ κ ≤ kmax. Returns (windows, unassigned_weight)."""
    upd_kw = {k: kw[k] for k in ("u_trigger", "max_add") if k in kw}
    wins = place_windows(ang, w, kmax_comp=kmax_comp, min_weight=min_weight, seed=seed)
    wins, _ = calibrate_kappa(wins, ang, w, E_star=E_star, kmin=kmin, kmax=kmax, memb=memb)  # E*/confine before update
    wins, _, U = update_windows(wins, ang, w, memb=memb, update_ov=update_ov, min_weight=min_weight,
                                kmax_comp=kmax_comp, seed=seed, **upd_kw)
    wins, _ = calibrate_kappa_overlap(wins, ang, w, E_star=E_star, kmin=kmin, kmax=kmax, ov_max=ov_max,
                                      memb=memb, merge=True)
    _, un = label(ang, wins, memb)
    return wins, float(w[un].sum() / w.sum())


# ── OpenMM harmonic (von Mises) restraint + continuous walkers ────────────────────────────────────
def build_harmonic_force(quartets, mu, kappa, kT_kj, group=31):
    """OpenMM ``CustomTorsionForce`` for the von Mises umbrella U = Σ_t κ_t·kT·(1−cos(θ_t−μ_t)) [kJ/mol] —
    analytically identical to ``bias_u``·kT. Native, periodic, smooth (no branch cut, no CV inner context)."""
    from openmm import CustomTorsionForce
    f = CustomTorsionForce("ktors*(1 - cos(theta - phiref))")
    f.addPerTorsionParameter("phiref")
    f.addPerTorsionParameter("ktors")
    for (a, b, c, d), m, k in zip(np.asarray(quartets, int), np.asarray(mu, float), np.asarray(kappa, float)):
        f.addTorsion(int(a), int(b), int(c), int(d), [float(m), float(k) * float(kT_kj)])
    f.setForceGroup(int(group))
    return f


class HarmonicWalkers:
    """Persistent continuous von-Mises-restrained walkers — one per window — for the coverage generational loop.
    Mirrors ``bais_us.UmbrellaWalkers`` but with the harmonic (κ) restraint. Each walker is a biased Langevin
    trajectory advanced T_gen/gen; frames accumulate into that window's confined ensemble (the reverse-AIS seed
    pool). New windows can be added mid-run (the update rule). The restraint biases the WHOLE window, so the
    confined density is reweighted to cold by exp(+bias_u) — matching ``bias_u`` exactly (no drift-free interior)."""

    def __init__(self, make_system, quartets, kT_kj, platform="CUDA", device=0, dt_fs=2.0, temp=300.0):
        import mdtraj as md
        self.prmtop, self.base = make_system()
        self.topo = self.prmtop.topology
        self.mdtop = md.Topology.from_openmm(self.topo)
        self.quartets = np.asarray(quartets, int)
        self.kT_kj = kT_kj; self.platform = platform; self.device = device
        self.dt_fs = dt_fs; self.temp = temp
        self.walkers = []

    def add(self, win, seed_xyz_nm, seed=0, minimize=True):
        """Spin up a persistent walker for `win` (dict with mu, kappa), seeded from seed_xyz_nm."""
        import copy
        from openmm import LangevinMiddleIntegrator, Platform, app, unit
        bias = build_harmonic_force(self.quartets, win["mu"], win["kappa"], self.kT_kj, group=31)
        system = copy.deepcopy(self.base); system.addForce(bias)
        integ = LangevinMiddleIntegrator(self.temp * unit.kelvin, 1.0 / unit.picosecond, self.dt_fs * unit.femtoseconds)
        plat = Platform.getPlatformByName(self.platform)
        props = {"Precision": "mixed"}
        if self.device is not None:
            props["DeviceIndex" if self.platform == "CUDA" else "OpenCLDeviceIndex"] = str(self.device)
        sim = app.Simulation(self.topo, system, integ, plat, props)
        sim.context.setPositions(np.asarray(seed_xyz_nm, float) * unit.nanometer)
        if minimize:
            sim.minimizeEnergy(maxIterations=200)
        sim.context.setVelocitiesToTemperature(self.temp * unit.kelvin, int(seed))
        self.walkers.append(dict(sim=sim, bias=bias, mu=np.asarray(win["mu"], float),
                                 kappa=np.asarray(win["kappa"], float), xyz=[]))
        return len(self.walkers) - 1

    def update_kappa(self, i, kappa):
        """Re-solve of κ for a running walker (μ unchanged): update the CustomTorsionForce ktors=κ·kT in place via
        updateParametersInContext — no walker restart. Used by the E* escape-feedback / per-G_update recalibration."""
        wk = self.walkers[i]; kappa = np.asarray(kappa, float); f = wk["bias"]
        for t, (q, k) in enumerate(zip(self.quartets, kappa)):
            f.setTorsionParameters(t, int(q[0]), int(q[1]), int(q[2]), int(q[3]),
                                   [float(wk["mu"][t]), float(k) * float(self.kT_kj)])
        f.updateParametersInContext(wk["sim"].context)
        wk["kappa"] = kappa

    def advance(self, t_ps, save_ps):
        from openmm import unit
        stride = max(1, int(round(save_ps * 1000 / self.dt_fs)))
        n_save = max(1, int(round(t_ps / save_ps)))
        for wk in self.walkers:
            for _ in range(n_save):
                wk["sim"].step(stride)
                wk["xyz"].append(wk["sim"].context.getState(getPositions=True).getPositions(asNumpy=True).value_in_unit(unit.nanometer))

    def samples(self, i):
        import mdtraj as md
        wk = self.walkers[i]
        return md.Trajectory(np.asarray(wk["xyz"], float), self.mdtop) if wk["xyz"] else None

    def n_frames(self, i):
        return len(self.walkers[i]["xyz"])

    def __len__(self):
        return len(self.walkers)
