"""asymptotic_bar.py — sequential (asymptotic) AIS + BAR cold-state free-energy estimator.

Each *round* extends the hot ensemble and contributes a batch of forward AIS works (hot->cold) and
reverse AIS works (cold->hot), labelled by cold basin. We accumulate the batches across rounds (at a
FIXED switching time, so plain BAR pooling is valid) and, at every round, report the per-basin cold
free-energy differences from BOTH:

  * combined-BAR        — endpoint-partitioned pairwise BAR + row-contrast d_ab - d_a0
  * hot-unified BAR      — endpoint-restricted (global-hot) BAR

The forward/reverse Crooks-paired work **overlap** is reported per basin as a *confidence / warning
index* (it is NOT used to control the switching time here). As rounds accumulate and the hot ensemble
converges, both estimates converge to the true cold ddF (asymptotic, under: hot ensemble equilibrated,
adequate work overlap, within-basin cold-MD equilibrium).

Pure numpy — reuses the BAR machinery in escort_ais.methods.endpoint_bar; no OpenMM, so unit-testable.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from escort_ais.methods.endpoint_bar import (
    _overlap_score,
    endpoint_partitioned_pairwise_bar,
    endpoint_restricted_bar,
    estimate_v3_row_contrast_endpoint_bar,
)

OVERLAP_WARN = 0.2      # overlap_score below this -> "low-overlap" confidence warning
OVERLAP_BAD = 0.05      # below this -> "very-low-overlap" (estimate unreliable)


@dataclass
class RoundData:
    """One round's AIS works + basin labels (reduced works W = -lnw)."""
    W_f: np.ndarray        # forward reduced works (hot->cold)
    a_f: np.ndarray        # forward hot-START basin
    b_f: np.ndarray        # forward cold-END basin
    W_r: np.ndarray        # reverse reduced works (cold->hot)
    b_r: np.ndarray        # reverse cold-START basin
    a_r: np.ndarray        # reverse hot-END basin
    hot_ns: float = np.nan  # cumulative hot-ensemble length for this round (bookkeeping)


@dataclass
class Accumulator:
    """Cumulative pool of round batches (valid plain-BAR pooling at fixed switching time)."""
    rounds: list = field(default_factory=list)

    def append(self, rd: RoundData) -> None:
        self.rounds.append(rd)

    def _cat(self, attr: str) -> np.ndarray:
        arrs = [np.asarray(getattr(r, attr)) for r in self.rounds]
        return np.concatenate(arrs) if arrs else np.array([])

    @property
    def pooled(self):
        return (self._cat("W_f"), self._cat("a_f").astype(int), self._cat("b_f").astype(int),
                self._cat("W_r"), self._cat("b_r").astype(int), self._cat("a_r").astype(int))


def _ddF_from_DeltaG(deltaG: dict, n_basins: int, ref: int = 0) -> np.ndarray:
    out = np.full(n_basins, np.nan)
    g0 = deltaG.get(ref, np.nan)
    for b in range(n_basins):
        gb = deltaG.get(b, np.nan)
        out[b] = gb - g0
    return out


def _rmse(vals: np.ndarray, ref: np.ndarray, mask: np.ndarray | None = None) -> float:
    vals = np.asarray(vals, float); ref = np.asarray(ref, float)
    m = np.isfinite(vals) & np.isfinite(ref)
    if mask is not None:
        m &= mask
    return float(np.sqrt(np.mean((vals[m] - ref[m]) ** 2))) if m.any() else np.nan


def _rmse_ci(samples: np.ndarray | None, ref: np.ndarray, mask: np.ndarray | None = None,
             q=(2.5, 97.5)) -> list | None:
    """95% CI on the RMSE by propagating the per-basin bootstrap ddF replicates.

    `samples` is the (n_boot, n_basins) replicate matrix from endpoint_restricted_bar; for each
    replicate we recompute RMSE over the (masked, finite) basins, then take percentiles."""
    if samples is None:
        return None
    ref = np.asarray(ref, float)
    m = np.isfinite(ref)
    if mask is not None:
        m = m & mask
    if not m.any():
        return None
    sub = samples[:, m] - ref[m]                       # (n_boot, n_masked)
    with np.errstate(invalid="ignore"):
        rmse = np.sqrt(np.nanmean(sub ** 2, axis=1))   # per-replicate RMSE, NaN-robust
    rmse = rmse[np.isfinite(rmse)]
    if len(rmse) < 2:
        return None
    return [float(np.percentile(rmse, q[0])), float(np.percentile(rmse, q[1]))]


def confidence_flags(overlap: np.ndarray, n_f_hits: np.ndarray, ddF: np.ndarray,
                     warn: float = OVERLAP_WARN, bad: float = OVERLAP_BAD) -> list[str]:
    """Per-basin confidence label from the BAR overlap + coverage (a warning index, not a control)."""
    flags = []
    for ov, nf, d in zip(overlap, n_f_hits, ddF):
        if not np.isfinite(d) or nf == 0:
            flags.append("gated")
        elif not np.isfinite(ov) or ov < bad:
            flags.append("very-low-overlap")
        elif ov < warn:
            flags.append("low-overlap")
        else:
            flags.append("ok")
    return flags


def estimate(acc: Accumulator, n_basins: int, reference_ddF: np.ndarray | None = None,
             reference_basin: int = 0, bootstrap: bool = True, n_bootstrap: int = 200,
             rng: np.random.Generator | None = None) -> dict:
    """Run combined-BAR + hot-unified BAR on the cumulative pool; return ddF + overlap confidence."""
    if rng is None:
        rng = np.random.default_rng(0)
    W_f, a_f, b_f, W_r, b_r, a_r = acc.pooled
    basin_ids = list(range(n_basins))

    # ── hot-unified (global-hot) BAR ──
    hub = endpoint_restricted_bar(W_f, b_f, W_r, b_r, basin_ids, reference_basin=reference_basin,
                                  bootstrap=bootstrap, n_bootstrap=n_bootstrap, rng=rng)
    ddF_hub = np.array([hub["ddF"].get(b, np.nan) for b in basin_ids])
    diag_hub = hub["diagnostics"]
    overlap = np.array([diag_hub.get(b, {}).get("overlap_score", np.nan) for b in basin_ids])
    n_f_hits = np.array([diag_hub.get(b, {}).get("N_f_hits", 0) for b in basin_ids])
    n_r = np.array([diag_hub.get(b, {}).get("N_r", 0) for b in basin_ids])
    # harmonic-mean effective pair count per basin (forward hits vs reverse starts)
    with np.errstate(divide="ignore", invalid="ignore"):
        ess = np.where((n_f_hits + n_r) > 0, 2.0 * n_f_hits * n_r / (n_f_hits + n_r), 0.0)
    hub_ci = np.array([(diag_hub.get(b, {}).get("bootstrap_95ci_low", np.nan),
                        diag_hub.get(b, {}).get("bootstrap_95ci_high", np.nan)) for b in basin_ids])

    # ── combined-BAR (endpoint-partitioned pairwise + row contrast) ──
    Delta, var, diag_pair = endpoint_partitioned_pairwise_bar(
        W_f, a_f, b_f, W_r, b_r, a_r, n_basins, bootstrap=bootstrap, n_bootstrap=n_bootstrap, rng=rng)
    ddF_cmb, ddF_cmb_std, _contrib, _dv3 = estimate_v3_row_contrast_endpoint_bar(
        Delta, var, diag_pair, reference_beta=reference_basin, n_basins=n_basins)
    ddF_cmb = np.asarray(ddF_cmb, float)

    # forward-only AIS baseline (Jarzynski per cold basin) for reference
    ddF_ais = np.array([hub["ddF_AIS"].get(b, np.nan) for b in basin_ids])

    out = dict(
        n_basins=n_basins,
        ddF_combined=ddF_cmb, ddF_combined_std=np.asarray(ddF_cmb_std, float),
        ddF_hotunified=ddF_hub, ddF_hotunified_ci=hub_ci,
        ddF_ais=ddF_ais,
        overlap=overlap, ess=ess, n_f_hits=n_f_hits, n_r=n_r,
        n_forward=int(len(W_f)), n_reverse=int(len(W_r)),
        confidence=confidence_flags(overlap, n_f_hits, ddF_hub),
    )
    if reference_ddF is not None:
        ref = np.asarray(reference_ddF, float)
        covered = np.array([f == "ok" or f == "low-overlap" for f in out["confidence"]])
        out["rmse_combined_all"] = _rmse(ddF_cmb, ref)
        out["rmse_hotunified_all"] = _rmse(ddF_hub, ref)
        out["rmse_combined_covered"] = _rmse(ddF_cmb, ref, covered)
        out["rmse_hotunified_covered"] = _rmse(ddF_hub, ref, covered)
        # bootstrap CIs on the hot-unified RMSE (propagate the per-basin ddF replicates)
        hub_samples = hub.get("ddF_bootstrap_samples")
        out["rmse_hotunified_all_ci"] = _rmse_ci(hub_samples, ref)
        out["rmse_hotunified_covered_ci"] = _rmse_ci(hub_samples, ref, covered)
        out["covered_basins"] = covered.tolist()
    return out
