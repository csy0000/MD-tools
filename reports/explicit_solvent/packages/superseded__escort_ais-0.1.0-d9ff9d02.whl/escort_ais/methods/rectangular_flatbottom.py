"""rectangular_flatbottom.py — independent 1-D periodic flat-bottom walls for rectangular basins.

Replaces the *radial* torus restraint ``U = ½k·max(0, √D − h)²`` for rectangular proposals.  A
rectangle is a product of periodic intervals, so its restraint is separable:

    U_m(phi, psi) = U_phi,m(phi) + U_psi,m(psi)

    U_theta,m(theta) = ½ k_theta,m · d_out(theta, I_theta,m)²,
    d_out(theta, I) = 0 inside I, else the shortest periodic distance to the nearest boundary.

**The identity that makes this clean.**  A periodic interval ``I`` is equivalently
``(centre mu, half-width h)``, and for *any* interval — wrapping or not —

    theta in I   <=>   |wrap(theta - mu)| <= h
    d_out(theta, I)  =  max(0, |wrap(theta - mu)| - h)

and ``|wrap(x)| = acos(cos x)``.  So one branch-free expression handles the ±pi seam exactly:

    U = 0.5 * k * max(0, acos(clamp(cos(theta - mu))) - h)^2

An unrestrained dimension is expressed either as ``k = 0`` or as a full-circle interval
(``h = pi``); both give **identically zero** energy and force, which is what §10 requires — a
basin gets a wall only in the dimension that actually separates it.

Two OpenMM builds are provided and are tested to agree:

* ``build_rectangular_flatbottom_force`` — a single ``CustomTorsionForce`` carrying one torsion
  per restrained dimension with per-torsion ``(k, mu, h)``.  Preferred: native, no inner Context,
  no extra force-evaluation pass.
* ``build_rectangular_flatbottom_cvforce`` — the ``CustomCVForce`` equivalent, kept as an
  independent cross-check of the expression.

Known and tested boundary behaviour: the force is continuous everywhere except at the *antipode*
of the interval centre (``|wrap(theta-mu)| = pi``), where the two walls are equidistant and the
restoring direction is genuinely ambiguous.  That is a measure-zero set intrinsic to confining a
periodic coordinate, it lies as far from the flat core as possible, and the energy stays
continuous there.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

from escort_ais.methods.barrier_partition import (PeriodicInterval, RectangularBasin,
                                                  circ_distance)

__all__ = [
    "rect_bias_kT",
    "rect_bias_matrix",
    "interval_wall_params",
    "build_rectangular_flatbottom_force",
    "build_rectangular_flatbottom_cvforce",
    "RECT_FORCE_GROUP",
]

RECT_FORCE_GROUP = 29
_ENERGY = "0.5*kw*dout^2; dout=max(0, acos(max(-1,min(1,cos(theta-mu)))) - hw)"


# ─────────────────────────────── NumPy reference ─────────────────────────────
def interval_wall_params(interval: PeriodicInterval, k: Optional[float]) -> tuple[float, float, float]:
    """``(k, mu, h)`` for one dimension; a full circle or ``k=None`` gives no restraint."""
    if k is None or interval.full:
        return 0.0, 0.0, float(np.pi)
    return float(k), float(interval.centre), float(interval.half_width)


def rect_bias_kT(phi, psi, basin: RectangularBasin) -> np.ndarray:
    """``U_m(phi, psi)`` in kT — the NumPy reference the OpenMM force is tested against."""
    k_phi, mu_phi, h_phi = interval_wall_params(basin.phi_interval, basin.k_phi)
    k_psi, mu_psi, h_psi = interval_wall_params(basin.psi_interval, basin.k_psi)
    d_phi = np.maximum(0.0, circ_distance(phi, mu_phi) - h_phi)
    d_psi = np.maximum(0.0, circ_distance(psi, mu_psi) - h_psi)
    return 0.5 * k_phi * d_phi ** 2 + 0.5 * k_psi * d_psi ** 2


def rect_bias_matrix(phi, psi, basins: Sequence[RectangularBasin]) -> np.ndarray:
    """``B[i, m] = U_m(x_i)`` in kT — the bias matrix mixture-CFT consumes."""
    phi = np.asarray(phi, float)
    return np.column_stack([rect_bias_kT(phi, psi, b) for b in basins])


# ─────────────────────────────── OpenMM builds ───────────────────────────────
def build_rectangular_flatbottom_force(phi_quartet, psi_quartet, basin: RectangularBasin,
                                       kT_kj: float, group: int = RECT_FORCE_GROUP,
                                       openmm=None):
    """Single ``CustomTorsionForce`` with one torsion per restrained dimension.

    Dimensions with no wall are simply not added, so they contribute exactly nothing — not a
    small number, nothing.
    """
    if openmm is None:
        import openmm
    f = openmm.CustomTorsionForce(_ENERGY)
    for name in ("kw", "mu", "hw"):
        f.addPerTorsionParameter(name)
    for quartet, interval, k in ((phi_quartet, basin.phi_interval, basin.k_phi),
                                 (psi_quartet, basin.psi_interval, basin.k_psi)):
        kk, mu, hw = interval_wall_params(interval, k)
        if kk <= 0.0 or hw >= np.pi - 1e-12:
            continue                                   # unrestrained dimension: add nothing
        a, b, c, d = (int(x) for x in quartet)
        f.addTorsion(a, b, c, d, [float(kk) * float(kT_kj), float(mu), float(hw)])
    f.setForceGroup(int(group))
    return f


def build_rectangular_flatbottom_cvforce(phi_quartet, psi_quartet, basin: RectangularBasin,
                                         kT_kj: float, group: int = RECT_FORCE_GROUP,
                                         openmm=None):
    """``CustomCVForce`` equivalent: one torsion CV per dimension, summed in the wrapper.

    Independent implementation of the same energy, used to cross-check the fast build.
    """
    if openmm is None:
        import openmm
    terms, cvs = [], {}
    for tag, quartet, interval, k in (("phi", phi_quartet, basin.phi_interval, basin.k_phi),
                                      ("psi", psi_quartet, basin.psi_interval, basin.k_psi)):
        kk, mu, hw = interval_wall_params(interval, k)
        if kk <= 0.0 or hw >= np.pi - 1e-12:
            continue
        cv = openmm.CustomTorsionForce("theta")
        a, b, c, d = (int(x) for x in quartet)
        cv.addTorsion(a, b, c, d, [])
        cvs[tag] = cv
        terms.append(f"0.5*kw_{tag}*max(0, acos(max(-1,min(1,cos({tag}-mu_{tag})))) - hw_{tag})^2")
    if not terms:
        f = openmm.CustomBondForce("0")               # nothing to restrain
        f.setForceGroup(int(group))
        return f
    f = openmm.CustomCVForce(" + ".join(terms))
    for tag, cv in cvs.items():
        f.addCollectiveVariable(tag, cv)
        interval = basin.phi_interval if tag == "phi" else basin.psi_interval
        k = basin.k_phi if tag == "phi" else basin.k_psi
        kk, mu, hw = interval_wall_params(interval, k)
        f.addGlobalParameter(f"kw_{tag}", float(kk) * float(kT_kj))
        f.addGlobalParameter(f"mu_{tag}", float(mu))
        f.addGlobalParameter(f"hw_{tag}", float(hw))
    f.setForceGroup(int(group))
    return f
