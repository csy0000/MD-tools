"""Disjoint-Substate Conditional BAR — free energy of each cold substate against a shared hot state.

Theory: ``docs/theory/alanine_disjoint_substate_conditional_bar.pdf``.

The cold ensemble is partitioned into exhaustive, mutually disjoint substates
``C = C_0 + C_1 + ... + C_{M-1}``. Each substate is a *conditional physical* ensemble
``pi_m = pi_C(.|x in C_m)`` — never an umbrella, a proposal, or a member of a mixture. The
recorded work is the physical hot<->cold work only: no ``+-U_m(x_0)`` endpoint term, no restraint
activation or removal work, no basin-dependent switching potential, and no intermediate ensemble
between H and C_m.

Everything here rests on the conditional Crooks relation (theory Prop. 1),

    P_F(W, C_m) = exp(W - Delta_m) * P_R^(m)(-W),      Delta_m = f_m - f_H,

whose Bennett solution is :func:`conditional_bar_delta`. Each substate is solved INDEPENDENTLY:
no coupled system, no MBAR/UWHAM self-consistency, no proposal mixture, no importance ratio, no
normalized mixture weights. ESS appears here only as a descriptive diagnostic and never inside an
estimator.

The forward normalizer deserves emphasis because it is the easiest thing to get wrong:
``M_m = log(N_F / N_R_m)`` uses the size of the WHOLE forward bank, not the number of trajectories
that landed in ``C_m``. In the conditional Crooks relation the forward side is a *joint* density in
which the landing probability is part of the estimand; normalizing by the landing count instead
silently estimates a within-substate quantity and drops the population information.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np
from scipy.optimize import brentq
from scipy.special import expit, logsumexp

__all__ = [
    "SubstateResult",
    "conditional_bar_delta",
    "jarzynski_delta",
    "jensen_guard",
    "solve_substates",
    "combine_substates",
    "reconstruct_density",
    "endpoint_restricted_delta",
]


@dataclass
class SubstateResult:
    """One substate's conditional-BAR solution and the diagnostics needed to trust it."""
    label: str
    delta: float                       # Delta_m = f_m - f_H  (reduced)
    delta_jarzynski: float             # forward-only initializer, diagnostic
    n_landed: int                      # forward trajectories terminating in C_m
    n_reverse: int
    identifiable: bool
    jensen: dict = field(default_factory=dict)
    ess_reverse: float = float("nan")  # descriptive only
    message: str = ""


def jarzynski_delta(forward_work: np.ndarray, landed: np.ndarray, n_forward: Optional[int] = None
                    ) -> float:
    """``Delta_m`` from the forward bank alone (theory eq. 8).

    ``(1/N_F) sum_i 1_m(x_i^T) exp(-W_i^F) -> exp(-Delta_m)``. One-sided exponential average:
    an initializer and a reference diagnostic, never the reported answer.
    """
    w = np.asarray(forward_work, float)
    mask = np.asarray(landed, bool)
    n_f = int(len(w) if n_forward is None else n_forward)
    if n_f <= 0 or not mask.any():
        return float("nan")
    return float(np.log(n_f) - logsumexp(-w[mask]))


def _bar_residual(delta: float, wf_landed: np.ndarray, wr: np.ndarray, m_shift: float) -> float:
    """Left minus right of theory eq. (9). Strictly increasing in ``delta`` (Prop. 2)."""
    return float(np.sum(expit(delta - m_shift - wf_landed))
                 - np.sum(expit(m_shift - delta - wr)))


def conditional_bar_delta(forward_work: np.ndarray, landed: np.ndarray, reverse_work: np.ndarray,
                          n_forward: Optional[int] = None, bracket: float = 400.0) -> float:
    """Solve theory eq. (9) for ``Delta_m = f_m - f_H``.

    :param forward_work: reduced physical work of every forward (H->C) trajectory.
    :param landed: boolean mask, True where the forward trajectory terminated in this substate.
    :param reverse_work: reduced physical work of the reverse (C->H) trajectories started from
        ``pi_m`` — the locally equilibrated conditional physical ensemble.
    :param n_forward: size of the WHOLE forward bank; defaults to ``len(forward_work)``.

    The residual is strictly increasing in ``Delta`` (the left sum rises, the right falls), so the
    root is unique and Brent finds the global solution rather than a local one.
    """
    wf = np.asarray(forward_work, float)
    mask = np.asarray(landed, bool)
    wr = np.asarray(reverse_work, float)
    n_f = int(len(wf) if n_forward is None else n_forward)
    wf_landed = wf[mask]
    if wf_landed.size == 0 or wr.size == 0 or n_f <= 0:
        return float("nan")
    m_shift = float(np.log(n_f / wr.size))

    lo, hi = -abs(bracket), abs(bracket)
    f_lo, f_hi = (_bar_residual(lo, wf_landed, wr, m_shift),
                  _bar_residual(hi, wf_landed, wr, m_shift))
    if f_lo > 0 or f_hi < 0:                                  # root outside the bracket
        return float("nan")
    return float(brentq(_bar_residual, lo, hi, args=(wf_landed, wr, m_shift), xtol=1e-10))


def jensen_guard(reverse_work: np.ndarray, delta: float, n_sem: float = 5.0) -> dict:
    """Per-substate Jensen bound ``E_{pi_m}[W^R] >= f_H - f_m = -Delta_m`` (exact, any protocol).

    A sample mean below the bound cannot be a favourable fluctuation: it means the reverse leg is
    not being generated from ``pi_m`` under the Hamiltonian that defines ``Delta_m`` — the usual
    causes being a mismatched system build or a substate the preparation never equilibrated across.
    """
    wr = np.asarray(reverse_work, float).ravel()
    if wr.size == 0 or not np.isfinite(delta):
        return dict(ok=False, mean=float("nan"), bound=float("nan"), message="no reverse work")
    mean = float(wr.mean())
    sem = float(wr.std() / np.sqrt(wr.size))
    bound = -float(delta)
    ok = bool(mean >= bound - n_sem * max(sem, 1e-12))
    return dict(ok=ok, mean=mean, sem=sem, bound=bound, deficit=bound - mean,
                message=("Jensen bound satisfied." if ok else
                         f"JENSEN VIOLATION: <W^R> = {mean:.3f} is {bound - mean:.3f} below "
                         f"f_H - f_m = {bound:.3f} (SEM {sem:.3f}). The reverse leg is not "
                         f"sampling pi_m under the Hamiltonian that defines Delta_m."))


def work_overlap(forward_work: np.ndarray, landed: np.ndarray, reverse_work: np.ndarray,
                 n_bins: int = 40) -> float:
    """Histogram overlap of the two work distributions a substate's BAR solve actually pairs.

    Under the Crooks pairing the forward works that LANDED in the substate and the negated reverse
    works started FROM it share an axis and cross at ``Delta_m``; their overlap in [0, 1] is how
    well conditioned that particular Bennett solve is. This is the per-substate analogue of the
    diagnostic ``endpoint_bar`` already reports, and it is the honest one to quote beside a
    ``delta``: the Jensen guard tests a bound and the reverse ESS measures weight concentration on
    one side only, so neither says whether the two distributions actually meet.

    Interpretation follows ``asymptotic_bar``'s established thresholds -- below 0.2 is low overlap,
    below 0.05 the estimate is unreliable -- rather than a fresh scale.

    NaN when either side has fewer than two samples, which is a statement about the data and must
    not be silently rendered as 0.0 (an overlap of zero means the distributions are disjoint, a
    much stronger and different claim).
    """
    wf = np.asarray(forward_work, float)[np.asarray(landed, bool)]
    wr = np.asarray(reverse_work, float)
    if wf.size < 2 or wr.size < 2:
        return float("nan")
    a, b = wf, -wr
    both = np.concatenate([a, b])
    lo, hi = np.percentile(both, 0.5), np.percentile(both, 99.5)
    pad = 0.05 * (hi - lo + 1e-9)
    bins = np.linspace(lo - pad, hi + pad, int(n_bins) + 1)
    pa, _ = np.histogram(a, bins=bins, density=True)
    pb, _ = np.histogram(b, bins=bins, density=True)
    return float(np.sum(np.minimum(pa, pb) * np.diff(bins)))


def _ess(values: np.ndarray) -> float:
    """Kish ESS of exp(-W) — a descriptive measure of weight concentration, never an estimator."""
    w = np.asarray(values, float)
    if w.size == 0:
        return float("nan")
    lw = -w - logsumexp(-w)
    p = np.exp(lw)
    return float(1.0 / np.sum(p ** 2))


def solve_substates(forward_work: np.ndarray, labels: np.ndarray,
                    reverse_work_by_substate: dict, substate_labels: Sequence[str] | None = None,
                    n_forward: Optional[int] = None) -> list[SubstateResult]:
    """Solve every substate independently.

    :param labels: integer substate index of each forward trajectory's TERMINAL configuration,
        or -1 if it fell outside the partition (which an exhaustive partition never does).
    :param reverse_work_by_substate: ``{substate_index: reverse works}``.

    A substate with no forward landing is reported as ``identifiable=False`` with ``delta=nan``
    rather than being assigned a value — theory §4.
    """
    wf = np.asarray(forward_work, float)
    lab = np.asarray(labels, int)
    n_f = int(len(wf) if n_forward is None else n_forward)
    keys = sorted(reverse_work_by_substate)
    names = list(substate_labels) if substate_labels is not None else [f"C{k}" for k in keys]

    out: list[SubstateResult] = []
    for name, key in zip(names, keys):
        mask = lab == key
        wr = np.asarray(reverse_work_by_substate[key], float)
        n_landed = int(mask.sum())
        if n_landed == 0:
            out.append(SubstateResult(
                label=name, delta=float("nan"), delta_jarzynski=float("nan"), n_landed=0,
                n_reverse=int(wr.size), identifiable=False,
                message=("no forward trajectory landed in this substate: unidentifiable from the "
                         "current data (theory §4). Report as such; do not assign a value.")))
            continue
        delta = conditional_bar_delta(wf, mask, wr, n_forward=n_f)
        out.append(SubstateResult(
            label=name, delta=delta,
            delta_jarzynski=jarzynski_delta(wf, mask, n_forward=n_f),
            n_landed=n_landed, n_reverse=int(wr.size),
            identifiable=bool(np.isfinite(delta)),
            jensen=jensen_guard(wr, delta), ess_reverse=_ess(wr),
            message=("" if np.isfinite(delta) else
                     "conditional BAR did not bracket a root; check the work units and overlap")))
    return out


def combine_substates(results: Sequence[SubstateResult], reference: int = 0) -> dict:
    """Populations, relative free energies and the global cold free energy (theory §6).

    ``pi_m = e^{-Delta_m} / sum_n e^{-Delta_n}`` and ``f_C - f_H = -log sum_m e^{-Delta_m}``. The
    latter is ``Z_C = sum_m Z_m`` divided by ``Z_H``, and is valid only because the partition is
    exhaustive — the caller is responsible for having verified that.
    """
    usable = [r for r in results if r.identifiable and np.isfinite(r.delta)]
    if not usable:
        return dict(populations={}, relative_free_energies={}, delta_f_HC=float("nan"),
                    unidentifiable=[r.label for r in results], n_substates=len(results))
    deltas = np.array([r.delta for r in usable], float)
    log_z = logsumexp(-deltas)                                  # log sum_m e^{-Delta_m}
    pops = np.exp(-deltas - log_z)
    ref_label = results[reference].label if 0 <= reference < len(results) else usable[0].label
    ref_delta = next((r.delta for r in usable if r.label == ref_label), usable[0].delta)
    return dict(
        populations={r.label: float(p) for r, p in zip(usable, pops)},
        relative_free_energies={r.label: float(r.delta - ref_delta) for r in usable},
        reference_substate=ref_label,
        delta_f_HC=float(-log_z),
        deltas={r.label: float(r.delta) for r in usable},
        unidentifiable=[r.label for r in results if not r.identifiable],
        n_substates=len(results),
    )


def reconstruct_density(populations: dict, substate_densities: dict) -> np.ndarray:
    """``p_recon = sum_m pi_m p_m`` (theory eq. 13) — the ONLY admissible reconstruction.

    ``substate_densities[m]`` must be normalized WITHIN its substate. No smoothing, blending or
    interpolation across substate boundaries is permitted: that would reintroduce coupling the
    disjoint partition excludes.
    """
    common = [k for k in populations if k in substate_densities]
    if not common:
        raise ValueError("no substate has both a population and a density")
    total = float(sum(populations[k] for k in common))
    if not np.isclose(total, 1.0, atol=1e-6):
        raise ValueError(f"populations over the supplied substates sum to {total:.6f}, not 1; "
                         f"the partition must be exhaustive before reconstruction")
    out = None
    for k in common:
        d = np.asarray(substate_densities[k], float)
        s = d.sum()
        if not np.isclose(s, 1.0, atol=1e-6):
            raise ValueError(f"substate {k!r} density is not normalized within its substate "
                             f"(sums to {s:.6f})")
        out = d * populations[k] if out is None else out + d * populations[k]
    return out


def endpoint_restricted_delta(forward_work, forward_landed, reverse_work, reverse_landed,
                              n_forward: int, n_reverse: int, bracket: float = 400.0) -> float:
    """Doubly-conditioned BAR: ``f^C_n - f^H_n`` from legs restricted at BOTH endpoints.

    Forward legs start in hot region ``H_n`` and are kept if they land in cold box ``C_n``; reverse
    legs start in ``C_n`` and are kept if they land in ``H_n``. Conditioning the joint Crooks
    relation on both endpoints,

        p_F(W, C_n | H_n) / p_R(-W, H_n | C_n) = exp(W - [Delta_f - ln(pi^C_n / pi^H_n)]),

    and the bracket collapses exactly to ``f^C_n - f^H_n``: the global ``Delta_f`` cancels against
    the population ratio. So the root of this residual is the *matched* hot-to-cold free energy,
    not a quantity referenced to the whole hot state.

    CRITICAL NORMALISER: ``M = ln(n_forward / n_reverse)`` uses the TOTAL number of legs launched
    from ``H_n`` and from ``C_n`` -- including those discarded for missing the far endpoint. The
    hit probabilities are part of the estimand, exactly as the landing fraction is in
    :func:`conditional_bar_delta`. Normalising by the retained counts would drop them.

    This is the building block for the stratified decomposition

        f^C_n - f^C_m = (f^C_n - f^H_n) - (f^C_m - f^H_m) + (f^H_n - f^H_m),

    whose last term is obtained by counting in the (well-sampled) hot ensemble.
    """
    wf = np.asarray(forward_work, float)[np.asarray(forward_landed, bool)]
    wr = np.asarray(reverse_work, float)[np.asarray(reverse_landed, bool)]
    if wf.size == 0 or wr.size == 0 or n_forward <= 0 or n_reverse <= 0:
        return float("nan")
    m_shift = float(np.log(n_forward / n_reverse))

    def residual(d):
        return float(np.sum(expit(d - m_shift - wf)) - np.sum(expit(m_shift - d - wr)))

    lo, hi = -abs(bracket), abs(bracket)
    if residual(lo) > 0 or residual(hi) < 0:
        return float("nan")
    return float(brentq(residual, lo, hi, xtol=1e-10))
