"""reverse_ais_bar.py — BAR free-energy estimator from forward+reverse AIS work values.

The Bennett Acceptance Ratio (BAR) estimator combines forward work W^{H→C}
and reverse work W^{C→H} to give a lower-variance estimate of ΔF_{H→C}.

Equations
---------
BAR self-consistency condition (Crooks/Bennett):
    Σ_f 1/(1 + n_f/n_r * exp(β(W_f - Δf))) = Σ_r 1/(1 + n_r/n_f * exp(β(W_r + Δf)))

Solved numerically via scipy.optimize.brentq on the balance condition.

Basin-restricted version uses only walkers whose cold endpoint lands in basin B.
All basin-restricted estimates are kept SEPARATE — never averaged across methods.
"""
from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy.optimize import brentq
from scipy.special import logsumexp


# ---------------------------------------------------------------------------
# BAR estimator (global, both directions)
# ---------------------------------------------------------------------------

def bar_free_energy(
    w_fwd: np.ndarray,
    w_rev: np.ndarray,
    beta: float = 1.0,
    tol: float = 1e-8,
    max_iter: int = 500,
) -> float:
    """Compute ΔF_{H→C} using the Bennett Acceptance Ratio.

    Parameters
    ----------
    w_fwd : (n_f,) reduced work values W^{H→C} (already dimensionless, i.e. β·W)
    w_rev : (n_r,) reduced work values W^{C→H} (already dimensionless)
    beta : inverse temperature (default 1.0; set to 1 if work already in kT)
    tol : convergence tolerance for brentq

    Returns
    -------
    delta_f : float  ΔF = F_C - F_H in the same units as w_fwd/w_rev
    """
    w_fwd = np.asarray(w_fwd, dtype=np.float64)
    w_rev = np.asarray(w_rev, dtype=np.float64)
    n_f = len(w_fwd)
    n_r = len(w_rev)
    if n_f == 0 or n_r == 0:
        return float("nan")

    log_ratio = np.log(n_f / n_r)

    def _bar_objective(delta_f: float) -> float:
        # Forward contribution: Σ_f f(β*w_f - delta_f - log(n_f/n_r))
        lhs = -np.sum(np.logaddexp(0.0, beta * w_fwd - delta_f - log_ratio))
        # Reverse contribution: Σ_r f(-(β*w_r + delta_f - log(n_f/n_r)))
        rhs = -np.sum(np.logaddexp(0.0, beta * w_rev + delta_f - log_ratio))
        return lhs - rhs

    # Bracket search
    df_bracket = _find_bracket(_bar_objective)
    if df_bracket is None:
        # Fallback to Jarzynski if bracketing fails
        return float(logsumexp(-w_fwd) - np.log(n_f))

    delta_f = brentq(_bar_objective, *df_bracket, xtol=tol, maxiter=max_iter)
    return float(delta_f)


def _find_bracket(f, x0: float = 0.0, scale: float = 1.0, max_doublings: int = 60):
    """Find a bracketing interval [a, b] such that f(a)*f(b) < 0."""
    a, b = x0 - scale, x0 + scale
    for _ in range(max_doublings):
        fa, fb = f(a), f(b)
        if fa * fb < 0:
            return (a, b)
        a -= scale
        b += scale
        scale *= 2
    return None


# ---------------------------------------------------------------------------
# BAR free energy — basin-restricted version
# ---------------------------------------------------------------------------

def basin_restricted_bar(
    w_fwd: np.ndarray,
    w_rev: np.ndarray,
    basin_labels_fwd: Sequence[str],
    basin_labels_rev: Sequence[str],
    all_basin_names: list[str] | None = None,
    beta: float = 1.0,
) -> dict[str, float]:
    """Compute basin-restricted BAR ΔF for each basin.

    Each basin B gets its own BAR estimate using only:
      - Forward walkers whose cold endpoint is in basin B
      - Reverse walkers that started in basin B

    Parameters
    ----------
    w_fwd : (n_f,) forward reduced work W^{H→C}
    w_rev : (n_r,) reverse reduced work W^{C→H}
    basin_labels_fwd : (n_f,) basin label per forward walker cold endpoint
    basin_labels_rev : (n_r,) basin label per reverse walker start (= cold start)
    all_basin_names : if given, include all basins even if unvisited
    beta : inverse temperature (default 1 if work already in kT)

    Returns
    -------
    dict basin → ΔF_B (float, in kT); NaN for empty basins.
    """
    labels_f = np.asarray(basin_labels_fwd)
    labels_r = np.asarray(basin_labels_rev)
    basins = sorted(
        set(labels_f) | set(labels_r) | (set(all_basin_names) if all_basin_names else set())
    )

    result: dict[str, float] = {}
    for b in basins:
        wf_b = np.asarray(w_fwd)[labels_f == b]
        wr_b = np.asarray(w_rev)[labels_r == b]
        if len(wf_b) == 0 and len(wr_b) == 0:
            result[str(b)] = float("nan")
        else:
            result[str(b)] = bar_free_energy(wf_b, wr_b, beta=beta)

    return result


# ---------------------------------------------------------------------------
# CFT (Crooks Fluctuation Theorem) estimator — crossing point of work distributions
# ---------------------------------------------------------------------------

def cft_free_energy(
    w_fwd: np.ndarray,
    w_rev: np.ndarray,
    n_bins: int = 50,
) -> float:
    """Estimate ΔF from the crossing point of forward and reverse work histograms.

    ΔF is the work value where P_fwd(W) = P_rev(-W).  Only valid when the
    distributions overlap well; otherwise returns NaN.

    Parameters
    ----------
    w_fwd : (n_f,) forward work values (β*W_k^{H→C})
    w_rev : (n_r,) reverse work values (β*W_k^{C→H})
    n_bins : histogram bin count

    Returns
    -------
    delta_f : float (NaN if distributions don't overlap)
    """
    w_fwd = np.asarray(w_fwd, dtype=np.float64)
    w_rev = np.asarray(w_rev, dtype=np.float64)

    if len(w_fwd) == 0 or len(w_rev) == 0:
        return float("nan")

    w_min = min(w_fwd.min(), -w_rev.max())
    w_max = max(w_fwd.max(), -w_rev.min())
    if not np.isfinite(w_min) or not np.isfinite(w_max) or w_min >= w_max:
        return float("nan")

    bins = np.linspace(w_min, w_max, n_bins + 1)
    centers = 0.5 * (bins[:-1] + bins[1:])

    hist_f, _ = np.histogram(w_fwd, bins=bins, density=True)
    hist_r, _ = np.histogram(-w_rev, bins=bins, density=True)

    # Crossing: find where hist_f - hist_r changes sign
    diff = hist_f - hist_r
    sign_changes = np.where(np.diff(np.sign(diff)))[0]
    if len(sign_changes) == 0:
        return float("nan")

    # Use the first crossing
    idx = sign_changes[0]
    d0, d1 = diff[idx], diff[idx + 1]
    x0, x1 = centers[idx], centers[idx + 1]
    crossing = x0 - d0 * (x1 - x0) / (d1 - d0)
    return float(crossing)
