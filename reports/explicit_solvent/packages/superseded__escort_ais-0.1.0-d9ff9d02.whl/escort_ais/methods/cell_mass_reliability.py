"""Is a partition cell's estimated mass reliably above the mass floor?

This is the replacement for the G_PREP population-ratio rule (rule 4). That rule compared the hot
walker's basin populations in two time windows and required their ratio to lie in ``[0.9, 1.1]``.
It was retired for three independent reasons, any one of which is disqualifying:

* **It cannot detect what it exists to detect.** Its purpose is to catch a partition sitting on a
  drifting or trapped hot ensemble, but it compares two windows of the *same* walker. Internal
  block self-consistency measured 47x more optimistic than an independent-reference comparison --
  a trapped walker is perfectly self-consistent with itself.
* **It watches the wrong ensemble.** The failure that actually corrupted the RGD partition lived in
  the *cold* Hummer-Szabo weights, where one shot carried 74% of a cell's mass and lifted a 0.23%
  region across the 1% floor. A hot-walker diagnostic is blind to that however precise it is.
* **It is unpassable at realistic generation lengths.** A 5 ns window holds 6-40 independent
  observations (basin-indicator tau_int 0.13-0.81 ns), so the ratio of two windows scatters by tens
  of percent against a +-10% band. Measured pass rate: 0/20 on AIS, 1/99 on REMD.

The replacement asks the question the gate actually needs answered -- *is this cell's mass
reliably above ``min_basin_mass``?* -- and reuses the floor that already exists, so it introduces
no second threshold:

    admit cell m   iff   pi_m - z * se(pi_m)  >  min_basin_mass

``pi_m`` is a self-normalised importance-sampling ratio, not a binomial proportion, so its variance
is the clustered delta-method estimator below. Treating the effective sample size as a binomial
``n`` and applying a Wilson interval is *much* too conservative -- it rejects every partition
including the correct one.

**The clustering unit is load-bearing.** For AIS the independent unit is the SHOT: each shot
contributes one row per HS slice (~20), so clustering by row inflates the effective sample size
~20x and admits anything. For an equilibrium reference the unit is a decorrelated block within one
replica. Passing ``cluster_ids`` is therefore mandatory, not optional.

Validated on 32 partition evaluations -- 20 AIS+HS generations and 12 REMD generations spanning
10-495 ns -- where it admitted every correct partition and rejected every artefact, with no
borderline case.

It leaves campaign v5's alanine partition (``min_basin_mass = 0.01``, 2 basins, ``G_PREP = 6``)
unchanged: bounds +0.954 and +0.0124 against the 0.01 floor. The 3-basin partition at alanine's own
``min_basin_mass = 0.001`` is a *borderline* case and the method decides it: the phi>0 psi>0 cell
holds 0.00332 with ``se`` 0.00152, so the normal bound is +0.000831 (``z_crit`` 1.53, just under
1.645) and REJECTS, while the shot-clustered bootstrap 5th percentile is +0.001229 and ADMITS.
Given the measured right-skew of rare cells the bootstrap is the better-calibrated of the two there.

**Where the test is applied matters as much as the test.** Applied to a FINISHED partition it is a
veto, and on a system whose minor states sit near the floor that veto can never be lifted: the tree
splits down TO the floor (``score_boundary`` accepts a cut whose smaller child holds exactly
``min_basin_mass``) while this rule demands the cells sit reliably ABOVE it. Since 2026-08-06
:func:`cut_admissible` is called INSIDE the basin trees, so an unreliable cut is rejected and the
search continues; rule 4 then holds by construction. See
``docs/decisions/2026-08-06_reject-cut-not-partition.md``.

**What it does NOT do.** It certifies the reliability of the cells it is *given*. It cannot see a
state that the mass floor dissolved before the partition was built: a 1% floor on alanine merges
the phi>0 psi split, shifts the surviving substate by 0.24 kT, and passes this rule confidently.
``min_basin_mass`` is a per-system scientific choice and no diagnostic here substitutes for it.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

__all__ = ["cluster_weights", "cell_mass_se", "cell_mass_bootstrap", "cell_shot_support",
           "admit_partition", "cut_admissible", "Z_95_ONE_SIDED"]

# One-sided 95% normal quantile. One-sided is the correct form: the question is "is the mass ABOVE
# the floor", not "is it different from the floor", so 1.645 rather than 1.960. Note this is a
# risk-tolerance choice, not a derived quantity -- and the normal quantile assumes a normality that
# the rare cells do not have (skew +0.7 to +0.9 measured), so `cell_mass_bootstrap` is the better
# calibrated companion. Both are reported; the gate uses whichever the caller selects.
Z_95_ONE_SIDED = 1.6448536269514722


def cluster_weights(weights, cluster_ids, inside):
    """Aggregate row weights to independent units.

    Returns ``(unit_total, unit_inside)``: each unit's total weight and the part of it lying inside
    the cell, in a stable order. Aggregating BEFORE any variance or resampling step is what makes
    the result cluster-correct.
    """
    w = np.asarray(weights, float)
    c = np.asarray(cluster_ids)
    m = np.asarray(inside, bool)
    if not (len(w) == len(c) == len(m)):
        raise ValueError(f"length mismatch: weights {len(w)}, cluster_ids {len(c)}, "
                         f"inside {len(m)}")
    if np.issubdtype(c.dtype, np.integer) and c.size and c.min() >= 0:
        # Fast path for pre-factorised ids. Unused codes appear as zero-weight units, which
        # contribute nothing to any downstream sum (their normalised weight is 0), so this is the
        # same result as np.unique -- but np.unique on 200k string ids, once per candidate cut,
        # dominates the reliability-gated tree search.
        n = int(c.max()) + 1
        return np.bincount(c, weights=w, minlength=n), np.bincount(c, weights=w * m, minlength=n)
    units, inv = np.unique(c, return_inverse=True)
    tot = np.bincount(inv, weights=w, minlength=len(units))
    ins = np.bincount(inv, weights=w * m, minlength=len(units))
    return tot, ins


def cell_mass_se(weights, cluster_ids, inside):
    """``(pi_m, se(pi_m))`` for a self-normalised IS ratio, clustered by unit.

    The delta-method variance of ``pi_m = sum_{i in m} w_i / sum_i w_i`` is

        var = sum_u  wt_u^2 (I_u - pi_m)^2

    with ``wt_u`` unit u's normalised total weight and ``I_u`` its in-cell fraction. This is NOT
    ``pi(1-pi)/n_eff``: pi_m is a ratio of random sums, and the binomial form double-counts by
    adding sampling noise that the weights already carry.
    """
    tot, ins = cluster_weights(weights, cluster_ids, inside)
    s = tot.sum()
    if s <= 0:
        return 0.0, 0.0
    wt = tot / s
    pi = float(ins.sum() / s)
    with np.errstate(invalid="ignore", divide="ignore"):
        frac = np.where(tot > 0, ins / np.where(tot > 0, tot, 1.0), 0.0)
    return pi, float(np.sqrt(np.sum(wt ** 2 * (frac - pi) ** 2)))


def cell_mass_bootstrap(weights, cluster_ids, inside, n_boot: int = 500,
                        percentile: float = 5.0, rng=None):
    """``(pi_m, percentile of the bootstrap distribution)`` resampling UNITS with replacement.

    Preferred over the normal bound when the cell is rare: the sampling distribution of a rare
    cell's mass is right-skewed (bounded below by zero, heavy-tailed weights), so ``pi - z*se``
    carries no confidence level. Measured skew +0.67 to +0.94 on RGD's rare cells; the bootstrap
    5th percentile came out ABOVE the normal bound there, i.e. the normal form was conservative,
    not optimistic.
    """
    rng = np.random.default_rng() if rng is None else rng
    tot, ins = cluster_weights(weights, cluster_ids, inside)
    n = len(tot)
    if n == 0 or tot.sum() <= 0:
        return 0.0, 0.0
    pi = float(ins.sum() / tot.sum())
    idx = rng.integers(0, n, size=(int(n_boot), n))
    denom = tot[idx].sum(axis=1)
    with np.errstate(invalid="ignore", divide="ignore"):
        draws = np.where(denom > 0, ins[idx].sum(axis=1) / np.where(denom > 0, denom, 1.0), 0.0)
    return pi, float(np.percentile(draws, percentile))


def cell_shot_support(weights, cluster_ids, inside):
    """``(n_units, unit_ESS, top1_share)`` for the cell -- reported, not gated on.

    ``top1 <= 0.5`` guarantees only ESS >= 2, so it is the legible summary rather than the
    criterion; ESS is the statistic the standard error is built from.
    """
    tot, ins = cluster_weights(weights, cluster_ids, inside)
    keep = ins > 0
    if not keep.any():
        return 0, 0.0, 1.0
    q = ins[keep] / ins[keep].sum()
    return int(keep.sum()), float(1.0 / np.sum(q ** 2)), float(q.max())


def cut_admissible(weights, cluster_ids, child_masks: Sequence[np.ndarray],
                   min_basin_mass: float, z: float = Z_95_ONE_SIDED,
                   method: str = "normal", n_boot: int = 500,
                   percentile: float = 5.0, rng=None, screen: bool = True,
                   screen_margin: float = 2.0) -> dict:
    """The same criterion applied to a CANDIDATE cut rather than to a finished partition.

    A cut is admissible iff *both* children would be reliably above the floor. This is the form the
    basin trees call during the search, so a cut that would create an unmeasurable cell is rejected
    and the search continues to the next candidate, instead of the whole partition being vetoed
    after the fact.

    The distinction matters because the tree splits down TO the floor while the post-hoc rule asks
    the resulting cells to sit reliably ABOVE it: on a system whose minor states sit near the floor
    those two requirements are contradictory and no partition can ever be admitted. Applying the
    test inside the search makes rule 4 a property of the construction rather than a veto over it.

    Only the requested bound is computed -- the bootstrap is skipped under ``method='normal'`` --
    because this runs once per candidate cut inside the search loop, not once per partition.
    """
    if method not in ("normal", "bootstrap"):
        raise ValueError(f"method must be 'normal' or 'bootstrap', got {method!r}")
    rng = np.random.default_rng() if rng is None else rng
    mass, se, lcb, boot = [], [], [], []
    for inside in child_masks:
        p, s = cell_mass_se(weights, cluster_ids, inside)
        mass.append(p); se.append(s); lcb.append(p - z * s)
        # SCREEN. The bootstrap costs O(n_boot * n_units) and dominates the gate (79% of a
        # generation's check at 9900 shots), but it can only change the verdict near the floor.
        # Outside that band the cheap analytic bound already decides:
        #   pi <= floor                          -> no lower bound can exceed the floor; reject.
        #   pi - z*se > floor + screen_margin*se -> too far above to be flipped; admit.
        # The margin is doing real work. The two bounds are NOT ordered in general: for a rare
        # (right-skewed) cell the bootstrap sits above the normal quantile, but for a well
        # populated one it can sit slightly below -- measured 0.2853 vs 0.2862 at pi = 0.30, a
        # discrepancy of ~0.11 se. `screen_margin = 2` therefore covers it with an order of
        # magnitude to spare, and an unmargined screen would have been wrong.
        need = (method == "bootstrap" and screen
                and p > min_basin_mass
                and p - z * s <= min_basin_mass + screen_margin * s)
        boot.append(cell_mass_bootstrap(weights, cluster_ids, inside, n_boot, percentile, rng)[1]
                    if (method == "bootstrap" and (need or not screen)) else float("nan"))
        if method == "bootstrap" and screen and not need:
            boot[-1] = lcb[-1]      # decided by the analytic bound; record what actually gated
    bound = np.asarray(lcb if method == "normal" else boot, float)
    return dict(admissible=bool(len(child_masks) > 0 and np.all(bound > min_basin_mass)),
                method=method, z=float(z), min_basin_mass=float(min_basin_mass),
                mass=[float(v) for v in mass], se=[float(v) for v in se],
                lcb_normal=[float(v) for v in lcb], boot_percentile=[float(v) for v in boot],
                bound=[float(v) for v in bound],
                per_child_admitted=[bool(v > min_basin_mass) for v in bound])


def admit_partition(weights, cluster_ids, inside_masks: Sequence[np.ndarray],
                    min_basin_mass: float, z: float = Z_95_ONE_SIDED,
                    method: str = "normal", n_boot: int = 500,
                    percentile: float = 5.0, rng=None) -> dict:
    """G_PREP rule 4: every cell's lower confidence bound must exceed ``min_basin_mass``.

    ``method='normal'`` uses ``pi - z*se``; ``method='bootstrap'`` uses the ``percentile``-th
    bootstrap percentile. Both are computed and returned regardless, so a trace records the
    evidence for either and the choice can be revisited without re-running anything.

    ``z_crit = (pi - floor)/se`` is reported per cell: it is threshold-free and carries the whole
    margin, so a reader can apply their own tolerance after the fact.
    """
    if method not in ("normal", "bootstrap"):
        raise ValueError(f"method must be 'normal' or 'bootstrap', got {method!r}")
    rng = np.random.default_rng() if rng is None else rng
    mass, se, lcb, boot, zc, ess, top1, nu = [], [], [], [], [], [], [], []
    for inside in inside_masks:
        p, s = cell_mass_se(weights, cluster_ids, inside)
        _, b = cell_mass_bootstrap(weights, cluster_ids, inside, n_boot, percentile, rng)
        n, e, t = cell_shot_support(weights, cluster_ids, inside)
        mass.append(p); se.append(s); lcb.append(p - z * s); boot.append(b)
        zc.append((p - min_basin_mass) / s if s > 0 else np.inf)
        ess.append(e); top1.append(t); nu.append(n)
    bound = np.asarray(lcb if method == "normal" else boot, float)
    return dict(admitted=bool(len(inside_masks) > 0 and np.all(bound > min_basin_mass)),
                method=method, z=float(z), min_basin_mass=float(min_basin_mass),
                mass=[float(v) for v in mass], se=[float(v) for v in se],
                lcb_normal=[float(v) for v in lcb], boot_percentile=[float(v) for v in boot],
                z_crit=[float(v) for v in zc], unit_ess=[float(v) for v in ess],
                top1_share=[float(v) for v in top1], n_units=[int(v) for v in nu],
                per_cell_admitted=[bool(v > min_basin_mass) for v in bound])
