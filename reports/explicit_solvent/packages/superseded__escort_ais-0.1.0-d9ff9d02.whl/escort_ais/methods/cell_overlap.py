"""Bhattacharyya overlap between two flat-bottom-confined cell ensembles.

This is the decisive test for whether a partition boundary is real. Two cells that are genuinely
separate basins produce confined ensembles that barely overlap; a boundary cut through the middle of
one basin produces two ensembles that overlap strongly across the shared wall.

The estimator is free of the partition functions. With

    p_m(x) = pi(x) e^{-U_m(x)} / Z_m ,      Omega = \\int sqrt(p_m p_n) dx ,

writing the ratio in terms of the bias difference dU = U_n - U_m gives

    Omega = sqrt( Z_m/Z_n ) E_{p_m}[ e^{-dU/2} ]   and   Omega = sqrt( Z_n/Z_m ) E_{p_n}[ e^{+dU/2} ]

so the unknown Z's cancel in the product:

    **Omega = sqrt( E_{p_m}[e^{-dU/2}] * E_{p_n}[e^{+dU/2}] )**

Both expectations are taken over the WALKER frames of the respective confined walkers -- not over
landings, which carry a different (unconfined) distribution. Every frame contributes: the biases
U_m and U_n are defined everywhere, and it is precisely the wall-region frames that carry the
overlap signal, so they must not be filtered out the way reverse-leg SEEDS are.

Interpretation, per ``docs/protocols/conditional_bar_conventions.md`` and the merge/discard rules:

* ``Omega > 0.2`` between wall-sharing siblings -> MERGE; their union is rectangular and therefore
  expressible by the flat-bottom wall, which is why only siblings are candidates.
* ``Omega ~ 0`` -> the boundary separates genuinely distinct basins; retain.
* Never merge on small mass alone: a real rare state also has small mass.

Requires the verdict to be reproduced across two ``G_update`` before acting (see
:func:`merge_verdict`), or the partition oscillates between merged and split.
"""
from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np

from escort_ais.methods.nd_flatbottom import nd_bias_kT

MERGE_OVERLAP_THRESHOLD = 0.2


def bhattacharyya_overlap(angles_m, cell_m, angles_n, cell_n, k_wall: float = 100.0) -> float:
    """``Omega`` in [0, 1] between the two confined ensembles, from their own walker frames.

    :param angles_m: (n_frames, n_cv) RADIANS, frames of the walker confined to ``cell_m``.
    :param angles_n: likewise for ``cell_n``.

    Returns 0.0 if either walker contributed no frames. The two exponential means are evaluated in
    log space; ``dU`` routinely reaches tens of kT in the far wall region, and the naive product of
    two exponentials underflows to 0.0 there and silently reports "no overlap".
    """
    a_m = np.atleast_2d(np.asarray(angles_m, float))
    a_n = np.atleast_2d(np.asarray(angles_n, float))
    if len(a_m) == 0 or len(a_n) == 0:
        return 0.0

    # dU = U_n - U_m, evaluated on each walker's own frames
    d_m = nd_bias_kT(a_m, cell_n, k_wall) - nd_bias_kT(a_m, cell_m, k_wall)
    d_n = nd_bias_kT(a_n, cell_n, k_wall) - nd_bias_kT(a_n, cell_m, k_wall)

    log_e_m = _logmeanexp(-0.5 * d_m)          # E_{p_m}[e^{-dU/2}]
    log_e_n = _logmeanexp(+0.5 * d_n)          # E_{p_n}[e^{+dU/2}]
    return float(np.exp(0.5 * (log_e_m + log_e_n)))


def _logmeanexp(x) -> float:
    x = np.asarray(x, float)
    m = np.max(x)
    if not np.isfinite(m):
        return -np.inf
    return float(m + np.log(np.mean(np.exp(x - m))))


def wall_sharing_pairs(cells: Sequence) -> list[tuple[int, int, int]]:
    """``(i, j, dim)`` for cell pairs that differ in exactly ONE dimension and abut in it.

    That is the structural signature of tree siblings, and the reason only siblings are merge
    candidates: only their union is rectangular, hence expressible by ``nd_flatbottom``. A pair
    differing in two or more dimensions has an L-shaped union and must never be merged, however
    large its overlap.
    """
    out = []
    for i in range(len(cells)):
        for j in range(i + 1, len(cells)):
            ci, cj = cells[i], cells[j]
            dims = sorted(set(ci.active_dims()) | set(cj.active_dims()))
            differing = [d for d in dims if not _same_arc(ci.arcs[d], cj.arcs[d])]
            if len(differing) != 1:
                continue
            d = differing[0]
            if _abuts(ci.arcs[d], cj.arcs[d]):
                out.append((i, j, d))
    return out


def _same_arc(a, b, tol: float = 1e-9) -> bool:
    if getattr(a, "full", False) and getattr(b, "full", False):
        return True
    if getattr(a, "full", False) != getattr(b, "full", False):
        return False
    return abs(_wrap(a.lo - b.lo)) < tol and abs(_wrap(a.hi - b.hi)) < tol


def _abuts(a, b, tol: float = 1e-6) -> bool:
    """True if the two arcs share an endpoint, i.e. sit either side of one wall."""
    if getattr(a, "full", False) or getattr(b, "full", False):
        return False
    return (abs(_wrap(a.hi - b.lo)) < tol) or (abs(_wrap(b.hi - a.lo)) < tol)


def _wrap(x):
    return (np.asarray(x, float) + np.pi) % (2 * np.pi) - np.pi


def merge_verdict(overlaps: Iterable[float], threshold: float = MERGE_OVERLAP_THRESHOLD,
                  n_required: int = 2) -> str:
    """``"merge"`` only if the LAST ``n_required`` generations all exceed ``threshold``.

    Requiring consecutive confirmations is what stops a partition oscillating: a single generation
    above threshold may be a walker excursion, and merging then re-splitting on the next update
    never converges.
    """
    o = [float(x) for x in overlaps]
    if len(o) < n_required:
        return "insufficient"
    return "merge" if all(x > threshold for x in o[-n_required:]) else "retain"
