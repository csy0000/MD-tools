#!/usr/bin/env python3
"""run_bais_standalone.py — STANDALONE generational BAIS on real MD (no REMD anywhere in the protocol).

The fixed-parameter BAIS estimator, run as a self-contained sampler that acquires cold-state thermodynamics
(faster than REMD) *and* kinetics, using none of REMD's information:

  Phase A (per generation, lockstep hot=cold):
    * consume one T_walker-length window of a pre-existing s=s_hot hot ensemble (pretend live hot walker);
    * forward AIS (square-spaced schedule, 1 perturb + 1 propagate per window) hot->cold -> reduced works W_f
      and cold LANDING coordinates;
    * detect basins from the exp(logw)-WEIGHTED (cold-representative) landing cloud (KMeans+BIC modes) and
      SEED ONE continuous cold (s=1.0) walker the first time a basin is discovered (geometric merge_radius
      dedup on the seed positions -> seed-once-per-basin). Every seeded walker then runs to the END of the
      protocol -- NO trajectory merge or split. Walkers grow across gens and may reach different lengths.
      (The BAR-slow / MSM-fast BASIN merge is a Phase-B analysis decision — PCCA+ lumps fast-interconverting
      microstates into one kinetic basin — not a run-time walker operation.)

  Phase B (once, on the full pooled data):
    * KMeans microclustering -> PCCA+ metastable macrostates = the BASINS (never REMD, never a hand PMF);
    * assign every forward landing to its basin; count-matched reverse AIS (N_rev,b = N_fwd,b) from the cold
      reservoir of each basin cold->hot -> reduced works W_r;
    * endpoint-restricted BAR over (W_f, land_basin, W_r, start_basin) -> per-basin dF and populations pi;
    * fixed-pi reversible MSM on the cold macro-dtrajs -> transition matrix, slow ITS, and the full MFPT matrix
      -> a basin tree (nodes = basins sized by pi, edges = MFPT). Alanine also gets a phi/psi basin map.

REMD is used nowhere to define basins, seed walkers, count-match, or score; it is compared only afterwards.

Systems (config below):
  alanine : ff19sb_gbn2 implicit; phi/psi; s_hot=0.25; T_AIS=2 ps (t_ais=1000, freq=1); N_AIS=25; T_walker=200 ps.
  rgd     : macrocycle gbn2;      torsion quartets; s_hot=0.25; T_AIS=5 ps (t_ais=2500, freq=1); N_AIS=100; 20 ns.

    conda activate escort-ais
    python -m escort_ais.methods.run_bais_standalone --system alanine --n-gen 500 --platform CUDA
    python -m escort_ais.methods.run_bais_standalone --system alanine --smoke   # 2 gens, tiny
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
import warnings
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

warnings.filterwarnings("ignore")
import numpy as np
import mdtraj as md

from escort_ais.common.paths import project_root
from escort_ais.methods.ais_linear import LinearAISConfig, run_linear_scaling_ais
from escort_ais.methods.ais_prep import hot_ais_step, run_hot_prep   # shared hot forward-AIS PREP (both methods)
try:  # BAIS (MSM/kinetics) + BasinManager are ARCHIVED — only the deprecated --method seed|we paths used them;
    from escort_ais.methods.bais import basin_free_energies, estimate_bais, slow_timescale  # noqa: F401
    from escort_ais.methods.bais_basins import BasinManager  # noqa: F401
except ImportError:  # BAUS (--method us|coverage) needs none of these; keep the module importable without BAIS.
    basin_free_energies = estimate_bais = slow_timescale = BasinManager = None

ROOT = project_root()

# ── system registry ──────────────────────────────────────────────────────────
def _macrocycle_entry(slug: str, hot_dir: str) -> dict:
    """Build a BAIS SYSTEMS entry for an RGD-family macrocycle (sage/GBn2 implicit) by reading its per-system
    topology from disk, so all three (rgd, cilengitide, rgd_redPheVal) share ONE config path. `hot_dir` is the
    s=0.25 single-walker hot-ensemble dir under data/<slug>/ (holds trajectory.dcd + start_structure_minimized.pdb).
    omega-exclude bonds and n_solute_atoms come from the topology dir; the shared MD/AIS params are the macrocycle
    class defaults (5 ps AIS switch, 10 ns/gen cold walkers, 15 gens)."""
    topo = ROOT / f"data/{slug}/topology"
    hot = ROOT / f"data/{slug}/{hot_dir}"
    omega = np.load(topo / "omega_exclude_bonds.npy").tolist()          # per-system ω (secondary-amide) bonds
    n_solute = int(json.loads((topo / "config.json").read_text())["n_solute_atoms"])
    return dict(
        topology_dir=topo,
        prmtop=topo / "system_scale_1p0.prmtop",
        inpcrd=topo / "system_scale_1p0.inpcrd",
        pdb=hot / "start_structure_minimized.pdb",
        hot_dcd=hot / "trajectory.dcd",
        s_hot=0.25, t_ais=2500, freq_ais=1, n_ais=100,   # 5 ps AIS switch (t_ais*freq_ais steps), 100 shots/gen
        walker_ps=10000.0, n_gen=15,                     # 10 ns/gen cold-walker extension, 15 generations
        cold_save_ps=20.0, max_walkers=24, n_micro=200, n_macro=6,   # Phase-B: 200 TICA microstates, >=6 basins
        hot_ps_per_frame=10.0, omega_exclude=omega,
        feature="torsions", solvent="implicit",
        gb_radii="mbondi3",       # GBn2 on the macrocycle needs mbondi3 radii (matches reference/REMD Hamiltonian)
        n_solute_atoms=n_solute,  # all atoms are solute (implicit) — the AIS CustomGB scaler needs this hint
        # BAIS-WE overrides (applied only under --we; seed-once BAIS keeps the defaults above).
        # n_gen is DERIVED to match REMD's TOTAL investment: cold = (N_rep-1)*T_rep spread over N_walker^WE=we_M*n_macro
        # walkers => n_gen = (N_rep-1)*T_rep / (T_walker * we_M * n_macro).  RGD: N_rep=6, T_rep=500 ns.
        we=dict(walker_ps=500.0, cold_save_ps=10.0, remd_n_rep=6, remd_t_rep_ns=500.0,   # T_walker=0.5 ns
                we_M=4, we_tau=50.0, we_c_min=5, we_barrier_boost=2, we_max_contexts=48, we_burn_gens=1),
    )


SYSTEMS = {
    "alanine": dict(
        topology_dir=ROOT / "data/topology/ff19sb_gbn2",
        prmtop=ROOT / "data/topology/ff19sb_gbn2/system.prmtop",
        inpcrd=ROOT / "data/topology/ff19sb_gbn2/system_scale_1p0.inpcrd",
        pdb=ROOT / "data/topology/ff19sb_gbn2/_sequence.pdb",
        hot_dcd=ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-50ns/trajectory.dcd",   # corrected s=0.25 hot (25000 frames)
        s_hot=0.25, t_ais=1000, freq_ais=1, n_ais=25, walker_ps=200.0, n_gen=100,   # 100 gens x 200ps = 20ns hot (matches 20ns REMD)
        cold_save_ps=1.0, max_walkers=12, n_micro=150, n_macro=4,
        hot_ps_per_frame=2.0, omega_exclude=None, feature="phipsi", solvent="implicit",
        gb_radii="mbondi3",   # enforced (2026-07-31); was None -> legacy AmberPrmtopFile GB branch
        # BAIS-WE overrides (applied only under --we): mbondi3 Hamiltonian + matched mbondi3 hot ensemble.
        # Steering bins = 8 sticky add-only MICROSTATES, n_we=5 walkers each (N_cold=40); macrostates are lumped
        # from the microstates ONLY for BAR/US basins + the BAR weight anchor; the count matrix stays on the 8
        # microstates. n_gen is DERIVED from the 500 ns REMD cold budget (see _derive_n_gen_we).
        we=dict(gb_radii="mbondi3",
                hot_dcd=ROOT / "data/alanine_dipeptide/2026-07-17-hot-s0p25-mbondi3-100ns/trajectory.dcd",
                walker_ps=100.0, cold_save_ps=1.0,               # T_walker=100 ps
                we_M=5, we_n_micro=8, we_tau=10.0, we_c_min=5, we_barrier_boost=2,
                we_max_contexts=40, we_burn_gens=1, remd_n_rep=6, remd_t_rep_ns=100.0),
    ),
    # RGD-family macrocycles — all use the 800 ns s=0.25 single-walker hot ensemble
    "rgd": _macrocycle_entry("rgd", "2026-07-02-ref-sw-hot-s0p25-800ns-startmajor-seed20260701"),
    "cilengitide": _macrocycle_entry("cilengitide", "2026-07-06-sw-hot-s0p25-800ns"),
    "rgd_redPheVal": _macrocycle_entry("rgd_redPheVal", "2026-07-06-sw-hot-s0p25-800ns"),
}


# ── featurization -> (cos,sin) ───────────────────────────────────────────────
def featurize(traj: md.Trajectory, cfg: dict):
    """Return (features (n,2d), angles_deg (n,d)). Alanine: (phi,psi). RGD: the cached backbone torsion
    quartets (mdtraj phi/psi fails on the cyclic sage/openff peptide), incl. omega cis/trans."""
    if cfg["feature"] == "phipsi":
        phi = md.compute_phi(traj)[1][:, 0]; psi = md.compute_psi(traj)[1][:, 0]
        ang = np.stack([phi, psi], axis=1)
    else:                                                       # rgd: dihedrals from the backbone quartets
        ang = md.compute_dihedrals(traj, cfg["_quartets"])
    feat = np.concatenate([np.cos(ang), np.sin(ang)], axis=1)
    return feat, np.degrees(ang)


# ── AIS seed-dir + legs ──────────────────────────────────────────────────────
def _seed_config(cfg: dict) -> dict:
    """The config.json the AIS reads to rebuild the Hamiltonian. GBn2 + mbondi3 is now enforced by
    ais_linear even when the key is absent, but it is written out ALWAYS so the run records which
    Hamiltonian branch it actually used (the earlier configs are silent on this, which is what made
    the 2026-07-31 audit need direct energy comparison to settle)."""
    c = {"prmtop_path": str(cfg["prmtop"]), "inpcrd_path": str(cfg["inpcrd"])}
    if cfg.get("solvent", "implicit") == "implicit":
        from escort_ais.systems.openmm_system import DEFAULT_GB_RADII
        c["gb_radii"] = cfg.get("gb_radii") or DEFAULT_GB_RADII; c["gb_model"] = "GBn2"
    if cfg.get("n_solute_atoms"):
        c["n_solute_atoms"] = int(cfg["n_solute_atoms"])
    return c


def _make_seed_dir(work: Path, cfg: dict, window: md.Trajectory) -> Path:
    """Build the input_scaled_dir the AIS reads: config.json(prmtop) + start_structure.pdb + trajectory.dcd."""
    work.mkdir(parents=True, exist_ok=True)
    (work / "config.json").write_text(json.dumps(_seed_config(cfg)))
    if not (work / "start_structure.pdb").exists():
        shutil.copy(cfg["pdb"], work / "start_structure.pdb")
    window.save_dcd(str(work / "trajectory.dcd"))
    return work


def _ais_cfg(seed_dir, out, cfg, k, s_hot, s_cold, platform, seed, device):
    """Build the exact LinearAISConfig BAIS uses for one (sub-)leg, pinned to `device` (None = default GPU)."""
    omega = np.asarray(cfg["omega_exclude"], int) if cfg["omega_exclude"] else None
    return LinearAISConfig(
        solvent=cfg["solvent"], k_ais=k, t_ais=cfg["t_ais"], freq_ais=cfg["freq_ais"],
        s_hot=s_hot, s_cold=s_cold, scaling_mode="square", seed=seed,
        start_frame_offset=0, start_frame_stride=1,
        input_scaled_dir=seed_dir, output_dir=out,
        platform=platform, device_index=(str(device) if device is not None else None),
        overwrite=True, save_traj_every_switch=False, omega_exclude_bonds=omega,
        neq_integrator=bool(cfg.get("neq_integrator", False)),
        # WALL-STRATIFIED co-switch, forwarded only when the caller asks for it. Absent keys leave
        # the defaults, so every existing caller builds a byte-identical config.
        wall_quartets=cfg.get("wall_quartets"), wall_cell=cfg.get("wall_cell"),
        wall_k_hot=float(cfg.get("wall_k_hot", 0.0)),
        wall_k_cold=float(cfg.get("wall_k_cold", 100.0)),
        wall_kT_kj=float(cfg.get("wall_kT_kj", 1.0)))


def _read_leg(out: Path, seed_dir: Path):
    import pandas as pd
    logw = pd.read_csv(out / "ais_trajectory_summary.csv")["final_logw"].to_numpy(float)
    land = md.load_dcd(str(out / "ais_final_coordinates.dcd"), top=str(seed_dir / "start_structure.pdb"))
    return -logw, land                                          # reduced work W = -logw


def _ais_leg(seed_dir: Path, out: Path, cfg: dict, k: int, s_hot: float, s_cold: float,
             platform: str, seed: int, devices=None):
    """Run one AIS leg (square schedule, freq=1). Returns (reduced_work W (k,), final_coords_traj).
    devices: list of GPU indices to shard the k shots across (in-process thread-split, EXACT same
    LinearAISConfig per shard, only device_index + a per-shard seed differ). None/single -> one leg,
    default device. Shots are iid draws from the window, so a per-shard seed split is statistically
    equivalent to one k-shot leg (not bit-identical)."""
    devs = [None] if not devices else list(devices)
    if len(devs) == 1:
        run_linear_scaling_ais(_ais_cfg(seed_dir, out, cfg, k, s_hot, s_cold, platform, seed, devs[0]))
        return _read_leg(out, seed_dir)
    ndev = len(devs)                                            # split k across devices; drop empty shards
    ks = [k // ndev + (1 if i < k % ndev else 0) for i in range(ndev)]
    def _run(i):
        if ks[i] == 0:
            return None
        od = out / f"shard{i}"
        run_linear_scaling_ais(_ais_cfg(seed_dir, od, cfg, ks[i], s_hot, s_cold, platform,
                                        seed + 1000 * (i + 1), devs[i]))
        return _read_leg(od, seed_dir)
    with ThreadPoolExecutor(max_workers=ndev) as pool:          # OpenMM releases the GIL in step()
        parts = [r for r in pool.map(_run, range(ndev)) if r is not None]
    W = np.concatenate([p[0] for p in parts])
    land = md.join([p[1] for p in parts])
    return W, land


# ── continuous cold (s=1.0) walker ───────────────────────────────────────────
def _build_cold_system(cfg):
    """Base physical (s=1.0) GBn2 system, on the SAME builder branch as the AIS legs.

    Delegates to :func:`escort_ais.systems.openmm_system.build_implicit_system` so the cold walker
    and the AIS endpoints cannot drift onto different builders — they did exactly that before
    2026-07-31, whenever a config omitted ``gb_radii``.
    """
    import parmed as pmd  # noqa: PLC0415

    from escort_ais.systems.openmm_system import (  # noqa: PLC0415
        DEFAULT_GB_RADII, build_implicit_system)

    st = pmd.load_file(str(cfg["prmtop"]), xyz=str(cfg["inpcrd"]))   # .topology, like AmberPrmtopFile
    system = build_implicit_system(cfg["prmtop"], gb_radii=cfg.get("gb_radii") or DEFAULT_GB_RADII,
                                   inpcrd_path=cfg["inpcrd"])
    return st, system


class ColdWalker:
    """One continuous cold Langevin walker: seeded from a landing structure, extended T_walker each generation.
    Frames are streamed to a per-walker DCD (appended across generations), so the reservoir grows on disk."""

    def __init__(self, wid, prmtop, system, seed_xyz_nm, dcd_path, platform, device, seed,
                 save_ps, dt_fs=2.0, temp=300.0):
        from openmm import LangevinMiddleIntegrator, Platform, app, unit
        plat = Platform.getPlatformByName(platform)
        props = {}
        if platform == "CUDA":
            props = {"Precision": "mixed", "DeviceIndex": str(device)}
        elif platform == "OpenCL":
            props = {"Precision": "mixed", "OpenCLDeviceIndex": str(device)}
        integ = LangevinMiddleIntegrator(temp * unit.kelvin, 1.0 / unit.picosecond, dt_fs * unit.femtoseconds)
        self.sim = app.Simulation(prmtop.topology, system, integ, plat, props)
        self.sim.context.setPositions(np.asarray(seed_xyz_nm) * unit.nanometer)
        self.sim.minimizeEnergy(maxIterations=200)
        self.sim.context.setVelocitiesToTemperature(temp * unit.kelvin, int(seed))
        self.save_every = max(1, int(round(save_ps * 1000 / dt_fs)))
        self.dt_fs = dt_fs
        self.wid = int(wid)
        self.dcd_path = Path(dcd_path)
        self.sim.reporters.append(app.DCDReporter(str(self.dcd_path), self.save_every))
        self.total_ps = 0.0

    def extend(self, ps):
        n_steps = int(round(ps * 1000 / self.dt_fs))
        self.sim.step(n_steps)
        self.total_ps += ps


# ── multi-D TICA -> KMeans -> MSM -> PCCA+ basins + MFPT (Phase B definitive analysis) ────────
class _TicaKm:
    """Wrapper so `.transform(raw_cos_sin_feats)` = KMeans-in-TICA-subspace microstate id: projects the raw
    (cos,sin) features onto the TICA slow subspace, then assigns the microstate. Preserves the km interface
    that `phase_b` relies on (`km.transform(cold_feat)` / `km.transform(land_feat)`)."""
    def __init__(self, tica, km):
        self.tica, self.km = tica, km

    def transform(self, x):
        return np.asarray(self.km.transform(np.asarray(self.tica.transform(np.asarray(x, float)), float)), int)


def cluster_pcca(cold_feat_list, land_feat, kind, n_micro=150, n_macro=4, lag=1, tica_lag=10, n_tica=6, alpha_gap=10.0):
    """Multi-D TICA -> KMeans microstates IN THE TICA SUBSPACE -> reversible MSM -> spectral-gap n_c (floored at
    n_macro) -> PCCA+ macrostates = the basins. TICA isolates the slow subspace first, so a modest microstate set
    resolves the metastable structure of a MANY-torsion macrocycle (a raw high-D KMeans starves microstates and,
    like a 1-D TICA, collapses near-orthogonal slow coordinates). n_c is read from the implied-timescale spectral
    gap but never below n_macro, so the reported granularity matches the reference. Returns
    (km_wrap, macro_of_micro, msm, mfpt, macro_of_land); km_wrap.transform projects via TICA then assigns."""
    from deeptime.clustering import KMeans
    from deeptime.markov import TransitionCountEstimator
    from deeptime.markov.msm import MaximumLikelihoodMSM
    from deeptime.decomposition import TICA
    from escort_ais.methods.kcc_split import spectral_gap_nc
    pool = np.concatenate(cold_feat_list, axis=0) if cold_feat_list else land_feat
    n_micro = int(min(n_micro, max(2, pool.shape[0] // 20)))
    n_tica = int(max(1, min(int(n_tica), pool.shape[1] - 1)))
    # multi-D TICA on within-walker lagged pairs (each cold_feat is one continuous cold walker)
    tl = int(max(1, tica_lag))
    xt = np.concatenate([f[:-tl] for f in cold_feat_list if len(f) > tl], axis=0)
    xl = np.concatenate([f[tl:] for f in cold_feat_list if len(f) > tl], axis=0)
    tica = TICA(dim=n_tica).fit((xt, xl)).fetch_model()
    proj_list = [np.asarray(tica.transform(f), float) for f in cold_feat_list]
    km = KMeans(n_clusters=n_micro, max_iter=300, fixed_seed=13, progress=None).fit_fetch(np.concatenate(proj_list, axis=0))
    cold_dtrajs = [np.asarray(km.transform(p), int) for p in proj_list]
    counts = TransitionCountEstimator(lagtime=lag, count_mode="sliding").fit_fetch(cold_dtrajs).submodel_largest()
    msm = MaximumLikelihoodMSM(reversible=True).fit_fetch(counts)
    nc_gap, _gaps = spectral_gap_nc(msm.timescales(), lag, alpha_gap=alpha_gap)   # auto n_c from the spectrum
    nmac = int(min(max(nc_gap, n_macro), msm.n_states))                           # ...never below the n_macro floor
    macro_of_micro = np.full(n_micro, -1, int)
    mfpt = None
    if nmac >= 2:
        pcca = msm.pcca(nmac)
        macro_of_micro[counts.state_symbols] = pcca.assignments
        nonempty = [len(pcca.sets[i]) > 0 for i in range(nmac)]   # PCCA+ can leave a macrostate unpopulated
        mfpt = np.zeros((nmac, nmac))
        for i in range(nmac):
            for j in range(nmac):
                if i != j:
                    mfpt[i, j] = (msm.mfpt(pcca.sets[i], pcca.sets[j])
                                  if (nonempty[i] and nonempty[j]) else np.inf)   # empty set -> unreachable
    else:                                                          # degenerate reservoir: <2 metastable states
        macro_of_micro[counts.state_symbols] = 0                   # -> single basin, so BAR/MFPT run (don't crash)
    km_wrap = _TicaKm(tica, km)
    macro_of_land = macro_of_micro[km_wrap.transform(land_feat)]
    return km_wrap, macro_of_micro, msm, mfpt, macro_of_land


def _macro_count_matrix(km, macro_of_micro, cold_feat_list, nb, lag=1):
    """Cold macro-state (basin) lag-tau count matrix, from the pooled cold walker dtrajs mapped micro->macro."""
    C = np.zeros((nb, nb))
    for f in cold_feat_list:
        mic = km.transform(f)
        mac = macro_of_micro[mic]
        keep = mac >= 0
        mac = mac[keep]
        if len(mac) > lag:
            np.add.at(C, (mac[:-lag], mac[lag:]), 1.0)
    return C


def _mfpt_from_T(T, lag):
    """Full MFPT matrix (in frames) from a transition matrix T: m_ij = expected steps to first reach j from i."""
    n = T.shape[0]
    M = np.zeros((n, n))
    for j in range(n):
        # solve (I - T_{-j}) t = 1  on states != j
        idx = [i for i in range(n) if i != j]
        A = np.eye(len(idx)) - T[np.ix_(idx, idx)]
        try:
            t = np.linalg.solve(A, np.ones(len(idx)))
        except np.linalg.LinAlgError:
            t = np.full(len(idx), np.nan)
        for k, i in enumerate(idx):
            M[i, j] = t[k] * lag
    return M


def _seed_walker(cold, cfg, out, platform, devices, xyz):
    """Spawn a fresh continuous cold walker at `xyz` on a round-robin GPU. Returns the walker."""
    wid = cold["next_wid"]; cold["next_wid"] += 1
    dcd = out / f"cold/walker_{wid:03d}.dcd"; dcd.parent.mkdir(parents=True, exist_ok=True)
    dev = devices[wid % len(devices)]
    w = ColdWalker(wid, cold["prmtop"], cold["system"], xyz, dcd, platform, dev,
                   seed=2000 + wid, save_ps=cfg["cold_save_ps"])
    cold["walkers"].append(w)
    return w, wid, dev


# ── one generation (Phase A) ─────────────────────────────────────────────────
def run_generation(g, cfg, out, hot, cold, platform, devices, pool, hot_draw, n_gen, mgr, rng):
    """BAIS generation: forward AIS on this gen's hot window; detect basins from the exp(logw)-WEIGHTED
    GMM+BIC landing modes (BasinManager.seed_targets) and SEED ONE cold walker per basin not yet covered by
    an existing walker's seed (geometric merge_radius dedup -> seed-once-per-basin); then extend EVERY walker
    to the end of the protocol. No trajectory merge or split. Mutates `cold`. Returns (Wf, land_feat, land_ang, land)."""
    if hot_draw == "chunk":                                         # per-gen sequential chunk (real-case emulation)
        chunk = max(cfg["n_ais"], hot.n_frames // max(1, n_gen))
        lo = min(g * chunk, max(0, hot.n_frames - chunk))
        window = hot[lo:lo + chunk]
    else:                                                           # deterministic sliding window (default)
        fpf = int(round(cfg["walker_ps"] / cfg["hot_ps_per_frame"]))
        span = max(cfg["n_ais"], fpf)
        lo = (g * fpf) % max(1, hot.n_frames - span)
        window = hot[lo:lo + span]
    ais_devices = devices if len(devices) > 1 else None
    seed_dir = _make_seed_dir(out / f"gen{g:04d}/seed_hot", cfg, window)
    Wf, land = _ais_leg(seed_dir, out / f"gen{g:04d}/fwd", cfg, cfg["n_ais"], cfg["s_hot"], 1.0,
                        platform, seed=1000 + g, devices=ais_devices)
    land_feat, land_ang = featurize(land, cfg)

    # WEIGHTED seeding: exp(logw)-weighted (cold-representative) GMM+BIC modes -> seed ONCE per basin.
    # Coverage is a geometric merge_radius dedup on the SEED positions (no cold-reservoir recount, no
    # walker merge): seed a discovered basin only if no existing walker already seeds within merge_radius.
    r2 = mgr.merge_radius ** 2
    empty = np.zeros((0, land_feat.shape[1]), float)                # empty -> seed_targets returns ALL weighted modes
    for near, _is_new, W_c in mgr.seed_targets(land_feat, -Wf, empty, rng):   # logw = -reduced work W
        if len(cold["walkers"]) >= cfg["max_walkers"]:
            break
        sf = land_feat[int(near)]
        if cold["seed_feat"] and min(((sf - s) ** 2).sum() for s in cold["seed_feat"]) <= r2:
            continue                                                # a walker already seeds this basin -> seed-once
        _, wid, dev = _seed_walker(cold, cfg, out, platform, devices, land.xyz[int(near)])
        cold["seed_feat"].append(sf)
        print(f"    gen {g}: seeded cold walker {wid} (W_c={W_c:.2f}) GPU {dev}", file=sys.stderr)

    walkers = cold["walkers"]                                    # extend every walker by one T_walker (run-to-end)
    if pool is not None and len(walkers) > 1:                    # concurrent stepping across GPUs (GIL released)
        list(pool.map(lambda w: w.extend(cfg["walker_ps"]), walkers))
    else:
        for w in walkers:
            w.extend(cfg["walker_ps"])
    return Wf, land_feat, land_ang, land


# ── Phase B: definitive basins, reverse AIS, BAR pi, MFPT, figures ────────────
def phase_b(cfg, out, cold, Wf_all, land_feat_all, land_ang_all, land_xyz_all, platform, devices):
    top = cfg["pdb"]
    all_w = cold["walkers"]                                     # every seeded walker (all run to the end)
    trajs = []
    for w in all_w:
        if not Path(w.dcd_path).exists():
            continue
        t = md.load_dcd(str(w.dcd_path), top=str(top))
        if t.n_frames > 0:
            trajs.append(t)
    cold_feat_list, cold_ang_list = [], []
    for t in trajs:
        f, a = featurize(t, cfg)
        cold_feat_list.append(f); cold_ang_list.append(a)
    if not cold_feat_list:
        raise RuntimeError("no cold-walker frames — Phase A produced no cold reservoir")

    land_feat = np.concatenate(land_feat_all, axis=0)
    land_ang = np.concatenate(land_ang_all, axis=0)
    Wf = np.concatenate(Wf_all, axis=0)
    land_xyz = np.concatenate(land_xyz_all, axis=0)

    km, macro_micro, msm, mfpt_free, land_basin = cluster_pcca(
        cold_feat_list, land_feat, cfg["feature"],
        n_micro=cfg["n_micro"], n_macro=cfg["n_macro"], lag=1)
    nb = int(macro_micro.max() + 1)
    print(f"[bais] PCCA+ basins: {nb}; forward landings assigned: "
          f"{np.bincount(land_basin[land_basin >= 0], minlength=nb).tolist()}", file=sys.stderr)

    # ── count-matched reverse AIS: N_rev,b = N_fwd,b from the cold reservoir of basin b ──
    cold_feat = np.concatenate(cold_feat_list, axis=0)
    cold_ang = np.concatenate(cold_ang_list, axis=0)
    cold_basin = macro_micro[km.transform(cold_feat)]
    # pooled cold coordinates for reverse-AIS seeding (reuse the trajs already loaded above, same order)
    cold_xyz = np.concatenate([t.xyz for t in trajs], axis=0)

    Wr_all, rev_start_all = [], []
    ref_top = md.load(str(top))
    n_fwd_b = np.bincount(land_basin[land_basin >= 0], minlength=nb)
    for b in range(nb):
        k = int(n_fwd_b[b])
        pool = np.where(cold_basin == b)[0]
        if k == 0 or len(pool) == 0:
            continue
        # basin-b cold frames as the reverse-AIS start ensemble
        seed_dir = out / f"reverse/basin_{b:02d}/seed_cold"
        seed_dir.mkdir(parents=True, exist_ok=True)
        (seed_dir / "config.json").write_text(json.dumps(_seed_config(cfg)))
        shutil.copy(top, seed_dir / "start_structure.pdb")
        md.Trajectory(cold_xyz[pool], ref_top.topology).save_dcd(str(seed_dir / "trajectory.dcd"))
        Wr, _ = _ais_leg(seed_dir, out / f"reverse/basin_{b:02d}/rev", cfg, k,
                         1.0, cfg["s_hot"], platform, seed=5000 + b,   # cold(s=1)->hot(s=s_hot)
                         devices=(devices if len(devices) > 1 else None))
        Wr_all.append(Wr); rev_start_all.append(np.full(k, b, int))
        print(f"    reverse basin {b}: {k} shots, mean W_r={np.mean(Wr):.2f} kT", file=sys.stderr)

    Wr = np.concatenate(Wr_all) if Wr_all else np.array([])
    rev_start = np.concatenate(rev_start_all) if rev_start_all else np.array([], int)

    # ── endpoint-restricted BAR populations ──
    keep = land_basin >= 0
    bar = basin_free_energies(Wf[keep], land_basin[keep], Wr, rev_start, nb)
    pi = bar["pi"]
    print(f"[bais] BAR populations pi = {np.round(pi, 3).tolist()}", file=sys.stderr)

    # ── fixed-pi reversible MSM kinetics on cold macro-dtrajs -> MFPT ──
    C = _macro_count_matrix(km, macro_micro, cold_feat_list, nb, lag=1)
    kin = estimate_bais(C, np.nan_to_num(pi, nan=0.0) if np.isfinite(pi).any() else None, lag=1)
    mfpt_fixedpi = _mfpt_from_T(kin["T"], lag=1) if kin.get("T") is not None else None

    # ── basin geometry (angle centroids) for the tree/map ──
    basin_ang = np.array([
        np.degrees(np.arctan2(np.sin(np.radians(cold_ang[cold_basin == b])).mean(0),
                              np.cos(np.radians(cold_ang[cold_basin == b])).mean(0)))
        if np.any(cold_basin == b) else np.full(cold_ang.shape[1], np.nan)
        for b in range(nb)])

    results = dict(
        system=cfg.get("_slug", "?"), n_basins=int(nb),
        pi=np.asarray(pi, float).tolist(), dF=np.asarray(bar["dF"], float).tolist(),
        n_fwd_per_basin=n_fwd_b.tolist(),
        cold_frames_per_basin=[int(np.sum(cold_basin == b)) for b in range(nb)],
        its_fixedpi=float(kin.get("its", np.nan)),
        mfpt_fixedpi=(None if mfpt_fixedpi is None else np.asarray(mfpt_fixedpi, float).tolist()),
        mfpt_free=(None if mfpt_free is None else np.asarray(mfpt_free, float).tolist()),
        basin_ang_deg=basin_ang.tolist(),
        cold_save_ps=cfg["cold_save_ps"],
    )
    (out / "bais_results.json").write_text(json.dumps(results, indent=1))
    print(f"[bais] wrote {out / 'bais_results.json'}", file=sys.stderr)

    _figs(cfg, out, results, cold_ang, cold_basin, land_ang, land_basin, nb)
    return results


def _figs(cfg, out, res, cold_ang, cold_basin, land_ang, land_basin, nb):
    """Basin tree (nodes = basins sized by pi, edges labelled with MFPT) + phi/psi basin map (alanine)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    pi = np.array(res["pi"], float)
    mfpt = np.array(res["mfpt_fixedpi"], float) if res["mfpt_fixedpi"] else \
        (np.array(res["mfpt_free"], float) if res["mfpt_free"] else None)
    basin_ang = np.array(res["basin_ang_deg"], float)

    try:
        # node layout: alanine -> (phi,psi) centroid; rgd -> circular
        if cfg["feature"] == "phipsi":
            pos = basin_ang[:, :2]
        else:
            th = np.linspace(0, 2 * np.pi, nb, endpoint=False)
            pos = np.stack([np.cos(th), np.sin(th)], axis=1) * 100.0
        fig, ax = plt.subplots(figsize=(7, 6))
        finite = np.isfinite(pi)
        smax = np.nanmax(pi[finite]) if finite.any() else 1.0
        for i in range(nb):
            for j in range(nb):
                if i < j and mfpt is not None and np.isfinite(mfpt[i, j]):
                    ax.annotate("", xy=pos[j], xytext=pos[i],
                                arrowprops=dict(arrowstyle="-", color="0.7", lw=1))
                    mid = 0.5 * (pos[i] + pos[j])
                    tij = f"{mfpt[i, j]:.0f}/{mfpt[j, i]:.0f}"
                    ax.text(mid[0], mid[1], tij, fontsize=7, color="0.4", ha="center")
        for i in range(nb):
            s = 300 + 3000 * (pi[i] / smax if np.isfinite(pi[i]) else 0.0)
            ax.scatter(*pos[i], s=s, c=[plt.cm.tab10(i)], edgecolors="k", zorder=3)
            lbl = f"b{i}\nπ={pi[i]:.2f}" if np.isfinite(pi[i]) else f"b{i}\nπ=NaN"
            ax.text(pos[i, 0], pos[i, 1], lbl, ha="center", va="center", fontsize=8, zorder=4)
        ax.set_title(f"BAIS basin tree ({res['system']}): nodes ∝ π, edges = MFPT (frames, i/j)")
        if cfg["feature"] == "phipsi":
            ax.set_xlabel("φ (deg)"); ax.set_ylabel("ψ (deg)")
            ax.set_xlim(-180, 180); ax.set_ylim(-180, 180)
        else:
            ax.set_xticks([]); ax.set_yticks([])
        fig.tight_layout(); fig.savefig(out / "bais_basin_tree.png", dpi=150); plt.close(fig)

        if cfg["feature"] == "phipsi":                          # Ramachandran basin map
            fig, ax = plt.subplots(figsize=(6.5, 6))
            keep = cold_basin >= 0
            ax.scatter(cold_ang[keep, 0], cold_ang[keep, 1], s=2, c=cold_basin[keep],
                       cmap="tab10", alpha=0.35, vmin=0, vmax=max(9, nb - 1))
            lk = land_basin >= 0
            ax.scatter(land_ang[lk, 0], land_ang[lk, 1], s=14, c=land_basin[lk],
                       cmap="tab10", edgecolors="k", linewidths=0.3, vmin=0, vmax=max(9, nb - 1))
            for i in range(nb):
                if np.isfinite(basin_ang[i, 0]):
                    ax.text(basin_ang[i, 0], basin_ang[i, 1], f"b{i}\nπ={pi[i]:.2f}",
                            ha="center", va="center", fontsize=9,
                            bbox=dict(boxstyle="round", fc="white", alpha=0.8))
            ax.set_xlabel("φ (deg)"); ax.set_ylabel("ψ (deg)")
            ax.set_xlim(-180, 180); ax.set_ylim(-180, 180)
            ax.set_title("BAIS basins on the Ramachandran map (cold reservoir + forward landings)")
            fig.tight_layout(); fig.savefig(out / "bais_phipsi_basins.png", dpi=150); plt.close(fig)
        print(f"[bais] wrote figures to {out}", file=sys.stderr)
    except Exception as e:
        print(f"  [figs] skipped: {e}", file=sys.stderr)


# ══════════════════════════════════════════════════════════════════════════════════════════════
# BAIS-WE: a BAR-anchored weighted-ensemble cold reservoir (docs/theory/BAIS-WE_theory.pdf)
# Swaps the seed-once cold manager for a WEReservoir; the hot ensemble, forward/reverse AIS, and the
# hot-unified BAR populations are UNCHANGED. Enabled by --we; the default (seed-once) path is untouched.
# ══════════════════════════════════════════════════════════════════════════════════════════════
def _apply_we_overrides(cfg: dict) -> dict:
    """Fold the per-system `we=dict(...)` registry knobs into cfg (mbondi3 Hamiltonian + matched hot ensemble,
    T_walker, cold_save_ps, and the we_* WE knobs). Called only under --we."""
    we = dict(cfg.get("we") or {})
    cfg.update(we)                                                 # gb_radii/hot_dcd/walker_ps/... override
    cfg.setdefault("we_M", 5)                    # n_we: WE walkers per PERMANENT microstate (gen ≥2)
    cfg.setdefault("we_n_micro", 8)              # n_microstate: FROZEN PCCA+ state count (target of the gen-1 lump)
    cfg.setdefault("we_k_temp", 2 * cfg["we_n_micro"])   # gen-1 temporary KMeans state count (PCCA+ lumps these)
    cfg.setdefault("we_tau", 10.0); cfg.setdefault("we_c_min", 5)
    cfg.setdefault("we_barrier_boost", 2); cfg.setdefault("we_burn_gens", 1)
    cfg.setdefault("we_max_contexts", cfg["we_M"] * cfg["we_n_micro"])   # = n_we·n_microstate
    cfg.setdefault("we_tile_cutoff", 0.35)      # WExplore barrier-tile spawn radius in (cos,sin) feature space
    cfg.setdefault("remd_n_rep", 6); cfg.setdefault("remd_t_rep_ns", 100.0)
    return cfg


def _t_ais_ps(cfg: dict) -> float:
    """One AIS switch length in ps: t_ais integration steps × the AIS dt (2 fs). alanine: 1000×2fs = 2 ps."""
    return cfg["t_ais"] * 0.002


def _derive_n_gen_we(cfg: dict, n_cold: int) -> int:
    """Cold-budget termination (coordinator formula). Match REMD's cold investment (N_rep−1)·T_rep to the per-gen
    force-eval cost N_cold·T_walker + 2·N_AIS·T_AIS:
        n_gen = round( (N_rep−1)·T_rep / (N_cold·T_walker + 2·N_AIS·T_AIS) ),   clamped to a sane minimum.
    BAIS-WE: N_cold = n_we·n_microstate (=40 for alanine ⇒ ~122 gens). BAIS-US: N_cold = #PCCA macrostate basins."""
    cold_ns = (cfg["remd_n_rep"] - 1) * cfg["remd_t_rep_ns"]
    per_gen_ns = (n_cold * cfg["walker_ps"] + 2 * cfg["n_ais"] * _t_ais_ps(cfg)) / 1000.0
    return int(max(10, round(cold_ns / max(per_gen_ns, 1e-9))))


def _lump_micro_macro(Cw, n_macro_floor, rng, alpha=10.0):
    """PCCA/LEQ macrostate lump of the (weighted) MICROSTATE count matrix (the toy `leq_macrostates` rule): micro
    reversible-MLE MSM → implied timescales → spectral-gap n_c (floored at n_macro_floor) → lump by KMeans on the
    leading (n_c−1) slow right eigenvectors. Returns (macro_of_micro (K,), n_macro). BAR basins + US umbrellas ride
    this coarse lump; the count matrix stays on the fine microstates (the decouple rule)."""
    from escort_ais.methods.fixed_pi_msm import implied_timescales, reversible_mle
    from escort_ais.methods.kcc_split import spectral_gap_nc
    K = int(Cw.shape[0])
    if K <= 1 or Cw.sum() <= 0:
        return np.zeros(max(K, 1), int), 1
    T, _ = reversible_mle(Cw + 1e-9)
    its = implied_timescales(T, lag=1)
    n_c, _ = spectral_gap_nc(its, 1, alpha_gap=alpha, n_cap=min(6, K))
    n_c = int(min(max(n_c, n_macro_floor), K))
    lam, V = np.linalg.eig(T)
    ev = np.real(V[:, np.argsort(np.abs(lam))[::-1][1:n_c]])              # (K, n_c-1) slow eigenvectors
    if ev.shape[1] == 0:
        return np.zeros(K, int), 1
    if n_c == 2:
        macro = (ev[:, 0] >= np.median(ev[:, 0])).astype(int)
    else:
        from sklearn.cluster import KMeans
        macro = KMeans(n_clusters=n_c, n_init=5,
                       random_state=int(rng.integers(1, 2**31 - 1))).fit_predict(ev)
    return macro.astype(int), int(n_c)


# ── microstate lifecycle: gen-1 temporary KMeans states → PERMANENT PCCA+ states (frozen forever, no eviction) ──
def _micro_of_feat(we, feat):
    """Current microstate id of each feature row. GEN 1 (provisional): nearest temporary-KMeans centre. GEN ≥2
    (frozen): the PCCA+ lump of the nearest FROZEN KMeans centre — one fixed discretisation, never re-discretised."""
    tid = _nearest_centre(feat, we["km_centres"])
    return we["pcca_map"][tid] if we.get("pcca_map") is not None else tid


def _fold_counts(C, amap, n):
    """Fold a k×k temporary count matrix into an n×n permanent one via amap (temp→permanent, PCCA+ assignment)."""
    F = np.zeros((n, n))
    ii, jj = np.meshgrid(amap, amap, indexing="ij")
    np.add.at(F, (ii.ravel(), jj.ravel()), C.ravel())
    return F


def _freeze_pcca_micro(we, cfg, rng):
    """After gen 1: PCCA+ (target n_microstate) on the gen-1 temporary count matrix defines the PERMANENT
    microstates (frozen forever). Folds every Cw_lag[L] onto the permanent states, sets the permanent centres
    (mean temp-centre per PCCA+ set), and reports a bootstrap state-stability diagnostic (adjusted-Rand under a
    Poisson resample of the gen-1 counts — a proxy for whether a 2nd bootstrap generation would change the states;
    the freeze-after-gen-1 rule stands regardless)."""
    from escort_ais.methods.fixed_pi_msm import reversible_mle
    C = we["Cw_lag"][1]; k_temp = C.shape[0]
    n_target = int(min(cfg["we_n_micro"], k_temp))
    amap = _pcca_assign(C, n_target, rng)
    n_micro = int(amap.max() + 1)
    for L in list(we["Cw_lag"]):
        we["Cw_lag"][L] = _fold_counts(we["Cw_lag"][L], amap, n_micro)
    km = we["km_centres"]
    we["micro_centres"] = np.array([km[amap == s].mean(0) if np.any(amap == s) else km[0]
                                    for s in range(n_micro)])
    we["pcca_map"] = amap; we["frozen_micro"] = True; we["n_micro"] = n_micro
    # state-stability: Poisson-bootstrap the gen-1 counts, re-PCCA, adjusted-Rand vs the frozen assignment
    try:
        from sklearn.metrics import adjusted_rand_score
        ars = []
        for _ in range(10):
            Cb = rng.poisson(np.maximum(C, 0.0))
            if Cb.sum() <= 0:
                continue
            ars.append(adjusted_rand_score(amap, _pcca_assign(Cb.astype(float), n_target, rng)))
        we["pcca_stability_ars"] = float(np.mean(ars)) if ars else None
    except Exception:
        we["pcca_stability_ars"] = None
    print(f"    [we] FROZEN PCCA+ microstates: {k_temp} temp KMeans → {n_micro} permanent states "
          f"(stability ARS={we['pcca_stability_ars']})", file=sys.stderr)


def _pcca_assign(C, n_target, rng):
    """PCCA+ crisp assignment (temp state → 0..n_target−1) from a weighted count matrix, via deeptime on the
    reversible-MLE transition matrix; falls back to the spectral `_lump_micro_macro` lump if deeptime PCCA fails."""
    from escort_ais.methods.fixed_pi_msm import reversible_mle
    if C.shape[0] <= n_target:
        return np.arange(C.shape[0], dtype=int)
    T, _ = reversible_mle(C + 1e-9)
    try:
        from deeptime.markov.msm import MarkovStateModel
        return np.asarray(MarkovStateModel(T).pcca(n_target).assignments, int)
    except Exception:
        macro, _ = _lump_micro_macro(C, n_target, rng)
        return macro


def _gmm_basins(feat, w, rng, kmax=8, seed=0):
    """CONFIDENT population BASINS = a torus-native product-von-Mises mixture on the WEIGHTED converged landings
    (manifold-aware replacement for the Euclidean GMM), K* selected by BIC-ARGMIN (data-driven N_umbrella = K*,
    NOT a preset or the PCCA count; argmin — not the knee — resolves rare states). Features are the (cos,sin)
    layout [cos_1..cos_D, sin_1..sin_D]; we recover the D torsion angles, fit a weighted product-vM (weights =
    AIS importance weights), and return the (cos,sin) means. Returns (means (K*, 2D), K*)."""
    from escort_ais.systems.vonmises_mixture import fit_vmm_bic, cossin_to_angles, angles_to_cossin
    feat = np.asarray(feat, float); w = np.asarray(w, float)
    n = len(feat)
    if n < 6:
        return (feat.mean(0, keepdims=True) if n else np.zeros((1, feat.shape[1]))), 1
    m = min(n, 2000)
    idx = rng.choice(n, size=m, p=w / w.sum())                          # weighted resample of the landings
    theta = cossin_to_angles(feat[idx])                                 # (m, D) rad
    kmax = int(min(kmax, m // 10 + 1))
    fit = fit_vmm_bic(theta, kmax, seed=seed)                           # unweighted (already resampled ∝ w)
    return angles_to_cossin(fit["mu"]), int(fit["Kstar"])


def _gmm_cov_for_centres(land_feat, w_land, centres, rng, kmax=8, seed=0):
    """Re-fit the product-von-Mises mixture (K* by BIC-ARGMIN) on the weighted converged landings and return, for
    each committed BASIN centre, the (cos,sin) covariance of its NEAREST component. Factored from `_gmm_basins`
    (same weighted-resample + BIC selection). The per-component covariance is a DIAGONAL (cos,sin) matrix whose
    trace equals the validated chord width^2 = Σ_d 2(1 − I1/I0(κ_d)) — exactly what the BAIS-US harmonic spring
    rule reads (w_i = √trace Σ_i). Returns (covs (nb, 2D, 2D), kstar)."""
    from escort_ais.systems.vonmises_mixture import fit_vmm_bic, cossin_to_angles, angles_to_cossin, \
        kappa_to_cossin_diag_cov
    feat = np.asarray(land_feat, float); w = np.asarray(w_land, float); C = np.asarray(centres, float)
    dim = feat.shape[1]
    n = len(feat)
    if n < 6:
        return np.tile(np.eye(dim) * 1e-2, (len(C), 1, 1)), 1
    m = min(n, 2000)
    idx = rng.choice(n, size=m, p=w / w.sum())
    theta = cossin_to_angles(feat[idx])                                 # (m, D) rad
    kmax = int(min(kmax, m // 10 + 1))
    fit = fit_vmm_bic(theta, kmax, seed=seed)
    means = angles_to_cossin(fit["mu"])                                 # (K*, 2D)
    comp_covs = kappa_to_cossin_diag_cov(fit["kappa"])                  # (K*, 2D, 2D); trace = chord width^2
    # map each committed basin centre to its nearest component, take that component's covariance
    comp_of_basin = _nearest_centre(C, means)
    return comp_covs[comp_of_basin], int(fit["Kstar"])


def _basins_from_gmm_lump(micro_centres, land_feat, w_land, kmax, rng):
    """BASINS as a GMM lump of the FROZEN microstates (coordinator: data-driven K*, coverage-guaranteed). Fit
    GMM(K* by BIC, K*≤kmax=n_microstate) on the weighted converged landings; assign each microstate to its nearest
    GMM component; keep only components that catch ≥1 microstate (relabelled 0..nb−1). Returns (basin_means,
    micro2basin, K*_bic). Every basin then owns ≥1 microstate ⇒ every basin has walkers ⇒ no NaN π^BAR."""
    means, kstar = _gmm_basins(land_feat, w_land, rng, kmax=int(kmax))
    raw = _nearest_centre(micro_centres, means)                          # microstate → GMM component
    occ = np.unique(raw)
    relabel = {int(c): i for i, c in enumerate(occ)}
    basins = means[occ]
    micro2basin = np.array([relabel[int(c)] for c in raw], int)
    return basins, micro2basin, int(kstar)


def _merge_kinetic_basins(basins, micro_centres, Cw, rng, min_flux=100.0):
    """§7 metastability guard: if the weighted MICROSTATE MSM says two GMM basins are kinetically ONE metastable
    region, merge them BEFORE placing umbrella walls (don't let a wall sit mid-basin). Fold the micro count matrix
    to the basin level (micro→nearest basin), lump by metastability (`_lump_micro_macro`), and merge basins that
    share a metastable set. Only fires when the basin-level flux is well resolved (Σ weighted counts ≥ min_flux;
    weighted counts sum to ~1 per WE round, so this waits ~min_flux rounds); else keeps K* (GMM by BIC)."""
    basins = np.asarray(basins, float); K = len(basins)
    if K <= 1 or Cw.sum() < min_flux:
        return basins, K, _nearest_centre(micro_centres, basins)
    m2b = _nearest_centre(micro_centres, basins)
    Cb = np.zeros((K, K))
    for i in range(Cw.shape[0]):
        for j in range(Cw.shape[0]):
            Cb[m2b[i], m2b[j]] += Cw[i, j]
    meta, n_meta = _lump_micro_macro(Cb, 1, rng)
    if n_meta >= K:
        return basins, K, m2b
    merged = np.array([basins[np.where(meta == s)[0]].mean(0) for s in range(n_meta)
                       if np.any(meta == s)])
    return merged, len(merged), _nearest_centre(micro_centres, merged)


def _weighted_kmeans_feat(X, w, k, seed=0):
    """Weighted KMeans on (cos,sin) features → (k,2d) centres (sticky-centre seed for gen 0)."""
    from sklearn.cluster import KMeans
    X = np.asarray(X, float); w = np.asarray(w, float)
    k = int(min(k, len(X)))
    km = KMeans(n_clusters=max(1, k), n_init=5, random_state=int(seed)).fit(X, sample_weight=w)
    return np.asarray(km.cluster_centers_, float)


def _nearest_centre(feat, centres):
    """Nearest sticky-centre id for each feature row (the WE steering bin = committed basin)."""
    feat = np.atleast_2d(np.asarray(feat, float)); C = np.asarray(centres, float)
    return np.argmin(((feat[:, None, :] - C[None, :, :]) ** 2).sum(-1), axis=1).astype(int)


def _weighted_emd(Xa, wa, Xb, wb, cap=120, rng=None):
    """Exact weighted 2-Wasserstein distance W2 (squared-Euclidean ground cost, in feature/chord units), for the
    AIS-landing convergence gate (BAIS-US_theory §3, eq. w2). POT `ot.emd2` if importable, else an exact
    scipy-linprog transport LP; both subsample to `cap` points/side (drawn ∝ weight) for tractability."""
    rng = rng or np.random.default_rng(0)
    Xa = np.asarray(Xa, float); Xb = np.asarray(Xb, float)
    wa = np.asarray(wa, float); wb = np.asarray(wb, float)
    if len(Xa) == 0 or len(Xb) == 0:
        return np.nan
    wa = wa / wa.sum(); wb = wb / wb.sum()
    if len(Xa) > cap:
        ia = rng.choice(len(Xa), size=cap, p=wa); Xa, wa = Xa[ia], np.full(cap, 1.0 / cap)
    if len(Xb) > cap:
        ib = rng.choice(len(Xb), size=cap, p=wb); Xb, wb = Xb[ib], np.full(cap, 1.0 / cap)
    M = ((Xa[:, None, :] - Xb[None, :, :]) ** 2).sum(-1)
    try:
        import ot
        cost = float(ot.emd2(wa, wb, M, numItermax=200_000))
    except Exception:                                             # exact LP fallback (POT not installed)
        from scipy.optimize import linprog
        na, nb = len(wa), len(wb)
        A_eq, b_eq = [], []
        for i in range(na):                                       # row marginals Σ_j γ_ij = wa_i
            r = np.zeros(na * nb); r[i * nb:(i + 1) * nb] = 1.0; A_eq.append(r); b_eq.append(wa[i])
        for j in range(nb):                                       # col marginals Σ_i γ_ij = wb_j
            r = np.zeros(na * nb); r[j::nb] = 1.0; A_eq.append(r); b_eq.append(wb[j])
        res = linprog(M.ravel(), A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=(0, None), method="highs")
        cost = float(res.fun) if res.success else np.nan
    return float(np.sqrt(max(0.0, cost))) if np.isfinite(cost) else np.nan


def _we_self_floor(X, w, rng):
    """Self-W2 floor: W2 between two random halves of the SAME weighted landing sample (BAIS-US §3). Convergence
    is declared against this floor, not zero, since W2 between two finite samples of one law is O(N^{-1/2d})>0."""
    n = len(X)
    if n < 6:
        return np.nan
    idx = rng.permutation(n); h = n // 2
    return _weighted_emd(X[idx[:h]], w[idx[:h]], X[idx[h:]], w[idx[h:]], rng=rng)


def _we_assign(reservoir, cfg, ref_top, we):
    """Batch-featurise every active WE walker's current positions and assign it to its MICROSTATE steering bin
    (gen-1 temporary KMeans, or the frozen PCCA+ state from gen 2 on — `_micro_of_feat`). Sets w.bin_id."""
    if not reservoir.active:
        return np.zeros(0, int), np.zeros((0, 2 * (1 if cfg["feature"] == "phipsi" else 0)), float)
    xyz = np.array([w.positions_nm() for w in reservoir.active], float)    # (n, natoms, 3)
    traj = md.Trajectory(xyz, ref_top.topology)
    feat, _ = featurize(traj, cfg)
    bins = _micro_of_feat(we, feat)
    for w, b in zip(reservoir.active, bins):
        w.bin_id = int(b)
    return bins, feat


def _grow(C, nb):
    """Grow a square count matrix to nb×nb, preserving existing counts (sticky states)."""
    if C.shape[0] >= nb:
        return C
    Cn = np.zeros((nb, nb)); Cn[:C.shape[0], :C.shape[0]] = C
    return Cn


# ── ADAPTIVE BARRIER TILING: WExplore-style add-only bins for the WE steering + kinetics count matrix ──
# DECOUPLED from the frozen well-states/GMM basins (those stay the thermo/BAR layer). A walker on the φ/ψ
# transition region — farther than we_tile_cutoff from every existing tile centre — spawns a NEW tile there, so
# the barrier itself becomes a set of steering bins; splitting into those tiles is what manufactures inter-basin
# flux the well-only count matrix never sees. Add-only, never removed; the count matrix appends rows/cols; bins
# are paired at OBSERVATION time (no re-binning of past transitions).
def _assign_tiles(we, feat, cutoff, create=True):
    """WExplore add-only tile id for each feature row; spawns a new tile (barrier tile) whenever a walker is >
    cutoff from every existing tile centre. Grows we['tile_centres'] and every we['Cw_tile'][L] accordingly."""
    feat = np.atleast_2d(np.asarray(feat, float))
    ids = np.empty(len(feat), int)
    for i, f in enumerate(feat):
        C = we["tile_centres"]
        if C is None or len(C) == 0:
            if not create:
                ids[i] = -1; continue
            we["tile_centres"] = f[None, :].copy(); ids[i] = 0
        else:
            d2 = ((f - C) ** 2).sum(1); m = int(d2.argmin())
            if np.sqrt(d2[m]) > cutoff and create:                        # transition-region walker → new tile
                we["tile_centres"] = np.vstack([C, f]); ids[i] = len(we["tile_centres"]) - 1
            else:
                ids[i] = m
        for L in we["Cw_tile"]:
            we["Cw_tile"][L] = _grow(we["Cw_tile"][L], len(we["tile_centres"]))
    return ids


def _we_assign_tiles(reservoir, cfg, ref_top, we, cutoff):
    """Assign every active walker to its adaptive TILE (creating barrier tiles), set w.bin_id=tile, return
    (tile_ids, feats)."""
    if not reservoir.active:
        return np.zeros(0, int), np.zeros((0, 2), float)
    xyz = np.array([w.positions_nm() for w in reservoir.active], float)
    feat, _ = featurize(md.Trajectory(xyz, ref_top.topology), cfg)
    tiles = _assign_tiles(we, feat, cutoff, create=True)
    for w, t in zip(reservoir.active, tiles):
        w.bin_id = int(t)
    return tiles, feat


def _basin_of_tile(we):
    """Map each adaptive tile → its thermo basin (nearest GMM basin centre). Used to derive π_tile from π^BAR and
    to count the manufactured inter-basin crossings in the barrier-tiled count matrix."""
    if we["tile_centres"] is None or we.get("basins") is None:
        return np.zeros(0, int)
    return _nearest_centre(we["tile_centres"], we["basins"])


def _we_targets_fixed_pool(bins_now, Cw, n_pool, c_min, boost):
    """FIXED-total-walker-pool split/merge target with FRONTIER-CONCENTRATED barrier boosting (the toy-validated
    scheme, replacing per-bin `barrier_targets` which let Σ M_i exceed the context pool and starved tiles). The
    `n_pool` walkers are distributed over the CURRENTLY-OCCUPIED bins by INVERSE-VISITATION weighting: every
    occupied bin gets the minimum (1), then the remaining pool is poured into the under-visited FRONTIER (barrier)
    tiles ∝ 1/(visits+1), each capped at c_min·boost. Well-sampled states keep the minimum. Σ M_i ≤ n_pool, so the
    reservoir never needs more than `n_pool` contexts (no acquire starvation) and no global lowest-weight merge is
    used (merge stays LOCAL/per-bin in the reservoir). Returns {bin_id: M_i} (+ default key −1)."""
    bins_now = np.asarray(bins_now, int)
    occ = np.unique(bins_now[bins_now >= 0])
    n = len(occ)
    if n == 0:
        return {-1: 1}
    n_pool = int(max(n_pool, n))                                          # at least 1 per occupied bin
    visits = (Cw.sum(0) + Cw.sum(1)) if Cw.size else np.zeros(int(occ.max()) + 1)
    v = np.array([visits[b] if b < len(visits) else 0.0 for b in occ], float)
    invvis = 1.0 / (v + 1.0)                                              # frontier (low-visitation) weighted up
    cap = int(max(1, c_min * boost))
    M = np.ones(n, int)                                                   # base minimum: well-states
    remaining = n_pool - n
    while remaining > 0:
        avail = M < cap
        if not avail.any():
            break
        for idx in np.argsort(-(invvis * avail)):                        # frontier-first, one walker at a time
            if remaining <= 0:
                break
            if M[idx] < cap:
                M[idx] += 1; remaining -= 1
    out = {int(b): int(m) for b, m in zip(occ, M)}
    out[-1] = 1
    return out


def _anchor_by_basin(we, cfg, pi_basin):
    """Re-anchor the weighted ensemble on the THERMO basins (eq. anchor at basin resolution): assign each walker to
    its nearest GMM basin, set bin_id=basin, rescale each basin's total weight to π^BAR. (Steering/counts happen on
    the decoupled tile layer; the weight normalisation happens on the basins.)"""
    res = we["reservoir"]
    if not res.active:
        return
    xyz = np.array([w.positions_nm() for w in res.active], float)
    feat, _ = featurize(md.Trajectory(xyz, we["ref_top"].topology), cfg)
    wb = _nearest_centre(feat, we["basins"])
    for w, b in zip(res.active, wb):
        w.bin_id = int(b)
    res.anchor(np.asarray(pi_basin, float))


def run_generation_we(g, cfg, out, hot, we, platform, devices, pool, rng, hot_draw, n_gen):
    """One BAIS-WE generation (BAIS-WE_theory §algo). Forward AIS (unchanged) → sticky-centre discovery + BAR-weight
    seed of new basins → reverse AIS + BAR anchor → WE inner loop (bin → run τ → weighted counts → split/merge to a
    barrier-enhanced M_i) → re-anchor. Mutates `we` (the WE state dict). Returns a per-gen log record."""
    ref_top = we["ref_top"]
    we_M, we_tau, c_min, boost = cfg["we_M"], cfg["we_tau"], cfg["we_c_min"], cfg["we_barrier_boost"]

    # ── GEN-0 HOT BURN-IN: the first hot chunk is discarded ENTIRELY (coordinator spec). Its frames never enter
    #    the hot ensemble, its AIS landings never enter the graph, and its work never enters BAR — the shared hot
    #    front-end (ensemble + landings + graph + BAR ΔF) is built starting at gen 1. ──
    if g == 0:
        print("  [we] gen 0 [hot_burnin]: first hot chunk discarded (front-end starts at gen 1)", file=sys.stderr)
        return dict(gen=0, phase="hot_burnin", n_basins=0, n_active=0, n_fwd=0, n_rev=0,
                    fwd_counts=[], rev_counts=[], g_freeze=None, hot_frozen=False, pi_bar=[])

    # ── 1. hot window + forward AIS (BAIS unchanged). GROWING phase (g ≤ g_freeze): consume a fresh hot chunk.
    #        FROZEN phase (g > g_freeze): the hot ensemble no longer advances — draw N_AIS *fresh* AIS switches by
    #        RESAMPLING the frozen hot frames (seed=1000+g differs each gen ⇒ fresh stochastic forward works, not
    #        duplicates), sized to match the per-gen reverse count. Forward count = N_AIS in BOTH phases. ──
    # ── 1-2. hot window + forward AIS + AIS-landing W2 gate + freeze-hot — now the SHARED hot leg (ais_prep), used
    #        identically by BAUS. Mutates the WE state (Wf_all/land_*_all/prev_land/w2_streak/hot_frozen/…). ──
    Wf, land, land_feat, land_ang, w_land, emd, self_floor, converged = hot_ais_step(
        g, cfg, hot, we, out, platform, devices, rng)
    dF_now = float(np.nanmean(np.abs(we.get("pi_bar", np.array([np.nan]))))) if we.get("pi_bar") is not None else np.nan

    # ── 3. STEERING MICROSTATES (kinetics/count-matrix resolution only; decouple rule). GEN 1: TEMPORARY KMeans
    #        states on the exp(logw)-weighted landings (AIS weights = initial π). GEN ≥2: the FROZEN PCCA+ states
    #        defined once from the gen-1 count matrix — never re-discretised. ──
    if we.get("frozen_micro"):
        micro = we["micro_centres"]; n_micro = len(micro)
    else:                                                             # gen 1: provisional KMeans microstates
        k_temp = int(min(cfg.get("we_k_temp", 2 * cfg["we_n_micro"]), max(cfg["we_n_micro"] + 1, len(land_feat))))
        we["km_centres"] = _weighted_kmeans_feat(land_feat, w_land, k_temp, seed=0)
        we["pcca_map"] = None
        micro = we["km_centres"]; n_micro = len(micro)
    for L in we["Cw_lag"]:
        we["Cw_lag"][L] = _grow(we["Cw_lag"][L], n_micro)

    # ── 3b. BASINS = GMM(K* by BIC) on the CONVERGED FROZEN landings, fit ONCE at hot-freeze and FROZEN thereafter
    #        (data-driven, for BAR + US). Defined as a LUMP of the frozen microstates (each microstate → its nearest
    #        GMM component; only components that catch ≥1 microstate survive) ⇒ every basin has microstates AND
    #        walkers ⇒ no NaN π^BAR. A §7 metastability guard further merges basins the weighted MSM says are one
    #        kinetic region. BEFORE hot-freeze: provisional per-microstate basins (identity). ──
    land_feat_pool = np.concatenate(we["land_feat_all"], axis=0)
    Wf_pool = np.concatenate(we["Wf_all"])
    w_land_pool = np.exp(-Wf_pool - (-Wf_pool).max())
    if we.get("basins_frozen"):
        basins = we["basins"]; micro2basin = we["micro2basin"]; nb = len(basins); Kstar = we["Kstar"]
    elif we["hot_frozen"] and we.get("frozen_micro"):                    # converged: fit + freeze the GMM basins
        basins, micro2basin, Kstar = _basins_from_gmm_lump(micro, land_feat_pool, w_land_pool, cfg["we_n_micro"], rng)
        basins, nb, micro2basin = _merge_kinetic_basins(basins, micro, we["Cw_lag"][1], rng)
        we["basins"] = basins; we["micro2basin"] = micro2basin; we["Kstar"] = int(Kstar)
        we["basins_frozen"] = True
        print(f"    [we] FROZEN GMM basins: K*(BIC)={Kstar} → {len(basins)} covered basins "
              f"(micro→basin lump {np.asarray(micro2basin).tolist()})", file=sys.stderr)
    else:                                                                # pre-freeze provisional: micro = basin
        basins = micro; micro2basin = np.arange(n_micro, dtype=int); Kstar = n_micro
    nb = len(basins)
    we["basins"] = basins; we["micro2basin"] = micro2basin; we["Kstar"] = int(Kstar); we["n_basins"] = int(nb)

    # ── 4. seed one WE walker into every MICROSTATE not yet holding a walker (WE loop then splits to n_we/micro).
    #        Seed weight = the landing's AIS importance weight (the gen-1 initial π; anchored to BAR below). ──
    _we_assign(we["reservoir"], cfg, ref_top, we)                # tag active walkers by microstate
    occupied = {w.bin_id for w in we["reservoir"].active}
    land_micro_g = _micro_of_feat(we, land_feat)                 # landings → microstate (same map as walkers)
    for m in range(n_micro):
        if m in occupied:
            continue
        cand = np.where(land_micro_g == m)[0]
        pick = (int(cand[np.argmax(w_land[cand])]) if len(cand)
                else int(np.argmin(((micro[m] - land_feat) ** 2).sum(1))))  # nearest landing to an empty micro
        w_new = we["reservoir"].seed(land.xyz[pick], max(float(w_land[pick]), 1e-8), rng)
        if w_new is not None:
            w_new.bin_id = m
    we["reservoir"].renormalize()

    # ── 5. BASIN-RATIO- & COUNT-MATCHED reverse AIS (per GMM BASIN) + endpoint-restricted BAR → π_basin. Reverse
    #        budget R = this gen's forward count; distributed ∝ the forward-landing BASIN ratio (largest-remainder).
    #        Reverse draws come from walkers whose microstate lumps to that basin, so every basin is covered. ──
    _we_assign(we["reservoir"], cfg, ref_top, we)
    active = we["reservoir"].active
    land_basin_g = micro2basin[land_micro_g]                              # this gen's landings → basin
    fwd_counts = np.bincount(land_basin_g, minlength=nb).astype(int)
    R = int(len(Wf))
    frac = (fwd_counts / max(len(Wf), 1)) * R
    rev_counts = np.floor(frac).astype(int)
    rem = int(R - rev_counts.sum())
    if rem > 0:
        for i in np.argsort(-(frac - rev_counts))[:rem]:
            rev_counts[i] += 1
    rev_done = np.zeros(nb, int)
    for b in range(nb):
        k = int(rev_counts[b])
        members = [w for w in active if 0 <= w.bin_id < n_micro and micro2basin[w.bin_id] == b]
        if k == 0 or not members:
            continue
        wts = np.array([w.weight for w in members], float)
        wts = wts / wts.sum() if wts.sum() > 0 else None
        take = rng.choice(len(members), size=k, replace=True, p=wts)
        xyz = np.array([members[int(t)].positions_nm() for t in take], float)
        seed_dir = out / f"gen{g:04d}/reverse/basin_{b:02d}"
        seed_dir.mkdir(parents=True, exist_ok=True)
        (seed_dir / "config.json").write_text(json.dumps(_seed_config(cfg)))
        shutil.copy(cfg["pdb"], seed_dir / "start_structure.pdb")
        md.Trajectory(xyz, ref_top.topology).save_dcd(str(seed_dir / "trajectory.dcd"))
        Wr, _ = _ais_leg(seed_dir, seed_dir / "rev", cfg, k, 1.0, cfg["s_hot"], platform,
                         seed=5000 + 100 * g + b, devices=(devices if len(devices) > 1 else None))
        we["Wr_all"].append(Wr); we["rev_start_all"].append(np.full(k, b, int))
        rev_done[b] = k
    we["fwd_counts_g"] = fwd_counts.tolist(); we["rev_counts_g"] = rev_done.tolist()

    land_basin_pool = micro2basin[_nearest_centre(land_feat_pool, micro)]
    Wr_pool = np.concatenate(we["Wr_all"]) if we["Wr_all"] else np.array([])
    rev_start_pool = np.concatenate(we["rev_start_all"]) if we["rev_start_all"] else np.array([], int)
    rev_start_pool = np.clip(rev_start_pool, 0, nb - 1) if rev_start_pool.size else rev_start_pool
    bar = basin_free_energies(Wf_pool, land_basin_pool, Wr_pool, rev_start_pool, nb)
    we["pi_bar"] = bar["pi"]; we["dF_bar"] = bar["dF"]           # SHARED front-end: π+ΔF feed BOTH WE anchor and US

    # ── 6. WE inner loop. STEERING + kinetics count matrix on the DECOUPLED layer: gen 1 = temporary microstates
    #        (needed for the PCCA+ freeze); gen ≥2 = ADAPTIVE BARRIER TILES (WExplore add-only). Weight normalisation
    #        (anchor) is always on the thermo BASINS. bin(steer) → run τ → weighted independent-lag counts →
    #        split/merge to n_we per steer-bin (barrier-enhanced on under-crossed edges). ──
    use_tiles = bool(we.get("frozen_micro"))                    # gen ≥2
    cutoff = cfg["we_tile_cutoff"]
    if use_tiles:
        _anchor_by_basin(we, cfg, we["pi_bar"]); Cw = we["Cw_tile"]
    else:
        pi_micro = _pi_micro_from_basin(active, we["pi_bar"], micro2basin, n_micro, we_M)
        we["pi_micro"] = pi_micro; we["reservoir"].anchor(pi_micro); Cw = we["Cw_lag"]
    n_round = max(1, int(round(cfg["walker_ps"] / we_tau)))
    lag_scan = tuple(Cw.keys())
    crossings = 0.0
    hist = {}; prev_ids = set()                                 # per-walker steer-bin history (independent-lag)
    for _r in range(n_round):
        if use_tiles:
            bins_before, _ = _we_assign_tiles(we["reservoir"], cfg, ref_top, we, cutoff)
        else:
            bins_before, _ = _we_assign(we["reservoir"], cfg, ref_top, we)
        we["reservoir"].extend_all(we_tau, pool)
        if use_tiles:
            bins_after, _ = _we_assign_tiles(we["reservoir"], cfg, ref_top, we, cutoff)
        else:
            bins_after, _ = _we_assign(we["reservoir"], cfg, ref_top, we)
        act = we["reservoir"].active
        wts = np.array([w.weight for w in act], float)
        nbins = len(we["tile_centres"]) if use_tiles else n_micro
        for k in range(len(bins_after)):                        # lag-1 weighted counts (all transitions)
            Cw[1][int(bins_before[k]), int(bins_after[k])] += wts[k]
        if use_tiles:                                           # manufactured inter-basin crossings (barrier flux)
            bot = _basin_of_tile(we)
            for k in range(len(bins_after)):
                if bot[int(bins_before[k])] != bot[int(bins_after[k])]:
                    crossings += float(wts[k])
        cur_ids = set()                                         # independent higher-lag counts from lineage chains
        for w, mic in zip(act, bins_after):
            i = id(w); cur_ids.add(i)
            if i not in prev_ids:                              # fresh split/seed: delta start, LEQ-gated (new chain)
                hist[i] = []
            hist[i].append((int(mic), float(w.weight)))
            seq = hist[i]
            for L in lag_scan:
                if L >= 2 and len(seq) > L:
                    Cw[L][seq[-1 - L][0], seq[-1][0]] += seq[-1][1]
        for i in list(hist):
            if i not in cur_ids:
                del hist[i]
        prev_ids = cur_ids
        # FIXED-pool frontier-boosted targets (Σ M_i ≤ context pool ⇒ no starvation; barrier tiles held, not merged)
        target_M = _we_targets_fixed_pool(bins_after, Cw[1], cfg["we_max_contexts"], c_min, boost)
        we["reservoir"].resample(target_M, rng)
    if use_tiles:
        _anchor_by_basin(we, cfg, we["pi_bar"])
    else:
        _we_assign(we["reservoir"], cfg, ref_top, we)
        we["reservoir"].anchor(_pi_micro_from_basin(we["reservoir"].active, we["pi_bar"], micro2basin, n_micro, we_M))
    we["crossings"] += crossings

    # ── FREEZE the microstates after gen 1: PCCA+ (target n_microstate) on the gen-1 count matrix → the permanent
    #    states, used unchanged from gen 2 on (the count matrix accumulates on this ONE fixed definition forever). ──
    if not we.get("frozen_micro"):
        _freeze_pcca_micro(we, cfg, rng)

    # budget accounting: cold force-evals this gen (walker MD + 2×AIS legs) vs the 500 ns cap
    cold_ps_gen = len(active) * cfg["walker_ps"] + (len(Wf) + int(np.sum(rev_done))) * _t_ais_ps(cfg)
    we["cold_ps"] += cold_ps_gen

    phase = "frozen" if we["hot_frozen"] else "growing"
    pib = np.round(np.asarray(we["pi_bar"], float), 3).tolist()
    n_tiles = 0 if we["tile_centres"] is None else len(we["tile_centres"])
    rec = dict(gen=g, phase=phase, micro_temp=(None if we.get("frozen_micro") and g > 1 else int(n_micro)),
               n_micro_frozen=(int(we["n_micro"]) if we.get("frozen_micro") else None),
               pcca_stability_ars=we.get("pcca_stability_ars"),
               n_tiles=int(n_tiles), crossings_weighted=float(we["crossings"]),
               Kstar=int(Kstar), n_basins=int(nb),
               n_active=len(we["reservoir"].active), mean_Wf=float(np.mean(Wf)),
               W2=float(emd) if np.isfinite(emd) else None,
               W2_self_floor=float(self_floor) if np.isfinite(self_floor) else None,
               hot_frozen=we["hot_frozen"], g_freeze=we["g_freeze"],
               n_fwd=int(len(Wf)), n_rev=int(np.sum(rev_done)),
               fwd_counts=fwd_counts.tolist(), rev_counts=rev_done.tolist(),
               cold_ps=we["cold_ps"], pi_bar=pib)
    print(f"  [we] gen {g} [{phase}]: micro(steer)={n_micro} frozen={we.get('n_micro')}, K*={Kstar}→basins={nb}, "
          f"tiles={n_tiles}, xings={we['crossings']:.3g}, active={rec['n_active']}, "
          f"n_fwd={rec['n_fwd']} n_rev={rec['n_rev']} (fwd/rev {rec['fwd_counts']}/{rec['rev_counts']}), "
          f"W2={rec['W2']}, g_freeze={we['g_freeze']}, cold={we['cold_ps']/1000:.1f}ns, pi_BAR={pib}",
          file=sys.stderr)
    return rec


def _pi_micro_from_basin(active, pi_basin, micro2basin, n_micro, we_M):
    """Microstate stationary vector for the anchor/haMSM: each basin's π^BAR spread over its microstates ∝ their
    current WE weight (uniform if a basin's walkers carry no weight yet). Σ within a basin = π_basin."""
    pi_basin = np.asarray(pi_basin, float)
    w_micro = np.zeros(n_micro)
    for w in active:
        if 0 <= w.bin_id < n_micro:
            w_micro[int(w.bin_id)] += max(w.weight, 0.0)
    pi_micro = np.zeros(n_micro)
    for b in range(len(pi_basin)):
        ms = np.where(micro2basin == b)[0]
        if not len(ms) or not np.isfinite(pi_basin[b]):
            continue
        wsum = w_micro[ms].sum()
        share = (w_micro[ms] / wsum) if wsum > 0 else np.full(len(ms), 1.0 / len(ms))
        pi_micro[ms] = pi_basin[b] * share
    s = pi_micro.sum()
    return pi_micro / s if s > 0 else np.full(n_micro, 1.0 / n_micro)


def phase_b_we(cfg, out, we):
    """BAIS-WE readout:
      * Populations = per-BASIN endpoint-BAR π^BAR (GMM basins) — BAIS thermodynamics, untouched.
      * Kinetics = fixed-π reversible haMSM on the ADAPTIVE BARRIER-TILED weighted count matrix C̃_tile(Lτ) (the
        decoupled steering layer — this is what carries the manufactured inter-basin flux the well-only matrix
        lacks). π_tile distributes π^BAR over the tiles of each basin ∝ tile visitation. INDEPENDENT-LAG ITS scan
        (each lag its own C̃_tile(Lτ) from lineage pairs) is the convergence gate vs the 1 µs plateau; T̃(τ)^L
        Chapman–Kolmogorov composition is the Markovianity cross-check. Basin MFPT lumps the tile MSM by tile→basin."""
    micro = we["micro_centres"]; n_micro = len(micro); nb = we["n_basins"]
    pi_basin = np.asarray(we["pi_bar"], float)
    we_tau = cfg["we_tau"]
    n_tiles = 0 if we["tile_centres"] is None else len(we["tile_centres"])
    Cw1 = we["Cw_tile"][1] if n_tiles else we["Cw_lag"][1]      # barrier-tiled kinetics (fallback: micro if no tiles)
    Cw_dict = we["Cw_tile"] if n_tiles else we["Cw_lag"]
    tile2basin = _basin_of_tile(we) if n_tiles else np.asarray(we.get("micro2basin", np.zeros(n_micro, int)), int)

    # π_tile: spread π^BAR over each basin's tiles ∝ tile visitation (row sums), Σ within a basin = π_basin
    rowsum = Cw1.sum(1) + 1e-12
    pi_tile = np.zeros(Cw1.shape[0])
    for b in range(nb):
        ts = np.where(tile2basin == b)[0]
        if len(ts) and np.isfinite(pi_basin[b]):
            pi_tile[ts] = pi_basin[b] * (rowsum[ts] / rowsum[ts].sum())
    s = pi_tile.sum(); pi_tile = pi_tile / s if s > 0 else np.full(Cw1.shape[0], 1.0 / max(Cw1.shape[0], 1))

    kin = estimate_bais(Cw1, pi_tile if pi_tile.sum() > 0 else None, lag=1)
    T = kin.get("T")
    its_indep, its_ck = [], []
    for L in sorted(Cw_dict):
        CwL = Cw_dict[L]
        kL = estimate_bais(CwL, pi_tile if pi_tile.sum() > 0 and CwL.shape[0] == len(pi_tile) else None, lag=L)
        itsL = kL.get("its", np.nan)
        its_indep.append(dict(lag_tau=int(L), lag_ps=float(L * we_tau), counts=float(CwL.sum()),
                              its_ps=(None if not np.isfinite(itsL) else float(itsL * we_tau))))
        if T is not None and CwL.shape == Cw1.shape:
            itsc = slow_timescale(np.linalg.matrix_power(T, int(L)), lag=L, C=Cw1)
            its_ck.append(dict(lag_tau=int(L), its_ps=(None if not np.isfinite(itsc) else float(itsc * we_tau))))
    its_ps = float(kin.get("its", np.nan)) * we_tau if np.isfinite(kin.get("its", np.nan)) else np.nan

    # basin MFPT by lumping the TILE transition matrix over tile→basin
    mfpt_basin = None
    if T is not None and nb >= 2:
        Cb = np.zeros((nb, nb))
        for i in range(Cw1.shape[0]):
            for j in range(Cw1.shape[0]):
                Cb[tile2basin[i], tile2basin[j]] += Cw1[i, j]
        kb = estimate_bais(Cb, pi_basin if np.isfinite(pi_basin).all() and pi_basin.sum() > 0 else None, lag=1)
        mfpt_basin = _mfpt_from_T(kb["T"], lag=we_tau) if kb.get("T") is not None else None

    results = dict(
        system=cfg.get("_slug", "?"), method="bais_we",
        n_micro=int(n_micro), Kstar=int(we["Kstar"]), n_basins=int(nb),
        pi=np.asarray(pi_basin, float).tolist(),
        weighted_counts_total=float(Cw1.sum()),
        n_barrier_tiles=int(n_tiles), manufactured_crossings_weighted=float(we["crossings"]),
        tile_visits_weighted=(Cw1.sum(1) + Cw1.sum(0)).round(3).tolist() if n_tiles else [],
        tile2basin=(tile2basin.tolist() if n_tiles else []),
        its_slow_ps=(None if not np.isfinite(its_ps) else its_ps),
        its_vs_lag_independent=its_indep, its_vs_lag_ck=its_ck,
        mfpt_basin_ps=(None if mfpt_basin is None else np.asarray(mfpt_basin, float).tolist()),
        basins_feat=np.asarray(we["basins"], float).tolist(),
        micro_feat=np.asarray(micro, float).tolist(), micro2basin=np.asarray(we["micro2basin"], int).tolist(),
        we_tau_ps=we_tau, we_M=cfg["we_M"], we_n_micro=cfg["we_n_micro"], we_tile_cutoff=cfg["we_tile_cutoff"],
        hot_frozen=we["hot_frozen"], g_freeze=we["g_freeze"], cold_ns=we["cold_ps"] / 1000.0,
    )
    (out / "bais_we_results.json").write_text(json.dumps(results, indent=1))
    print(f"[bais-we] wrote {out / 'bais_we_results.json'}", file=sys.stderr)
    print(f"[bais-we] K*={we['Kstar']} basins={nb}, {n_tiles} barrier tiles, "
          f"{we['crossings']:.3g} manufactured crossings, pi_BAR={np.round(pi_basin,3).tolist()}, "
          f"slow ITS={results['its_slow_ps']} ps; ITS-vs-lag(indep)={[s['its_ps'] for s in its_indep]}",
          file=sys.stderr)
    return results


def _we_main(args, cfg, out, devices, platform, n_gen):
    """Driver for --we: build the WEReservoir, run the per-generation BAIS-WE cycle, then the haMSM readout."""
    from escort_ais.methods.bais_we import WEReservoir
    if out.exists():
        shutil.rmtree(out)
    (out / "forward").mkdir(parents=True, exist_ok=True)
    hot = md.load_dcd(str(cfg["hot_dcd"]), top=str(cfg["pdb"]))
    burn = int(round(args.hot_burn_ps / cfg["hot_ps_per_frame"]))
    if burn > 0:
        hot = hot[burn:]
    prmtop, system = _build_cold_system(cfg)
    ref_top = md.load(str(cfg["pdb"]))
    reservoir = WEReservoir(prmtop, system, cfg, platform, devices, cfg["we_max_contexts"])
    pool = ThreadPoolExecutor(max_workers=3 * len(devices)) if len(devices) > 1 else None
    rng = np.random.default_rng(0)
    we = dict(reservoir=reservoir, ref_top=ref_top,
              km_centres=None, pcca_map=None, micro_centres=None, frozen_micro=False, n_micro=None,
              pcca_stability_ars=None, basins=None, micro2basin=None, Kstar=None, n_basins=0, basins_frozen=False,
              tile_centres=None, crossings=0.0,
              Cw_lag={L: np.zeros((0, 0)) for L in (1, 2, 3, 4)},
              Cw_tile={L: np.zeros((0, 0)) for L in (1, 2, 3, 4)},
              Wf_all=[], land_feat_all=[], land_ang_all=[], land_xyz_all=[],
              Wr_all=[], rev_start_all=[], pi_bar=None, pi_micro=None, dF_bar=None, prev_land=None, w2_streak=0,
              hot_frozen=False, frozen_window=None, g_freeze=None, fwd_counts_g=[], rev_counts_g=[], cold_ps=0.0)
    # gen 0 is a HOT BURN-IN (discarded); the n_gen productive cold generations are gens 1..n_gen.
    total_gens = n_gen + 1
    print(f"[bais-we] {args.system}: hot={hot.n_frames} frames, 1 burn-in + {n_gen} cold gens, "
          f"T_walker={cfg['walker_ps']} ps, we_M={cfg['we_M']}, we_tau={cfg['we_tau']} ps, "
          f"max_ctx={cfg['we_max_contexts']}, devices={devices}", file=sys.stderr)
    per_gen = []
    t0 = time.time()
    for g in range(total_gens):
        rec = run_generation_we(g, cfg, out, hot, we, platform, devices, pool, rng, args.hot_draw, n_gen)
        rec["t_min"] = (time.time() - t0) / 60
        per_gen.append(rec)
        (out / "bais_we_pergen.json").write_text(json.dumps(dict(system=args.system, n_gen=n_gen, per_gen=per_gen),
                                                            indent=1))
    res = phase_b_we(cfg, out, we)
    if pool is not None:
        pool.shutdown()
    return res, we


def _us_gen_main(args, cfg, out, devices, platform):
    """GENERATIONAL BAUS (the production BAUS): per-generation reversible NES-BAR with a SLIDING hot ensemble (no
    freeze) and GROWING umbrellas. Phase A (no-freeze PREP → umbrellas at G_conv) then G_N main generations, each:
    slide-hot forward AIS (accumulate) → min-work labels N^L_m → advance continuous flat-bottom walkers →
    backward reverse-AIS C_m→C→H (debiased) with count = cumulative label (3a 'label') or N_AIS/gen (3b 'fixed') →
    soft-BAR over ALL forward + accumulated reverse → per-gen π. Every G_update gens: adaptive umbrella growth
    (add an umbrella if an unexplained >1% landing-weight region concentrates into a >1% component)."""
    from escort_ais.methods import ais_prep, bais_us
    from escort_ais.methods.soft_bar import basin_free_energies_soft
    from escort_ais.systems.vonmises_mixture import (angles_to_cossin, cossin_to_angles, fit_vmm_bic,
                                                     kappa_to_cossin_diag_cov)
    from openmm import unit
    import pandas as pd
    if out.exists():
        shutil.rmtree(out)
    (out / "forward").mkdir(parents=True, exist_ok=True)
    cfg["prep_no_freeze"] = True                                   # BAUS: hot keeps sliding (the fix)
    kT_kj = (unit.MOLAR_GAS_CONSTANT_R * 300 * unit.kelvin).value_in_unit(unit.kilojoule_per_mole)
    hot = md.load_dcd(str(cfg["hot_dcd"]), top=str(cfg["pdb"]))
    burn = int(round(args.hot_burn_ps / cfg["hot_ps_per_frame"]))
    if burn > 0:
        hot = hot[burn:]
    ref_top = md.load(str(cfg["pdb"]))
    rng = np.random.default_rng(0)
    ais_devices = devices if len(devices) > 1 else None
    quartets = (np.array([md.compute_phi(ref_top)[0][0], md.compute_psi(ref_top)[0][0]], int)
                if cfg["feature"] == "phipsi" else np.asarray(cfg["_quartets"], int))
    d = int(len(quartets))
    E_star = float(cfg.get("us_e_reach", bais_us.E_STAR_DEFAULT)); k_max = float(cfg.get("us_k_max", bais_us.K_MAX_DEFAULT))
    impl = str(cfg.get("us_flatbottom_impl", "compound"))
    strategy = str(cfg.get("us_reverse", "label"))                # 'label' (3a) | 'fixed' (3b)
    G_N = 3 if args.smoke else int(cfg.get("us_gens", 10))
    G_update = int(cfg.get("us_gupdate", 5)); G_burn = int(cfg.get("us_gburn", 1))
    T_gen = 6.0 if args.smoke else float(cfg.get("us_tgen", cfg["walker_ps"]))
    save_ps = 1.0 if args.smoke else 5.0
    n_ais = int(cfg["n_ais"]); unassigned_kT = float(cfg.get("us_unassigned_kT", 1.0))
    make_system = lambda: _build_cold_system(cfg)
    state = ais_prep.new_prep_state()

    def _pool(key):                                               # accumulated arrays from the (no-freeze) PREP state
        return np.concatenate(state[key]) if state[key] else np.empty((0,))

    def _u_of(land_ang_deg, win):                                 # u_m(x) [kT] per landing (rows) per umbrella (cols)
        la = np.radians(np.atleast_2d(np.asarray(land_ang_deg, float)))
        return np.array([[bais_us.flatbottom_bias_D(bais_us.torsion_D(a, np.asarray(w["phi_ref"], float)),
                                                    w["hw_lin"], w["k_kT"]) for w in win] for a in la])

    def _reverse(mi, k):                                          # k debiased reverse works C_m→C→H from walker mi
        traj = walkers.samples(mi)
        if traj is None or len(traj) == 0:
            return np.array([])
        pick = rng.choice(len(traj), size=max(int(k), 1), replace=(len(traj) < int(k)))
        seeds_traj = traj[pick]
        rout = out / f"reverse/umb_{mi:02d}/g{gcur:04d}"
        sdir = _make_seed_dir(out / f"reverse/umb_{mi:02d}/seed_g{gcur:04d}", cfg, seeds_traj)
        Wr, _ = _ais_leg(sdir, rout, cfg, int(k), 1.0, cfg["s_hot"], platform, seed=5000 + 100 * gcur + mi,
                         devices=ais_devices)
        Wr = np.asarray(Wr, float)
        try:                                                      # −u_m(x_start) debias, per shot via the AIS summary
            ifx = pd.read_csv(rout / "ais_trajectory_summary.csv")["initial_frame_index"].to_numpy()
            sang = md.compute_dihedrals(seeds_traj, quartets)
            pr = np.asarray(windows[mi]["phi_ref"], float); hw = windows[mi]["hw_lin"]; kk = windows[mi]["k_kT"]
            Ub = np.array([bais_us.flatbottom_bias_D(bais_us.torsion_D(sang[min(max(int(j), 0), len(sang) - 1)], pr),
                                                     hw, kk) for j in ifx])
            if len(Ub) == len(Wr):
                Wr = Wr - Ub
        except Exception as e:                                    # pragma: no cover
            print(f"    [us-gen] umb {mi} g{gcur}: debias skipped ({type(e).__name__}: {e})", file=sys.stderr)
        return Wr

    def _new_window(nm_feat, nc):                                 # design one umbrella given existing means+covs
        allm = np.vstack([means, nm_feat[None]]); allc = np.concatenate([covs, nc[None]], axis=0)
        k, dij, jnn, wv = bais_us.spring_from_gmm_overlap(allm, allc, d, E_star=E_star, k_max=k_max)
        j = len(means)
        return dict(basin=j, phi_ref=bais_us.basin_reference_angles(nm_feat, d).tolist(),
                    k_kT=float(k[j]), hw_lin=float(wv[j]), d_ij_lin=float(dij[j]), nearest_j=int(jnn[j]),
                    w_lin=float(wv[j]))

    # ── generation loop ──
    means = covs = None; windows = []; walkers = None
    Wr_all, rev_start_all, Nrev, label_cum, labeled_from = [], [], [], [], []
    pergen = []; g_conv = None; gcur = 0
    while True:
        gcur += 1
        ais_prep.hot_ais_step(gcur, cfg, hot, state, out, platform, devices, rng)
        if gcur <= G_burn:                                        # discard burn-in landings (keep W2 continuity)
            for key in ("Wf_all", "land_feat_all", "land_ang_all", "land_xyz_all"):
                if state[key]:
                    state[key].pop()
            pergen.append(dict(gen=gcur, phase="burn")); continue
        # define umbrellas ONCE at G_conv, spin up the continuous walkers
        if not windows and state["g_freeze"] is not None:
            g_conv = int(state["g_freeze"])
            lf = _pool("land_feat_all"); Wf = _pool("Wf_all"); w = np.exp(-Wf - (-Wf).max())
            m = min(len(lf), 2000); idx = np.random.default_rng(0).choice(len(lf), size=m, p=w / w.sum())
            fit = fit_vmm_bic(cossin_to_angles(lf[idx]), int(cfg["we_n_micro"]), seed=0)
            means, covs, _grp, mlog = bais_us.merge_oversplit_windows(
                angles_to_cossin(fit["mu"]), kappa_to_cossin_diag_cov(fit["kappa"]), d,
                np.radians(_pool("land_ang_all")), w, E_star=E_star, k_max=k_max, comp_w=fit["weights"])
            windows = bais_us.design_windows(means, covs, d, E_star=E_star, k_max=k_max)
            walkers = bais_us.UmbrellaWalkers(make_system, quartets, kT_kj, platform, devices[0], impl=impl)
            la_all = _pool("land_ang_all"); lx_all = _pool("land_xyz_all")
            for w_ in windows:
                Db = bais_us.torsion_D(np.radians(la_all), np.asarray(w_["phi_ref"], float))
                walkers.add(w_, lx_all[int(np.argmin(Db))])
            Nrev = [0] * len(windows); label_cum = [0] * len(windows); labeled_from = [g_conv] * len(windows)
            wdeg = np.degrees([w_["phi_ref"] for w_ in windows])
            print(f"[us-gen] {args.system}: G_conv={g_conv}, {len(windows)} umbrellas "
                  f"(phi>0: {int(np.sum(wdeg[:,0]>0))}); strategy={strategy}", file=sys.stderr)
        if not windows:
            pergen.append(dict(gen=gcur, phase="prep")); continue
        gi = gcur - g_conv                                        # main-generation index

        # 1. min-work labels for THIS gen's landings (argmin_m u_m); accumulate per umbrella
        la_g = state["land_ang_all"][-1]
        L_g = _u_of(la_g, windows).argmin(1)
        for mi in range(len(windows)):
            label_cum[mi] += int(np.sum(L_g == mi))
        # 2. advance every continuous confined walker by T_gen
        walkers.advance(T_gen, save_ps)
        # 3. backward per umbrella (fire only the incremental shots)
        for mi in range(len(windows)):
            target = label_cum[mi] if strategy == "label" else n_ais * (gcur - labeled_from[mi])
            k_new = int(max(0, target - Nrev[mi]))
            if k_new <= 0:
                continue
            Wr = _reverse(mi, k_new)
            if len(Wr):
                Wr_all.append(Wr); rev_start_all.append(np.full(len(Wr), mi, int)); Nrev[mi] += int(len(Wr))
        # 4. soft-BAR over ALL forward (+u_m) and accumulated reverse
        Wf_pool = _pool("Wf_all"); land_ang_pool = np.radians(_pool("land_ang_all"))
        Wr = np.concatenate(Wr_all) if Wr_all else np.array([])
        rev_start = np.concatenate(rev_start_all) if rev_start_all else np.array([], int)
        sb = basin_free_energies_soft(Wf_pool, land_ang_pool, Wr, rev_start, windows)
        pi = np.asarray(sb["pi"], float)
        wdeg = np.degrees([w_["phi_ref"] for w_ in windows])
        pergen.append(dict(gen=gcur, gi=gi, phase="main", n_land=int(len(Wf_pool)), n_umbrella=len(windows),
                           pi=np.nan_to_num(pi).tolist(), Nrev=list(map(int, Nrev)), label_cum=list(map(int, label_cum)),
                           phi_pos=float(pi[wdeg[:, 0] > 0].sum()), centres_deg=wdeg.round(0).tolist()))
        (out / "us_gen_pergen.json").write_text(json.dumps(dict(system=args.system, strategy=strategy, per_gen=pergen), indent=1))
        print(f"[us-gen] g{gcur} (gi={gi}): {len(windows)} umb, {len(Wf_pool)} land | phi>0={pi[wdeg[:,0]>0].sum():.3f} "
              f"| pi={np.round(np.nan_to_num(pi),3).tolist()}", file=sys.stderr)
        # 5. adaptive umbrella growth every G_update gens (first check at gi=G_update, not gi=0)
        if gi and gi % G_update == 0 and gi < G_N:
            lf = _pool("land_feat_all"); Wf = _pool("Wf_all"); wgt = np.exp(-Wf - (-Wf).max())
            minu = _u_of(_pool("land_ang_all"), windows).min(1)
            un = minu > unassigned_kT
            if un.any() and wgt[un].sum() / wgt.sum() > 0.01 and un.sum() >= 20:
                mfit = min(4, int(un.sum()) // 10 + 1)
                mi2 = min(int(un.sum()), 1000)
                ia = np.random.default_rng(gcur).choice(np.where(un)[0], size=mi2,
                                                        p=(wgt[un] / wgt[un].sum()))
                gf = fit_vmm_bic(cossin_to_angles(lf[ia]), mfit, seed=0)
                gmu = angles_to_cossin(gf["mu"]); gcov = kappa_to_cossin_diag_cov(gf["kappa"])
                for c in range(int(gf["Kstar"])):                 # accept a component that captures >1% total weight
                    ucand = np.array([bais_us.flatbottom_bias_D(
                        bais_us.torsion_D(np.radians(a), gf["mu"][c]), float(np.sqrt(max(np.trace(gcov[c]), 1e-9))),
                        E_star) for a in _pool("land_ang_all")])
                    share = wgt[ucand < unassigned_kT].sum() / wgt.sum()
                    if share > 0.01:
                        nw = _new_window(gmu[c], gcov[c])
                        means = np.vstack([means, gmu[c][None]]); covs = np.concatenate([covs, gcov[c][None]], axis=0)
                        windows.append(nw)
                        Db = bais_us.torsion_D(np.radians(_pool("land_ang_all")), np.asarray(nw["phi_ref"], float))
                        walkers.add(nw, _pool("land_xyz_all")[int(np.argmin(Db))])
                        Nrev.append(0); label_cum.append(0); labeled_from.append(gcur)   # label only FUTURE landings
                        print(f"[us-gen] g{gcur}: GREW umbrella {len(windows)-1} at phi,psi="
                              f"{np.round(np.degrees(nw['phi_ref']),0).tolist()} (share={share:.3f})", file=sys.stderr)
        if gi >= G_N:
            break

    # ── C0 PMF RECONSTRUCTION (the meaningful output): MBAR/WHAM over EVERY umbrella configuration, with the
    #    per-umbrella BAR free energies as the inter-umbrella offsets (H1 bridges the non-overlapping umbrellas).
    #    Each umbrella is a biased sample of the cold C0 density; WHAM removes the KNOWN flat-bottom bias and the
    #    BAR offsets tie the umbrellas onto one scale -> the unbiased C0 PMF. Basin populations = integrate. This,
    #    not the umbrella BAR populations, is what compares to REMD/cold-MD. ──
    pi_us = None; pmf_micro = None; wdeg = np.degrees([w_["phi_ref"] for w_ in windows])
    angles_list = []
    for m in range(len(windows)):
        tj = walkers.samples(m)
        angles_list.append(md.compute_dihedrals(tj, quartets) if (tj is not None and len(tj)) else np.zeros((0, d)))
    pooled = np.concatenate([a for a in angles_list if len(a)], axis=0) if any(len(a) for a in angles_list) else np.zeros((0, d))
    if len(pooled) >= len(windows):
        from sklearn.cluster import KMeans
        n_nodes = int(min(max(3 * len(windows), 24), 80, len(pooled)))
        feat = np.concatenate([np.cos(pooled), np.sin(pooled)], axis=1)          # (N, 2d) [cos_1..cos_D, sin_1..sin_D]
        km = KMeans(n_clusters=n_nodes, n_init=4, random_state=0).fit(feat)
        node_ang = cossin_to_angles(km.cluster_centers_)                          # (n_nodes, d) rad microstate nodes
        node_basin = np.array([int(np.argmin([bais_us.torsion_D(na, np.asarray(w_["phi_ref"], float))
                                              for w_ in windows])) for na in node_ang], int)
        rec = bais_us.reconstruct_mbar(windows, angles_list, None, node_ang, node_basin,
                                       np.asarray(sb["pi"], float))               # BAR pi = the inter-umbrella offsets
        pi_us = np.asarray(rec.get("pi_us") or [], float); pmf_micro = rec.get("pmf_micro")
        np.savez(out / "umbrella_samples.npz",
                 **{f"umb_{m:02d}": angles_list[m] for m in range(len(windows))},
                 node_ang=node_ang, node_basin=node_basin, P_micro=np.asarray(rec.get("P_micro") or []))
        print(f"[us-gen] C0 PMF (WHAM+BAR-bridge over {len(pooled)} umbrella configs, {n_nodes} nodes): "
              f"pi_us={np.round(pi_us,3).tolist()}  phi>0(C0 PMF)={pi_us[wdeg[:,0]>0].sum():.3f}", file=sys.stderr)

    # final result
    res = dict(method="us_generational", strategy=strategy, n_umbrella=len(windows), g_conv=g_conv, G_N=G_N,
               centres_deg=wdeg.tolist(),
               pi_c0_pmf=(None if pi_us is None else np.nan_to_num(pi_us).tolist()),   # THE COMPARISON QUANTITY
               phi_pos_c0=(None if pi_us is None else float(pi_us[wdeg[:, 0] > 0].sum())),
               pmf_micro=pmf_micro,
               pi_bar=np.nan_to_num(np.asarray(sb["pi"], float)).tolist(),             # bridge/support only
               dF_kT=np.asarray(sb["dF"], float).tolist(),
               phi_pos_bar=float(np.asarray(sb["pi"], float)[wdeg[:, 0] > 0].sum()),
               diagnostics=sb["diagnostics"], per_gen=pergen,
               windows=windows, n_land=int(len(_pool("Wf_all"))), n_rev=list(map(int, Nrev)))
    (out / "us_gen_results.json").write_text(json.dumps(res, indent=1))
    np.savez(out / "works.npz", Wf=_pool("Wf_all"), land_ang=np.radians(_pool("land_ang_all")),
             Wr=(np.concatenate(Wr_all) if Wr_all else np.array([])),
             rev_start=(np.concatenate(rev_start_all) if rev_start_all else np.array([], int)),
             phi_ref=np.array([w_["phi_ref"] for w_ in windows]),
             hw=np.array([w_["hw_lin"] for w_ in windows]), k=np.array([w_["k_kT"] for w_ in windows]))
    print(f"[us-gen] DONE {args.system} ({strategy}): {len(windows)} umb | "
          f"C0-PMF phi>0={res['phi_pos_c0']}  (bridge BAR phi>0={res['phi_pos_bar']:.3f})  ref 0.0285", file=sys.stderr)
    return res


def _load_mst_design():
    """Lazy-load the experimental MST-guided umbrella-design module. It lives in ``methods/test/MST-bridge/`` whose
    hyphen makes it non-importable as a package, so we load it by file path. Only invoked under ``--cov-mst-design``."""
    import importlib.util
    p = Path(__file__).resolve().parent / "test" / "MST-bridge" / "prep_umbrella_design.py"
    spec = importlib.util.spec_from_file_location("prep_umbrella_design", p)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod                          # register so @dataclass introspection resolves
    spec.loader.exec_module(mod)
    return mod


def _coverage_gen_main(args, cfg, out, devices, platform):
    """GENERATIONAL COVERAGE-window BAIS: anisotropic HARMONIC (von Mises) umbrellas placed by landing-COVERAGE
    (product-von-Mises BIC, diagonal in torsion space), grown per generation by the [A] coherent-core ∧
    [B] BAR-overlap<update_ov update rule (methods/coverage_windows). PRIMARY populations =
    **bidirectional soft-BAR per window** (forward H→C→Cₘ
    with +bias_u vs the reverse Cₘ→C→H with −bias_u; `basin_free_energies_soft(bias_fn=cw.bias_u)`) — the reverse
    leg supplies the rare-state (α_L) weight that forward-JE alone under-counts. Forward-JE cold weights are kept as
    a diagnostic. Mirrors `_us_gen_main`'s forward/reverse-AIS + per-gen bookkeeping."""
    from escort_ais.methods import ais_prep
    from escort_ais.methods import coverage_windows as cw
    from escort_ais.methods.soft_bar import basin_free_energies_soft
    from openmm import unit
    import pandas as pd
    if out.exists():
        shutil.rmtree(out)
    (out / "forward").mkdir(parents=True, exist_ok=True)
    cfg["prep_no_freeze"] = True
    kT_kj = (unit.MOLAR_GAS_CONSTANT_R * 300 * unit.kelvin).value_in_unit(unit.kilojoule_per_mole)
    hot = md.load_dcd(str(cfg["hot_dcd"]), top=str(cfg["pdb"]))
    burn = int(round(args.hot_burn_ps / cfg["hot_ps_per_frame"]))
    if burn > 0:
        hot = hot[burn:]
    ref_top = md.load(str(cfg["pdb"]))
    rng = np.random.default_rng(0)
    ais_devices = devices if len(devices) > 1 else None
    quartets = (np.array([md.compute_phi(ref_top)[0][0], md.compute_psi(ref_top)[0][0]], int)
                if cfg["feature"] == "phipsi" else np.asarray(cfg["_quartets"], int))
    update_ov = float(cfg.get("cov_update_ov", cw.UPDATE_OV_DEFAULT))
    ov_max = float(cfg.get("cov_overlap_max", cw.OVERLAP_MAX_DEFAULT))   # RULE 2: pairwise BAR overlap ceiling
    memb = float(cfg.get("cov_memb", 0.10)); estar = float(cfg.get("cov_estar", cw.E_STAR_DEFAULT))
    escape_fb = bool(cfg.get("cov_escape_feedback", False))      # OFF by default (opt-in via cfg)
    G_N = 3 if args.smoke else int(cfg.get("us_gens", 10)); G_burn = int(cfg.get("us_gburn", 1))
    G_update = 2 if args.smoke else int(cfg.get("us_gupdate", 5))   # seed/recalibrate umbrellas only every G_update gens
    G_PREP = 2 if args.smoke else int(cfg.get("cov_gprep", 5))      # MIN PREP gens before seeding (floor on OT convergence)
    T_gen = 6.0 if args.smoke else float(cfg.get("us_tgen", cfg["walker_ps"]))
    save_ps = 1.0 if args.smoke else 5.0
    n_ais = int(cfg["n_ais"])                                    # forward-AIS shots/gen (window quality)
    # FORWARD-ONLY is the default (MSK estimator); bidirectional reverse-AIS soft-BAR is opt-in and "on hold".
    n_rev = int(cfg.get("cov_n_rev", min(n_ais, 25))) if cfg.get("cov_bidirectional") else 0
    make_system = lambda: _build_cold_system(cfg)
    state = ais_prep.new_prep_state()

    def _pool(key):
        return np.concatenate(state[key]) if state[key] else np.empty((0,))

    def _seed_xyz(win):
        la = np.radians(_pool("land_ang_all")); lx = _pool("land_xyz_all")
        return lx[int(np.argmin(cw.bias_u(la, win)))]

    def _reverse(mi, k):
        traj = walkers.samples(mi)
        if traj is None or len(traj) == 0:
            return np.array([])
        pick = rng.choice(len(traj), size=max(int(k), 1), replace=(len(traj) < int(k)))
        seeds_traj = traj[pick]
        rout = out / f"reverse/umb_{mi:02d}/g{gcur:04d}"
        sdir = _make_seed_dir(out / f"reverse/umb_{mi:02d}/seed_g{gcur:04d}", cfg, seeds_traj)
        Wr, _ = _ais_leg(sdir, rout, cfg, int(k), 1.0, cfg["s_hot"], platform, seed=5000 + 100 * gcur + mi, devices=ais_devices)
        Wr = np.asarray(Wr, float)
        try:
            ifx = pd.read_csv(rout / "ais_trajectory_summary.csv")["initial_frame_index"].to_numpy()
            sang = md.compute_dihedrals(seeds_traj, quartets)
            Ub = np.array([float(cw.bias_u(sang[min(max(int(j), 0), len(sang) - 1)][None], windows[mi])[0]) for j in ifx])
            if len(Ub) == len(Wr):
                Wr = Wr - Ub                                       # −u_m(x_start) harmonic debias, per shot
        except Exception as e:                                    # pragma: no cover
            print(f"    [cov-gen] umb {mi} g{gcur}: debias skipped ({type(e).__name__}: {e})", file=sys.stderr)
        return Wr

    def _pi_fwdje():                                              # DIAGNOSTIC: forward-JE cold populations (trusted w)
        la = np.radians(_pool("land_ang_all")); Wf = _pool("Wf_all"); w = np.exp(-(Wf - Wf.min()))
        lab, un = cw.label(la, windows, memb)
        pi = np.array([w[(lab == m) & ~un].sum() for m in range(len(windows))])
        return (pi / pi.sum()) if pi.sum() > 0 else pi

    def _pi_bar():                                                # PRIMARY: bidirectional soft-BAR per window (harmonic)
        Wf = _pool("Wf_all"); la = np.radians(_pool("land_ang_all"))
        Wr = np.concatenate(Wr_all) if Wr_all else np.array([])
        rs = np.concatenate(rev_start_all) if rev_start_all else np.array([], int)
        sb = basin_free_energies_soft(Wf, la, Wr, rs, windows, bias_fn=cw.bias_u)
        return np.nan_to_num(np.asarray(sb["pi"], float)), sb

    windows = []; walkers = None; g_conv = None; gcur = 0; pergen = []
    Wr_all = []; rev_start_all = []; Nrev = []
    while True:
        gcur += 1
        ais_prep.hot_ais_step(gcur, cfg, hot, state, out, platform, devices, rng)
        if gcur <= G_burn:
            for key in ("Wf_all", "land_feat_all", "land_ang_all", "land_xyz_all"):
                if state[key]:
                    state[key].pop()
            pergen.append(dict(gen=gcur, phase="burn")); continue
        # Seed umbrellas ONCE, after the OT-convergence gate AND at least G_PREP PREP generations (enough landings).
        if not windows and state["g_freeze"] is not None and (gcur - G_burn) >= G_PREP:
            g_conv = gcur                                        # count gi from the ACTUAL build gen (not g_freeze)
            la = np.radians(_pool("land_ang_all")); Wf = _pool("Wf_all"); w = np.exp(-(Wf - Wf.min()))
            windows = None
            if cfg.get("cov_mst_design"):                        # OPT-IN experimental: MST-guided window-per-basin + bridges
                try:
                    _res = _load_mst_design().design_from_prep(
                        la, Wf, radius=float(cfg.get("cov_mst_radius", 20.0)), e_star=estar,
                        kmin=cw.KMIN_DEFAULT, kmax=cw.KMAX_DEFAULT, ov_target=float(cfg.get("cov_mst_ov", 0.40)))
                    if not _res.windows:
                        raise ValueError("MST design found no basins")
                    windows = [{"mu": np.asarray(wd.mu, float), "kappa": np.asarray(wd.kappa, float)} for wd in _res.windows]
                    U = float(_res.coverage["orphaned_frac"])
                    nbas = sum(1 for wd in _res.windows if wd.kind == "basin")
                    print(f"[cov-gen] {args.system}: MST-design seed@g{gcur} — {nbas} basin + {len(windows)-nbas} "
                          f"bridge windows, orphaned-cold-weight={U:.3f}", file=sys.stderr)
                except Exception as _e:                          # D>2 systems, sparse PREP, etc. → fall back
                    print(f"[cov-gen] MST-design unavailable ({type(_e).__name__}: {_e}); using build_windows",
                          file=sys.stderr)
                    windows = None
            if not windows:                                      # default: vM-mixture 3-rule build_windows
                windows, U = cw.build_windows(la, w, update_ov=update_ov, memb=memb, E_star=estar, ov_max=ov_max)
            walkers = cw.HarmonicWalkers(make_system, quartets, kT_kj, platform, devices[0])
            for win in windows:
                walkers.add(win, _seed_xyz(win)); Nrev.append(0)
            cen = np.degrees([win["mu"] for win in windows])
            print(f"[cov-gen] {args.system}: seed@g{gcur} (g_freeze={state['g_freeze']}, G_PREP={G_PREP}), "
                  f"{len(windows)} windows (phi>0:{int((cen[:,0]>0).sum())}) unassigned={U:.3f}", file=sys.stderr)
        if not windows:
            pergen.append(dict(gen=gcur, phase="prep")); continue
        gi = gcur - g_conv
        la_all = np.radians(_pool("land_ang_all")); Wf_all = _pool("Wf_all"); w_all = np.exp(-(Wf_all - Wf_all.min()))
        if (not cfg.get("cov_mst_design")) and gi and gi % G_update == 0 and gi < G_N:  # UPDATE only every G_update gens (add-only); MST design is fixed at seeding
            windows, added, U = cw.update_windows(windows, la_all, w_all, memb=memb, update_ov=update_ov)
            windows, mpairs = cw.calibrate_kappa_overlap(windows, la_all, w_all, E_star=estar, kmin=cw.KMIN_DEFAULT,
                                                         kmax=cw.KMAX_DEFAULT, ov_max=ov_max, memb=memb, merge=False)
            n_exist = len(windows) - len(added)
            for mi in range(min(n_exist, len(walkers))):                         # re-tune existing walkers in place
                walkers.update_kappa(mi, windows[mi]["kappa"])
            for win in windows[n_exist:]:                                        # spin up walkers for new windows
                walkers.add(win, _seed_xyz(win)); Nrev.append(0)
            if added or mpairs:
                print(f"[cov-gen] g{gcur}: +{len(added)} window(s) -> {len(windows)}"
                      + (f"  infeasible(too-close) {mpairs}" if mpairs else ""), file=sys.stderr)
        else:                                           # between updates: umbrellas FROZEN (μ,κ fixed); just report coverage
            _, un_all = cw.label(la_all, windows, memb)
            U = float(w_all[un_all].sum() / max(float(w_all.sum()), 1e-300))
        walkers.advance(T_gen, save_ps)
        if escape_fb:   # OPT-IN escape-feedback: tighten κ for any walker that wandered > 3σ out of its window
            n_recent = max(1, int(round(T_gen / save_ps)))
            for mi in range(len(windows)):
                samp = walkers.samples(mi)
                if samp is None:
                    continue
                ai = md.compute_dihedrals(samp[-n_recent:], quartets)
                dth = np.abs(np.angle(np.exp(1j * (ai - windows[mi]["mu"])))).mean(0)
                if np.any(dth > 3.0 / np.sqrt(np.maximum(windows[mi]["kappa"], 1e-6))):
                    windows[mi]["kappa"] = np.clip(windows[mi]["kappa"] * 1.5, cw.KMIN_DEFAULT, cw.KMAX_DEFAULT)
                    walkers.update_kappa(mi, windows[mi]["kappa"])
                    print(f"[cov-gen] g{gcur}: escape-feedback tightened win {mi} -> κ={windows[mi]['kappa'].round(1)}",
                          file=sys.stderr)
        if n_rev > 0:                                           # reverse AIS shooting (skipped in forward-landing-only mode)
            for mi in range(len(windows)):
                Wr = _reverse(mi, n_rev)
                if len(Wr):
                    Wr_all.append(Wr); rev_start_all.append(np.full(len(Wr), mi, int)); Nrev[mi] += int(len(Wr))
        pi, sb = _pi_bar(); pi_fje = _pi_fwdje(); cen = np.degrees([win["mu"] for win in windows])
        pergen.append(dict(gen=gcur, gi=gi, phase="main", n_land=int(len(w_all)), n_win=len(windows),
                           pi=pi.tolist(), phi_pos=float(pi[cen[:, 0] > 0].sum()),
                           pi_fwdje=pi_fje.tolist(), phi_pos_fwdje=float(pi_fje[cen[:, 0] > 0].sum()),
                           n_rev=int(sum(len(x) for x in Wr_all)), unassigned=float(U),
                           centres_deg=cen.round(0).tolist()))
        (out / "cov_gen_pergen.json").write_text(json.dumps(dict(system=args.system, per_gen=pergen), indent=1))
        print(f"[cov-gen] g{gcur} (gi={gi}): {len(windows)} win, {len(w_all)} land | "
              f"phi>0(BAR)={pi[cen[:,0]>0].sum():.3f} (fwdJE {pi_fje[cen[:,0]>0].sum():.3f}) | U={U:.3f}", file=sys.stderr)
        if gi >= G_N:
            break

    pi, sb = _pi_bar(); pi_fje = _pi_fwdje(); cen = np.degrees([win["mu"] for win in windows])
    la_final = np.radians(_pool("land_ang_all"))
    lab_final, un_final = cw.label(la_final, windows, memb)
    np.savez(out / "coverage_windows.npz", mu=np.array([win["mu"] for win in windows]),
             kappa=np.array([win["kappa"] for win in windows]),
             Wf=_pool("Wf_all"), land_ang=la_final, label=lab_final, unassigned=un_final,   # RADIANS (matches works.npz)
             Wr=np.concatenate(Wr_all) if Wr_all else np.array([]),
             rev_start=np.concatenate(rev_start_all) if rev_start_all else np.array([], int))
    # per-window CONTIGUOUS confined-walker torsion time series (one frame / save_ps) for correlation-time / TICA
    # analysis of each umbrella's within-window relaxation. HarmonicWalkers.samples(i) is time-ordered.
    win_ang = {}
    for i in range(len(windows)):
        tr = walkers.samples(i)
        win_ang[f"umb_{i:02d}"] = (md.compute_dihedrals(tr, quartets) if tr is not None and tr.n_frames
                                   else np.zeros((0, len(quartets)), float))
    np.savez(out / "window_walker_angles.npz", save_ps=float(save_ps),
             centres_deg=cen.round(1), **win_ang)
    results = dict(method="coverage_generational", n_win=len(windows), g_conv=g_conv, centres_deg=cen.round(0).tolist(),
                   pi=pi.tolist(), phi_pos=float(pi[cen[:, 0] > 0].sum()),
                   pi_fwdje=pi_fje.tolist(), phi_pos_fwdje=float(pi_fje[cen[:, 0] > 0].sum()),
                   bar_diagnostics={str(k): v for k, v in sb["diagnostics"].items()}, per_gen=pergen)
    (out / "coverage_results.json").write_text(json.dumps(results, indent=1))
    print(f"[cov-gen] DONE {args.system}: {len(windows)} windows | phi>0(BAR)={pi[cen[:,0]>0].sum():.4f} "
          f"(fwdJE {pi_fje[cen[:,0]>0].sum():.4f}, ref 0.0285)", file=sys.stderr)
    return results


def _us_main(args, cfg, out, devices, platform):
    """Driver for --method us = BAUS (the project's umbrella-sampling thermodynamics tool). Reservoir-free by
    definition: NO WE reservoir is built. Pipeline:
      1. shared hot forward-AIS PREP (ais_prep.run_hot_prep — identical hot leg to BAWE) → frozen landings;
      2. vM-BIC windows on the weighted landings (BIC-argmin, resolves α_L) + the MEDIAN-to-median E*/k_max merge
         (bais_us.merge_oversplit_windows) — NO _basins_from_gmm_lump / _merge_kinetic_basins (those erased α_L);
      3. confined flat-bottom MD per window (the umbrellas ARE the cold sampling);
      4. reverse-AIS FROM EACH WINDOW'S OWN confined samples (cold s=1 → hot s=s_hot) → soft flat-bottom BAR π
         (production) + WHAM π_US + forward-only π_AUS. The reverse pool is the umbrellas themselves, not a
         separate weighted-ensemble reservoir (the decoupling)."""
    from escort_ais.methods import ais_prep, bais_us
    from escort_ais.systems.vonmises_mixture import (angles_to_cossin, cossin_to_angles, fit_vmm_bic,
                                                     kappa_to_cossin_diag_cov)
    from openmm import unit
    if out.exists():
        shutil.rmtree(out)
    (out / "forward").mkdir(parents=True, exist_ok=True)
    kT_kj = (unit.MOLAR_GAS_CONSTANT_R * 300 * unit.kelvin).value_in_unit(unit.kilojoule_per_mole)
    hot = md.load_dcd(str(cfg["hot_dcd"]), top=str(cfg["pdb"]))
    burn = int(round(args.hot_burn_ps / cfg["hot_ps_per_frame"]))
    if burn > 0:
        hot = hot[burn:]
    ref_top = md.load(str(cfg["pdb"]))
    rng = np.random.default_rng(0)
    ais_devices = devices if len(devices) > 1 else None

    # 1) shared hot PREP → frozen forward-AIS landings (land_feat cos/sin, land_ang DEGREES, land_xyz, Wf)
    max_gen = 3 if args.smoke else int(cfg.get("prep_max_gen", 200))   # accumulate landings to prep_target_landings
    prep = ais_prep.run_hot_prep(cfg, hot, out, platform, devices, rng, max_gen=max_gen)
    land_feat = np.asarray(prep["land_feat"], float); land_ang = np.asarray(prep["land_ang"], float)
    land_xyz = prep["land_xyz"]; Wf = np.asarray(prep["Wf"], float)
    w_land = np.exp(-Wf - (-Wf).max())
    d = land_ang.shape[1]

    # 2) vM-BIC windows (NO lump/prune) + median-to-median E*/k_max merge
    m = min(len(land_feat), 2000)
    idx = np.random.default_rng(0).choice(len(land_feat), size=m, p=w_land / w_land.sum())
    fit = fit_vmm_bic(cossin_to_angles(land_feat[idx]), int(cfg["we_n_micro"]), seed=0)
    means0 = angles_to_cossin(fit["mu"]); covs0 = kappa_to_cossin_diag_cov(fit["kappa"])
    E_star = float(cfg.get("us_e_reach", bais_us.E_STAR_DEFAULT))
    k_max = float(cfg.get("us_k_max", bais_us.K_MAX_DEFAULT))
    means, covs, groups, mlog = bais_us.merge_oversplit_windows(
        means0, covs0, d, np.radians(land_ang), w_land, E_star=E_star, k_max=k_max, comp_w=fit["weights"])
    nb = len(means)
    _wdeg = np.degrees(np.array([bais_us.basin_reference_angles(means[b], d) for b in range(nb)]))
    _phi_pos = int(np.sum(_wdeg[:, 0] > 0)) if _wdeg.shape[1] >= 1 else 0
    print(f"[bais-us] {args.system}: PREP {prep['n_gen_prep']} gens (freeze G={prep['g_freeze']}), "
          f"{len(land_ang)} landings; vM-BIC K*={len(means0)} → {nb} windows (median E*={E_star:.0f} merge)",
          file=sys.stderr)
    print(f"[bais-us] window centres (deg): {[[round(x,0) for x in row] for row in _wdeg.tolist()]}  "
          f"| phi>0 (alpha_L) windows: {_phi_pos}", file=sys.stderr)

    # 3) seeds (most-central landing per window) + soft-BAR forward inputs (Wf, land_ang_rad, land→window)
    lb = _nearest_centre(land_feat, means)
    seeds = []
    for b in range(nb):
        cand = np.where(lb == b)[0]
        if len(cand) == 0:
            seeds.append(None); continue
        phi_ref = bais_us.basin_reference_angles(means[b], d)
        Db = bais_us.torsion_D(np.radians(land_ang[cand]), phi_ref)
        seeds.append(land_xyz[cand[int(np.argmin(Db))]])
    # (4) reverse count = UNWEIGHTED forward landings per basin (count-matched, uncapped): n_rev_cap default huge.
    fwd_soft = dict(Wf=Wf, land_ang_rad=np.radians(land_ang), land_basin=lb,
                    n_rev_cap=int(cfg.get("us_n_rev_cap", 100000)))
    pi_aus0 = np.array([w_land[lb == b].sum() for b in range(nb)], float)
    pi_aus0 = pi_aus0 / pi_aus0.sum() if pi_aus0.sum() > 0 else np.full(nb, 1.0 / nb)   # forward-only fallback bridge
    quartets = (np.array([md.compute_phi(ref_top)[0][0], md.compute_psi(ref_top)[0][0]], int)
                if cfg["feature"] == "phipsi" else np.asarray(cfg["_quartets"], int))

    # per-window flat-bottom spring (k, hw) + centre angles — for the EXACT reverse wall-removal term (item 5)
    _k_arr, _, _, _hw_arr = bais_us.spring_from_gmm_overlap(means, covs, d, E_star=E_star, k_max=k_max)
    _cang = [bais_us.basin_reference_angles(means[b], d) for b in range(nb)]

    # 4/5) reverse-AIS FROM WINDOWS: cold(s=1)→hot(s=s_hot) from each window's OWN confined frames, count-matched;
    #      made the EXACT C_m→C→H reverse by subtracting the wall-removal work U_bias^i(x_start) per shot (the
    #      C_m→C leg; ≈0 for flat-interior seeds, finite for the wall tail).
    def reverse_ais_fn(traj_i, i, k_i):
        import pandas as _pd
        n = len(traj_i)
        pick = rng.choice(n, size=max(int(k_i), 1), replace=(n < int(k_i)))
        seeds_traj = traj_i[pick]
        rev_out = out / f"reverse/window_{i:02d}/rev"
        seed_dir = _make_seed_dir(out / f"reverse/window_{i:02d}/seed_cold", cfg, seeds_traj)
        Wr, _ = _ais_leg(seed_dir, rev_out, cfg, int(k_i), 1.0, cfg["s_hot"], platform,
                         seed=5000 + i, devices=ais_devices)                       # cold(s=1)→hot(s=s_hot)
        Wr = np.asarray(Wr, float)
        try:                                                                       # (5) subtract −U_bias^i(x_start)
            ifx = _pd.read_csv(rev_out / "ais_trajectory_summary.csv")["initial_frame_index"].to_numpy()
            sang = md.compute_dihedrals(seeds_traj, quartets)                      # (npick, d) rad seed angles
            Ub = np.array([bais_us.flatbottom_bias_D(
                bais_us.torsion_D(sang[min(max(int(j), 0), len(sang) - 1)], _cang[i]), _hw_arr[i], _k_arr[i])
                for j in ifx])
            if len(Ub) == len(Wr):
                Wr = Wr - Ub                                                       # C_m→C removal completes the mirror
        except Exception as e:                                                     # pragma: no cover
            print(f"    [bais-us] window {i}: reverse wall-removal skipped ({type(e).__name__}: {e})", file=sys.stderr)
        return Wr

    us_n_gen = _derive_n_gen_we(cfg, nb)
    if args.smoke:
        n_ps = 6.0
    elif cfg.get("us_confined_ns"):
        n_ps = float(cfg["us_confined_ns"]) * 1000.0                              # explicit confined-MD budget/window (ns)
    else:
        n_ps = float(us_n_gen * cfg["walker_ps"])
    save_ps = 1.0 if args.smoke else 20.0
    make_system = lambda: _build_cold_system(cfg)
    prep_budget = dict(G_conv=prep["g_freeze"], n_gen_prep=prep["n_gen_prep"], we_cold_ps=0.0,
                       source="run_hot_prep (no WE reservoir); reverse pool = confined windows")
    impl = str(cfg.get("us_flatbottom_impl", "cvforce"))
    res = bais_us.run_bais_us(cfg, make_system, means, covs, pi_aus0, quartets, seeds, kT_kj,
                              out, platform=platform, device=devices[0], n_ps=n_ps, save_ps=save_ps,
                              smoke=args.smoke, reverse_ais_fn=reverse_ais_fn, fwd_soft=fwd_soft,
                              prep_budget=prep_budget, E_star=E_star, k_max=k_max, impl=impl)
    res["merge_log"] = mlog
    (out / "bais_us_results.json").write_text(json.dumps(res, indent=1))
    print(f"[bais-us] DONE {args.system}: {nb} windows | pi_soft_bar={np.round(np.nan_to_num(np.asarray(res.get('pi_soft_bar') or [], float)),3).tolist()} "
          f"| pi_aus={np.round(np.asarray(res.get('pi_aus') or [], float),3).tolist()}", file=sys.stderr)
    return res


def _us_from_we(args, cfg, out, we, res_we, devices, platform):
    """DEPRECATED / LEGACY (NOT BAUS): reconstruct umbrella populations π^US from a FINISHED WE run's reservoir,
    reached only via `--us-from-run` on an old WE output. This is the superseded reservoir-COUPLED umbrella path;
    the project's BAUS is now `_us_main` (reservoir-free — its own hot PREP + reverse-AIS from each window). Kept
    only so historical WE productions can still be re-read. Builds flat-bottom windows on the WE basin graph and
    takes reverse works from each basin's WE reservoir (soft_bar_inputs)."""
    from escort_ais.methods import bais_us
    from openmm import unit
    kT_kj = (unit.MOLAR_GAS_CONSTANT_R * 300 * unit.kelvin).value_in_unit(unit.kilojoule_per_mole)
    basins = np.asarray(we["basins"], float); nb = len(basins)            # US umbrellas = GMM(K*) BASINS
    ref_top = we["ref_top"]
    lf = np.concatenate(we["land_feat_all"], axis=0)
    lb = _nearest_centre(lf, basins)                                     # landing → nearest GMM basin
    dF = np.nan_to_num(np.asarray(we["dF_bar"], float), nan=0.0)           # SHARED BAR ΔF (provenance/log only now)
    # GMM covariances for the harmonic spring rule: re-fit GMM(K*) on the frozen landings (avoids touching the WE
    # run), take each committed basin's nearest-component covariance (w_i = √trace Σ_i).
    Wf_pool = np.concatenate(we["Wf_all"]); w_land = np.exp(-Wf_pool - (-Wf_pool).max())
    covs, _kcov = _gmm_cov_for_centres(lf, w_land, basins, np.random.default_rng(0), kmax=cfg["we_n_micro"])
    # per basin: seed each window from its MOST-CENTRAL in-basin landing (min CV distance to φ_ref).
    land_xyz = np.concatenate(we["land_xyz_all"], axis=0)
    land_ang = np.concatenate(we["land_ang_all"], axis=0)                  # (N, d) degrees
    d = int(basins.shape[1] // 2)
    seeds = []
    for b in range(nb):
        cand = np.where(lb == b)[0]
        if len(cand) == 0:
            seeds.append(None); continue
        phi_ref = bais_us.basin_reference_angles(basins[b], d)            # rad
        Db = bais_us.torsion_D(np.radians(land_ang[cand]), phi_ref)        # in-basin CV values
        seeds.append(land_xyz[cand[int(np.argmin(Db))]])                  # most-central landing
    quartets = (np.array([md.compute_phi(ref_top)[0][0], md.compute_psi(ref_top)[0][0]], int)
                if cfg["feature"] == "phipsi" else np.asarray(cfg["_quartets"], int))
    # US budget: N_cold = N_umbrella = K* ⇒ n_gen_US, and biased MD per window = n_gen_US·T_walker (~100 ns).
    us_n_gen = _derive_n_gen_we(cfg, nb)
    n_ps = 6.0 if args.smoke else float(us_n_gen * cfg["walker_ps"])
    save_ps = 1.0 if args.smoke else 20.0
    print(f"[bais-us] N_umbrella=K*={nb}; budget n_gen={us_n_gen} ⇒ harmonic-window MD/window="
          f"{'6 ps (smoke)' if args.smoke else f'{n_ps/1000:.0f} ns'}", file=sys.stderr)
    make_system = lambda: _build_cold_system(cfg)                 # fresh (prmtop_like, base_system) per window

    # SOFT flat-bottom BAR inputs (port 2): the SHARED --we forward works + landing angles (→rad) and the reverse
    # works/starts drawn from each basin's WE reservoir. Present only when --we produced them (not for --us-from-run
    # reconstructions with no reverse pool) → guarded so the US bridge falls back to the endpoint π^BAR.
    soft_bar_inputs = None
    Wr_all = we.get("Wr_all") or []
    rev_start_all = we.get("rev_start_all") or []
    if Wr_all and rev_start_all:
        soft_bar_inputs = dict(
            Wf=np.concatenate(we["Wf_all"]),
            land_ang_rad=np.radians(np.concatenate(we["land_ang_all"], axis=0)),
            Wr=np.concatenate(Wr_all),
            rev_start=np.clip(np.concatenate(rev_start_all), 0, nb - 1))

    # PREP bookkeeping (port 3): the --we hot phase (up to the W2 landing-gate freeze G_conv = g_freeze) is the
    # hot-only PREP; the confined US cold windows below run ONLY AFTER it (PREP cold-spend = 0 for the US phase).
    prep_budget = dict(G_conv=we.get("g_freeze"), we_cold_ps=float(we.get("cold_ps", 0.0)),
                       source="--we hot ensemble + reservoir (US confined windows start after G_conv)")
    return bais_us.run_bais_us(cfg, make_system, basins, covs, we["pi_bar"], quartets, seeds, kT_kj,
                               out, dF_ais=dF, platform=platform, device=devices[0], n_ps=n_ps, save_ps=save_ps,
                               micro_centres=we["micro_centres"], micro2basin=we["micro2basin"],
                               smoke=args.smoke, soft_bar_inputs=soft_bar_inputs, prep_budget=prep_budget)


def _persist_us_inputs(out, we, cfg):
    """Persist the frozen-graph state BAIS-US needs, so `--us-from-run` can run the revised US on the FINISHED WE
    production without re-running WE. Written once at the end of --we (the running WE keeps this only in memory)."""
    try:
        np.savez(
            out / "us_inputs.npz",
            land_feat=np.concatenate(we["land_feat_all"], axis=0),
            land_ang=np.concatenate(we["land_ang_all"], axis=0),
            land_xyz=np.concatenate(we["land_xyz_all"], axis=0),
            Wf=np.concatenate(we["Wf_all"]),
            micro_centres=np.asarray(we["micro_centres"], float),
            micro2basin=np.asarray(we["micro2basin"], int),
            basins=np.asarray(we["basins"], float),
            pi_bar=np.asarray(we["pi_bar"], float),
            dF_bar=np.nan_to_num(np.asarray(we["dF_bar"], float), nan=0.0),
            feature=str(cfg["feature"]),
        )
        print(f"[bais-we] persisted US inputs → {out / 'us_inputs.npz'}", file=sys.stderr)
    except Exception as e:                                                # pragma: no cover
        print(f"[bais-we] WARNING: could not persist US inputs ({type(e).__name__}: {e})", file=sys.stderr)


def _we_from_run(cfg, out):
    """Reconstruct a minimal `we`-like dict for BAIS-US from a FINISHED WE run directory `out`. Prefers the
    persisted `us_inputs.npz`; else falls back to `bais_we_results.json` (basins/micro/pi) + the per-gen forward
    landing DCDs (`gen*/fwd/ais_final_coordinates.dcd`), recomputing land_feat/ang/xyz via `featurize`."""
    ref_top = md.load(str(cfg["pdb"]))
    npz = out / "us_inputs.npz"
    if npz.exists():
        z = np.load(npz, allow_pickle=True)
        we = dict(ref_top=ref_top, basins=z["basins"], micro_centres=z["micro_centres"],
                  micro2basin=z["micro2basin"], pi_bar=z["pi_bar"], dF_bar=z["dF_bar"],
                  land_feat_all=[z["land_feat"]], land_ang_all=[z["land_ang"]],
                  land_xyz_all=[z["land_xyz"]], Wf_all=[z["Wf"]])
        print(f"[bais-us] loaded persisted us_inputs.npz ({len(z['land_feat'])} landings, "
              f"{len(z['basins'])} basins)", file=sys.stderr)
        return we
    # fallback: bais_we_results.json + per-gen forward DCDs (works on the already-running production, old code)
    resj = json.loads((out / "bais_we_results.json").read_text())
    basins = np.asarray(resj["basins_feat"], float)
    micro_centres = np.asarray(resj["micro_feat"], float)
    micro2basin = np.asarray(resj["micro2basin"], int)
    pi_bar = np.asarray(resj["pi"], float)
    seed_pdbs = sorted(out.glob("gen*/seed_hot/start_structure.pdb"))
    dcds = sorted(out.glob("gen*/fwd/ais_final_coordinates.dcd"))
    if not dcds:
        raise SystemExit(f"--us-from-run: no us_inputs.npz and no forward DCDs under {out}")
    top = str(seed_pdbs[0]) if seed_pdbs else str(cfg["pdb"])
    lf, la, lx = [], [], []
    for dcd in dcds:
        tr = md.load_dcd(str(dcd), top=top)
        f, a = featurize(tr, cfg)
        lf.append(f); la.append(a); lx.append(tr.xyz)
    land_feat = np.concatenate(lf, axis=0); land_ang = np.concatenate(la, axis=0)
    land_xyz = np.concatenate(lx, axis=0)
    print(f"[bais-us] reconstructed {len(land_feat)} landings from {len(dcds)} forward DCDs "
          f"(no us_inputs.npz; dF_bar unused by revised US)", file=sys.stderr)
    return dict(ref_top=ref_top, basins=basins, micro_centres=micro_centres, micro2basin=micro2basin,
                pi_bar=pi_bar, dF_bar=-np.log(np.clip(pi_bar, 1e-12, None)),
                land_feat_all=[land_feat], land_ang_all=[land_ang], land_xyz_all=[land_xyz],
                Wf_all=[np.zeros(len(land_feat))])


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--system", required=True, choices=list(SYSTEMS))
    ap.add_argument("--n-gen", type=int, default=None)
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--cold-device", default="0", help="single GPU device index (back-compat; used if --devices unset)")
    ap.add_argument("--devices", default=None,
                    help="comma-separated GPU indices, e.g. '0,1'. Cold walkers are round-robined across them and "
                         "forward/reverse AIS shots are sharded across them. Default: [--cold-device] (single GPU).")
    ap.add_argument("--hot-draw", choices=["window", "chunk"], default="window",
                    help="'window' (deterministic sliding window, default) or 'chunk' (g-th sequential chunk; the "
                         "AIS randomly samples its seeds from it — the toy per-generation random-draw 'real case')")
    ap.add_argument("--hot-burn-ps", type=float, default=0.0,
                    help="discard this many ps from the start of the hot ensemble as burn-in before sampling seeds")
    ap.add_argument("--smoke", action="store_true", help="2 gens, tiny k/cold for a pipeline smoke test")
    # ── Method selector: exactly ONE cold estimator. Seed-once BAIS / BAIS-WE / BAIS-US are SEPARATE tools
    #    (thermo vs kinetics), NOT composable stages — hence a single mutually-exclusive choice, not two booleans. ──
    ap.add_argument("--method", choices=["us", "coverage"], default=None,   # BAUS-only (seed/we archived)
                    help="which cold estimator to run (CANONICAL, mutually exclusive): 'seed' = seed-once BAIS "
                         "(default); 'we' = BAIS-WE weighted-ensemble reservoir (kinetics; BAIS-WE_theory.pdf); "
                         "'us' = BAIS-US flat-bottom umbrellas (thermodynamics; BAIS-US_theory.pdf).")
    ap.add_argument("--we", action="store_true",
                    help="DEPRECATED alias for --method we.")
    ap.add_argument("--us", action="store_true",
                    help="DEPRECATED alias for --method us. NOTE: `--we --us` is no longer a combined run — US and "
                         "WE are separate methods; prefer --method.")
    ap.add_argument("--n-ais", type=int, default=None,
                    help="AIS shots per generation (forward). Larger → more accumulated forward landings for robust "
                         "umbrella definition + rare-state BAR (e.g. 200 → ~2500 forward over 10 gens). Overrides cfg.")
    ap.add_argument("--t-ais", type=int, default=None,
                    help="AIS switch length in integration steps (= # of REST2 λ-intermediates at freq_ais=1). "
                         "Overrides cfg['t_ais'] (default 1000 = 2 ps / 1000 GPU syncs per leg). Lower (e.g. 100) is "
                         "much faster per leg — use for quick benchmarks; higher improves AIS work overlap.")
    ap.add_argument("--neq-integrator", action="store_true",
                    help="Accumulate AIS protocol work ON the GPU via the openmmtools nonequilibrium integrator "
                         "(one readback/trajectory instead of the per-λ getState loop). Numerically validated "
                         "equivalent; helps most on OpenCL / large M_ais.")
    ap.add_argument("--freq-ais", type=int, default=None,
                    help="MD steps per λ-window (Freq_ais). M_ais = T_ais/Freq_ais λ-windows at fixed T_AIS. "
                         "Overrides cfg['freq_ais'] (default 1). Freq_ais=10 measured ~5x faster with equal/better "
                         "work ESS on alanine (fewer, better-relaxed windows). T_ais must be divisible by it.")
    ap.add_argument("--us-reverse", choices=["label", "fixed"], default="label",
                    help="Generational BAUS reverse-count strategy: 'label' (3a, cumulative min-work label count "
                         "N^L_m per umbrella) or 'fixed' (3b, N_AIS reverse shots/umbrella/gen).")
    ap.add_argument("--us-gens", type=int, default=10, help="generational BAUS: number of main generations G_N")
    ap.add_argument("--us-gupdate", type=int, default=5, help="generational BAUS: umbrella-growth check every N gens")
    ap.add_argument("--cov-bidirectional", action="store_true",
                    help="coverage: re-enable reverse-AIS soft-BAR (on hold); DEFAULT is forward-only AIS + MSK")
    ap.add_argument("--cov-gprep", type=int, default=5,
                    help="coverage: minimum PREP generations before seeding umbrellas (floor on OT convergence)")
    ap.add_argument("--cov-mst-design", action="store_true",
                    help="coverage (EXPERIMENTAL, D=2 torsions): seed umbrellas by MST-guided design from the PREP "
                         "landings — one window per basin + confident bridges — instead of vM-mixture build_windows; "
                         "falls back to build_windows on any failure (e.g. D>2 systems)")
    ap.add_argument("--cov-mst-radius", type=float, default=20.0,
                    help="coverage MST design: connection radius / KDE bandwidth (deg)")
    ap.add_argument("--cov-mst-ov", type=float, default=0.40,
                    help="coverage MST design: confident-bridge BAR-overlap target to each basin")
    ap.add_argument("--us-gburn", type=int, default=1, help="generational BAUS: discarded burn-in generations")
    ap.add_argument("--us-tgen", type=float, default=None, help="generational BAUS: confined-walker advance/gen (ps)")
    ap.add_argument("--us-oneshot", action="store_true",
                    help="use the legacy one-shot lean BAUS (_us_main) instead of the generational loop")
    ap.add_argument("--us-confined-ns", type=float, default=None,
                    help="BAUS confined-MD (umbrella) budget PER WINDOW in ns (overrides the REMD-matched budget). "
                         "Single-well within-basin sampling converges in a few ns, so ~15 is plenty and ~5x faster.")
    ap.add_argument("--us-flatbottom-impl", choices=["cvforce", "compound"], default=None,
                    help="BAUS flat-bottom wall implementation: 'cvforce' (default, CustomCVForce) or 'compound' "
                         "(CustomCompoundBondForce — energy-identical, faster, no CV inner-context overhead). "
                         "'compound' writes to us_prod_compound so it doesn't overwrite the cvforce reference.")
    ap.add_argument("--us-from-run", default=None, metavar="DIR",
                    help="DEPRECATED (legacy, NOT BAUS): reconstruct umbrella populations from a FINISHED WE run's "
                         "reservoir (e.g. .../bais_standalone/we_prod) without re-running WE. BAUS is now "
                         "reservoir-free (--method us); this exists only to re-read historical WE productions.")
    ap.add_argument("--we-M", type=int, default=None, help="WE target walkers per bin (override we_M)")
    ap.add_argument("--we-tau", type=float, default=None, help="WE resample interval in ps (override we_tau)")
    ap.add_argument("--we-burn-gens", type=int, default=None, help="consec. converged gens before hot-freeze")
    ap.add_argument("--we-c-min", type=int, default=None, help="reciprocated-crossing threshold for barrier boost")
    ap.add_argument("--we-barrier-boost", type=int, default=None, help="M_i multiplier on under-crossed edges")
    ap.add_argument("--we-max-contexts", type=int, default=None, help="WE OpenMM context pool cap")
    ap.add_argument("--analyze-only", action="store_true",
                    help="skip Phase A; re-run Phase B (basins/reverse/BAR/MFPT) on the persisted forward npzs "
                         "+ cold-walker DCDs already on disk (for checkpoint/resume of a long run)")
    args = ap.parse_args()
    # Resolve the (mutually exclusive) method. --method is canonical; --we/--us are deprecated aliases. US and WE are
    # separate tools, so `--we --us` no longer means a combined run — it maps to the US method. (--us-from-run below
    # is an orthogonal "run US on a finished dir" sub-mode.)
    if args.method is not None:
        if args.we or args.us:
            ap.error("--method is mutually exclusive with the deprecated --we/--us flags; use one or the other")
        method = args.method
    elif args.us:                                              # legacy --us → the US method (still supported)
        method = "us"
        print("[deprecation] --us is deprecated; use `--method us`", file=sys.stderr)
    elif args.we:
        ap.error("BAWE (--we / `--method we`) is ARCHIVED; this build is BAUS-only. Use --method us|coverage.")
    else:
        ap.error("no method given; this build is BAUS-only. Use --method us|coverage.")
    cfg = dict(SYSTEMS[args.system]); cfg["_slug"] = args.system
    if cfg["feature"] == "torsions":                            # RGD: cache the backbone dihedral quartets
        cfg["_quartets"] = np.load(cfg["topology_dir"] / "torsion_quartets_backbone.npz")["quartets"]
    devices = [s.strip() for s in args.devices.split(",")] if args.devices else [args.cold_device]

    out = ROOT / f"data/{'alanine_dipeptide' if args.system == 'alanine' else args.system}/bais_standalone"

    # ══ BAIS-US on a FINISHED WE run (no re-run of WE): reload the frozen graph and reconstruct the PMF ══
    if args.us_from_run:
        _apply_we_overrides(cfg)                               # match the WE Hamiltonian used to build the graph
        run_dir = Path(args.us_from_run)
        we = _we_from_run(cfg, run_dir)
        _us_from_we(args, cfg, run_dir, we, None, devices, args.platform)
        print(f"[bais-us] DONE (--us-from-run {run_dir})", file=sys.stderr)
        return

    # ══ BAWE (method 'we') / BAUS (method 'us') branch (separate output tree; leaves the seed-once path + its
    #    outputs untouched). BAUS is reservoir-free (`_us_main`): shared hot PREP → vM-BIC windows → confined MD →
    #    reverse-AIS from each window. BAWE keeps the WE reservoir (kinetics). ══
    if method in ("we", "us", "coverage"):
        _apply_we_overrides(cfg)                               # mbondi3 Hamiltonian + matched hot + we_* knobs
        for k, a in (("we_M", args.we_M), ("we_tau", args.we_tau), ("we_burn_gens", args.we_burn_gens),
                     ("we_c_min", args.we_c_min), ("we_barrier_boost", args.we_barrier_boost),
                     ("we_max_contexts", args.we_max_contexts)):
            if a is not None:
                cfg[k] = a
        # Report the PRODUCTION-settings n_gen derivation (coordinator formula) regardless of smoke.
        n_cold_prod = cfg["we_M"] * cfg["we_n_micro"]
        print(f"[bais-we] budget: cold={( cfg['remd_n_rep']-1)*cfg['remd_t_rep_ns']:.0f} ns, "
              f"N_cold=n_we·n_micro={cfg['we_M']}·{cfg['we_n_micro']}={n_cold_prod}, "
              f"T_walker={cfg['walker_ps']} ps, N_AIS={cfg['n_ais']}, T_AIS={_t_ais_ps(cfg):.3g} ps "
              f"⇒ n_gen(prod)={_derive_n_gen_we(cfg, n_cold_prod)}", file=sys.stderr)
        if args.smoke:                                         # tiny WE smoke: few states/walkers, short τ/walker
            cfg.update(n_ais=20, walker_ps=10.0, t_ais=100, cold_save_ps=2.0,
                       we_M=2, we_n_micro=4, we_k_temp=8, we_tau=2.0, we_max_contexts=12, we_burn_gens=1,
                       we_c_min=3, we_barrier_boost=2, we_tile_cutoff=0.5)
        if method == "coverage":                               # coverage-window BAIS (harmonic vM umbrellas)
            if args.n_ais is not None:
                cfg["n_ais"] = int(args.n_ais)
            if args.t_ais is not None:
                cfg["t_ais"] = int(args.t_ais)                 # shorten the AIS switch (fewer GPU λ-syncs/leg)
            if args.freq_ais is not None:
                cfg["freq_ais"] = int(args.freq_ais)           # MD steps/λ-window → M_ais = t_ais/freq_ais
            cfg["neq_integrator"] = bool(args.neq_integrator)  # on-device NEQ work accumulation (opt-in)
            cfg["us_gens"] = args.us_gens; cfg["us_gburn"] = args.us_gburn; cfg["us_gupdate"] = args.us_gupdate
            cfg["cov_bidirectional"] = bool(args.cov_bidirectional); cfg["cov_gprep"] = int(args.cov_gprep)
            cfg["cov_mst_design"] = bool(args.cov_mst_design); cfg["cov_mst_radius"] = float(args.cov_mst_radius)
            cfg["cov_mst_ov"] = float(args.cov_mst_ov)
            if args.us_tgen is not None:
                cfg["us_tgen"] = float(args.us_tgen)
            out = out / ("coverage_smoke" if args.smoke else "coverage")
            _coverage_gen_main(args, cfg, out, devices, args.platform)
            return
        if method == "us":                                     # BAUS — reservoir-free (no WE reservoir built)
            if args.us_flatbottom_impl is not None:
                cfg["us_flatbottom_impl"] = args.us_flatbottom_impl
            if args.us_confined_ns is not None:
                cfg["us_confined_ns"] = float(args.us_confined_ns)
            if args.us_oneshot:                                # legacy one-shot lean BAUS
                _impl = str(cfg.get("us_flatbottom_impl", "cvforce"))
                _suf = "" if _impl == "cvforce" else f"_{_impl}"
                out = out / (("us_smoke" if args.smoke else "us_prod") + _suf)
                _us_main(args, cfg, out, devices, args.platform)
                return
            # generational BAUS (default): per-gen reversible NES-BAR, sliding hot, growing umbrellas
            cfg["us_flatbottom_impl"] = cfg.get("us_flatbottom_impl", "compound")   # compound default for the gen loop
            if args.n_ais is not None:
                cfg["n_ais"] = int(args.n_ais)                 # bigger forward batch → robust umbrellas + BAR
            cfg["us_reverse"] = args.us_reverse
            cfg["us_gens"] = args.us_gens; cfg["us_gupdate"] = args.us_gupdate; cfg["us_gburn"] = args.us_gburn
            if args.us_tgen is not None:
                cfg["us_tgen"] = float(args.us_tgen)
            out = out / (("us_gen_smoke" if args.smoke else "us_gen") + f"_{args.us_reverse}")
            _us_gen_main(args, cfg, out, devices, args.platform)
            return
        n_gen = args.n_gen or (4 if args.smoke else _derive_n_gen_we(cfg, cfg["we_M"] * cfg["we_n_micro"]))
        out = out / ("we_smoke" if args.smoke else "we_prod")
        res_we, we = _we_main(args, cfg, out, devices, args.platform, n_gen)
        _persist_us_inputs(out, we, cfg)                        # save frozen graph for later --us-from-run
        print(f"[bais-we] DONE {args.system}: K*={res_we['Kstar']} basins={res_we['n_basins']}, "
              f"pi={np.round(np.array(res_we['pi']),3).tolist()}", file=sys.stderr)
        return

    if args.smoke:
        cfg.update(n_ais=6, walker_ps=20.0 if args.system == "alanine" else 200.0, t_ais=100,
                   cold_save_ps=2.0 if args.system == "alanine" else 20.0, n_micro=40, n_macro=3)
    n_gen = args.n_gen or (2 if args.smoke else cfg["n_gen"])
    out = out / ("smoke" if args.smoke else "prod")

    if args.analyze_only:                                       # re-run Phase B from disk (checkpoint/resume)
        fwd = sorted((out / "forward").glob("gen*.npz"))
        if not fwd:
            raise SystemExit(f"--analyze-only: no forward npzs under {out/'forward'}")
        if args.n_gen and args.n_gen < len(fwd):                # cap the forward window (e.g. 100 gens = 20 ns hot)
            fwd = fwd[:args.n_gen]
        Wf_all = [np.load(f)["Wf"] for f in fwd]
        land_feat_all = [np.load(f)["land_feat"] for f in fwd]
        land_ang_all = [np.load(f)["land_ang"] for f in fwd]
        land_xyz_all = [np.load(f)["land_xyz"] for f in fwd]
        walkers = [type("W", (), {"dcd_path": p})() for p in sorted((out / "cold").glob("walker_*.dcd"))]
        print(f"[bais] analyze-only: {len(fwd)} gens, {len(walkers)} cold walkers from disk", file=sys.stderr)
        res = phase_b(cfg, out, dict(walkers=walkers), Wf_all, land_feat_all, land_ang_all, land_xyz_all,
                      args.platform, devices)
        print(f"[bais] analyze DONE: {res['n_basins']} basins, pi={np.round(np.array(res['pi']),3).tolist()}",
              file=sys.stderr)
        return

    if out.exists():
        shutil.rmtree(out)
    (out / "forward").mkdir(parents=True, exist_ok=True)
    hot = md.load_dcd(str(cfg["hot_dcd"]), top=str(cfg["pdb"]))
    burn_frames = int(round(args.hot_burn_ps / cfg["hot_ps_per_frame"]))
    if burn_frames > 0:                                            # discard the hot burn-in transient
        hot = hot[burn_frames:]
    pool_workers = 3 * len(devices)                                # 3 concurrent cold-walker jobs per GPU
    pool = ThreadPoolExecutor(max_workers=pool_workers) if len(devices) > 1 else None
    print(f"[bais] {args.system}: hot={hot.n_frames} frames (burn {burn_frames}), draw={args.hot_draw}, "
          f"{n_gen} gens, N_AIS={cfg['n_ais']}, T_walker={cfg['walker_ps']} ps, devices={devices}, "
          f"cold-pool={pool_workers if pool else 1} (3/GPU)", file=sys.stderr)

    prmtop, system = _build_cold_system(cfg)
    cold = dict(prmtop=prmtop, system=system, walkers=[], next_wid=0, seed_feat=[])
    mgr = BasinManager(lag=2, w_min=0.02, merge_radius=0.5, seed=0)   # weighted GMM+BIC seed detector (no merge/split)
    rng = np.random.default_rng(0)

    Wf_all, land_feat_all, land_ang_all, land_xyz_all, per_gen = [], [], [], [], []
    t0 = time.time()
    for g in range(n_gen):
        Wf, lf, la, land = run_generation(g, cfg, out, hot, cold, args.platform, devices, pool,
                                          args.hot_draw, n_gen, mgr, rng)
        Wf_all.append(Wf); land_feat_all.append(lf); land_ang_all.append(la); land_xyz_all.append(land.xyz)
        np.savez(out / f"forward/gen{g:04d}.npz", Wf=Wf, land_feat=lf, land_ang=la, land_xyz=land.xyz)
        per_gen.append(dict(gen=g, n_fwd=int(len(Wf)), n_walkers=len(cold["walkers"]),
                            mean_Wf=float(np.mean(Wf)), t_min=(time.time() - t0) / 60))
        (out / "bais_pergen.json").write_text(json.dumps(              # rewrite each gen for live monitoring
            dict(system=args.system, n_gen=n_gen, per_gen=per_gen), indent=1))
        print(f"  gen {g}: {len(Wf)} fwd AIS, mean W_f={np.mean(Wf):.2f} kT, "
              f"landings={land.n_frames}, cold walkers={len(cold['walkers'])}, "
              f"{(time.time() - t0)/60:.1f} min", file=sys.stderr)

    res = phase_b(cfg, out, cold, Wf_all, land_feat_all, land_ang_all, land_xyz_all,
                  args.platform, devices)
    if pool is not None:
        pool.shutdown()
    print(f"[bais] DONE {args.system}: {res['n_basins']} basins, pi={np.round(np.array(res['pi']),3).tolist()}, "
          f"{(time.time() - t0)/60:.1f} min total", file=sys.stderr)


if __name__ == "__main__":
    main()
