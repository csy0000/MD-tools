"""Confined-MD-ONLY run of the MST-design umbrella windows — EXPERIMENTAL / test.

Seeds the MST-guided windows (prep_umbrella_design.design_from_prep) from the EXISTING PREP landings of a source
coverage run, then advances the production harmonic walkers (coverage_windows.HarmonicWalkers) for N_GEN x T_GEN.
**No additional hot sampling and no AIS** — the hot ensemble / forward-AIS are not touched; only the confined cold
walkers run. Writes window_walker_angles.npz in the umb_NN schema (compatible with the coverage C0 reconstruction).

  python src/escort_ais/methods/test/MST-bridge/run_windows_md_only.py \
      --src data/alanine_dipeptide/bais_standalone/coverage_reportPREP_20260724 \
      --out data/alanine_dipeptide/bais_standalone/coverage_mst_mdonly \
      --prep 500 --n-gen 10 --t-gen 200 --platform CUDA --device 0
"""
import argparse
import glob
import sys
from pathlib import Path

import numpy as np
import mdtraj as md

sys.path.insert(0, str(Path(__file__).resolve().parent))
import prep_umbrella_design as pud
import escort_ais.methods.coverage_windows as cw
from escort_ais.methods.run_bais_standalone import SYSTEMS, _build_cold_system


def main():
    ap = argparse.ArgumentParser(description="Confined-MD-only run of the MST-design windows (no AIS).")
    ap.add_argument("--src", required=True, help="source coverage run dir (PREP landings + landing coords)")
    ap.add_argument("--out", required=True, help="output dir for window_walker_angles.npz + design.json")
    ap.add_argument("--system", default="alanine")
    ap.add_argument("--prep", type=int, default=500, help="use the first N landings for the design (PREP pool)")
    ap.add_argument("--n-gen", type=int, default=10)
    ap.add_argument("--t-gen", type=float, default=200.0, help="ps of confined MD per generation")
    ap.add_argument("--save-ps", type=float, default=5.0)
    ap.add_argument("--radius", type=float, default=20.0)
    ap.add_argument("--ov-target", type=float, default=0.40)
    ap.add_argument("--e-star", type=float, default=3.0, help="E* wall (kT) for the design")
    ap.add_argument("--wall-min", type=float, default=8.0, help="min bridge wall (kT); below this a saddle is chained")
    ap.add_argument("--platform", default="CUDA")
    ap.add_argument("--device", type=int, default=0)
    args = ap.parse_args()

    cfg = dict(SYSTEMS[args.system])
    src = Path(args.src)

    # 1) design the windows from the EXISTING PREP landings (no new sampling)
    z = np.load(str(src / "coverage_windows.npz"))
    res = pud.design_from_prep(z["land_ang"][:args.prep], z["Wf"][:args.prep], radius=args.radius,
                               ov_target=args.ov_target, e_star=args.e_star, wall_min=args.wall_min,
                               basin_namer=(pud._alanine_namer if args.system == "alanine" else None))
    mu, kap, kinds, names = res.seed_arrays()
    windows = [{"mu": mu[i], "kappa": kap[i]} for i in range(len(mu))]
    print(f"[md-only] design: {len(windows)} windows -> " + ", ".join(f"{n}({k})" for n, k in zip(names, kinds)), flush=True)

    # 2) seed structures = the SAME PREP landings used for the design: the first `--prep` landing coords in
    #    land_ang order (burn generations excluded, post-seeding main generations excluded). Concatenating the
    #    post-burn gen fwd-DCDs in gen order reproduces the land_ang order, so [:prep] is the exact design pool.
    import json
    ref = md.load(str(cfg["pdb"]))
    quartets = np.array([md.compute_phi(ref)[0][0], md.compute_psi(ref)[0][0]], int)
    pergen = json.load(open(src / "cov_gen_pergen.json"))["per_gen"]
    burn = {int(r["gen"]) for r in pergen if r.get("phase") == "burn"}
    _gnum = lambda p: int(Path(p).parts[-3].replace("gen", ""))
    dcds = [d for d in sorted(glob.glob(str(src / "gen0*" / "fwd" / "ais_final_coordinates.dcd")), key=_gnum)
            if _gnum(d) not in burn]
    land = md.join([md.load_dcd(d, top=str(cfg["pdb"])) for d in dcds])[:args.prep]   # first `prep` = PREP design pool
    ang = md.compute_dihedrals(land, quartets)
    print(f"[md-only] seed pool: {land.n_frames} PREP landing coords (= design pool; burn gen(s) {sorted(burn)} "
          f"excluded, post-seeding main gens excluded)", flush=True)

    # 3) build the cold system + harmonic walkers; seed each from its nearest existing landing
    from openmm import unit
    kT_kj = (unit.MOLAR_GAS_CONSTANT_R * 300 * unit.kelvin).value_in_unit(unit.kilojoule_per_mole)
    make_system = lambda: _build_cold_system(cfg)
    walkers = cw.HarmonicWalkers(make_system, quartets, kT_kj, args.platform, args.device)
    for k, win in enumerate(windows):
        j = int(np.argmin(cw.bias_u(ang, win)))
        walkers.add(win, land.xyz[j], seed=k)
    print(f"[md-only] seeded {len(windows)} walkers; running {args.n_gen} gens x {args.t_gen:.0f} ps "
          f"(save {args.save_ps:.0f} ps) on {args.platform}:{args.device} — NO AIS", flush=True)

    # 4) advance the confined walkers; checkpoint the per-window angle pool each generation
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    import json
    json.dump(dict(src=str(src), prep=args.prep, radius=args.radius, ov_target=args.ov_target,
                   n_gen=args.n_gen, t_gen=args.t_gen, save_ps=args.save_ps,
                   windows=[dict(name=names[i], kind=kinds[i], mu_deg=list(np.degrees(mu[i])),
                                 kappa=list(map(float, kap[i]))) for i in range(len(windows))],
                   coverage=res.coverage), open(out / "design.json", "w"), indent=2)
    for g in range(args.n_gen):
        walkers.advance(args.t_gen, args.save_ps)
        angs = {}
        for i in range(len(windows)):
            tr = walkers.samples(i)
            angs[f"umb_{i:02d}"] = md.compute_dihedrals(tr, quartets) if tr is not None else np.zeros((0, 2))
        np.savez(out / "window_walker_angles.npz", save_ps=float(args.save_ps), centres_deg=np.degrees(mu),
                 mu=mu, kappa=kap, names=np.array(names), kinds=np.array(kinds), **angs)
        print(f"[md-only] gen {g + 1}/{args.n_gen} done — frames/win={[int(walkers.n_frames(i)) for i in range(len(windows))]}", flush=True)
    print("[md-only] DONE", flush=True)


if __name__ == "__main__":
    main()
