"""Streamlined MST-guided umbrella design for coverage-BAUS, run AFTER the PREP stage — EXPERIMENTAL / test.

ONE entry point, ``design_from_prep(land_ang, work, ...)``, turns the accumulated forward-AIS PREP landings (the
data available at the umbrella-seeding gate) into the umbrella set to seed:

  1. cold-weighted (phi,psi) PMF at connection radius ``r`` -> basins (density minima) + the MINIMUM SPANNING TREE
     of the barrier graph (watershed adjacent-basin saddles -> Kruskal; the single-linkage / disconnectivity tree);
  2. saddles classified RESOLVED vs DATA-LIMITED by bandwidth persistence;
  3. DESIGN: one window per basin (E*-LP kappa) + an ANISOTROPIC confident bridge per RESOLVED saddle. Each bridge
     is placed on the basin-connecting path and shaped so its BAR overlap to BOTH basins is ~= ``ov_target`` AND its
     own reweighted-landing ESS is maximal (width across the basin-separation axis sets the overlap; the
     perpendicular width gathers channel samples). Data-limited saddles get NO bridge (location un-pinned); their
     isolated endpoint is still covered by its basin window.

Design choices (validated on alanine, see reports/legacy/alanine/20260724_mst_bridge_design/): a window per basin is
required — leaning on the unbiased landing pool alone leaves ~half the cold weight locally under-covered.
``design_from_prep`` is PURE (arrays in, windows out); the CLI at the bottom loads a coverage run's
``coverage_windows.npz`` and writes a design figure + JSON. Reuses ``escort_ais.methods.coverage_windows``
(``estar_kappa``, ``bar_overlap``, ``_wrap``)."""
from __future__ import annotations
import argparse
import heapq
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter, minimum_filter
from scipy.optimize import minimize

from escort_ais.methods.coverage_windows import estar_kappa, _wrap, E_STAR_DEFAULT

# ---- defaults (see the alanine report) ------------------------------------------------------------------------
RADIUS = 20.0          # connection radius / KDE bandwidth (deg): sets which landings are "connected"
KMIN, KMAX = 3.0, 50.0
E_STAR = float(E_STAR_DEFAULT)
OV_TARGET = 0.40       # bridge BAR overlap target to each endpoint basin
ESS_THR = 20.0         # basin landing ESS below which the basin is flagged "isolated"
RES_RANGE = 3.0        # MST-saddle barrier range over the persistence sweep < this kT => RESOLVED
GRID = 120
PERSIST_H = (12.0, 16.0, 20.0, 25.0, 30.0)   # bandwidth sweep for saddle persistence
_EDGES4 = ((1, 0), (-1, 0), (0, 1), (0, -1))
_MIN_POPFRAC = 0.003   # a density minimum must hold at least this cold-weight fraction within r to count as a basin


@dataclass
class Window:
    name: str
    mu: np.ndarray                 # (D,) centre, radians
    kappa: np.ndarray              # (D,) per-torsion concentration
    kind: str                      # "basin" | "bridge"
    ess: float = 0.0               # reweighted PREP-landing ESS informing the window
    isolated: bool = False         # basins only: landing-thin (ESS < ess_thr)
    endpoints: tuple | None = None # bridges only: (basin_i, basin_j) indices
    overlaps: tuple | None = None  # bridges only: (ov_i, ov_j)
    n_core: int = 0                # bridges only: raw landings within 1 sigma


@dataclass
class DesignResult:
    radius: float
    basin_names: list
    basin_centres: np.ndarray      # (nb, D) radians
    basin_F: np.ndarray            # (nb,) PMF at each basin centre
    mst: list                      # [{"i","j","barrier","mu"(saddle,rad),"resolved"}]
    windows: list                  # list[Window] (basins first, then bridges)
    coverage: dict = field(default_factory=dict)

    def seed_arrays(self):
        """(mu (nw,D), kappa (nw,D), kinds (nw,), names (nw,)) — ready to hand to umbrella seeding."""
        mu = np.array([w.mu for w in self.windows]); kap = np.array([w.kappa for w in self.windows])
        return mu, kap, [w.kind for w in self.windows], [w.name for w in self.windows]


# =============================== the streamlined pipeline ======================================================
def design_from_prep(land_ang, work, *, radius=RADIUS, e_star=E_STAR, kmin=KMIN, kmax=KMAX, ov_target=OV_TARGET,
                     ess_thr=ESS_THR, res_range=RES_RANGE, grid=GRID, basin_namer=None,
                     wall_min=8.0, chain_kmax=6) -> DesignResult:
    """Design the coverage-BAUS umbrella set from the PREP forward-AIS landings.

    ``land_ang`` : (N, D) landing torsions, radians.   ``work`` : (N,) reduced forward anneal work of each landing
    (cold weight ``w_i = exp(-(W_i - W.min()))``; NEVER weight by ``exp(-W[kJ/mol])``). ``basin_namer(phi,psi)`` ->
    str is optional (labels only). Returns a :class:`DesignResult`; ``result.seed_arrays()`` gives the (mu, kappa)
    to seed. Only ``D==2`` (phi,psi) is wired for the geometry search; higher-D basins/bridges would need the
    grid/watershed generalized."""
    la = np.asarray(land_ang, float)
    if la.ndim != 2 or la.shape[1] != 2:
        raise ValueError("design_from_prep currently supports D==2 (phi,psi) torsions only")
    land = np.degrees(la)
    w = np.exp(-(np.asarray(work, float) - np.min(work)))
    wtot = float(w.sum())
    phi, psi = land[:, 0], land[:, 1]
    G = int(grid); e = np.linspace(-180, 180, G + 1); ctr = 0.5 * (e[:-1] + e[1:]); cell = 360.0 / G
    namer = basin_namer or (lambda p, s: f"b@({p:+.0f},{s:+.0f})")

    def pmf(h):
        H, _, _ = np.histogram2d(phi, psi, bins=(e, e), weights=w)
        H = gaussian_filter(H, h / cell, mode="wrap"); H /= H.sum()
        F = -np.log(H + 1e-12); return F - F.min()

    def tor(a):
        return (np.asarray(a) + 180) % 360 - 180

    # ---- (1) basins = density minima at radius r ----
    F0 = pmf(radius); sz = max(int(round(radius / cell)), 2)
    cand = np.argwhere(F0 == minimum_filter(F0, size=2 * sz + 1, mode="wrap"))
    bcell = []
    for (i, j) in cand:
        d = np.hypot(tor(phi - ctr[i]), tor(psi - ctr[j]))
        if w[d < radius].sum() / wtot < _MIN_POPFRAC:
            continue
        c = np.array([ctr[i], ctr[j]])
        if any(np.hypot(*tor(c - np.array([ctr[a], ctr[b]]))) < radius for (a, b) in bcell):
            continue
        bcell.append((int(i), int(j)))
    nb = len(bcell)
    bmu = np.array([[np.radians(ctr[i]), np.radians(ctr[j])] for (i, j) in bcell])
    bcd = np.degrees(bmu); bnames = [namer(*bcd[m]) for m in range(nb)]
    bF = np.array([F0[i, j] for (i, j) in bcell])

    # ---- watershed adjacent-basin saddles + MST (Kruskal) ----
    def watershed(F):
        Ff = F.ravel(); lab = -np.ones(G * G, int); sadF, sadcell = {}, {}
        heap = [(F[i, j], i * G + j, m) for m, (i, j) in enumerate(bcell)]; heapq.heapify(heap)
        while heap:
            f, idx, m = heapq.heappop(heap)
            if lab[idx] != -1:
                continue
            lab[idx] = m; r, c = divmod(idx, G)
            for dr, dc in _EDGES4:
                ni = ((r + dr) % G) * G + (c + dc) % G
                if lab[ni] == -1:
                    heapq.heappush(heap, (Ff[ni], ni, m))
                elif lab[ni] != m:
                    k = (min(m, lab[ni]), max(m, lab[ni])); fb = max(f, Ff[ni])
                    if k not in sadF or fb < sadF[k]:
                        sadF[k] = fb; sadcell[k] = idx
        return lab, sadF, sadcell

    def minimax(h):                      # bottleneck-barrier matrix (single-linkage) for persistence
        F = pmf(h); parent = np.arange(G * G); occ = np.zeros(G * G, bool); comp = {}
        cwn = {i * G + j: m for m, (i, j) in enumerate(bcell)}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]; x = parent[x]
            return x
        mg = []; nc = 0
        for idx in np.argsort(F.ravel()):
            occ[idx] = True; r, c = divmod(idx, G)
            if idx in cwn:
                comp[idx] = frozenset({cwn[idx]})
            for dr, dc in _EDGES4:
                ni = ((r + dr) % G) * G + (c + dc) % G
                if not occ[ni]:
                    continue
                ra, rb = find(idx), find(ni)
                if ra == rb:
                    continue
                wa, wb = comp.get(ra, frozenset()), comp.get(rb, frozenset())
                parent[rb] = ra; comp[ra] = wa | wb
                if wa and wb:
                    mg.append((min(wa), min(wb), float(F[r, c]))); nc += 1
            if nc >= nb - 1:
                break
        sad = np.full((nb, nb), np.nan); cof = list(range(nb))

        def cr(x):
            while cof[x] != x:
                x = cof[x]
            return x
        for (a, b, s) in sorted(mg, key=lambda t: t[2]):
            ra, rb = cr(a), cr(b)
            if ra == rb:
                continue
            A = [m for m in range(nb) if cr(m) == ra]; B = [m for m in range(nb) if cr(m) == rb]
            for i in A:
                for j in B:
                    sad[i, j] = sad[j, i] = s
            cof[ra] = rb
        return sad

    lab0, sadF, sadcell = watershed(F0)
    SW = {h: minimax(h) for h in PERSIST_H} if nb > 1 else {}
    cof = list(range(nb))

    def cr(x):
        while cof[x] != x:
            x = cof[x]
        return x
    mst = []
    for (i, j), fF in sorted(sadF.items(), key=lambda t: t[1]):
        if cr(i) != cr(j):
            cof[cr(i)] = cr(j); sr, sc = divmod(sadcell[(i, j)], G)
            cv = np.array([SW[h][i, j] for h in PERSIST_H])
            mst.append(dict(i=i, j=j, barrier=float(fF), mu=np.radians([ctr[sr], ctr[sc]]),
                            resolved=bool((cv.max() - cv.min()) < res_range)))
        if len(mst) == nb - 1:
            break

    # ---- basin landing ESS ----
    li = np.clip(np.digitize(phi, e) - 1, 0, G - 1); lj = np.clip(np.digitize(psi, e) - 1, 0, G - 1)
    lbasin = lab0[li * G + lj]
    basin_ess = []
    for m in range(nb):
        ww = w[lbasin == m]
        basin_ess.append(float(ww.sum() ** 2 / np.sum(ww ** 2)) if len(ww) and np.sum(ww ** 2) > 0 else 0.0)

    # ---- reweight / overlap helpers on the PREP landings ----
    def _wm(mu_, kap):
        return w * np.exp(-(np.clip(kap, kmin, kmax) * (1 - np.cos(_wrap(np.asarray(mu_) - la)))).sum(1))

    def _ess(mu_, kap):
        q = _wm(mu_, kap); s = np.sum(q ** 2); return float(q.sum() ** 2 / s) if s > 0 else 0.0

    def _ncore(mu_, kap):
        return int((np.abs(_wrap(la - mu_)) < 1.0 / np.sqrt(np.clip(kap, kmin, kmax))).all(1).sum())

    # ---- (3a) one window per basin (E*-LP kappa) ----
    windows = []
    for m in range(nb):
        k, _, _ = estar_kappa(m, bmu, bF, E_star=e_star, kmin=kmin, kmax=kmax)
        windows.append(Window(name=bnames[m], mu=bmu[m].copy(), kappa=np.asarray(k, float), kind="basin",
                              ess=basin_ess[m], isolated=bool(basin_ess[m] < ess_thr)))
    bwin = {m: windows[m] for m in range(nb)}    # basin index -> its window

    def _ov(mu_, kap, m):
        qi = _wm(mu_, kap); qi = qi / qi.sum()
        b = bwin[m]; qj = w * np.exp(-(b.kappa * (1 - np.cos(_wrap(la - b.mu)))).sum(1)); qj /= qj.sum()
        return float(np.sqrt(qi * qj).sum())

    def _ov2(muA, kapA, muB, kapB):                      # BAR overlap of two arbitrary windows
        qa = _wm(muA, kapA); qa = qa / qa.sum(); qb = _wm(muB, kapB); qb = qb / qb.sum()
        return float(np.sqrt(qa * qb).sum())

    def _wall(mu_, kap, m):                              # E* wall (kT) of a window toward basin m's centre
        return float((kap * (1 - np.cos(_wrap(np.asarray(mu_) - bmu[m])))).sum())

    # ---- (3b) anisotropic confident bridge per RESOLVED saddle; chain if one window can't hold + connect ----
    def solve_bridge(i, j):
        dij = _wrap(bmu[j] - bmu[i])

        def obj(x):
            x = np.asarray(x, float); mu_ = _wrap(bmu[i] + np.clip(x[0], 0.1, 0.9) * dij); kap = np.clip(x[1:], kmin, kmax)
            oi, oj = _ov(mu_, kap, i), _ov(mu_, kap, j)
            return 5000 * ((oi - ov_target) ** 2 + (oj - ov_target) ** 2) - _ess(mu_, kap)
        best = (1e18, None)
        for t in np.linspace(0.25, 0.75, 9):
            for ka in np.geomspace(kmin, kmax, 8):
                for kb in np.geomspace(kmin, kmax, 8):
                    v = obj([t, ka, kb])
                    if v < best[0]:
                        best = (v, [t, ka, kb])
        r = minimize(obj, best[1], method="Nelder-Mead", options=dict(xatol=1e-3, fatol=1e-5, maxiter=8000))
        x = r.x; mu_ = _wrap(bmu[i] + np.clip(x[0], 0.1, 0.9) * dij); kap = np.clip(x[1:], kmin, kmax)
        return mu_, kap

    def build_chain(i, j):
        """Lay K windows evenly on the basin-connecting geodesic. Each window's width is set by the spacing
        s=D/(K+1): kappa=4/s^2 (sigma~s/2) gives ~0.6 overlap with each neighbour, so consecutive windows connect;
        the far basins are then automatically strongly walled. Add windows (increase K) until the CENTRE window's
        wall toward BOTH basins clears wall_min, so the interior of the chain cannot leak into either basin."""
        dij = _wrap(bmu[j] - bmu[i]); D = float(np.hypot(*dij))
        cmus = ckaps = None
        for K in range(2, chain_kmax + 1):
            s = D / (K + 1)
            kap = np.clip(np.full(bmu.shape[1], 4.0 / s ** 2), kmin, kmax)
            us = np.linspace(1.0 / (K + 1), K / (K + 1), K)
            cmus = [_wrap(bmu[i] + u * dij) for u in us]; ckaps = [kap.copy() for _ in cmus]
            mid = cmus[K // 2]
            if min(_wall(mid, kap, i), _wall(mid, kap, j)) >= wall_min:
                break
        return cmus, ckaps

    for ed in mst:
        if not ed["resolved"]:
            continue
        i, j = ed["i"], ed["j"]; mu_, kap = solve_bridge(i, j)
        if min(_wall(mu_, kap, i), _wall(mu_, kap, j)) >= wall_min:           # single window holds -> use it
            windows.append(Window(name=f"{bnames[i]}|{bnames[j]}", mu=mu_, kappa=kap, kind="bridge",
                                  ess=_ess(mu_, kap), endpoints=(i, j), overlaps=(_ov(mu_, kap, i), _ov(mu_, kap, j)),
                                  n_core=_ncore(mu_, kap)))
        else:                                                                # too weak to hold -> CHAIN of windows
            cmus, ckaps = build_chain(i, j)
            for kk, (c, ck) in enumerate(zip(cmus, ckaps)):
                windows.append(Window(name=f"{bnames[i]}|{bnames[j]}#{kk + 1}/{len(cmus)}", mu=c, kappa=ck, kind="bridge",
                                      ess=_ess(c, ck), endpoints=(i, j), overlaps=(_ov(c, ck, i), _ov(c, ck, j)),
                                      n_core=_ncore(c, ck)))

    # ---- coverage diagnostic: window-orphaned / at-risk cold weight ----
    cov = np.max([np.exp(-(win.kappa * (1 - np.cos(_wrap(la - win.mu)))).sum(1)) for win in windows], axis=0)
    localess = np.array([(lambda s: float(s.sum() ** 2 / np.sum(s ** 2)) if np.sum(s ** 2) > 0 else 0.0)
                         (w[np.hypot(tor(land[:, 0] - land[k, 0]), tor(land[:, 1] - land[k, 1])) < radius])
                         for k in range(len(w))])
    orphan = cov < np.exp(-e_star); thin = localess < ess_thr
    coverage = dict(orphaned_frac=float(w[orphan].sum() / wtot), atrisk_frac=float(w[orphan & thin].sum() / wtot))

    return DesignResult(radius=radius, basin_names=bnames, basin_centres=bmu, basin_F=bF, mst=mst,
                        windows=windows, coverage=coverage)


# =============================== CLI / diagnostics =============================================================
def _alanine_namer(p, s):
    if p > 0:
        return "aL" if -90 < s < 120 else "C7ax"
    if s > 95:
        return "C7eq/b" if p > -110 else "C5/bII"
    return "PPII" if s > 55 else ("aR" if -70 < s < 55 else "C7ax'")


def print_design(res: DesignResult):
    nb = len(res.basin_names); brs = [w for w in res.windows if w.kind == "bridge"]
    print(f"design (r={res.radius:.0f} deg): {nb} basins -> {len(res.windows)} windows ({nb} basin + {len(brs)} bridge)")
    for w in res.windows:
        cd = np.degrees(w.mu); s = np.degrees(1 / np.sqrt(w.kappa))
        if w.kind == "basin":
            print(f"  basin  {w.name:<8} ({cd[0]:+4.0f},{cd[1]:+4.0f}) kappa=({w.kappa[0]:4.1f},{w.kappa[1]:4.1f}) "
                  f"ESS={w.ess:4.0f} {'ISOLATED' if w.isolated else 'connected'}")
        else:
            print(f"  bridge {w.name:<14} ({cd[0]:+4.0f},{cd[1]:+4.0f}) kappa=({w.kappa[0]:4.1f},{w.kappa[1]:4.1f}) "
                  f"sigma=({s[0]:2.0f},{s[1]:2.0f}) ov={w.overlaps[0]:.2f}/{w.overlaps[1]:.2f} ESS={w.ess:4.1f} n1={w.n_core}")
    print(f"coverage: window-orphaned {100*res.coverage['orphaned_frac']:.1f}%, "
          f"at-risk {100*res.coverage['atrisk_frac']:.1f}%")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Streamlined MST-guided umbrella design from PREP landings (test).")
    ap.add_argument("--run", required=True, help="coverage run dir or coverage_windows.npz")
    ap.add_argument("--prep", type=int, default=500, help="use the first N landings (the PREP pool)")
    ap.add_argument("--radius", type=float, default=RADIUS)
    ap.add_argument("--ov-target", type=float, default=OV_TARGET)
    ap.add_argument("--alanine-labels", action="store_true", help="use alanine Ramachandran basin names")
    ap.add_argument("--out", default=None, help="figure path (default: <run>/figures/prep_umbrella_design.png)")
    ap.add_argument("--no-plot", action="store_true")
    args = ap.parse_args(argv)

    p = Path(args.run); p = p / "coverage_windows.npz" if p.is_dir() else p
    z = np.load(str(p)); la = np.asarray(z["land_ang"], float)[:args.prep]; work = np.asarray(z["Wf"], float)[:args.prep]
    res = design_from_prep(la, work, radius=args.radius, ov_target=args.ov_target,
                           basin_namer=_alanine_namer if args.alanine_labels else None)
    print_design(res)
    if not args.no_plot:
        out = Path(args.out) if args.out else (p.parent / "figures" / "prep_umbrella_design.png")
        out.parent.mkdir(parents=True, exist_ok=True)
        _plot(res, la, work, out)


def _plot(res: DesignResult, land_ang, work, out_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Ellipse
    from matplotlib.lines import Line2D
    from scipy.ndimage import gaussian_filter as gf
    la = np.asarray(land_ang, float); land = np.degrees(la); w = np.exp(-(work - np.min(work)))
    G = 120; e = np.linspace(-180, 180, G + 1); ctr = 0.5 * (e[:-1] + e[1:])
    F = -np.log(gf(np.histogram2d(land[:, 0], land[:, 1], bins=(e, e), weights=w)[0], res.radius / (360 / G), mode="wrap") / w.sum() + 1e-12)
    F -= F.min()
    fig, ax = plt.subplots(figsize=(10, 8.6))
    ax.contourf(ctr, ctr, np.clip(F, 0, 8).T, levels=np.linspace(0, 8, 17), cmap="Greys", alpha=0.45, extend="max")
    for win in res.windows:
        cd = np.degrees(win.mu); s = np.degrees(1 / np.sqrt(win.kappa))
        col = "#1f77b4" if win.kind == "basin" else "#2ca02c"; mk = "o" if win.kind == "basin" else "X"
        ax.add_patch(Ellipse(cd, 2 * s[0], 2 * s[1], fill=False, edgecolor=col, lw=2.2, zorder=5))
        ax.plot(*cd, mk, color=col, ms=11, markeredgecolor="k", zorder=6)
        ax.annotate(win.name, cd, fontsize=8, ha="center", va="bottom", xytext=(0, 10), textcoords="offset points", fontweight="bold", zorder=7)
        if win.kind == "bridge":
            for m, o in zip(win.endpoints, win.overlaps):
                p = np.degrees(res.basin_centres[m]); ax.plot([cd[0], p[0]], [cd[1], p[1]], "-", color="#2ca02c", lw=2.2, alpha=0.8, zorder=3)
                ax.annotate(f"{o:.2f}", 0.5 * (cd + p), fontsize=8, ha="center", va="center", fontweight="bold", zorder=7,
                            bbox=dict(boxstyle="round,pad=0.1", fc="white", ec="none", alpha=0.85))
    ax.legend(handles=[Line2D([], [], marker="o", color="w", markerfacecolor="#1f77b4", markeredgecolor="k", ms=11, label="basin window"),
                       Line2D([], [], marker="X", color="w", markerfacecolor="#2ca02c", markeredgecolor="k", ms=12, label="confident bridge (ov≈%.2f)" % OV_TARGET)],
              loc="lower right", fontsize=8)
    nb = len(res.basin_names)
    ax.set_title(f"Streamlined PREP umbrella design (r={res.radius:.0f}°): {nb} basins + {len(res.windows)-nb} bridges\n"
                 f"window-orphaned cold weight {100*res.coverage['orphaned_frac']:.1f}%")
    ax.set_xlabel("φ (deg)"); ax.set_ylabel("ψ (deg)"); ax.set_xlim(-180, 180); ax.set_ylim(-180, 180); ax.grid(alpha=0.2)
    fig.tight_layout(); fig.savefig(str(out_path), dpi=125); plt.close(fig)
    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
