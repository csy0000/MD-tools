"""disjoint_flatbottom_windows.py — flat-bottom umbrellas with provably NON-OVERLAPPING cores,
populated by importance sampling from the cold-weighted AIS pool.

Two design choices, both requested explicitly:

**1. The flat cores must not overlap.**  The restraint is the validated torus-periodic radial form

    D_m(x) = Σ_t 2[1 − cos(θ_t − μ_{t,m})],   U_m(x) = ½ k_m · max(0, √D_m − h_m)²

and ``√D`` is a genuine metric on the torus — it is the Euclidean distance in the ``(cos, sin)``
embedding — so the flat core of window ``m`` is exactly the metric ball ``B(μ_m, h_m)``.  Two
cores are therefore disjoint **iff**

    d(μ_m, μ_n)  >  h_m + h_n .

:func:`disjoint_core_radii` returns radii that satisfy this by construction (and then grows them
greedily to use the available room), :func:`verify_disjoint_cores` proves it two ways — the
pairwise inequality and a brute-force grid scan.

Why it matters: a configuration inside two flat cores is unbiased under both restraints at once,
so the two "windows" sample the same distribution there and their samples are not attributable
to one window.  Disjoint cores make the assignment unambiguous — each configuration in a core
belongs to exactly one window — which is what a stratified proposal set needs.

**2. The window ensembles are built by importance sampling, not by restrained MD.**  Given the
cold-weighted AIS pool ``{x_i, w_i}`` (``w_i = e^{−W_i}`` for landings, or the Hummer–Szabo
weight for intermediate slices), the target for window ``m`` is

    π_m(x) ∝ e^{−u_C(x)} e^{−U_m(x)}          (the restrained cold ensemble)

so reweighting the pool by the acceptance ratio ``∝ exp(−U_m(x))`` and resampling gives draws
from ``π_m`` with no extra MD at all:

    w_i^{(m)} ∝ w_i · exp(−U_m(x_i)) .

Inside the core ``U_m = 0``, so core configurations keep their full cold weight; outside they are
exponentially suppressed by the wall.  The cost is entirely accounting; the honest limitation is
that this can only resample configurations the pool already contains, so :func:`window_ensembles`
reports per-window ESS and distinct-configuration counts, and :func:`core_coverage` reports how
much cold weight falls outside every core.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

__all__ = [
    "torus_D",
    "chord_distance_matrix",
    "disjoint_core_radii",
    "wall_stiffness_for_E_star",
    "design_disjoint_windows",
    "verify_disjoint_cores",
    "core_coverage",
    "window_ensembles",
    "Window",
]

E_STAR_DEFAULT = 3.0        # free-energy wall height in kT (project invariant)
K_MIN, K_MAX = 3.0, 50.0    # per-window wall stiffness clamp (kT per unit sqrt(D))


# ─────────────────────────────── geometry ────────────────────────────────────
def torus_D(angles, centre) -> np.ndarray:
    """``D = Σ_t 2[1 − cos(θ_t − μ_t)]``; angles in radians, shape (..., d)."""
    a = np.asarray(angles, float)
    c = np.asarray(centre, float)
    return np.sum(2.0 * (1.0 - np.cos(a - c)), axis=-1)


def chord_distance_matrix(mu) -> np.ndarray:
    """Pairwise ``√D`` between window centres — the metric the flat core lives in."""
    mu = np.atleast_2d(np.asarray(mu, float))
    K = len(mu)
    out = np.zeros((K, K))
    for i in range(K):
        out[i] = np.sqrt(np.clip(torus_D(mu, mu[i]), 0.0, None))
    np.fill_diagonal(out, 0.0)
    return out


def disjoint_core_radii(mu, h_max=None, margin: float = 0.05, n_grow: int = 50,
                        h_floor: float = 0.05) -> np.ndarray:
    """Core radii guaranteeing ``h_m + h_n ≤ (1 − margin)·d(μ_m, μ_n)`` for all m ≠ n.

    Starts from the always-safe ``h_m = ½ min_n d_mn`` (then ``h_m + h_n ≤ d_mn`` trivially) and
    grows each radius greedily into whatever room its neighbours leave, so an isolated component
    is not penalised by a crowded pair elsewhere.  ``h_max`` optionally caps each window (e.g. by
    its own vM width, so a core cannot spill beyond the basin it represents).
    """
    mu = np.atleast_2d(np.asarray(mu, float))
    K = len(mu)
    d = chord_distance_matrix(mu)
    budget = (1.0 - float(margin)) * d
    if K == 1:
        h = np.array([h_max[0] if h_max is not None else 1.0], float)
        return np.maximum(h, h_floor)

    off = ~np.eye(K, dtype=bool)
    h = np.array([0.5 * budget[i][off[i]].min() for i in range(K)], float)

    for _ in range(int(n_grow)):                       # grow into the remaining room
        h_new = h.copy()
        for i in range(K):
            room = np.min([budget[i, j] - h[j] for j in range(K) if j != i])
            h_new[i] = max(h_floor, min(room, h_max[i] if h_max is not None else np.inf))
        if np.allclose(h_new, h, atol=1e-12):
            h = h_new
            break
        h = h_new

    # final safety pass: shrink any pair that still violates the constraint
    for _ in range(K * K):
        bad = [(i, j) for i in range(K) for j in range(i + 1, K)
               if h[i] + h[j] > budget[i, j]]
        if not bad:
            break
        for i, j in bad:
            excess = h[i] + h[j] - budget[i, j]
            tot = h[i] + h[j]
            h[i] -= excess * h[i] / tot
            h[j] -= excess * h[j] / tot
    return np.maximum(h, 0.0)


def wall_stiffness_for_E_star(d_nearest, h, E_star: float = E_STAR_DEFAULT,
                              k_min: float = K_MIN, k_max: float = K_MAX) -> np.ndarray:
    """``k`` such that ``U = ½k(d_nearest − h)² ≥ E*`` at the nearest neighbouring centre."""
    reach = np.maximum(np.asarray(d_nearest, float) - np.asarray(h, float), 1e-6)
    return np.clip(2.0 * float(E_star) / reach ** 2, k_min, k_max)


# ─────────────────────────────── the design ──────────────────────────────────
@dataclass
class Window:
    index: int
    phi_ref: np.ndarray          # (d,) centre, radians
    hw_lin: float                # flat-core radius h in sqrt(D) units
    k_kT: float                  # wall stiffness, kT per unit sqrt(D)
    mixture_weight: float = float("nan")
    kappa: Optional[np.ndarray] = None
    label: str = ""
    nearest_centre_distance: float = float("nan")
    nearest_index: int = -1

    def bias_kT(self, angles) -> np.ndarray:
        d = np.sqrt(np.clip(torus_D(angles, self.phi_ref), 0.0, None))
        return 0.5 * self.k_kT * np.clip(d - self.hw_lin, 0.0, None) ** 2

    def in_core(self, angles) -> np.ndarray:
        return np.sqrt(np.clip(torus_D(angles, self.phi_ref), 0.0, None)) <= self.hw_lin

    def as_dict(self) -> dict:
        return dict(index=self.index, phi_ref=list(map(float, self.phi_ref)),
                    phi_ref_deg=[float(np.degrees(x)) for x in self.phi_ref],
                    hw_lin=float(self.hw_lin), k_kT=float(self.k_kT),
                    mixture_weight=float(self.mixture_weight), label=self.label,
                    nearest_centre_distance=float(self.nearest_centre_distance),
                    nearest_index=int(self.nearest_index),
                    kappa=(None if self.kappa is None else list(map(float, self.kappa))))


def design_disjoint_windows(mu, mixture_weights=None, kappa=None, labels=None,
                            E_star: float = E_STAR_DEFAULT, margin: float = 0.05,
                            h_cap_from_kappa: bool = True,
                            h_cap_sigma: float = 1.0) -> list[Window]:
    """Build flat-bottom windows with pairwise-disjoint cores from vM mixture components.

    ``h_cap_from_kappa`` caps each core by the component's own angular width, ``h ≤ σ_chord``
    with ``σ_chord = sqrt(Σ_t 1/κ_t)`` (the small-angle chord width of a vM with concentration
    κ), so a core never claims more of the torus than the density it was fitted to.
    """
    mu = np.atleast_2d(np.asarray(mu, float))
    K = len(mu)
    d = chord_distance_matrix(mu)
    off = ~np.eye(K, dtype=bool)

    h_max = None
    if h_cap_from_kappa and kappa is not None:
        kap = np.atleast_2d(np.asarray(kappa, float))
        h_max = h_cap_sigma * np.sqrt(np.sum(1.0 / np.clip(kap, 1e-6, None), axis=1))
    h = disjoint_core_radii(mu, h_max=h_max, margin=margin)

    nearest = np.array([np.argmin(np.where(off[i], d[i], np.inf)) for i in range(K)])
    d_near = np.array([d[i, nearest[i]] for i in range(K)])
    k = wall_stiffness_for_E_star(d_near, h, E_star)

    w = (np.full(K, 1.0 / K) if mixture_weights is None
         else np.asarray(mixture_weights, float))
    out = []
    for i in range(K):
        out.append(Window(index=i, phi_ref=mu[i], hw_lin=float(h[i]), k_kT=float(k[i]),
                          mixture_weight=float(w[i]),
                          kappa=(None if kappa is None else np.asarray(kappa)[i]),
                          label=("" if labels is None else str(labels[i])),
                          nearest_centre_distance=float(d_near[i]),
                          nearest_index=int(nearest[i])))
    return out


# ─────────────────────────────── verification ────────────────────────────────
def verify_disjoint_cores(windows: Sequence[Window], n_grid: int = 240,
                          strict: bool = True) -> dict:
    """Prove the cores are disjoint, both analytically and by brute force.

    (a) pairwise: ``h_m + h_n < d(μ_m, μ_n)`` for every pair;
    (b) grid scan: no point of a dense periodic grid lies inside two cores.
    """
    mu = np.array([w.phi_ref for w in windows], float)
    h = np.array([w.hw_lin for w in windows], float)
    K, dim = mu.shape
    d = chord_distance_matrix(mu)

    pairs = []
    worst = np.inf
    for i in range(K):
        for j in range(i + 1, K):
            slack = d[i, j] - (h[i] + h[j])
            worst = min(worst, slack)
            pairs.append(dict(i=i, j=j, centre_distance=float(d[i, j]),
                              h_sum=float(h[i] + h[j]), slack=float(slack),
                              disjoint=bool(slack > 0)))
    analytic_ok = all(p["disjoint"] for p in pairs)

    grid_ok, max_multi, frac_covered = True, 0, float("nan")
    if dim == 2:
        g = np.linspace(-np.pi, np.pi, int(n_grid), endpoint=False)
        P, Q = np.meshgrid(g, g, indexing="ij")
        pts = np.column_stack([P.ravel(), Q.ravel()])
        inside = np.zeros(len(pts), int)
        for w in windows:
            inside += w.in_core(pts).astype(int)
        max_multi = int(inside.max())
        grid_ok = max_multi <= 1
        frac_covered = float(np.mean(inside > 0))

    res = dict(n_windows=K, analytic_disjoint=analytic_ok, min_pair_slack=float(worst),
               grid_disjoint=grid_ok, max_windows_covering_a_point=max_multi,
               torus_fraction_inside_some_core=frac_covered, pairs=pairs,
               h=[float(x) for x in h])
    if strict and not (analytic_ok and grid_ok):
        raise ValueError(f"flat-bottom cores OVERLAP: {res}")
    return res


def core_coverage(angles, log_weights, windows: Sequence[Window]) -> dict:
    """How much cold weight lands inside some core, and how it splits between windows."""
    a = np.asarray(angles, float)
    lw = np.asarray(log_weights, float)
    w = np.exp(lw - lw.max())
    w = w / w.sum()
    inside = np.zeros(len(a), int)
    per = {}
    for win in windows:
        m = win.in_core(a)
        inside += m.astype(int)
        per[win.index] = dict(label=win.label, n_samples=int(m.sum()),
                              cold_weight=float(w[m].sum()))
    return dict(weight_inside_any_core=float(w[inside > 0].sum()),
                weight_outside_every_core=float(w[inside == 0].sum()),
                n_samples_in_multiple_cores=int((inside > 1).sum()),
                per_window=per)


# ────────────────────── importance-sampling construction ─────────────────────
def window_ensembles(angles, log_weights, windows: Sequence[Window], n_target: int = 500,
                     seed: int = 0, coordinates=None) -> dict:
    """Draw each window's proposal ensemble from the cold pool by acceptance ∝ exp(−U_m).

    ``w_i^{(m)} ∝ w_i · exp(−U_m(x_i))`` followed by systematic resampling.  No MD is run.
    Reports, per window: ESS of the reweighted pool, number of DISTINCT configurations drawn,
    and the fraction of the drawn ensemble that sits inside the flat core (where the restraint is
    exactly zero and the samples are unbiased cold samples).
    """
    from escort_ais.common.resampling import systematic_resample

    a = np.asarray(angles, float)
    lw0 = np.asarray(log_weights, float)
    rng = np.random.default_rng(seed)
    out = {}
    for win in windows:
        lw = lw0 - win.bias_kT(a)                       # log w_i + log exp(-U_m)
        lw = lw - lw.max()
        w = np.exp(lw)
        tot = w.sum()
        if tot <= 0:
            out[win.index] = dict(error="zero total weight")
            continue
        p = w / tot
        ess = float(1.0 / np.sum(p ** 2))
        idx = np.asarray(systematic_resample(lw, int(n_target), rng), int)   # takes LOG weights
        in_core = win.in_core(a[idx])
        rec = dict(label=win.label, index=win.index, hw_lin=win.hw_lin, k_kT=win.k_kT,
                   phi_ref_deg=[float(np.degrees(x)) for x in win.phi_ref],
                   pool_ess=ess, pool_ess_fraction=ess / len(a),
                   n_drawn=int(len(idx)), n_distinct=int(len(np.unique(idx))),
                   frac_drawn_in_core=float(in_core.mean()),
                   max_single_weight=float(p.max()),
                   mean_bias_kT=float(np.mean(win.bias_kT(a[idx]))),
                   indices=idx.tolist())
        if coordinates is not None:
            rec["coordinates"] = np.asarray(coordinates)[idx]
        out[win.index] = rec
    return out
