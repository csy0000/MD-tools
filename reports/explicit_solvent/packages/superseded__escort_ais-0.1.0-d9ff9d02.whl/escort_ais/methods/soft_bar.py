#!/usr/bin/env python3
"""soft_bar.py — soft flat-bottom / bias BAR for BAUS.

Extracted from the (archived) BAIS core `bais.py` so the BAUS umbrella path has no BAIS dependency. Provides
`basin_free_energies_soft`: the per-window soft-BAR that turns forward (H→C) and reverse (C→H) AIS works into
per-window free energies, with a FINITE forward final-step umbrella perturbation (flat-bottom wall by default, or
any `bias_fn` such as the anisotropic von Mises `coverage_windows.bias_u`). Reverse works must already carry the
matching −U_bias(x_start) debias (the coverage/US drivers do this)."""
from __future__ import annotations

import numpy as np

from escort_ais.methods.endpoint_bar import (_ais_delta_g, _overlap_score, endpoint_restricted_bar,
                                             solve_bar_with_infinite_works)


def basin_free_energies(Wf, land_basin, Wr, rev_start_basin, nb, ref_basin=None, bootstrap=False, n_boot=200, rng=None):
    """HARD endpoint-restricted BAR per basin — the ∞-padded conditional BAR (`endpoint_restricted_bar`) that the
    soft-BAR below reduces to in the crisp (large-E*) limit. Kept alongside the soft variant as its reference.

    Wf, land_basin : forward reduced works (= −logw, hot→cold) and cold LANDING basin per shot.
    Wr, rev_start_basin : reverse reduced works (= −logw, cold→hot) and cold START basin.
    Returns dict(dF, pi, ref_basin, diagnostics)."""
    if ref_basin is None:
        fwd = np.bincount(np.asarray(land_basin, int), minlength=nb).astype(float)
        has_rev = np.zeros(nb, bool)
        rsb = np.asarray(rev_start_basin, int)
        if rsb.size:
            has_rev[np.unique(rsb[(rsb >= 0) & (rsb < nb)])] = True
        ref_basin = int(np.argmax(fwd * has_rev)) if has_rev.any() else int(np.argmax(fwd))
    res = endpoint_restricted_bar(Wf, land_basin, Wr, rev_start_basin, list(range(nb)),
                                  reference_basin=ref_basin, bootstrap=bootstrap, n_bootstrap=n_boot, rng=rng)
    dF = np.array([res["ddF"][b] for b in range(nb)], float)          # F_b^cold − F_ref^cold (ref = 0)
    fin = np.isfinite(dF)
    pi = np.full(nb, np.nan)
    if fin.any():
        p = np.exp(-(dF[fin] - np.nanmin(dF[fin]))); pi[fin] = 0.0; pi[fin] = p / p.sum()
    return dict(dF=dF, pi=pi, ref_basin=ref_basin, diagnostics=res["diagnostics"],
                ddF_bootstrap=res.get("ddF_bootstrap_samples"))


def basin_free_energies_soft(Wf, land_ang, Wr, rev_start_basin, windows, ref_basin=None, bias_fn=None):
    """SOFT flat-bottom BAR: replaces the HARD ``b_end == B`` endpoint veto with a FINITE forward final-step
    perturbation — EVERY forward landing enters EVERY basin B with

        W_f^B = W_f + U_bias^B(x_land),   U_bias^B(x) = ½·k·max(0, √D_B(x) − hw_B)²      (flat-bottom wall)

    where D_B(x) = Σ_k 2(1−cos(φ_k(x) − φ_ref,B,k)) is the window-B CV. A landing far from B gets a large-but-
    FINITE work → soft down-weight, NOT a hard exclusion. Per basin, BAR is solved via
    `solve_bar_with_infinite_works` (n_f_total = ALL forward shots) with an AIS/Jarzynski (`_ais_delta_g`) fallback.
    In the CRISP / large-E* limit this reduces to the hard-veto endpoint BAR (asserted in
    `tests/test_bais_us_flatbottom.py`).

    Wf : (N_f,) forward reduced works (= −logw_f, hot→cold), for ALL forward shots.
    land_ang : (N_f, d) forward-landing defining-torsion angles in RADIANS.
    Wr, rev_start_basin : (N_r,) reverse reduced works and the cold basin each reverse shot STARTED from
        (the confined window for that basin under the flat-interior≈within-basin-Boltzmann approximation).
    windows : list of per-basin dicts with keys phi_ref (rad, d), hw_lin, k_kT (from `bais_us.design_windows`).
    bias_fn : optional callable ``bias_fn(land_ang, windows[B]) -> (N_f,)`` giving U_bias^B(x) in kT. Default (None)
        is the flat-bottom wall above. Pass e.g. ``coverage_windows.bias_u`` for the harmonic (von Mises) umbrella
        bias — same forward final-step perturbation, a different (smooth) restraint.
    Returns dict(dF, pi, ref_basin, diagnostics, soft_bar=True).
    """
    from escort_ais.methods.bais_us import flatbottom_bias_D, torsion_D
    Wf = np.asarray(Wf, float)
    land_ang = np.asarray(land_ang, float)
    Wr = np.asarray(Wr, float)
    rsb = np.asarray(rev_start_basin, int)
    nb = len(windows)
    n_f_total = len(Wf)

    dG = np.full(nb, np.nan); dG_ais = np.full(nb, np.nan); ovl = np.full(nb, np.nan)
    n_r_B = np.zeros(nb, int)
    for B in range(nb):
        if bias_fn is None:
            phi_ref = np.asarray(windows[B]["phi_ref"], float)
            DB = torsion_D(land_ang, phi_ref)                          # (N_f,) window-B CV per forward landing
            bias_B = flatbottom_bias_D(DB, windows[B]["hw_lin"], windows[B]["k_kT"])  # flat-bottom wall (default)
        else:
            bias_B = np.asarray(bias_fn(land_ang, windows[B]), float)  # e.g. harmonic von Mises bias_u
        Wf_B = Wf + bias_B                                             # +U_bias, FINITE (no hard veto)
        Wr_B = Wr[rsb == B]
        n_r_B[B] = int(Wr_B.size)
        if Wf_B.size == 0 or Wr_B.size == 0:
            continue
        dG_ais[B] = _ais_delta_g(Wf_B, n_f_total)
        dG[B], _ok = solve_bar_with_infinite_works(Wf_B, Wr_B, n_f_total=n_f_total, n_r_total=Wr_B.size)
        ovl[B] = _overlap_score(Wf_B, Wr_B)

    if ref_basin is None:                                             # prefer most-populated basin with reverse data
        has_rev = n_r_B > 0
        finite = np.isfinite(dG)
        cand = finite & has_rev
        ref_basin = int(np.argmax(cand)) if cand.any() else (int(np.argmax(finite)) if finite.any() else 0)

    gg = np.array([dG[b] if np.isfinite(dG[b]) else
                   (dG_ais[b] if np.isfinite(dG_ais[b]) else np.nan) for b in range(nb)])
    fin = np.isfinite(gg)
    dF = np.full(nb, np.nan); pi = np.full(nb, np.nan)
    if fin.any():
        gg = gg - np.nanmin(gg[fin])
        dF[fin] = gg[fin]
        p = np.exp(-gg[fin]); pi[fin] = p / p.sum()
    diagnostics = {b: dict(DeltaG_BAR=float(dG[b]) if np.isfinite(dG[b]) else None,
                           DeltaG_AIS=float(dG_ais[b]) if np.isfinite(dG_ais[b]) else None,
                           overlap_score=float(ovl[b]) if np.isfinite(ovl[b]) else None,
                           N_f_total=n_f_total, N_r=int(n_r_B[b])) for b in range(nb)}
    return dict(dF=dF, pi=pi, ref_basin=int(ref_basin), diagnostics=diagnostics, soft_bar=True)
