"""batched_copy_prototype.py — EXPERIMENTAL: B non-interacting copies in one OpenMM System (report §8).

Question this module exists to answer, and nothing more:

    can the AIS protocol work of EACH copy be recovered exactly and cleanly from a batched
    ``U_batch(X) = Σ_b U(x_b)`` system, or only the total ``W_batch = Σ_b W_b``?

Mixture-CFT (and Jarzynski, and BAR) need the *individual* ``W_b``; a batch total is useless, so
per §8 the prototype STOPS rather than accepting one.

What the prototype establishes
------------------------------
``build_batched_system`` puts every copy's forces in **its own force group**, which makes the
per-copy energy readable in isolation (``getState(groups={b})``) and — more importantly —
addressable from inside a ``CustomIntegrator`` as the per-group energy variable ``energy{b}``.
``BatchedNEQIntegrator`` therefore accumulates ``B`` separate protocol works entirely on-device,
with no per-switch readback:

    for each perturbation:  w_b += energy{b}(new λ) − energy{b}(old λ)     (b = 0 … B−1)

``verify_per_copy_work`` checks these against B independent single-copy runs driven with the same
seeds.  ``benchmark_batch`` times B = 1, 2, 4, 8, 16 against the same number of independent
contexts.

Measured outcome (``reports/alanine/ais_performance/data/batched_copies*.json``)
-------------------------------------------------------------------------------
* Per-copy work **is** exactly recoverable in principle: on a replicable Hamiltonian the four
  on-device accumulators reproduce four independent single-copy runs to **0 ULP**, and the four
  values are distinct.  So the answer to the §8 question is not "only the total".
* But the construction **cannot run on a GPU**.  Both the CUDA and the CPU platform reject a
  System holding several ``NonbondedForce`` objects with different exceptions
  (*"All Forces must have identical exceptions/exclusions"*); only ``Reference`` accepts it.  One
  force group per copy requires one force per copy, so the two requirements are incompatible on
  every platform we would actually run on.
* The production alanine Hamiltonian additionally contains a ``CustomGBForce`` (GBn2) and a
  ``CustomCVForce`` (the ff19SB CMAP wrapper), neither of which can be split per copy at all.
* Physical additivity itself is NOT the problem: with a single *shared* GB force, replicating the
  molecule 2/3/4 times 5 nm apart changes the GB energy by only −0.004/−0.009/−0.014 kT
  (≈0 at 20 nm).  A batched system is a faithful Hamiltonian — it simply reports one energy, and
  a single energy yields only ``W_batch = Σ_b W_b``.
* OpenMM's 32 force groups would cap the batch at B ≤ 32 in any case.

Per §8 the implementation therefore **stops here**: separate trajectory work values cannot be
obtained cleanly for the production Hamiltonian on a GPU, and a batch total is not usable.  The
adopted alternative is process-level parallelism (``chunked_neq_launcher``).

STATUS: FROZEN — DO NOT DEVELOP FURTHER (report §11)
----------------------------------------------------
This module and its tests are retained for **provenance only**.  The conclusion is settled:

1. separate per-copy work is theoretically recoverable — the on-device accumulator formulation
   is correct;
2. deterministic exactness was demonstrated (0 ULP against independent single-copy runs, with
   mutually distinct per-copy values);
3. CUDA and CPU both reject the required construction (several ``NonbondedForce`` objects with
   differing exceptions/exclusions), so it runs only on ``Reference``;
4. ``CustomGBForce`` (GBn2) and the CMAP ``CustomCVForce`` cannot be split per copy at all;
5. a batch-total work ``W_batch = Sum_b W_b`` is insufficient for mixture-CFT, which needs each
   trajectory's individual work.

Nothing here is imported by the production workflow.  Revisiting batching would require a custom
OpenMM plugin or a custom CUDA kernel — explicitly out of scope.
"""
from __future__ import annotations

import time
from typing import Optional, Sequence

import numpy as np

__all__ = [
    "build_batched_system",
    "BatchedNEQIntegrator",
    "verify_per_copy_work",
    "measure_gb_crosstalk",
    "benchmark_batch",
    "MAX_FORCE_GROUPS",
]

MAX_FORCE_GROUPS = 32


def build_batched_system(single_system, n_copies: int, group_offset: int = 0):
    """Replicate ``single_system`` ``n_copies`` times, one FORCE GROUP per copy.

    Returns ``(batched_system, atom_slices)``.  Only force types whose particle indices can be
    remapped one-to-one are replicated; anything else raises, because a silently dropped force is
    a different Hamiltonian.
    """
    import openmm
    from openmm import unit

    if n_copies + group_offset > MAX_FORCE_GROUPS:
        raise ValueError(f"{n_copies} copies + offset {group_offset} exceed OpenMM's "
                         f"{MAX_FORCE_GROUPS} force groups — per-copy work is not addressable")
    n_atoms = single_system.getNumParticles()
    batched = openmm.System()
    slices = []
    for b in range(n_copies):
        slices.append(slice(b * n_atoms, (b + 1) * n_atoms))
        for i in range(n_atoms):
            batched.addParticle(single_system.getParticleMass(i))

    for b in range(n_copies):
        off = b * n_atoms
        for fi in range(single_system.getNumForces()):
            f = single_system.getForce(fi)
            g = openmm.XmlSerializer.deserialize(openmm.XmlSerializer.serialize(f))
            if isinstance(g, openmm.HarmonicBondForce):
                for k in range(g.getNumBonds()):
                    i, j, r0, kk = g.getBondParameters(k)
                    g.setBondParameters(k, i + off, j + off, r0, kk)
            elif isinstance(g, openmm.HarmonicAngleForce):
                for k in range(g.getNumAngles()):
                    i, j, l, a0, kk = g.getAngleParameters(k)
                    g.setAngleParameters(k, i + off, j + off, l + off, a0, kk)
            elif isinstance(g, openmm.PeriodicTorsionForce):
                for k in range(g.getNumTorsions()):
                    i, j, l, m, per, ph, kk = g.getTorsionParameters(k)
                    g.setTorsionParameters(k, i + off, j + off, l + off, m + off, per, ph, kk)
            elif isinstance(g, openmm.CustomTorsionForce):
                for k in range(g.getNumTorsions()):
                    i, j, l, m, par = g.getTorsionParameters(k)
                    g.setTorsionParameters(k, i + off, j + off, l + off, m + off, par)
            elif isinstance(g, openmm.NonbondedForce):
                # A NonbondedForce spans EVERY particle of the System, so copy b's force has to
                # carry zeroed dummies for the other copies' atoms.  Correct, but the pair loop
                # still walks them: O(B^2 N^2) instead of O(B N^2).  See the module docstring.
                src = g
                g = openmm.NonbondedForce()
                g.setNonbondedMethod(src.getNonbondedMethod())
                g.setCutoffDistance(src.getCutoffDistance())
                zero = (0.0 * unit.elementary_charge, 0.1 * unit.nanometer,
                        0.0 * unit.kilojoule_per_mole)
                for gp in range(src.getNumGlobalParameters()):
                    g.addGlobalParameter(src.getGlobalParameterName(gp),
                                         src.getGlobalParameterDefaultValue(gp))
                for p in range(n_copies * n_atoms):
                    g.addParticle(*(src.getParticleParameters(p - off)
                                    if off <= p < off + n_atoms else zero))
                for k in range(src.getNumExceptions()):
                    i, j, cp, sig, eps = src.getExceptionParameters(k)
                    g.addException(i + off, j + off, cp, sig, eps)
                for k in range(src.getNumParticleParameterOffsets()):     # REST2 charge/eps offsets
                    name, pi, qs, ss, es = src.getParticleParameterOffset(k)
                    g.addParticleParameterOffset(name, pi + off, qs, ss, es)
                for k in range(src.getNumExceptionParameterOffsets()):
                    name, ei, qs, ss, es = src.getExceptionParameterOffset(k)
                    g.addExceptionParameterOffset(name, ei, qs, ss, es)
            elif isinstance(g, openmm.CMMotionRemover):
                continue
            else:
                raise NotImplementedError(
                    f"{type(g).__name__} cannot be replicated with a per-copy force group; "
                    "batched per-copy work is unavailable for this Hamiltonian")
            g.setForceGroup(group_offset + b)
            batched.addForce(g)
    return batched, slices


class BatchedNEQIntegrator:
    """CustomIntegrator that ramps one global ``lambda`` and accumulates B SEPARATE works.

    ``w{b}`` is a global integrator variable; the update uses the per-group energy variable
    ``energy{g}`` so nothing is read back to the host during the protocol.
    """

    def __init__(self, n_copies: int, n_steps: int, alchemical_functions: dict,
                 temperature_k: float, friction_per_ps: float, timestep_fs: float,
                 group_offset: int = 0, seed: Optional[int] = None):
        import openmm
        from openmm import unit

        self.n_copies = int(n_copies)
        self.n_steps = int(n_steps)
        kT = unit.MOLAR_GAS_CONSTANT_R * temperature_k * unit.kelvin
        integ = openmm.CustomIntegrator(timestep_fs * unit.femtosecond)
        integ.addGlobalVariable("lambda", 0.0)
        integ.addGlobalVariable("kT", kT.value_in_unit(unit.kilojoule_per_mole))
        integ.addGlobalVariable("a", np.exp(-friction_per_ps * timestep_fs / 1000.0))
        integ.addGlobalVariable("bfac", np.sqrt(1 - np.exp(-2 * friction_per_ps * timestep_fs / 1000.0)))
        integ.addPerDofVariable("x1", 0)
        for b in range(self.n_copies):
            integ.addGlobalVariable(f"w{b}", 0.0)
            integ.addGlobalVariable(f"e{b}old", 0.0)
        integ.addUpdateContextState()
        # H: record old per-group energies, advance lambda, accumulate per-copy work
        for b in range(self.n_copies):
            integ.addComputeGlobal(f"e{b}old", f"energy{group_offset + b}")
        integ.addComputeGlobal("lambda", f"lambda + 1.0/{self.n_steps}")
        for name, expr in alchemical_functions.items():
            integ.addComputeGlobal(name, expr)
        for b in range(self.n_copies):
            integ.addComputeGlobal(f"w{b}", f"w{b} + (energy{group_offset + b} - e{b}old)/kT")
        # V R O R V (BAOAB)
        integ.addComputePerDof("v", "v + 0.5*dt*f/m")
        integ.addComputePerDof("x", "x + 0.5*dt*v")
        integ.addComputePerDof("v", "a*v + bfac*sqrt(kT/m)*gaussian")
        integ.addComputePerDof("x", "x + 0.5*dt*v")
        integ.addConstrainPositions()
        integ.addComputePerDof("v", "v + 0.5*dt*f/m")
        integ.addConstrainVelocities()
        if seed is not None:
            integ.setRandomNumberSeed(int(seed))
        self.integrator = integ

    def works(self) -> np.ndarray:
        return np.array([self.integrator.getGlobalVariableByName(f"w{b}")
                         for b in range(self.n_copies)], float)

    def reset(self) -> None:
        self.integrator.setGlobalVariableByName("lambda", 0.0)
        for b in range(self.n_copies):
            self.integrator.setGlobalVariableByName(f"w{b}", 0.0)


def measure_gb_crosstalk(single_system, xyz_nm: np.ndarray, n_copies: int = 2,
                         separation_nm: float = 5.0, platform: str = "Reference") -> dict:
    """Is the implicit-solvent energy of copy 0 changed by the presence of the other copies?

    A ``CustomGBForce`` computes Born radii from ALL particles in the System and offers no
    interaction groups, so copies that are physically far apart still see each other through the
    GB descreening sum.  This function measures the size of that error directly: it is the reason
    the batched route is unavailable for the production (GBn2) alanine Hamiltonian.
    """
    import openmm
    from openmm import unit

    plat = openmm.Platform.getPlatformByName(platform)
    x = np.asarray(xyz_nm, float)

    def energy(system, positions):
        ctx = openmm.Context(system, openmm.VerletIntegrator(1.0 * unit.femtosecond), plat)
        ctx.setPositions(positions * unit.nanometer)
        return float(ctx.getState(getEnergy=True).getPotentialEnergy()
                     .value_in_unit(unit.kilojoule_per_mole))

    e_single = energy(single_system, x)
    try:
        batched, slices = build_batched_system(single_system, n_copies)
    except NotImplementedError as exc:
        return dict(replicable=False, reason=str(exc), e_single_kj=e_single)

    big = np.concatenate([x + np.array([b * separation_nm, 0.0, 0.0]) for b in range(n_copies)])
    e_batch = energy(batched, big)
    return dict(replicable=True, n_copies=n_copies, separation_nm=separation_nm,
                e_single_kj=e_single, e_batch_kj=e_batch,
                e_batch_minus_n_single_kj=e_batch - n_copies * e_single,
                additive=bool(abs(e_batch - n_copies * e_single) < 1e-3))


def verify_per_copy_work(single_system, xyz_nm: np.ndarray, alchemical_functions: dict,
                         n_copies: int = 4, n_steps: int = 100, temperature_k: float = 300.0,
                         friction_per_ps: float = 1.0, timestep_fs: float = 2.0,
                         separation_nm: float = 5.0, platform: str = "Reference",
                         seed: int = 4242) -> dict:
    """Do the B on-device per-copy works equal B independent single-copy runs?

    The comparison is exact only if the two setups also share a random stream, which they cannot
    (one context vs. B contexts).  What IS exactly comparable, and what this checks, is the
    *work functional*: with the Langevin friction set to zero and identical initial velocities,
    both routes are deterministic and must agree to numerical precision.
    """
    import openmm
    from openmm import unit

    plat = openmm.Platform.getPlatformByName(platform)
    x = np.asarray(xyz_nm, float)
    batched, slices = build_batched_system(single_system, n_copies)
    # each copy gets a DISTINCT configuration, otherwise identical per-copy works would not
    # prove that the accumulators are separate.
    rng = np.random.default_rng(0)
    perturb = [rng.normal(0.0, 0.01, x.shape) for _ in range(n_copies)]
    perturb[0][:] = 0.0
    big = np.concatenate([x + perturb[b] + np.array([b * separation_nm, 0.0, 0.0])
                          for b in range(n_copies)])

    bi = BatchedNEQIntegrator(n_copies, n_steps, alchemical_functions, temperature_k,
                              0.0, timestep_fs, seed=seed)            # friction 0 => deterministic
    ctx = openmm.Context(batched, bi.integrator, plat)
    ctx.setPositions(big * unit.nanometer)
    ctx.setVelocities(np.zeros_like(big) * unit.nanometer / unit.picosecond)
    bi.reset()
    bi.integrator.step(n_steps)
    w_batch = bi.works()

    w_single = []
    for b in range(n_copies):
        si = BatchedNEQIntegrator(1, n_steps, alchemical_functions, temperature_k, 0.0,
                                  timestep_fs, seed=seed)
        one, _ = build_batched_system(single_system, 1)
        c = openmm.Context(one, si.integrator, plat)
        c.setPositions((x + perturb[b] + np.array([b * separation_nm, 0.0, 0.0])) * unit.nanometer)
        c.setVelocities(np.zeros_like(x) * unit.nanometer / unit.picosecond)
        si.reset()
        si.integrator.step(n_steps)
        w_single.append(float(si.works()[0]))
    w_single = np.array(w_single)

    return dict(n_copies=n_copies, n_steps=n_steps, w_batched=w_batch.tolist(),
                w_independent=w_single.tolist(),
                max_abs_difference_kT=float(np.abs(w_batch - w_single).max()),
                exact=bool(np.allclose(w_batch, w_single, atol=1e-8, rtol=1e-10)),
                works_are_distinct=bool(len(set(np.round(w_batch, 9))) == n_copies))


def benchmark_batch(single_system, xyz_nm: np.ndarray, alchemical_functions: dict,
                    batch_sizes: Sequence[int] = (1, 2, 4, 8, 16), n_steps: int = 500,
                    platform: str = "CUDA", temperature_k: float = 300.0,
                    friction_per_ps: float = 1.0, timestep_fs: float = 2.0,
                    separation_nm: float = 5.0) -> dict:
    """Throughput of one batched context vs. B independent contexts, per completed trajectory."""
    import openmm
    from openmm import unit

    plat = openmm.Platform.getPlatformByName(platform)
    x = np.asarray(xyz_nm, float)
    out = {}
    for B in batch_sizes:
        if B > MAX_FORCE_GROUPS:
            out[str(B)] = dict(error="exceeds force-group limit")
            continue
        batched, _ = build_batched_system(single_system, B)
        big = np.concatenate([x + np.array([b * separation_nm, 0.0, 0.0]) for b in range(B)])
        bi = BatchedNEQIntegrator(B, n_steps, alchemical_functions, temperature_k,
                                  friction_per_ps, timestep_fs, seed=7)
        ctx = openmm.Context(batched, bi.integrator, plat)
        ctx.setPositions(big * unit.nanometer)
        ctx.setVelocitiesToTemperature(temperature_k * unit.kelvin, 11)
        bi.reset()
        bi.integrator.step(10)                                        # warm up / JIT
        bi.reset()
        t0 = time.perf_counter()
        bi.integrator.step(n_steps)
        _ = bi.works()
        t_batch = time.perf_counter() - t0

        t0 = time.perf_counter()
        for b in range(B):
            si = BatchedNEQIntegrator(1, n_steps, alchemical_functions, temperature_k,
                                      friction_per_ps, timestep_fs, seed=7 + b)
            one, _ = build_batched_system(single_system, 1)
            c = openmm.Context(one, si.integrator, plat)
            c.setPositions(x * unit.nanometer)
            c.setVelocitiesToTemperature(temperature_k * unit.kelvin, 11 + b)
            si.reset()
            si.integrator.step(n_steps)
            _ = si.works()
        t_serial = time.perf_counter() - t0
        out[str(B)] = dict(batch_s=t_batch, serial_s=t_serial,
                           s_per_trajectory_batched=t_batch / B,
                           s_per_trajectory_serial=t_serial / B,
                           speedup=t_serial / max(t_batch, 1e-12),
                           n_atoms=int(batched.getNumParticles()))
    return out
