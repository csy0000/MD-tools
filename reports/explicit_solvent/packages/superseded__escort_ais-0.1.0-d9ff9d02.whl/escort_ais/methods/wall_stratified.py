"""Wall-stratified conditional BAR: both AIS endpoints confined, the wall annealed along the switch.

WHAT THIS CHANGES. In mainstream conditional BAR the forward leg runs from the GLOBAL hot ensemble
to a wall-confined cold cell, and a leg is kept only if it happens to land in the cell it is being
used for. Measured on cyclo-(RGDfV) condbar_v2, that doubly-conditioned restriction is brutal for
the rare cell: of 397 legs launched from hot cell C2, only 171 landed in cold C2 -- a 43% hit rate,
and more of them (225) landed in C1 than in C2. C2's conditional term therefore rests on 171 of the
campaign's 9900 forward legs.

Here each cell gets its OWN confined hot ensemble H_m, so a leg starts inside the region it is meant
to sample and the hit rate is a design property rather than an accident. The estimand is unchanged:

    f^C_n - f^C_m = (f^C_n - f^H_n) - (f^C_m - f^H_m) + (f^H_n - f^H_m)
                    \_____ per-cell BAR over H_m -> C_m legs _____/   \__ MBAR over {H_n} __/

with the last term from MBAR across the hot confined ensembles instead of counting a single
unconfined walker.

THE INVARIANT THIS DEPARTS FROM, DELIBERATELY. ``conditional_bar_conventions`` states that no
restraint enters the physical work, and the test suite asserts the AIS system carries none. That
rule is correct for mainstream cBAR, where the wall only DEFINES the cold sub-ensembles and the
switch runs between unrestrained states. It is wrong here: both endpoints are defined WITH walls, so
the wall is part of the alchemical path and its contribution belongs in the work. This is a
different scheme, not a relaxation of the old one, and it needs its own decision record before any
result from it is compared with a mainstream cBAR number.

THE WALL SCHEDULE. With t the AIS progress variable in [0, 1],

    k(t) = (1 - sqrt(t)) * k_hot + sqrt(t) * k_cold  =  k_hot + (k_cold - k_hot) * sqrt(t)

so k(0) = k_hot and k(1) = k_cold. NOTE the variable is t, not the REST2 scale s: writing the same
expression in s (which runs s_hot -> 1, not 0 -> 1) gives k = 51.5 at the hot end for
k_hot=3, k_cold=100 -- a stiff wall exactly where the scheme needs a soft one, and the hot cells
would have overlap ~0.004 and be unusable by MBAR.

The sqrt shape is front-loaded: ~50% of the stiffening happens in the first quarter of the switch,
while the solute is still hot and mobile and can relax into the core. That direction is the
favourable one, but sqrt carries NO physical justification here -- unlike REST2's sqrt(s), which
follows from charges scaling as sqrt(s), the wall is a bias, not an interaction. The schedule is a
free choice and should be selected by measured dissipation, ``<W> + ln<e^{-W}>``, not by analogy.
``geometric_wall_schedule`` is provided as the alternative worth testing: for a stiffness spanning
25x, equal path length per e-fold is the natural parameterisation.

CHOOSING k_hot. Not by a schedule -- by the requirement that MBAR can actually solve
``f^H_n - f^H_m``. MBAR needs the overlap graph over {H_n} to be CONNECTED (one component; a
spanning tree suffices). Degree >= 1 per cell is NOT enough: two disjoint pairs satisfy it and leave
the free energies between components unidentifiable. So k_hot is solved as the STIFFEST wall whose
maximum-spanning-tree bottleneck still meets a target overlap. Measured on cyclo-(RGDfV):

    target Omega >= 0.4  ->  k_hot = 4.04     (binding edge C0-C1; C1-C2 already 0.652)
    target Omega >= 0.3  ->  k_hot = 5.03
    target Omega >= 0.2  ->  k_hot = 6.55

against a cold wall of 100. A ``sqrt(s)``-style schedule would have given k_hot = 50, where the
measured overlaps are 0.004 / 0.002 / 0.126 -- disconnected.

TWO WARNINGS ABOUT THOSE NUMBERS.
* k_hot ~ 4 is deep inside the regime where confinement stops confining. ``assign_walls`` records
  that at k = 12-14 alanine's smallest basin -- 0.29% of the mass with neighbours ~100x denser --
  leaked 60% of its own proposal mass. A hot wall this soft will leak; whether that matters depends
  on whether the leaked frames are still counted as H_m, which they are by construction here (the
  ensemble is defined by the bias, not by a hard boundary), but it does mean H_m is a much broader
  object than C_m and the two should never be described as "the same cell at two temperatures".
* A single global k_hot is wasteful. The binding edge is always the one involving the dominant cell;
  the others would stay connected at a far stiffer wall. ``solve_k_hot_per_cell`` allows each cell
  its own stiffness so only the cell that needs softening gets it.

DO NOT CONFUSE THE TWO OVERLAP THRESHOLDS. ``cell_overlap`` uses ``Omega > 0.2`` between COLD,
full-wall confined samples to mean "these two cells are one basin -- MERGE them". The threshold here
is on HOT, soft-wall ensembles and means "MBAR can bridge these two". Same statistic, different
ensembles, opposite conclusions. They must never be applied to each other's samples.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

from escort_ais.methods.nd_flatbottom import nd_bias_kT

class _IntervalAsArc:
    """Adapt ``barrier_partition.PeriodicInterval`` to the ``nd_basin_tree.Arc`` attribute names.

    Same geometry, different spelling: an Arc exposes ``lo``/``hi``, a PeriodicInterval
    ``lower``/``upper``. ``nd_flatbottom.arc_params`` reads the Arc names, so without this the
    wall silently fails to build for the 2-D partition.
    """

    __slots__ = ("lo", "hi", "full", "width")

    def __init__(self, iv):
        self.lo = float(iv.lower)
        self.hi = float(iv.upper)
        self.full = bool(iv.full)
        self.width = float(iv.width)


class _BasinAsCell:
    """Adapt a 2-D ``barrier_partition.RectangularBasin`` to the nd-cell interface.

    The two partition schemas expose different names for the same geometry: an nd cell has
    ``active_dims()`` and ``arcs[d]``, while a 2-D basin has ``active_walls`` (CV NAMES, not
    indices) and ``phi_interval``/``psi_interval``. Everything in this module is written against
    the nd interface, so alanine needs this shim rather than a parallel implementation -- one
    wall formula, two ways of naming its inputs.

    Dimension order follows the dipeptide CV definition, (phi, psi), which is the order
    ``cv_definition.compute`` returns and therefore the order of the angle columns.
    """

    _ORDER = ("phi", "psi")

    def __init__(self, basin):
        self._b = basin
        self.label = basin.label
        self.arcs = {0: _IntervalAsArc(basin.phi_interval),
                     1: _IntervalAsArc(basin.psi_interval)}

    def active_dims(self):
        # a full circle carries no wall, so it is not an active dimension whatever the name says
        names = (self._b.active_walls() if callable(self._b.active_walls)
                 else self._b.active_walls)
        return [i for i, nm in enumerate(self._ORDER)
                if nm in names and not self.arcs[i].full]


def as_nd_cells(cells):
    """Pass nd cells through; wrap 2-D basins. Accepts either schema."""
    return [c if hasattr(c, "active_dims") else _BasinAsCell(c) for c in cells]


#: Wall stiffness in kT/rad^2 used for the COLD (production) cells; see assign_walls for why 100.
K_COLD_DEFAULT = 100.0


# --------------------------------------------------------------- overlap between hot cells
def omega_matrix(angles_rad: np.ndarray, cells: Sequence, k_wall: float) -> np.ndarray:
    """Pairwise Bhattacharyya overlap between the confined ensembles at stiffness ``k_wall``.

    Both ensembles are reweightings of the SAME sample, which collapses the coefficient to one
    numerically stable expression:

        log Omega = logsumexp(-(U_m+U_n)/2) - 0.5*logsumexp(-U_m) - 0.5*logsumexp(-U_n)

    (the two cross expectations ``E_m[e^{-dU/2}]`` and ``E_n[e^{+dU/2}]`` share the numerator).
    Everything stays in log space: ``dU`` reaches tens of kT in the far wall region and the naive
    product of two exponentials underflows to 0.0, silently reporting "no overlap" -- which is
    indistinguishable from the real thing and is exactly the failure this scheme must detect.

    ``angles_rad`` should cover every cell's region; an unconfined hot pool reweighted this way is
    the usual source, in which case the far-wall tails are only as good as the frames the free
    walker happened to visit there. Overlaps between well-separated cells are the least reliable
    entries and should be treated as upper bounds on confidence, not on value.
    """
    from scipy.special import logsumexp

    a = np.atleast_2d(np.asarray(angles_rad, float))
    U = [nd_bias_kT(a, c, k_wall) for c in as_nd_cells(cells)]
    n = len(cells)
    out = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            lo = (logsumexp(-(U[i] + U[j]) / 2.0)
                  - 0.5 * logsumexp(-U[i]) - 0.5 * logsumexp(-U[j]))
            out[i, j] = out[j, i] = float(np.exp(lo))
    return out


#: default overlap target. Since 2026-08-11 this is a BAR overlap, not a Bhattacharyya one.
OVERLAP_TARGET_DEFAULT = 0.4


def bar_overlap_matrix(angles_rad: np.ndarray, cells: Sequence, k_wall: float,
                       bins: int = 80) -> np.ndarray:
    """Pairwise BAR overlap: the overlap AREA of the two windows' ``dU`` distributions.

    This is the quantity that decides whether BAR/MBAR between two windows is well conditioned,
    and it is NOT ``omega_matrix``. For the pair (i, j) the only energy difference is the wall,
    ``dU = U_j - U_i``, so:

        P_i(dU) = distribution of dU under window i     (weights e^{-U_i})
        P_j(dU) = distribution of dU under window j     (weights e^{-U_j})
        overlap = integral min(P_i, P_j)  in [0, 1]

    WHY THIS REPLACED THE BHATTACHARYYA TARGET (2026-08-11). Omega is a single overlap INTEGRAL and
    a modest number of well-placed configurations satisfies it, so it stays high while the two
    ensembles are already pulling apart. Measured on cilengitide's hot rung, the two criteria pick
    very different walls:

        Omega = 0.40  ->  k_hot 4.016,  BAR overlap there only 0.140
        BAR   = 0.40  ->  k_hot 2.174,  Omega there 0.719

    At the Omega-chosen wall the two windows' dU distributions had means +5.29 and -0.61 against
    standard deviations 2.2 and 1.7 -- MBAR carried by tails, not bulk -- and wall-cBAR's hot term
    came out +0.203 kT from REMD while the free hot walker used by normal/strat-cBAR was within
    -0.048. Omega is a connectivity measure; it was never a statement about BAR conditioning.

    Estimated by reweighting ONE sample into both windows, so it inherits that sample's coverage:
    an unconfined hot pool reweighted into a stiff wall has few frames in the far wall region and
    the overlap there is an upper bound on confidence, not on value.
    """
    a = np.atleast_2d(np.asarray(angles_rad, float))
    nd = as_nd_cells(cells)
    U = [nd_bias_kT(a, c, k_wall) for c in nd]
    n = len(cells)
    out = np.eye(n)
    for i in range(n):
        for j in range(i + 1, n):
            dU = U[j] - U[i]
            lo, hi = float(dU.min()), float(dU.max())
            if hi - lo < 1e-12:                     # identical windows: perfect overlap
                out[i, j] = out[j, i] = 1.0
                continue
            wi = np.exp(-(U[i] - U[i].min())); wi /= wi.sum()
            wj = np.exp(-(U[j] - U[j].min())); wj /= wj.sum()
            e = np.linspace(lo, hi, bins + 1); bw = e[1] - e[0]
            pi_, _ = np.histogram(dU, bins=e, weights=wi)
            pj_, _ = np.histogram(dU, bins=e, weights=wj)
            pi_ = pi_ / (pi_.sum() * bw); pj_ = pj_ / (pj_.sum() * bw)
            out[i, j] = out[j, i] = float(np.minimum(pi_, pj_).sum() * bw)
    return out


def overlap_matrix(angles_rad: np.ndarray, cells: Sequence, k_wall: float,
                   criterion: str = "bar") -> np.ndarray:
    """Dispatch to the chosen overlap metric. ``bar`` is the default since 2026-08-11."""
    if criterion == "bar":
        return bar_overlap_matrix(angles_rad, cells, k_wall)
    if criterion == "omega":
        return omega_matrix(angles_rad, cells, k_wall)
    raise ValueError(f"unknown overlap criterion {criterion!r}; use 'bar' or 'omega'")


def mst_bottleneck(omega: np.ndarray) -> float:
    """Smallest edge on the MAXIMUM spanning tree = largest threshold keeping the graph connected.

    This is the quantity to root-find on, not connectivity itself: connectivity is a boolean step
    function of ``k`` with no gradient, while the bottleneck is continuous and monotone decreasing
    in ``k``, so a bracketing solver is both correct and cheap.
    """
    a = np.asarray(omega, float)
    n = len(a)
    if n < 2:
        return 1.0
    in_tree, worst = {0}, 1.0
    while len(in_tree) < n:
        best_w, best_j = -1.0, None
        for i in in_tree:
            for j in range(n):
                if j not in in_tree and a[i, j] > best_w:
                    best_w, best_j = a[i, j], j
        if best_j is None:                       # disconnected even at zero threshold
            return 0.0
        worst = min(worst, best_w)
        in_tree.add(best_j)
    return float(worst)


def solve_k_hot(angles_rad: np.ndarray, cells: Sequence,
                target_overlap: float = OVERLAP_TARGET_DEFAULT,
                k_bracket: tuple[float, float] = (0.05, 500.0),
                xtol: float = 1e-3, criterion: str = "bar",
                target_omega: float | None = None) -> dict:
    """Stiffest single hot wall whose cells stay connected at ``target_overlap``.

    Root-find, not minimisation. Returns the solution plus BOTH overlap matrices at it, so the
    binding edge is visible and a run can be compared against either criterion afterwards -- if one
    pair sets the answer, ``solve_k_hot_per_cell`` will do better.

    Raises if the target is unreachable across the bracket, rather than returning an endpoint: a
    silently clipped k_hot would produce a scheme whose MBAR leg cannot close.

    ``criterion`` DEFAULTS TO ``"bar"`` SINCE 2026-08-11. It previously targeted the Bhattacharyya
    coefficient, which is a connectivity measure and is systematically optimistic about BAR
    conditioning: on cilengitide, Omega = 0.4 gives k_hot 4.016 where the BAR overlap is only 0.140,
    and that wall produced a hot term +0.203 kT from REMD. ``criterion="omega"`` reproduces the old
    behaviour for re-analysing pre-2026-08-11 runs; it is not a supported production setting.

    ``target_omega`` is accepted as a DEPRECATED alias for ``target_overlap`` so old call sites keep
    working, but it does NOT re-select the Bhattacharyya criterion -- pass ``criterion="omega"`` for
    that, deliberately, so no caller silently gets the old wall back by keyword name alone.
    """
    from scipy.optimize import brentq

    if target_omega is not None:
        target_overlap = float(target_omega)

    def f(k):
        return mst_bottleneck(overlap_matrix(angles_rad, cells, k, criterion)) - target_overlap

    lo, hi = k_bracket
    f_lo, f_hi = f(lo), f(hi)

    def _report(k):
        """Both matrices at the solution, so a run is comparable under either criterion."""
        A = overlap_matrix(angles_rad, cells, k, criterion)
        return A, dict(k_hot=float(k), bottleneck=float(mst_bottleneck(A)),
                       criterion=criterion, target=float(target_overlap),
                       overlap=A.tolist(),
                       bar_overlap=bar_overlap_matrix(angles_rad, cells, k).tolist(),
                       omega=omega_matrix(angles_rad, cells, k).tolist())

    if f_lo < 0:
        raise ValueError(
            f"even k={lo} gives bottleneck {f_lo + target_overlap:.4f} < {target_overlap} under "
            f"criterion {criterion!r}: the cells cannot be connected at this target by softening "
            "alone. Add bridging states or lower the target -- do not clip k_hot.")
    if f_hi > 0:
        _, out = _report(hi)
        out.update(clipped_at_max=True)
        return out
    k = float(brentq(f, lo, hi, xtol=xtol))
    A, out = _report(k)
    n = len(cells)
    binding = min(((A[i, j], i, j) for i in range(n) for j in range(i + 1, n)
                   if A[i, j] >= target_overlap - 1e-9), default=(np.nan, -1, -1))
    out.update(binding_edge=(int(binding[1]), int(binding[2])), clipped_at_max=False)
    return out


def solve_k_hot_per_cell(angles_rad: np.ndarray, cells: Sequence, target_omega: float = 0.4,
                         k_cold: float = K_COLD_DEFAULT,
                         k_floor: float = 0.05) -> np.ndarray:
    """Per-cell stiffness: soften only the cells that need it to keep the graph connected.

    A single global ``k_hot`` softens EVERY cell to accommodate the worst pair, which on
    cyclo-(RGDfV) means dropping C1 and C2 to k=4 when they would stay connected at far stiffer
    walls. Here each cell starts at ``k_cold`` and is softened only while it still has no edge
    meeting the target, greedily, cheapest-first.

    NOTE this is a heuristic, not an optimum: the overlap of a pair depends on BOTH cells'
    stiffnesses, so softening one changes every edge it touches. It is intended to beat the global
    solution, not to be optimal, and the returned array should be checked with ``omega_matrix_mixed``
    before use.
    """
    n = len(cells)
    k = np.full(n, float(k_cold))
    for _ in range(200):
        A = omega_matrix_mixed(angles_rad, cells, k)
        if mst_bottleneck(A) >= target_omega:
            return k
        # soften the cell with the weakest best-edge; that is what is holding the graph apart
        best_edge = np.array([max(A[i, j] for j in range(n) if j != i) for i in range(n)])
        i = int(np.argmin(best_edge))
        k[i] = max(k_floor, k[i] * 0.85)
        if k[i] <= k_floor:
            break
    return k


def omega_matrix_mixed(angles_rad: np.ndarray, cells: Sequence, k_per_cell) -> np.ndarray:
    """``omega_matrix`` with a per-cell stiffness vector rather than one global value."""
    from scipy.special import logsumexp

    a = np.atleast_2d(np.asarray(angles_rad, float))
    kk = np.asarray(k_per_cell, float)
    U = [nd_bias_kT(a, c, float(kk[i])) for i, c in enumerate(cells)]
    n = len(cells)
    out = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            lo = (logsumexp(-(U[i] + U[j]) / 2.0)
                  - 0.5 * logsumexp(-U[i]) - 0.5 * logsumexp(-U[j]))
            out[i, j] = out[j, i] = float(np.exp(lo))
    return out


# --------------------------------------------------------------- the annealed wall schedule
def sqrt_wall_schedule(k_hot: float, k_cold: float = K_COLD_DEFAULT) -> str:
    """``k(t) = k_hot + (k_cold - k_hot)*sqrt(t)`` as a Lepton expression in ``lambda``.

    ``lambda`` is the AIS progress variable the openmmtools NEQ integrator drives from 0 to 1, NOT
    the REST2 scale. Expressing this schedule in ``s`` instead is the mistake that puts a stiff wall
    at the hot endpoint.
    """
    return f"({float(k_hot)} + {float(k_cold) - float(k_hot)}*sqrt(lambda))"


def geometric_wall_schedule(k_hot: float, k_cold: float = K_COLD_DEFAULT) -> str:
    """``k(t) = k_hot * (k_cold/k_hot)**sqrt(t)`` -- equal path length per e-fold.

    The alternative worth testing against :func:`sqrt_wall_schedule` when the stiffness spans a
    large ratio (25x for k_hot=4, k_cold=100): linear-in-sqrt(t) spends most of the switch already
    near the cold stiffness, while the geometric form distributes the change multiplicatively.
    Which dissipates less is an empirical question -- compare ``<W> + ln<e^{-W}>`` per cell.
    """
    return f"({float(k_hot)}*({float(k_cold) / float(k_hot)})^sqrt(lambda))"


def wall_alchemical_functions(cell, k_hot: float, kT_kj: float,
                              k_cold: float = K_COLD_DEFAULT,
                              schedule: str = "sqrt") -> dict[str, str]:
    """Alchemical functions driving this cell's wall stiffness, to merge with the REST2 ones.

    ``build_nd_flatbottom_force`` already registers ``kw_t<d>`` as OpenMM GLOBAL PARAMETERS, which
    is exactly what ``AlchemicalNonequilibriumLangevinIntegrator`` drives -- so annealing the wall
    needs no new force machinery, only these entries alongside ``rest2_sqrt_s_minus_1`` and friends.

    UNITS. ``kw_*`` is stored in kJ/mol/rad^2 (``k * kT_kj``), not in kT, so the schedule is scaled
    by ``kT_kj`` here. Emitting a kT-unit expression would silently soften every wall by ~1/2.5 at
    300 K.

    Only ACTIVE dimensions appear: a dimension whose arc is the full circle carries no wall and no
    parameter, and inventing one would put a restraint where the partition has none.
    """
    fn = {"sqrt": sqrt_wall_schedule, "geometric": geometric_wall_schedule}[schedule]
    expr = fn(k_hot, k_cold)
    return {f"kw_t{int(d)}": f"{kT_kj}*{expr}" for d in cell.active_dims()}


def hot_wall_force(quartets, cell, kT_kj: float, k_hot: float, openmm=None):
    """The cell's flat-bottom force initialised at the HOT stiffness.

    Thin wrapper over ``build_nd_flatbottom_force`` so the caller cannot accidentally build the hot
    ensemble at the cold stiffness -- the failure mode that makes every hot cell disjoint and the
    MBAR leg unsolvable, while looking entirely normal in the logs.
    """
    from escort_ais.methods.nd_flatbottom import build_nd_flatbottom_force

    return build_nd_flatbottom_force(quartets, cell, kT_kj, k_wall=float(k_hot), openmm=openmm)


def build_coswitch_wall_force(quartets, cell, kT_kj: float, k_hot: float,
                              k_cold: float = K_COLD_DEFAULT, group: int = 29, openmm=None):
    """Flat-bottom wall whose stiffness is ANNEALED by the engine's existing ramp.

    ``k(t) = k_hot + (k_cold - k_hot) * sqrt(umbrella_lambda)``, i.e. the sqrt schedule, written
    into the ENERGY EXPRESSION rather than pushed in per step. Two things make this work without a
    second protocol coordinate:

    * the flat-bottom energy is LINEAR in k, so annealing the stiffness is exactly annealing the
      restraint -- no reparameterisation is needed;
    * ``umbrella_lambda`` is the same global parameter ``build_coswitch_umbrella_force`` uses, and
      the engine already ramps it 0 (hot) -> 1 (cold) on both leg directions. Declaring it here
      binds this force to that ramp; OpenMM shares one global parameter across forces.

    At ``umbrella_lambda = 1`` the expression is IDENTICALLY the production wall at ``k_cold``, so
    the cold endpoint is the ensemble the campaign already reports. That equality is what the
    scoped invariant exception rests on -- see
    docs/decisions/2026-08-10_wall-stratified-restraint-in-work.md.
    """
    if openmm is None:
        import openmm
    from escort_ais.methods.nd_flatbottom import arc_params

    cell = as_nd_cells([cell])[0]
    terms, cvs = [], {}
    for d in cell.active_dims():
        p = arc_params(cell.arcs[d], 1.0)          # k factored out; taken from the ramp below
        if p is None:
            continue
        _, mu, hw = p
        tag = "t%d" % d
        cv = openmm.CustomTorsionForce("theta")
        a, b, c, e = (int(x) for x in quartets[d])
        cv.addTorsion(a, b, c, e, [])
        cvs[tag] = (cv, mu, hw)
        terms.append(
            "0.5*(khot_{t} + dk_{t}*sqrt(umbrella_lambda))"
            "*max(0, acos(max(-1,min(1,cos({t}-mu_{t})))) - hw_{t})^2".format(t=tag))

    if not terms:
        f = openmm.CustomBondForce("0")
        f.setForceGroup(int(group))
        return f

    f = openmm.CustomCVForce(" + ".join(terms))
    for tag, (cv, mu, hw) in cvs.items():
        f.addCollectiveVariable(tag, cv)
        f.addGlobalParameter("khot_%s" % tag, float(k_hot) * kT_kj)
        f.addGlobalParameter("dk_%s" % tag, float(k_cold - k_hot) * kT_kj)
        f.addGlobalParameter("mu_%s" % tag, mu)
        f.addGlobalParameter("hw_%s" % tag, hw)
    f.addGlobalParameter("umbrella_lambda", 0.0)
    f.setForceGroup(int(group))
    return f


def make_hot_walled_walker(positions_nm, cell, k_hot: float, s_hot: float, seed: int,
                           platform_name: str = "CUDA", device=None):
    """A HOT walker (REST2 scale ``s_hot``) confined by the SOFT wall of ``cell``.

    This is the state ``H_m`` of the window-to-window identity

        C_m - C_n = (C_m - H_m) + (H_m - H_n) + (H_n - C_n)

    and it did not previously exist: ``condbar_walkers.make_hot_walker`` is unconfined and
    ``make_box_walker`` is cold at the production stiffness. It supplies BOTH things the estimator
    needs from the hot side -- the MBAR samples for ``H_m - H_n``, and the seeds for the co-switch
    NES legs.

    SEEDING THE LEGS FROM THIS WALKER IS NOT OPTIONAL. Drawing leg starts from the unconfined hot
    ensemble instead puts most of a rare cell's legs outside that cell (measured on alanine: 6% of
    B1's seeds were actually in B1), so the switch spends its work dragging the configuration
    across the barrier rather than measuring a free-energy difference. That inflated the observed
    dissipation to 27 kT and made forward-only Jarzynski unusable.
    """
    import mdtraj as md

    from escort_ais.methods import condbar_walkers as CW
    from escort_ais.systems.openmm_system import build_rest2_scaled_system

    base = CW.build_base_system()
    system = build_rest2_scaled_system(base, np.arange(CW.N_SOLUTE), float(s_hot))
    top = CW.load_topology()
    phi_q, psi_q = CW.torsion_quartets(top)
    quartets = np.vstack([phi_q, psi_q])
    system.addForce(build_coswitch_wall_force(quartets, cell, CW.KT_KJ, k_hot, k_hot))
    sim = CW._make_simulation(system, positions_nm, seed, platform_name, device)
    w = CW.Walker(name=f"H_{getattr(cell, 'label', '?')}_s{s_hot:g}", simulation=sim,
                  n_atoms=system.getNumParticles())
    w._mdtop = md.Topology.from_openmm(top)
    # the wall force reads `umbrella_lambda`; pin it at 0 so this walker stays at k_hot
    sim.context.setParameter("umbrella_lambda", 0.0)
    return w


def hot_window_mbar(samples_by_cell, cells, k_hot: float):
    """``f^H_m - f^H_0`` by MBAR across the WALLED hot windows.

    ``samples_by_cell[m]`` is the (n_m, n_cv) angle array sampled by window m. Every window's
    samples are evaluated in every window's potential, which is what lets MBAR bridge them -- and
    is why ``solve_k_hot`` targets an overlap on the MST bottleneck rather than a single pair: the
    window graph has to be CONNECTED or MBAR has no path between the far cells.

    Uses only the wall energies, which are analytic. The unwalled part of the Hamiltonian is
    identical across windows and cancels in every u_kn difference, so it need not be evaluated.
    """
    from pymbar import MBAR

    from escort_ais.methods.nd_flatbottom import nd_bias_kT
    nd = as_nd_cells(cells)
    K = len(nd)
    N_k = np.array([len(samples_by_cell[m]) for m in range(K)], int)
    allx = np.concatenate([np.asarray(samples_by_cell[m], float) for m in range(K)])
    u_kn = np.vstack([nd_bias_kT(allx, nd[m], k_hot) for m in range(K)])
    mbar = MBAR(u_kn, N_k)
    f = mbar.compute_free_energy_differences()["Delta_f"][0]
    return np.asarray(f, float)
