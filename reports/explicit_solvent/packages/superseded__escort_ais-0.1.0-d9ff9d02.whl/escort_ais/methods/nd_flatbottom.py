"""Flat-bottom confinement of an N-dimensional rectangular cell in periodic CVs.

``rectangular_flatbottom`` builds its wall from a single (phi, psi) quartet pair, which cannot
express a macrocycle cell restrained in four or more backbone torsions. This module builds the same
energy for an arbitrary number of torsions:

    U(x) = sum_d  0.5 * k_d * max(0, |wrap(theta_d - mu_d)| - h_d)^2      [kT]

with one term per ACTIVE dimension of the cell (a full-circle arc is unrestrained and contributes
nothing). ``mu_d`` is the arc centre and ``h_d`` its half-width, so the energy is exactly zero
inside the cell and rises quadratically outside — the same convention as the 2-D version, verified
against it in :func:`selftest_against_rect`.

The wall is SOFT: at k = 100 kT/rad^2 a walker reaches 5.7 deg beyond the boundary for 0.5 kT and
14 deg for 3 kT. That penetration is the point — it is what lets a confined walker report whether
its own boundary is real (see ``docs/protocols/conditional_bar_conventions.md`` §6).

As everywhere in this project, the restraint generates a confined ensemble ONLY. It never enters
the AIS work.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

TWO_PI = 2.0 * np.pi


def _wrap(a):
    return (np.asarray(a, float) + np.pi) % TWO_PI - np.pi


def arc_params(arc, k: float):
    """(k, centre, half_width) for one periodic arc; k <= 0 or a full circle means no wall."""
    if arc.full or k is None or k <= 0.0:
        return None
    width = arc.width
    if width >= TWO_PI - 1e-12:
        return None
    centre = float(_wrap(arc.lo + 0.5 * width))
    return float(k), centre, float(0.5 * width)


def nd_bias_kT(angles, cell, k_wall: float = 100.0) -> np.ndarray:
    """Reference implementation of ``U`` in kT. ``angles`` is (n_frames, n_cv) in RADIANS."""
    a = np.atleast_2d(np.asarray(angles, float))
    u = np.zeros(len(a))
    for d in cell.active_dims():
        p = arc_params(cell.arcs[d], k_wall)
        if p is None:
            continue
        k, mu, hw = p
        dev = np.abs(_wrap(a[:, d] - mu))
        u += 0.5 * k * np.maximum(0.0, dev - hw) ** 2
    return u


def interior_mask(angles, cell) -> np.ndarray:
    """True where every active arc contains the point, i.e. ``U == 0`` exactly."""
    a = np.atleast_2d(np.asarray(angles, float))
    m = np.ones(len(a), bool)
    for d in cell.active_dims():
        m &= cell.arcs[d].contains(a[:, d])
    return m


def build_nd_flatbottom_force(quartets, cell, kT_kj: float, k_wall: float = 100.0,
                              group: int = 29, openmm=None):
    """``CustomCVForce`` confining ``cell``: one torsion CV per active dimension.

    :param quartets: (n_cv, 4) atom indices, one per CV, in the SAME order as the cell's arcs.
    :param kT_kj: k_B T in kJ/mol, to convert the kT-unit stiffness to OpenMM energy units.

    ``acos(max(-1,min(1,cos(t-mu))))`` is the wrap-safe |angular deviation|; clamping the argument
    matters because floating-point cos can leave [-1,1] and NaN the force.
    """
    if openmm is None:
        import openmm

    terms, cvs = [], {}
    for d in cell.active_dims():
        p = arc_params(cell.arcs[d], k_wall)
        if p is None:
            continue
        k, mu, hw = p
        tag = "t%d" % d
        cv = openmm.CustomTorsionForce("theta")
        a, b, c, e = (int(x) for x in quartets[d])
        cv.addTorsion(a, b, c, e, [])
        cvs[tag] = (cv, k * kT_kj, mu, hw)
        terms.append(
            "0.5*kw_{t}*max(0, acos(max(-1,min(1,cos({t}-mu_{t})))) - hw_{t})^2".format(t=tag))

    if not terms:                                   # nothing to restrain (all arcs full)
        f = openmm.CustomBondForce("0")
        f.setForceGroup(int(group))
        return f

    f = openmm.CustomCVForce(" + ".join(terms))
    for tag, (cv, kk, mu, hw) in cvs.items():
        f.addCollectiveVariable(tag, cv)
        f.addGlobalParameter("kw_%s" % tag, kk)
        f.addGlobalParameter("mu_%s" % tag, mu)
        f.addGlobalParameter("hw_%s" % tag, hw)
    f.setForceGroup(int(group))
    return f


def selftest_against_rect(basin, phi_quartet, psi_quartet, kT_kj, n: int = 2000, seed: int = 0):
    """Cross-check ``nd_bias_kT`` against the validated 2-D ``rect_bias_kT`` on random angles."""
    from escort_ais.methods.nd_basin_tree import Arc, Cell
    from escort_ais.methods.rectangular_flatbottom import rect_bias_kT

    rng = np.random.default_rng(seed)
    ang = rng.uniform(-np.pi, np.pi, size=(n, 2))
    cell = Cell([Arc(basin.phi_interval.lower, basin.phi_interval.upper, basin.phi_interval.full),
                 Arc(basin.psi_interval.lower, basin.psi_interval.upper, basin.psi_interval.full)])
    k = basin.k_phi or basin.k_psi or 100.0
    mine = nd_bias_kT(ang, cell, k_wall=k)
    ref = np.asarray(rect_bias_kT(ang[:, 0], ang[:, 1], basin), float)
    return float(np.max(np.abs(mine - ref)))
