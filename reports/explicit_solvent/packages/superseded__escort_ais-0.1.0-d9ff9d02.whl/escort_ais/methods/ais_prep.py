"""ais_prep.py — SHARED hot forward-AIS PREP for BAIS methods (method-agnostic; deliberately NOT WE-named).

The hot window + forward-AIS shot + AIS-landing W2 convergence gate + freeze-hot is common to BAIS-WE (BAWE, the
weighted-ensemble reservoir) and BAUS (BAIS-US, reservoir-free umbrellas). Historically it lived inline inside
`run_generation_we` (§1-2), which both buried it and tied it to the WE name. Here it is extracted verbatim:

  * `hot_ais_step(...)` runs ONE generation's hot leg, mutating a plain state dict (the subset of the WE state the
    hot leg touches). `run_generation_we` calls this for its §1-2, so BAWE behavior is byte-identical.
  * `run_hot_prep(...)` loops `hot_ais_step` into a standalone reservoir-free PREP that returns the accumulated
    forward-AIS landings — this is what BAUS uses instead of building a WE reservoir.

The low-level AIS primitives (featurize/_ais_leg/_make_seed_dir/_weighted_emd/_we_self_floor) are imported LAZILY
from run_bais_standalone to avoid a circular import at module load.
"""
import sys

import numpy as np


def new_prep_state():
    """Fresh accumulator holding exactly the WE-state fields the hot leg reads/writes (so `hot_ais_step` can run
    against either a full `we` dict or a minimal BAUS state)."""
    return dict(Wf_all=[], land_feat_all=[], land_ang_all=[], land_xyz_all=[],
                prev_land=None, w2_streak=0, hot_frozen=False, frozen_window=None, g_freeze=None, pi_bar=None)


def hot_ais_step(g, cfg, hot, state, out, platform, devices, rng):
    """ONE generation of the hot forward-AIS PREP (BAIS §1-2), extracted verbatim from run_generation_we so BOTH
    BAWE and BAUS share identical hot behavior. Mutates `state`
    (Wf_all/land_feat_all/land_ang_all/land_xyz_all/prev_land/w2_streak/hot_frozen/frozen_window/g_freeze).
    Returns (Wf, land, land_feat, land_ang, w_land, emd, self_floor, converged)."""
    from escort_ais.methods.run_bais_standalone import (  # noqa: PLC0415  (lazy to break the import cycle)
        featurize, _ais_leg, _make_seed_dir, _weighted_emd, _we_self_floor)

    # ── 1. hot window + forward AIS (BAIS unchanged). GROWING phase: consume a fresh hot chunk; FROZEN phase:
    #        resample the frozen pool (seed=1000+g differs each gen ⇒ fresh stochastic forward works).
    #        NO-FREEZE mode (BAUS generational, cfg["prep_no_freeze"]): the window ALWAYS slides through the hot MD
    #        so the forward samples the hot ensemble representatively; G_conv is recorded but the hot never freezes. ──
    no_freeze = bool(cfg.get("prep_no_freeze", False))
    if state["hot_frozen"] and not no_freeze:
        window = state["frozen_window"]
    else:
        fpf = int(round(cfg["walker_ps"] / cfg["hot_ps_per_frame"]))
        span = max(cfg["n_ais"], fpf)
        lo = (g * fpf) % max(1, hot.n_frames - span)
        window = hot[lo:lo + span]
        state["frozen_window"] = window
    ais_devices = devices if len(devices) > 1 else None
    seed_dir = _make_seed_dir(out / f"gen{g:04d}/seed_hot", cfg, window)
    Wf, land = _ais_leg(seed_dir, out / f"gen{g:04d}/fwd", cfg, cfg["n_ais"], cfg["s_hot"], 1.0,
                        platform, seed=1000 + g, devices=ais_devices)
    land_feat, land_ang = featurize(land, cfg)
    w_land = np.exp(-Wf - (-Wf).max())                            # cold-representative importance weights
    state["Wf_all"].append(Wf); state["land_feat_all"].append(land_feat)
    state["land_ang_all"].append(land_ang); state["land_xyz_all"].append(land.xyz)

    # ── 2. AIS-landing W2 convergence gate + freeze-hot (BAIS-US_theory §3) ──
    emd = self_floor = np.nan
    if state["prev_land"] is not None:
        pf, pw = state["prev_land"]
        emd = _weighted_emd(land_feat, w_land, pf, pw, rng=rng)
        self_floor = _we_self_floor(np.concatenate([land_feat, pf]), np.concatenate([w_land, pw]), rng)
    state["prev_land"] = (land_feat, w_land)
    converged = bool(np.isfinite(emd) and np.isfinite(self_floor) and emd <= 1.5 * self_floor)
    state["w2_streak"] = state["w2_streak"] + 1 if converged else 0
    if state["w2_streak"] >= cfg["we_burn_gens"] and state["g_freeze"] is None:
        state["g_freeze"] = g                                     # G_conv: landings now trusted for umbrella design
        if no_freeze:
            print(f"    [prep] W2 converged at gen {g} — G_conv (landings trusted; hot keeps sliding, NO freeze)",
                  file=sys.stderr)
        else:
            state["hot_frozen"] = True
            print(f"    [prep] hot ensemble FROZEN at gen {g} (W2={emd:.3g} ≤ 1.5·self-floor {self_floor:.3g})",
                  file=sys.stderr)
    return Wf, land, land_feat, land_ang, w_land, emd, self_floor, converged


def run_hot_prep(cfg, hot, out, platform, devices, rng, max_gen=None, target_landings=None):
    """Standalone reservoir-free hot PREP for BAUS: run the hot forward-AIS leg generation by generation
    (gen 0 = discarded burn-in, matching BAWE). The hot ensemble W2-FREEZES once its AIS-landing distribution
    converges (BAWE §3) — but freeze stops *growing the hot pool*, it does NOT stop *accumulating landings*.
    Accumulation CONTINUES past the freeze, resampling the frozen pool (seed=1000+g differs each gen ⇒ fresh
    stochastic forward works) until `target_landings` have piled up, or `max_gen` is hit. Stopping AT the freeze
    gen gives only ~1-2 gens of landings (~50), far too few for vM-BIC to resolve the rare α_L; the WE path
    accumulates across ALL cold gens (~3050 landings ⇒ K*≈7 incl. α_L), which this target-count loop reproduces.
    Returns dict(land_ang, Wf, land_feat, land_xyz, g_freeze, n_gen_prep)."""
    state = new_prep_state()
    max_gen = int(max_gen or cfg.get("prep_max_gen", 200))
    target = int(target_landings if target_landings is not None else cfg.get("prep_target_landings", 2500))
    g = 1                                                          # gen 0 is the discarded burn-in (never sampled)

    def _n_land():
        return int(sum(len(a) for a in state["land_ang_all"]))

    while g <= max_gen:
        hot_ais_step(g, cfg, hot, state, out, platform, devices, rng)
        if state["hot_frozen"] and _n_land() >= target:          # freeze stops GROWING hot pool, NOT accumulation
            break
        g += 1
    return dict(
        land_ang=np.concatenate(state["land_ang_all"], axis=0) if state["land_ang_all"] else np.empty((0,)),
        Wf=np.concatenate(state["Wf_all"]) if state["Wf_all"] else np.empty((0,)),
        land_feat=np.concatenate(state["land_feat_all"], axis=0) if state["land_feat_all"] else np.empty((0, 0)),
        land_xyz=np.concatenate(state["land_xyz_all"], axis=0) if state["land_xyz_all"] else None,
        g_freeze=state["g_freeze"], n_gen_prep=g)
