#!/usr/bin/env python3
r"""baus_estimator.py — the joint MSK(hot-edge BAR) ⊕ equilibrium-MBAR estimator for BAUS.

This is the CENTRAL, validated BAUS estimator (theory: ``docs/theory/BAUS_theory.pdf``). It replaces the
retired density-corrected reverse work ``W_1 = ln(q̃_m/p)`` (kept only as a clearly-labelled unsupported
exploratory alternative in ``bais_us.density_corrected_first_step``; NOT used here or on any default path).

Reduced units throughout (β = 1/k_BT = 1; reduced work ``W = -ln w``). ``U_m`` is the von Mises umbrella bias
``U_m(θ) = Σ_t κ_{m,t}[1 - cos(θ_t - μ_{m,t})]`` (``coverage_windows.bias_u``); ``u_C`` is the (unknown,
pointwise) cold reduced potential; the confined ensemble of window ``m`` is ``q_m ∝ exp[-u_C - U_m]/Z_m``.

MATCHED bidirectional protocols (the whole point — forward and reverse switch between the SAME two states):

    forward   H_1 → C_0 → C_m :  W_{H→m}(x_τ) = W_{H→C} + U_m(x_τ)          (x_τ = the forward landing)
    reverse   C_m → C_0 → H_1 :  W_{m→H}(x_0) = -U_m(x_0) + W_{C→H},         x_0 ~ q_m (EQUILIBRIUM umbrella draw)

Free energies ``f_i = -ln Z_i``; hot-edge gap ``Δ_{Hm} = f_m - f_H``; directional count correction
``c_{Hm} = ln(N_{H→m}^{AIS} / N_{m→H}^{AIS})`` (uses ONLY the AIS work-trajectory counts on that edge, never the
much larger equilibrium sample count). Per hot edge, the count-corrected BAR estimating equation is

    Σ_k 1/(1 + exp[ W_{H→m,k} - Δ_{Hm} + c_{Hm} ]) = Σ_l 1/(1 + exp[ W_{m→H,l} + Δ_{Hm} - c_{Hm} ]).       (BAR)

Equilibrium MBAR over the umbrella configurations (``u_C`` is common to all cold windows and CANCELS from the
reverse-logistic MBAR likelihood):

    ℓ_eq(f) = Σ_m Σ_{i∈m} [ ln N_m + f_m - U_m(x_{m,i}) - ln Σ_n N_n exp(f_n - U_n(x_{m,i})) ].                (EQ)

Joint objective (gauge f_H = 0):

    ℓ_joint(f) = ℓ_eq(f) + Σ_m ℓ_{Hm}^{BAR}(f_H, f_m).                                                        (JOINT)

Continuous unbiased cold reconstruction from the pooled umbrella configurations {x_i} with normalized weights

    a_i^C ∝ 1 / ( Σ_m N_m exp[ f_m - U_m(x_i) ] ),   Σ_i a_i^C = 1,   π_A = Σ_i a_i^C · 1[x_i ∈ A].            (REC)

Information graph: for edge i↔j with contrast vector ``q_{ij} = e_j - e_i`` the positive edge information is
``I_{ij} = -∂²ℓ_{ij}/∂Δ_{ij}² ≥ 0`` and the local information matrix is the weighted graph Laplacian
``L = Σ_{(i,j)} I_{ij} q_{ij} q_{ij}^T`` (``information_laplacian``).

Reused observations (one hot landing scored under every U_m; an umbrella config used in MBAR and also launching
reverse AIS) make this a COMPOSITE-likelihood objective with correlated observations — the naive inverse Hessian
UNDERSTATES uncertainty. Report uncertainty by parent-unit bootstrap (``block_bootstrap_populations``): resample
complete parent units (a hot trajectory with all its per-U_m endpoint works; an umbrella config with its
cross-energies and any reverse AIS it launched; whole time blocks of a correlated umbrella trajectory).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

from escort_ais.methods.endpoint_bar import _overlap_score, solve_bar_with_infinite_works


# ── umbrella-bias evaluation ────────────────────────────────────────────────────────────────────
def bias_matrix(pooled_ang: np.ndarray, windows: Sequence[dict],
                bias_fn: Optional[Callable] = None) -> np.ndarray:
    r"""``U[n, i] = U_n(x_i)`` — the umbrella bias of every window ``n`` evaluated at every pooled config ``x_i``.

    ``windows[n]`` must be accepted by ``bias_fn`` (default ``coverage_windows.bias_u``: keys ``mu``, ``kappa``).
    Each equilibrium configuration enters the MBAR dataset ONCE, cross-evaluated under all ``U_n`` — no
    ``N_m·N_n`` duplicated pseudo-observations. Returns ``(n_windows, n_samples)`` reduced-energy matrix.
    """
    if bias_fn is None:
        from escort_ais.methods.coverage_windows import bias_u as bias_fn
    A = np.asarray(pooled_ang, float)
    if A.ndim == 1:
        A = A[:, None]
    return np.array([np.asarray(bias_fn(A, w), float) for w in windows])   # (nb, N)


# ── hot-edge matched works ──────────────────────────────────────────────────────────────────────
def hot_edge_works(Wf: np.ndarray, U_m_land: np.ndarray,
                   Wann: np.ndarray, U_m_start: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    r"""Matched forward/reverse hot-edge works for one umbrella ``m``.

        forward  W_{H→m} = W_{H→C} + U_m(x_land)      (ALL forward landings; +U_m turns the umbrella ON)
        reverse  W_{m→H} = -U_m(x_0) + W_{C→H}        (x_0 ~ q_m equilibrium; -U_m turns the umbrella OFF)

    ``Wf``      : (N_f,) forward reduced anneal works W_{H→C} for every forward AIS landing.
    ``U_m_land``: (N_f,) U_m evaluated at each forward landing config.
    ``Wann``    : (N_r,) reverse reduced anneal works W_{C→H} for the reverse AIS shots launched from window m.
    ``U_m_start``:(N_r,) U_m evaluated at each reverse-AIS START config (the equilibrium umbrella draw x_0).
    Returns (W_{H→m} (N_f,), W_{m→H} (N_r,)).
    """
    Wfwd = np.asarray(Wf, float) + np.asarray(U_m_land, float)
    Wrev = np.asarray(Wann, float) - np.asarray(U_m_start, float)
    return Wfwd, Wrev


def count_correction(n_fwd: int, n_rev: int) -> float:
    r"""``c_{Hm} = ln(N_{H→m}^{AIS} / N_{m→H}^{AIS})`` — the directional AIS-trajectory count correction.

    Uses ONLY the number of AIS work trajectories present on the edge (NEVER the equilibrium umbrella-sample
    count). Unequal forward/reverse counts are allowed and correctly handled by the BAR offset below.
    """
    n_fwd, n_rev = int(n_fwd), int(n_rev)
    if n_fwd <= 0 or n_rev <= 0:
        return np.nan
    return float(np.log(n_fwd / n_rev))


def bar_edge_free_energy(Wfwd: np.ndarray, Wrev: np.ndarray,
                         n_fwd: Optional[int] = None, n_rev: Optional[int] = None) -> tuple[float, bool]:
    r"""Solve the count-corrected BAR equation (BAR) for a single hot edge → ``Δ_{Hm} = f_m - f_H``.

    Delegates to ``endpoint_bar.solve_bar_with_infinite_works`` (whose internal ``n_f/n_r`` ratio IS the
    ``c_{Hm}`` offset: ``1/(1 + (N_f/N_r) e^{W-Δ}) = 1/(1 + e^{W-Δ+c})``). ``Wfwd`` may contain ``+inf`` (a
    forward landing that never reaches the edge); such entries stay in ``n_fwd`` but contribute 0 to the sums.
    Returns (Δ_{Hm}, converged).
    """
    n_fwd = len(Wfwd) if n_fwd is None else n_fwd
    n_rev = len(Wrev) if n_rev is None else n_rev
    return solve_bar_with_infinite_works(Wfwd, Wrev, n_f_total=n_fwd, n_r_total=n_rev)


def _edge_nll(Delta: float, Wfwd: np.ndarray, Wrev: np.ndarray, c: float) -> float:
    r"""Convex BAR negative log-likelihood of one hot edge, ``-ℓ_{Hm}^{BAR}(Δ)``.

        -ℓ_{Hm}(Δ) = Σ_k softplus(Δ - W_{H→m,k} - c) + Σ_l softplus(c - Δ - W_{m→H,l})

    Its stationary point ``∂/∂Δ = 0`` is exactly the count-corrected BAR equation (BAR). ``+inf`` forward works
    contribute ``softplus(-inf)=0`` and drop out (they still count via ``c``). Convex in Δ.
    """
    wf = np.asarray(Wfwd, float)
    wf = wf[np.isfinite(wf)]
    wr = np.asarray(Wrev, float)
    wr = wr[np.isfinite(wr)]
    return float(np.logaddexp(0.0, Delta - wf - c).sum() + np.logaddexp(0.0, c - Delta - wr).sum())


def _edge_information(Delta: float, Wfwd: np.ndarray, Wrev: np.ndarray, c: float) -> float:
    r"""Edge information ``I = -∂²ℓ/∂Δ² = ∂²(-ℓ)/∂Δ² = Σ σ'(·) ≥ 0`` (σ' = σ(1-σ), the logistic curvature)."""
    wf = np.asarray(Wfwd, float); wf = wf[np.isfinite(wf)]
    wr = np.asarray(Wrev, float); wr = wr[np.isfinite(wr)]
    def _sig(z):
        return 1.0 / (1.0 + np.exp(-z))
    s1 = _sig(Delta - wf - c)
    s2 = _sig(c - Delta - wr)
    return float((s1 * (1.0 - s1)).sum() + (s2 * (1.0 - s2)).sum())


# ── equilibrium MBAR ────────────────────────────────────────────────────────────────────────────
def equilibrium_mbar_loglik(f: np.ndarray, U: np.ndarray, sample_window: np.ndarray,
                            N: np.ndarray) -> float:
    r"""Equilibrium MBAR/UWHAM log-likelihood ℓ_eq(f) — eq. (EQ). MAXIMIZED (return value is ℓ_eq, not -ℓ_eq).

    ``U``            : (nb, Nsamp) bias matrix ``U_n(x_i)`` from ``bias_matrix``.
    ``sample_window``: (Nsamp,) the window m each pooled config was sampled from.
    ``N``            : (nb,) equilibrium sample count per window (``N_m``); windows with N_m=0 are excluded.
    ``f``            : (nb,) trial free energies.
    """
    U = np.asarray(U, float)
    f = np.asarray(f, float)
    N = np.asarray(N, float)
    sw = np.asarray(sample_window, int)
    logN = np.log(np.where(N > 0, N, np.nan))
    denom = logsumexp((logN + f)[:, None] - U, axis=0)         # (Nsamp,) ln Σ_n N_n exp(f_n - U_n(x_i))
    own = (logN[sw] + f[sw]) - U[sw, np.arange(U.shape[1])]    # ln N_{m_i} + f_{m_i} - U_{m_i}(x_i)
    return float(np.sum(own - denom))


def equilibrium_information_edges(U: np.ndarray, f: np.ndarray,
                                  N: np.ndarray) -> list[tuple[int, int, float]]:
    r"""Return pairwise MBAR weights whose Laplacian is ``-d²ℓ_eq/df²``.

    If ``p_mi = N_m exp(f_m-U_mi) / Σ_n N_n exp(f_n-U_ni)``, the
    information on umbrella contrast ``m↔n`` is ``Σ_i p_mi p_ni``.
    """
    U = np.asarray(U, float)
    f = np.asarray(f, float)
    N = np.asarray(N, float)
    if U.ndim != 2 or U.shape[0] != len(f) or len(f) != len(N):
        raise ValueError("U, f, and N have incompatible shapes")
    if not np.any(N > 0):
        return []
    logN = np.full(len(N), -np.inf)
    logN[N > 0] = np.log(N[N > 0])
    logits = (logN + f)[:, None] - U
    probabilities = np.exp(logits - logsumexp(logits, axis=0))
    return [
        (m, n, float(np.sum(probabilities[m] * probabilities[n])))
        for m in range(len(N)) for n in range(m + 1, len(N))
        if N[m] > 0 and N[n] > 0
    ]


# ── joint solve ─────────────────────────────────────────────────────────────────────────────────
@dataclass
class HotEdge:
    """One matched hot↔umbrella AIS edge. Works are reduced; ``+inf`` forward entries allowed."""
    window: int                         # cold-window index m (0-based)
    Wfwd: np.ndarray                    # W_{H→m} for all forward AIS landings
    Wrev: np.ndarray                    # W_{m→H} for the reverse AIS shots from m
    n_fwd: Optional[int] = None         # AIS forward count (defaults to len(Wfwd))
    n_rev: Optional[int] = None         # AIS reverse count (defaults to len(Wrev))

    def __post_init__(self):
        self.Wfwd = np.asarray(self.Wfwd, float)
        self.Wrev = np.asarray(self.Wrev, float)
        self.n_fwd = int(len(self.Wfwd) if self.n_fwd is None else self.n_fwd)
        self.n_rev = int(len(self.Wrev) if self.n_rev is None else self.n_rev)

    @property
    def c(self) -> float:
        return count_correction(self.n_fwd, self.n_rev)


@dataclass
class JointResult:
    f: np.ndarray                       # (nb,) per-window free energies, gauge f_H = 0
    converged: bool
    edge_delta_bar: np.ndarray          # (nb,) standalone per-edge BAR Δ_{Hm} (init / diagnostic)
    edge_information: np.ndarray        # (nb,) hot-edge information I_{Hm} at the solution
    n_windows: int
    diagnostics: dict = field(default_factory=dict)


def jarzynski_anchor(Wfwd: np.ndarray) -> tuple[float, float]:
    r"""Forward-only hot-edge free energy and its precision from the forward works alone:
    ``f̂_m = -ln⟨e^{-W_{H→m}}⟩`` (Jarzynski), precision ``≈ ESS`` (effective sample size of the weights
    ``w=e^{-W}``). Used by the forward-only MSK (drop the reverse leg, keep the equilibrium MBAR)."""
    wf = np.asarray(Wfwd, float); wf = wf[np.isfinite(wf)]
    if len(wf) == 0:
        return float("nan"), 0.0
    lw = -wf                                                        # log importance weights
    fJ = -(logsumexp(lw) - np.log(len(wf)))
    ess = float(np.exp(2.0 * logsumexp(lw) - logsumexp(2.0 * lw)))  # (Σw)²/Σw²  ∈ [1, n]
    return float(fJ), ess


def solve_joint(edges: Sequence[HotEdge], U: Optional[np.ndarray], sample_window: Optional[np.ndarray],
                N: Optional[np.ndarray], n_windows: int, *, gauge: str = "hot",
                forward_only: bool = False, maxiter: int = 2000) -> JointResult:
    r"""Minimize ``-ℓ_joint(f) = -ℓ_eq(f) + Σ_m [-ℓ_{Hm}(f_m)]`` over the cold-window free energies ``f``.

    Gauge ``f_H = 0`` (the hot state is the reference; each hot edge ties ``f_m`` to it via ``Δ_{Hm} = f_m``).
    ``U``/``sample_window``/``N`` supply the equilibrium MBAR term (pass ``U=None`` to solve from the hot edges
    alone). The hot-edge term is, per window:
      * ``forward_only=False`` (default, BAUS): the bidirectional count-corrected BAR NLL ``-ℓ_{Hm}^{BAR}``;
      * ``forward_only=True``:  the FORWARD-only Jarzynski anchor ``½·ESS_m·(f_m - f̂_m)²`` — the reverse leg is
        dropped and replaced by a precision-weighted quadratic pull toward ``f̂_m=-ln⟨e^{-W_{H→m}}⟩``. The
        equilibrium MBAR then couples overlapping windows so a sparse-landing (rare) window borrows strength.
    Initialized from per-edge BAR (bidirectional) or ``f̂_m`` (forward-only). Returns a ``JointResult``.
    """
    nb = int(n_windows)
    have_eq = U is not None and N is not None and sample_window is not None
    if have_eq:
        U = np.asarray(U, float); N = np.asarray(N, float); sample_window = np.asarray(sample_window, int)

    # per-edge standalone estimate (init + diagnostic); index by window
    edge_delta = np.full(nb, np.nan)
    edge_by_window: dict[int, HotEdge] = {}
    fwd_anchor: dict[int, tuple[float, float]] = {}
    for e in edges:
        if forward_only:
            fJ, ess = jarzynski_anchor(e.Wfwd)
            fwd_anchor[e.window] = (fJ, ess); edge_delta[e.window] = fJ
        else:
            edge_delta[e.window], _ok = bar_edge_free_energy(e.Wfwd, e.Wrev, e.n_fwd, e.n_rev)
        edge_by_window[e.window] = e

    f0 = np.where(np.isfinite(edge_delta), edge_delta, 0.0)

    def negloglik(f):
        val = 0.0
        if have_eq:
            val -= equilibrium_mbar_loglik(f, U, sample_window, N)
        if forward_only:
            for m, (fJ, ess) in fwd_anchor.items():
                val += 0.5 * ess * (f[m] - fJ) ** 2                 # precision-weighted forward Jarzynski anchor
        else:
            for m, e in edge_by_window.items():
                val += _edge_nll(f[m], e.Wfwd, e.Wrev, e.c)
        return val

    res = minimize(negloglik, f0, method="L-BFGS-B", options={"maxiter": maxiter, "ftol": 1e-12})
    f = np.asarray(res.x, float)
    # anchor the gauge (hot reference): the hot state is index -inf; f is already f_m - f_H with f_H≡0.
    info = np.zeros(nb)
    for m, e in edge_by_window.items():
        info[m] = fwd_anchor[m][1] if forward_only else _edge_information(f[m], e.Wfwd, e.Wrev, e.c)
    return JointResult(f=f, converged=bool(res.success), edge_delta_bar=edge_delta,
                       edge_information=info, n_windows=nb,
                       diagnostics=dict(nll=float(res.fun), n_edges=len(edges), has_equilibrium=have_eq,
                                        forward_only=forward_only))


# ── alternative: hot-edge-only (BAR-only) estimator ───────────────────────────────────────────────
@dataclass
class BarOnlyResult:
    f: np.ndarray                       # (nb,) per-window free energies from the H↔m edges alone, gauge f_H=0
    converged: np.ndarray               # (nb,) per-edge BAR convergence flags
    edge_information: np.ndarray        # (nb,) hot-edge information I_{Hm}
    edge_overlap: np.ndarray            # (nb,) forward/reverse work-overlap score (BAR conditioning, [0,1])
    n_windows: int


def bar_only_free_energies(edges: Sequence[HotEdge], n_windows: int) -> BarOnlyResult:
    r"""Hot-edge-only estimator: solve every ``H↔C_m`` bidirectional BAR edge INDEPENDENTLY (no equilibrium-MBAR
    overlap coupling). Each window's free energy is ``f_m=\Delta_{Hm}`` from its own matched forward/reverse works
    (eq. BAR), gauge ``f_H=0``.

    This is the fully decoupled sibling of ``solve_joint``: it uses ONLY the bidirectional AIS/MSK/BAR ties to the
    hot state and NONE of the inter-umbrella overlap. It is the simplest estimator, embarrassingly parallel across
    edges, and robust when umbrellas do not overlap — but it forgoes the variance reduction and cycle-consistency
    that equilibrium MBAR provides, so each ``f_m`` is only as good as its own edge's work overlap (small
    ``I_{Hm}`` ⇒ large variance / possible finite-sample bias). Use it as a baseline, a cross-check against the
    joint estimator, and the natural choice for isolated windows (where it coincides with ``solve_joint``). Feed
    the returned ``f`` to ``reconstruct_weights`` exactly as for the joint solution.
    """
    nb = int(n_windows)
    f = np.full(nb, np.nan); conv = np.zeros(nb, bool)
    info = np.zeros(nb); ovl = np.full(nb, np.nan)
    for e in edges:
        d, ok = bar_edge_free_energy(e.Wfwd, e.Wrev, e.n_fwd, e.n_rev)
        f[e.window] = d; conv[e.window] = bool(ok)
        info[e.window] = _edge_information(d, e.Wfwd, e.Wrev, e.c) if np.isfinite(d) else 0.0
        ovl[e.window] = _overlap_score(np.asarray(e.Wfwd, float)[np.isfinite(e.Wfwd)], e.Wrev)
    return BarOnlyResult(f=f, converged=conv, edge_information=info, edge_overlap=ovl, n_windows=nb)


# ── continuous cold-ensemble reconstruction ───────────────────────────────────────────────────────
def reconstruct_weights(U: np.ndarray, f: np.ndarray, N: np.ndarray) -> np.ndarray:
    r"""Normalized MBAR reconstruction weights ``a_i^C`` for the pooled umbrella configs — eq. (REC).

        a_i^C ∝ 1 / ( Σ_m N_m exp[ f_m - U_m(x_i) ] ),   Σ_i a_i^C = 1.

    ``U`` (nb, Nsamp), ``f`` (nb,), ``N`` (nb,). Returns ``a`` (Nsamp,) summing to 1.
    """
    U = np.asarray(U, float); f = np.asarray(f, float); N = np.asarray(N, float)
    logN = np.log(np.where(N > 0, N, np.nan))
    log_denom = logsumexp((logN + f)[:, None] - U, axis=0)     # (Nsamp,) = ln Σ_m N_m e^{f_m - U_m(x_i)}
    log_a = -log_denom
    log_a -= logsumexp(log_a)
    return np.exp(log_a)


def region_population(a: np.ndarray, in_region: np.ndarray) -> float:
    r"""``π_A = Σ_i a_i^C · 1[x_i ∈ A]`` — the population of an arbitrary region from the reconstruction weights.

    No metastable-state definition is required: ``in_region`` is any boolean mask over the pooled configs.
    """
    a = np.asarray(a, float)
    mask = np.asarray(in_region, bool)
    return float(a[mask].sum())


# ── information graph ─────────────────────────────────────────────────────────────────────────────
def information_laplacian(edges_info: Sequence[tuple[int, int, float]], n_nodes: int) -> np.ndarray:
    r"""Assemble the weighted graph Laplacian ``L = Σ_{(i,j)} I_{ij} q_{ij} q_{ij}^T`` — the local information matrix.

    ``edges_info`` : iterable of ``(i, j, I_ij)`` with ``I_ij ≥ 0`` the edge information and ``q_{ij}=e_j-e_i``.
    ``n_nodes``    : total nodes (e.g. hot node + every umbrella). Returns the (n_nodes, n_nodes) PSD Laplacian.
    A near-zero eigenvalue direction = a poorly-determined free-energy offset (disconnected overlap component
    reachable only through a low-information hot edge); the constant vector is always a null direction (gauge).
    """
    L = np.zeros((n_nodes, n_nodes), float)
    for i, j, I in edges_info:
        if not np.isfinite(I) or I <= 0:
            continue
        L[i, i] += I; L[j, j] += I
        L[i, j] -= I; L[j, i] -= I
    return L


# ── uncertainty: parent-unit / block bootstrap ────────────────────────────────────────────────────
def block_bootstrap_populations(build_inputs: Callable[[np.random.Generator], dict],
                                region_mask_key: str = "in_region", n_boot: int = 200,
                                seed: int = 0) -> dict:
    r"""Parent-unit bootstrap for a region population, the honest uncertainty for this composite likelihood.

    ``build_inputs(rng)`` must RESAMPLE COMPLETE PARENT UNITS (a hot trajectory + all its per-U_m endpoint
    works; an umbrella config + its cross-energies + any reverse AIS it launched; whole time blocks of a
    correlated umbrella trajectory) and return a dict with keys ``edges``, ``U``, ``sample_window``, ``N``,
    ``n_windows`` and ``region_mask_key`` (the boolean region mask over the pooled configs). Returns
    dict(mean, std, ci_low, ci_high, samples). Do NOT substitute the naive inverse-Hessian for this.
    """
    rng = np.random.default_rng(seed)
    samples = []
    for _ in range(int(n_boot)):
        inp = build_inputs(rng)
        r = solve_joint(inp["edges"], inp.get("U"), inp.get("sample_window"), inp.get("N"),
                        inp["n_windows"])
        a = reconstruct_weights(inp["U"], r.f, inp["N"])
        samples.append(region_population(a, inp[region_mask_key]))
    s = np.array(samples, float)
    s = s[np.isfinite(s)]
    if len(s) < 2:
        return dict(mean=np.nan, std=np.nan, ci_low=np.nan, ci_high=np.nan, samples=s.tolist())
    return dict(mean=float(s.mean()), std=float(s.std(ddof=1)),
                ci_low=float(np.percentile(s, 2.5)), ci_high=float(np.percentile(s, 97.5)),
                samples=s.tolist())
