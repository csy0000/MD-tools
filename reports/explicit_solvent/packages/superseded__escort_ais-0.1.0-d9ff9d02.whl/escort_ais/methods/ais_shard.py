"""ais_shard.py — fan an AIS leg across N parallel processes and merge into single-run output.

`run_sharded_ais` splits k independent AIS trajectories into n_shards subprocesses (each a separate
CUDA context, time-slicing the under-utilised GPU), then concatenates their outputs so the result dir
is byte-for-byte SHAPED like one `run_linear_scaling_ais` call: ais_trajectory_summary.csv (final_logw),
selected_initial_frames.csv (in seed-dir coordinates), ais_final_coordinates.dcd. Downstream basin
assignment / BAR code is therefore unchanged — sharding is a drop-in speed-up.

Shard i draws the disjoint residue class {i, i+N, i+2N, …} of the seed pool (offset=i, stride=N) so no
seed frame is reused across shards; k_i = k//N (+1 for the first k%N shards). Distinct seed per shard.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import mdtraj as md
import numpy as np
import pandas as pd

from escort_ais.common.paths import project_root
ROOT = project_root()
LEG = ROOT / "src/escort_ais/experiments/misc/run_ais_leg.py"


def run_sharded_ais(seed_dir, out_dir, k, s_hot, s_cold, switch_ps, n_shards,
                    omega_exclude=None, freq_ais=10, timestep_fs=2.0, platform="CUDA",
                    seed=0, top_pdb=None, devices=None):
    """Run k AIS trajectories across n_shards parallel processes; merge to a single-run-shaped out_dir.

    devices: optional list/comma-string of GPU device indices; shards are round-robined across them
    (e.g. devices=[1] pins all shards to GPU1; devices=[1,2] spreads them). None = platform default."""
    seed_dir = Path(seed_dir); out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    top_pdb = Path(top_pdb) if top_pdb else seed_dir / "start_structure.pdb"
    n_shards = max(1, int(n_shards))
    sizes = [k // n_shards + (1 if i < k % n_shards else 0) for i in range(n_shards)]
    if isinstance(devices, str):
        devices = [d.strip() for d in devices.split(",") if d.strip() != ""]
    env = {**os.environ, "PYTHONPATH": "src"}

    procs, shard_dirs = [], []
    for i, ki in enumerate(sizes):
        if ki == 0:
            continue
        sd = out_dir / f"shard_{i:02d}"; shard_dirs.append(sd)
        cmd = [sys.executable, str(LEG), "--seed-dir", str(seed_dir), "--out-dir", str(sd),
               "--k", str(ki), "--s-hot", str(s_hot), "--s-cold", str(s_cold),
               "--switch-ps", str(switch_ps), "--frame-offset", str(i), "--frame-stride", str(n_shards),
               "--freq-ais", str(freq_ais), "--timestep-fs", str(timestep_fs),
               "--platform", platform, "--seed", str(seed + i)]
        if devices:
            cmd += ["--device", str(devices[i % len(devices)])]
        if omega_exclude is not None:
            cmd += ["--omega-exclude", str(omega_exclude)]
        log = open(sd.parent / f"shard_{i:02d}.log", "w") if False else subprocess.DEVNULL
        procs.append(subprocess.Popen([str(c) for c in cmd], cwd=ROOT, env=env,
                                      stdout=open(out_dir / f"shard_{i:02d}.log", "w"),
                                      stderr=subprocess.STDOUT))
    rc = [p.wait() for p in procs]
    fail = [d for d, r in zip(shard_dirs, rc) if r != 0]
    if fail:
        raise RuntimeError(f"AIS shards failed: {[str(d) for d in fail]}")

    # ── merge in shard order (summary rows, selected frames, endpoint coords all aligned) ──
    summ = pd.concat([pd.read_csv(d / "ais_trajectory_summary.csv") for d in shard_dirs], ignore_index=True)
    sel = pd.concat([pd.read_csv(d / "selected_initial_frames.csv") for d in shard_dirs], ignore_index=True)
    summ.to_csv(out_dir / "ais_trajectory_summary.csv", index=False)
    sel.to_csv(out_dir / "selected_initial_frames.csv", index=False)
    eps = [md.load_dcd(str(d / "ais_final_coordinates.dcd"), top=str(top_pdb)) for d in shard_dirs]
    md.join(eps).save_dcd(str(out_dir / "ais_final_coordinates.dcd"))
    return dict(k=int(summ.shape[0]), n_shards=len([s for s in sizes if s]), out_dir=str(out_dir))
