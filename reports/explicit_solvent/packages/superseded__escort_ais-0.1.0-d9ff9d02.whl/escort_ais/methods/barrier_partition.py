"""
BARRIER CONVENTION (changed 2026-07-30). A cut's barrier is measured from the DEEPEST minimum in
the region being split,

    dF = F(cut) - min(F_mode_left, F_mode_right),

not from the shallowest. The two differ in which escape direction they describe, and only the
former is relevant to whether a partition is needed.

Let A be the deeper well and B the shallower. Escape rates go as
``k_{A->B} ~ exp(-(F_cut - F_A))`` and ``k_{B->A} ~ exp(-(F_cut - F_B))``, so the SLOW direction is
out of the deep well. The mean first passage time A -> B is what decides whether an unrestrained
cold walker started in the dominant basin would ever visit B on the timescale of the run. If it
would not, B must be given its own confined walker -- which is exactly the condition the splitting
criterion should detect. Measuring from the shallower minimum instead reports the FAST direction
and systematically under-splits: a minor region separated by a large barrier from the dominant
basin can present a small barrier back, and would be merged into it despite being kinetically
unreachable.

The usual objection to this convention is that it would split off a shallow, non-metastable dimple
that cannot hold a walker. That objection does not apply here, because a substate ``C_m`` is defined
by a hard region indicator rather than by metastability: ``pi_m = pi_C(.|x in C_m)`` is well defined
for any region, and the flat-bottom wall enforces the confinement whether or not the region is
intrinsically metastable. Insignificant regions are rejected by ``min_basin_mass``, which is the
criterion that exists for that purpose. The two checks therefore divide cleanly -- mass rejects
regions that do not matter, barrier detects regions the dominant basin cannot reach.

Pass ``barrier_from_shallower=True`` to restore the pre-2026-07-30 behaviour; it exists only to
reproduce partitions built under the old convention.
barrier_partition.py — barrier-aligned rectangular partitioning of the periodic (phi, psi) torus.

**The proposal states are not density-mixture components.**  They are barrier-separated,
axis-aligned periodic regions chosen to produce independently restrained rectangular proposal
ensembles.

The pipeline this module implements:

1. reconstruct the cold density from **20 Hummer–Szabo time slices** (not just the AIS landings);
2. locate high-PMF / low-density corridors as candidate axis-aligned cuts ``phi = c`` / ``psi = d``;
3. split recursively, scoring each candidate *conditionally inside its parent rectangle* — a
   barrier that exists only within one region is invisible to a global marginal;
4. emit one periodic rectangle ``B_m = I_phi,m x I_psi,m`` per region;
5. hand those rectangles to independent one-dimensional flat-bottom walls
   (:mod:`escort_ais.methods.rectangular_flatbottom`).

Why rectangles and not mixture responsibilities: a responsibility boundary is an equal-density
surface between two fitted components, which sits wherever the fit puts it and generally does
*not* follow the physical barrier.  A barrier-aligned rectangle puts the wall in the high-PMF
corridor, keeps the interior exactly unbiased, and — being a product of one-dimensional intervals
— can be restrained with independent, separable walls, so a dimension that does not separate
anything is left unrestrained.

Von Mises mixtures remain useful as *diagnostics* (mode positions, multimodality checks) and are
used here only to count density maxima inside a candidate region; they never define a basin.

Everything is periodic.  Intervals may wrap across ±pi, and the partition is verified to cover
the torus exactly once, with the boundary convention that a point lying on a cut belongs to the
region **above** the cut (half-open ``[lower, upper)`` in the wrapped coordinate).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Literal, Optional, Sequence

import numpy as np

from escort_ais.methods.cell_mass_reliability import Z_95_ONE_SIDED, cut_admissible

__all__ = [
    "wrap_angle",
    "circ_distance",
    "PeriodicInterval",
    "RectangularBasin",
    "hz_density",
    "conditional_marginal",
    "cut_candidates",
    "score_cut",
    "score_cut_pair",
    "find_best_cut_pair",
    "find_best_cut",
    "recursive_partition",
    "barrier_ladder_scan",
    "partition_alanine_2state",
    "partition_alanine_3state",
    "verify_partition",
    "assign_basins",
    "basin_masses",
    "wall_stiffness_from_separation",
    "partition_to_dict",
    "partition_from_dict",
    "count_density_maxima",
    "projected_pmf",
    "capped_barrier",
    "resolution_ceiling_kT",
    "build_basin_tree",
    "format_basin_tree",
    "peak_split_candidates",
    "periodic_peaks_valleys",
]

TWO_PI = 2.0 * np.pi


# ─────────────────────────────── angle helpers ───────────────────────────────
def wrap_angle(a):
    """Wrap to (-pi, pi]."""
    a = np.asarray(a, float)
    return -((-a + np.pi) % TWO_PI - np.pi)


def circ_distance(a, b):
    """Shortest distance on the circle, in [0, pi]."""
    return np.abs(wrap_angle(np.asarray(a, float) - np.asarray(b, float)))


# ───────────────────────────── periodic interval ─────────────────────────────
@dataclass(frozen=True)
class PeriodicInterval:
    """Half-open periodic interval ``[lower, upper)`` on the circle.

    ``wraps`` records whether the interval crosses ±pi (``upper < lower`` in wrapped
    coordinates).  A full circle is represented by ``width = 2*pi``.

    Internally everything is done through the equivalent **(centre, half-width)** form, because
    ``theta in I  <=>  |wrap(theta - centre)| <= half_width`` holds for wrapping and
    non-wrapping intervals alike — no branching, and it is exactly what the OpenMM restraint
    expression uses.
    """
    lower: float
    upper: float
    wraps: bool = False
    full: bool = False

    @staticmethod
    def full_circle() -> "PeriodicInterval":
        return PeriodicInterval(lower=-np.pi, upper=np.pi, wraps=False, full=True)

    @staticmethod
    def from_bounds(lower: float, upper: float) -> "PeriodicInterval":
        lo, up = float(wrap_angle(lower)), float(wrap_angle(upper))
        if abs(wrap_angle(up - lo)) < 1e-12:
            # Half-open [a, a) is ambiguous on a circle -- zero width or the whole circle? It is
            # never legitimately produced by a split (a cut AT an endpoint leaves an empty
            # child), and silently reading it as the full circle makes that child overlap every
            # other basin. Refuse to build it; use full_circle() for the whole circle.
            raise ValueError(
                f"degenerate periodic interval [{np.degrees(lo):.3f}, {np.degrees(up):.3f}) deg: "
                "a cut coincided with an interval endpoint. Use PeriodicInterval.full_circle() "
                "for the whole circle.")
        return PeriodicInterval(lower=lo, upper=up, wraps=bool(up <= lo), full=False)

    @staticmethod
    def from_centre(centre: float, half_width: float) -> "PeriodicInterval":
        if half_width >= np.pi - 1e-12:
            return PeriodicInterval.full_circle()
        return PeriodicInterval.from_bounds(centre - half_width, centre + half_width)

    # ── geometry ─────────────────────────────────────────────────────────────
    @property
    def width(self) -> float:
        """Periodic interval width in radians (``2*pi`` only for the full circle)."""
        if self.full:
            return TWO_PI
        return (self.upper - self.lower) % TWO_PI

    @property
    def half_width(self) -> float:
        return np.pi if self.full else 0.5 * self.width

    @property
    def centre(self) -> float:
        return 0.0 if self.full else float(wrap_angle(self.lower + 0.5 * self.width))

    def contains(self, theta) -> np.ndarray:
        """Half-open membership ``[lower, upper)``, correct across the ±pi seam."""
        t = np.asarray(theta, float)
        if self.full:
            return np.ones(t.shape, bool)
        return ((t - self.lower) % TWO_PI) < self.width

    def distance_to(self, theta) -> np.ndarray:
        """Shortest periodic distance from ``theta`` to the interval (0 inside)."""
        if self.full:
            return np.zeros(np.shape(theta), float)
        return np.maximum(0.0, circ_distance(theta, self.centre) - self.half_width)

    def distance_to_lower_wall(self, theta) -> np.ndarray:
        return circ_distance(theta, self.lower)

    def distance_to_upper_wall(self, theta) -> np.ndarray:
        return circ_distance(theta, self.upper)

    def as_dict(self) -> dict:
        return dict(lower=float(self.lower), upper=float(self.upper), wraps=bool(self.wraps),
                    full=bool(self.full), width=float(self.width),
                    centre=float(self.centre), half_width=float(self.half_width),
                    lower_deg=float(np.degrees(self.lower)),
                    upper_deg=float(np.degrees(self.upper)))


periodic_interval_width = lambda iv: iv.width                       # noqa: E731 (named per spec)
periodic_distance_to_interval = lambda iv, th: iv.distance_to(th)   # noqa: E731
periodic_distance_to_lower_wall = lambda iv, th: iv.distance_to_lower_wall(th)   # noqa: E731
periodic_distance_to_upper_wall = lambda iv, th: iv.distance_to_upper_wall(th)   # noqa: E731


# ───────────────────────────── rectangular basin ─────────────────────────────
@dataclass
class RectangularBasin:
    basin_id: int
    phi_interval: PeriodicInterval
    psi_interval: PeriodicInterval
    mass: float = float("nan")
    label: str = ""
    parent: str = "root"
    active_walls: list = field(default_factory=list)   # subset of {"phi", "psi"}
    k_phi: Optional[float] = None
    k_psi: Optional[float] = None
    wall_geometry: dict = field(default_factory=dict)

    def contains(self, phi, psi) -> np.ndarray:
        return self.phi_interval.contains(phi) & self.psi_interval.contains(psi)

    @property
    def area_fraction(self) -> float:
        return float(self.phi_interval.width * self.psi_interval.width / (TWO_PI * TWO_PI))

    def as_dict(self) -> dict:
        return dict(basin_id=int(self.basin_id), label=self.label, parent=self.parent,
                    phi_interval=self.phi_interval.as_dict(),
                    psi_interval=self.psi_interval.as_dict(),
                    mass=float(self.mass), area_fraction=self.area_fraction,
                    active_walls=list(self.active_walls),
                    k_phi=(None if self.k_phi is None else float(self.k_phi)),
                    k_psi=(None if self.k_psi is None else float(self.k_psi)),
                    wall_geometry=self.wall_geometry)


def _rect(phi_iv, psi_iv, basin_id=0, **kw) -> RectangularBasin:
    return RectangularBasin(basin_id=basin_id, phi_interval=phi_iv, psi_interval=psi_iv, **kw)


# ──────────────────────── HS density reconstruction (§1) ─────────────────────
def hz_density(hz, bin_width_deg: float = 4.0, smooth_deg: float = 4.0,
               s_min: Optional[float] = None, combine: str = "ess_weighted",
               weights_column: Optional[str] = None) -> dict:
    """Weighted periodic 2-D cold density from the **20 Hummer–Szabo slices**.

    Each slice is reweighted to cold with the HS weight
    ``log w~ = -W_{0:l} - [u_C(x_il) - u_l(x_il)]`` and normalised on its own; the slices are
    then combined (``ess_weighted`` by default, so an ESS-starved hot slice cannot dominate).
    All 20 slices are used unless ``s_min`` is given.

    ``smooth_deg`` is a *mild* circular Gaussian; the default (one bin) is deliberately small so
    that clearly separated alanine basins are never merged.
    """
    import pandas as pd

    from escort_ais.analysis.hz_reconstruction import hz_log_weights, weighted_ess

    if not isinstance(hz, pd.DataFrame):
        hz = pd.DataFrame(hz)
    slice_col = "observation_id" if "observation_id" in hz.columns else "observation_index"
    sub = hz if s_min is None else hz[hz["s"] >= float(s_min)]
    if sub.empty:
        raise ValueError("no HS rows left after the s_min cut")

    nb = int(round(360.0 / float(bin_width_deg)))
    edges = np.linspace(-np.pi, np.pi, nb + 1)
    centres = 0.5 * (edges[:-1] + edges[1:])

    per_slice, ess, s_values = [], [], []
    for sid, g in sub.groupby(slice_col):
        if weights_column is not None:
            lw = np.asarray(g[weights_column], float)
        else:
            lw = np.asarray(hz_log_weights(g["cumulative_reduced_work"], g["u_current_reduced"],
                                           g["u_cold_reduced"]), float)
        w = np.exp(lw - lw.max())
        H, _, _ = np.histogram2d(wrap_angle(np.radians(g["phi"].to_numpy())),
                                 wrap_angle(np.radians(g["psi"].to_numpy())),
                                 bins=[edges, edges], weights=w)
        tot = H.sum()
        per_slice.append(H / tot if tot > 0 else H)
        ess.append(weighted_ess(lw))
        s_values.append(float(g["s"].iloc[0]))

    P = np.stack(per_slice)
    e = np.asarray(ess, float)
    if combine == "ess_weighted" and e.sum() > 0:
        p = (P * e[:, None, None]).sum(0) / e.sum()
    elif combine == "per_slice_mean":
        p = P.mean(0)
    else:
        raise ValueError(f"unknown combine={combine!r}")
    p = p / p.sum()

    if smooth_deg and smooth_deg > 0:
        p = _circular_gaussian_2d(p, sigma_bins=float(smooth_deg) / float(bin_width_deg))
        p = p / p.sum()

    with np.errstate(divide="ignore"):
        F = -np.log(np.where(p > 0, p, np.nan))
    F = F - np.nanmin(F)
    return dict(density=p, free_energy=F, edges=edges, centres=centres,
                bin_width_deg=float(bin_width_deg), smooth_deg=float(smooth_deg),
                n_slices=int(len(per_slice)), slice_s_values=s_values,
                slice_ess=[float(x) for x in ess], s_min=s_min, combine=combine)


def _circular_gaussian_2d(p: np.ndarray, sigma_bins: float) -> np.ndarray:
    """Separable Gaussian blur with periodic wrap in both dimensions."""
    if sigma_bins <= 0:
        return p
    r = max(1, int(np.ceil(3 * sigma_bins)))
    x = np.arange(-r, r + 1)
    k = np.exp(-0.5 * (x / sigma_bins) ** 2)
    k /= k.sum()
    out = np.apply_along_axis(lambda v: np.convolve(np.r_[v[-r:], v, v[:r]], k, "same")[r:-r],
                              0, p)
    out = np.apply_along_axis(lambda v: np.convolve(np.r_[v[-r:], v, v[:r]], k, "same")[r:-r],
                              1, out)
    return out


# ─────────────────────── conditional marginals & scoring ─────────────────────
def _region_mask(dens: dict, region: RectangularBasin) -> tuple[np.ndarray, np.ndarray]:
    c = dens["centres"]
    return region.phi_interval.contains(c), region.psi_interval.contains(c)


def conditional_marginal(dens: dict, region: RectangularBasin, dim: str) -> tuple[np.ndarray, np.ndarray]:
    """``p_{phi|R}(c)`` or ``p_{psi|R}(d)`` — the marginal **inside the parent rectangle only**.

    A global marginal averages over the whole torus and can completely hide a barrier that
    exists only within one region; that is why every split after the first is scored this way.
    Returns ``(angles, marginal)`` restricted to the region's own extent along ``dim``.
    """
    p = dens["density"]
    c = dens["centres"]
    mphi, mpsi = _region_mask(dens, region)
    if dim == "phi":
        ang, prof, iv = c[mphi], p[:, mpsi].sum(axis=1)[mphi], region.phi_interval
    elif dim == "psi":
        ang, prof, iv = c[mpsi], p[mphi, :].sum(axis=0)[mpsi], region.psi_interval
    else:
        raise ValueError(f"dim must be 'phi' or 'psi', got {dim!r}")
    # Order the profile ALONG the interval, not by global angle. For an interval that wraps the
    # +/-pi seam the masked bins are [.., -90, 94, ..] in global order, so "adjacent in the
    # array" is not "adjacent in the interval" -- peak/valley adjacency and the endpoint
    # exclusion both depend on this being right.
    if not iv.full:
        order = np.argsort((ang - iv.lower) % TWO_PI)
        ang, prof = ang[order], prof[order]
    return ang, prof


def count_density_maxima(dens: dict, region: RectangularBasin,
                         rel_threshold: float = 0.25, min_separation_deg: float = 30.0) -> int:
    """Number of distinct density maxima inside a region (a *diagnostic*, §11).

    Used only to check that a proposed child actually contains its own high-density island, and
    to flag strongly multimodal rectangles.  It never defines a boundary.
    """
    p = dens["density"].copy()
    mphi, mpsi = _region_mask(dens, region)
    mask = np.outer(mphi, mpsi)
    q = np.where(mask, p, 0.0)
    if q.max() <= 0:
        return 0
    thr = rel_threshold * q.max()
    n = q.shape[0]
    sep = max(1, int(round(min_separation_deg / dens["bin_width_deg"])))
    peaks = []
    for i, j in zip(*np.where(q >= thr)):
        nb = q[np.ix_([(i + di) % n for di in range(-1, 2)],
                      [(j + dj) % n for dj in range(-1, 2)])]
        if q[i, j] >= nb.max():
            peaks.append((i, j, q[i, j]))
    peaks.sort(key=lambda t: -t[2])
    kept = []
    for i, j, v in peaks:
        if all(min(abs(i - a) % n, n - abs(i - a) % n) >= sep
               or min(abs(j - b) % n, n - abs(j - b) % n) >= sep for a, b, _ in kept):
            kept.append((i, j, v))
    return len(kept)


def cut_candidates(dens: dict, region: RectangularBasin, dim: str,
                   min_width_deg: float = 30.0,
                   restrict_deg: Optional[tuple[float, float]] = None) -> np.ndarray:
    """Cut positions that leave both children at least ``min_width_deg`` wide."""
    angles, _ = conditional_marginal(dens, region, dim)
    iv = region.phi_interval if dim == "phi" else region.psi_interval
    min_w = np.radians(min_width_deg)
    keep = []
    for a in angles:
        # width of the two children if we cut here
        if iv.full:
            w1, w2 = (a - (-np.pi)) % TWO_PI, TWO_PI - ((a - (-np.pi)) % TWO_PI)
        else:
            w1 = (a - iv.lower) % TWO_PI
            w2 = iv.width - w1
        if w1 >= min_w and w2 >= min_w:
            keep.append(a)
    keep = np.asarray(keep, float)
    if restrict_deg is not None and keep.size:
        lo, hi = np.radians(restrict_deg[0]), np.radians(restrict_deg[1])
        keep = keep[(wrap_angle(keep - lo) >= 0) & (wrap_angle(keep - hi) <= 0)]
    return keep


def score_cut(dens: dict, region: RectangularBasin, dim: str, value: float,
              barrier_from_shallower: bool = False,
              min_basin_mass: float = 0.02, min_width_deg: float = 30.0,
              barrier_threshold_kT: float = 1.0) -> dict:
    """Score one candidate cut against every acceptance criterion of §5.

    All criteria are evaluated and recorded even when one fails, so the full candidate scan is
    inspectable rather than only the winner.
    """
    angles, prof = conditional_marginal(dens, region, dim)
    if angles.size < 3 or prof.sum() <= 0:
        return dict(dimension=dim, value_rad=float(value), accepted=False,
                    reason="empty or degenerate parent region")

    prof_n = prof / prof.sum()
    i_cut = int(np.argmin(circ_distance(angles, value)))
    with np.errstate(divide="ignore"):
        F = -np.log(np.where(prof_n > 0, prof_n, np.nan))

    left, right = _split_region(region, dim, float(angles[i_cut]))
    m_left, m_right = _region_mass(dens, left), _region_mass(dens, right)

    # Modes on either side of the cut, taken from the SAME conditional marginal. Sides are
    # assigned by asking which child actually contains the angle, so the +/-pi seam is handled
    # by PeriodicInterval rather than by arithmetic here.
    left_iv = left.phi_interval if dim == "phi" else left.psi_interval
    in_right = ~np.asarray(left_iv.contains(angles), bool)
    F_left = F[~in_right]
    F_right = F[in_right]
    F_mode_left = float(np.nanmin(F_left)) if F_left.size else np.inf
    F_mode_right = float(np.nanmin(F_right)) if F_right.size else np.inf
    F_cut = float(F[i_cut])
    # Measured from the DEEPEST minimum: the slow escape direction, which is what decides whether
    # the dominant basin can reach the minor region at all. See the module docstring.
    dF = F_cut - (max(F_mode_left, F_mode_right) if barrier_from_shallower
                  else min(F_mode_left, F_mode_right))

    n_max_left = count_density_maxima(dens, left)
    n_max_right = count_density_maxima(dens, right)
    w_left = (region_width(left, dim))
    w_right = (region_width(right, dim))

    checks = dict(
        barrier_evidence=bool(np.isfinite(dF) and dF >= barrier_threshold_kT),
        mass_both_sides=bool(min(m_left, m_right) >= min_basin_mass),
        distinct_maxima=bool(n_max_left >= 1 and n_max_right >= 1),
        min_width=bool(min(w_left, w_right) >= np.radians(min_width_deg)),
    )
    return dict(dimension=dim, value_rad=float(angles[i_cut]),
                value_deg=float(np.degrees(angles[i_cut])),
                barrier_height_kT=float(dF), F_cut_kT=F_cut,
                F_mode_left_kT=F_mode_left, F_mode_right_kT=F_mode_right,
                mass_left=float(m_left), mass_right=float(m_right),
                n_maxima_left=int(n_max_left), n_maxima_right=int(n_max_right),
                width_left_deg=float(np.degrees(w_left)),
                width_right_deg=float(np.degrees(w_right)),
                checks=checks, accepted=bool(all(checks.values())))


def region_width(region: RectangularBasin, dim: str) -> float:
    return (region.phi_interval if dim == "phi" else region.psi_interval).width


def _split_region(region: RectangularBasin, dim: str, value: float):
    """Split a rectangle at ``value`` along ``dim``; children are half-open ``[lower, upper)``."""
    iv = region.phi_interval if dim == "phi" else region.psi_interval
    v = float(wrap_angle(value))
    if iv.full:
        # Cutting a periodic coordinate once necessarily creates TWO boundaries. Following the
        # spec, the second one is placed at the +/-pi seam rather than at the antipode of the
        # chosen cut: I_1 = [-pi, v), I_2 = [v, pi). These tile the circle exactly.
        a = PeriodicInterval.from_bounds(-np.pi, v)
        b = PeriodicInterval.from_bounds(v, np.pi)
    else:
        a = PeriodicInterval.from_bounds(iv.lower, v)
        b = PeriodicInterval.from_bounds(v, iv.upper)
    if dim == "phi":
        lo = _rect(a, region.psi_interval, parent=region.label or "root")
        hi = _rect(b, region.psi_interval, parent=region.label or "root")
    else:
        lo = _rect(region.phi_interval, a, parent=region.label or "root")
        hi = _rect(region.phi_interval, b, parent=region.label or "root")
    return lo, hi


def _region_mass(dens: dict, region: RectangularBasin) -> float:
    p = dens["density"]
    mphi, mpsi = _region_mask(dens, region)
    return float(p[np.ix_(mphi, mpsi)].sum())



def _split_full_circle(region: RectangularBasin, dim: str, c1: float, c2: float):
    """Split a FULL periodic dimension with TWO cuts: ``[c1, c2)`` and ``[c2, c1)``.

    Cutting a circle once necessarily creates two boundaries, and pinning the second one to the
    +/-pi seam can slice straight through a basin that happens to straddle the seam — exactly
    what alanine's phi>0 region does in psi, where the psi ~ 160 and psi ~ -150 density is ONE
    basin wrapping across the seam.  Searching for both boundaries lets one child wrap.
    """
    a = PeriodicInterval.from_bounds(c1, c2)
    b = PeriodicInterval.from_bounds(c2, c1)
    if dim == "phi":
        return (_rect(a, region.psi_interval, parent=region.label or "root"),
                _rect(b, region.psi_interval, parent=region.label or "root"))
    return (_rect(region.phi_interval, a, parent=region.label or "root"),
            _rect(region.phi_interval, b, parent=region.label or "root"))


def score_cut_pair(dens: dict, region: RectangularBasin, dim: str, c1: float, c2: float,
                   barrier_from_shallower: bool = False,
                   min_basin_mass: float = 0.02, min_width_deg: float = 30.0,
                   barrier_threshold_kT: float = 1.0) -> dict:
    """Score a two-boundary split of a full periodic dimension.

    The *weaker* of the two boundaries determines the separation, so the barrier height is
    ``min(F(c1), F(c2)) - min(F_mode_A, F_mode_B)``: the weaker BOUNDARY still sets the separation,
    but the reference is the DEEPEST minimum (module docstring).  Both children are checked for mass, width
    and their own density maximum.
    """
    angles, prof = conditional_marginal(dens, region, dim)
    if angles.size < 4 or prof.sum() <= 0:
        return dict(dimension=dim, accepted=False, reason="degenerate parent region")
    prof_n = prof / prof.sum()
    with np.errstate(divide="ignore"):
        F = -np.log(np.where(prof_n > 0, prof_n, np.nan))
    i1 = int(np.argmin(circ_distance(angles, c1)))
    i2 = int(np.argmin(circ_distance(angles, c2)))
    if i1 == i2:
        return dict(dimension=dim, accepted=False, reason="coincident cuts")
    v1, v2 = float(angles[i1]), float(angles[i2])

    A, B = _split_full_circle(region, dim, v1, v2)
    iv_A = A.phi_interval if dim == "phi" else A.psi_interval
    in_A = np.asarray(iv_A.contains(angles), bool)
    F_A = F[in_A]
    F_B = F[~in_A]
    if F_A.size == 0 or F_B.size == 0:
        return dict(dimension=dim, accepted=False, reason="one child is empty")
    F_mode_A, F_mode_B = float(np.nanmin(F_A)), float(np.nanmin(F_B))
    F_cut = float(min(F[i1], F[i2]))
    dF = F_cut - (max(F_mode_A, F_mode_B) if barrier_from_shallower
                  else min(F_mode_A, F_mode_B))

    m_A, m_B = _region_mass(dens, A), _region_mass(dens, B)
    w_A, w_B = region_width(A, dim), region_width(B, dim)
    n_A, n_B = count_density_maxima(dens, A), count_density_maxima(dens, B)
    checks = dict(
        barrier_evidence=bool(np.isfinite(dF) and dF >= barrier_threshold_kT),
        mass_both_sides=bool(min(m_A, m_B) >= min_basin_mass),
        distinct_maxima=bool(n_A >= 1 and n_B >= 1),
        min_width=bool(min(w_A, w_B) >= np.radians(min_width_deg)),
    )
    return dict(dimension=dim, pair=True, value_rad=v1, value_deg=float(np.degrees(v1)),
                value2_rad=v2, value2_deg=float(np.degrees(v2)),
                barrier_height_kT=float(dF), F_cut_kT=F_cut,
                F_cut_1_kT=float(F[i1]), F_cut_2_kT=float(F[i2]),
                F_mode_left_kT=F_mode_A, F_mode_right_kT=F_mode_B,
                mass_left=float(m_A), mass_right=float(m_B),
                n_maxima_left=int(n_A), n_maxima_right=int(n_B),
                width_left_deg=float(np.degrees(w_A)), width_right_deg=float(np.degrees(w_B)),
                checks=checks, accepted=bool(all(checks.values())))


def find_best_cut_pair(dens: dict, region: RectangularBasin, dim: str,
                       barrier_from_shallower: bool = False,
                       min_basin_mass: float = 0.02, min_width_deg: float = 30.0,
                       barrier_threshold_kT: float = 1.0, stride: int = 1,
                       restrict_first_deg: Optional[tuple[float, float]] = None) -> dict:
    """Search BOTH boundaries of a full periodic dimension.

    ``restrict_first_deg`` pins one member of the pair to a window (e.g. the physically
    meaningful ``phi ~ 0`` barrier) while the second is found freely -- the second barrier of a
    periodic coordinate is generally NOT at the +/-pi seam, and pinning it there can cut through
    a basin that wraps the seam.
    """
    angles = cut_candidates(dens, region, dim, min_width_deg=min_width_deg)
    angles = angles[::max(1, int(stride))]
    firsts = (angles if restrict_first_deg is None
              else cut_candidates(dens, region, dim, min_width_deg=min_width_deg,
                                  restrict_deg=restrict_first_deg))
    scores = []
    seen = set()
    for a in firsts:
        for b in angles:
            key = tuple(sorted((round(float(a), 9), round(float(b), 9))))
            if key in seen or abs(float(a) - float(b)) < 1e-9:
                continue
            seen.add(key)
            sc = score_cut_pair(dens, region, dim, float(a), float(b),
                                barrier_from_shallower=barrier_from_shallower,
                                min_basin_mass=min_basin_mass, min_width_deg=min_width_deg,
                                barrier_threshold_kT=barrier_threshold_kT)
            if "barrier_height_kT" in sc:
                scores.append(sc)
    ok = [s for s in scores if s.get("accepted")]
    best = max(ok, key=lambda s: s["barrier_height_kT"]) if ok else None
    return dict(best=best, n_candidates=len(scores), n_accepted=len(ok), candidates=scores)

# ─────────────────────────── cut search & recursion ──────────────────────────
def find_best_cut(dens: dict, region: RectangularBasin, dims=("phi", "psi"),
                  barrier_from_shallower: bool = False,
                  min_basin_mass: float = 0.02, min_width_deg: float = 30.0,
                  barrier_threshold_kT: float = 1.0,
                  restrict: Optional[dict] = None) -> dict:
    """Highest-barrier accepted cut inside ``region``; every candidate score is returned."""
    all_scores = []
    for dim in dims:
        rd = (restrict or {}).get(dim)
        for c in cut_candidates(dens, region, dim, min_width_deg=min_width_deg,
                                restrict_deg=rd):
            all_scores.append(score_cut(dens, region, dim, float(c),
                                        barrier_from_shallower=barrier_from_shallower,
                                        min_basin_mass=min_basin_mass,
                                        min_width_deg=min_width_deg,
                                        barrier_threshold_kT=barrier_threshold_kT))
    ok = [s for s in all_scores if s.get("accepted")]
    best = max(ok, key=lambda s: s["barrier_height_kT"]) if ok else None
    return dict(best=best, n_candidates=len(all_scores), n_accepted=len(ok),
                candidates=all_scores)


def recursive_partition(dens: dict, n_basins: Optional[int] = None, dims=("phi", "psi"),
                        min_basin_mass: float = 0.02, min_width_deg: float = 30.0,
                        barrier_threshold_kT: float = 1.0,
                        stop_barrier_kT: Optional[float] = None,
                        max_basins: int = 12, pair_stride: int = 2,
                        first_cut: Optional[dict] = None) -> dict:
    """Split recursively, always taking the strongest *conditional* barrier available.

    Two stopping rules, and they answer different questions:

    * ``n_basins`` — stop at a requested number of basins (K is an input);
    * ``stop_barrier_kT`` — **stop when the best remaining cut anywhere is lower than this**, so
      the number of states is a property of the landscape rather than a guess.  This is the
      recommended mode: project the free energy along both dimensions, take the highest barrier,
      recurse inside the children, and stop once the best available barrier falls below the
      threshold.

    In threshold mode the geometric criteria (mass, width, its own density maximum) still gate a
    candidate, but the *barrier* criterion is evaluated separately so the true best barrier is
    known at every step -- including the one that finally fails, which is reported as
    ``stopping.best_rejected_barrier_kT``.  That number tells you what a slightly lower threshold
    would have bought.
    """
    threshold_mode = stop_barrier_kT is not None
    if threshold_mode:
        target = int(max_basins)
        search_threshold = -np.inf          # gate on geometry only; decide on the barrier below
    else:
        target = int(n_basins if n_basins is not None else 2)
        search_threshold = barrier_threshold_kT

    root = _rect(PeriodicInterval.full_circle(), PeriodicInterval.full_circle(), 0,
                 label="root", parent="root")
    regions = [root]
    cuts, scans, ladder = [], [], []
    stop_reason, best_rejected = "reached the requested number of basins", None

    if first_cut is not None:
        sc = score_cut(dens, root, first_cut["dimension"], first_cut["value_rad"],
                       min_basin_mass=min_basin_mass, min_width_deg=min_width_deg,
                       barrier_threshold_kT=-np.inf)
        lo, hi = _split_region(root, first_cut["dimension"], sc["value_rad"])
        regions = [lo, hi]
        cuts.append(dict(**sc, parent_region="root", forced=True))

    while len(regions) < target:
        best, best_i, best_scan = None, -1, None
        for i, R in enumerate(regions):
            for dim in dims:
                iv = R.phi_interval if dim == "phi" else R.psi_interval
                if iv.full:
                    scan = find_best_cut_pair(dens, R, dim, min_basin_mass=min_basin_mass,
                                              min_width_deg=min_width_deg,
                                              barrier_threshold_kT=search_threshold,
                                              stride=pair_stride)
                else:
                    scan = find_best_cut(dens, R, dims=(dim,),
                                         barrier_from_shallower=barrier_from_shallower,
                                         min_basin_mass=min_basin_mass,
                                         min_width_deg=min_width_deg,
                                         barrier_threshold_kT=search_threshold)
                if scan["best"] and (best is None or scan["best"]["barrier_height_kT"]
                                     > best["barrier_height_kT"]):
                    best, best_i, best_scan = scan["best"], i, scan
        if best is None:
            stop_reason = "no candidate cut satisfies the mass / width / maximum criteria"
            break
        if threshold_mode and best["barrier_height_kT"] < float(stop_barrier_kT):
            stop_reason = (f"best remaining barrier {best['barrier_height_kT']:.2f} kT is below "
                           f"the {float(stop_barrier_kT):.2f} kT threshold")
            best_rejected = dict(best)
            break

        R = regions.pop(best_i)
        if best.get("pair"):
            lo, hi = _split_full_circle(R, best["dimension"], best["value_rad"],
                                        best["value2_rad"])
        else:
            lo, hi = _split_region(R, best["dimension"], best["value_rad"])
        regions.extend([lo, hi])
        cuts.append(dict(**best, parent_region=(R.label or f"region{best_i}"), forced=False,
                         parent_extent=dict(phi=R.phi_interval.as_dict(),
                                            psi=R.psi_interval.as_dict())))
        ladder.append(dict(step=len(cuts), n_basins=len(regions),
                           dimension=best["dimension"],
                           value_deg=best["value_deg"],
                           value2_deg=best.get("value2_deg"),
                           barrier_height_kT=best["barrier_height_kT"],
                           parent=(R.label or f"region{best_i}")))
        scans.append(dict(parent=(R.label or f"region{best_i}"),
                          n_candidates=best_scan["n_candidates"],
                          candidates=best_scan["candidates"]))
    else:
        if threshold_mode:
            stop_reason = f"hit max_basins = {max_basins}"

    basins = _finalise(dens, regions)
    return dict(basins=basins, cuts=cuts, candidate_scans=scans,
                barrier_ladder=ladder,
                stopping=dict(reason=stop_reason,
                              mode=("barrier threshold" if threshold_mode else "fixed K"),
                              stop_barrier_kT=(None if not threshold_mode
                                               else float(stop_barrier_kT)),
                              n_basins=len(basins),
                              last_accepted_barrier_kT=(ladder[-1]["barrier_height_kT"]
                                                        if ladder else None),
                              best_rejected_barrier_kT=(None if best_rejected is None
                                                        else best_rejected["barrier_height_kT"]),
                              best_rejected_cut=(None if best_rejected is None else dict(
                                  dimension=best_rejected["dimension"],
                                  value_deg=best_rejected["value_deg"],
                                  value2_deg=best_rejected.get("value2_deg"),
                                  mass_left=best_rejected["mass_left"],
                                  mass_right=best_rejected["mass_right"]))),
                stopped_early=bool(n_basins is not None and len(basins) < int(n_basins)))


def barrier_ladder_scan(dens: dict, max_basins: int = 10,
                        thresholds: Optional[Sequence[float]] = None, **kw) -> dict:
    """The barrier ladder, and the number of basins each stopping threshold actually produces.

    Note the ladder is **not monotone**: the greedy "best barrier anywhere" can *rise* after a
    split, because splitting a region exposes children whose conditional marginals contain
    barriers that were invisible in the parent.  (Measured on alanine: 8.76, 4.86, 2.13, 1.29,
    1.00, 0.90, **1.66**, 0.54 kT.)  So ``K(threshold)`` cannot be read off a single run by
    counting steps above the threshold — each threshold is run for real.

    The stopping rule itself remains self-consistent: with threshold ``T`` the recursion runs
    while the global best barrier is >= ``T``, and any cut that could expose a new region is
    itself >= ``T``.
    """
    unlimited = recursive_partition(dens, stop_barrier_kT=-np.inf, max_basins=max_basins, **kw)
    ladder = unlimited["barrier_ladder"]
    if thresholds is None:
        # Use the EXACT barrier heights, not rounded ones: rounding a threshold up above the
        # barrier it came from makes that split fail its own threshold and reports a spurious
        # extra basin boundary.
        seen, thresholds = set(), []
        for t in sorted({x["barrier_height_kT"] for x in ladder} | {0.5, 1.0, 2.0, 3.0, 5.0},
                        reverse=True):
            key = round(float(t), 6)
            if key not in seen:
                seen.add(key)
                thresholds.append(float(t))

    table = []
    for t in thresholds:
        r = recursive_partition(dens, stop_barrier_kT=float(t), max_basins=max_basins, **kw)
        table.append(dict(threshold_kT=float(t), n_basins=len(r["basins"]),
                          stop_reason=r["stopping"]["reason"],
                          last_accepted_barrier_kT=r["stopping"]["last_accepted_barrier_kT"],
                          best_rejected_barrier_kT=r["stopping"]["best_rejected_barrier_kT"]))
    return dict(ladder=ladder, k_vs_threshold=table, max_basins=int(max_basins),
                ladder_is_monotone=bool(all(ladder[i]["barrier_height_kT"]
                                            >= ladder[i + 1]["barrier_height_kT"]
                                            for i in range(len(ladder) - 1))))


def _finalise(dens: dict, regions: Sequence[RectangularBasin]) -> list[RectangularBasin]:
    out = []
    for i, R in enumerate(sorted(regions, key=lambda r: (r.phi_interval.centre,
                                                         r.psi_interval.centre))):
        b = RectangularBasin(basin_id=i, phi_interval=R.phi_interval,
                             psi_interval=R.psi_interval, parent=R.parent,
                             mass=_region_mass(dens, R))
        b.label = f"B{i}"
        out.append(b)
    return out


# ───────────────────────── the named alanine partitions ──────────────────────
def partition_alanine_2state(dens: dict, search_deg: tuple[float, float] = (-30.0, 30.0),
                             fix_at_zero: bool = False, tie_tol_kT: float = 0.25,
                             seam_convention: bool = False, min_basin_mass: float = 0.02,
                             min_width_deg: float = 30.0, pair_stride: int = 1, **kw) -> dict:
    """Two states separated by the ``phi`` barriers.

    phi is periodic, so separating it needs **two** boundaries.  For alanine the marginal has a
    barrier at ``phi ~ +6`` (F = 11.5 kT) *and* one at ``phi ~ +142`` (F = 13.1 kT), while the
    +/-pi seam sits at F ~ 2-3 kT -- i.e. the seam is populated, because the C5/betaII basin
    wraps it.  Pinning the second boundary to the seam therefore cuts a basin in half, so by
    default both boundaries are searched with one pinned inside ``search_deg`` around the
    physically meaningful ``phi = 0``.

    ``seam_convention=True`` restores the literal ``I_1 = [-pi, phi_c)``, ``I_2 = [phi_c, pi)``
    form; it is kept for reference and is NOT the default.
    """
    root = _rect(PeriodicInterval.full_circle(), PeriodicInterval.full_circle(), 0, label="root")

    if seam_convention or fix_at_zero:
        if fix_at_zero:
            chosen = score_cut(dens, root, "phi", 0.0, barrier_threshold_kT=-np.inf,
                               min_basin_mass=min_basin_mass, min_width_deg=min_width_deg)
            scored = [chosen]
        else:
            cands = cut_candidates(dens, root, "phi", min_width_deg=min_width_deg,
                                   restrict_deg=search_deg)
            scored = [score_cut(dens, root, "phi", float(c), barrier_threshold_kT=-np.inf,
                                min_basin_mass=min_basin_mass, min_width_deg=min_width_deg)
                      for c in cands]
            if not scored:
                raise ValueError(f"no admissible phi cut inside {search_deg} deg")
            best_h = max(s["barrier_height_kT"] for s in scored)
            tied = [s for s in scored if s["barrier_height_kT"] >= best_h - tie_tol_kT]
            chosen = min(tied, key=lambda s: abs(s["value_rad"]))
            chosen["n_tied_candidates"] = len(tied)
            chosen["tie_break"] = "closest to phi = 0 among candidates within tie_tol_kT"
        lo, hi = _split_region(root, "phi", chosen["value_rad"])
        chosen["seam_convention"] = True
    else:
        scan = find_best_cut_pair(dens, root, "phi", min_basin_mass=min_basin_mass,
                                  min_width_deg=min_width_deg, barrier_threshold_kT=-np.inf,
                                  stride=pair_stride, restrict_first_deg=search_deg)
        scored = scan["candidates"]
        if scan["best"] is None:
            if not scored:
                raise ValueError("no admissible phi cut pair")
            best_h = max(s["barrier_height_kT"] for s in scored)
            tied = [s for s in scored if s["barrier_height_kT"] >= best_h - tie_tol_kT]
            chosen = min(tied, key=lambda s: abs(s["value_rad"]))
            chosen["n_tied_candidates"] = len(tied)
        else:
            chosen = scan["best"]
        chosen["tie_break"] = ("both phi boundaries searched; one pinned near phi = 0 "
                               f"({search_deg[0]:.0f}..{search_deg[1]:.0f} deg)")
        lo, hi = _split_full_circle(root, "phi", chosen["value_rad"], chosen["value2_rad"])

    basins = _finalise(dens, [lo, hi])
    return dict(basins=basins,
                cuts=[dict(**chosen, parent_region="root", forced=fix_at_zero,
                           parent_extent=dict(phi=root.phi_interval.as_dict(),
                                              psi=root.psi_interval.as_dict()))],
                candidate_scans=[dict(parent="root", n_candidates=len(scored),
                                      candidates=scored)],
                partition_mode="alanine-2state")


def partition_alanine_3state(dens: dict, search_deg: tuple[float, float] = (-30.0, 30.0),
                             fix_at_zero: bool = False, min_basin_mass: float = 0.005,
                             min_width_deg: float = 30.0,
                             barrier_threshold_kT: float = 0.5, **kw) -> dict:
    """``phi ~ 0`` first, then the strongest **conditional** psi barrier inside ``phi > 0``.

    The second cut is deliberately searched only within the positive-phi child: a global psi
    marginal is dominated by the heavily populated ``phi < 0`` side and does not see the
    C7ax / alpha_L separation at all.
    """
    two = partition_alanine_2state(dens, search_deg=search_deg, fix_at_zero=fix_at_zero,
                                   min_basin_mass=min_basin_mass, min_width_deg=min_width_deg,
                                   tie_tol_kT=kw.pop("tie_tol_kT", 0.25),
                                   seam_convention=kw.pop("seam_convention", False))
    cut0 = two["cuts"][0]
    root = _rect(PeriodicInterval.full_circle(), PeriodicInterval.full_circle(), 0, label="root")
    if cut0.get("pair"):
        lo, hi = _split_full_circle(root, "phi", cut0["value_rad"], cut0["value2_rad"])
    else:
        lo, hi = _split_region(root, "phi", cut0["value_rad"])
    positive = hi if hi.phi_interval.contains(np.radians(60.0)) else lo   # the phi>0 child
    other = lo if positive is hi else hi

    # psi inside phi>0 is still a FULL circle, so it needs TWO boundaries. Pinning the second
    # to the +/-pi seam would cut straight through the psi ~ 160 / psi ~ -150 density, which is
    # one basin wrapping the seam; the pair search lets that child wrap instead.
    scan = find_best_cut_pair(dens, positive, "psi", min_basin_mass=min_basin_mass,
                              min_width_deg=min_width_deg,
                              barrier_threshold_kT=barrier_threshold_kT,
                              stride=kw.pop("pair_stride", 2))
    if scan["best"] is None:
        scan = find_best_cut_pair(dens, positive, "psi", min_basin_mass=0.0,
                                  min_width_deg=min_width_deg,
                                  barrier_threshold_kT=-np.inf, stride=2)
        if scan["best"] is None:
            raise ValueError("no admissible conditional psi cut inside the phi>0 region")
        scan["best"]["forced_despite_failing_checks"] = True

    p_lo, p_hi = _split_full_circle(positive, "psi", scan["best"]["value_rad"],
                                    scan["best"]["value2_rad"])
    basins = _finalise(dens, [other, p_lo, p_hi])
    cuts = [dict(**two["cuts"][0]),
            dict(**scan["best"], parent_region="phi>0", forced=False,
                 parent_extent=dict(phi=positive.phi_interval.as_dict(),
                                    psi=positive.psi_interval.as_dict()))]
    return dict(basins=basins, cuts=cuts,
                candidate_scans=two["candidate_scans"] + [dict(parent="phi>0",
                                                               n_candidates=scan["n_candidates"],
                                                               candidates=scan["candidates"])],
                partition_mode="alanine-3state")


# ─────────────────────────────── verification ────────────────────────────────
def assign_basins(phi, psi, basins: Sequence[RectangularBasin]) -> np.ndarray:
    """Index of the (unique) basin containing each point; -1 if none (should never happen)."""
    phi = np.asarray(phi, float)
    out = np.full(phi.shape, -1, int)
    for b in basins:
        m = b.contains(phi, psi) & (out < 0)
        out[m] = b.basin_id
    return out


def basin_masses(dens: dict, basins: Sequence[RectangularBasin]) -> np.ndarray:
    return np.array([_region_mass(dens, b) for b in basins], float)


def verify_partition(basins: Sequence[RectangularBasin], n_grid: int = 361,
                     strict: bool = True) -> dict:
    """The partition must cover the torus exactly once, and be invariant under +/- 2pi shifts."""
    g = np.linspace(-np.pi, np.pi, int(n_grid), endpoint=False) + (np.pi / n_grid)
    P, Q = np.meshgrid(g, g, indexing="ij")
    cover = np.zeros(P.shape, int)
    for b in basins:
        cover += b.contains(P, Q).astype(int)

    shifted = np.zeros(P.shape, int)
    for b in basins:
        shifted += b.contains(P + TWO_PI, Q - TWO_PI).astype(int)

    res = dict(n_basins=len(basins),
               covers_torus=bool(cover.min() >= 1), n_gap_points=int((cover == 0).sum()),
               no_overlap=bool(cover.max() <= 1), n_overlap_points=int((cover > 1).sum()),
               exact_single_cover=bool(cover.min() == 1 and cover.max() == 1),
               periodic_invariant=bool(np.array_equal(cover, shifted)),
               area_fractions=[b.area_fraction for b in basins],
               total_area_fraction=float(sum(b.area_fraction for b in basins)))
    if strict and not (res["exact_single_cover"] and res["periodic_invariant"]):
        raise ValueError(f"rectangular partition is not an exact cover of the torus: {res}")
    return res


# ─────────────────── wall stiffness from cluster separation (§9) ─────────────
def wall_stiffness_from_separation(theta_left, w_left, theta_right, w_right, cut: float,
                                   E_wall: float = 5.0, alpha: float = 0.5,
                                   quantile: float = 0.1,
                                   k_min: float = 1.0, k_max: float = 200.0) -> dict:
    """``k = 2 E_wall / (alpha * Delta)^2`` from the gap between the two neighbouring clouds.

    ``Delta = d_{m->c} + d_{n->c}`` where each term is the weighted ``quantile`` of the periodic
    distance from that side's samples to the cut — i.e. how close that cloud actually comes to
    the boundary.  Nearby clouds give a sharp wall, well-separated clouds a soft one.  The flat
    interior stays exactly unbiased either way.
    """
    def _q(theta, w):
        theta = np.asarray(theta, float)
        if theta.size == 0:
            return float("nan")
        w = np.ones_like(theta) if w is None else np.asarray(w, float)
        d = circ_distance(theta, cut)
        o = np.argsort(d)
        d, w = d[o], w[o]
        c = np.cumsum(w) / max(w.sum(), 1e-300)
        return float(np.interp(quantile, c, d))

    d_l, d_r = _q(theta_left, w_left), _q(theta_right, w_right)
    gap = float(np.nansum([d_l, d_r]))
    if not np.isfinite(gap) or gap <= 0:
        k_raw = float(k_max)
    else:
        k_raw = float(2.0 * E_wall / (alpha * gap) ** 2)
    return dict(k_unclipped=k_raw, k=float(np.clip(k_raw, k_min, k_max)),
                d_left=d_l, d_right=d_r, gap=gap, E_wall=float(E_wall), alpha=float(alpha),
                quantile=float(quantile), k_min=float(k_min), k_max=float(k_max),
                clipped=bool(k_raw < k_min or k_raw > k_max))


# ────────────────────────────── output schema (§16) ──────────────────────────
def partition_to_dict(result: dict, dens: Optional[dict] = None,
                      partition_mode: str = "recursive-barrier",
                      extra: Optional[dict] = None) -> dict:
    d = dict(
        partition_mode=result.get("partition_mode", partition_mode),
        hz_n_slices=(None if dens is None else int(dens["n_slices"])),
        hz_s_values=(None if dens is None else [float(x) for x in dens["slice_s_values"]]),
        hz_slice_ess=(None if dens is None else [float(x) for x in dens["slice_ess"]]),
        density_grid=(None if dens is None else dict(bin_width_deg=dens["bin_width_deg"],
                                                     smooth_deg=dens["smooth_deg"],
                                                     s_min=dens["s_min"],
                                                     combine=dens["combine"])),
        cuts=[{k: v for k, v in c.items() if k != "candidates"} for c in result.get("cuts", [])],
        basins=[b.as_dict() for b in result["basins"]],
    )
    if extra:
        d.update(extra)
    return d


def partition_from_dict(d: dict) -> list[RectangularBasin]:
    """Rebuild basins from ``barrier_partition.json`` — the umbrella code consumes THIS."""
    out = []
    for b in d["basins"]:
        def _iv(x):
            return (PeriodicInterval.full_circle() if x.get("full")
                    else PeriodicInterval.from_bounds(x["lower"], x["upper"]))
        out.append(RectangularBasin(
            basin_id=int(b["basin_id"]), phi_interval=_iv(b["phi_interval"]),
            psi_interval=_iv(b["psi_interval"]), mass=float(b.get("mass", float("nan"))),
            label=b.get("label", ""), parent=b.get("parent", "root"),
            active_walls=list(b.get("active_walls", [])),
            k_phi=b.get("k_phi"), k_psi=b.get("k_psi"),
            wall_geometry=b.get("wall_geometry", {})))
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Peak/valley formulation and the explicit basin TREE
#
# Equivalent to the cut scan above but stated the way the landscape is: project the ensemble
# onto one dimension, read off the peaks of the projected PMF, and split at the valley between
# two peaks that are far enough apart and separated by a high enough barrier.  Cheaper (O(n)
# per dimension instead of O(n^2) over cut pairs), and it produces the tree directly.
#
# THE EPSILON MATTERS.  F = -log(p + eps) is finite only because of eps, and an empty corridor
# reports a barrier of roughly log(p_mode / eps) -- a number set by the regulariser, not by
# physics.  The default eps = 1/ESS_total is the smallest probability the sample can resolve, so
# a barrier quoted as "8.8 kT" across an empty corridor should be read as "at least ~8.8 kT, and
# not measurable more precisely with this much sampling".
# ─────────────────────────────────────────────────────────────────────────────

def projected_pmf(profile: np.ndarray, epsilon: float = 1e-300) -> np.ndarray:
    """``F = -log(p + eps)``, min-shifted.  ``eps`` is a NUMERICAL guard only.

    The physically meaningful cap is applied to the *barrier* instead (see
    :func:`capped_barrier`), because a cap on ``F`` itself is measured from the global mode and
    therefore crushes barriers that sit next to a shallow peak.
    """
    p = np.asarray(profile, float)
    p = p / max(p.sum(), 1e-300)
    F = -np.log(p + float(epsilon))
    return F - F.min()


def capped_barrier(F_valley: float, F_peak: float,
                   barrier_cap_kT: Optional[float] = None) -> tuple[float, bool]:
    """Barrier ``F_valley - F_peak``.  ``barrier_cap_kT=None`` (the default) means NO capping.

    Capping turned out to be unnecessary.  The decision a split needs is only the comparison
    ``dF >= threshold``, and ``dF`` is finite anyway: the density is an ESS-weighted average over
    20 HS slices, so the hot slices deposit a trace of weight nearly everywhere and ``-log(p)``
    never diverges (measured on alanine: not one exactly-zero bin at 4 deg smoothing).

    What the cap was really guarding against was a *regulariser* leaking sampling depth into the
    decision -- which ``eps = 1/ESS`` did, reporting only 1.28 kT for a completely empty corridor
    because the flanking alpha_L peak holds ~2.6 effective samples.  Using the raw ``-log(p)``
    avoids that without any cap at all.

    The honest caveat is reported instead of enforced: for an unsampled valley the *value* of
    ``dF`` is set by the smoothing kernel and the slice tails (8.8 kT at 4 deg smoothing, 21.7 kT
    at none), so it is a lower bound, not a measurement.  Callers get
    ``valley_effective_samples``; below ~1 the barrier should be read as ">=".  Any threshold in
    the physically interesting range (1-5 kT) sits far below that value, so the *decision* is
    robust even though the number is not.

    A cap is still available for callers that want a bounded score for ranking.
    """
    raw = float(F_valley) - float(F_peak)
    if not np.isfinite(raw):
        return (float(barrier_cap_kT) if barrier_cap_kT is not None else np.inf), True
    if barrier_cap_kT is not None and raw >= float(barrier_cap_kT):
        return float(barrier_cap_kT), True
    return raw, False


def resolution_ceiling_kT(p_peak: float, ess: Optional[float]) -> float:
    """``log(ESS * p_peak)`` -- the largest barrier this sampling could *measure* from that peak.

    Reported as a DIAGNOSTIC alongside every cut so a saturated barrier is never mistaken for a
    measured one.  It no longer participates in any decision.
    """
    if not ess or ess <= 0 or p_peak <= 0:
        return float("nan")
    return float(np.log(max(ess * p_peak, 1e-300)))


def periodic_peaks_valleys(angles: np.ndarray, profile: np.ndarray, is_full: bool,
                           min_separation_deg: float = 30.0,
                           rel_peak_threshold: float = 0.05) -> dict:
    """Peaks of a 1-D projected profile and the valley between each adjacent pair.

    On a full circle the peaks are cyclic, so ``K`` peaks are separated by ``K`` valleys and any
    split needs **two** of them; on a sub-interval ``K`` peaks give ``K-1`` interior valleys and
    one cut suffices.  Peaks closer than ``min_separation_deg`` are merged (keeping the taller),
    which is the "two separate peaks, e.g. 30 degrees apart" rule.
    """
    a = np.asarray(angles, float)
    p = np.asarray(profile, float)
    n = len(a)
    if n < 3:
        return dict(peaks=[], valleys=[], n_peaks=0)
    step = float(np.median(np.abs(np.diff(np.unwrap(a))))) if n > 1 else 1.0
    sep_bins = max(1, int(round(np.radians(min_separation_deg) / max(step, 1e-9))))

    def nb(i, d):
        j = i + d
        if is_full:
            return j % n
        return min(max(j, 0), n - 1)

    # On a sub-interval the endpoints are excluded: a cut there would leave an empty child, and
    # the clamped neighbour comparison would make an endpoint look like an extremum anyway.
    interior_range = range(n) if is_full else range(1, n - 1)
    cand = [i for i in interior_range if p[i] >= p[nb(i, -1)] and p[i] >= p[nb(i, 1)]
            and p[i] >= rel_peak_threshold * p.max()]
    cand.sort(key=lambda i: -p[i])
    peaks = []
    for i in cand:
        if all((min(abs(i - j), n - abs(i - j)) if is_full else abs(i - j)) >= sep_bins
               for j in peaks):
            peaks.append(i)
    peaks.sort()

    valleys = []
    if len(peaks) >= 2:
        pairs = (list(zip(peaks, peaks[1:] + peaks[:1])) if is_full
                 else list(zip(peaks, peaks[1:])))
        for i, j in pairs:
            idx = ([k % n for k in range(i, j + n)] if (is_full and j <= i)
                   else list(range(i, j + 1)))
            if len(idx) < 3:
                continue
            interior = idx[1:-1]
            v = min(interior, key=lambda k: p[k])
            valleys.append(dict(index=int(v), angle_rad=float(a[v]),
                                angle_deg=float(np.degrees(a[v])),
                                depth=float(p[v]),
                                peak_left=int(i), peak_right=int(j),
                                peak_left_deg=float(np.degrees(a[i])),
                                peak_right_deg=float(np.degrees(a[j])),
                                peak_separation_deg=float(np.degrees(
                                    circ_distance(a[i], a[j]) if is_full
                                    else abs(a[j] - a[i])))))
    return dict(peaks=[int(x) for x in peaks], peak_angles_deg=[float(np.degrees(a[i]))
                                                                for i in peaks],
                valleys=valleys, n_peaks=len(peaks))


def peak_split_candidates(dens: dict, region: RectangularBasin, dim: str,
                          min_peak_separation_deg: float = 30.0,
                          barrier_cap_kT: Optional[float] = None,
                          ess: Optional[float] = None,
                          rel_peak_threshold: float = 0.05) -> dict:
    """Candidate splits of ``region`` along ``dim``, from the peaks of its projected PMF.

    Barriers are capped at ``barrier_cap_kT`` relative to each pair's own peak; the
    ESS-based resolution ceiling is reported but never used to decide anything.
    """
    angles, prof = conditional_marginal(dens, region, dim)
    iv = region.phi_interval if dim == "phi" else region.psi_interval
    if angles.size < 3 or prof.sum() <= 0:
        return dict(dimension=dim, n_peaks=0, candidates=[])
    pn = prof / prof.sum()
    F = projected_pmf(prof)
    pv = periodic_peaks_valleys(angles, pn, iv.full,
                                min_separation_deg=min_peak_separation_deg,
                                rel_peak_threshold=rel_peak_threshold)

    out = []
    for v in pv["valleys"]:
        i_weak = (v["peak_left"] if F[v["peak_left"]] >= F[v["peak_right"]]
                  else v["peak_right"])          # the SHALLOWER peak bounds the barrier
        barrier, saturated = capped_barrier(F[v["index"]], F[i_weak], barrier_cap_kT)
        n_eff_valley = (float(ess) * float(pn[v["index"]])) if ess else float("nan")
        out.append(dict(**v, barrier_height_kT=barrier, saturated=bool(saturated),
                        barrier_cap_kT=(None if barrier_cap_kT is None
                                        else float(barrier_cap_kT)),
                        valley_effective_samples=n_eff_valley,
                        unsampled_valley=bool(np.isfinite(n_eff_valley) and n_eff_valley < 1.0),
                        F_valley_kT=float(F[v["index"]]),
                        F_peak_left_kT=float(F[v["peak_left"]]),
                        F_peak_right_kT=float(F[v["peak_right"]]),
                        valley_probability=float(pn[v["index"]]),
                        weak_peak_probability=float(pn[i_weak]),
                        resolution_ceiling_kT=resolution_ceiling_kT(float(pn[i_weak]), ess),
                        resolution_limited=bool(
                            ess is not None and barrier_cap_kT is not None
                            and resolution_ceiling_kT(float(pn[i_weak]), ess)
                            < float(barrier_cap_kT))))
    out.sort(key=lambda d: -d["barrier_height_kT"])
    return dict(dimension=dim, n_peaks=pv["n_peaks"],
                peak_angles_deg=pv.get("peak_angles_deg", []),
                barrier_cap_kT=(None if barrier_cap_kT is None else float(barrier_cap_kT)),
                is_full=bool(iv.full), candidates=out)


@dataclass
class BasinNode:
    node_id: int
    region: RectangularBasin
    parent_id: Optional[int] = None
    children: list = field(default_factory=list)
    depth: int = 0
    mass: float = float("nan")
    split: Optional[dict] = None          # the cut that split THIS node (None for a leaf)
    stop_reason: Optional[str] = None     # why this node was not split further

    @property
    def is_leaf(self) -> bool:
        return not self.children

    def as_dict(self) -> dict:
        return dict(node_id=self.node_id, parent_id=self.parent_id, depth=self.depth,
                    children=list(self.children), is_leaf=self.is_leaf, mass=float(self.mass),
                    phi_interval=self.region.phi_interval.as_dict(),
                    psi_interval=self.region.psi_interval.as_dict(),
                    split=self.split, stop_reason=self.stop_reason)


def build_basin_tree(dens: dict, stop_barrier_kT: float = 3.0,
                     barrier_from_shallower: bool = False,
                     min_peak_separation_deg: float = 30.0,
                     min_basin_mass: float = 0.001, min_width_deg: float = 30.0,
                     max_basins: int = 12, dims=("phi", "psi"),
                     barrier_cap_kT: Optional[float] = None,
                     ess: Optional[float] = None, cloud: Optional[dict] = None,
                     reliability_z: float = Z_95_ONE_SIDED,
                     reliability_method: str = "normal", reliability_n_boot: int = 500,
                     reliability_percentile: float = 5.0, max_rejected_cuts: int = 400,
                     rng=None) -> dict:
    """Recursive peak-splitting tree; leaves are the final rectangular basins.

    At each node the ensemble is projected onto each dimension, the projected PMF
    ``F = -log(p + eps)`` is read for peaks, and the node is split at the valley between the two
    best-separated peaks **iff** the valley barrier exceeds ``stop_barrier_kT``, the peaks are at
    least ``min_peak_separation_deg`` apart, and both children keep enough mass and width.  A
    full periodic dimension is split with the two deepest valleys, so one child may wrap.

    The leaves tile the torus exactly (verified by :func:`verify_partition`), and every wall is a
    recorded valley, so the wall locations come with their provenance.

    :param cloud: optional ``dict(phi=, psi=, weights=, cluster_ids=)`` of the underlying weighted
        samples (angles in RADIANS, ``cluster_ids`` the AIS shot). Supplying it turns on the
        reliability gate: a candidate split is taken only if BOTH children clear ``min_basin_mass``
        with confidence, ``pi_child - z*se > min_basin_mass``. A split that fails is rejected and
        the search moves on to the next-best valley pair, so the rejection costs that cut and not
        the whole partition. Without ``cloud`` the gate is off and the tree is unchanged. The masses
        the gate tests come from the SAMPLES, not from the smoothed density grid, because the
        standard error needs the per-shot weights that the grid has already summed away.
    """
    cap = barrier_cap_kT              # None = no capping (the default)
    gated = cloud is not None
    rng = np.random.default_rng() if rng is None else rng
    if gated:
        c_phi = np.asarray(cloud["phi"], float)
        c_psi = np.asarray(cloud["psi"], float)
        c_w = np.asarray(cloud["weights"], float)
        c_id = np.asarray(cloud["cluster_ids"])
    blacklist: set = set()            # (node id, dim, cut angles) turned down for reliability
    rejected: list = []
    truncated = False
    root_region = _rect(PeriodicInterval.full_circle(), PeriodicInterval.full_circle(), 0,
                        label="n0", parent="root")
    nodes = {0: BasinNode(0, root_region, None, [], 0, _region_mass(dens, root_region))}
    frontier = [0]
    next_id = 1

    while frontier:
        n_leaves = sum(1 for n in nodes.values() if n.is_leaf)
        if n_leaves >= max_basins:
            for i in frontier:
                nodes[i].stop_reason = f"max_basins ({max_basins}) reached"
            break

        best = None
        for nid in frontier:
            node = nodes[nid]
            for dim in dims:
                sc = peak_split_candidates(dens, node.region, dim,
                                           min_peak_separation_deg=min_peak_separation_deg,
                                           barrier_cap_kT=cap, ess=ess)
                iv = node.region.phi_interval if dim == "phi" else node.region.psi_interval
                cands = sc["candidates"]
                if not cands:
                    continue
                # Valley sets in preference order. The FIRST is the historical choice
                # (``cands[:2]`` on a circle, ``cands[:1]`` on an arc), so with an empty blacklist
                # the search is unchanged; later sets are only ever reached after a reliability
                # rejection blacklists an earlier one.
                if iv.full:
                    if len(cands) < 2:
                        continue                       # a circle needs two valleys to be cut
                    sets = [[cands[i], cands[j]] for i in range(len(cands))
                            for j in range(i + 1, len(cands))]
                else:
                    sets = [[c] for c in cands]
                pick = next((p for p in sets if (nid, dim, tuple(
                    round(float(c["angle_rad"]), 9) for c in p)) not in blacklist), None)
                if pick is None:
                    continue
                if iv.full:
                    barrier = min(c["barrier_height_kT"] for c in pick)
                    child_a, child_b = _split_full_circle(node.region, dim,
                                                          pick[0]["angle_rad"],
                                                          pick[1]["angle_rad"])
                else:
                    barrier = pick[0]["barrier_height_kT"]
                    child_a, child_b = _split_region(node.region, dim, pick[0]["angle_rad"])

                sep_ok = all(c["peak_separation_deg"] >= min_peak_separation_deg for c in pick)
                m_a, m_b = _region_mass(dens, child_a), _region_mass(dens, child_b)
                w_ok = min(region_width(child_a, dim),
                           region_width(child_b, dim)) >= np.radians(min_width_deg)
                # the floor may depend on the barrier (nd_basin_tree.barrier_tiered_floor): a state
                # behind a high barrier costs a SILENT bias if merged, only a wide error bar if
                # split, so it earns a lower floor than a state behind a shallow one
                mm = float(min_basin_mass(barrier)) if callable(min_basin_mass) else \
                    float(min_basin_mass)
                ok = sep_ok and w_ok and min(m_a, m_b) >= mm
                cand = dict(node_id=nid, dimension=dim, barrier_height_kT=barrier,
                            valleys=pick, n_peaks=sc["n_peaks"],
                            peak_angles_deg=sc["peak_angles_deg"],
                            barrier_cap_kT=cap,
                            saturated=bool(all(c.get("saturated") for c in pick)),
                            unsampled_valley=bool(all(c.get("unsampled_valley") for c in pick)),
                            valley_effective_samples=min(
                                (c.get("valley_effective_samples", float("nan")) for c in pick),
                                default=float("nan")),
                            resolution_ceiling_kT=min(
                                (c.get("resolution_ceiling_kT", float("nan")) for c in pick),
                                default=float("nan")),
                            mass_left=float(m_a), mass_right=float(m_b),
                            children=(child_a, child_b),
                            min_basin_mass_used=mm,
                            checks=dict(peak_separation=bool(sep_ok), min_width=bool(w_ok),
                                        mass_both_sides=bool(min(m_a, m_b) >= mm)),
                            acceptable=bool(ok))
                if ok and (best is None or barrier > best["barrier_height_kT"]):
                    best = cand

        if best is None:
            for i in frontier:
                nodes[i].stop_reason = ("no dimension has two peaks that satisfy the separation, "
                                        "mass and width criteria")
            break
        if best["barrier_height_kT"] < float(stop_barrier_kT):
            for i in frontier:
                nodes[i].stop_reason = (f"best available barrier {best['barrier_height_kT']:.2f} kT "
                                        f"< stop_barrier {float(stop_barrier_kT):.2f} kT")
            break

        parent = nodes[best["node_id"]]
        ca, cb = best["children"]

        if gated:
            ver = cut_admissible(c_w, c_id,
                                 [ca.contains(c_phi, c_psi), cb.contains(c_phi, c_psi)],
                                 best.get("min_basin_mass_used", min_basin_mass),
                                 z=reliability_z, method=reliability_method,
                                 n_boot=reliability_n_boot, percentile=reliability_percentile,
                                 rng=rng)
            if not ver["admissible"]:
                blacklist.add((best["node_id"], best["dimension"],
                               tuple(round(float(c["angle_rad"]), 9) for c in best["valleys"])))
                rejected.append(dict(node_id=int(best["node_id"]), dimension=best["dimension"],
                                     cut_angles_deg=[float(c["angle_deg"])
                                                     for c in best["valleys"]],
                                     barrier_height_kT=float(best["barrier_height_kT"]),
                                     child_mass=ver["mass"], child_se=ver["se"],
                                     child_bound=ver["bound"], method=ver["method"]))
                if len(rejected) >= int(max_rejected_cuts):
                    truncated = True
                    break
                continue                      # search again WITHOUT this valley set

        for child in (ca, cb):
            child.label = f"n{next_id}"
            nodes[next_id] = BasinNode(next_id, child, parent.node_id, [], parent.depth + 1,
                                       _region_mass(dens, child))
            parent.children.append(next_id)
            next_id += 1
        parent.split = {k: v for k, v in best.items() if k != "children"}
        frontier = [i for i in frontier if i != parent.node_id] + parent.children

    leaves = [n for n in nodes.values() if n.is_leaf]
    leaves.sort(key=lambda n: (n.region.phi_interval.centre, n.region.psi_interval.centre))
    basins = []
    for i, n in enumerate(leaves):
        b = RectangularBasin(basin_id=i, phi_interval=n.region.phi_interval,
                             psi_interval=n.region.psi_interval, mass=n.mass,
                             label=f"B{i}", parent=f"n{n.parent_id}")
        basins.append(b)

    cuts = []
    for n in nodes.values():
        if n.split:
            v = n.split["valleys"]
            cuts.append(dict(dimension=n.split["dimension"],
                             value_rad=v[0]["angle_rad"], value_deg=v[0]["angle_deg"],
                             value2_rad=(v[1]["angle_rad"] if len(v) > 1 else None),
                             value2_deg=(v[1]["angle_deg"] if len(v) > 1 else None),
                             barrier_height_kT=n.split["barrier_height_kT"],
                             parent_region=f"n{n.node_id}", depth=n.depth,
                             n_peaks=n.split["n_peaks"],
                             peak_angles_deg=n.split["peak_angles_deg"],
                             barrier_cap_kT=n.split["barrier_cap_kT"],
                             saturated=n.split["saturated"],
                             unsampled_valley=n.split["unsampled_valley"],
                             valley_effective_samples=n.split["valley_effective_samples"],
                             resolution_ceiling_kT=n.split["resolution_ceiling_kT"],
                             mass_left=n.split["mass_left"], mass_right=n.split["mass_right"],
                             checks=n.split["checks"], accepted=True,
                             parent_extent=dict(phi=n.region.phi_interval.as_dict(),
                                                psi=n.region.psi_interval.as_dict())))
    cuts.sort(key=lambda c: (c["depth"], -c["barrier_height_kT"]))
    return dict(basins=basins, cuts=cuts, tree={k: v.as_dict() for k, v in nodes.items()},
                rejected_cuts=rejected, reliability_gated=bool(gated),
                rejection_search_truncated=bool(truncated),
                reliability_z=(float(reliability_z) if gated else None),
                reliability_method=(reliability_method if gated else None),
                n_nodes=len(nodes), n_leaves=len(basins),
                stop_barrier_kT=float(stop_barrier_kT), barrier_cap_kT=cap,
                min_peak_separation_deg=float(min_peak_separation_deg),
                partition_mode=f"basin-tree-stop{stop_barrier_kT:g}kT")


def format_basin_tree(res: dict) -> str:
    """Readable rendering of the tree: each node, its split, its barrier, its leaves."""
    tree = res["tree"]
    lines = []

    def walk(nid: int, prefix: str = "", is_last: bool = True):
        n = tree[nid] if nid in tree else tree[str(nid)]
        phi, psi = n["phi_interval"], n["psi_interval"]
        rng = (f"phi[{phi['lower_deg']:+.0f},{phi['upper_deg']:+.0f})"
               f"{'w' if phi['wraps'] else ' '} "
               f"psi[{psi['lower_deg']:+.0f},{psi['upper_deg']:+.0f})"
               f"{'w' if psi['wraps'] else ' '}")
        head = f"{prefix}{'└─' if is_last else '├─'}n{n['node_id']} {rng} mass={n['mass']:.4f}"
        if n["split"]:
            s = n["split"]
            v = s["valleys"]
            cut = f"{s['dimension']}={v[0]['angle_deg']:+.0f}°"
            if len(v) > 1:
                cut += f" & {v[1]['angle_deg']:+.0f}°"
            mark = ">=" if (s.get("saturated") or s.get("unsampled_valley")) else "= "
            head += (f"  --split--> {cut}  ΔF{mark}{s['barrier_height_kT']:.2f} kT "
                     f"({s['n_peaks']} peaks)")
        else:
            head += f"  [LEAF] {n.get('stop_reason') or ''}"
        lines.append(head)
        kids = n["children"]
        for i, c in enumerate(kids):
            walk(c, prefix + ("   " if is_last else "│  "), i == len(kids) - 1)

    walk(0)
    return "\n".join(lines)
