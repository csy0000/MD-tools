"""OpenMM Annealed Importance Sampling (AIS).

Two strategies are supported:

energy_interpolation
    U_lambda = (1-lambda)*U_scaled + lambda*U_unscaled.  Propagation is
    performed under U_scaled throughout (approximate).  Work increments are
    computed from endpoint energies at each window boundary.  Requires an
    explicit unscaled target topology directory (``target_topology``).
    config.json records ``"propagation_hamiltonian": "U_source_only"``.

rest2_scaling_interpolation
    U_lambda = U_REST2(s_lambda) where s_lambda = (1-lambda)*s_source + lambda*1.0.
    Requires a REST2 scale factor < 1.0, supplied via ``json_scaling``.
    A single OpenMM Context is built and its REST2 scale factor is updated in
    place at each window boundary via ``Rest2ContextScaler.apply()`` +
    ``updateParametersInContext()``.  This is GPU-capable (no N+1 context OOM).
    config.json records
    ``"propagation_hamiltonian": "rest2_interpolated_step_function"``.

The lambda schedule is always discretised at one step per MD timestep:
    n_lambda_windows = int(switching_time_ps * 1000 / timestep_fs)
"""
from __future__ import annotations

import csv
import glob
import json
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Optional

import mdtraj as md
import numpy as np
from openmm import LangevinMiddleIntegrator, Platform, Vec3, unit
from openmm import app
from scipy.special import logsumexp

from escort_ais.systems.openmm_system import (
    BOLTZMANN_KJ_PER_MOL_K,
    Rest2ContextScaler,
    build_rest2_scaled_system,
)

_SOLUTE_RESIDUE_NAMES = {"ACE", "ALA", "NME"}

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

OpenMMAISStrategy = Literal["energy_interpolation", "rest2_scaling_interpolation"]
# Backward-compat alias
AISStrategy = OpenMMAISStrategy


def _read_topology_config_dir(topo_dir: Path) -> dict:
    """Read config.json from a build-topology output directory."""
    cfg_path = topo_dir / "config.json"
    if not cfg_path.exists():
        raise FileNotFoundError(
            f"build-topology config.json not found: {cfg_path}. "
            "Pass a build-topology output directory."
        )
    return json.loads(cfg_path.read_text())


def _label_to_scale(label: str) -> float:
    """Convert a prmtop filename label back to a float. '0p2' → 0.2, '1p0' → 1.0"""
    return float(label.replace("p", "."))


def _scale_to_label(scale: float) -> str:
    """Convert a REST2 scale factor to a filename-safe label. 0.2 → '0p2', 1.0 → '1p0'"""
    txt = f"{scale:.4f}".rstrip("0")
    if txt.endswith("."):
        txt += "0"
    return txt.replace(".", "p")


def _read_scale_source(json_scaling_dir: Path) -> float:
    """Extract the REST2 scale factor from a build-topology directory.

    Priority order:
    1. Scan for system_scale_*.prmtop files (new naming convention).
    2. Fall back to rest2/ladder.json (REMD mode).
    3. Fall back to rest2/scaled_s*.xml filename (single-scale mode).
    Returns the minimum (hottest) non-physical scale factor found.
    """
    # 1. Prmtop filename scanning (new convention)
    prmtop_files = sorted(json_scaling_dir.glob("system_scale_*.prmtop"))
    if prmtop_files:
        hot_factors = []
        for p in prmtop_files:
            m = re.match(r"system_scale_([0-9p]+)\.prmtop$", p.name)
            if m:
                sf = _label_to_scale(m.group(1))
                if sf < 1.0 - 1e-9:
                    hot_factors.append(sf)
        if hot_factors:
            return min(hot_factors)
        # Only physical prmtop present — fall through to XML check

    # 2. rest2/ladder.json (REMD)
    rest2_dir = json_scaling_dir / "rest2"
    ladder_path = rest2_dir / "ladder.json"
    if ladder_path.exists():
        entries = json.loads(ladder_path.read_text())
        hot_factors = [float(e["scale_factor"]) for e in entries if float(e["scale_factor"]) < 1.0]
        if hot_factors:
            return min(hot_factors)
        raise ValueError(
            f"rest2/ladder.json in {json_scaling_dir} has no scale factor < 1.0."
        )

    # 3. rest2/scaled_s*.xml filename (single-scale legacy)
    xml_files = glob.glob(str(rest2_dir / "scaled_s*.xml"))
    if xml_files:
        m = re.search(r"scaled_s([0-9.]+)\.xml", Path(xml_files[0]).name)
        if m:
            sf = float(m.group(1))
            if sf < 1.0:
                return sf

    raise ValueError(
        f"No REST2 scale factor < 1.0 found in {json_scaling_dir}. "
        "Expected system_scale_<N>.prmtop, rest2/ladder.json, or rest2/scaled_s<N>.xml."
    )


def rest2_scaling_available(json_scaling_dir: Path) -> bool:
    """Return True if the build-topology dir contains a REST2 scale factor < 1.0."""
    try:
        _read_scale_source(json_scaling_dir)
        return True
    except (ValueError, FileNotFoundError):
        return False


def _gb_model_map():
    return {
        "HCT": app.HCT,
        "OBC1": app.OBC1,
        "OBC2": app.OBC2,
        "GBn": app.GBn,
        "GBn2": app.GBn2,
    }


def _count_solute_atoms(topology: app.Topology) -> int:
    atom_iter = topology.atoms() if callable(getattr(topology, "atoms", None)) else topology.atoms
    return sum(1 for atom in atom_iter if atom.residue.name.strip() in _SOLUTE_RESIDUE_NAMES)


@dataclass
class OpenMMAISConfig:
    """Configuration for a single OpenMM AIS run."""

    solvent: Literal["implicit", "explicit"]
    strategy: OpenMMAISStrategy
    source_traj: Path                          # DCD trajectory of the scaled source ensemble
    output_dir: Path
    source_prmtop: Optional[Path] = None       # auto-resolved from json_scaling dir if not given
    n_samples: int = 1000
    switching_time_ps: float = 1.0
    timestep_fs: float = 2.0                   # determines n_lambda_windows = T_ais / dt
    temperature_k: float = 300.0
    seed: int = 123
    json_scaling: Optional[Path] = None        # build-topology dir; required for parameter-scaling
    target_topology: Optional[Path] = None     # build-topology dir; required for energy-interpolation
    hot_time_length_ps: Optional[float] = None
    traj_interval_ps: Optional[float] = None   # required when hot_time_length_ps is set
    lambda_schedule: str = "linear"
    platform: str = "CPU"
    device_index: Optional[str] = None
    friction_per_ps: float = 1.0
    overwrite: bool = False
    debug: bool = False
    notes: list = field(default_factory=list)

    @property
    def n_lambda_windows(self) -> int:
        """Number of lambda windows = one MD step per window."""
        if self.debug:
            return 5
        return max(1, int(self.switching_time_ps * 1000 / self.timestep_fs))


# Backward-compat alias
AISConfig = OpenMMAISConfig


# ---------------------------------------------------------------------------
# Pure utility functions (importable without OpenMM)
# ---------------------------------------------------------------------------

def make_linear_lambda_schedule(n_steps: int) -> np.ndarray:
    """Return a linear lambda schedule with *n_steps + 1* values from 0 to 1."""
    return np.linspace(0.0, 1.0, n_steps + 1)


def compute_reduced_work_increment(u_old: float, u_new: float) -> float:
    """Return the reduced work increment *u_new - u_old*."""
    return u_new - u_old


def sample_initial_frame_indices(n_frames: int, n_samples: int, seed: int) -> np.ndarray:
    """Sample *n_samples* frame indices from a trajectory of *n_frames* frames.

    Uses sampling without replacement when ``n_samples <= n_frames``, and
    with replacement otherwise.
    """
    rng = np.random.default_rng(seed)
    if n_samples <= n_frames:
        return rng.choice(n_frames, size=n_samples, replace=False)
    return rng.choice(n_frames, size=n_samples, replace=True)


def _limit_source_traj_to_time(
    traj: md.Trajectory,
    config: OpenMMAISConfig,
    logger: logging.Logger,
) -> tuple[md.Trajectory, Optional[int]]:
    if config.hot_time_length_ps is None:
        return traj, None
    if config.traj_interval_ps is None:
        raise ValueError(
            "--hot-time-length requires --traj-interval-ps (the trajectory frame "
            "write interval in ps) to compute the frame limit."
        )
    frame_limit = int(np.floor(config.hot_time_length_ps / float(config.traj_interval_ps))) + 1
    frame_limit = max(1, min(frame_limit, traj.n_frames))
    logger.info(
        "Restricting source trajectory to first %.3f ps -> %d/%d frames (traj_interval_ps=%.3f)",
        config.hot_time_length_ps,
        frame_limit,
        traj.n_frames,
        float(config.traj_interval_ps),
    )
    return traj[:frame_limit], frame_limit


def compute_log_weights(work_reduced: np.ndarray) -> np.ndarray:
    """Compute log importance-sampling weights from reduced works.

    log w_i = -W_i  (up to a normalisation constant).
    """
    return -np.asarray(work_reduced, dtype=float)


def compute_ess(log_weights: np.ndarray) -> float:
    """Compute the effective sample size using the log-sum-exp trick."""
    log_weights = np.asarray(log_weights, dtype=float)
    log_weights = log_weights - logsumexp(log_weights)   # normalise
    weights = np.exp(log_weights)
    return float(np.sum(weights) ** 2 / np.sum(weights ** 2))


def compute_jarzynski_delta_f(log_weights: np.ndarray) -> float:
    """Estimate Delta F (reduced) via the Jarzynski equality.

    Returns -logsumexp(-W_i) + log(N).
    """
    works = -np.asarray(log_weights, dtype=float)  # log_weights = -W
    return float(-logsumexp(-works) + np.log(len(works)))


# ---------------------------------------------------------------------------
# OpenMM helpers
# ---------------------------------------------------------------------------

def _build_simulation(
    topology,
    system,
    temperature_k: float,
    friction_per_ps: float,
    timestep_fs: float,
    platform_name: str,
    device_index: Optional[str] = None,
) -> app.Simulation:
    integrator = LangevinMiddleIntegrator(
        temperature_k * unit.kelvin,
        friction_per_ps / unit.picosecond,
        (timestep_fs / 1000.0) * unit.picoseconds,
    )
    platform = Platform.getPlatformByName(platform_name)
    props: dict[str, str] = {}
    if platform_name in {"CUDA", "OpenCL"}:
        props["Precision"] = "mixed"
        if device_index is not None:
            key = "DeviceIndex" if platform_name == "CUDA" else "DeviceIndex"
            props[key] = str(device_index)
    return app.Simulation(topology, system, integrator, platform, props)


def _set_positions(simulation: app.Simulation, positions_nm: np.ndarray,
                   box_nm: Optional[np.ndarray] = None) -> None:
    """Set positions (and optionally box vectors) on a simulation context."""
    simulation.context.setPositions(positions_nm * unit.nanometer)
    if box_nm is not None:
        simulation.context.setPeriodicBoxVectors(
            Vec3(*box_nm[0]) * unit.nanometer,
            Vec3(*box_nm[1]) * unit.nanometer,
            Vec3(*box_nm[2]) * unit.nanometer,
        )


def _get_positions(simulation: app.Simulation) -> np.ndarray:
    """Return positions in nm as (N, 3) numpy array."""
    return simulation.context.getState(getPositions=True).getPositions(asNumpy=True).value_in_unit(unit.nanometer)


def _get_box(simulation: app.Simulation) -> Optional[np.ndarray]:
    """Return periodic box vectors as (3, 3) array in nm, or None."""
    state = simulation.context.getState(getPositions=True)
    bv = state.getPeriodicBoxVectors()
    if bv is None:
        return None
    return np.array([[v.x, v.y, v.z] for v in bv], dtype=float)  # in nm


def _get_energy_kj_mol(simulation: app.Simulation) -> float:
    return simulation.context.getState(getEnergy=True).getPotentialEnergy().value_in_unit(
        unit.kilojoules_per_mole
    )


def _get_velocities(simulation: app.Simulation) -> np.ndarray:
    return simulation.context.getState(getVelocities=True).getVelocities(asNumpy=True).value_in_unit(
        unit.nanometer / unit.picosecond
    )


def _set_velocities(simulation: app.Simulation, velocities_nm_ps: np.ndarray) -> None:
    simulation.context.setVelocities(velocities_nm_ps * (unit.nanometer / unit.picosecond))


# ---------------------------------------------------------------------------
# Strategy A inner loop (energy interpolation, approximate)
# ---------------------------------------------------------------------------

def _run_sample_strategy_a(
    sim_prop: app.Simulation,
    sim_eval: app.Simulation,
    positions_nm: np.ndarray,
    box_nm: Optional[np.ndarray],
    n_lambda_windows: int,
    lambda_values: np.ndarray,
    steps_per_window: int,
    beta0: float,
    is_explicit: bool,
) -> tuple[float, np.ndarray, Optional[np.ndarray], list[float]]:
    """Run one AIS sample for Strategy A.

    Propagates under U_source throughout.  Work increments are computed from
    endpoint energies at each window boundary.

    Returns
    -------
    work_reduced, final_positions_nm, final_box_nm, work_series
    """
    _set_positions(sim_prop, positions_nm, box_nm)
    sim_prop.context.setVelocitiesToTemperature(beta0 ** -1 / BOLTZMANN_KJ_PER_MOL_K * unit.kelvin)

    work = 0.0
    work_series: list[float] = []

    for window in range(n_lambda_windows):
        d_lambda = float(lambda_values[window + 1] - lambda_values[window])

        # Read current positions from propagation context (U_source)
        state = sim_prop.context.getState(getPositions=True, getEnergy=True)
        pos = state.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
        E_source = state.getPotentialEnergy().value_in_unit(unit.kilojoules_per_mole)

        # Evaluate U_target energy at same positions
        _set_positions(sim_eval, pos, _get_box(sim_prop) if is_explicit else None)
        E_target = _get_energy_kj_mol(sim_eval)

        # Work increment: beta0 * d_lambda * (E_target - E_source)
        work += beta0 * d_lambda * (E_target - E_source)
        work_series.append(work)

        # Propagate under U_source
        sim_prop.context.getIntegrator().step(steps_per_window)

    final_pos = _get_positions(sim_prop)
    final_box = _get_box(sim_prop) if is_explicit else None
    return work, final_pos, final_box, work_series


# ---------------------------------------------------------------------------
# Strategy B inner loop (REST2 scaling interpolation)
# ---------------------------------------------------------------------------

def _run_sample_strategy_b(
    sim: app.Simulation,
    scaler: Rest2ContextScaler,
    lambda_scales: list[float],
    n_lambda_windows: int,
    steps_per_window: int,
    beta0: float,
    temperature_k: float,
    is_explicit: bool,
    positions_nm: np.ndarray,
    box_nm: Optional[np.ndarray],
) -> tuple[float, np.ndarray, Optional[np.ndarray], list[float]]:
    """Run one AIS sample for Strategy B (single-context, parameter interpolation).

    Uses a single OpenMM Context whose REST2 scale factor is updated in place via
    ``Rest2ContextScaler.apply()`` at each window boundary.  Velocities carry over
    naturally through the shared integrator state — no inter-context transfer needed.

    Parameters
    ----------
    sim : app.Simulation
        The single simulation context (System must be the one *scaler* was built from).
    scaler : Rest2ContextScaler
        Caches unscaled base parameters and applies scale in place.
    lambda_scales : list[float]
        Scale factors at each window boundary (length = n_lambda_windows + 1).
        ``lambda_scales[0]`` = source scale, ``lambda_scales[-1]`` = 1.0 (target).
    positions_nm, box_nm : ndarray or None
        Initial positions (nm) and periodic box vectors, or None for implicit.

    Returns
    -------
    work_reduced, final_positions_nm, final_box_nm, work_series
    """
    # Initialise: set scale to s[0], load positions, draw velocities from Boltzmann
    scaler.apply(lambda_scales[0], sim.context)
    _set_positions(sim, positions_nm, box_nm)
    sim.context.setVelocitiesToTemperature(temperature_k * unit.kelvin)

    work = 0.0
    work_series: list[float] = []

    for window in range(n_lambda_windows):
        # Energy under current scale (forces already set; positions from last step)
        E_curr = _get_energy_kj_mol(sim)

        # Switch to next scale in place — positions/velocities unchanged
        scaler.apply(lambda_scales[window + 1], sim.context)

        # Energy at next scale, same positions
        E_next = _get_energy_kj_mol(sim)

        # Work increment: beta0 * (U_next - U_curr) at fixed positions
        work += beta0 * (E_next - E_curr)
        work_series.append(work)

        # Propagate one MD step under the next scale's Hamiltonian
        sim.context.getIntegrator().step(steps_per_window)

    final_pos = _get_positions(sim)
    final_box = _get_box(sim) if is_explicit else None
    return work, final_pos, final_box, work_series


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_openmm_ais(config: OpenMMAISConfig) -> dict:
    """Run OpenMM AIS and write all outputs to *config.output_dir*.

    Returns a summary dict with aggregate statistics.
    """
    t_start = time.time()
    output_dir = Path(config.output_dir)
    source_traj_path = Path(config.source_traj)
    # source_prmtop is resolved below after scale_source is known

    # ------------------------------------------------------------------
    # Guard: do not overwrite existing output
    # ------------------------------------------------------------------
    if output_dir.exists() and any(output_dir.iterdir()) and not config.overwrite:
        raise FileExistsError(
            f"Output directory already contains files: {output_dir}. "
            "Pass overwrite=True or --overwrite to replace."
        )
    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Set up logging to file + console
    # ------------------------------------------------------------------
    log_path = output_dir / "run.log"
    logger = logging.getLogger(f"ais.{output_dir.name}")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    fh = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s", datefmt="%Y-%m-%dT%H:%M:%S")
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(ch)

    logger.info("=== OpenMM AIS ===")
    logger.info("solvent=%s  strategy=%s", config.solvent, config.strategy)
    logger.info("source_traj=%s", source_traj_path)
    logger.info("output_dir=%s", output_dir)

    # ------------------------------------------------------------------
    # Resolve scaling parameters from topology config dirs
    # ------------------------------------------------------------------
    temperature_k: float = config.temperature_k
    beta0 = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * temperature_k)
    timestep_fs: float = config.timestep_fs
    scale_target = 1.0

    if config.json_scaling is not None:
        topo_cfg = _read_topology_config_dir(Path(config.json_scaling))
        n_solute_atoms: int = int(topo_cfg["n_solute_atoms"])
        gb_model: str = topo_cfg.get("gb_model", "GBn2")
        scale_source: float = _read_scale_source(Path(config.json_scaling))
        logger.info("json_scaling=%s  scale_source=%.6f  n_solute_atoms=%d",
                    config.json_scaling, scale_source, n_solute_atoms)
        # Auto-resolve source prmtop from topology dir using scale label
        if config.source_prmtop is not None:
            source_prmtop_path = Path(config.source_prmtop)
        else:
            topo_dir = Path(config.json_scaling)
            scale_label = _scale_to_label(scale_source)
            for candidate_name in (
                f"system_scale_{scale_label}.prmtop",
                "system_scale_1p0.prmtop",
                "system.prmtop",
            ):
                candidate = topo_dir / candidate_name
                if candidate.exists():
                    source_prmtop_path = candidate
                    break
            else:
                raise FileNotFoundError(
                    f"source prmtop not found in {topo_dir}. "
                    "Pass --source-prmtop or rebuild topology with the new naming convention."
                )
            logger.info("Auto-resolved source_prmtop=%s", source_prmtop_path)
    elif config.target_topology is not None:
        topo_cfg = _read_topology_config_dir(Path(config.target_topology))
        n_solute_atoms = int(topo_cfg.get("n_solute_atoms", 0))
        gb_model = topo_cfg.get("gb_model", "GBn2")
        scale_source = 1.0  # propagate under base (unscaled) Hamiltonian
        if config.source_prmtop is not None:
            source_prmtop_path = Path(config.source_prmtop)
        else:
            topo_dir = Path(config.target_topology)
            for candidate_name in ("system_scale_1p0.prmtop", "system.prmtop"):
                candidate = topo_dir / candidate_name
                if candidate.exists():
                    source_prmtop_path = candidate
                    break
            else:
                raise FileNotFoundError(
                    f"source prmtop not found in {topo_dir}. Pass --source-prmtop explicitly."
                )
            logger.info("Auto-resolved source_prmtop=%s", source_prmtop_path)
    else:
        raise ValueError(
            "Provide --json-scaling (parameter-scaling) or "
            "--target-topology (energy-interpolation)."
        )
    logger.info("source_prmtop=%s", source_prmtop_path)

    T_source = temperature_k / scale_source
    T_target = temperature_k  # scale_target = 1.0
    logger.info("temperature_k=%.2f  scale_source=%.6f  T_source=%.2f K",
                temperature_k, scale_source, T_source)

    # ------------------------------------------------------------------
    # Lambda schedule: one step per window (n_windows = T_ais / dt)
    # ------------------------------------------------------------------
    n_lambda_windows = config.n_lambda_windows   # @property: T_ais/dt or 5 in debug
    steps_per_window = 1
    lambda_values = make_linear_lambda_schedule(n_lambda_windows)

    logger.info("switching_time_ps=%.3f  timestep_fs=%.3f  n_lambda_windows=%d  steps_per_window=%d",
                config.switching_time_ps, timestep_fs, n_lambda_windows, steps_per_window)

    # ------------------------------------------------------------------
    # Build OpenMM base system from source prmtop
    # ------------------------------------------------------------------
    is_explicit = config.solvent == "explicit"

    if not source_prmtop_path.exists():
        raise FileNotFoundError(f"source prmtop not found: {source_prmtop_path}")

    prmtop = app.AmberPrmtopFile(str(source_prmtop_path))
    if is_explicit:
        base_system = prmtop.createSystem(
            nonbondedMethod=app.PME,
            nonbondedCutoff=1.0 * unit.nanometer,
            constraints=app.HBonds,
            rigidWater=True,
        )
        logger.info("Built explicit PME base system  n_atoms=%d", base_system.getNumParticles())
    else:
        base_system = prmtop.createSystem(
            nonbondedMethod=app.NoCutoff,
            constraints=app.HBonds,
            implicitSolvent=_gb_model_map()[gb_model],
        )
        logger.info("Built implicit %s base system  n_atoms=%d", gb_model, base_system.getNumParticles())

    # Fall back to residue-name counting if n_solute_atoms wasn't in the topology config
    if n_solute_atoms <= 0:
        n_solute_atoms = _count_solute_atoms(prmtop.topology)
        if n_solute_atoms <= 0:
            raise RuntimeError(
                "Failed to determine n_solute_atoms from topology config or residue names. "
                "Ensure your build-topology config.json has n_solute_atoms > 0."
            )
        logger.warning("n_solute_atoms not in topology config; counted from residue names: %d", n_solute_atoms)

    solute_indices = np.arange(n_solute_atoms, dtype=np.int64)
    topology = prmtop.topology

    # ------------------------------------------------------------------
    # Build scaled systems and create simulations
    # ------------------------------------------------------------------
    logger.info("Building OpenMM systems for strategy=%s  platform=%s ...", config.strategy, config.platform)
    t_build = time.time()

    if config.strategy == "energy_interpolation":
        if config.target_topology is None:
            raise ValueError(
                "energy_interpolation requires target_topology. "
                "Pass --target-topology pointing to a build-topology output dir."
            )
        target_topo_dir = Path(config.target_topology)
        target_prmtop_path = target_topo_dir / "system.prmtop"
        if not target_prmtop_path.exists():
            raise FileNotFoundError(
                f"Target topology prmtop not found: {target_prmtop_path}"
            )
        target_prmtop = app.AmberPrmtopFile(str(target_prmtop_path))
        target_topo_cfg = _read_topology_config_dir(target_topo_dir)
        target_gb_model = target_topo_cfg.get("gb_model", "GBn2")
        if is_explicit:
            sys_target = target_prmtop.createSystem(
                nonbondedMethod=app.PME,
                nonbondedCutoff=1.0 * unit.nanometer,
                constraints=app.HBonds,
                rigidWater=True,
            )
        else:
            sys_target = target_prmtop.createSystem(
                nonbondedMethod=app.NoCutoff,
                constraints=app.HBonds,
                implicitSolvent=_gb_model_map()[target_gb_model],
            )
        if sys_target.getNumParticles() != base_system.getNumParticles():
            raise ValueError(
                f"Target topology has {sys_target.getNumParticles()} atoms "
                f"but source topology has {base_system.getNumParticles()} atoms. "
                "Both must have the same number of atoms for position transfer."
            )
        sys_source = build_rest2_scaled_system(base_system, solute_indices, scale_source)
        sim_prop = _build_simulation(topology, sys_source, temperature_k, config.friction_per_ps,
                                     timestep_fs, config.platform, config.device_index)
        eval_platform = "CPU" if config.platform not in {"CPU", "Reference"} else config.platform
        sim_eval = _build_simulation(target_prmtop.topology, sys_target, temperature_k,
                                     config.friction_per_ps, timestep_fs, eval_platform, None)
        propagation_hamiltonian = "U_source_only"
        logger.info(
            "Strategy A: source prmtop=%s  target prmtop=%s  "
            "eval on %s, propagation on %s.",
            source_prmtop_path, target_prmtop_path, eval_platform, config.platform,
        )
    else:
        # rest2_scaling_interpolation: single context retuned per window via
        # Rest2ContextScaler.apply() + updateParametersInContext().
        if scale_source >= 1.0:
            raise ValueError(
                "parameter-scaling (rest2_scaling_interpolation) requires a REST2 "
                "scale factor < 1.0 from --json-scaling. "
                f"Got scale_source={scale_source:.6f} (physical ensemble). "
                "Use energy-scaling instead, or provide a --json-scaling dir with "
                "REST2 scale factor < 1.0."
            )
        lambda_scales: list[float] = [
            (1.0 - lv) * scale_source + lv * scale_target for lv in lambda_values
        ]
        # Clone the unscaled base system so the scaler can cache s=1 params.
        # IMPORTANT: Rest2ContextScaler.__init__ modifies sys_b's CustomGBForce
        # expressions (injects rest2_scale_gb global parameter).  The Context
        # MUST be created AFTER the scaler so the compiled kernels include it.
        from escort_ais.systems.openmm_system import _clone_system
        sys_b = _clone_system(base_system)
        scaler = Rest2ContextScaler(sys_b, solute_indices)  # modifies sys_b first
        sim_single = _build_simulation(topology, sys_b, temperature_k, config.friction_per_ps,
                                       timestep_fs, config.platform, config.device_index)
        # Prime the context at the source scale (first window's Hamiltonian)
        scaler.apply(scale_source, sim_single.context)
        propagation_hamiltonian = "rest2_interpolated_step_function"
        logger.info(
            "Strategy B: single context, %d windows, scale %.4f→%.4f, platform=%s.",
            n_lambda_windows, scale_source, scale_target, config.platform,
        )

    logger.info("System build took %.1f s", time.time() - t_build)

    # ------------------------------------------------------------------
    # Load source trajectory and sample initial frames
    # ------------------------------------------------------------------
    if not source_traj_path.exists():
        raise FileNotFoundError(f"source trajectory not found: {source_traj_path}")

    logger.info("Loading source trajectory: %s", source_traj_path)
    traj = md.load_dcd(str(source_traj_path), top=str(source_prmtop_path))
    n_traj_frames_full = traj.n_frames
    traj, used_frame_limit = _limit_source_traj_to_time(traj, config, logger)
    n_traj_frames = traj.n_frames
    logger.info("Source trajectory: %d frames  n_atoms=%d", n_traj_frames, traj.n_atoms)

    n_samples = config.n_samples if not config.debug else min(5, config.n_samples)
    logger.info("n_samples=%d (debug=%s)", n_samples, config.debug)

    frame_indices = sample_initial_frame_indices(n_traj_frames, n_samples, config.seed)
    initial_positions_all = traj.xyz[frame_indices]      # (n_samples, N, 3) in nm
    initial_box_all = traj.unitcell_vectors[frame_indices] if is_explicit and traj.unitcell_vectors is not None else None

    np.save(output_dir / "initial_indices.npy", frame_indices)
    np.save(output_dir / "lambda_schedule.npy", lambda_values)

    # Save initial samples DCD
    initial_traj = md.Trajectory(
        initial_positions_all, traj.topology,
        unitcell_lengths=traj.unitcell_lengths[frame_indices] if is_explicit and traj.unitcell_lengths is not None else None,
        unitcell_angles=traj.unitcell_angles[frame_indices] if is_explicit and traj.unitcell_angles is not None else None,
    )
    initial_traj.save_dcd(str(output_dir / "initial_samples.dcd"))
    logger.info("Saved initial_indices.npy, lambda_schedule.npy, initial_samples.dcd")

    # ------------------------------------------------------------------
    # Write config.json
    # ------------------------------------------------------------------
    ais_config_dict = {
        "molecule": "alanine_dipeptide",
        "solvent": config.solvent,
        "strategy": config.strategy,
        "n_samples": n_samples,
        "switching_time_ps": config.switching_time_ps,
        "timestep_fs": timestep_fs,
        "n_lambda_windows": n_lambda_windows,
        "steps_per_window": steps_per_window,
        "lambda_schedule": "linear",
        "seed": config.seed,
        "source_traj": str(source_traj_path),
        "source_prmtop": str(source_prmtop_path),
        "json_scaling_dir": str(config.json_scaling) if config.json_scaling else None,
        "target_topology_dir": str(config.target_topology) if config.target_topology else None,
        "hot_time_length_ps": config.hot_time_length_ps,
        "traj_interval_ps": config.traj_interval_ps,
        "scale_source": scale_source,
        "scale_target": scale_target,
        "T_source_K": T_source,
        "T_target_K": T_target,
        "beta_target": beta0,
        "target_temperature_K": temperature_k,
        "platform": config.platform,
        "device_index": config.device_index,
        "propagation_hamiltonian": propagation_hamiltonian,
        "rest2_context_mode": (
            "single_context_updateParametersInContext"
            if config.strategy == "rest2_scaling_interpolation"
            else "N_plus_1_contexts"
        ),
        "work_hamiltonian": config.strategy,
        "n_source_frames": n_traj_frames,
        "n_source_frames_full": n_traj_frames_full,
        "hot_time_frame_limit": used_frame_limit,
        "n_solute_atoms": n_solute_atoms,
        "debug": config.debug,
        "notes": config.notes,
    }
    (output_dir / "config.json").write_text(json.dumps(ais_config_dict, indent=2))

    # ------------------------------------------------------------------
    # Run AIS loop
    # ------------------------------------------------------------------
    csv_path = output_dir / "ais_work.csv"
    csv_columns = [
        "sample_id", "initial_frame_index", "work_reduced", "work_kj_mol",
        "initial_u_source_reduced", "initial_u_target_reduced",
        "final_u_source_reduced", "final_u_target_reduced",
        "switching_time_ps", "n_steps", "timestep_fs", "strategy", "solvent",
        "scale_source", "scale_target", "success", "failure_reason",
    ]

    n_success = 0
    n_failed = 0
    all_work_reduced: list[float] = []
    final_positions_list: list[np.ndarray] = []
    work_timeseries_list: list[list[float]] = []
    initial_u_source_list: list[float] = []
    initial_u_target_list: list[float] = []

    with csv_path.open("w", newline="", encoding="utf-8") as csv_fh:
        writer = csv.DictWriter(csv_fh, fieldnames=csv_columns)
        writer.writeheader()

        for sample_id in range(n_samples):
            if sample_id % 50 == 0:
                elapsed = time.time() - t_start
                logger.info("Sample %d / %d  (elapsed %.1f s)", sample_id, n_samples, elapsed)

            pos0 = initial_positions_all[sample_id]         # (N, 3) nm
            box0 = initial_box_all[sample_id] if initial_box_all is not None else None

            # Initial energies for logging
            try:
                if config.strategy == "energy_interpolation":
                    _set_positions(sim_prop, pos0, box0)
                    E_source_init = _get_energy_kj_mol(sim_prop)
                    _set_positions(sim_eval, pos0, box0)
                    E_target_init = _get_energy_kj_mol(sim_eval)
                else:
                    # Single-context: temporarily switch scale to evaluate each endpoint
                    scaler.apply(scale_source, sim_single.context)
                    _set_positions(sim_single, pos0, box0)
                    E_source_init = _get_energy_kj_mol(sim_single)
                    scaler.apply(scale_target, sim_single.context)
                    E_target_init = _get_energy_kj_mol(sim_single)

                initial_u_source = beta0 * E_source_init
                initial_u_target = beta0 * E_target_init
            except Exception:
                initial_u_source = float("nan")
                initial_u_target = float("nan")

            try:
                if config.strategy == "energy_interpolation":
                    work, final_pos, final_box, work_series = _run_sample_strategy_a(
                        sim_prop, sim_eval, pos0, box0,
                        n_lambda_windows, lambda_values, steps_per_window, beta0, is_explicit,
                    )
                else:
                    work, final_pos, final_box, work_series = _run_sample_strategy_b(
                        sim_single, scaler, lambda_scales,
                        n_lambda_windows, steps_per_window, beta0, temperature_k, is_explicit,
                        pos0, box0,
                    )

                # Final energies
                if config.strategy == "energy_interpolation":
                    _set_positions(sim_prop, final_pos, final_box)
                    E_source_final = _get_energy_kj_mol(sim_prop)
                    _set_positions(sim_eval, final_pos, final_box)
                    E_target_final = _get_energy_kj_mol(sim_eval)
                else:
                    # Evaluate endpoint energies with the single context
                    scaler.apply(scale_source, sim_single.context)
                    _set_positions(sim_single, final_pos, final_box)
                    E_source_final = _get_energy_kj_mol(sim_single)
                    scaler.apply(scale_target, sim_single.context)
                    E_target_final = _get_energy_kj_mol(sim_single)

                n_success += 1
                all_work_reduced.append(work)
                final_positions_list.append(final_pos)
                work_timeseries_list.append(work_series)
                initial_u_source_list.append(initial_u_source)
                initial_u_target_list.append(initial_u_target)

                writer.writerow({
                    "sample_id": sample_id,
                    "initial_frame_index": int(frame_indices[sample_id]),
                    "work_reduced": f"{work:.8f}",
                    "work_kj_mol": f"{work / beta0:.8f}",
                    "initial_u_source_reduced": f"{initial_u_source:.8f}",
                    "initial_u_target_reduced": f"{initial_u_target:.8f}",
                    "final_u_source_reduced": f"{beta0 * E_source_final:.8f}",
                    "final_u_target_reduced": f"{beta0 * E_target_final:.8f}",
                    "switching_time_ps": config.switching_time_ps,
                    "n_steps": n_lambda_windows,
                    "timestep_fs": timestep_fs,
                    "strategy": config.strategy,
                    "solvent": config.solvent,
                    "scale_source": scale_source,
                    "scale_target": scale_target,
                    "success": True,
                    "failure_reason": "",
                })

            except Exception as exc:
                n_failed += 1
                logger.warning("Sample %d failed: %s", sample_id, exc)
                writer.writerow({
                    "sample_id": sample_id,
                    "initial_frame_index": int(frame_indices[sample_id]),
                    "work_reduced": "nan",
                    "work_kj_mol": "nan",
                    "initial_u_source_reduced": f"{initial_u_source:.8f}",
                    "initial_u_target_reduced": f"{initial_u_target:.8f}",
                    "final_u_source_reduced": "nan",
                    "final_u_target_reduced": "nan",
                    "switching_time_ps": config.switching_time_ps,
                    "n_steps": n_lambda_windows,
                    "timestep_fs": timestep_fs,
                    "strategy": config.strategy,
                    "solvent": config.solvent,
                    "scale_source": scale_source,
                    "scale_target": scale_target,
                    "success": False,
                    "failure_reason": str(exc),
                })

    # ------------------------------------------------------------------
    # Write outputs
    # ------------------------------------------------------------------
    if final_positions_list:
        final_pos_array = np.stack(final_positions_list, axis=0)
        ref_top = md.load_prmtop(str(source_prmtop_path))
        final_traj = md.Trajectory(final_pos_array, ref_top)
        final_traj.save_dcd(str(output_dir / "final_samples.dcd"))
        logger.info("Saved final_samples.dcd  (%d frames)", len(final_positions_list))

    if work_timeseries_list:
        max_len = max(len(w) for w in work_timeseries_list)
        wts = np.full((len(work_timeseries_list), max_len), float("nan"))
        for i, ws in enumerate(work_timeseries_list):
            wts[i, :len(ws)] = ws
        np.save(output_dir / "work_timeseries.npy", wts)

    # ------------------------------------------------------------------
    # Summary JSON
    # ------------------------------------------------------------------
    works = np.array(all_work_reduced, dtype=float)
    if len(works) > 0:
        log_w = compute_log_weights(works)
        ess = compute_ess(log_w)
        ess_normalized = ess / len(works)
        jarzynski_df = compute_jarzynski_delta_f(log_w)
    else:
        ess = ess_normalized = jarzynski_df = float("nan")

    summary = {
        "n_attempted": n_samples,
        "n_success": n_success,
        "n_failed": n_failed,
        "work_reduced_mean": float(np.mean(works)) if len(works) else None,
        "work_reduced_std": float(np.std(works)) if len(works) else None,
        "work_reduced_min": float(np.min(works)) if len(works) else None,
        "work_reduced_max": float(np.max(works)) if len(works) else None,
        "ess": ess if np.isfinite(ess) else None,
        "ess_normalized": ess_normalized if np.isfinite(ess_normalized) else None,
        "jarzynski_delta_f_reduced": jarzynski_df if np.isfinite(jarzynski_df) else None,
        "wall_time_s": time.time() - t_start,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2))

    elapsed = time.time() - t_start
    logger.info("=== OpenMM AIS complete: %d success, %d failed, wall %.1f s ===",
                n_success, n_failed, elapsed)
    logger.info("work_reduced: mean=%.4f  std=%.4f  ESS=%.1f (%.1f%%)",
                summary["work_reduced_mean"] or float("nan"),
                summary["work_reduced_std"] or float("nan"),
                ess, 100 * ess_normalized)

    return summary


# Backward-compat alias — existing code calling run_rest2_ais still works
run_rest2_ais = run_openmm_ais
