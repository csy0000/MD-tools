"""chunked_neq_launcher.py — process-level trajectory parallelism for chunked-NEQ AIS (report §7).

One OS process per worker.  Each worker owns its own OpenMM switching Context, NEQ integrator,
persistent cold-energy Context, random-seed sequence, output directory and (fixed) GPU.  Nothing
is shared: no two workers ever write the same file, and the merge step is deterministic
(``chunked_neq_ais.merge_workers``).

Why processes and not threads: an OpenMM Context is bound to the thread that created it and the
Python-side driver loop holds the GIL between ``step()`` calls, so threads would serialise exactly
the part we are trying to overlap.  Processes also isolate a worker crash.

Seed assignment is ``seed_{w,i} = base_seed + 10**6 · w + i`` (``chunked_neq_ais.worker_seed``),
which is collision-free for < 10**6 trajectories per worker and independent of how the launcher
happens to partition the work.

Primary throughput metric: **completed AIS trajectories per GPU-hour**
(``n_trajectories / (wall_clock_hours × n_gpus)``).  CUDA MPS is not required; if it is enabled
externally the same code benefits from it, which is why the launcher only ever sets
``DeviceIndex``.
"""
from __future__ import annotations

import json
import multiprocessing as mp
import os
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


from escort_ais.methods.chunked_neq_ais import (
    ChunkedNEQConfig,
    ChunkedNEQRunner,
    merge_workers,
    worker_seed,
)

__all__ = [
    "WorkerAssignment",
    "LaunchSpec",
    "assign_workers",
    "run_worker",
    "launch",
    "rerun_failed_partitions",
    "verify_partitions",
    "write_failed_partitions",
    "output_checksums",
]


# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class WorkerAssignment:
    worker_id: int
    device_index: Optional[str]
    trajectory_indices: list[int]        # GLOBAL trajectory ids (seeds follow these, not the order)
    frame_indices: list[int]             # source hot-MD frame per trajectory


@dataclass
class LaunchSpec:
    """A whole multi-worker AIS leg."""
    cfg: ChunkedNEQConfig                                # per-worker template (device_index is overridden)
    input_scaled_dir: Path
    run_dir: Path
    n_trajectories: int
    workers_per_gpu: int = 1     # §1: one per GPU is optimal for alanine without CUDA MPS
    device_indices: tuple[str, ...] = ("0",)
    base_seed: int = 20260728
    solvent: str = "implicit"
    start_frame_stride: int = 1
    start_frame_offset: int = 0
    omega_exclude_bonds: Optional[np.ndarray] = None
    cv_definition: Optional[str] = None   # systems/<slug>/cv_definition.json, or a slug
    resume: bool = True          # §7: skip global trajectory ids already flushed to disk
    command: Optional[str] = None                    # recorded verbatim in the run manifest

    @property
    def n_workers(self) -> int:
        return max(1, int(self.workers_per_gpu)) * max(1, len(self.device_indices))

    @property
    def n_gpus(self) -> int:
        return max(1, len(self.device_indices))


def assign_workers(n_trajectories: int, frame_indices: Sequence[int], workers_per_gpu: int,
                   device_indices: Sequence[str]) -> list[WorkerAssignment]:
    """Round-robin trajectories over ``workers_per_gpu × n_devices`` workers.

    Round-robin (not contiguous blocks) so that any systematic ordering of the source frames is
    spread evenly across workers — a worker that dies then costs a *representative* slice, not a
    contiguous chunk of the seed bank.
    """
    devices = [str(d) for d in device_indices] or [None]
    n_workers = max(1, int(workers_per_gpu)) * len(devices)
    out = [WorkerAssignment(worker_id=w, device_index=devices[w % len(devices)],
                            trajectory_indices=[], frame_indices=[])
           for w in range(n_workers)]
    for i in range(int(n_trajectories)):
        w = i % n_workers
        out[w].trajectory_indices.append(i)
        out[w].frame_indices.append(int(frame_indices[i]))
    return out


# ─────────────────────────── run manifest & partitions (§7) ──────────────────
def _sha256(path: Path, chunk: int = 1 << 20) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def _git_state() -> dict:
    import subprocess
    def run(*args):
        try:
            return subprocess.run(args, capture_output=True, text=True, timeout=10,
                                  cwd=str(Path(__file__).resolve().parent)).stdout.strip()
        except Exception:
            return ""
    return dict(commit=run("git", "rev-parse", "HEAD"),
                branch=run("git", "rev-parse", "--abbrev-ref", "HEAD"),
                dirty=bool(run("git", "status", "--porcelain")))


def output_checksums(run_dir: Path) -> dict:
    """sha256 of every per-worker and merged artefact, so a partition can be proven intact."""
    out = {}
    for pat in ("worker_*/*.parquet", "worker_*/*.npz", "merged/*.parquet", "merged/*.npz"):
        for f in sorted(Path(run_dir).glob(pat)):
            out[str(f.relative_to(run_dir))] = dict(sha256=_sha256(f), bytes=f.stat().st_size)
    return out


def write_failed_partitions(run_dir: Path, assignments, errors: dict) -> Optional[Path]:
    """Record exactly which trajectory ids are missing, so ONLY they can be rerun.

    The file is the rerun contract: ``--rerun-partition <path>`` replays these ids with their
    original global trajectory numbers (and therefore their original seeds), so a partial rerun
    is bit-identical to what the failed worker would have produced.
    """
    if not errors:
        return None
    by_id = {a.worker_id: a for a in assignments}
    rec = dict(failed_workers=[], n_failed_trajectories=0)
    for wid, msg in sorted(errors.items()):
        a = by_id.get(wid)
        traj = [int(t) for t in (a.trajectory_indices if a else [])]
        frames = [int(f) for f in (a.frame_indices if a else [])]
        rec["failed_workers"].append(dict(worker_id=wid, device_index=(a.device_index if a else None),
                                          error=str(msg)[:2000], trajectory_indices=traj,
                                          frame_indices=frames))
        rec["n_failed_trajectories"] += len(traj)
    p = Path(run_dir) / "failed_partitions.json"
    p.write_text(json.dumps(rec, indent=2, default=str))
    return p


def verify_partitions(run_dir: Path, expected: int) -> dict:
    """§7: which global trajectory ids actually made it to disk, and which are missing."""
    import pandas as pd
    present = set()
    for f in sorted(Path(run_dir).glob("worker_*/trajectory_summary.parquet")):
        try:
            present |= {int(i) for i in pd.read_parquet(f, columns=["trajectory_index"])
                        ["trajectory_index"].to_numpy()}
        except Exception:
            continue
    missing = sorted(set(range(int(expected))) - present)
    return dict(n_expected=int(expected), n_present=len(present), n_missing=len(missing),
                missing_trajectory_ids=missing[:1000], complete=not missing)


# ─────────────────────────────── the worker body ─────────────────────────────
def run_worker(payload: dict) -> dict:
    """Body of one worker process.  Importable/callable directly for single-worker benchmarks."""
    import mdtraj as md

    from escort_ais.methods.ais_linear import LinearAISConfig, _load_frame, load_ais_inputs

    cfg = ChunkedNEQConfig(**payload["cfg"])
    cfg.device_index = payload["device_index"]
    assign = payload["assignment"]
    run_dir = Path(payload["run_dir"])
    t_open = time.perf_counter()

    # the SAME loader the single-process driver uses (identical GBn2/parmed branch)
    lin = LinearAISConfig(solvent=payload["solvent"], k_ais=1, t_ais=cfg.t_ais, freq_ais=cfg.freq_ais,
                          s_hot=cfg.s_hot, s_cold=cfg.s_cold, temperature_k=cfg.temperature_k,
                          platform=cfg.platform, scaling_mode=cfg.scaling_mode)
    inputs = load_ais_inputs(lin, Path(payload["input_scaled_dir"]))

    # Generic CVs: the system declares them in systems/<slug>/cv_definition.json. Without this a
    # macrocycle records only mdtraj phi/psi, which do not exist on a cyclic topology -- the
    # all-NaN columns in the RGD Hummer-Szabo clouds.
    cv_def = None
    if payload.get("cv_definition"):
        from escort_ais.systems.cv_definition import load_cv_definition
        cv_def = load_cv_definition(payload["cv_definition"])

    runner = ChunkedNEQRunner(
        cfg, inputs.base_system, inputs.topology, inputs.solute_indices,
        phi_indices=inputs.phi_indices, psi_indices=inputs.psi_indices,
        omega_exclude_bonds=payload.get("omega_exclude_bonds"),
        worker_id=assign["worker_id"], base_seed=payload["base_seed"],
        cv_definition=cv_def)
    t_ready = time.perf_counter()

    # §7 resume: skip only what is DURABLY on disk. Trajectory ids are global, so the skip set
    # is meaningful no matter how the launcher partitioned the work this time.
    done_already = runner.already_done(run_dir) if payload.get("resume", True) else set()
    todo = [(t, f) for t, f in zip(assign["trajectory_indices"], assign["frame_indices"])
            if int(t) not in done_already]
    n_skipped = len(assign["trajectory_indices"]) - len(todo)

    n_done = 0
    for i_traj, frame_index in todo:
        with runner.timer("initial_frame_loading"):
            frame = _load_frame(md, inputs.source_traj_path, inputs.source_topology_path,
                                int(frame_index))
            xyz0 = np.asarray(frame.xyz[0], float)
            box = None
            if frame.unitcell_vectors is not None:
                from openmm import Vec3, unit as ommunit
                bv = np.asarray(frame.unitcell_vectors[0], float)
                box = tuple(Vec3(*row) * ommunit.nanometer for row in bv)
        rec = runner.run_trajectory(xyz0, box=box, trajectory_index=int(i_traj))
        rec["initial_frame_index"] = int(frame_index)
        runner.maybe_flush(run_dir)
        n_done += 1
    runner.flush(run_dir)

    t_end = time.perf_counter()
    prof = runner.profile()
    prof["_wall"] = dict(context_setup_s=t_ready - t_open, switching_s=t_end - t_ready,
                         total_s=t_end - t_open, n_trajectories=n_done,
                         n_skipped_already_done=n_skipped)
    prof["_worker"] = dict(worker_id=assign["worker_id"], device_index=cfg.device_index,
                           pid=os.getpid(),
                           first_seed=worker_seed(payload["base_seed"], assign["worker_id"], 0),
                           assigned=[int(t) for t in assign["trajectory_indices"]],
                           completed=sorted(int(t) for t in runner._completed | done_already))
    (run_dir / f"worker_{assign['worker_id']:02d}" / "profile.json").write_text(
        json.dumps(prof, indent=2, default=str))
    runner.close()
    return prof


def _worker_entry(payload: dict, q) -> None:
    try:
        q.put(("ok", payload["assignment"]["worker_id"], run_worker(payload)))
    except BaseException as exc:                                   # report, never hang the parent
        import traceback
        q.put(("error", payload["assignment"]["worker_id"],
               f"{type(exc).__name__}: {exc}\n{traceback.format_exc()[-2000:]}"))


# ────────────────────────────────── launcher ─────────────────────────────────
def launch(spec: LaunchSpec, merge: bool = True) -> dict:
    """Run ``spec.n_trajectories`` AIS legs across ``spec.n_workers`` processes and merge.

    Returns the run-level metrics dict (also written to ``run_dir/launch_metrics.json``).
    """
    from escort_ais.methods.ais_linear import (LinearAISConfig, _count_dcd_frames,
                                               candidate_initial_frame_indices, load_ais_inputs,
                                               sample_initial_frame_indices_from_candidates)

    run_dir = Path(spec.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)

    # frame selection is made ONCE in the parent, with the same helpers the single-process driver
    # uses, so the worker partition cannot change WHICH configurations are switched.
    lin = LinearAISConfig(solvent=spec.solvent, k_ais=spec.n_trajectories, t_ais=spec.cfg.t_ais,
                          freq_ais=spec.cfg.freq_ais, s_hot=spec.cfg.s_hot, s_cold=spec.cfg.s_cold,
                          seed=spec.base_seed, scaling_mode=spec.cfg.scaling_mode)
    inputs = load_ais_inputs(lin, Path(spec.input_scaled_dir))
    import mdtraj as md
    n_source_frames = _count_dcd_frames(md, inputs.source_traj_path, inputs.source_topology_path)
    candidates = candidate_initial_frame_indices(n_source_frames, stride=spec.start_frame_stride,
                                                offset=spec.start_frame_offset)
    frames, with_replacement = sample_initial_frame_indices_from_candidates(
        candidates, spec.n_trajectories, spec.base_seed)

    assignments = assign_workers(spec.n_trajectories, frames, spec.workers_per_gpu,
                                 spec.device_indices)
    cfg_dict = {k: (str(v) if isinstance(v, Path) else v) for k, v in asdict(spec.cfg).items()}
    payloads = [dict(cfg=cfg_dict, device_index=a.device_index, assignment=asdict(a),
                     run_dir=str(run_dir), input_scaled_dir=str(spec.input_scaled_dir),
                     solvent=spec.solvent, base_seed=spec.base_seed,
                     omega_exclude_bonds=spec.omega_exclude_bonds, cv_definition=spec.cv_definition,
                     resume=spec.resume)
                for a in assignments]

    ctx = mp.get_context("spawn")            # a forked CUDA context is invalid; spawn is mandatory
    started_at = _now()
    t0 = time.perf_counter()
    profiles: dict[int, dict] = {}
    errors: dict[int, str] = {}
    if len(payloads) == 1:
        profiles[0] = run_worker(payloads[0])              # in-process: cleaner single-worker timing
    else:
        q = ctx.Queue()
        procs = [ctx.Process(target=_worker_entry, args=(p, q), daemon=False) for p in payloads]
        for p in procs:
            p.start()
        for _ in procs:
            status, wid, body = q.get()
            (profiles if status == "ok" else errors)[wid] = body
        for p in procs:
            p.join()
        for p, pay in zip(procs, payloads):
            if p.exitcode not in (0, None):
                errors.setdefault(pay["assignment"]["worker_id"],
                                  f"exitcode {p.exitcode}")
    wall = time.perf_counter() - t0

    finished_at = _now()
    n_done = sum(pr["_wall"]["n_trajectories"] for pr in profiles.values())
    n_skipped = sum(pr["_wall"].get("n_skipped_already_done", 0) for pr in profiles.values())
    metrics = dict(
        n_trajectories_requested=spec.n_trajectories, n_trajectories_completed=int(n_done),
        n_workers=spec.n_workers, workers_per_gpu=spec.workers_per_gpu,
        device_indices=list(spec.device_indices), n_gpus=spec.n_gpus,
        mode=spec.cfg.mode, m_ais=spec.cfg.m_ais, freq_ais=spec.cfg.freq_ais,
        t_ais=spec.cfg.t_ais, scaling_mode=spec.cfg.scaling_mode,
        hz_n_observations=(spec.cfg.hz_n_observations if spec.cfg.collects_hz else 0),
        hz_s_min=(spec.cfg.hz_s_min if spec.cfg.collects_hz else None),
        full_coordinate_interval_ps=spec.cfg.full_coordinate_interval_ps,
        wall_clock_s=wall,
        trajectories_per_gpu_hour=(n_done / (wall / 3600.0) / spec.n_gpus) if wall > 0 else float("nan"),
        trajectories_per_hour=(n_done / (wall / 3600.0)) if wall > 0 else float("nan"),
        n_trajectories_skipped_resume=int(n_skipped),
        sampled_with_replacement=bool(with_replacement),
        base_seed=spec.base_seed, errors=errors,
        per_worker={str(w): pr["_wall"] for w, pr in sorted(profiles.items())},
        stage_timings={str(w): {k: v for k, v in pr.items() if not k.startswith("_")}
                       for w, pr in sorted(profiles.items())},
    )
    # §7: merge ONLY completed partitions, then say exactly what is missing.
    metrics["partitions"] = verify_partitions(run_dir, spec.n_trajectories)
    if merge and profiles:
        metrics["merged"] = merge_workers(run_dir)
    failed_path = write_failed_partitions(run_dir, assignments, errors)
    if failed_path is not None:
        metrics["failed_partitions_file"] = str(failed_path)

    # ── run-level manifest (§7) ─────────────────────────────────────────────
    banner = next((pr.get("_banner") for pr in profiles.values() if pr.get("_banner")), {})
    manifest = dict(
        git=_git_state(),
        command=spec.command,
        started_at=started_at, finished_at=finished_at, wall_clock_s=wall,
        configuration=cfg_dict,
        gpu_list=list(spec.device_indices), worker_count=spec.n_workers,
        workers_per_gpu=spec.workers_per_gpu,
        openmm_platform=banner.get("actual_platform", spec.cfg.platform),
        precision=banner.get("actual_precision", spec.cfg.precision),
        openmm_version=banner.get("openmm_version"),
        random_seeds=dict(base_seed=spec.base_seed,
                          per_worker_first={str(a.worker_id):
                                            worker_seed(spec.base_seed, a.worker_id, 0)
                                            for a in assignments},
                          formula="seed_{w,i} = base_seed + 10**6 * w + i"),
        input_seed_bank=dict(input_scaled_dir=str(spec.input_scaled_dir),
                             trajectory=str(inputs.source_traj_path),
                             topology=str(inputs.source_topology_path),
                             n_source_frames=int(n_source_frames),
                             start_frame_stride=spec.start_frame_stride,
                             start_frame_offset=spec.start_frame_offset,
                             sampled_with_replacement=bool(with_replacement)),
        trajectories=dict(requested=spec.n_trajectories, completed=int(n_done),
                          skipped_already_done=int(n_skipped),
                          failed=metrics["partitions"]["n_missing"],
                          missing_ids=metrics["partitions"]["missing_trajectory_ids"]),
        runtime_banner=banner,
        output_checksums=output_checksums(run_dir),
    )
    (run_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    metrics["run_manifest"] = str(run_dir / "run_manifest.json")

    (run_dir / "launch_metrics.json").write_text(json.dumps(metrics, indent=2, default=str))
    if errors:
        raise RuntimeError(
            f"{len(errors)} worker(s) failed; {metrics['partitions']['n_missing']} trajectories "
            f"missing. Failed partitions recorded in {failed_path}. Rerun only those with "
            f"rerun_failed_partitions(). Errors: "
            + "; ".join(f"w{w}: {e.splitlines()[0]}" for w, e in errors.items()))
    return metrics


def rerun_failed_partitions(run_dir: Path, spec: LaunchSpec) -> dict:
    """§7: replay ONLY the trajectory ids recorded in ``failed_partitions.json``.

    Global trajectory ids (and therefore seeds) are preserved, so the rerun produces exactly what
    the failed worker would have produced -- not a fresh sample.
    """
    rec_path = Path(run_dir) / "failed_partitions.json"
    if not rec_path.exists():
        return dict(status="nothing to rerun", n_trajectories=0)
    rec = json.loads(rec_path.read_text())
    pairs = [(t, f) for w in rec["failed_workers"]
             for t, f in zip(w["trajectory_indices"], w["frame_indices"])]
    if not pairs:
        return dict(status="nothing to rerun", n_trajectories=0)

    devices = [str(d) for d in spec.device_indices] or ["0"]
    n_workers = max(1, spec.workers_per_gpu) * len(devices)
    assignments = [WorkerAssignment(worker_id=w, device_index=devices[w % len(devices)],
                                    trajectory_indices=[], frame_indices=[])
                   for w in range(n_workers)]
    for j, (t, f) in enumerate(pairs):
        a = assignments[j % n_workers]
        a.trajectory_indices.append(int(t))
        a.frame_indices.append(int(f))
    cfg_dict = {k: (str(v) if isinstance(v, Path) else v) for k, v in asdict(spec.cfg).items()}
    payloads = [dict(cfg=cfg_dict, device_index=a.device_index, assignment=asdict(a),
                     run_dir=str(run_dir), input_scaled_dir=str(spec.input_scaled_dir),
                     solvent=spec.solvent, base_seed=spec.base_seed,
                     omega_exclude_bonds=spec.omega_exclude_bonds, cv_definition=spec.cv_definition,
                     resume=True)
                for a in assignments if a.trajectory_indices]

    ctx = mp.get_context("spawn")
    profiles, errors = {}, {}
    if len(payloads) == 1:
        profiles[payloads[0]["assignment"]["worker_id"]] = run_worker(payloads[0])
    else:
        q = ctx.Queue()
        procs = [ctx.Process(target=_worker_entry, args=(pl, q), daemon=False) for pl in payloads]
        for pr in procs:
            pr.start()
        for _ in procs:
            status, wid, body = q.get()
            (profiles if status == "ok" else errors)[wid] = body
        for pr in procs:
            pr.join()
    parts = verify_partitions(run_dir, spec.n_trajectories)
    if parts["complete"]:
        rec_path.unlink(missing_ok=True)
    merge_workers(run_dir)
    return dict(status="ok" if not errors else "partial", n_trajectories=len(pairs),
                errors=errors, partitions=parts)
