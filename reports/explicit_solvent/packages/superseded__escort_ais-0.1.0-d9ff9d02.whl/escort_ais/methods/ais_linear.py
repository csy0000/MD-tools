from __future__ import annotations

import csv
import json
import logging
import math
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Optional

import numpy as np
from scipy.special import logsumexp


LinearAISSolvent = Literal["implicit", "explicit"]

_SOLUTE_RESIDUES = {"ACE", "ALA", "NME"}


@dataclass
class LinearAISConfig:
    solvent: LinearAISSolvent
    k_ais: int
    t_ais: int
    freq_ais: int
    s_hot: float = 0.188
    s_cold: float = 1.0
    temperature_k: float = 300.0
    platform: str = "CPU"
    seed: int = 123
    start_frame_stride: int = 1
    start_frame_offset: int = 0
    input_scaled_dir: Optional[Path] = None
    output_dir: Optional[Path] = None
    overwrite: bool = False
    dry_run: bool = False
    save_traj_every_switch: bool = True
    save_tail_ps: Optional[float] = None
    # Subsample WHICH λ-windows write a coordinate + the cold-state energy U_target when
    # save_traj_every_switch is on: keep interval_index % save_switch_stride == 0.
    # 1 = previous behaviour (every switch).  Purely additive; used by the mixture-CFT
    # time-slice reweighting, which needs u_C(x_ik) at intermediate AIS configurations but
    # not at all 2500 of them.  Ignored when save_tail_ps selects the tail instead.
    save_switch_stride: int = 1
    device_index: Optional[str] = None
    # (M,2) OpenMM atom-index pairs: central bonds of omega torsions to leave UNSCALED
    # (non-proline-like peptide bonds for macrocycles). None = scale all solute torsions.
    omega_exclude_bonds: Optional["np.ndarray"] = None
    # Drive per-window REST2 scaling via GPU-side global parameters (parameter offsets +
    # CustomTorsion + GB global) instead of per-window updateParametersInContext reloads.
    # Auto-falls back to the reload scaler for CMAP/non-all-solute systems.
    gpu_switching: bool = True
    # REST2 scale-schedule spacing: 'linear' (even in s) or 'square' (even in sqrt(s); the natural REST2
    # coordinate — solute-solvent coupling ~sqrt(s) — used by the square-spaced BAIS/REMD ladders).
    scaling_mode: str = "linear"
    # Accumulate the AIS protocol work ON THE GPU inside an openmmtools nonequilibrium (NEQ) integrator
    # (AlchemicalNonequilibriumLangevinIntegrator) — one work readback per trajectory instead of the manual
    # per-λ-window getState loop. Numerically validated identical to the manual path (frozen work to ~1e-13);
    # requires the GPU-side global-parameter scaler (gpu_switching). Off by default (opt-in).
    neq_integrator: bool = False
    # CO-SWITCH strategy: ramp a von-Mises umbrella U_m = Σ κ_t[1-cos(θ_t-μ_t)] LINEARLY with λ (U_bias = λ·U_m)
    # ALONGSIDE the REST2 scale, so the switch runs H_1↔C_m directly (endpoint C_m = cold + full umbrella). When
    # `umbrella_quartets` is set the co-switch is active: λ(s) = (s-s_lo)/(s_hi-s_lo) drives `umbrella_lambda`
    # (0 at the hottest scale → 1 at the coldest). The work automatically includes both the REST2 and umbrella
    # changes. (Endpoint strategy = leave these None; the umbrella enters as the ±U_m estimator endpoint term.)
    umbrella_quartets: Optional["np.ndarray"] = None                 # (d,4) torsion atom indices
    umbrella_mu: Optional["np.ndarray"] = None                       # (d,) window centres (rad)
    umbrella_kappa: Optional["np.ndarray"] = None                    # (d,) per-torsion concentrations
    umbrella_kT_kj: float = 1.0                                      # kT in kJ/mol (κ is reduced)
    # umbrella ramp χ(λ_cold)=λ_cold^exponent (λ_cold=0 hot→1 cold): 1.0 = LINEAR in the protocol coordinate;
    # >1 = CONVEX (grows slower when hot, faster when cold — the √s/s-flavoured schedule). Exact-reverse for any
    # exponent (χ depends only on physical coldness). decompose_coswitch_work logs per-step biasing vs tempering work.
    coswitch_ramp_exponent: float = 1.0
    # WALL-STRATIFIED co-switch: anneal a flat-bottom wall instead of a von-Mises umbrella. Shares
    # the `umbrella_lambda` ramp -- the two are mutually exclusive and setting both is refused.
    wall_quartets: Optional["np.ndarray"] = None
    wall_cell: object = None
    wall_k_hot: float = 0.0
    wall_k_cold: float = 100.0
    wall_kT_kj: float = 1.0
    decompose_coswitch_work: bool = False
    # ── process-level parallelism over the K independent AIS trajectories (Part 6) ──────────────
    # n_workers=1 (default) keeps the historical single-process path byte-for-byte. With
    # n_workers>1 the SELECTED FRAMES are partitioned deterministically (round-robin on the global
    # ais_trajectory_index), each worker builds its OWN OpenMM context in a *spawned* process, and
    # the parent merges outputs back into ais_trajectory_index order. Seeds are derived from
    # (config.seed, global trajectory index), so a trajectory gets the same seed at any n_workers.
    n_workers: int = 1
    # Device string per worker, e.g. ["0", "1"]. Workers are mapped round-robin onto this list;
    # None reuses config.device_index for every worker.
    worker_device_indices: Optional[list[str]] = None


# ── frozen-work validation escape hatch (Part 2) ───────────────────────────────────────────────
# s_hot == s_cold makes every ΔW identically zero, which is a *test* configuration (it is how the
# frozen-work telescoping identity is checked), never a production one. It is allowed only when
# explicitly requested, so a mistyped production config cannot silently produce W ≡ 0.
ALLOW_ZERO_WORK_ENV = "ESCORT_AIS_ALLOW_ZERO_WORK"
SUPPORTED_SCALING_MODES = ("linear", "square")
SUPPORTED_PLATFORMS = ("Reference", "CPU", "CUDA", "OpenCL", "HIP")


def validate_ais_config(config: LinearAISConfig, *, allow_zero_work: Optional[bool] = None) -> None:
    """Validate a :class:`LinearAISConfig` BEFORE any system or trajectory construction (Part 2).

    Cheap, import-free, and unit-testable: every failure here would otherwise surface minutes
    later, after topology building and context creation, or — worse — not at all.

    The NEQ conditions are the load-bearing ones. ``neq_integrator`` drives REST2 through *global
    context parameters*, which only the GPU-side scaler exposes, and it accumulates work on-device
    with a single readback per trajectory. It therefore cannot honour per-window intermediate
    output, and a request for it is an error rather than something to ignore.
    """
    import os

    validate_ais_lengths(config.k_ais, config.t_ais, config.freq_ais)

    if not (config.s_hot > 0.0):
        raise ValueError(f"s_hot must be positive; got {config.s_hot}.")
    if not (config.s_cold > 0.0):
        raise ValueError(f"s_cold must be positive; got {config.s_cold}.")
    if allow_zero_work is None:
        allow_zero_work = os.environ.get(ALLOW_ZERO_WORK_ENV, "") not in ("", "0", "false", "False")
    if math.isclose(float(config.s_hot), float(config.s_cold)) and not allow_zero_work:
        raise ValueError(
            f"s_hot == s_cold ({config.s_hot}) makes every work increment identically zero. "
            f"That is a frozen-work validation mode, not a production run: pass "
            f"allow_zero_work=True or set {ALLOW_ZERO_WORK_ENV}=1 if it is intended."
        )
    if config.scaling_mode not in SUPPORTED_SCALING_MODES:
        raise ValueError(
            f"unknown scaling_mode {config.scaling_mode!r}; expected one of {SUPPORTED_SCALING_MODES}."
        )
    if config.platform not in SUPPORTED_PLATFORMS:
        raise ValueError(
            f"unknown platform {config.platform!r}; expected one of {SUPPORTED_PLATFORMS}."
        )
    if config.temperature_k <= 0.0:
        raise ValueError(f"temperature_k must be positive; got {config.temperature_k}.")
    if int(config.save_switch_stride) < 1:
        raise ValueError(f"save_switch_stride must be >= 1; got {config.save_switch_stride}.")
    if int(config.n_workers) < 1:
        raise ValueError(f"n_workers must be >= 1; got {config.n_workers}.")
    if config.worker_device_indices is not None and len(config.worker_device_indices) == 0:
        raise ValueError("worker_device_indices must be None or a non-empty list.")

    if config.neq_integrator:
        if not config.gpu_switching:
            raise ValueError(
                "neq_integrator=True requires gpu_switching=True: the on-device nonequilibrium "
                "integrator drives REST2 through global context parameters, which only the "
                "GPU-side Rest2LambdaScaler exposes."
            )
        if config.save_traj_every_switch or config.save_tail_ps is not None:
            raise ValueError(
                "neq_integrator=True currently produces final work and final coordinates only. "
                "Set save_traj_every_switch=False and save_tail_ps=None, or use the manual AIS "
                "path when intermediate work samples are required."
            )
        if config.decompose_coswitch_work:
            raise ValueError(
                "neq_integrator=True cannot decompose the co-switch work: the split needs the "
                "per-window umbrella energy, which the on-device path never reads back. Use the "
                "manual AIS path (neq_integrator=False)."
            )


def resolve_tail_intervals(
    save_tail_ps: Optional[float],
    m_ais: int,
    freq_ais: int,
    timestep_fs: float,
) -> Optional[int]:
    """Return the number of near-target tail intervals to save, or *None* if all.

    When *save_tail_ps* is set, only the last ``n_tail`` intervals (those whose
    pre-propagation configs are closest to the target Hamiltonian) are written to
    ``ais_work_coordinates.dcd``.  Work increments are still accumulated for all
    intervals so ``cumulative_W`` stays correct.

    :param save_tail_ps: length of tail to save in picoseconds, or *None*.
    :param m_ais: number of AIS intervals per trajectory.
    :param freq_ais: MD steps per interval.
    :param timestep_fs: MD timestep in femtoseconds.
    :returns: integer tail count, or *None* if all intervals should be saved.
    :raises ValueError: if *save_tail_ps* resolves to 0 or more than *m_ais*.
    """
    if save_tail_ps is None:
        return None
    interval_ps = freq_ais * timestep_fs / 1000.0
    if interval_ps <= 0.0:
        raise ValueError("interval_ps must be positive; check freq_ais and timestep_fs.")
    n = round(save_tail_ps / interval_ps)
    if n < 1:
        raise ValueError(
            f"save_tail_ps={save_tail_ps} ps resolves to 0 tail intervals "
            f"(interval duration={interval_ps:.4f} ps). Increase save_tail_ps."
        )
    if n > m_ais:
        raise ValueError(
            f"save_tail_ps={save_tail_ps} ps resolves to {n} tail intervals > "
            f"M_ais={m_ais}. Reduce save_tail_ps or increase T_ais/decrease Freq_ais."
        )
    return n


def validate_ais_lengths(k_ais: int, t_ais: int, freq_ais: int) -> tuple[int, int]:
    if k_ais <= 0:
        raise ValueError("K_ais must be positive.")
    if t_ais <= 0:
        raise ValueError("T_ais must be positive.")
    if freq_ais <= 0:
        raise ValueError("Freq_ais must be positive.")
    if t_ais % freq_ais != 0:
        raise ValueError(
            f"T_ais must be divisible by Freq_ais; got T_ais={t_ais}, Freq_ais={freq_ais}."
        )
    m_ais = t_ais // freq_ais
    n_ais = k_ais * m_ais
    return m_ais, n_ais


def make_linear_scaling_schedule(s_hot: float, s_cold: float, m_ais: int, mode: str = "linear") -> np.ndarray:
    """REST2 scale schedule s_hot->s_cold over m_ais windows (m_ais+1 rungs).

    mode='linear' : even in s (the historical schedule).
    mode='square' : even in sqrt(s) — s = (linspace(sqrt(s_hot), sqrt(s_cold)))**2. This is the natural REST2
        coordinate because the solute-solvent coupling scales as sqrt(s), so even sqrt(s) spacing keeps the
        per-window work (and thus AIS overlap) roughly uniform; matches the square-spaced REMD ladders.
    """
    if m_ais <= 0:
        raise ValueError("M_ais must be positive.")
    if mode == "square":
        return np.linspace(math.sqrt(float(s_hot)), math.sqrt(float(s_cold)), int(m_ais) + 1) ** 2
    if mode != "linear":
        raise ValueError(f"unknown schedule mode {mode!r} (expected 'linear' or 'square')")
    return np.linspace(float(s_hot), float(s_cold), int(m_ais) + 1)


def compute_lambda_from_scale(scale: float, s_hot: float, s_cold: float) -> float:
    if math.isclose(s_cold, s_hot):
        return 0.0
    return float((scale - s_hot) / (s_cold - s_hot))


# ── openmmtools NEQ (nonequilibrium) integrator path ─────────────────────────────────────────────
def alchemical_functions_for(s_hot: float, s_cold: float, scaling_mode: str = "linear") -> dict[str, str]:
    """REST2 global parameters as Lepton expressions in the master alchemical variable ``lambda``∈[0,1], so that
    at ``lambda = i/M_ais`` the scale ``s`` equals ``make_linear_scaling_schedule(...)[i]`` exactly. Mirrors
    ``Rest2LambdaScaler.apply``: rest2_sqrt_s_minus_1=√s−1, rest2_s_minus_1=s−1, {lambda_rest, rest2_scale_gb,
    lambda_cmap}=s. ``scaling_mode``: 'linear' (s even) or 'square' (√s even)."""
    sh, sc = float(s_hot), float(s_cold)
    if scaling_mode == "square":
        rh, rc = math.sqrt(sh), math.sqrt(sc)
        s = f"(({rh}) + ({rc - rh})*lambda)^2"
    elif scaling_mode == "linear":
        s = f"(({sh}) + ({sc - sh})*lambda)"
    else:
        raise ValueError(f"unknown scaling_mode {scaling_mode!r} (expected 'linear' or 'square')")
    return {"rest2_sqrt_s_minus_1": f"sqrt({s}) - 1", "rest2_s_minus_1": f"{s} - 1",
            "lambda_rest": s, "rest2_scale_gb": s, "lambda_cmap": s}


def active_alchemical_functions(s_hot: float, s_cold: float, scaling_mode: str,
                                existing_params) -> dict[str, str]:
    """The REST2 alchemical functions that are actually present in the system (Part 1).

    The NEQ integrator can only drive global parameters the system defines. If the intersection is
    empty the integrator would run happily and ramp *nothing*: every window would be a pure MD
    propagation, the accumulated protocol work would be ~0, and the run would produce a confidently
    wrong Delta f rather than an error. Refuse instead, and do it here so it is unit-testable
    without building a Context.
    """
    wanted = alchemical_functions_for(s_hot, s_cold, scaling_mode)
    present = set(existing_params or ())
    active = {key: value for key, value in wanted.items() if key in present}
    if not active:
        raise RuntimeError(
            "No REST2 global parameters were found for the NEQ integrator. Expected at least one "
            f"of {sorted(wanted)}; the system exposes {sorted(present) or 'none'}. The on-device "
            "path cannot drive this system — use the manual AIS path (neq_integrator=False)."
        )
    return active


UMBRELLA_FORCE_GROUP = 30                                            # own force group so the bias reads in isolation


def build_coswitch_umbrella_force(quartets, mu, kappa, kT_kj, group=UMBRELLA_FORCE_GROUP, openmm=None):
    """CO-SWITCH umbrella: U_bias = umbrella_lambda · Σ_t κ_t·kT·[1-cos(θ_t-μ_t)]  (a CustomTorsionForce whose
    global parameter `umbrella_lambda`∈[0,1] linearly ramps the von-Mises umbrella of window m). Byte-identical to
    ``coverage_windows.bias_u`` at umbrella_lambda=1. Own force group so its bias reads in isolation."""
    if openmm is None:
        import openmm
    q = np.asarray(quartets, int); m = np.asarray(mu, float); k = np.asarray(kappa, float)
    f = openmm.CustomTorsionForce("umbrella_lambda*ktors*(1-cos(theta-phiref))")
    f.addGlobalParameter("umbrella_lambda", 0.0)
    f.addPerTorsionParameter("ktors"); f.addPerTorsionParameter("phiref")
    for t in range(len(q)):
        f.addTorsion(int(q[t, 0]), int(q[t, 1]), int(q[t, 2]), int(q[t, 3]),
                     [float(k[t] * kT_kj), float(m[t])])
    f.setForceGroup(int(group))
    return f


def coswitch_lambda(progress, cold_at_end, exponent=1.0):
    """Umbrella ramp χ(λ_cold)=λ_cold**exponent, where λ_cold∈[0,1] is the physical *coldness* (0 hot → 1 cold):
    ``progress``∈[0,1] is the leg progress (0 start, 1 end); for a forward (hot→cold) leg λ_cold=progress, for a
    reverse (cold→hot) leg λ_cold=1-progress, so the umbrella turns on toward the cold end in both directions and
    the protocol is exact-reverse for any exponent. exponent=1 → LINEAR in the protocol coordinate (U_bias=λ·U_m);
    exponent>1 → CONVEX: grows slower when hot, faster when cold (the √s/s-flavoured schedule)."""
    lam_cold = float(progress) if cold_at_end else (1.0 - float(progress))
    return lam_cold ** float(exponent)


def build_neq_integrator(config, m_ais: int, timestep_fs: float, friction_per_ps: float, existing_params, openmm,
                         random_seed: Optional[int] = None):
    """openmmtools ``AlchemicalNonequilibriumLangevinIntegrator`` that ramps ``lambda`` 0→1 over ``M_ais`` windows
    (one alchemical perturbation ``H`` + ``Freq_ais`` BAOAB propagation steps per window), accumulating the
    protocol work ON the GPU. Only REST2 params present in the system are driven. Returns the integrator.

    ``random_seed`` seeds the Langevin (O-step) noise and MUST be applied before the ``Context`` is created —
    ``setRandomNumberSeed`` after Context construction is silently ignored by OpenMM.  Left unset, the platform
    draws its own seed and the accumulated work is NOT reproducible run to run (only the *initial velocities*
    were ever seeded).  The driver now passes ``config.seed``, which makes the whole per-leg SEQUENCE of
    trajectories reproducible while keeping consecutive trajectories independent (``reset()`` does not rewind
    the random stream)."""
    from openmm import unit
    from openmmtools.integrators import AlchemicalNonequilibriumLangevinIntegrator
    afuncs = active_alchemical_functions(config.s_hot, config.s_cold, config.scaling_mode, existing_params)
    splitting = "H " + " ".join(["V R O R V"] * max(int(config.freq_ais), 1))
    integ = AlchemicalNonequilibriumLangevinIntegrator(
        alchemical_functions=afuncs, nsteps_neq=int(m_ais), splitting=splitting,
        temperature=config.temperature_k * unit.kelvin, collision_rate=friction_per_ps / unit.picosecond,
        timestep=timestep_fs * unit.femtosecond)
    if random_seed is not None:
        integ.setRandomNumberSeed(int(random_seed))
    return integ


class PhaseTimer:
    """Accumulating ``perf_counter`` stopwatch, one entry per named phase (Part 4).

    Deliberately dumb: no logging inside a timed block, so logger/formatting cost is never charged
    to GPU propagation. Nested phases are allowed and recorded independently; the reconciliation
    against the total is reported rather than enforced.
    """

    def __init__(self) -> None:
        import time
        self._perf = time.perf_counter
        self.totals: dict[str, float] = {}
        self._t0 = self._perf()

    class _Scope:
        def __init__(self, owner: "PhaseTimer", name: str) -> None:
            self.owner, self.name = owner, name

        def __enter__(self):
            self.t = self.owner._perf()
            return self

        def __exit__(self, *exc):
            self.owner.add(self.name, self.owner._perf() - self.t)
            return False

    def phase(self, name: str) -> "PhaseTimer._Scope":
        return PhaseTimer._Scope(self, name)

    def add(self, name: str, seconds: float) -> None:
        self.totals[name] = self.totals.get(name, 0.0) + float(seconds)

    @property
    def elapsed(self) -> float:
        return float(self._perf() - self._t0)


def summarize_timings(timer: PhaseTimer, per_trajectory: list[dict], *, m_ais: int, freq_ais: int,
                      k_ais: int, setup_phases: tuple[str, ...]) -> dict:
    """Phase totals, per-trajectory statistics and throughput (Part 4).

    ``ns/day`` is reported only for the propagation itself; quoting it against wall clock would
    fold in one-off setup and flatter the number.
    """
    totals = dict(timer.totals)
    total_runtime = timer.elapsed
    setup_s = float(sum(totals.get(p, 0.0) for p in setup_phases))
    per = {key: np.array([row.get(key, float("nan")) for row in per_trajectory], dtype=float)
           for key in ("frame_load_s", "state_setup_s", "ais_execution_s", "work_readback_s",
                       "final_state_readback_s", "output_write_s", "total_trajectory_s")}
    steps_per_traj = int(m_ais) * int(freq_ais)
    total_steps = steps_per_traj * int(k_ais)
    prop_s = float(np.nansum(per["ais_execution_s"])) if per_trajectory else 0.0

    def _stat(fn, arr):
        return float(fn(arr)) if arr.size and np.isfinite(arr).any() else float("nan")

    out = {
        "phase_totals_s": totals,
        "total_runtime_s": total_runtime,
        "setup_s": setup_s,
        "runtime_excluding_setup_s": total_runtime - setup_s,
        "K_ais": int(k_ais), "M_ais": int(m_ais), "Freq_ais": int(freq_ais),
        "md_steps_per_trajectory": steps_per_traj,
        "total_propagated_steps": total_steps,
        "per_trajectory_s": {
            "mean": _stat(np.nanmean, per["total_trajectory_s"]),
            "median": _stat(np.nanmedian, per["total_trajectory_s"]),
            "std": _stat(np.nanstd, per["total_trajectory_s"]),
            "min": _stat(np.nanmin, per["total_trajectory_s"]),
            "max": _stat(np.nanmax, per["total_trajectory_s"]),
        },
        "per_trajectory_phase_mean_s": {k: _stat(np.nanmean, v) for k, v in per.items()},
        "trajectories_per_second_including_setup": (k_ais / total_runtime) if total_runtime > 0 else float("nan"),
        "trajectories_per_second_excluding_setup": (
            k_ais / (total_runtime - setup_s) if (total_runtime - setup_s) > 0 else float("nan")),
        "md_steps_per_second_propagation_only": (total_steps / prop_s) if prop_s > 0 else float("nan"),
    }
    return out


def add_ns_per_day(summary: dict, timestep_fs: float) -> dict:
    """ns/day from the propagation-only step rate; meaningless without a timestep, so kept apart."""
    rate = summary.get("md_steps_per_second_propagation_only", float("nan"))
    if rate and np.isfinite(rate):
        summary["ns_per_day_propagation_only"] = float(rate * timestep_fs * 1e-6 * 86400.0)
    else:
        summary["ns_per_day_propagation_only"] = float("nan")
    return summary


def describe_execution_mode(config: LinearAISConfig, simulation, scaler, gpu_switching_active: bool,
                            m_ais: int, n_ais: int) -> dict:
    """What the run is ACTUALLY doing, queried from the live Context where possible (Part 3).

    Recording only the *requested* settings has bitten this driver before: gpu_switching silently
    falls back, and the CUDA platform silently defaults to single precision. Every field below is
    read from the constructed objects, not from the config, wherever OpenMM exposes it.
    """
    platform = simulation.context.getPlatform()
    platform_actual = platform.getName()
    precision = None
    if platform_actual in ("CUDA", "OpenCL"):
        try:
            precision = platform.getPropertyValue(simulation.context, "Precision")
        except Exception:                                            # property absent on this build
            precision = None
    device = None
    for prop in ("DeviceIndex", "OpenCLDeviceIndex"):
        try:
            device = platform.getPropertyValue(simulation.context, prop)
            break
        except Exception:
            continue
    return {
        "gpu_switching_requested": bool(config.gpu_switching),
        "gpu_switching_active": bool(gpu_switching_active),
        "scaler_class": type(scaler).__name__,
        "neq_integrator": bool(config.neq_integrator),
        "integrator_class": type(simulation.integrator).__name__,
        "platform_requested": config.platform,
        "platform_actual": platform_actual,
        "device_index_requested": config.device_index,
        "device_index_actual": device,
        "precision": precision,
        "scaling_mode": config.scaling_mode,
        "M_ais": int(m_ais),
        "N_ais": int(n_ais),
        "Freq_ais": int(config.freq_ais),
        "n_workers": int(config.n_workers),
        # The NEQ path reads work back once per trajectory and never reads intermediate
        # coordinates, so downstream consumers (Hummer-Szabo reweighting) must be able to tell.
        "intermediate_work_available": not bool(config.neq_integrator),
        "intermediate_coordinates_available": not bool(config.neq_integrator),
    }


def format_execution_mode(mode: dict) -> str:
    keys = ("platform_actual", "precision", "scaler_class", "gpu_switching_active",
            "integrator_class", "neq_integrator", "M_ais", "Freq_ais", "n_workers")
    return "\n".join(f"  {k}={mode[k]}" for k in keys if k in mode)


def candidate_initial_frame_indices(
    n_frames: int,
    stride: int = 1,
    offset: int = 0,
) -> np.ndarray:
    if n_frames <= 0:
        raise ValueError("n_frames must be positive.")
    if stride <= 0:
        raise ValueError("start_frame_stride must be positive.")
    if offset < 0:
        raise ValueError("start_frame_offset must be non-negative.")
    indices = np.arange(offset, n_frames, stride, dtype=np.int64)
    if len(indices) == 0:
        raise ValueError(
            f"No usable starting frames for n_frames={n_frames}, stride={stride}, offset={offset}."
        )
    return indices


def sample_initial_frame_indices_from_candidates(
    candidate_indices: np.ndarray,
    k_ais: int,
    seed: int,
) -> tuple[np.ndarray, bool]:
    rng = np.random.default_rng(seed)
    candidate_indices = np.asarray(candidate_indices, dtype=np.int64)
    replace = len(candidate_indices) < k_ais
    selected = rng.choice(candidate_indices, size=k_ais, replace=replace)
    return np.asarray(selected, dtype=np.int64), bool(replace)


def summarize_final_log_weights(final_logw: np.ndarray) -> dict[str, float]:
    final_logw = np.asarray(final_logw, dtype=float)
    if final_logw.size == 0:
        return {
            "mean_final_logw": float("nan"),
            "std_final_logw": float("nan"),
            "min_final_logw": float("nan"),
            "max_final_logw": float("nan"),
            "ess": float("nan"),
            "ess_over_k": float("nan"),
        }

    logw_norm = final_logw - logsumexp(final_logw)
    weights = np.exp(logw_norm)
    ess = float(1.0 / np.sum(weights ** 2))
    return {
        "mean_final_logw": float(np.mean(final_logw)),
        "std_final_logw": float(np.std(final_logw)),
        "min_final_logw": float(np.min(final_logw)),
        "max_final_logw": float(np.max(final_logw)),
        "ess": ess,
        "ess_over_k": float(ess / len(final_logw)),
    }


def default_input_scaled_dir(repo_root: Path, solvent: LinearAISSolvent) -> Path:
    if solvent == "explicit":
        return (
            repo_root
            / "data/alanine_dipeptide/md_explicit"
            / "etkdg_v3_seed_20260526_n20000_opc_opencl_1us_scale_0p188_replica_00"
        )
    return (
        repo_root
        / "data/alanine_dipeptide/md"
        / "ff19sb_gbn2_300K_nvt_5ns_s0p2"
    )


def default_output_dir(repo_root: Path, config: LinearAISConfig) -> Path:
    if config.output_dir is not None:
        return Path(config.output_dir)

    solvent_tag = "explicit_opc" if config.solvent == "explicit" else "implicit_gbn2"
    scale_tag = f"scale_{_scale_label(config.s_hot)}_to_{_scale_label(config.s_cold)}"
    run_tag = f"K{config.k_ais}_T{config.t_ais}_Freq{config.freq_ais}"
    return repo_root / "data/alanine_dipeptide/ais_linear_scaling" / f"{solvent_tag}_{scale_tag}" / run_tag


def _scale_label(scale: float) -> str:
    return f"{float(scale):g}".replace(".", "p")


def _box_lengths_angles_from_vectors(box_nm: Optional[np.ndarray]) -> tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    if box_nm is None:
        return None, None

    a, b, c = [np.asarray(vec, dtype=float) for vec in box_nm]
    lengths = np.array([
        np.linalg.norm(a),
        np.linalg.norm(b),
        np.linalg.norm(c),
    ], dtype=float)

    def _angle(u: np.ndarray, v: np.ndarray) -> float:
        denom = np.linalg.norm(u) * np.linalg.norm(v)
        if denom == 0.0:
            return 90.0
        cosine = np.clip(np.dot(u, v) / denom, -1.0, 1.0)
        return float(np.degrees(np.arccos(cosine)))

    angles = np.array([
        _angle(b, c),
        _angle(a, c),
        _angle(a, b),
    ], dtype=float)
    return lengths, angles


def _set_positions_and_box(simulation, positions_nm: np.ndarray, box_nm: Optional[np.ndarray], unit_module, vec3_cls) -> None:
    simulation.context.setPositions(positions_nm * unit_module.nanometer)
    if box_nm is not None:
        simulation.context.setPeriodicBoxVectors(
            vec3_cls(*box_nm[0]) * unit_module.nanometer,
            vec3_cls(*box_nm[1]) * unit_module.nanometer,
            vec3_cls(*box_nm[2]) * unit_module.nanometer,
        )


def _build_simulation(topology, system, temperature_k: float, platform_name: str, timestep_fs: float,
                      friction_per_ps: float, device_index: Optional[str], openmm_module, app_module,
                      random_seed: Optional[int] = None):
    integrator = openmm_module.LangevinMiddleIntegrator(
        temperature_k * openmm_module.unit.kelvin,
        friction_per_ps / openmm_module.unit.picosecond,
        (timestep_fs / 1000.0) * openmm_module.unit.picoseconds,
    )
    if random_seed is not None:                                      # thermostat noise; must precede the Context
        integrator.setRandomNumberSeed(int(random_seed))
    platform = openmm_module.Platform.getPlatformByName(platform_name)
    properties: dict[str, str] = {}
    if platform_name in {"CUDA", "OpenCL"}:
        properties["Precision"] = "mixed"
        if device_index is not None:
            # property name is platform-specific: CUDA uses DeviceIndex, OpenCL uses OpenCLDeviceIndex
            key = "DeviceIndex" if platform_name == "CUDA" else "OpenCLDeviceIndex"
            properties[key] = str(device_index)
    return app_module.Simulation(topology, system, integrator, platform, properties)




def _count_dcd_frames(md_module, trajectory_path: Path, topology_path: Path) -> int:
    n_frames = 0
    for chunk in md_module.iterload(str(trajectory_path), top=str(topology_path), chunk=1000):
        n_frames += int(chunk.n_frames)
    return n_frames


def _load_frame(md_module, trajectory_path: Path, topology_path: Path, frame_index: int):
    return md_module.load_frame(str(trajectory_path), int(frame_index), top=str(topology_path))


def _select_solute_atom_indices(topology, n_solute_atoms=None) -> np.ndarray:
    # Prefer the build_topology convention (solute = contiguous [0, n_solute_atoms)),
    # which works for any ligand/peptide; fall back to the alanine residue-name rule.
    if n_solute_atoms is not None:
        return np.arange(int(n_solute_atoms), dtype=np.int64)
    indices = [atom.index for atom in topology.atoms() if atom.residue.name.strip() in _SOLUTE_RESIDUES]
    return np.asarray(indices, dtype=np.int64)


@dataclass
class AISInputs:
    """Everything ``run_linear_scaling_ais`` (and the multi-worker chunked-NEQ launcher) needs to
    build the AIS Hamiltonian from a prepared hot-MD seed directory.

    Factored out of ``run_linear_scaling_ais`` verbatim so that BOTH entry points construct the
    base system through exactly the same branch.  This is load-bearing, not cosmetic: for GBn2,
    ``AmberPrmtopFile.createSystem`` and ``parmed.Structure.createSystem`` differ by ~16.6 kJ/mol
    at identical radii, which REST2 scaling turns into several kT of spurious work, so a second
    copy of this logic would be a silent Hamiltonian mismatch.
    """
    input_scaled_dir: Path
    input_cfg: dict
    source_traj_path: Path
    source_topology_path: Path
    prmtop: object
    base_system: object
    topology: object
    solute_indices: np.ndarray
    phi_indices: Optional[np.ndarray]
    psi_indices: Optional[np.ndarray]
    timestep_fs: float
    friction_per_ps: float
    solvent_model: str
    pressure_bar: Optional[float]


def load_ais_inputs(config: LinearAISConfig, input_scaled_dir: Optional[Path] = None) -> AISInputs:
    """Resolve the seed directory, force field and base OpenMM system for an AIS leg."""
    from openmm import app, unit

    from escort_ais.analysis.analysis import find_phi_psi_indices
    from escort_ais.common.paths import project_root

    input_scaled_dir = Path(input_scaled_dir or config.input_scaled_dir
                            or default_input_scaled_dir(project_root(), config.solvent))
    if not input_scaled_dir.exists():
        raise FileNotFoundError(f"Scaled input directory does not exist: {input_scaled_dir}")

    input_config_path = input_scaled_dir / "config.json"
    input_cfg = json.loads(input_config_path.read_text()) if input_config_path.exists() else {}
    source_traj_path = input_scaled_dir / "trajectory.dcd"
    source_topology_path = input_scaled_dir / "start_structure.pdb"
    if not source_traj_path.exists() or not source_topology_path.exists():
        raise FileNotFoundError(
            f"Expected trajectory/topology at {source_traj_path} and {source_topology_path}."
        )

    if config.solvent == "implicit":
        # Support two config layouts:
        # (a) old etkdg runs:  input_cfg["openmm_dir"] → dir containing ace_ala_nme.prmtop
        # (b) new md runs:     input_cfg["prmtop_path"] / input_cfg["inpcrd_path"] directly
        if "openmm_dir" in input_cfg:
            prmtop_dir = Path(input_cfg["openmm_dir"])
            prmtop_path = prmtop_dir / "ace_ala_nme.prmtop"
            inpcrd_path = prmtop_dir / "ace_ala_nme.inpcrd"
        elif "prmtop_path" in input_cfg:
            prmtop_path = Path(input_cfg["prmtop_path"])
            inpcrd_path = Path(input_cfg["inpcrd_path"])
        else:
            raise KeyError(
                f"Cannot resolve prmtop path from {input_config_path}: "
                "expected 'openmm_dir' or 'prmtop_path' key."
            )
        gb_model = input_cfg.get("gb_model", input_cfg.get("topology_solvent", "GBn2"))
        # Normalise topology_solvent value (e.g. "gbn2" → "GBn2")
        _gb_map = {"gbn2": "GBn2", "gbn": "GBn", "obc2": "OBC2", "obc1": "OBC1", "hct": "HCT"}
        gb_model = _gb_map.get(gb_model.lower(), gb_model)
        prmtop = app.AmberPrmtopFile(str(prmtop_path))
        app.AmberInpcrdFile(str(inpcrd_path))
        # GBn2 + mbondi3 through parmed is ENFORCED (see systems.openmm_system.build_implicit_system):
        # the parmed and AmberPrmtopFile GB branches differ by ~16 kJ/mol at identical radii, which
        # REST2 turns into several kT of spurious work. A seed config may set
        # "gb_radii": "amber-builtin" to reproduce a pre-2026-07-31 run; omitting the key now gives
        # mbondi3 rather than the AmberPrmtopFile branch it used to select.
        from escort_ais.systems.openmm_system import DEFAULT_GB_RADII, build_implicit_system
        gb_radii = input_cfg.get("gb_radii") or DEFAULT_GB_RADII
        base_system = build_implicit_system(prmtop_path, gb_model=gb_model, gb_radii=gb_radii,
                                            inpcrd_path=inpcrd_path)
        solvent_model = f"implicit_{gb_model.lower()}"
        pressure_bar = None
    else:
        explicit_openmm_dir = Path(input_cfg["explicit_openmm_dir"])
        prmtop_path = explicit_openmm_dir / "ace_ala_nme_explicit.prmtop"
        inpcrd_path = explicit_openmm_dir / "ace_ala_nme_explicit.inpcrd"
        water_model = input_cfg.get("water_model", "OPC")
        prmtop = app.AmberPrmtopFile(str(prmtop_path))
        app.AmberInpcrdFile(str(inpcrd_path))
        base_system = prmtop.createSystem(
            nonbondedMethod=app.PME,
            nonbondedCutoff=1.0 * unit.nanometer,
            constraints=app.HBonds,
            rigidWater=True,
        )
        base_system.addForce(app.MonteCarloBarostat(input_cfg.get("pressure_bar", 1.0) * unit.bar, config.temperature_k * unit.kelvin, 50))
        solvent_model = f"explicit_{water_model.lower()}"
        pressure_bar = input_cfg.get("pressure_bar", 1.0)

    topology = prmtop.topology
    solute_indices = _select_solute_atom_indices(topology, input_cfg.get("n_solute_atoms"))
    try:
        phi_indices, psi_indices = find_phi_psi_indices(topology)
    except Exception:
        phi_indices, psi_indices = None, None    # non-alanine (e.g. cyclosporin): skip phi/psi diagnostics
    return AISInputs(
        input_scaled_dir=input_scaled_dir, input_cfg=input_cfg,
        source_traj_path=source_traj_path, source_topology_path=source_topology_path,
        prmtop=prmtop, base_system=base_system, topology=topology,
        solute_indices=solute_indices, phi_indices=phi_indices, psi_indices=psi_indices,
        timestep_fs=float(input_cfg.get("timestep_fs", 2.0)),
        friction_per_ps=float(input_cfg.get("friction_per_ps", 1.0)),
        solvent_model=solvent_model, pressure_bar=pressure_bar)


@dataclass
class SingleAISTrajectoryResult:
    """Everything one AIS trajectory produces (Part 7).

    The helper returns data and writes nothing, so the serial driver and a spawned worker share the
    *same* scientific code path and differ only in who owns the DCD handles. ``work_rows`` carry
    ``coordinate_frame_index=-1``; the writer assigns the running index, which keeps the serial
    numbering (trajectory-major, interval-minor) identical under merge.
    """
    trajectory_index: int
    frame_index: int
    final_w: float
    final_logw: float
    final_positions_nm: np.ndarray
    final_box_nm: Optional[np.ndarray]
    final_phi: float
    final_psi: float
    work_rows: list[dict]
    work_coordinates: list[tuple[np.ndarray, Optional[np.ndarray]]]
    timings: dict[str, float]


def run_single_ais_trajectory(*, trajectory_index: int, frame_index: int, config: LinearAISConfig,
                              simulation, scaler, neq_integ, scales: np.ndarray, m_ais: int,
                              beta: float, solvent_model: str, phi_indices, psi_indices,
                              n_tail_intervals: Optional[int], coswitch: bool, cold_at_end: bool,
                              md, unit, Vec3, source_traj_path: Path, source_topology_path: Path,
                              dihedral_deg) -> SingleAISTrajectoryResult:
    """Propagate ONE AIS trajectory on an already-built context; return its work, coordinates, timings.

    Scientific conventions are unchanged and must stay that way:
      * manual path  ``dW_m = U(x_m; s_{m+1}) - U(x_m; s_m)`` and ``dlogw_m = -beta*dW_m``, with the
        work increment assigned to the PRE-propagation coordinate x_m;
      * NEQ path     ``cumulative_logw = -protocol_work(dimensionless)``;
      * velocities seeded from ``config.seed + trajectory_index`` — the GLOBAL index, so a
        trajectory keeps its seed at any worker count.
    """
    timer = PhaseTimer()
    ctx = simulation.context

    with timer.phase("frame_load_s"):
        frame = _load_frame(md, source_traj_path, source_topology_path, int(frame_index))
        positions_nm = np.asarray(frame.xyz[0], dtype=float)
        box_nm = None
        if frame.unitcell_vectors is not None and len(frame.unitcell_vectors):
            box_nm = np.asarray(frame.unitcell_vectors[0], dtype=float)

    with timer.phase("state_setup_s"):
        scaler.apply(float(scales[0]), ctx)
        if coswitch:                                                 # leg start (progress=0)
            ctx.setParameter("umbrella_lambda",
                             coswitch_lambda(0.0, cold_at_end, config.coswitch_ramp_exponent))
        _set_positions_and_box(simulation, positions_nm, box_nm, unit, Vec3)
        ctx.setVelocitiesToTemperature(config.temperature_k * unit.kelvin,
                                       config.seed + trajectory_index)

    cumulative_w = 0.0
    cumulative_logw = 0.0
    cumulative_w_temp = 0.0
    cumulative_w_bias = 0.0
    work_rows: list[dict] = []
    work_coordinates: list[tuple[np.ndarray, Optional[np.ndarray]]] = []
    timer.add("work_readback_s", 0.0)

    if config.neq_integrator:
        # ramp lambda 0->1 over M_ais windows ON THE GPU; protocol work accumulated on-device.
        with timer.phase("ais_execution_s"):
            neq_integ.reset()
            simulation.step(m_ais)
        # get_protocol_work() synchronises, so the readback is where the GPU queue actually drains;
        # keeping it OUT of ais_execution_s would attribute propagation time to the readback.
        with timer.phase("work_readback_s"):
            cumulative_logw = -float(neq_integ.get_protocol_work(dimensionless=True))  # logw = -beta*W
            cumulative_w = float(neq_integ.get_protocol_work().value_in_unit(unit.kilojoule_per_mole))

    for interval_index in range(0 if config.neq_integrator else m_ais):
        s_old = float(scales[interval_index])
        s_new = float(scales[interval_index + 1])

        with timer.phase("work_readback_s"):
            # Context is at s_old; read pre-propagation state
            state_old = ctx.getState(getPositions=True, getEnergy=True)
            x_m = state_old.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
            if box_nm is not None:
                box_vectors = state_old.getPeriodicBoxVectors()
                box_nm = np.array([[vec.x, vec.y, vec.z] for vec in box_vectors], dtype=float)
            u_old = float(state_old.getPotentialEnergy().value_in_unit(unit.kilojoules_per_mole))

            ubias_old = (float(ctx.getState(getEnergy=True, groups={UMBRELLA_FORCE_GROUP})
                               .getPotentialEnergy().value_in_unit(unit.kilojoules_per_mole))
                         if (coswitch and config.decompose_coswitch_work) else 0.0)

            # Switch scale in place — positions/velocities unchanged (co-switch: ramp the umbrella too)
            scaler.apply(s_new, ctx)
            if coswitch:                                             # χ(λ_cold)=λ_cold^exponent
                ctx.setParameter("umbrella_lambda",
                                 coswitch_lambda((interval_index + 1) / m_ais, cold_at_end,
                                                 config.coswitch_ramp_exponent))
            u_new = float(ctx.getState(getEnergy=True).getPotentialEnergy()
                          .value_in_unit(unit.kilojoules_per_mole))

            delta_w = float(u_new - u_old)
            if coswitch and config.decompose_coswitch_work:          # split ΔW into tempering + biasing
                ubias_new = float(ctx.getState(getEnergy=True, groups={UMBRELLA_FORCE_GROUP})
                                  .getPotentialEnergy().value_in_unit(unit.kilojoules_per_mole))
                delta_w_bias = ubias_new - ubias_old
                delta_w_temp = delta_w - delta_w_bias
            else:
                delta_w_bias = float("nan"); delta_w_temp = float("nan")

        delta_u = float(beta * delta_w)
        delta_logw = float(-delta_u)
        cumulative_w += delta_w
        cumulative_logw += delta_logw
        if coswitch and config.decompose_coswitch_work:
            cumulative_w_temp += delta_w_temp
            cumulative_w_bias += delta_w_bias
        phi = dihedral_deg(x_m, phi_indices) if phi_indices is not None else float("nan")
        psi = dihedral_deg(x_m, psi_indices) if psi_indices is not None else float("nan")

        if n_tail_intervals is not None:
            is_saved = interval_index >= m_ais - n_tail_intervals
        else:
            is_saved = (config.save_traj_every_switch
                        and interval_index % max(int(config.save_switch_stride), 1) == 0)

        if is_saved:
            with timer.phase("work_readback_s"):
                s_cold_f = float(config.s_cold)
                if abs(s_old - s_cold_f) < 1e-12:
                    u_target: float = u_old
                elif abs(s_new - s_cold_f) < 1e-12:
                    u_target = u_new
                else:
                    scaler.apply(s_cold_f, ctx)
                    u_target = float(ctx.getState(getEnergy=True).getPotentialEnergy()
                                     .value_in_unit(unit.kilojoules_per_mole))
                    scaler.apply(s_new, ctx)                         # restore for propagation
        else:
            u_target = float("nan")

        work_rows.append({
            "global_sample_index": -1,                               # assigned by the writer
            "ais_trajectory_index": trajectory_index,
            "ais_interval_index": interval_index,
            "initial_frame_index": int(frame_index),
            "solvent_model": solvent_model,
            "s_old": s_old,
            "s_new": s_new,
            "lambda_old": compute_lambda_from_scale(s_old, config.s_hot, config.s_cold),
            "lambda_new": compute_lambda_from_scale(s_new, config.s_hot, config.s_cold),
            "U_old": u_old,
            "U_new": u_new,
            "delta_W": delta_w,
            "delta_W_temp": delta_w_temp,
            "delta_W_bias": delta_w_bias,
            "delta_u": delta_u,
            "delta_logw": delta_logw,
            "cumulative_W": cumulative_w,
            "cumulative_W_temp": cumulative_w_temp,
            "cumulative_W_bias": cumulative_w_bias,
            "cumulative_logw": cumulative_logw,
            "md_step_start": interval_index * config.freq_ais,
            "md_step_end": (interval_index + 1) * config.freq_ais,
            "coordinate_file": "ais_work_coordinates.dcd",
            "coordinate_frame_index": -1,                            # assigned by the writer
            "saved": is_saved,
            "U_target": u_target,
            "phi": phi,
            "psi": psi,
        })
        if is_saved:
            work_coordinates.append((np.array(x_m, dtype=float),
                                     None if box_nm is None else np.array(box_nm, dtype=float)))

        # Propagate under s_new; context already at s_new with positions x_m
        with timer.phase("ais_execution_s"):
            simulation.step(config.freq_ais)

    with timer.phase("final_state_readback_s"):
        final_state = ctx.getState(getPositions=True)
        final_positions_nm = final_state.getPositions(asNumpy=True).value_in_unit(unit.nanometer)
        final_box_nm = box_nm
        if box_nm is not None:
            final_box_vectors = final_state.getPeriodicBoxVectors()
            final_box_nm = np.array([[vec.x, vec.y, vec.z] for vec in final_box_vectors], dtype=float)
        final_phi = dihedral_deg(final_positions_nm, phi_indices) if phi_indices is not None else float("nan")
        final_psi = dihedral_deg(final_positions_nm, psi_indices) if psi_indices is not None else float("nan")

    timings = dict(timer.totals)
    timings.setdefault("ais_execution_s", 0.0)
    timings.setdefault("final_state_readback_s", 0.0)
    timings["total_trajectory_s"] = timer.elapsed
    return SingleAISTrajectoryResult(
        trajectory_index=int(trajectory_index), frame_index=int(frame_index),
        final_w=float(cumulative_w), final_logw=float(cumulative_logw),
        final_positions_nm=np.asarray(final_positions_nm, dtype=float),
        final_box_nm=final_box_nm, final_phi=float(final_phi), final_psi=float(final_psi),
        work_rows=work_rows, work_coordinates=work_coordinates, timings=timings)


def partition_trajectories(k_ais: int, n_workers: int) -> list[list[int]]:
    """Deterministic round-robin partition of the GLOBAL trajectory indices over workers (Part 6).

    Round-robin rather than contiguous blocks so that a partial failure or a slow device does not
    correlate with a contiguous stretch of the frame list. The partition depends only on
    (k_ais, n_workers) — never on timing — so re-running reproduces the same assignment.
    """
    if k_ais <= 0 or n_workers <= 0:
        raise ValueError("k_ais and n_workers must be positive.")
    return [list(range(w, int(k_ais), int(n_workers))) for w in range(int(n_workers))]


def worker_integrator_seed(base_seed: int, first_trajectory_index: int) -> int:
    """Distinct, deterministic Langevin seed per worker, keyed to its FIRST global trajectory.

    OpenMM applies ``setRandomNumberSeed`` only before Context construction, so the thermostat
    stream cannot be rewound per trajectory: a worker's stream is fixed when its Context is built.
    Seeding every worker with ``config.seed`` would therefore give worker 0 and worker 1 the SAME
    O-step noise sequence, correlating trajectories that the estimator assumes are independent.
    Keying on the worker's first global trajectory index keeps the seed deterministic (the same
    partition always yields the same seeds) while making the streams distinct, and reduces to
    ``base_seed`` for the serial path, whose first trajectory is 0.
    """
    return int((int(base_seed) + 1_000_003 * int(first_trajectory_index)) % (2 ** 31 - 1))


def worker_device_for(worker_index: int, devices: Optional[list[str]],
                      fallback: Optional[str]) -> Optional[str]:
    """Deterministic worker→device mapping: worker w gets ``devices[w % len(devices)]``."""
    if not devices:
        return fallback
    return str(devices[int(worker_index) % len(devices)])


def _ais_worker_entry(payload: dict) -> dict:
    """Run one worker's share of the trajectories in a SPAWNED process (Part 6).

    Module-level and self-contained so it is picklable by the spawn context. Each worker builds its
    own System, Context and integrator: an OpenMM Context must never be shared or inherited across
    processes, which is also why "fork" is not an option here.
    """
    import pickle

    config: LinearAISConfig = payload["config"]
    assignments: list[tuple[int, int]] = payload["assignments"]
    integrator_seed = int(payload["integrator_seed"])
    out_path = Path(payload["out_path"])

    import mdtraj as md
    from openmm import Vec3, app, unit
    import openmm

    from escort_ais.analysis.analysis import dihedral_deg
    from escort_ais.systems.openmm_system import (BOLTZMANN_KJ_PER_MOL_K, Rest2ContextScaler,
                                                  Rest2LambdaScaler, build_rest2_lambda_system)

    m_ais, _ = validate_ais_lengths(config.k_ais, config.t_ais, config.freq_ais)
    scales = make_linear_scaling_schedule(config.s_hot, config.s_cold, m_ais, mode=config.scaling_mode)
    inputs = load_ais_inputs(config, Path(payload["input_scaled_dir"]))
    beta = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * config.temperature_k)
    n_tail = resolve_tail_intervals(config.save_tail_ps, m_ais, config.freq_ais, inputs.timestep_fs)

    gpu_switching_active = False
    scaler = None
    sim_system = inputs.base_system
    if config.gpu_switching:
        try:
            sim_system = build_rest2_lambda_system(
                inputs.base_system, inputs.solute_indices,
                exclude_central_bonds=config.omega_exclude_bonds)
            scaler = Rest2LambdaScaler(sim_system)
            gpu_switching_active = True
        except RuntimeError:
            scaler, sim_system, gpu_switching_active = None, inputs.base_system, False
    if scaler is None:
        scaler = Rest2ContextScaler(inputs.base_system, inputs.solute_indices,
                                    exclude_central_bonds=config.omega_exclude_bonds)
    if config.neq_integrator and not gpu_switching_active:
        raise RuntimeError(
            "neq_integrator=True requires GPU/global-parameter REST2 switching through "
            "Rest2LambdaScaler; this worker fell back to Rest2ContextScaler.")

    wall_cos = config.wall_quartets is not None and config.wall_cell is not None
    if wall_cos and config.umbrella_quartets is not None:
        raise ValueError("umbrella co-switch and wall co-switch both requested; they drive the "
                         "same `umbrella_lambda` ramp and would silently superpose two restraints")
    coswitch = config.umbrella_quartets is not None or wall_cos
    cold_at_end = float(config.s_cold) >= float(config.s_hot)
    if config.umbrella_quartets is not None:
        sim_system.addForce(build_coswitch_umbrella_force(
            config.umbrella_quartets, config.umbrella_mu, config.umbrella_kappa,
            config.umbrella_kT_kj, openmm=openmm))
    if wall_cos:
        from escort_ais.methods.wall_stratified import build_coswitch_wall_force
        sim_system.addForce(build_coswitch_wall_force(
            config.wall_quartets, config.wall_cell, config.wall_kT_kj,
            config.wall_k_hot, config.wall_k_cold, openmm=openmm))

    if config.neq_integrator:
        neq_integ = build_neq_integrator(config, m_ais, inputs.timestep_fs, inputs.friction_per_ps,
                                         getattr(scaler, "_params", set()), openmm,
                                         random_seed=integrator_seed)
        plat = openmm.Platform.getPlatformByName(config.platform)
        props = {}
        if config.platform in ("CUDA", "OpenCL"):
            props["Precision"] = "mixed"
            if config.device_index is not None:
                props["DeviceIndex" if config.platform == "CUDA" else "OpenCLDeviceIndex"] = \
                    str(config.device_index)
        simulation = app.Simulation(inputs.topology, sim_system, neq_integ, plat, props)
    else:
        neq_integ = None
        simulation = _build_simulation(
            inputs.topology, sim_system, config.temperature_k, config.platform,
            inputs.timestep_fs, inputs.friction_per_ps, config.device_index, openmm, app,
            random_seed=integrator_seed)

    results = []
    for traj_idx, frame_idx in assignments:
        results.append(run_single_ais_trajectory(
            trajectory_index=int(traj_idx), frame_index=int(frame_idx), config=config,
            simulation=simulation, scaler=scaler, neq_integ=neq_integ, scales=scales,
            m_ais=m_ais, beta=beta, solvent_model=inputs.solvent_model,
            phi_indices=inputs.phi_indices, psi_indices=inputs.psi_indices,
            n_tail_intervals=n_tail, coswitch=coswitch, cold_at_end=cold_at_end,
            md=md, unit=unit, Vec3=Vec3, source_traj_path=inputs.source_traj_path,
            source_topology_path=inputs.source_topology_path, dihedral_deg=dihedral_deg))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("wb") as handle:
        pickle.dump(results, handle, protocol=pickle.HIGHEST_PROTOCOL)
    return {"worker": int(payload["worker_index"]), "n": len(results), "out_path": str(out_path),
            "gpu_switching_active": gpu_switching_active}


def _run_workers(config: LinearAISConfig, selected_frame_indices, input_scaled_dir: Path,
                 tmp_dir: Path, logger) -> list[SingleAISTrajectoryResult]:
    """Spawn the workers, collect their results, and return them in trajectory order (Part 6).

    A worker failure aborts the whole job: a silently dropped trajectory would bias the estimator
    by removing exactly the trajectories most likely to be numerically awkward.
    """
    import multiprocessing as mp
    import pickle
    from dataclasses import replace

    n_workers = int(config.n_workers)
    parts = partition_trajectories(int(config.k_ais), n_workers)
    devices = config.worker_device_indices
    if devices and config.platform == "CUDA" and n_workers > len(devices):
        logger.warning("%d workers over %d CUDA device(s): %d worker(s) share a GPU. Measured on "
                       "this project, two processes per A5000 run ~4.7x slower EACH without MPS.",
                       n_workers, len(devices), n_workers - len(devices))

    payloads = []
    for w, traj_indices in enumerate(parts):
        assignments = [(int(t), int(selected_frame_indices[t])) for t in traj_indices]
        device = worker_device_for(w, devices, config.device_index)
        payloads.append({
            "worker_index": w,
            "config": replace(config, device_index=device, n_workers=1),
            "assignments": assignments,
            "integrator_seed": worker_integrator_seed(config.seed,
                                                      traj_indices[0] if traj_indices else 0),
            "input_scaled_dir": str(input_scaled_dir),
            "out_path": str(tmp_dir / f"worker_{w:02d}.pkl"),
        })
        logger.info("worker %d: %d trajectories, device=%s", w, len(assignments), device)

    ctx = mp.get_context("spawn")        # a forked CUDA/OpenMM context is invalid; spawn is required
    with ctx.Pool(processes=n_workers) as pool:
        try:
            reports = pool.map(_ais_worker_entry, payloads)
        except Exception as exc:                                     # noqa: BLE001 - re-raised below
            raise RuntimeError(
                f"AIS worker failed ({exc}); aborting rather than dropping trajectories."
            ) from exc

    results: list[SingleAISTrajectoryResult] = []
    for report in reports:
        with Path(report["out_path"]).open("rb") as handle:
            results.extend(pickle.load(handle))
    results.sort(key=lambda r: r.trajectory_index)
    got = [r.trajectory_index for r in results]
    if got != list(range(int(config.k_ais))):
        raise RuntimeError(
            f"worker outputs do not cover every trajectory exactly once: got {len(got)} results "
            f"for K_ais={config.k_ais}.")
    return results


def _write_trajectory_result(result: SingleAISTrajectoryResult, *, work_dcd, final_dcd,
                             work_rows: list, final_rows: list, per_trajectory_timings: list,
                             config: LinearAISConfig, m_ais: int, solvent_model: str,
                             work_frame_count: int, global_sample_index: int,
                             final_frame_count: int, timer: "PhaseTimer") -> tuple[int, int, int]:
    """Assign the global indices and write one trajectory's outputs (shared by serial and merge).

    Index assignment lives HERE and nowhere else, so a merged parallel run reproduces the serial
    numbering exactly: results are consumed in ``ais_trajectory_index`` order, and within a
    trajectory in interval order, which is the order the serial loop used.
    """
    with timer.phase("output_write_s"):
        coord_iter = iter(result.work_coordinates)
        for row in result.work_rows:
            row["global_sample_index"] = global_sample_index
            global_sample_index += 1
            if row["saved"]:
                x_m, box_nm = next(coord_iter)
                row["coordinate_frame_index"] = work_frame_count
                lengths_nm, angles_deg = _box_lengths_angles_from_vectors(box_nm)
                work_dcd.write(
                    x_m[np.newaxis, :, :],
                    cell_lengths=None if lengths_nm is None else lengths_nm[np.newaxis, :],
                    cell_angles=None if angles_deg is None else angles_deg[np.newaxis, :],
                )
                work_frame_count += 1
            work_rows.append(row)

        final_rows.append({
            "ais_trajectory_index": result.trajectory_index,
            "initial_frame_index": int(result.frame_index),
            "solvent_model": solvent_model,
            "K_ais": config.k_ais,
            "T_ais": config.t_ais,
            "Freq_ais": config.freq_ais,
            "M_ais": m_ais,
            "s_hot": config.s_hot,
            "s_cold": config.s_cold,
            "final_W": result.final_w,
            "final_logw": result.final_logw,
            "final_phi": result.final_phi,
            "final_psi": result.final_psi,
            "final_coordinate_file": "ais_final_coordinates.dcd",
            "final_coordinate_frame_index": result.trajectory_index,
            # per-trajectory timing columns (Part 4)
            "frame_load_s": result.timings.get("frame_load_s", float("nan")),
            "state_setup_s": result.timings.get("state_setup_s", float("nan")),
            "ais_execution_s": result.timings.get("ais_execution_s", float("nan")),
            "work_readback_s": result.timings.get("work_readback_s", float("nan")),
            "final_state_readback_s": result.timings.get("final_state_readback_s", float("nan")),
            "output_write_s": result.timings.get("output_write_s", float("nan")),
            "total_trajectory_s": result.timings.get("total_trajectory_s", float("nan")),
        })
        final_lengths_nm, final_angles_deg = _box_lengths_angles_from_vectors(result.final_box_nm)
        final_dcd.write(
            result.final_positions_nm[np.newaxis, :, :],
            cell_lengths=None if final_lengths_nm is None else final_lengths_nm[np.newaxis, :],
            cell_angles=None if final_angles_deg is None else final_angles_deg[np.newaxis, :],
        )
        final_frame_count += 1

    for key, value in result.timings.items():
        if key != "total_trajectory_s":
            timer.add(key, float(value))
    per_trajectory_timings.append(dict(result.timings))
    return work_frame_count, global_sample_index, final_frame_count


def run_linear_scaling_ais(config: LinearAISConfig) -> dict[str, float | int | str]:
    import mdtraj as md
    from openmm import Vec3, app, unit
    import openmm

    from escort_ais.analysis.analysis import dihedral_deg, find_phi_psi_indices
    from escort_ais.systems.openmm_system import (BOLTZMANN_KJ_PER_MOL_K, Rest2ContextScaler,
                                           Rest2LambdaScaler, build_rest2_lambda_system)

    timer = PhaseTimer()                                             # total runtime starts here
    validate_ais_config(config)                                      # cheap gate, before any build
    m_ais, n_ais = validate_ais_lengths(config.k_ais, config.t_ais, config.freq_ais)
    scales = make_linear_scaling_schedule(config.s_hot, config.s_cold, m_ais, mode=config.scaling_mode)
    from escort_ais.common.paths import project_root
    repo_root = project_root()
    input_scaled_dir = Path(config.input_scaled_dir or default_input_scaled_dir(repo_root, config.solvent))
    output_dir = default_output_dir(repo_root, config)

    if config.dry_run:
        return {
            "input_scaled_dir": str(input_scaled_dir),
            "output_dir": str(output_dir),
            "M_ais": m_ais,
            "N_ais": n_ais,
        }

    if output_dir.exists():
        if not config.overwrite:
            raise FileExistsError(f"Output directory already exists: {output_dir}")
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger(f"ais_linear.{output_dir.name}")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    log_path = output_dir / "run.log"
    file_handler = logging.FileHandler(log_path, mode="w", encoding="utf-8")
    console_handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s", datefmt="%Y-%m-%dT%H:%M:%S")
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)
    console_handler.setLevel(logging.INFO)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    with timer.phase("input_load_s"):
        inputs = load_ais_inputs(config, input_scaled_dir)
    input_cfg = inputs.input_cfg
    source_traj_path, source_topology_path = inputs.source_traj_path, inputs.source_topology_path
    prmtop, base_system = inputs.prmtop, inputs.base_system
    solvent_model, pressure_bar = inputs.solvent_model, inputs.pressure_bar
    topology, solute_indices = inputs.topology, inputs.solute_indices
    phi_indices, psi_indices = inputs.phi_indices, inputs.psi_indices
    timestep_fs, friction_per_ps = inputs.timestep_fs, inputs.friction_per_ps
    beta = 1.0 / (BOLTZMANN_KJ_PER_MOL_K * config.temperature_k)
    n_tail_intervals = resolve_tail_intervals(config.save_tail_ps, m_ais, config.freq_ais, timestep_fs)

    logger.info("=== AIS linear scaling factor ===")
    logger.info("solvent=%s input_scaled_dir=%s", config.solvent, input_scaled_dir)
    logger.info(
        "K_ais=%d T_ais=%d Freq_ais=%d M_ais=%d N_ais=%d",
        config.k_ais, config.t_ais, config.freq_ais, m_ais, n_ais,
    )
    logger.info("s_hot=%.6f s_cold=%.6f platform=%s", config.s_hot, config.s_cold, config.platform)
    if n_tail_intervals is not None:
        logger.info("save_tail_ps=%.4f → %d tail intervals saved (of %d)", config.save_tail_ps, n_tail_intervals, m_ais)
    else:
        logger.info("save_traj_every_switch=%s", config.save_traj_every_switch)


    with timer.phase("source_frame_count_s"):
        n_source_frames = _count_dcd_frames(md, source_traj_path, source_topology_path)
    candidates = candidate_initial_frame_indices(
        n_source_frames,
        stride=config.start_frame_stride,
        offset=config.start_frame_offset,
    )
    selected_frame_indices, sampled_with_replacement = sample_initial_frame_indices_from_candidates(
        candidates,
        config.k_ais,
        config.seed,
    )

    with (output_dir / "selected_initial_frames.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "ais_trajectory_index",
                "initial_frame_index",
                "source_trajectory_file",
                "source_topology_file",
            ],
        )
        writer.writeheader()
        for traj_idx, frame_idx in enumerate(selected_frame_indices):
            writer.writerow({
                "ais_trajectory_index": traj_idx,
                "initial_frame_index": int(frame_idx),
                "source_trajectory_file": str(source_traj_path),
                "source_topology_file": str(source_topology_path),
            })

    with (output_dir / "ais_schedule.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["ais_interval_index", "s_old", "s_new", "lambda_old", "lambda_new", "md_step_start", "md_step_end"],
        )
        writer.writeheader()
        for interval_index in range(m_ais):
            s_old = float(scales[interval_index])
            s_new = float(scales[interval_index + 1])
            writer.writerow({
                "ais_interval_index": interval_index,
                "s_old": s_old,
                "s_new": s_new,
                "lambda_old": compute_lambda_from_scale(s_old, config.s_hot, config.s_cold),
                "lambda_new": compute_lambda_from_scale(s_new, config.s_hot, config.s_cold),
                "md_step_start": interval_index * config.freq_ais,
                "md_step_end": (interval_index + 1) * config.freq_ais,
            })

    # Single shared context. Two per-window scaling paths:
    #  - gpu_switching (default): a lambda-driven system whose scaling is set via GPU-side global
    #    parameters (no updateParametersInContext) — Rest2LambdaScaler.apply() is setParameter-only.
    #  - reload fallback: Rest2ContextScaler recomputes per-particle params + updateParametersInContext.
    # gpu_switching_active is an EXPLICIT flag rather than an isinstance() probe of the scaler: the
    # fallback below is silent by design (CMAP/non-all-solute systems legitimately take it), and the
    # NEQ integrator is only valid on the global-parameter path. Set True only when BOTH
    # build_rest2_lambda_system() and Rest2LambdaScaler() succeed.
    gpu_switching_active = False
    scaler = None
    sim_system = base_system
    _t_rest2 = timer._perf()
    if config.gpu_switching:
        try:
            sim_system = build_rest2_lambda_system(
                base_system, solute_indices, exclude_central_bonds=config.omega_exclude_bonds)
            scaler = Rest2LambdaScaler(sim_system)
            gpu_switching_active = True
            logger.info("GPU-side REST2 switching (global-parameter scaler) enabled.")
        except RuntimeError as exc:
            logger.info("GPU-side switching unavailable (%s); using reload scaler.", exc)
            scaler = None
            gpu_switching_active = False
            sim_system = base_system
    if scaler is None:
        scaler = Rest2ContextScaler(base_system, solute_indices,
                                    exclude_central_bonds=config.omega_exclude_bonds)  # mutates base_system GB expr

    timer.add("rest2_system_build_s", timer._perf() - _t_rest2)

    if config.neq_integrator and not gpu_switching_active:
        # Reachable even though validate_ais_config() has already accepted the request: gpu_switching
        # was asked for and *failed at build time*. Failing here is mandatory — the reload scaler
        # mutates per-particle parameters through updateParametersInContext, which the on-device
        # integrator neither sees nor can accumulate work for.
        raise RuntimeError(
            "neq_integrator=True requires GPU/global-parameter REST2 switching through "
            "Rest2LambdaScaler. The system fell back to Rest2ContextScaler, which is not "
            "compatible with the on-device nonequilibrium integrator."
        )
    wall_cos = config.wall_quartets is not None and config.wall_cell is not None
    coswitch = config.umbrella_quartets is not None or wall_cos
    cold_at_end = float(config.s_cold) >= float(config.s_hot)        # forward hot→cold: cold (s=1) at the leg end
    if config.umbrella_quartets is not None:                          # λ-ramped von-Mises umbrella
        sim_system.addForce(build_coswitch_umbrella_force(
            config.umbrella_quartets, config.umbrella_mu, config.umbrella_kappa, config.umbrella_kT_kj,
            openmm=openmm))
        logger.info("CO-SWITCH: umbrella U_bias=χ(λ_cold)·U_m, χ=λ_cold^%.3g (%s) ramped alongside the REST2 scale "
                    "(endpoint C_m = cold+full umbrella).", config.coswitch_ramp_exponent,
                    "linear" if abs(config.coswitch_ramp_exponent - 1.0) < 1e-9 else "convex")
    if wall_cos:                                                     # λ-ramped FLAT-BOTTOM wall
        from escort_ais.methods.wall_stratified import build_coswitch_wall_force
        sim_system.addForce(build_coswitch_wall_force(
            config.wall_quartets, config.wall_cell, config.wall_kT_kj,
            config.wall_k_hot, config.wall_k_cold, openmm=openmm))
        logger.info("CO-SWITCH: flat-bottom wall k(λ)=%.4g+(%.4g)·sqrt(λ_cold) kT/rad^2 ramped alongside "
                    "the REST2 scale; k(1) IS the production wall.",
                    config.wall_k_hot, config.wall_k_cold - config.wall_k_hot)
    _t_ctx = timer._perf()
    if config.neq_integrator:
        # on-device NEQ path: openmmtools accumulates protocol work on the GPU (one readback / trajectory).
        neq_integ = build_neq_integrator(config, m_ais, timestep_fs, friction_per_ps,
                                         getattr(scaler, "_params", set()), openmm,
                                         random_seed=config.seed)
        _plat = openmm.Platform.getPlatformByName(config.platform)
        _props = {}
        if config.platform in ("CUDA", "OpenCL"):
            # Match the manual path's _build_simulation: without this the NEQ branch inherited the
            # platform DEFAULT precision (single on CUDA) while the manual branch ran mixed — the
            # two work estimators in this one driver were not running at the same precision, and
            # single is ~25 % faster, which silently flattered the NEQ timings.
            _props["Precision"] = "mixed"
            if config.device_index is not None:
                _props["DeviceIndex" if config.platform == "CUDA" else "OpenCLDeviceIndex"] = \
                    str(config.device_index)
        simulation = app.Simulation(topology, sim_system, neq_integ, _plat, _props)
        logger.info("AIS work: openmmtools NEQ integrator on-device (M_ais=%d, Freq_ais=%d).", m_ais, config.freq_ais)
    else:
        neq_integ = None
        simulation = _build_simulation(
            topology, sim_system, config.temperature_k, config.platform,
            timestep_fs, friction_per_ps, config.device_index, openmm, app,
            random_seed=config.seed,
        )
    timer.add("context_construction_s", timer._perf() - _t_ctx)
    ctx = simulation.context
    execution_mode = describe_execution_mode(config, simulation, scaler, gpu_switching_active,
                                             m_ais, n_ais)
    logger.info("Execution mode:\n%s", format_execution_mode(execution_mode))

    work_rows: list[dict[str, object]] = []
    final_rows: list[dict[str, object]] = []
    per_trajectory_timings: list[dict[str, float]] = []
    work_frame_count = 0
    final_frame_count = 0
    global_sample_index = 0

    with md.formats.DCDTrajectoryFile(str(output_dir / "ais_work_coordinates.dcd"), mode="w", force_overwrite=True) as work_dcd, \
            md.formats.DCDTrajectoryFile(str(output_dir / "ais_final_coordinates.dcd"), mode="w", force_overwrite=True) as final_dcd:
        # Serial (n_workers=1) runs the trajectories inline on the shared context; parallel runs
        # them in spawned workers and merges. BOTH consume results in ais_trajectory_index order
        # through the same writer, so the outputs are index-for-index identical.
        if int(config.n_workers) > 1:
            with timer.phase("worker_execution_s"):
                _tmp = output_dir / "_workers"
                _tmp.mkdir(parents=True, exist_ok=True)
                results_iter = iter(_run_workers(config, selected_frame_indices,
                                                 input_scaled_dir, _tmp, logger))
        else:
            results_iter = None

        for traj_idx, frame_index in enumerate(selected_frame_indices):
            if results_iter is not None:
                result = next(results_iter)
                assert result.trajectory_index == traj_idx, "merged results out of order"
            else:
                result = run_single_ais_trajectory(
                    trajectory_index=int(traj_idx), frame_index=int(frame_index), config=config,
                    simulation=simulation, scaler=scaler, neq_integ=neq_integ, scales=scales,
                    m_ais=m_ais, beta=beta, solvent_model=solvent_model, phi_indices=phi_indices,
                    psi_indices=psi_indices, n_tail_intervals=n_tail_intervals, coswitch=coswitch,
                    cold_at_end=cold_at_end, md=md, unit=unit, Vec3=Vec3,
                    source_traj_path=source_traj_path, source_topology_path=source_topology_path,
                    dihedral_deg=dihedral_deg)
            work_frame_count, global_sample_index, final_frame_count = _write_trajectory_result(
                result, work_dcd=work_dcd, final_dcd=final_dcd, work_rows=work_rows,
                final_rows=final_rows, per_trajectory_timings=per_trajectory_timings,
                config=config, m_ais=m_ais, solvent_model=solvent_model,
                work_frame_count=work_frame_count, global_sample_index=global_sample_index,
                final_frame_count=final_frame_count, timer=timer)

    if int(config.n_workers) > 1:
        shutil.rmtree(output_dir / "_workers", ignore_errors=True)

    _t_csv = timer._perf()
    with (output_dir / "ais_work_samples.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(work_rows[0].keys()) if work_rows else [])
        if work_rows:
            writer.writeheader()
            writer.writerows(work_rows)

    with (output_dir / "ais_trajectory_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(final_rows[0].keys()) if final_rows else [])
        if final_rows:
            writer.writeheader()
            writer.writerows(final_rows)

    timer.add("csv_write_s", timer._perf() - _t_csv)

    metadata = {
        "method": "AIS linear scaling factor",
        "s_hot": config.s_hot,
        "s_cold": config.s_cold,
        "K_ais": config.k_ais,
        "T_ais": config.t_ais,
        "Freq_ais": config.freq_ais,
        "M_ais": m_ais,
        "N_ais": n_ais,
        "temperature": config.temperature_k,
        "beta_unit": "1/(kJ/mol)",
        "solvent": config.solvent,
        "solvent_model": solvent_model,
        "input_scaled_dir": str(input_scaled_dir),
        "output_dir": str(output_dir),
        "platform": config.platform,
        "seed": config.seed,
        "start_frame_stride": config.start_frame_stride,
        "start_frame_offset": config.start_frame_offset,
        "sampled_with_replacement": sampled_with_replacement,
        "source_trajectory_file": str(source_traj_path),
        "source_topology_file": str(source_topology_path),
        "work_convention": "delta_W = U_new(x_m) - U_old(x_m), assigned to pre-propagation coordinate x_m",
        "log_weight_convention": "delta_logw = -beta * delta_W",
        "save_traj_every_switch": config.save_traj_every_switch,
        "save_tail_ps": config.save_tail_ps,
        "n_tail_intervals": n_tail_intervals,
        "n_saved_frames": work_frame_count,
        "pressure_bar": pressure_bar,
        # Part 3: what the run ACTUALLY did, queried from the live Context.
        **execution_mode,
    }
    (output_dir / "ais_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    timing_summary = add_ns_per_day(
        summarize_timings(timer, per_trajectory_timings, m_ais=m_ais, freq_ais=config.freq_ais,
                          k_ais=config.k_ais,
                          setup_phases=("input_load_s", "source_frame_count_s",
                                        "rest2_system_build_s", "context_construction_s")),
        timestep_fs)
    timing_summary["execution_mode"] = execution_mode
    (output_dir / "ais_timing_summary.json").write_text(
        json.dumps(timing_summary, indent=2) + "\n", encoding="utf-8")
    logger.info("timing: total=%.2fs setup=%.2fs propagation=%.2fs traj/s(excl setup)=%.3f",
                timing_summary["total_runtime_s"], timing_summary["setup_s"],
                timing_summary["phase_totals_s"].get("ais_execution_s", float("nan")),
                timing_summary["trajectories_per_second_excluding_setup"])

    # the NEQ path accumulates work on-device and does NOT emit per-interval work_rows / saved frames.
    assert config.neq_integrator or len(work_rows) == n_ais
    _stride = max(int(config.save_switch_stride), 1)
    expected_saved = (
        n_tail_intervals * config.k_ais
        if n_tail_intervals is not None
        else (len(range(0, m_ais, _stride)) * config.k_ais if config.save_traj_every_switch else 0)
    )
    assert config.neq_integrator or work_frame_count == expected_saved, (
        f"Expected {expected_saved} saved frames, got {work_frame_count}"
    )
    assert len(final_rows) == config.k_ais
    assert final_frame_count == config.k_ais
    assert np.isclose(scales[0], config.s_hot)
    assert np.isclose(scales[-1], config.s_cold)

    final_logw = np.array([row["final_logw"] for row in final_rows], dtype=float)
    summary = summarize_final_log_weights(final_logw)
    summary.update({
        "output_dir": str(output_dir),
        "K_ais": config.k_ais,
        "M_ais": m_ais,
        "N_ais": n_ais,
    })
    logger.info(
        "final_logw mean=%.6f std=%.6f min=%.6f max=%.6f ESS=%.3f ESS/K=%.6f",
        summary["mean_final_logw"],
        summary["std_final_logw"],
        summary["min_final_logw"],
        summary["max_final_logw"],
        summary["ess"],
        summary["ess_over_k"],
    )
    return summary
