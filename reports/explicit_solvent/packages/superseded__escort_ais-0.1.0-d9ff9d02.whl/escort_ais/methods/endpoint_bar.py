"""endpoint_bar.py — Endpoint-restricted BAR for cold basin free energies (v6).

Estimator name: v6_endpoint_restricted_BAR  (aliases: "v6 endpoint-BAR",
"Endpoint-restricted BAR", "Partial-partition BAR").

Target, for each cold basin B:

    Delta G_B = F_B^cold - F^hot = -ln( Z_B^cold / Z^hot )

estimated by BAR between two states:
    state 0 = hot  (the unconfined hot ensemble; all forward AIS trajectories
                    start here)
    state 1 = cold restricted to basin B,  U_{c,B}(x) = U_c(x) if x in B else +inf.

Forward data : ordinary UNCONFINED hot->cold AIS works W_f, with cold endpoint
               basin b_end.  A forward trajectory contributes work
                   W_{f,B} = W_f         if b_end == B
                   W_{f,B} = +inf         otherwise
               The +inf (non-hit) samples are KEPT — they enter only through the
               finite-sample correction, contributing 0 to the BAR sums.
Reverse data : ordinary UNCONFINED cold->hot AIS works W_r for trajectories whose
               cold STARTING basin is B.

Crucial detail: the BAR sample-size ratio uses N_f_TOTAL (all forward
trajectories), not N_f_hits.  Then

    ddF_B = Delta G_B - Delta G_0   (B0 reported as exactly 0).

This is NOT intra-basin MSK (which targets F_B^cold - F_B^hot) and uses NO
hot-basin correction and NO hot starting-basin labels.

Work-sign convention matches the rest of the codebase: pass reduced works
W_f = -lnw_f (hot->cold) and W_r = -lnw_r (cold->hot).  BAR then returns
F_cold - F_hot.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
from scipy.optimize import brentq, minimize
from scipy.special import logsumexp


# ── core BAR pieces ─────────────────────────────────────────────────────────────

def _bar_residual(delta: float, W_f_hits: np.ndarray, W_r: np.ndarray,
                  n_f_total: int, n_r: int) -> float:
    """Bennett self-consistency residual (lhs - rhs), pymbar/ _bar_obj convention.

    Non-hit forward samples have W=+inf and contribute 0 to lhs, so only the
    finite hit works are summed — but the ratio uses n_f_total.
    Monotone increasing in delta; unique root when n_f_hits>0 and n_r>0.
    """
    inv_ratio = n_f_total / n_r      # n_f / n_r  on the forward (lhs) side
    ratio = n_r / n_f_total          # n_r / n_f  on the reverse (rhs) side
    # stable logistic: 1/(1 + c*exp(z)) = exp(-softplus(z + ln c))
    lhs = np.sum(_inv_one_plus_cexp(W_f_hits - delta, inv_ratio))
    rhs = np.sum(_inv_one_plus_cexp(W_r + delta, ratio))
    return float(lhs - rhs)


def _inv_one_plus_cexp(z: np.ndarray, c: float) -> np.ndarray:
    """Numerically stable 1 / (1 + c * exp(z)) = sigmoid(-(z + ln c))."""
    a = z + np.log(c)
    # sigmoid(-a) without overflow
    out = np.empty_like(a, dtype=float)
    pos = a > 0
    out[pos] = np.exp(-a[pos]) / (1.0 + np.exp(-a[pos]))
    out[~pos] = 1.0 / (1.0 + np.exp(a[~pos]))
    return out


def _ais_delta_g(W_f_hits: np.ndarray, n_f_total: int) -> float:
    """Forward AIS / Jarzynski estimate of Delta G_B = -ln[(1/N_f) sum_hits e^{-W_f}]."""
    if len(W_f_hits) == 0:
        return np.inf
    return float(-logsumexp(-W_f_hits) + np.log(n_f_total))


def solve_bar_with_infinite_works(W_f, W_r, n_f_total=None, n_r_total=None,
                                  initial_delta=None, max_iter=100, tol=1e-10):
    """Solve BAR for the reduced free-energy difference DeltaF = F_state1 - F_state0.

    W_f, W_r are reduced forward / reverse works and MAY contain ``np.inf``
    (endpoint-wall samples).  Infinite entries are retained in the sample counts
    but contribute zero to the finite exponential sums.  ``n_f_total`` /
    ``n_r_total`` default to ``len(W_f)`` / ``len(W_r)`` (i.e. the full pool,
    including the +inf samples) and are what enter the finite-sample correction.

    Returns (DeltaF, converged).  Same sign convention as the rest of the module
    (W_f = -lnw forward, W_r = -lnw reverse -> DeltaF = F_cold - F_hot).
    """
    W_f = np.asarray(W_f, float)
    W_r = np.asarray(W_r, float)
    if n_f_total is None:
        n_f_total = len(W_f)
    if n_r_total is None:
        n_r_total = len(W_r)
    Wf_hits = W_f[np.isfinite(W_f)]
    Wr_hits = W_r[np.isfinite(W_r)]
    if len(Wf_hits) == 0 or len(Wr_hits) == 0 or n_f_total == 0 or n_r_total == 0:
        return np.nan, False
    # initial guess: AIS/Jarzynski estimate (a good anchor for the monotone root)
    g0 = initial_delta if initial_delta is not None else _ais_delta_g(Wf_hits, n_f_total)
    if not np.isfinite(g0):
        g0 = 0.0
    # expand a bracket around g0 until the residual changes sign
    lo, hi = g0 - 5.0, g0 + 5.0
    f_lo = _bar_residual(lo, Wf_hits, Wr_hits, n_f_total, n_r_total)
    f_hi = _bar_residual(hi, Wf_hits, Wr_hits, n_f_total, n_r_total)
    for _ in range(max_iter):
        if f_lo < 0 < f_hi or f_hi < 0 < f_lo:
            break
        lo -= 5.0
        hi += 5.0
        f_lo = _bar_residual(lo, Wf_hits, Wr_hits, n_f_total, n_r_total)
        f_hi = _bar_residual(hi, Wf_hits, Wr_hits, n_f_total, n_r_total)
    else:
        return np.nan, False
    try:
        root = brentq(_bar_residual, lo, hi, args=(Wf_hits, Wr_hits, n_f_total, n_r_total),
                      xtol=tol, maxiter=500)
        return float(root), True
    except ValueError:
        return np.nan, False


def _solve_endpoint_bar(W_f_hits: np.ndarray, W_r: np.ndarray,
                        n_f_total: int, n_r: int) -> tuple[float, bool]:
    """Backward-compatible thin wrapper: finite hit arrays + explicit pool counts.

    Delegates to solve_bar_with_infinite_works (which also accepts +inf arrays).
    """
    return solve_bar_with_infinite_works(W_f_hits, W_r, n_f_total=n_f_total,
                                         n_r_total=n_r)


def _overlap_score(W_f_hits: np.ndarray, W_r: np.ndarray, n_bins: int = 40) -> float:
    """Histogram overlap of forward hit works W_f and negated reverse works -W_r.

    They share an axis under the Crooks pairing and cross at Delta G_B; OVL in
    [0,1], higher = better-conditioned BAR.  NaN if either side has <2 samples.
    """
    if len(W_f_hits) < 2 or len(W_r) < 2:
        return np.nan
    a, b = np.asarray(W_f_hits, float), -np.asarray(W_r, float)
    both = np.concatenate([a, b])
    lo, hi = np.percentile(both, 0.5), np.percentile(both, 99.5)
    pad = 0.05 * (hi - lo + 1e-9)
    bins = np.linspace(lo - pad, hi + pad, n_bins + 1)
    pa, _ = np.histogram(a, bins=bins, density=True)
    pb, _ = np.histogram(b, bins=bins, density=True)
    return float(np.sum(np.minimum(pa, pb) * np.diff(bins)))


# ── public estimator ────────────────────────────────────────────────────────────

def endpoint_restricted_bar(
    W_f: np.ndarray,
    b_end_f: np.ndarray,
    W_r: np.ndarray,
    b_start_r: np.ndarray,
    basin_ids,
    reference_basin: int = 0,
    bootstrap: bool = False,
    n_bootstrap: int = 200,
    rng: Optional[np.random.Generator] = None,
) -> dict:
    """Endpoint-restricted BAR (v6) for cold basin free-energy differences.

    Parameters
    ----------
    W_f, b_end_f : (N_f,) reduced forward works (= -lnw_f) and cold ENDPOINT basin.
    W_r, b_start_r : (N_r,) reduced reverse works (= -lnw_r) and cold START basin.
    basin_ids : iterable of basin labels (ints), e.g. [0,1,2,3].
    reference_basin : basin used as the ddF reference (ddF_ref == 0).

    Returns
    -------
    dict with "DeltaG", "ddF", "ddF_AIS", "diagnostics".
    """
    W_f = np.asarray(W_f, float)
    b_end_f = np.asarray(b_end_f, int)
    W_r = np.asarray(W_r, float)
    b_start_r = np.asarray(b_start_r, int)
    basin_ids = list(basin_ids)
    n_f_total = len(W_f)
    if rng is None:
        rng = np.random.default_rng(0)

    DeltaG, DeltaG_AIS, diagnostics = {}, {}, {}
    for B in basin_ids:
        hit = b_end_f == B
        W_f_hits = W_f[hit]
        W_r_B = W_r[b_start_r == B]
        n_hits, n_r = int(hit.sum()), int(len(W_r_B))

        dG_ais = _ais_delta_g(W_f_hits, n_f_total)
        dG_bar, ok = _solve_endpoint_bar(W_f_hits, W_r_B, n_f_total, n_r)
        DeltaG[B] = dG_bar
        DeltaG_AIS[B] = dG_ais

        warning = None
        if n_hits == 0:
            warning = "zero forward hits — basin free energy unidentifiable"
        elif n_hits < 5:
            warning = f"only {n_hits} forward hits — high uncertainty"
        elif n_r == 0:
            warning = "no reverse trajectories start in this basin"
        diagnostics[B] = dict(
            N_f_total=n_f_total, N_f_hits=n_hits,
            hit_fraction=n_hits / n_f_total if n_f_total else 0.0,
            N_r=n_r,
            DeltaG_BAR=dG_bar, DeltaG_AIS=dG_ais,
            bar_converged=bool(ok),
            overlap_score=_overlap_score(W_f_hits, W_r_B),
            warning=warning,
        )

    # ddF relative to the reference basin
    g_ref = DeltaG.get(reference_basin, np.nan)
    g_ref_ais = DeltaG_AIS.get(reference_basin, np.nan)
    ddF = {B: DeltaG[B] - g_ref for B in basin_ids}
    ddF_AIS = {B: DeltaG_AIS[B] - g_ref_ais for B in basin_ids}
    for B in basin_ids:
        diagnostics[B]["ddF_BAR"] = ddF[B]
        diagnostics[B]["ddF_AIS"] = ddF_AIS[B]
        # large BAR-AIS discrepancy flag
        if np.isfinite(ddF[B]) and np.isfinite(ddF_AIS[B]) and abs(ddF[B] - ddF_AIS[B]) > 2.0:
            extra = f"|ddF_BAR - ddF_AIS| = {abs(ddF[B]-ddF_AIS[B]):.2f} > 2 kT"
            diagnostics[B]["warning"] = (
                extra if diagnostics[B]["warning"] is None
                else diagnostics[B]["warning"] + "; " + extra)

    # ── bootstrap (resample the FULL forward set + per-basin reverse pool) ──────
    ddF_boot_samples = None
    if bootstrap:
        boot, ddF_boot_samples = _bootstrap(W_f, b_end_f, W_r, b_start_r, basin_ids,
                                            reference_basin, n_f_total, n_bootstrap, rng)
        for B in basin_ids:
            diagnostics[B].update(boot[B])
    else:
        for B in basin_ids:
            diagnostics[B].update(dict(bootstrap_std=None, bootstrap_mean=None,
                                       bootstrap_95ci_low=None, bootstrap_95ci_high=None))

    return dict(DeltaG=DeltaG, ddF=ddF, ddF_AIS=ddF_AIS, diagnostics=diagnostics,
                ddF_bootstrap_samples=ddF_boot_samples, bootstrap_basin_ids=list(basin_ids))


# ── endpoint-PARTITIONED pairwise BAR/MSK (v3 / v4a-c / v5) ──────────────────────
#
# Replaces the old channel-conditioned all-basin MSK (collect_ais_pairs_paired +
# corrected_cross_bar), which used only the successful alpha->beta channel.
#
# For every pair (alpha, beta):
#   * FORWARD pool  = ALL forward trajectories starting in hot basin alpha
#                     (n_f_pool = #{start==alpha}); a trajectory's work is W_f if
#                     its cold endpoint is beta, else +inf (final-wall).
#   * REVERSE pool  = ALL reverse trajectories starting in cold basin beta
#                     (n_r_pool = #{start==beta}); work is W_r if its hot endpoint
#                     is alpha, else +inf.
#   BAR over these two endpoint-partitioned states estimates
#       Delta[alpha, beta] = F_C^beta - F_H^alpha.
# The +inf-wall samples contribute 0 to the BAR sums but stay in the pool counts
# (n_f_pool, n_r_pool) — exactly the v6 endpoint-restriction, applied at BOTH ends.

def endpoint_partitioned_pairwise_bar(
    W_f, a_start_f, b_end_f, W_r, b_start_r, a_end_r, n_basins,
    bootstrap=False, n_bootstrap=200, rng=None,
):
    """Pairwise endpoint-partitioned BAR. Returns (Delta, var, diagnostics).

    Delta[alpha, beta] = F_C^beta - F_H^alpha  (nan where unidentifiable).
    var[alpha, beta]   = bootstrap variance of Delta (nan if bootstrap=False).
    """
    W_f = np.asarray(W_f, float); a_start_f = np.asarray(a_start_f, int)
    b_end_f = np.asarray(b_end_f, int)
    W_r = np.asarray(W_r, float); b_start_r = np.asarray(b_start_r, int)
    a_end_r = np.asarray(a_end_r, int)
    if rng is None:
        rng = np.random.default_rng(0)

    n_f_pool = np.array([(a_start_f == a).sum() for a in range(n_basins)])
    n_r_pool = np.array([(b_start_r == b).sum() for b in range(n_basins)])

    Delta = np.full((n_basins, n_basins), np.nan)
    var = np.full((n_basins, n_basins), np.nan)
    diagnostics = {}
    # pre-split pools by start basin
    f_pool_idx = {a: np.where(a_start_f == a)[0] for a in range(n_basins)}
    r_pool_idx = {b: np.where(b_start_r == b)[0] for b in range(n_basins)}

    for a in range(n_basins):
        fi = f_pool_idx[a]
        for b in range(n_basins):
            ri = r_pool_idx[b]
            Wf_hit = W_f[fi][b_end_f[fi] == b]
            Wr_hit = W_r[ri][a_end_r[ri] == a]
            nhf, nhr = len(Wf_hit), len(Wr_hit)
            nfp, nrp = int(n_f_pool[a]), int(n_r_pool[b])
            d, ok = (np.nan, False)
            if nhf >= 1 and nhr >= 1 and nfp > 0 and nrp > 0:
                d, ok = _solve_endpoint_bar(Wf_hit, Wr_hit, nfp, nrp)
            Delta[a, b] = d
            diagnostics[(a, b)] = dict(
                n_f_pool=nfp, n_r_pool=nrp, n_hits_f=nhf, n_hits_r=nhr,
                overlap_score=_overlap_score(Wf_hit, Wr_hit), converged=bool(ok),
            )

    # JOINT bootstrap: per replicate, resample each forward pool (per alpha) and
    # reverse pool (per beta) ONCE and recompute the whole Delta matrix.  This
    # keeps replicates paired across (alpha,beta), so row contrasts d_ab - d_a0
    # (v3) get correct covariance.  Stored in diagnostics["_boot_delta"].
    boot_delta = None
    if bootstrap:
        boot_delta = np.full((n_bootstrap, n_basins, n_basins), np.nan)
        for k in range(n_bootstrap):
            fsel = {a: f_pool_idx[a][rng.integers(0, n_f_pool[a], n_f_pool[a])]
                    if n_f_pool[a] > 0 else np.array([], int) for a in range(n_basins)}
            rsel = {b: r_pool_idx[b][rng.integers(0, n_r_pool[b], n_r_pool[b])]
                    if n_r_pool[b] > 0 else np.array([], int) for b in range(n_basins)}
            for a in range(n_basins):
                if n_f_pool[a] == 0:
                    continue
                be = b_end_f[fsel[a]]
                for b in range(n_basins):
                    if n_r_pool[b] == 0 or not diagnostics[(a, b)]["converged"]:
                        continue
                    wf = W_f[fsel[a]][be == b]
                    wr = W_r[rsel[b]][a_end_r[rsel[b]] == a]
                    if len(wf) >= 1 and len(wr) >= 1:
                        dd, okk = _solve_endpoint_bar(wf, wr, int(n_f_pool[a]), int(n_r_pool[b]))
                        if okk:
                            boot_delta[k, a, b] = dd
        with np.errstate(invalid="ignore"):
            var = np.nanvar(boot_delta, axis=0)
            var[np.isnan(Delta)] = np.nan
        diagnostics["_boot_delta"] = boot_delta
    return Delta, var, diagnostics


def _pair_neff(diag, a, b):
    d = diag[(a, b)]
    nhf, nhr = d["n_hits_f"], d["n_hits_r"]
    return 2.0 * nhf * nhr / (nhf + nhr) if (nhf + nhr) > 0 else 0.0


def _pair_ok(diagnostics, Delta, a, b, min_fh, min_rh, ovl_thr):
    if not np.isfinite(Delta[a, b]):
        return False
    d = diagnostics[(a, b)]
    if not d.get("converged", True):
        return False
    if d["n_hits_f"] < min_fh or d["n_hits_r"] < min_rh:
        return False
    ov = d.get("overlap_score")
    if ov is not None and np.isfinite(ov) and ov < ovl_thr:
        return False
    return True


def estimate_v3_row_contrast_endpoint_bar(
    Delta, var, diagnostics, reference_beta=0, n_basins=None, epsilon=1e-8,
    min_forward_hits=3, min_reverse_hits=3, overlap_threshold=1e-3,
    max_bootstrap_std=5.0,
):
    """v3 (corrected): cold ddF from SAME-hot-row contrasts.

    For each cold basin beta, each hot source alpha gives
        Delta f_{beta|alpha} = d[alpha,beta] - d[alpha,reference_beta]
                             = F(C_beta) - F(C_0)      (the hot source F(H_alpha) cancels),
    combined over the valid hot rows alpha with inverse-variance weights.  This
    REPLACES the wrong diagonal contrast d[beta,beta]-d[0,0] (which is the
    switching FE, not cold ddF).  Row variances use the JOINT bootstrap
    replicates in diagnostics["_boot_delta"] (paired across pairs, so the shared
    forward-alpha pool cancels); fallback sigma^2 ~ var[a,beta]+var[a,0].

    Returns (ddF_v3, ddF_v3_std, row_contributions, diagnostics_v3).
    """
    if n_basins is None:
        n_basins = Delta.shape[0]
    boot = diagnostics.get("_boot_delta")
    ddF = np.full(n_basins, np.nan)
    ddF_std = np.full(n_basins, np.nan)
    ddF[reference_beta] = 0.0
    ddF_std[reference_beta] = 0.0
    row_contributions, diag_v3 = {}, {}

    def ok(a, b):
        return _pair_ok(diagnostics, Delta, a, b, min_forward_hits,
                        min_reverse_hits, overlap_threshold)

    for beta in range(n_basins):
        if beta == reference_beta:
            continue
        ests, weights, stds, used = [], [], [], []
        for a in range(n_basins):
            if not (ok(a, beta) and ok(a, reference_beta)):
                continue
            est = Delta[a, beta] - Delta[a, reference_beta]
            if boot is not None:
                diff = boot[:, a, beta] - boot[:, a, reference_beta]
                diff = diff[np.isfinite(diff)]
                s2 = float(np.var(diff)) if len(diff) >= 2 else np.nan
            else:
                s2 = np.nan
            if not np.isfinite(s2):
                vb = var[a, beta] if np.isfinite(var[a, beta]) else 0.0
                v0 = var[a, reference_beta] if np.isfinite(var[a, reference_beta]) else 0.0
                s2 = vb + v0
            srow = np.sqrt(s2) if np.isfinite(s2) else np.inf
            if np.isfinite(srow) and srow > max_bootstrap_std:
                continue
            w = 1.0 / (s2 + epsilon) if (np.isfinite(s2) and s2 > 0) \
                else _pair_neff(diagnostics, a, beta)
            if not np.isfinite(w) or w <= 0:
                continue
            ests.append(est); weights.append(w); stds.append(float(srow)); used.append(a)
        if ests:
            w = np.array(weights); e = np.array(ests)
            ddF[beta] = float(np.dot(w, e) / w.sum())
            ddF_std[beta] = float(1.0 / np.sqrt(w.sum()))
            warn = None
        else:
            warn = "gated: no valid hot-source row"
        diag_v3[beta] = dict(beta=beta, valid_alpha_rows=used,
                             row_estimates=[float(x) for x in ests],
                             row_weights=[float(x) for x in weights],
                             row_bootstrap_std=stds, ddF=ddF[beta],
                             ddF_std=ddF_std[beta], warning=warn)
        row_contributions[beta] = list(zip(used, [float(x) for x in ests], stds))
    return ddF, ddF_std, row_contributions, diag_v3


def augmented_hot_g(hot_counts, S_fwd, E_rev=None, lambda_S=1.0, lambda_E=0.0,
                    reference=0, pseudocount=0.5):
    """v4c hot basin free energies from a regularized/augmented occupancy.

        C_eff[a] = C_MD[a] + lambda_S * S_fwd[a] + lambda_E * E_rev[a] + pseudocount
        g[a]     = -ln( C_eff[a] / C_eff[reference] )

    S_fwd = forward AIS hot-START counts per basin (drawn from the hot equilibrium
    if the hot seed is valid -> safe to add).  E_rev = reverse AIS hot-END counts
    (nonequilibrium endpoints -> off by default, lambda_E=0).
    """
    C = np.asarray(hot_counts, float) + lambda_S * np.asarray(S_fwd, float)
    if E_rev is not None and lambda_E != 0.0:
        C = C + lambda_E * np.asarray(E_rev, float)
    C = C + pseudocount
    return -np.log(C / C[reference])


def combine_pairs_with_g(Delta, var, diagnostics, g, n_basins, reference_basin=0,
                         min_forward_hits=3, min_reverse_hits=3,
                         overlap_threshold=1e-3, max_bootstrap_std=5.0, eps=1e-6):
    """v4: f_beta = uncertainty-weighted mean over alpha of (Delta[a,b] + g[a]).

    Each pair estimates F_C^beta - F_H^0 = Delta[a,b] + g[a]; combine over alpha.
    Pairs are GATED out if they have too few forward/reverse hits, poor overlap,
    a non-converged BAR, or an excessive bootstrap std.  Weights are
    inverse-variance (1/(bootstrap_std^2 + eps)); falls back to n_eff when no
    bootstrap variance is available.  Records ``used_in_v4`` in diagnostics.
    Returns ddF (f - f_ref).
    """
    f = np.full(n_basins, np.nan)
    for b in range(n_basins):
        hs, ws = [], []
        for a in range(n_basins):
            d = diagnostics[(a, b)]
            used = False
            gate_ok = (
                np.isfinite(Delta[a, b]) and np.isfinite(g[a])
                and d["n_hits_f"] >= min_forward_hits
                and d["n_hits_r"] >= min_reverse_hits
                and d.get("converged", True)
                and (d.get("overlap_score") is None
                     or (np.isfinite(d.get("overlap_score"))
                         and d.get("overlap_score") >= overlap_threshold))
            )
            v = var[a, b]
            if gate_ok and np.isfinite(v) and v > 0 and np.sqrt(v) > max_bootstrap_std:
                gate_ok = False
            if gate_ok:
                w = (1.0 / (v + eps)) if (np.isfinite(v) and v > 0) \
                    else _pair_neff(diagnostics, a, b)
                if w > 0:
                    hs.append(Delta[a, b] + g[a]); ws.append(w); used = True
            d["used_in_v4"] = used
        if hs:
            ws = np.array(ws); f[b] = float(np.dot(ws, hs) / ws.sum())
    return f - f[reference_basin]


def joint_endpoint_msk(Delta, var, diagnostics, g_msm, hot_counts, n_basins,
                       reference_basin=0):
    """v5: jointly solve {f_beta},{g_alpha} from the endpoint-BAR pair estimates
    AND the hot MSM, by weighted linear least squares (gauge f_0 = g_0 = 0).

    Observations (with the global switching offset c = F_C^0 - F_H^0 free, since
    the absolute pair BAR gives F_C^beta - F_H^alpha = f_beta - g_alpha + c):
      pair (alpha,beta):  f_beta - g_alpha + c = Delta[alpha,beta]  (weight w_pair)
      hot MSM   (alpha):  g_alpha             = g_msm[alpha]        (weight w_msm)
    Gauge f_0 = g_0 = 0; c absorbs the basin-0 hot->cold switching FE.
    Returns (ddF, f, g).  Linear-Gaussian limit of the joint MLE over the
    endpoint-MSK BAR likelihood and the hot-MSM likelihood.
    """
    # unknown vector: [f_1..f_{n-1}, g_1..g_{n-1}, c]  (f_0 = g_0 = 0)
    nf = n_basins - 1
    idx_f = {b: (b - 1) for b in range(1, n_basins)}
    idx_g = {a: nf + (a - 1) for a in range(1, n_basins)}
    idx_c = 2 * nf
    rows, rhs, wts = [], [], []
    for a in range(n_basins):
        for b in range(n_basins):
            if not np.isfinite(Delta[a, b]):
                continue
            v = var[a, b]
            w = (1.0 / v) if (np.isfinite(v) and v > 0) else _pair_neff(diagnostics, a, b)
            if w <= 0:
                continue
            row = np.zeros(2 * nf + 1)
            if b != reference_basin:
                row[idx_f[b]] += 1.0
            if a != reference_basin:
                row[idx_g[a]] -= 1.0
            row[idx_c] += 1.0
            rows.append(row); rhs.append(Delta[a, b]); wts.append(w)
    # hot MSM anchor for g (weight ~ hot counts, low variance)
    g_msm = np.asarray(g_msm, float)
    for a in range(1, n_basins):
        if not np.isfinite(g_msm[a]):
            continue
        row = np.zeros(2 * nf + 1)
        row[idx_g[a]] = 1.0
        rows.append(row); rhs.append(g_msm[a]); wts.append(float(hot_counts[a]))
    A = np.array(rows); b_vec = np.array(rhs); w = np.sqrt(np.array(wts))
    theta, *_ = np.linalg.lstsq(A * w[:, None], b_vec * w, rcond=None)
    f = np.zeros(n_basins); g = np.zeros(n_basins)
    for bb in range(1, n_basins):
        f[bb] = theta[idx_f[bb]]
        g[bb] = theta[idx_g[bb]]
    return f - f[reference_basin], f, g


def joint_endpoint_msk_likelihood(
    W_f, a_start_f, b_end_f, W_r, b_start_r, a_end_r, n_basins,
    g_msm, hot_counts, reference_basin=0, prior_scale=1.0,
    min_hits=1, Delta_init=None, var_init=None, diag_init=None,
):
    """v5 (full joint): minimize the endpoint-partitioned BAR negative
    log-likelihood over (f, g, c) plus a Gaussian hot-MSM prior on g.

    For each pair (a,b) with Delta_ab = f_b - g_a + c and pool-count offset
    M_ab = ln(n_f_pool[a] / n_r_pool[b]), the per-pair NLL is the convex BAR
    (Shirts logistic) objective:
        sum_{i in fwd a->b} softplus(Delta_ab - W_f,i - M_ab)
      + sum_{j in rev b->a} softplus(M_ab - Delta_ab - W_r,j)
    using only finite (matching-endpoint) works; +inf-wall samples contribute 0
    but stay in n_f_pool[a] / n_r_pool[b].  Gauge f_0 = g_0 = 0; c = F_C^0 - F_H^0.
    Prior:  0.5 * prior_scale * sum_a hot_counts[a] * (g_a - g_msm[a])^2.

    Initialized from the LLS joint_endpoint_msk solution.  Returns (ddF, f, g, c).
    """
    W_f = np.asarray(W_f, float); a_start_f = np.asarray(a_start_f, int)
    b_end_f = np.asarray(b_end_f, int)
    W_r = np.asarray(W_r, float); b_start_r = np.asarray(b_start_r, int)
    a_end_r = np.asarray(a_end_r, int)
    g_msm = np.asarray(g_msm, float); hot_counts = np.asarray(hot_counts, float)

    n_f_pool = np.array([(a_start_f == a).sum() for a in range(n_basins)])
    n_r_pool = np.array([(b_start_r == b).sum() for b in range(n_basins)])
    # precompute finite hit works + offsets per pair that has both-side support
    pairs = []
    f_idx = {a: np.where(a_start_f == a)[0] for a in range(n_basins)}
    r_idx = {b: np.where(b_start_r == b)[0] for b in range(n_basins)}
    for a in range(n_basins):
        for b in range(n_basins):
            if n_f_pool[a] == 0 or n_r_pool[b] == 0:
                continue
            wf = W_f[f_idx[a]][b_end_f[f_idx[a]] == b]
            wr = W_r[r_idx[b]][a_end_r[r_idx[b]] == a]
            if len(wf) < min_hits or len(wr) < min_hits:
                continue
            M = np.log(n_f_pool[a] / n_r_pool[b])
            pairs.append((a, b, wf, wr, M))

    nf = n_basins - 1
    idx_f = {b: (b - 1) for b in range(1, n_basins)}
    idx_g = {a: nf + (a - 1) for a in range(1, n_basins)}
    idx_c = 2 * nf

    def unpack(theta):
        f = np.zeros(n_basins); g = np.zeros(n_basins)
        for bb in range(1, n_basins):
            f[bb] = theta[idx_f[bb]]; g[bb] = theta[idx_g[bb]]
        return f, g, theta[idx_c]

    def nll(theta):
        f, g, c = unpack(theta)
        total = 0.0
        for (a, b, wf, wr, M) in pairs:
            D = f[b] - g[a] + c
            total += np.sum(np.logaddexp(0.0, D - wf - M))
            total += np.sum(np.logaddexp(0.0, M - D - wr))
        # Gaussian hot-MSM prior on g (g_0 fixed at 0)
        for a in range(1, n_basins):
            if np.isfinite(g_msm[a]):
                total += 0.5 * prior_scale * hot_counts[a] * (g[a] - g_msm[a]) ** 2
        return total

    # initialise from the LLS surrogate
    if Delta_init is None:
        Delta_init, var_init, diag_init = endpoint_partitioned_pairwise_bar(
            W_f, a_start_f, b_end_f, W_r, b_start_r, a_end_r, n_basins)
    _, f0, g0 = joint_endpoint_msk(Delta_init, var_init, diag_init, g_msm,
                                   hot_counts, n_basins, reference_basin)
    theta0 = np.zeros(2 * nf + 1)
    for bb in range(1, n_basins):
        theta0[idx_f[bb]] = f0[bb] if np.isfinite(f0[bb]) else 0.0
        theta0[idx_g[bb]] = g0[bb] if np.isfinite(g0[bb]) else g_msm[bb]
    # c init: median of (Delta - f + g) over finite pairs
    cs = [Delta_init[a, b] - (f0[b] if np.isfinite(f0[b]) else 0.0)
          + (g0[a] if np.isfinite(g0[a]) else 0.0)
          for a in range(n_basins) for b in range(n_basins)
          if np.isfinite(Delta_init[a, b])]
    theta0[idx_c] = float(np.median(cs)) if cs else 0.0

    res = minimize(nll, theta0, method="L-BFGS-B",
                   options={"maxiter": 500, "ftol": 1e-10})
    f, g, c = unpack(res.x)
    return f - f[reference_basin], f, g, float(c)


def _bootstrap(W_f, b_end_f, W_r, b_start_r, basin_ids, reference_basin,
               n_f_total, n_boot, rng) -> dict:
    """Basin-wise bootstrap; resamples the FULL forward set (keeps non-B endpoints)
    and the per-basin reverse pool, recomputing ddF_B = dG_B - dG_ref each replicate."""
    # pre-split reverse pools by basin
    r_idx = {B: np.where(b_start_r == B)[0] for B in basin_ids}
    samples = {B: [] for B in basin_ids}
    for _ in range(n_boot):
        f_sel = rng.integers(0, n_f_total, n_f_total)
        Wf_b, bend_b = W_f[f_sel], b_end_f[f_sel]
        # reference dG (resample its reverse pool)
        dG = {}
        for B in basin_ids:
            idx = r_idx[B]
            if len(idx) == 0:
                dG[B] = np.nan
                continue
            r_sel = idx[rng.integers(0, len(idx), len(idx))]
            hit = bend_b == B
            dG[B], _ = _solve_endpoint_bar(Wf_b[hit], W_r[r_sel], n_f_total, len(r_sel))
        g_ref = dG.get(reference_basin, np.nan)
        for B in basin_ids:
            samples[B].append(dG[B] - g_ref)
    out = {}
    for B in basin_ids:
        arr = np.array(samples[B], float)
        arr = arr[np.isfinite(arr)]
        if len(arr) < 2:
            out[B] = dict(bootstrap_std=np.nan, bootstrap_mean=np.nan,
                          bootstrap_95ci_low=np.nan, bootstrap_95ci_high=np.nan)
        else:
            out[B] = dict(
                bootstrap_std=float(np.std(arr)),
                bootstrap_mean=float(np.mean(arr)),
                bootstrap_95ci_low=float(np.percentile(arr, 2.5)),
                bootstrap_95ci_high=float(np.percentile(arr, 97.5)),
            )
    # aligned (n_boot, n_basins) replicate matrix (columns follow basin_ids order); lets callers
    # propagate the SAME replicates into a derived statistic (e.g. an RMSE-distribution CI).
    mat = np.column_stack([np.array(samples[B], float) for B in basin_ids])
    return out, mat
