"""Recursive rectangular basin tree in an arbitrary number of periodic CVs.

``barrier_partition`` is built around a dense 2-D ``(phi, psi)`` grid. A macrocycle needs all of its
backbone torsions as CVs -- ten for a cyclic pentapeptide -- and a ten-dimensional histogram is not
representable. This module does the same recursion on the weighted SAMPLES instead of a grid, so the
dimensionality only enters through 1-D marginals.

Algorithm, one node at a time:

  1. screen EVERY CV: build the weighted 1-D periodic marginal of the samples inside the node;
  2. enumerate candidate boundaries in that CV. A full circle needs a PAIR of cuts to produce two
     arcs; an interval that is already an arc needs one;
  3. score each candidate by the barrier

         dF = F_boundary - min(F_mode_A, F_mode_B),      F_boundary = min over the new cuts,

     i.e. measured from the DEEPEST minimum in the node (the slow escape direction -- see
     ``barrier_partition`` module docstring) and, for a periodic pair, through the EASIER of the two
     boundaries, since a walker will use whichever crossing is cheaper;
  4. accept only if dF >= stop_barrier_kT, both children carry at least ``min_basin_mass``, and both
     children are at least ``min_width_deg`` wide;
  5. take the accepted candidate with the LARGEST dF, across all CVs, and split;
  6. recurse until no node admits an accepted split.

The result is an exhaustive, mutually disjoint set of rectangular cells in the full CV space.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

from escort_ais.methods.cell_mass_reliability import Z_95_ONE_SIDED, cut_admissible

TWO_PI = 2.0 * np.pi


def wrap(a):
    return (np.asarray(a, float) + np.pi) % TWO_PI - np.pi


@dataclass
class Arc:
    """Half-open periodic interval ``[lo, hi)``; ``full`` marks the whole circle."""
    lo: float = -np.pi
    hi: float = np.pi
    full: bool = True

    @property
    def width(self) -> float:
        return TWO_PI if self.full else (self.hi - self.lo) % TWO_PI

    def contains(self, x) -> np.ndarray:
        x = np.asarray(x, float)
        if self.full:
            return np.ones(x.shape, bool)
        return ((x - self.lo) % TWO_PI) < self.width

    def as_deg(self):
        return (None if self.full else (float(np.degrees(self.lo)), float(np.degrees(self.hi))))


@dataclass
class Cell:
    """A rectangular cell: one :class:`Arc` per CV."""
    arcs: list
    label: str = "C0"
    parent: Optional[str] = None
    mass: float = 1.0
    depth: int = 0
    split_dim: Optional[int] = None
    split_barrier_kT: Optional[float] = None
    stop_reason: str = ""
    # Stable identity. ``label`` is renumbered after every split, so it cannot be used to
    # reconstruct ancestry; ``uid``/``parent_uid`` survive renumbering and give the real tree.
    uid: int = -1
    parent_uid: int = -1

    def contains(self, X) -> np.ndarray:
        m = np.ones(len(X), bool)
        for d, a in enumerate(self.arcs):
            if not a.full:
                m &= a.contains(X[:, d])
        return m

    def active_dims(self):
        return [d for d, a in enumerate(self.arcs) if not a.full]


def marginal(x, w, arc: Arc, nbin: int = 48, smooth: int = 2):
    """Weighted periodic 1-D free energy along one CV, restricted to ``arc``.

    Returns bin centres, ``F = -ln p`` referenced to its own minimum, and the normalised histogram.
    Smoothing is a periodic Gaussian, which matters because an unsmoothed marginal has spurious
    zero-density bins that read as infinite barriers.
    """
    if arc.full:
        e = np.linspace(-np.pi, np.pi, nbin + 1)
        h, _ = np.histogram(x, bins=e, weights=w)
        k = np.exp(-0.5 * (np.arange(-3 * smooth, 3 * smooth + 1) / smooth) ** 2); k /= k.sum()
        h = np.convolve(np.r_[h, h, h], k, mode="same")[nbin:2 * nbin]
    else:
        # unroll the arc so the histogram is contiguous, then smooth without wrapping across walls
        t = (x - arc.lo) % TWO_PI
        e = np.linspace(0.0, arc.width, nbin + 1)
        h, _ = np.histogram(t, bins=e, weights=w)
        k = np.exp(-0.5 * (np.arange(-3 * smooth, 3 * smooth + 1) / smooth) ** 2); k /= k.sum()
        h = np.convolve(h, k, mode="same")
        e = wrap(arc.lo + e)
    s = h.sum()
    if s <= 0:
        return None, None, None
    h = h / s
    with np.errstate(divide="ignore"):
        F = -np.log(np.where(h > 0, h, np.nan))
    c = wrap(0.5 * (np.linspace(-np.pi, np.pi, nbin + 1)[:-1] + np.linspace(-np.pi, np.pi, nbin + 1)[1:])) \
        if arc.full else wrap(arc.lo + (np.arange(nbin) + 0.5) * arc.width / nbin)
    return c, F - np.nanmin(F), h


def barrier_tiered_floor(tiers):
    """``f(barrier_kT) -> min_basin_mass``: a mass floor that relaxes for well-separated states.

    ``tiers`` is [(barrier_kT, floor), ...]; the highest tier whose barrier is met wins, and the
    last entry should have barrier 0 as the default.

    Rationale. The barrier and the floor answer different questions -- "is this a distinct kinetic
    state" and "can we measure it" -- so coupling them needs justifying. It is justified by the
    ASYMMETRY of the two errors under disjoint-substate conditional BAR:

      * splitting a cell we cannot measure well gives THAT cell a wide error bar, and no other,
        because every substate is solved independently against the shared hot state;
      * merging across a high barrier makes the merged cell's confined walker non-ergodic, and its
        free energy is then silently biased -- the campaign_v2 within-box equilibration failure.

    A loud error bar is preferable to a silent bias, so a state behind a high barrier deserves a
    lower mass floor than one behind a low barrier.

    Use a smooth or hysteretic form in production if cuts cluster near a tier edge: cilengitide's
    second cut sits at 4.99 kT, which a hard 5 kT step decides by 0.01 kT.
    """
    tiers = sorted(([float(b), float(f)] for b, f in tiers), key=lambda t: -t[0])

    def floor(barrier_kT: float) -> float:
        for b, f in tiers:
            if barrier_kT >= b:
                return f
        return tiers[-1][1]

    return floor


DEFAULT_FLOOR_TIERS = ((5.0, 0.005), (3.0, 0.01))
#: Project default (2026-08-06). A cut clearing 5 kT earns a 0.5% floor; one clearing only the
#: 3 kT admission barrier keeps 1%. Validated on cyclo-(RGDfV) (unchanged), cilengitide (correctly
#: refuses a 3.9 kT sliver that a flat 0.5% floor admits, TV vs REMD 0.0052 vs 0.0149) and
#: rgd_redPheVal (recovers a 10.4 kT / 1.42% state, TV vs REMD 0.0011 -- the best of any scheme).


def parse_floor_spec(spec):
    """``"5:0.005,3:0.01"`` -> a barrier-tiered floor; a bare number -> that constant floor."""
    if spec is None:
        return None
    if isinstance(spec, (int, float)):
        return float(spec)
    txt = str(spec).strip()
    if ":" not in txt:
        return float(txt)
    tiers = [tuple(float(v) for v in part.split(":")) for part in txt.split(",") if part.strip()]
    return barrier_tiered_floor(tiers)


def _mode_F(F, mask):
    v = F[mask]
    return float(np.nanmin(v)) if np.isfinite(v).any() else np.inf


def arc_mass_fn(x, w):
    """``f(arc) -> weight inside arc``, exact, in O(log n) instead of O(n) per call.

    ``Arc.contains`` scans the whole array, and the search asks for the mass of O(nbin^2) candidate
    arcs per CV per cell, so that scan is the dominant cost of a large build. Sorting once and
    reading a prefix sum gives the identical number: ``contains`` is the half-open ``[lo, lo+width)``
    and ``searchsorted(..., 'left')`` is the matching half-open prefix.
    """
    o = np.argsort(x)
    xs = np.asarray(x)[o]
    cw = np.concatenate([[0.0], np.cumsum(np.asarray(w, float)[o])])
    tot = float(cw[-1])

    def below(t):
        return float(cw[np.searchsorted(xs, t, side="left")])

    def mass(arc: Arc) -> float:
        if arc.full:
            return tot
        lo, hi = float(arc.lo), float(arc.hi)
        return below(hi) - below(lo) if lo <= hi else tot - below(lo) + below(hi)

    return mass


def score_boundary(x, w, arc: Arc, cuts, nbin, smooth, min_width, min_mass, total_w,
                   marginal_cache=None, mass_fn=None):
    """Barrier and acceptance for splitting ``arc`` at ``cuts`` (1 cut on an arc, 2 on a circle).

    ``marginal_cache`` is the ``(centres, F)`` pair for this ``(x, w, arc)``, which the caller may
    have already computed. It is a pure optimisation and changes no result -- but a large one: the
    marginal does not depend on ``cuts``, while the search evaluates O(nbin^2) candidate cuts per
    CV, so recomputing it inside each call rebuilds the identical weighted histogram hundreds of
    times per cell per CV. On a 200k-row, 11-CV cloud that redundancy dominates the whole build.
    """
    if marginal_cache is not None:
        c, F = marginal_cache
    else:
        c, F, _ = marginal(x, w, arc, nbin, smooth)
    if c is None:
        return None
    if arc.full:
        c1, c2 = cuts
        A, B = Arc(c1, c2, False), Arc(c2, c1, False)
        f_bound = min(np.interp(0.0, [0.0], [0.0]) if False else _nearest(c, F, c1),
                      _nearest(c, F, c2))
    else:
        (c1,) = cuts
        A, B = Arc(arc.lo, c1, False), Arc(c1, arc.hi, False)
        f_bound = _nearest(c, F, c1)
    if min(A.width, B.width) < min_width:
        return dict(accepted=False, reason="min_width")
    mA, mB = ((mass_fn(A), mass_fn(B)) if mass_fn is not None
              else (w[A.contains(x)].sum(), w[B.contains(x)].sum()))
    if not np.isfinite(f_bound):
        return dict(accepted=False, reason="empty boundary bin")
    fA, fB = _mode_F(F, A.contains(c)), _mode_F(F, B.contains(c))
    if not (np.isfinite(fA) and np.isfinite(fB)):
        return dict(accepted=False, reason="empty child")
    # DEEPEST minimum in the node, and the EASIER of the two periodic boundaries
    dF = float(f_bound - min(fA, fB))
    # the floor may depend on the barrier -- see barrier_tiered_floor
    mm = float(min_mass(dF)) if callable(min_mass) else float(min_mass)
    ok_mass = min(mA, mB) / max(total_w, 1e-300) >= mm
    return dict(accepted=bool(dF >= 0 and ok_mass), barrier_kT=dF,
                mass_A=float(mA), mass_B=float(mB), arcs=(A, B),
                F_boundary=float(f_bound), F_mode_A=fA, F_mode_B=fB,
                min_basin_mass_used=mm,
                reason=("" if ok_mass else "min_basin_mass"))


def _nearest(c, F, value):
    j = int(np.argmin(np.abs(wrap(c - value))))
    return F[j]


def build_nd_tree(X, w=None, stop_barrier_kT: float = 3.0, min_basin_mass: float = 0.01,
                  min_width_deg: float = 30.0, nbin: int = 48, smooth: int = 2,
                  max_cells: int = 32, cut_stride: int = 2, order_by: str = "barrier",
                  cluster_ids=None, reliability_z: float = Z_95_ONE_SIDED,
                  reliability_method: str = "normal", reliability_n_boot: int = 500,
                  reliability_percentile: float = 5.0, max_rejected_cuts: int = 400,
                  rng=None, verbose: bool = True):
    """Recursive N-D rectangular basin tree on weighted periodic samples.

    :param X: ``(n_samples, n_cv)`` angles in RADIANS.
    :param w: sample weights (uniform if None). Masses are fractions of the TOTAL weight, so
        ``min_basin_mass`` always refers to the global partition, not to the parent node.
    :param cluster_ids: independent-unit id per sample (the AIS SHOT for an HS cloud). Supplying it
        turns on the reliability gate: a candidate cut is taken only if BOTH children clear the mass
        floor with confidence, ``pi_child - z*se > min_basin_mass``. A candidate that fails is
        blacklisted and the search continues to the next-best one, exactly as for a cut below the
        barrier threshold, so the rejection costs that cut and not the whole partition. With
        ``cluster_ids=None`` the gate is off and the search is bit-identical to the ungated tree.

    Returns ``rejected_cuts`` alongside ``cells``/``trace``: every candidate turned down for
    reliability, with its barrier and its children's bounds, so the cost of the gate is visible
    rather than implicit.
    """
    X = np.asarray(X, float)
    n, D = X.shape
    w = np.full(n, 1.0 / n) if w is None else np.asarray(w, float) / np.sum(w)
    min_width = np.radians(min_width_deg)
    gated = cluster_ids is not None
    # factorise once: cluster_weights is called per candidate cut, and np.unique on
    # string shot ids there is the dominant cost of a gated build
    clusters = (np.unique(np.asarray(cluster_ids), return_inverse=True)[1]
                if gated else None)
    rng = np.random.default_rng() if rng is None else rng
    root = Cell([Arc() for _ in range(D)], label="C0", mass=1.0, uid=0)
    cells, trace, rejected = [root], [], []
    _next_uid = [1]
    blacklist: set = set()          # (cell uid, dim, cuts) turned down for reliability
    truncated = False

    # Scored candidates per cell uid. A cell's candidate set does not change while the cell lives,
    # so scoring it once keeps a rejection O(1) instead of re-scanning every CV: without this a
    # system that rejects hundreds of cuts costs quadratic time in the number of rejections.
    _cands: dict = {}

    def candidates_for(cell):
        if cell.uid in _cands:
            return _cands[cell.uid]
        m = cell.contains(X)
        out = []
        if m.any():
            xs, ws = X[m], w[m]
            for d in range(D):
                arc = cell.arcs[d]
                c, F, _ = marginal(xs[:, d], ws, arc, nbin, smooth)
                if c is None:
                    continue
                cand = c[::cut_stride]
                pairs = ([(a, b) for i, a in enumerate(cand) for b in cand[i + 1:]]
                         if arc.full else [(a,) for a in cand])
                mfn = arc_mass_fn(xs[:, d], ws)
                for cuts in pairs:
                    sc = score_boundary(xs[:, d], ws, arc, cuts, nbin, smooth, min_width,
                                        min_basin_mass, 1.0, marginal_cache=(c, F),
                                        mass_fn=mfn)
                    if sc is None or not sc.get("accepted"):
                        continue
                    # ORDERING across CVs. Within a CV the cut is always the max-barrier
                    # admissible one; this only decides which validated cut is taken FIRST.
                    #   "barrier" -- largest barrier. Tracks the physics and is robust on a
                    #     trustworthy ensemble (REMD margin 23%).
                    #   "balance" -- largest m_A m_B / (m_A + m_B). Rewards separating MASS, not
                    #     separating real states: on a contaminated cloud it promoted a large
                    #     spurious population to the root (RGD CV8, margin 36%) and was a
                    #     coin-flip on REMD (margin 0.6%). NOTE that measurement was made on the
                    #     omega-scaled RGD cloud retired 2026-07-31, so it is not evidence about
                    #     the current data.
                    #   "minor_mass" -- largest min(m_A, m_B). Orders by exactly the quantity rule
                    #     4 then tests (the minor child is the one whose lower bound must clear the
                    #     floor), so the search tries its most defensible cut first instead of its
                    #     steepest one. Nearly the same ordering as "balance" when the minor child
                    #     is small, but exact rather than a proxy.
                    mA, mB = sc["mass_A"], sc["mass_B"]
                    key = (sc["barrier_kT"] if order_by == "barrier"
                           else min(mA, mB) if order_by == "minor_mass"
                           else mA * mB / max(mA + mB, 1e-300))
                    out.append((key, int(d), tuple(cuts), sc))
        out.sort(key=lambda t: -t[0])
        _cands[cell.uid] = out
        return out

    while len(cells) < max_cells:
        best = None
        for ci, cell in enumerate(cells):
            if cell.stop_reason:
                continue
            if not cell.contains(X).any():
                cell.stop_reason = "empty"; continue
            lst = candidates_for(cell)
            if not lst:
                cell.stop_reason = cell.stop_reason or "no admissible cut"
                continue
            for key, d, cuts, sc in lst:            # sorted by key, so the first hit is this
                if sc["barrier_kT"] < stop_barrier_kT:   # cell's best surviving candidate.
                    continue                        # `continue`, not `break`: under order_by=
                if (cell.uid, d, tuple(np.round(cuts, 9))) in blacklist:   # "balance" the list is
                    continue                        # not sorted by barrier.
                if best is None or key > best[4]:
                    best = (sc, ci, d, cuts, key)
                break
        if best is None:
            break
        sc, ci, d, cuts, _key = best
        parent = cells[ci]
        A, B = sc["arcs"]

        if gated:
            # Would both children be reliably above the floor? The masks are evaluated on the WHOLE
            # cloud, not on the parent's subset, because min_basin_mass is a global fraction.
            masks = []
            for arc_new in (A, B):
                arcs = list(parent.arcs); arcs[d] = arc_new
                masks.append(Cell(arcs, label="?", uid=-1).contains(X))
            floor_here = sc.get("min_basin_mass_used", min_basin_mass)
            ver = cut_admissible(w, clusters, masks, floor_here, z=reliability_z,
                                 method=reliability_method, n_boot=reliability_n_boot,
                                 percentile=reliability_percentile, rng=rng)
            if not ver["admissible"]:
                blacklist.add((parent.uid, d, tuple(np.round(cuts, 9))))
                rejected.append(dict(parent_uid=int(parent.uid), parent_label=parent.label,
                                     dim=int(d), cuts_deg=[float(np.degrees(x)) for x in cuts],
                                     barrier_kT=float(sc["barrier_kT"]),
                                     child_mass=ver["mass"], child_se=ver["se"],
                                     child_bound=ver["bound"], method=ver["method"]))
                if verbose:
                    print(f"[nd-tree] REJECT CV {d:2d} at "
                          f"{', '.join('%+.0f' % np.degrees(x) for x in cuts)} deg  "
                          f"barrier {sc['barrier_kT']:.2f} kT  "
                          f"child mass {ver['mass'][0]:.4f}/{ver['mass'][1]:.4f}  "
                          f"bound {ver['bound'][0]:+.5f}/{ver['bound'][1]:+.5f} "
                          f"vs floor {min_basin_mass:g}")
                if len(rejected) >= int(max_rejected_cuts):
                    truncated = True
                    break
                continue                      # search again WITHOUT this candidate

        cells.pop(ci)
        kids = []
        for side, arc_new in zip("AB", (A, B)):
            arcs = list(parent.arcs); arcs[d] = arc_new
            kids.append(Cell(arcs, label="", parent=parent.label, depth=parent.depth + 1,
                             uid=_next_uid[0], parent_uid=parent.uid))
            _next_uid[0] += 1
        cells.extend(kids)
        for i, cc in enumerate(cells):
            cc.label = f"C{i}"
            cc.mass = float(w[cc.contains(X)].sum())
        trace.append(dict(parent_uid=int(parent.uid),
                          child_uids=[int(k.uid) for k in kids],
                          dim=int(d), cuts_deg=[float(np.degrees(x)) for x in cuts],
                          barrier_kT=float(sc["barrier_kT"]),
                          F_boundary=sc["F_boundary"],
                          F_mode_A=sc["F_mode_A"], F_mode_B=sc["F_mode_B"],
                          mass_A=sc["mass_A"], mass_B=sc["mass_B"],
                          n_cells=len(cells)))
        if verbose:
            print(f"[nd-tree] split CV {d:2d} at "
                  f"{', '.join('%+.0f' % np.degrees(x) for x in cuts)} deg  "
                  f"barrier {sc['barrier_kT']:.2f} kT  "
                  f"masses {sc['mass_A']:.4f}/{sc['mass_B']:.4f}  -> {len(cells)} cells")

    for i, cc in enumerate(cells):
        cc.label = f"C{i}"
        cc.mass = float(w[cc.contains(X)].sum())
    if truncated and verbose:
        print(f"[nd-tree] stopped after {len(rejected)} rejected cuts (max_rejected_cuts) -- "
              f"the search was NOT exhausted")
    return dict(cells=cells, trace=trace, n_cv=int(D), rejected_cuts=rejected,
                reliability_gated=bool(gated), rejection_search_truncated=bool(truncated),
                params=dict(stop_barrier_kT=stop_barrier_kT, min_basin_mass=min_basin_mass,
                            min_width_deg=min_width_deg, nbin=nbin, smooth=smooth,
                            cut_stride=cut_stride, max_cells=max_cells, order_by=order_by,
                            reliability_z=float(reliability_z) if gated else None,
                            reliability_method=reliability_method if gated else None))


def cells_to_spec(cells, n_cv=None, **extra) -> dict:
    """Serialise a cell list to a plain dict, so a frozen partition can be shared by file.

    Without this every consumer must RE-DERIVE the partition from the landing cloud that produced
    it, and the derivation depends on inputs that are easy to drift apart -- landing count, tree
    parameters, even the cloud file. On RGD three separate scripts re-derived the same cells three
    ways; a serialised partition makes "the frozen partition" a single artefact instead of a
    procedure everyone must repeat identically.

    ``arcs_rad`` carries EVERY dimension, not just the active ones, so a round trip is exact:
    an inactive dimension is the full circle and must come back as ``full=True`` rather than as a
    finite arc that happens to span 2*pi.
    """
    n_cv = int(n_cv if n_cv is not None else len(cells[0].arcs))
    return dict(
        n_cv=n_cv,
        cells=[dict(label=c.label, mass=float(c.mass),
                    active_dims=[int(d) for d in sorted(c.active_dims())],
                    arcs_rad=[[float(c.arcs[d].lo), float(c.arcs[d].hi)] for d in range(n_cv)],
                    arcs_full=[bool(c.arcs[d].full) for d in range(n_cv)],
                    arcs_deg={int(d): [float(np.degrees(c.arcs[d].lo)),
                                       float(np.degrees(c.arcs[d].hi))]
                              for d in sorted(c.active_dims())})
               for c in cells],
        **extra)


def cells_from_spec(spec: dict) -> list:
    """Inverse of :func:`cells_to_spec`. Returns cells ordered as stored."""
    n_cv = int(spec["n_cv"])
    out = []
    for i, cd in enumerate(spec["cells"]):
        full = cd.get("arcs_full")
        if full is None:                       # tolerate specs that only recorded active_dims
            act = set(int(d) for d in cd.get("active_dims", []))
            full = [d not in act for d in range(n_cv)]
        arcs = [Arc(lo=float(lo), hi=float(hi), full=bool(f))
                for (lo, hi), f in zip(cd["arcs_rad"], full)]
        c = Cell(arcs=arcs, label=cd.get("label", "C%d" % i), mass=float(cd.get("mass", 0.0)))
        out.append(c)
    return out


def summarize(res, cv_names=None):
    out = []
    for c in res["cells"]:
        act = {("CV%d" % d if cv_names is None else cv_names[d]): c.arcs[d].as_deg()
               for d in c.active_dims()}
        out.append(dict(label=c.label, mass=c.mass, depth=c.depth,
                        stop_reason=c.stop_reason, active=act))
    return out


def tree_lines(res, cv_names=None, weight_of=None):
    """ASCII tree of the partition: every split node and every leaf cell with its mass.

    Uses ``uid``/``parent_uid`` rather than ``label``, which is renumbered after each split.
    """
    tr = res["trace"]
    by_parent = {}
    for t in tr:
        by_parent[t["parent_uid"]] = t
    leaf = {c.uid: c for c in res["cells"]}
    name = (lambda d: "CV%d" % d) if cv_names is None else (lambda d: cv_names[d])
    out = []

    def walk(uid, prefix, is_last, depth):
        conn = "" if depth == 0 else ("└─ " if is_last else "├─ ")
        if uid in by_parent:
            t = by_parent[uid]
            cuts = ", ".join("%+.0f" % c for c in t["cuts_deg"])
            out.append("%s%ssplit %s @ %s deg   barrier %.2f kT   -> %.4f / %.4f"
                       % (prefix, conn, name(t["dim"]), cuts, t["barrier_kT"],
                          t["mass_A"], t["mass_B"]))
            kids = t["child_uids"]
            npre = prefix + ("" if depth == 0 else ("   " if is_last else "│  "))
            for i, k in enumerate(kids):
                walk(k, npre, i == len(kids) - 1, depth + 1)
        else:
            c = leaf.get(uid)
            if c is None:
                return
            act = ", ".join("%s=[%.0f,%.0f)" % (name(d), *c.arcs[d].as_deg())
                            for d in c.active_dims())
            out.append("%s%s%-4s mass %.4f   %s%s" % (prefix, conn, c.label, c.mass, act,
                                                      ("   [%s]" % c.stop_reason) if c.stop_reason else ""))
    walk(0, "", True, 0)
    return out
