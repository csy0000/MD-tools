"""multi_walker_md.py — Run K independent MD walkers from K external seed positions.

Differs from md_run.run_single_md in one way: accepts seed_positions_nm
(K, n_atoms, 3) instead of reading positions from inpcrd.  All other
topology/system setup is shared with md_run helpers.

Each walker writes to output_dir/walker_{k:04d}/:
  trajectory.dcd      — every traj_interval_steps
  state.csv           — every traj_interval_steps
  config.json         — per-walker config

After all walkers finish, the function writes to output_dir/:
  walker_index.npy    — (total_frames,) int array: which walker each frame belongs to
  frame_index.npy     — (total_frames,) int array: frame number within that walker
  summary.json        — n_walkers, n_frames_each, wall_time_s, ...

Walker-level outputs preserve identity: build_lagged_pairs must NEVER see
frames from different walkers as consecutive — use walker_index.npy.
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Optional

import numpy as np

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pure helpers (unit-testable without OpenMM)
# ---------------------------------------------------------------------------

def validate_seed_positions(seed_positions_nm: np.ndarray, n_atoms: int) -> None:
    """Raise if seed_positions_nm has the wrong shape."""
    arr = np.asarray(seed_positions_nm)
    if arr.ndim != 3:
        raise ValueError(
            f"seed_positions_nm must be 3-D (K, n_atoms, 3), got shape {arr.shape}"
        )
    K, n, xyz = arr.shape
    if n != n_atoms:
        raise ValueError(
            f"seed_positions_nm has {n} atoms; prmtop has {n_atoms}. "
            "Run reorder_positions_to_openmm first."
        )
    if xyz != 3:
        raise ValueError(f"Last dim must be 3 (x,y,z), got {xyz}.")


def walker_output_dir(output_dir: Path, walker_idx: int) -> Path:
    return output_dir / f"walker_{walker_idx:04d}"


def build_walker_frame_index(n_frames_per_walker: list[int]) -> tuple[np.ndarray, np.ndarray]:
    """Build walker_index and frame_index arrays from per-walker frame counts."""
    walker_idx_list = []
    frame_idx_list = []
    for w, n in enumerate(n_frames_per_walker):
        walker_idx_list.extend([w] * n)
        frame_idx_list.extend(range(n))
    return np.array(walker_idx_list, dtype=np.int64), np.array(frame_idx_list, dtype=np.int64)


# ---------------------------------------------------------------------------
# OpenMM simulation runner
# ---------------------------------------------------------------------------

def run_independent_walkers(
    topology_dir: Path,
    *,
    seed_positions_nm: np.ndarray,
    scale_factor: float = 1.0,
    duration_steps: int,
    temperature_k: float = 300.0,
    timestep_fs: float = 2.0,
    friction_per_ps: float = 1.0,
    traj_interval_steps: int = 500,
    platform: Optional[str] = None,
    seed: int = 42,
    output_dir: Path,
    minimize_steps: int = 500,
    dry_run: bool = False,
) -> dict:
    """Run K independent MD walkers from K external seed positions.

    Parameters
    ----------
    topology_dir:
        Build-topology output dir (system.prmtop + config.json).
    seed_positions_nm:
        (K, n_atoms, 3) float64 array in nm, Amber atom order.
    scale_factor:
        REST2 scale factor for all walkers (1.0 = physical; 0.4 = hot).
    duration_steps:
        Number of production MD steps per walker.
    temperature_k:
        Langevin temperature in Kelvin.
    timestep_fs:
        Integrator timestep in femtoseconds.
    friction_per_ps:
        Langevin friction coefficient in ps⁻¹.
    traj_interval_steps:
        Frames written every N steps.
    platform:
        OpenMM platform name ("CUDA", "OpenCL", "CPU").  Auto-detected if None.
    seed:
        Base RNG seed; walker k gets seed + k for velocity initialization.
    output_dir:
        Root output directory.  Walker k → output_dir/walker_{k:04d}/.
    minimize_steps:
        Energy minimization steps before velocity assignment (per walker).
    dry_run:
        If True, validate inputs and write config.json files but skip MD.

    Returns
    -------
    dict  Summary: n_walkers, n_frames_per_walker, output_dir, wall_time_s.
    """
    from openmm import unit  # noqa: PLC0415
    from openmm import app  # noqa: PLC0415
    from escort_ais.methods.md_run import (  # noqa: PLC0415
        _load_topology,
        _pick_platform,
        _create_base_system,
        _build_simulation,
        _attach_reporters,
    )
    from escort_ais.systems.openmm_system import build_rest2_scaled_system  # noqa: PLC0415
    from escort_ais.common.paths import ensure_dir  # noqa: PLC0415

    seed_positions_nm = np.asarray(seed_positions_nm, dtype=np.float64)
    topology_dir = Path(topology_dir)
    output_dir = Path(output_dir)

    # Load topology
    topo_config, prmtop_path, _ = _load_topology(topology_dir)
    topology_solvent = topo_config["solvent"]
    n_solute_atoms = int(topo_config["n_solute_atoms"])

    # Load prmtop to get n_atoms for shape validation
    prmtop = app.AmberPrmtopFile(str(prmtop_path))
    n_atoms = prmtop.topology.getNumAtoms()
    validate_seed_positions(seed_positions_nm, n_atoms)

    K = seed_positions_nm.shape[0]
    platform_name = _pick_platform(platform)

    # Build system once, reuse for all walkers
    base_system = _create_base_system(
        prmtop, topology_solvent, temperature_k, 1.0, "nvt",
        topology_dir=topology_dir
    )
    if abs(scale_factor - 1.0) > 1e-9:
        system = build_rest2_scaled_system(base_system, np.arange(n_solute_atoms), scale_factor)
    else:
        system = base_system

    ensure_dir(output_dir)

    # Write top-level config
    top_config = {
        "n_walkers": K,
        "scale_factor": scale_factor,
        "temperature_k": temperature_k,
        "duration_steps": duration_steps,
        "timestep_fs": timestep_fs,
        "friction_per_ps": friction_per_ps,
        "traj_interval_steps": traj_interval_steps,
        "platform": platform_name,
        "seed": seed,
        "minimize_steps": minimize_steps,
        "topology_dir": str(topology_dir.resolve()),
        "output_dir": str(output_dir.resolve()),
        "dry_run": dry_run,
    }
    (output_dir / "config.json").write_text(json.dumps(top_config, indent=2), encoding="utf-8")

    if dry_run:
        log.info("dry_run=True: skipping MD simulation for %d walkers", K)
        n_frames_each = [0] * K
        walker_idx, frame_idx = build_walker_frame_index(n_frames_each)
        np.save(output_dir / "walker_index.npy", walker_idx)
        np.save(output_dir / "frame_index.npy", frame_idx)
        summary = {
            "n_walkers": K,
            "n_frames_per_walker": n_frames_each,
            "total_frames": 0,
            "dry_run": True,
            "output_dir": str(output_dir.resolve()),
        }
        (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return summary

    t_start = time.time()
    n_frames_each: list[int] = []

    for k in range(K):
        walker_dir = ensure_dir(walker_output_dir(output_dir, k))
        walker_seed = seed + k

        # Build a fresh simulation (new integrator per walker to avoid state coupling)
        sim = _build_simulation(
            prmtop.topology, system, temperature_k, friction_per_ps, timestep_fs, platform_name
        )

        # Set external seed positions (nm → OpenMM Quantity in nm)
        positions_qty = unit.Quantity(
            seed_positions_nm[k].tolist(),
            unit.nanometer,
        )
        sim.context.setPositions(positions_qty)

        # Energy minimize to relax bad contacts from conformer generation
        if minimize_steps > 0:
            sim.minimizeEnergy(maxIterations=minimize_steps)

        # Assign velocities
        sim.context.setVelocitiesToTemperature(temperature_k * unit.kelvin, walker_seed)

        # Attach reporters
        _attach_reporters(sim, walker_dir, traj_interval_steps, traj_interval_steps * 10, duration_steps)

        # Production run
        sim.step(duration_steps)

        # Count frames written
        n_frames = max(1, duration_steps // traj_interval_steps)
        n_frames_each.append(n_frames)

        # Per-walker config
        walker_cfg = {**top_config, "walker_index": k, "seed": walker_seed,
                      "output_dir": str(walker_dir.resolve())}
        (walker_dir / "config.json").write_text(json.dumps(walker_cfg, indent=2), encoding="utf-8")

        log.info("Walker %d/%d done (%d frames)", k + 1, K, n_frames)

    wall_time_s = time.time() - t_start

    # Write walker_index / frame_index for lagged-pair computation
    walker_idx, frame_idx = build_walker_frame_index(n_frames_each)
    np.save(output_dir / "walker_index.npy", walker_idx)
    np.save(output_dir / "frame_index.npy", frame_idx)

    summary = {
        "n_walkers": K,
        "n_frames_per_walker": n_frames_each,
        "total_frames": int(sum(n_frames_each)),
        "wall_time_s": wall_time_s,
        "output_dir": str(output_dir.resolve()),
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary
