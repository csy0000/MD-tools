"""torsion_features.py — Torsion featurization and per-walker lagged-pair indexing.

All functions are pure numpy. No OpenMM, no deeptime, no mdtraj.

Key rules
---------
* NEVER feed raw periodic angles to TICA/MSM — always use sin/cos embeddings.
* Count lagged pairs ONLY within a single walker trajectory (never across boundaries).
"""
from __future__ import annotations

import numpy as np


# ---------------------------------------------------------------------------
# Sin/cos featurization
# ---------------------------------------------------------------------------

def sincos_features(
    phi_deg: np.ndarray,
    psi_deg: np.ndarray,
) -> np.ndarray:
    """Encode (phi, psi) as [cos_phi, cos_psi, sin_phi, sin_psi] (block ordering).

    Matches the convention of ``gmm_escort.extract_torsion_features``:
    all cosines first, then all sines — shape (N, 4).

    Parameters
    ----------
    phi_deg, psi_deg : (N,) arrays of angles in degrees

    Returns
    -------
    features : (N, 4) float64
    """
    phi = np.asarray(phi_deg, dtype=np.float64)
    psi = np.asarray(psi_deg, dtype=np.float64)
    rad = np.stack([phi, psi], axis=1) * (np.pi / 180.0)  # (N, 2)
    return np.concatenate([np.cos(rad), np.sin(rad)], axis=1)  # (N, 4)


def sincos_features_multi(
    angles_deg: np.ndarray,
) -> np.ndarray:
    """Encode an (N, d) angle array → (N, 2d) [cos block | sin block].

    Generalizes sincos_features to d torsions (not just phi/psi).

    Parameters
    ----------
    angles_deg : (N, d) degrees

    Returns
    -------
    features : (N, 2d) float64
    """
    rad = np.asarray(angles_deg, dtype=np.float64) * (np.pi / 180.0)
    return np.concatenate([np.cos(rad), np.sin(rad)], axis=1)


# ---------------------------------------------------------------------------
# Per-walker lagged-pair index builder
# ---------------------------------------------------------------------------

def build_lagged_pairs(
    walker_ids: np.ndarray,
    frame_ids: np.ndarray,
    lag: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return frame-index pairs (t, t+lag) that lie within the same walker.

    TICA and MSM require lagged correlations computed ONLY within a single
    continuous trajectory. Pairs that cross walker boundaries must never be
    counted — this function enforces that invariant.

    Parameters
    ----------
    walker_ids : (N,) int — walker id for each frame (need not be contiguous)
    frame_ids  : (N,) int — per-walker frame counter (within that walker)
    lag        : int — lag in frames

    Returns
    -------
    t_idx       : (M,) int64 — row indices of the "t"   frames in the full array
    t_lag_idx   : (M,) int64 — row indices of the "t+lag" frames

    Raises
    ------
    ValueError if lag < 1.
    """
    if lag < 1:
        raise ValueError(f"lag must be >= 1, got {lag}")

    walker_ids = np.asarray(walker_ids, dtype=np.int64)
    frame_ids = np.asarray(frame_ids, dtype=np.int64)
    N = len(walker_ids)

    # Build a lookup: (walker_id, frame_id) → row index
    lookup: dict[tuple[int, int], int] = {}
    for row in range(N):
        key = (int(walker_ids[row]), int(frame_ids[row]))
        lookup[key] = row

    t_list: list[int] = []
    t_lag_list: list[int] = []

    for row in range(N):
        wid = int(walker_ids[row])
        fid = int(frame_ids[row])
        lag_key = (wid, fid + lag)
        if lag_key in lookup:
            t_list.append(row)
            t_lag_list.append(lookup[lag_key])

    return np.array(t_list, dtype=np.int64), np.array(t_lag_list, dtype=np.int64)


def build_lagged_pairs_from_counts(
    n_frames_per_walker: list[int],
    lag: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Convenience variant: build lagged pairs when walkers have contiguous frames.

    Assumes walker w occupies rows [start_w, start_w + n_frames_w) in the data
    matrix, in order.

    Parameters
    ----------
    n_frames_per_walker : list of int — number of frames in each walker
    lag : int — lag in frames

    Returns
    -------
    t_idx, t_lag_idx : (M,) int64 arrays
    """
    if lag < 1:
        raise ValueError(f"lag must be >= 1, got {lag}")

    t_list: list[int] = []
    t_lag_list: list[int] = []
    offset = 0
    for n in n_frames_per_walker:
        for i in range(n - lag):
            t_list.append(offset + i)
            t_lag_list.append(offset + i + lag)
        offset += n
    return np.array(t_list, dtype=np.int64), np.array(t_lag_list, dtype=np.int64)


def split_features_by_walker(
    features: np.ndarray,
    walker_ids: np.ndarray,
) -> list[np.ndarray]:
    """Split a (N, d) feature matrix into per-walker sub-arrays.

    Preserves the within-walker ordering. Required for deeptime MSM dtrajs input
    (list of arrays, one per trajectory).

    Parameters
    ----------
    features  : (N, d) array
    walker_ids : (N,) int

    Returns
    -------
    list of (n_w, d) arrays, one per unique walker in sorted-id order
    """
    walker_ids = np.asarray(walker_ids, dtype=np.int64)
    unique = np.unique(walker_ids)
    return [features[walker_ids == w] for w in unique]
