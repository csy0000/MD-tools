"""vonmises_mixture.py — torus-native product-of-univariate von Mises mixture (weighted EM + BIC-argmin).

Factored from the VALIDATED EM in ``scripts/vonmises_basins_alanine.py`` so both BAIS basin-fitting
drivers can replace their Euclidean ``GaussianMixture`` fit with a manifold-aware one. A component density
is a product of univariate von Mises over the D torsions,

    p_k(theta) = prod_d  vM(theta_d; mu_kd, kappa_kd),   vM(x;mu,kappa) = exp(kappa cos(x-mu)) / (2 pi I0(kappa)),

with the exact normalizer prod_d 2 pi I0(kappa_d). EM: mean mu = atan2(sum w sin, sum w cos); kappa from the
Bessel ratio A(kappa) = I1/I0 = Rbar; component weight from responsibilities. Selection is BIC-ARGMIN
(NOT the knee): for the AIS-landing method the fit is on the (few, ~independent, weighted) landings, so no
decorrelation is needed — argmin on that N resolves rare states (e.g. alanine alpha_L) the knee under-resolves.

Weighted fit: each landing carries an AIS importance weight; the weighted EM incorporates them in the M-step
(and in the log-likelihood used by BIC). Weights are normalized to sum to N so -2 logL and p ln N stay on the
same footing as an unweighted N-point fit.

Width mappings for the downstream harmonic-spring / merge machinery (both keep the angular sigma_d ~ 1/sqrt(kappa_d)):
  * ``kappa_to_spherical_var``  -> spherical (cos,sin) variance var = 1/(2 kappa) so that the toy's
    angular width  w_ang = sqrt(2 var) = 1/sqrt(kappa)  (its native radians convention).
  * ``kappa_to_cossin_diag_cov`` -> a diagonal (2D,2D) (cos,sin) covariance whose trace equals the
    validated chord width^2 = sum_d 2(1 - A(kappa_d)),  A = I1/I0  (matches ``kappa_to_cossin_width``);
    the molecular spring rule reads w_i = sqrt(trace Sigma_i).
"""
from __future__ import annotations

import numpy as np
from scipy.special import i0e, i1e   # exponentially-scaled Bessel (stable for large kappa)


# ── von Mises primitives (verbatim from the validated alanine script) ─────────────────────────
def log_i0(kappa):
    """log I0(kappa) via the exp-scaled Bessel: I0(kappa) = i0e(kappa) e^kappa."""
    return np.log(i0e(kappa)) + kappa


def invert_A(Rbar):
    """kappa from A(kappa)=I1/I0=Rbar (Banerjee et al. 2005 init + 2 Newton steps). Rbar in [0,1)."""
    Rbar = np.clip(Rbar, 1e-8, 1 - 1e-8)
    k = Rbar * (2 - Rbar ** 2) / (1 - Rbar ** 2)
    for _ in range(2):
        A = i1e(k) / i0e(k)
        Aprime = 1 - A ** 2 - A / np.maximum(k, 1e-8)
        k = k - (A - Rbar) / np.maximum(Aprime, 1e-8)
    return np.clip(k, 1e-4, 1e6)


def comp_logpdf(theta, mu, kappa):
    """log prod_d vM(theta_d; mu_d, kappa_d) for one component. theta (N,D), mu/kappa (D,) -> (N,)."""
    return np.sum(kappa[None, :] * np.cos(theta - mu[None, :]) - np.log(2 * np.pi) - log_i0(kappa)[None, :], axis=1)


# ── weighted EM ───────────────────────────────────────────────────────────────────────────────
def fit_vmm(theta, K, sample_weight=None, n_iter=100, tol=1e-5, seed=0):
    """Weighted EM for a product-von-Mises mixture on theta (N,D) rad.

    sample_weight (N,) are per-observation weights (e.g. AIS importance weights). They are used in the
    M-step (weighted circular sums) and in the returned weighted log-likelihood. Returns
    (mu (K,D), kappa (K,D), w (K,), logL) where logL = sum_i sample_weight_i * log p(theta_i)."""
    rng = np.random.default_rng(seed)
    theta = np.atleast_2d(np.asarray(theta, float))
    N, D = theta.shape
    sw = np.ones(N) if sample_weight is None else np.asarray(sample_weight, float).ravel()
    mu = theta[rng.choice(N, K, replace=False)].copy()
    kappa = np.full((K, D), 5.0)
    w = np.full(K, 1.0 / K)
    prev = -np.inf
    for _ in range(n_iter):
        # E-step
        logp = np.stack([np.log(w[k] + 1e-300) + comp_logpdf(theta, mu[k], kappa[k]) for k in range(K)], axis=1)
        m = logp.max(1, keepdims=True)
        logZ = m[:, 0] + np.log(np.exp(logp - m).sum(1))
        logL = float((sw * logZ).sum())
        R = np.exp(logp - logZ[:, None])                   # (N,K) responsibilities
        Rw = R * sw[:, None]                                # weighted responsibilities
        # M-step
        Nk = Rw.sum(0) + 1e-12
        w = Nk / Nk.sum()
        for k in range(K):
            for d in range(D):
                C = (Rw[:, k] * np.cos(theta[:, d])).sum(); S = (Rw[:, k] * np.sin(theta[:, d])).sum()
                mu[k, d] = np.arctan2(S, C)
                Rbar = np.sqrt(C ** 2 + S ** 2) / Nk[k]
                kappa[k, d] = invert_A(Rbar)
        if abs(logL - prev) < tol * abs(prev + 1e-12):
            break
        prev = logL
    return mu, kappa, w, logL


def vmm_predict(theta, mu, kappa, w):
    """Hard assignment = argmax_k [log w_k + log p_k(theta)] (von Mises responsibility argmax). (N,) labels."""
    theta = np.atleast_2d(np.asarray(theta, float))
    K = len(w)
    logp = np.stack([np.log(w[k] + 1e-300) + comp_logpdf(theta, mu[k], kappa[k]) for k in range(K)], axis=1)
    return logp.argmax(1)


def _bic(logL, K, D, N):
    """BIC = -2 logL + p ln N,  p = K*(2D) [(mu,kappa) per torsion per comp] + (K-1) free weights."""
    p = K * (2 * D) + (K - 1)
    return -2.0 * logL + p * np.log(max(int(N), 1))


def _knee_K(bics, knee_frac=0.2):
    """Elbow/knee K on the BIC-vs-K curve: the first K whose NEXT component improves BIC by less than
    knee_frac of the largest single-component improvement (diminishing returns). Same rule the toy's original
    spherical-GMM `fit_gmm_bic` used (validated: 2/3/4-mode circular data -> K*=2/3/4). K indexes bics as 1..len."""
    d = -np.diff(np.asarray(bics, float))                   # BIC improvement from adding each component
    Kstar = 1
    if d.size and d.max() > 0:
        thr = knee_frac * d.max()
        Kstar = next((k + 1 for k in range(len(d)) if d[k] < thr), len(bics))
    return int(Kstar)


def fit_vmm_bic(theta, kmax, sample_weight=None, kmin=1, seed=0, n_bic=None,
                select="knee", knee_frac=0.2):
    """Fit product-vM mixtures for K in [kmin, kmax] and select K* from the BIC-vs-K curve.

    theta (N,D) rad; sample_weight (N,) optional. Weights are normalized to sum to n_bic (default N) so the
    weighted log-likelihood is on the same scale as an unweighted N-point fit and the p ln N penalty bites.

    select:
      * "knee" (default) — K* = elbow of the BIC-vs-K curve (`_knee_K`, `knee_frac`): the robust, conservative
        choice that avoids over-splitting a dense/curved basin (e.g. the alanine C7eq/beta ridge, which a
        product-of-1D-vM tiles with several near-duplicate components). Rare states the knee misses on the
        first fit are recovered by the driver's adaptive umbrella-growth step.
      * "argmin" — K* = argmin BIC. More aggressive; resolves rare states directly but over-splits dense
        basins (BIC keeps shaving as extra vM tile a curved ridge). Prefer "knee" + adaptive growth.

    HARD CEILING RULE (both selectors): if the selected K lands on the kmax boundary, BIC never leveled off
    over [kmin, kmax] — the "optimum" is a kmax-ceiling artifact of over-splitting, NOT a real optimum. Drop
    below the ceiling: fall to the interior elbow K_knee (or kmax-1 if the knee is itself at the ceiling).
    `ceiling_fallback=True` flags when this fired.

    Returns dict(Kstar, mu (K*,D), kappa (K*,D), weights (K*,), bics list, logLs list, N_bic, K_argmin, K_knee,
    ceiling_fallback)."""
    theta = np.atleast_2d(np.asarray(theta, float))
    N, D = theta.shape
    n_bic = int(N if n_bic is None else n_bic)
    if sample_weight is None:
        sw = np.ones(N)
    else:
        sw = np.asarray(sample_weight, float).ravel()
        s = sw.sum()
        sw = (sw / s * n_bic) if s > 0 else np.ones(N)      # normalize to sum == n_bic (fractional counts)
    kmax = int(max(kmin, min(kmax, N)))
    fits = {}
    bics, logLs = [], []
    for K in range(kmin, kmax + 1):
        mu, kappa, w, logL = fit_vmm(theta, K, sample_weight=sw, seed=seed)
        fits[K] = (mu, kappa, w)
        bics.append(float(_bic(logL, K, D, n_bic))); logLs.append(float(logL))
    Ks = list(range(kmin, kmax + 1))
    K_argmin = int(Ks[int(np.argmin(bics))])
    K_knee = int(Ks[_knee_K(bics, knee_frac) - 1])          # _knee_K returns 1-based index into bics
    if select == "knee":
        Kstar = K_knee
    elif select == "argmin":
        Kstar = K_argmin
    else:
        raise ValueError(f"select must be 'argmin' or 'knee', got {select!r}")
    ceiling_fallback = False
    if Kstar >= kmax and kmax > kmin:                       # HARD RULE: selected K on the kmax ceiling =
        Kstar = K_knee if K_knee < kmax else kmax - 1       # over-split artifact → drop below the ceiling
        ceiling_fallback = True
    mu, kappa, w = fits[Kstar]
    return dict(Kstar=int(Kstar), mu=mu, kappa=kappa, weights=w, bics=bics, logLs=logLs,
                N_bic=n_bic, K_argmin=K_argmin, K_knee=K_knee, ceiling_fallback=ceiling_fallback)


# ── coordinate + width helpers (mirror the GMM (cos,sin) surface the drivers consume) ──────────
def cossin_to_angles(feat):
    """[cos_1..cos_D, sin_1..sin_D] (N,2D) -> angles (N,D) via atan2(sin_d, cos_d). Works for D=1 (toy)."""
    feat = np.atleast_2d(np.asarray(feat, float))
    D = feat.shape[1] // 2
    return np.arctan2(feat[:, D:], feat[:, :D])


def angles_to_cossin(mu):
    """angles (K,D) -> [cos_1..cos_D, sin_1..sin_D] (K,2D), matching featurize()'s cos-block/sin-block layout."""
    mu = np.atleast_2d(np.asarray(mu, float))
    return np.concatenate([np.cos(mu), np.sin(mu)], axis=1)


def kappa_to_spherical_var(kappa):
    """Spherical (cos,sin) variance from concentration: var = 1/(2 kappa) so sqrt(2 var) = 1/sqrt(kappa) = angular
    sigma. For the toy (D=1) returns a per-component scalar (K,); for D>1 averages 1/(2 kappa_d) over torsions."""
    kappa = np.atleast_2d(np.asarray(kappa, float))            # (K,D)
    return (1.0 / (2.0 * kappa)).mean(axis=1)                  # (K,)


def kappa_to_cossin_diag_cov(kappa):
    """Diagonal (cos,sin) covariance per component with trace == chord width^2 = sum_d 2(1 - A(kappa_d)),
    A = I1/I0 (the validated ``kappa_to_cossin_width`` convention). Each torsion d contributes (1 - A_d) to
    both its cos_d and sin_d diagonal entry. kappa (K,D) -> covs (K, 2D, 2D)."""
    kappa = np.atleast_2d(np.asarray(kappa, float))            # (K,D)
    K, D = kappa.shape
    A = i1e(kappa) / i0e(kappa)                                # I1/I0 per (comp, torsion)
    var_axis = 1.0 - A                                         # (K,D); cos_d and sin_d each get this
    diag = np.concatenate([var_axis, var_axis], axis=1)        # (K,2D): [cos-block, sin-block]
    covs = np.zeros((K, 2 * D, 2 * D))
    idx = np.arange(2 * D)
    covs[:, idx, idx] = diag
    return covs
