from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
from rdkit import rdBase
from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit.Chem import rdDistGeom


ALANINE_DIPEPTIDE_SMILES = "CC(=O)N[C@@H](C)C(=O)NC"


@dataclass
class ETKDGConfig:
    n_conformers: int = 2500
    seed: int = 20260526
    max_mmff_iters: int = 100
    embedding_method: str = "etkdg_v3"
    num_threads: int = 0
    smiles: str = ALANINE_DIPEPTIDE_SMILES


def build_alanine_dipeptide_mol(smiles: str = ALANINE_DIPEPTIDE_SMILES) -> Chem.Mol:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Failed to parse SMILES: {smiles}")
    mol = Chem.AddHs(mol)
    return mol


def make_embed_params(method: str, seed: int, num_threads: int = 0):
    method = method.strip().lower()
    if method == "etkdg_v3":
        params = rdDistGeom.ETKDGv3()
        params.useRandomCoords = False
    elif method == "kdg_random":
        params = rdDistGeom.KDG()
        params.useRandomCoords = True
    else:
        raise ValueError(f"Unknown embedding method: {method}")

    params.randomSeed = int(seed)
    params.numThreads = int(num_threads)
    params.pruneRmsThresh = -1.0
    return params


def generate_etkdg_conformers(config: ETKDGConfig) -> tuple[Chem.Mol, pd.DataFrame]:
    """Backwards-compatible wrapper for conformer generation."""
    return generate_conformers(config)


def generate_conformers(config: ETKDGConfig) -> tuple[Chem.Mol, pd.DataFrame]:
    mol = build_alanine_dipeptide_mol(config.smiles)

    params = make_embed_params(config.embedding_method, config.seed, config.num_threads)

    t0 = time.perf_counter()
    conformer_ids = list(
        AllChem.EmbedMultipleConfs(
            mol,
            numConfs=int(config.n_conformers),
            params=params,
        )
    )
    if len(conformer_ids) == 0:
        raise RuntimeError("RDKit ETKDG failed to generate any conformers")

    mmff_props = AllChem.MMFFGetMoleculeProperties(mol, mmffVariant="MMFF94s")
    if mmff_props is None:
        raise RuntimeError("Could not create MMFF properties for alanine dipeptide molecule")

    records = []
    for conformer_id in conformer_ids:
        ff = AllChem.MMFFGetMoleculeForceField(mol, mmff_props, confId=int(conformer_id))
        if ff is None:
            raise RuntimeError(f"Failed to build MMFF force field for conformer {conformer_id}")
        minimize_status = ff.Minimize(maxIts=int(config.max_mmff_iters))
        energy = ff.CalcEnergy()
        records.append(
            {
                "conformer_id": int(conformer_id),
                "mmff_energy": float(energy),
                "mmff_converged": int(minimize_status == 0),
                "embedding_method": config.embedding_method,
                "use_random_coords": int(bool(getattr(params, "useRandomCoords", False))),
            }
        )

    metadata = pd.DataFrame(records).sort_values("mmff_energy", ascending=True).reset_index(drop=True)
    metadata["rank_by_mmff"] = metadata.index + 1
    metadata = metadata.sort_values("conformer_id", ascending=True).reset_index(drop=True)
    metadata.attrs["wall_time_seconds"] = float(time.perf_counter() - t0)
    metadata.attrs["n_embedded"] = int(len(conformer_ids))
    return mol, metadata


def save_etkdg_outputs(
    mol: Chem.Mol,
    metadata: pd.DataFrame,
    config: ETKDGConfig,
    output_dir: Path,
) -> dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)

    conformers_sdf = output_dir / "conformers.sdf"
    metadata_csv = output_dir / "conformer_metadata.csv"
    lowest_sdf = output_dir / "lowest_mmff_conformer.sdf"
    config_json = output_dir / "config.json"

    ranked = metadata.sort_values("rank_by_mmff", ascending=True).reset_index(drop=True)
    lowest_id = int(ranked.loc[0, "conformer_id"])
    lowest_energy = float(ranked.loc[0, "mmff_energy"])

    writer = Chem.SDWriter(str(conformers_sdf))
    for conformer_id in sorted(metadata["conformer_id"].astype(int).tolist()):
        writer.write(mol, confId=int(conformer_id))
    writer.close()

    low_writer = Chem.SDWriter(str(lowest_sdf))
    low_writer.write(mol, confId=lowest_id)
    low_writer.close()

    metadata.to_csv(metadata_csv, index=False)

    n_embedded = int(metadata.attrs.get("n_embedded", len(metadata)))
    wall_time_seconds = float(metadata.attrs.get("wall_time_seconds", 0.0))
    use_random_coords = int(metadata["use_random_coords"].iloc[0]) if not metadata.empty else 0

    with config_json.open("w", encoding="utf-8") as f:
        json.dump(
            {
                "workflow": "initial_conformer_generation",
                "embedding_method": config.embedding_method,
                "useRandomCoords": bool(use_random_coords),
                "smiles": config.smiles,
                "n_conformers": int(config.n_conformers),
                "n_embedded_conformers": n_embedded,
                "n_mmff_minimized_conformers": int(len(metadata)),
                "n_mmff_converged": int(metadata["mmff_converged"].sum()) if not metadata.empty else 0,
                "seed": int(config.seed),
                "embedding_preset": "ETKDGv3" if config.embedding_method == "etkdg_v3" else "KDG",
                "rdkit_version": rdBase.rdkitVersion,
                "mmff_variant": "MMFF94s",
                "max_mmff_iters": int(config.max_mmff_iters),
                "wall_time_seconds": wall_time_seconds,
                "lowest_mmff_conformer_id": lowest_id,
                "lowest_mmff_energy": lowest_energy,
            },
            f,
            indent=2,
        )

    return {
        "conformers_sdf": conformers_sdf,
        "metadata_csv": metadata_csv,
        "lowest_sdf": lowest_sdf,
        "config_json": config_json,
    }
