"""Load and validate machine-readable system definitions from ``systems/<slug>/system.yaml``.

A system definition is the tracked, machine-readable record of a benchmark molecular system (its
topology, force field, solvent, collective variables, state model, and reference status). It is the
counterpart to the narrative description in ``docs/systems/<slug>.md``.

This is a lightweight, read-only loader — runners are NOT yet required to consume it (see the
migration note in ``docs/protocols/report_and_run_provenance.md``).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from escort_ais.common.paths import project_root

SCHEMA_VERSION = 1
REQUIRED_KEYS = ("schema_version", "slug", "scientific_role", "reference_status",
                 "topology", "forcefield", "solvent_model", "collective_variables", "state_model")
REFERENCE_STATUS_VALUES = {"none", "planned", "in_progress", "available", "validated"}


def systems_root() -> Path:
    return project_root() / "systems"


def system_yaml_path(slug: str) -> Path:
    return systems_root() / slug / "system.yaml"


def list_systems() -> list[str]:
    """Slugs of all systems that have a ``system.yaml``."""
    root = systems_root()
    if not root.exists():
        return []
    return sorted(p.parent.name for p in root.glob("*/system.yaml"))


def load_system(slug: str) -> dict[str, Any]:
    """Load and validate ``systems/<slug>/system.yaml``; returns the parsed dict."""
    import yaml  # deferred; pyyaml is a declared dep

    path = system_yaml_path(slug)
    if not path.exists():
        raise FileNotFoundError(f"no system definition at {path}")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} did not parse to a mapping")
    validate_system(data)
    return data


def validate_system(data: dict[str, Any]) -> None:
    """Raise ``ValueError`` if required keys are missing or enum fields are invalid."""
    missing = [k for k in REQUIRED_KEYS if k not in data]
    if missing:
        raise ValueError(f"system definition missing required keys: {missing}")
    if data["schema_version"] != SCHEMA_VERSION:
        raise ValueError(f"unsupported schema_version {data['schema_version']!r} (expected {SCHEMA_VERSION})")
    if data["reference_status"] not in REFERENCE_STATUS_VALUES:
        raise ValueError(
            f"invalid reference_status {data['reference_status']!r}; allowed {sorted(REFERENCE_STATUS_VALUES)}"
        )
    if not isinstance(data["collective_variables"], list):
        raise ValueError("collective_variables must be a list")


#: Fallback cut-admission thresholds when a system definition declares no ``partition:`` block.
#: These are the macrocycle values; alanine declares its own because the state it exists to resolve
#: holds 0.73%, below the 0.5% tier.
DEFAULT_PARTITION = {
    "stop_barrier_kT": 3.0,
    "min_width_deg": 30.0,
    "min_basin_mass_tiers": "5:0.005,3:0.01",
    "gate_method": "normal",
    "gate_z": 1.0,
    "gate_n_boot": 500,
}


def partition_thresholds(slug: str) -> dict:
    """Cut-admission thresholds for ``slug``, from its ``partition:`` block.

    ``min_basin_mass`` is a per-system SCIENTIFIC choice, not a shared default -- it encodes how
    rare a state the study is about -- so it belongs in the system definition rather than in a CLI
    default that silently follows whichever system was worked on last. Missing keys fall back to
    :data:`DEFAULT_PARTITION`; a system with no definition at all raises.

    The returned ``min_basin_mass`` is ready to hand to either partitioner: a float for a flat
    floor, or a callable of the barrier for a tiered one.
    """
    from escort_ais.methods.nd_basin_tree import parse_floor_spec

    out = dict(DEFAULT_PARTITION)
    try:
        out.update(load_system(slug).get("partition") or {})
    except FileNotFoundError:
        pass
    out["min_basin_mass"] = parse_floor_spec(out["min_basin_mass_tiers"])
    return out
