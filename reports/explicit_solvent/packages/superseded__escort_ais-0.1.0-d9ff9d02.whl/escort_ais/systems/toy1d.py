"""toy1d.py — periodic 1D toy system with analytic ground truth, for validating bAIS+US and bAIS+MSM.

Mirrors the rgd challenge: a MAJOR basin split into two sub-wells (A1, A2) by a tunable internal barrier, plus a
MINOR basin (B) behind a big barrier. Pure numpy/scipy (no OpenMM). Coordinate θ is a periodic angle in RADIANS on
[-π, π). Energies in units of kT (default kT=1).

Model: equilibrium density is a von-Mises mixture  p_eq(θ) = Σ_i w_i·VM(θ; μ_i, κ_i),  and the COLD potential is
U_cold(θ) = −kT·ln p_eq(θ). The REST2-like HOT ensemble scales the potential:  U(θ; s) = s·U_cold(θ)  (s=s_hot<1
lowers barriers → p_hot ∝ p_eq^s, flatter). So the AIS work of a scale switch s_old→s_new at fixed θ is simply
ΔW = (s_new − s_old)·U_cold(θ), and  logw += −βΔW  (β=1/kT), matching ais_linear's Σ −βΔU convention.

Dynamics: overdamped (Brownian) Langevin at fixed kT, potential U(θ; s):
    θ ← θ − (1/γ)·U'(θ; s)·dt + sqrt(2·kT/γ·dt)·ξ,   wrapped to [-π, π).
Ground truth: quadrature Z(s), per-basin populations & free energies, and the Smoluchowski (Fokker–Planck)
operator's slow eigen-timescales (grid master equation with detailed balance).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.special import i0

TWO_PI = 2.0 * np.pi

# ── Numba-JIT kernels for the overdamped-Langevin integrators (≈100× the pure-NumPy loop) ─────────────
# The force needs no Bessel in the loop: with wn_i = w_i/(2π·I0(κ_i)) precomputed, the normalisation cancels
# in dp/p. Falls back to a pure-NumPy path (Toy1D._langevin_np / _us_np) if numba is unavailable.
try:
    from numba import njit
    _HAVE_NUMBA = True
except Exception:                                                    # pragma: no cover
    _HAVE_NUMBA = False

    def njit(*a, **k):                                               # no-op decorator fallback
        def deco(f):
            return f
        return deco(a[0]) if a and callable(a[0]) else deco


@njit(cache=True)
def _wrap1(x):
    return (x + np.pi) % TWO_PI - np.pi


@njit(cache=True)
def _force1(x, s, mu, wn, kappa, kT):
    """dU/dθ = s·(−kT·dp/p) for the von-Mises mixture at a single angle x."""
    p = 0.0; dp = 0.0
    for i in range(mu.shape[0]):
        e = wn[i] * np.exp(kappa[i] * np.cos(x - mu[i]))
        p += e
        dp += (-kappa[i] * np.sin(x - mu[i])) * e
    return s * (-kT * dp / p)


@njit(cache=True)
def _langevin_kernel(x0, n_steps, s, dt, gamma, noise, kT, mu, wn, kappa, save_stride, seed):
    np.random.seed(seed)
    K = x0.shape[0]
    x = np.empty(K)
    for i in range(K):
        x[i] = _wrap1(x0[i])
    out = np.empty((n_steps // save_stride, K))
    si = 0
    for t in range(n_steps):
        for i in range(K):
            f = _force1(x[i], s, mu, wn, kappa, kT)
            x[i] = _wrap1(x[i] - (f / gamma) * dt + noise * np.random.standard_normal())
        if (t + 1) % save_stride == 0:
            for i in range(K):
                out[si, i] = x[i]
            si += 1
    return out[:si]


@njit(cache=True)
def _us_kernel(c, hw, kw, n_steps, burn, walkers, dt, gamma, noise, kT, mu, wn, kappa, save_stride, seed, u_scale):
    """Flat-bottom umbrella Langevin: force = u_scale·dU + wall gradient (0 inside [c±hw])."""
    np.random.seed(seed)
    x = np.empty(walkers)
    for i in range(walkers):
        x[i] = _wrap1(c + (np.random.random() * 2.0 * hw - hw))
    out = np.empty((n_steps // save_stride, walkers))
    si = 0
    for t in range(burn + n_steps):
        for i in range(walkers):
            f = _force1(x[i], u_scale, mu, wn, kappa, kT)             # potential force ×u_scale (wall unscaled)
            d = _wrap1(x[i] - c); dev = abs(d)
            if dev > hw:
                f += kw * (dev - hw) * (1.0 if d > 0.0 else -1.0)
            x[i] = _wrap1(x[i] - (f / gamma) * dt + noise * np.random.standard_normal())
        if t >= burn and (t - burn + 1) % save_stride == 0:
            for i in range(walkers):
                out[si, i] = x[i]
            si += 1
    return out[:si]

# The single toy system: analytic populations 0.42/0.33/0.25 with a crossable A↔B barrier (cold MD eventually
# crosses A↔B, so the cold-MD baselines remain competitive here). Barrier height is decoupled from equilibrium
# weight by tuning only the von-Mises concentrations. REGIME_S / REGIMES are kept as the canonical handles.
REGIME_S = dict(name="S", kappa=np.array([26.0, 26.0, 9.0]),   # A1↔A2 ~2.9 kT, A↔B ~7.1 kT
                barriers_kT=dict(A1_A2=2.9, A_B=7.1))
REGIMES = {"S": REGIME_S}


def wrap(theta):
    """Wrap angle(s) to [-π, π)."""
    return (np.asarray(theta) + np.pi) % TWO_PI - np.pi


@dataclass
class Toy1D:
    # three wells: A1, A2 (major sub-wells, close + tight → tunable internal barrier), B (minor, far → big barrier)
    mu: np.ndarray = field(default_factory=lambda: np.radians([60.0, 120.0, -120.0]))
    w: np.ndarray = field(default_factory=lambda: np.array([0.42, 0.33, 0.25]))
    kappa: np.ndarray = field(default_factory=lambda: np.array([26.0, 26.0, 9.0]))   # the toy system: A1↔A2 ~2.9 kT
    s_hot: float = 0.01
    kT: float = 1.0
    gamma: float = 1.0
    dt: float = 2.0e-3
    u_scale: float = 1.0     # potential amplitude multiplier: U → u_scale·U (same STRUCTURE, u_scale× barriers).
    #                          u_scale=1 is the base toy; u_scale=5 scales the barriers 5x (and the well-depth
    #                          differences, so the populations sharpen — a structure-preserving hardening).

    def __post_init__(self):
        self.mu = np.asarray(self.mu, float); self.w = np.asarray(self.w, float)
        self.kappa = np.asarray(self.kappa, float)
        self.w = self.w / self.w.sum()
        # precompute normalised weights so the JIT force needs no Bessel in the loop
        self._mu = np.ascontiguousarray(self.mu, float)
        self._kap = np.ascontiguousarray(self.kappa, float)
        self._wn = np.ascontiguousarray(self.w / (TWO_PI * i0(self.kappa)), float)

    # ── equilibrium density and potential ────────────────────────────────────
    def _components(self, theta):
        theta = np.atleast_1d(np.asarray(theta, float))
        # (n_wells, N) von-Mises component densities weighted by w
        return np.stack([wi * np.exp(ki * np.cos(theta - mi)) / (TWO_PI * i0(ki))
                         for mi, wi, ki in zip(self.mu, self.w, self.kappa)], axis=0)

    def p_eq(self, theta):
        return self._components(theta).sum(0)

    def U_cold(self, theta):
        return -self.u_scale * self.kT * np.log(self.p_eq(theta))     # u_scale× amplitude (same structure)

    def U(self, theta, s=1.0):
        return s * self.U_cold(theta)

    def dU(self, theta, s=1.0):
        """dU/dθ at scale s. dU_cold/dθ = u_scale·(−kT·(dp/dθ)/p) ; dp/dθ = Σ_i (−κ_i sin(θ−μ_i))·comp_i."""
        c = self._components(theta)                                   # (n_wells, N)
        dc = (-self.kappa[:, None] * np.sin(np.atleast_1d(theta)[None, :] - self.mu[:, None])) * c
        p = c.sum(0); dp = dc.sum(0)
        return s * self.u_scale * (-self.kT * dp / p)

    # ── overdamped Langevin ──────────────────────────────────────────────────
    def langevin(self, x0, n_steps, s=1.0, rng=None, save_stride=1):
        """Vectorized Brownian dynamics. x0 (K,) start angles → trajectory (n_saved, K) wrapped angles.

        Uses the Numba-JIT kernel when available (≈100× faster); the noise realisation differs from the
        pure-NumPy path (the kernel draws its own seeded stream), so trajectories match *statistically*."""
        rng = np.random.default_rng() if rng is None else rng
        x0 = np.atleast_1d(np.asarray(x0, float))
        noise = np.sqrt(2.0 * (self.kT / self.gamma) * self.dt)
        if _HAVE_NUMBA and n_steps >= save_stride:
            seed = int(rng.integers(0, 2**31 - 1))
            # fold u_scale into the effective force scale (kernel force = arg·(−kT dp/p)); noise is s-independent
            return _langevin_kernel(x0, int(n_steps), float(s * self.u_scale), self.dt, self.gamma, noise, self.kT,
                                    self._mu, self._wn, self._kap, int(save_stride), seed)
        x = wrap(np.array(x0, float)); K = x.size
        out = []
        for t in range(n_steps):
            x = wrap(x - (self.dU(x, s) / self.gamma) * self.dt + noise * rng.standard_normal(K))
            if (t + 1) % save_stride == 0:
                out.append(x.copy())
        return np.array(out)                                          # (n_saved, K)

    def sample_equilibrium(self, s, n, rng, burn=3000, walkers=64):
        """Draw ~n equilibrium samples at scale s via Langevin (independent walkers, burn-in then production)."""
        rng = np.random.default_rng() if rng is None else rng
        x = wrap(rng.uniform(-np.pi, np.pi, walkers))
        x = self.langevin(x, burn, s, rng)[-1]                       # burned final state (walkers,)
        steps = int(np.ceil(n / walkers))
        traj = self.langevin(x, steps, s, rng)                       # (steps, walkers)
        return wrap(traj.reshape(-1))[:n]

    def sample_boltzmann(self, s, n, rng, ngrid=4000):
        """Exact equilibrium draw from p ∝ exp(−U(θ;s)/kT) via grid inverse-CDF. Use for the equilibrium REFERENCE
        and hot AIS starts (cold Langevin traps across the big barrier, so it cannot self-equilibrate)."""
        rng = np.random.default_rng() if rng is None else rng
        c, _, h = self._grid(ngrid)
        pdf = np.exp(-self.U(c, s) / self.kT); pdf /= pdf.sum()
        idx = np.searchsorted(np.cumsum(pdf), rng.random(n))
        return wrap(c[np.clip(idx, 0, ngrid - 1)] + (rng.random(n) - 0.5) * h)

    # ── AIS switching (parameter-offset / REST2-scale path) ──────────────────
    def ais_switch(self, x0, s_from, s_to, m_steps, freq, rng, langevin_first=False, schedule=None):
        """AIS along a scale schedule s_from→s_to. x0 (K,) equilibrated at s_from.

        `schedule` (optional) is an explicit array of scale rungs (e.g. a LOG-spaced ladder); its endpoints override
        s_from/s_to and its length sets the number of annealing steps. If None, a LINEAR s_from→s_to ladder of
        m_steps+1 rungs is used. Returns (landing (K,), logw (K,)) with logw = Σ −βΔW, ΔW = (s_new−s_old)·U_cold(θ)
        at fixed θ."""
        rng = np.random.default_rng() if rng is None else rng
        theta = wrap(np.array(x0, float)); K = theta.size
        schedule = np.linspace(s_from, s_to, m_steps + 1) if schedule is None else np.asarray(schedule, float)
        logw = np.zeros(K)
        for j in range(len(schedule) - 1):
            s_old, s_new = schedule[j], schedule[j + 1]
            dW = (s_new - s_old) * self.U_cold(theta)                # ΔW at fixed θ
            logw += -dW / self.kT
            theta = self.langevin(theta, freq, s_new, rng)[-1] if freq > 0 else theta
        return theta, logw

    # ── flat-bottom umbrella sampling ────────────────────────────────────────
    def us_sample(self, center, halfwidth, n_steps, rng, k=200.0, burn=1000, walkers=16, save_stride=1):
        """Langevin on U_cold + flat-bottom wall (zero force inside [center±halfwidth]). Returns samples (M,).

        Reuses the exact flat-bottom form of basin_restraint.flatbottom_energy: E=0.5k·max(0, dev−hw)^2,
        dev=acos(cos(θ−center)); its gradient is 0 inside, k·(dev−hw)·d(dev)/dθ outside."""
        rng = np.random.default_rng() if rng is None else rng
        c = float(center); hw = float(halfwidth)
        noise = np.sqrt(2.0 * (self.kT / self.gamma) * self.dt)
        if _HAVE_NUMBA and n_steps >= save_stride:
            seed = int(rng.integers(0, 2**31 - 1))
            out = _us_kernel(c, hw, float(k), int(n_steps), int(burn), int(walkers), self.dt, self.gamma,
                             noise, self.kT, self._mu, self._wn, self._kap, int(save_stride), seed, float(self.u_scale))
            return wrap(out.reshape(-1))

        def grad_wall(theta):
            d = wrap(theta - c)                                       # in (-π, π]; dev=|d|, sign gives direction
            dev = np.abs(d)
            outside = dev > hw
            g = np.zeros_like(theta)
            g[outside] = k * (dev[outside] - hw) * np.sign(d[outside])
            return g

        x = wrap(c + rng.uniform(-hw, hw, walkers))
        out = []
        for t in range(burn + n_steps):
            force = self.dU(x, 1.0) + grad_wall(x)
            x = wrap(x - (force / self.gamma) * self.dt + noise * rng.standard_normal(walkers))
            if t >= burn and (t - burn + 1) % save_stride == 0:
                out.append(x.copy())
        return wrap(np.array(out).reshape(-1))

    # ── analytic ground truth ────────────────────────────────────────────────
    def _grid(self, ngrid):
        edges = np.linspace(-np.pi, np.pi, ngrid + 1)
        centers = 0.5 * (edges[:-1] + edges[1:])
        return centers, edges, TWO_PI / ngrid

    def partition_function(self, s=1.0, ngrid=4000):
        c, _, h = self._grid(ngrid)
        return float(np.sum(np.exp(-self.U(c, s) / self.kT)) * h)     # ∫ p_eq^s dθ

    def delta_f_hot_cold(self, ngrid=4000):
        """ΔF = F_cold − F_hot = −kT ln(Z_cold/Z_hot)."""
        zc = self.partition_function(1.0, ngrid); zh = self.partition_function(self.s_hot, ngrid)
        return -self.kT * np.log(zc / zh)

    def extrema(self, ngrid=3600):
        """Circular local minima (well centers) and maxima (barriers) of U_cold, as angle arrays (sorted)."""
        c, _, _ = self._grid(ngrid); U = self.U_cold(c)
        lo = np.array([i for i in range(ngrid)
                       if U[i] < U[(i - 1) % ngrid] and U[i] <= U[(i + 1) % ngrid]])
        hi = np.array([i for i in range(ngrid)
                       if U[i] > U[(i - 1) % ngrid] and U[i] >= U[(i + 1) % ngrid]])
        return c[lo], c[hi]

    def basins(self, ngrid=3600):
        """Assign the circle to basins between consecutive barriers (maxima). Returns (boundaries_sorted, centers).

        n_basins = number of minima; boundary angles = the maxima. Basin k = arc between two consecutive maxima
        containing exactly one minimum."""
        mins, maxs = self.extrema(ngrid)
        return np.sort(maxs), np.sort(mins)

    def basin_of(self, theta, boundaries):
        """Well index of each angle given sorted boundary angles (circular)."""
        b = np.sort(np.asarray(boundaries))
        if b.size == 0:
            return np.zeros(np.size(theta), int)
        return (np.searchsorted(b, wrap(theta), side="right") % b.size).astype(int)

    def populations(self, ngrid=4000):
        """Analytic cold populations per basin (∫ p_eq over each basin), well-minimum centers, free energies."""
        c, _, h = self._grid(ngrid)
        boundaries, mins = self.basins(ngrid)
        lab = self.basin_of(c, boundaries)
        p = np.exp(-self.U_cold(c) / self.kT)         # Boltzmann density ∝ p_eq^{u_scale} (= p_eq when u_scale=1)
        n_basins = max(boundaries.size, 1)
        pops = np.array([float(np.sum(p[lab == k]) * h) for k in range(n_basins)])
        pops = pops / pops.sum()
        # well center of basin k = the minimum whose basin label is k (fallback to arc mean)
        min_lab = self.basin_of(mins, boundaries)
        well = np.array([mins[min_lab == k][0] if np.any(min_lab == k) else _basin_center(c, lab, k)
                         for k in range(n_basins)])
        return dict(pops=pops, well_centers_deg=np.degrees(well), boundaries_deg=np.degrees(boundaries),
                    free_energies=-self.kT * np.log(pops), n_basins=n_basins)

    def _fp_generator(self, ngrid=600):
        """Cold Smoluchowski generator on a periodic grid, reversible w.r.t. the Boltzmann π (detailed balance).

        Adjacent-bin rates k_{i→j}=(D/h²)·exp(−(U_j−U_i)/(2kT)) satisfy π_i k_{ij}=π_j k_{ji}, so the
        detailed-balance symmetrisation S=Π^{1/2}QΠ^{-1/2} is REAL SYMMETRIC (off-diag = D/h², a constant) — its
        eigen-spectrum (via eigh) is exact and free of the spurious complex/near-zero modes that plagued the old
        eigvals path. Returns (Q, S, pi, centers)."""
        c, _, h = self._grid(ngrid)
        U = self.U_cold(c); D = self.kT / self.gamma; off = D / h ** 2
        Q = np.zeros((ngrid, ngrid))
        for i in range(ngrid):
            for j in (i - 1, i + 1):
                jj = j % ngrid
                Q[i, jj] = off * np.exp(-(U[jj] - U[i]) / (2 * self.kT))
        np.fill_diagonal(Q, -Q.sum(1))
        pi = np.exp(-U / self.kT); pi /= pi.sum()
        sp = np.sqrt(pi)
        S = (sp[:, None] / sp[None, :]) * Q
        S = 0.5 * (S + S.T)                                          # enforce symmetry against round-off
        return Q, S, pi, c

    def smoluchowski_timescales(self, ngrid=600, n=6, in_frames=True):
        """Slowest relaxation timescales t=−1/λ of the cold Smoluchowski operator (real spectrum via eigh).

        Returned in MD FRAMES by default (physical time / dt) so they compare directly to MSM implied timescales;
        set in_frames=False for physical-time units."""
        _, S, _, _ = self._fp_generator(ngrid)
        lam = np.sort(np.linalg.eigvalsh(S))[::-1]                    # ~0 (stationary), then negative
        neg = lam[lam < -1e-9]
        t = -1.0 / neg[:n]
        return t / self.dt if in_frames else t

    def smoluchowski_kinetics(self, boundaries=None, ngrid=600, in_frames=True):
        """Analytic cold kinetic reference from the FP generator, in MD FRAMES (physical time / dt) by default: the
        two slow relaxation timescales identified as A↔B vs A1↔A2 (by the eigenvector's basin-sign structure), and the
        directional basin MFPTs. These are the ground-truth kinetics the estimators are scored against."""
        Q, S, pi, c = self._fp_generator(ngrid)
        if boundaries is None:
            boundaries = np.radians(self.populations()["boundaries_deg"])
        bas = self.basin_of(c, boundaries).astype(int)               # 0=B, 1=A1, 2=A2 (by well-center order)
        lam, U = np.linalg.eigh(S); order = np.argsort(lam)[::-1]; lam, U = lam[order], U[:, order]
        sp = np.sqrt(pi)
        t_AB = t_A1A2 = np.nan
        for k in range(1, min(6, ngrid)):
            if lam[k] >= -1e-9:
                continue
            v = U[:, k] / sp                                         # eigenvector of Q
            mB, mA1, mA2 = [float(np.mean(v[bas == b])) for b in (0, 1, 2)]
            t = -1.0 / lam[k]
            if np.sign(mA1) == np.sign(mA2) and np.sign(mA1) != np.sign(mB) and np.isnan(t_AB):
                t_AB = t
            elif np.sign(mA1) != np.sign(mA2) and np.isnan(t_A1A2):
                t_A1A2 = t

        def _mfpt(src_bins, dst_bins):
            absorb = np.zeros(ngrid, bool); absorb[dst_bins] = True
            keep = ~absorb
            tau = np.zeros(ngrid)
            tau[keep] = np.linalg.solve(Q[np.ix_(keep, keep)], -np.ones(keep.sum()))
            wsrc = pi[src_bins]; return float(np.sum(wsrc * tau[src_bins]) / wsrc.sum())

        A = np.where((bas == 1) | (bas == 2))[0]; B = np.where(bas == 0)[0]
        A1 = np.where(bas == 1)[0]; A2 = np.where(bas == 2)[0]
        f = 1.0 / self.dt if in_frames else 1.0                       # physical time → MD frames
        return dict(
            slow_its=[float(x * f) for x in (-1.0 / lam[1:4][lam[1:4] < -1e-9])],
            t_AB=t_AB * f, t_A1A2=t_A1A2 * f,
            mfpt_A_to_B=_mfpt(A, B) * f, mfpt_B_to_A=_mfpt(B, A) * f,
            mfpt_A1_to_A2=_mfpt(A1, A2) * f, mfpt_A2_to_A1=_mfpt(A2, A1) * f)


def _basin_center(grid, lab, k):
    """Circular-mean angle of grid points assigned to basin k (helper for populations)."""
    th = grid[lab == k]
    return np.arctan2(np.sin(th).mean(), np.cos(th).mean())
