"""peptide_torsions.py — identify omega (peptide-bond) dihedrals for REST2 exclusion.

For macrocyclic / N-methylated peptides we want the REST2 hot ensemble to keep the
omega (peptide-bond) torsion of *ordinary* peptide bonds physical (so cis/trans is not
artificially induced), while still scaling omega for *proline-like* (tertiary-amide)
bonds where cis/trans is a genuine slow degree of freedom.

Classification (RDKit SMARTS on the amide C-N bond):
  - secondary amide  : the amide N carries a hydrogen (N-H)         -> EXCLUDE omega
  - tertiary amide   : the amide N has no hydrogen (proline / N-Me) -> KEEP scaling omega

The omega torsion is the rotation about the amide C-N bond, so we exclude by the
*central bond* {C, N} (any PeriodicTorsionForce term whose middle two atoms are that
C-N pair is left unscaled).  Indices are returned in OpenMM topology order via the
map produced by ``map_rdkit_atoms_to_openmm_topology``.
"""
from __future__ import annotations

import numpy as np
from rdkit import Chem

# amide C(=O)-N ; match atoms = (carbonyl C, carbonyl O, amide N)
_AMIDE = Chem.MolFromSmarts("[CX3](=[OX1])[NX3]")


def classify_amide_bonds(mol: Chem.Mol) -> list[tuple[int, int, bool]]:
    """Return [(c_idx, n_idx, is_tertiary), ...] (RDKit indices) for each amide bond.

    is_tertiary = the amide nitrogen carries no hydrogen (proline-like: proline or
    N-methylated).  Robust to implicit or explicit hydrogens.
    """
    out = []
    for c_idx, _o_idx, n_idx in mol.GetSubstructMatches(_AMIDE):
        n_atom = mol.GetAtomWithIdx(int(n_idx))
        is_tertiary = n_atom.GetTotalNumHs(includeNeighbors=True) == 0
        out.append((int(c_idx), int(n_idx), bool(is_tertiary)))
    return out


def _invert_omm_to_rdkit(omm_to_rdkit: np.ndarray) -> np.ndarray:
    """omm_to_rdkit[omm] = rdkit  ->  rdkit_to_omm[rdkit] = omm."""
    omm_to_rdkit = np.asarray(omm_to_rdkit, dtype=np.int64)
    inv = np.empty(len(omm_to_rdkit), dtype=np.int64)
    inv[omm_to_rdkit] = np.arange(len(omm_to_rdkit), dtype=np.int64)
    return inv


def omega_exclude_bonds(mol: Chem.Mol, omm_to_rdkit: np.ndarray) -> np.ndarray:
    """Secondary-amide C-N central bonds, in OpenMM atom indices, shape (M, 2).

    These are the omega bonds to leave UNSCALED in the REST2 hot ensemble.
    ``omm_to_rdkit`` is the array from ``map_rdkit_atoms_to_openmm_topology``
    (``omm_to_rdkit[openmm_idx] = rdkit_idx``).
    """
    rdkit_to_omm = _invert_omm_to_rdkit(omm_to_rdkit)
    pairs = [(rdkit_to_omm[c], rdkit_to_omm[n])
             for c, n, is_tertiary in classify_amide_bonds(mol) if not is_tertiary]
    return np.asarray(pairs, dtype=np.int64).reshape(-1, 2)


def central_bond_set(pairs) -> set[frozenset]:
    """{frozenset({i, j}), ...} for fast central-bond lookup in the torsion scaler."""
    return {frozenset((int(a), int(b))) for a, b in np.asarray(pairs).reshape(-1, 2)}


def amide_census(mol: Chem.Mol) -> dict:
    """{'n_amide','n_tertiary','n_secondary'} — a correctness check for a known peptide."""
    amides = classify_amide_bonds(mol)
    n_tert = sum(1 for *_x, t in amides if t)
    return dict(n_amide=len(amides), n_tertiary=n_tert, n_secondary=len(amides) - n_tert)
