"""conformer_seeding.py — Diverse conformer generation for hot-walker seeding.

Three stages:
  1. generate_conformer_pool  — GPU ETKDG+MMFF via nvMolKit (falls back to RDKit
     if nvMolKit is not installed) to produce a large pool of conformers.
  2. maxmin_diversify          — MaxMinPicker on an RMSD matrix to select exactly
     n_pick diverse conformers from the pool.
  3. conformers_to_openmm_seeds — atom-reorder bridge (RDKit order → Amber/tleap
     order, Å → nm) producing the (K, n_atoms, 3) array expected by
     multi_walker_md.run_independent_walkers.

Run conformer generation as a separate process from OpenMM to avoid two CUDA
stacks sharing one interpreter.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np


# ---------------------------------------------------------------------------
# 1. Conformer generation
# ---------------------------------------------------------------------------

def generate_conformer_pool(
    smiles: str,
    n_pool: int = 5000,
    seed: int = 42,
    max_attempts_multiplier: int = 3,
    use_nvmolkit: bool = True,
) -> object:
    """Generate a large pool of 3D conformers via ETKDG + MMFF optimisation.

    Tries nvMolKit (GPU) first if available and use_nvmolkit=True, then falls
    back to standard RDKit ETKDG.

    Parameters
    ----------
    smiles:
        SMILES string for the molecule.
    n_pool:
        Target number of conformers to generate.
    seed:
        Random seed for ETKDG.
    max_attempts_multiplier:
        Multiply n_pool by this factor to over-generate before pruning.
    use_nvmolkit:
        Try nvMolKit GPU generation if True (requires nvmolkit conda package).

    Returns
    -------
    RDKit Mol with n_pool (or fewer) embedded conformers, MMFF-optimised.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles!r}")
    mol = Chem.AddHs(mol)

    n_requested = n_pool * max_attempts_multiplier

    if use_nvmolkit:
        mol = _try_nvmolkit(mol, n_requested, seed)
    else:
        mol = _rdkit_etkdg(mol, n_requested, seed)

    return mol


def _try_nvmolkit(mol, n_requested: int, seed: int):
    """Attempt nvMolKit GPU ETKDG; fall back to RDKit on ImportError."""
    try:
        import nvmolkit  # noqa: F401 — just check availability
        from nvmolkit.confsearch import generate_conformers
        mol = generate_conformers(mol, num_confs=n_requested, random_seed=seed,
                                  ff="mmff94s", minimize=True)
        return mol
    except ImportError:
        return _rdkit_etkdg(mol, n_requested, seed)


def _rdkit_etkdg(mol, n_requested: int, seed: int):
    from rdkit.Chem import AllChem

    params = AllChem.ETKDGv3()
    params.randomSeed = seed
    params.numThreads = 0  # use all available cores
    AllChem.EmbedMultipleConfs(mol, numConfs=n_requested, params=params)

    # MMFF optimisation in-place
    AllChem.MMFFOptimizeMoleculeConfs(mol, numThreads=0)
    return mol


# ---------------------------------------------------------------------------
# 2. MaxMin diversity picking
# ---------------------------------------------------------------------------

def maxmin_diversify(
    mol,
    n_pick: int,
    seed: int = 42,
) -> list[int]:
    """Select n_pick maximally diverse conformer IDs from an RDKit Mol.

    Uses Butina-style MaxMinPicker over pairwise RMSD.

    Parameters
    ----------
    mol:
        RDKit Mol with multiple conformers (MMFF-optimised).
    n_pick:
        Number of diverse conformers to select.
    seed:
        Random seed for the initial pick in MaxMinPicker.

    Returns
    -------
    List of n_pick conformer IDs (0-based).
    """
    from rdkit.Chem import AllChem
    from rdkit.SimDivFilters import rdSimDivPickers

    n_confs = mol.GetNumConformers()
    if n_confs == 0:
        raise ValueError("Molecule has no conformers. Run generate_conformer_pool first.")
    if n_pick > n_confs:
        raise ValueError(
            f"n_pick={n_pick} > n_confs={n_confs}. "
            "Increase n_pool or reduce n_pick."
        )

    # Cache RMSD matrix for fast lookup during LazyPick
    _rmsd_cache: dict[tuple[int, int], float] = {}

    def _dist(i: int, j: int) -> float:
        key = (min(i, j), max(i, j))
        if key not in _rmsd_cache:
            _rmsd_cache[key] = AllChem.GetBestRMS(mol, mol, key[0], key[1])
        return _rmsd_cache[key]

    picker = rdSimDivPickers.MaxMinPicker()
    rng = np.random.default_rng(seed)
    first_pick = int(rng.integers(0, n_confs))
    picked = list(picker.LazyPick(_dist, n_confs, n_pick, firstPicks=[first_pick]))
    return sorted(picked)


def maxmin_diversify_fast(
    mol,
    n_pick: int,
    seed: int = 42,
    heavy_only: bool = True,
) -> list[int]:
    """Faster MaxMin using CalcRMS (no alignment) for large pools (>500 confs).

    For small pools prefer maxmin_diversify which uses GetBestRMS with alignment.
    """
    from rdkit.Chem import AllChem
    from rdkit.SimDivFilters import rdSimDivPickers

    n_confs = mol.GetNumConformers()
    if n_pick > n_confs:
        raise ValueError(f"n_pick={n_pick} > n_confs={n_confs}.")

    # Fast RMSD without alignment
    def rmsd_fn(i, j):
        return AllChem.CalcRMS(mol, mol, i, j, prealigned=False)

    dists: list[float] = []
    for i in range(n_confs):
        for j in range(i):
            dists.append(rmsd_fn(i, j))

    picker = rdSimDivPickers.MaxMinPicker()
    rng = np.random.default_rng(seed)
    first_pick = int(rng.integers(0, n_confs))
    picked = list(picker.LazyPick(dists, n_confs, n_pick, firstPicks=[first_pick]))
    return sorted(picked)


# ---------------------------------------------------------------------------
# 3. Atom-reorder bridge → OpenMM seed positions
# ---------------------------------------------------------------------------

def conformers_to_openmm_seeds(
    mol,
    picked_ids: list[int],
    leap_pdb_path: Path,
) -> np.ndarray:
    """Convert picked RDKit conformers to OpenMM seed positions (Amber order, nm).

    Uses the verified atom-reorder bridge from openmm_system.py.

    Parameters
    ----------
    mol:
        RDKit Mol with 3D conformers (MMFF-optimised, from generate_conformer_pool).
    picked_ids:
        Conformer IDs to extract (from maxmin_diversify).
    leap_pdb_path:
        Path to the canonical tleap/Amber PDB file (e.g. ace_ala_nme_leap.pdb).
        Used as the atom-order reference.

    Returns
    -------
    seed_positions_nm : (K, n_atoms, 3) float64 array in nm, Amber/tleap atom order.
    """
    from rdkit.Chem import AllChem
    from escort_ais.systems.openmm_system import (
        map_rdkit_atoms_to_openmm_topology,
        reorder_positions_to_openmm,
    )

    leap_pdb_path = Path(leap_pdb_path)
    openmm_to_rdkit = map_rdkit_atoms_to_openmm_topology(mol, leap_pdb_path)

    seed_positions: list[np.ndarray] = []
    for cid in picked_ids:
        conf = mol.GetConformer(cid)
        # GetPositions returns (n_atoms, 3) in Angstroms
        coords_ang = np.array(conf.GetPositions(), dtype=np.float64)
        # reorder_positions_to_openmm: Å → nm, RDKit order → Amber order
        coords_nm = reorder_positions_to_openmm(coords_ang, openmm_to_rdkit)
        seed_positions.append(coords_nm)

    return np.stack(seed_positions, axis=0)  # (K, n_atoms, 3) nm


# ---------------------------------------------------------------------------
# Sanity gate: per-conformer energy check before expensive 1000-walker launch
# ---------------------------------------------------------------------------

def check_seed_energies(
    seed_positions_nm: np.ndarray,
    topology_dir: Path,
    scale_factor: float = 1.0,
    energy_upper_kj_mol: float = 1e5,
    platform: Optional[str] = "CPU",
) -> dict:
    """Compute reduced energies for each seed position to catch atom-order bugs.

    Parameters
    ----------
    seed_positions_nm:
        (K, n_atoms, 3) array in nm, Amber order.
    topology_dir:
        Build-topology output directory.
    scale_factor:
        REST2 scale factor to apply (use the hot scale, e.g. 0.4).
    energy_upper_kj_mol:
        Gate: seeds with U > this value are flagged as clashing.
    platform:
        OpenMM platform for energy evaluation.

    Returns
    -------
    dict with keys:
        energies_kj_mol : (K,) float array
        n_valid : int (energies below gate)
        n_clashing : int
        max_energy_kj_mol : float
        gate_passed : bool (all seeds valid)
    """
    from openmm import unit
    from openmm import app
    from escort_ais.methods.md_run import _load_topology, _pick_platform, _create_base_system
    from escort_ais.systems.openmm_system import build_rest2_scaled_system
    from escort_ais.common.paths import BOLTZMANN_KJ_PER_MOL_K  # noqa: F401 — if available

    seed_positions_nm = np.asarray(seed_positions_nm, dtype=np.float64)
    topology_dir = Path(topology_dir)

    topo_config, prmtop_path, _ = _load_topology(topology_dir)
    topology_solvent = topo_config["solvent"]
    n_solute_atoms = int(topo_config["n_solute_atoms"])

    prmtop = app.AmberPrmtopFile(str(prmtop_path))
    platform_name = _pick_platform(platform)

    base_system = _create_base_system(prmtop, topology_solvent, 300.0, 1.0, "nvt",
                                      topology_dir=topology_dir)
    if abs(scale_factor - 1.0) > 1e-9:
        system = build_rest2_scaled_system(base_system, np.arange(n_solute_atoms), scale_factor)
    else:
        system = base_system

    from openmm import LangevinMiddleIntegrator, Platform, Context

    integrator = LangevinMiddleIntegrator(300.0 * unit.kelvin, 1.0 / unit.picosecond,
                                          0.002 * unit.picoseconds)
    omm_platform = Platform.getPlatformByName(platform_name)
    context = Context(system, integrator, omm_platform)

    K = seed_positions_nm.shape[0]
    energies = np.empty(K)

    for k in range(K):
        pos_qty = unit.Quantity(seed_positions_nm[k].tolist(), unit.nanometer)
        context.setPositions(pos_qty)
        state = context.getState(getEnergy=True)
        energies[k] = state.getPotentialEnergy().value_in_unit(
            unit.kilojoule_per_mole
        )

    n_valid = int(np.sum(energies <= energy_upper_kj_mol))
    n_clashing = K - n_valid
    return {
        "energies_kj_mol": energies,
        "n_valid": n_valid,
        "n_clashing": n_clashing,
        "max_energy_kj_mol": float(np.max(energies)),
        "gate_passed": n_clashing == 0,
    }
